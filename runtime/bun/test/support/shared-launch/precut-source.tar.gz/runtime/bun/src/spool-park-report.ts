// The park's whole route, in process: the A1b transaction (`parkPlaced`) and the
// choreography `tap_spool_park_placed` kept in Bash after it — the green/red flash
// cue, the deliverer spawn, the backlog report and its warning, the queue-explanation
// injection branches and the queued receipts. One export for both doors: native
// `send` calls `parkAndReport` in process (its busy-pane route no longer spawns a
// Bash shell to park), and lib.sh's `tap_spool_park_placed` is an adapter over the
// same function through the CLI at the bottom. Ported with it, because these were
// the only live callers left of their bodies: `tap_pane_effect_flash` (+ `_body`),
// `tap_pane_effect_clear_verified`, `tap_spool_spawn_deliverer`,
// `tap_spool_backlog_warn` and the receipt rendering.
//
// The native waiter calls the retained Bash drain engine once per tick. The verbose human
// receipt's `[display state]` token is READINESS (`tap_spool_display_state` →
// `tap_spool_pane_ready`, the reader lane B's B1 ports); it enters as data
// (`ReceiptOptions.displayState`), computed by the incumbent on the Bash door and, on the
// native door, by the caller that owns the verbose form. `reply`'s route is quiet and never
// reads it (opus-xhigh-4, `…070427Z-d30f475f3e74`).
//
// Every decided outcome answers at exit 0 with a verdict; a refusal carries the
// incumbent's class and detail with the canonical retained.

import { closeSync, mkdirSync, openSync, rmSync, writeFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { dirname, join } from "node:path";

import { jsonObj } from "./fsatomic";
import { harnessQueueMessage, harnessQueued } from "./harness-queue";
import { acquirePaneLock } from "./panelock";
import { queueExplanation } from "./queue-explanation";
import { recoveryHold } from "./recovery/state";
import { reownRelease } from "./spool-reown";
import { ParkRefusal, parkPlaced, type ParkInput, type Parked } from "./spool-park";
import { backlogThresholds, spoolBacklog } from "./spool-backlog";
import { unresolvedInjection } from "./submit-phase";
import { observePaneResult, serverEpochFromRaw, tmux } from "./tmux";

// --- the pane-effect flash ------------------------------------------------------------

export interface FlashInput {
  /** `$TAP_HOME`: the effect token lives under `pane-effects/`. */
  home: string;
  pane: string;
  paneId: string;
  ownerId: string;
  style?: string;
  count?: number;
  env?: NodeJS.ProcessEnv;
}

function paneEffectTokenPath(home: string, paneId: string): string {
  return join(home, "pane-effects", `${paneId}.json`);
}

/** `tap_pane_observe`: the live pane id and server epoch, or null when the pane is gone. */
function observe(target: string, env: NodeJS.ProcessEnv): { paneId: string; epoch: string } | null {
  const r = observePaneResult(target, env);
  if (r.status !== "ok") return null;
  return { paneId: r.observation.paneId, epoch: r.observation.serverEpoch };
}

/** `tap_server_epoch_now`: the env pin, else the server's `#{pid}:#{start_time}`; "" when unobservable. */
export function serverEpochNow(env: NodeJS.ProcessEnv = process.env): string {
  if (env.TAP_SERVER_EPOCH !== undefined) return env.TAP_SERVER_EPOCH;
  const r = tmux(["display-message", "-p", "#{pid}:#{start_time}"], env);
  if (r.code !== 0) return "";
  try { return serverEpochFromRaw(r.stdout.replace(/\n$/, ""), env); } catch { return ""; }
}

/**
 * `tap_pane_effect_clear_verified <pane-id> <server-epoch>`: the pane is still the
 * one the effect was applied to (same id, same server generation), the window
 * styles are unset, and nothing remains set — all three, or the token stays.
 */
export function paneEffectClearVerified(paneId: string, epoch: string, env: NodeJS.ProcessEnv = process.env): boolean {
  if (!paneId || !epoch) return false;
  const live = observe(paneId, env);
  if (!live || live.paneId !== paneId || live.epoch !== epoch) return false;
  const r = tmux([
    "set-option", "-p", "-u", "-t", paneId, "window-style", ";",
    "set-option", "-p", "-u", "-t", paneId, "window-active-style", ";",
    "show-options", "-p", "-t", paneId, "window-style", ";",
    "show-options", "-p", "-t", paneId, "window-active-style",
  ], env);
  if (r.code !== 0) return false;
  return r.stdout === "";
}

/**
 * `tap_pane_effect_flash_body`: the effect itself, for a caller that already holds
 * the pane's submit lock. Observe the ADDRESS first (a recycled pane is not ours);
 * mint the effect token exclusively (an existing token means another effect is in
 * flight — do nothing); tint `count` times, re-observing the ID each time; clear and
 * verify; drop the token when the clear is verified or the server generation moved.
 */
export function flashPaneLocked(input: FlashInput): void {
  const env = input.env ?? process.env;
  const style = input.style ?? "bg=red";
  const count = input.count ?? 1;
  if (!input.paneId) return;
  const first = observe(input.pane, env);
  if (!first || first.paneId !== input.paneId || !first.epoch) return;
  const tokenEpoch = first.epoch;
  const path = paneEffectTokenPath(input.home, input.paneId);
  try { mkdirSync(dirname(path), { recursive: true }); } catch { /* the create below reports it */ }
  // `json.dump(…, sort_keys=True)` with Python's default separators, then a newline.
  const token = `{"applied_style": ${JSON.stringify(style)}, "owner_id": ${JSON.stringify(input.ownerId)}, "pane": ${JSON.stringify(input.pane)}, "pane_id": ${JSON.stringify(input.paneId)}, "server_epoch": ${JSON.stringify(tokenEpoch)}, "v": 2}\n`;
  let fd: number;
  try { fd = openSync(path, "wx", 0o600); } catch { return; }
  try { writeFileSync(fd, token); } finally { closeSync(fd); }
  for (let i = 0; i < count; i++) {
    const live = observe(input.paneId, env);
    if (!live || live.paneId !== input.paneId || !live.epoch) break;
    tmux(["select-pane", "-t", input.paneId, "-P", style], env);
  }
  if (paneEffectClearVerified(input.paneId, tokenEpoch, env)) {
    try { rmSync(path, { force: true }); } catch { /* best effort */ }
    return;
  }
  const now = serverEpochNow(env);
  if (now && now !== tokenEpoch) {
    try { rmSync(path, { force: true }); } catch { /* best effort */ }
  }
}

/**
 * `tap_pane_effect_flash`: the locked form. No lock, no flash; a recovery hold on
 * the pane, no flash — the cue is cosmetic and never contends with a delivery.
 */
export function flashPane(input: FlashInput): void {
  const env = input.env ?? process.env;
  // `tap_pane_submit_lock <pane>`: the configured wait (`TAP_PANE_SUBMIT_LOCK_TIMEOUT`,
  // seconds, fractional allowed), else 5 s — a cosmetic cue must not hold a parked send
  // behind a held lock longer than the operator configured.
  const seconds = Number(env.TAP_PANE_SUBMIT_LOCK_TIMEOUT ?? 5);
  const lock = acquirePaneLock(input.paneId, Number.isFinite(seconds) && seconds >= 0 ? seconds * 1000 : 5000, env);
  if (!lock) return;
  try {
    if (recoveryHold(input.paneId, env)) return;
    flashPaneLocked(input);
  } finally {
    lock.release();
  }
}

// --- the deliverer spawn ------------------------------------------------------------------

export interface SpawnDelivererInput {
  /** `$_TAP_SCRIPT_DIR`: locates the sibling Bun runtime and retained drain engine. */
  scriptsDir: string;
  home: string;
  spoolDir: string;
  id: string;
  /** The `.reown` lease the spawn carries to the waiter by ENV (`TAP_SPOOL_REOWN_TOKEN`). */
  reownToken?: string;
  env?: NodeJS.ProcessEnv;
}

/**
 * `tap_spool_spawn_deliverer`: launch the per-entry waiter detached, its output
 * appended to `<home>/tap-deliver.log`, `TAP_SPOOL_DRAIN_ACTIVE` scrubbed so the
 * waiter's own drain is not read as re-entrant. Under `TAP_SPOOL_DISABLE_DELIVERER=1`
 * nothing is spawned and a carried lease is released HERE — the only place that
 * knows the spawn did not happen. A failed spawn releases the lease the same way.
 */
export function spawnDeliverer(input: SpawnDelivererInput): boolean {
  const env = { ...(input.env ?? process.env) };
  const release = (): void => { if (input.reownToken) reownRelease(input.spoolDir, input.id, input.reownToken, env); };
  if (env.TAP_SPOOL_DISABLE_DELIVERER === "1") { release(); return true; }
  delete env.TAP_SPOOL_DRAIN_ACTIVE;
  if (input.reownToken) env.TAP_SPOOL_REOWN_TOKEN = input.reownToken;
  try {
    mkdirSync(input.home, { recursive: true });
    const log = openSync(join(input.home, "tap-deliver.log"), "a");
    try {
      const child = spawn(process.execPath, [join(input.scriptsDir, "../../../runtime/bun/src/spool-waiter.ts"), input.id], {
        env, stdio: ["ignore", log, log], detached: true,
      });
      child.on("error", () => { /* surfaced through the spawn result below */ });
      child.unref();
      if (child.pid === undefined) { release(); return false; }
    } finally {
      closeSync(log);
    }
    return true;
  } catch {
    release();
    return false;
  }
}

// --- the report --------------------------------------------------------------------------

export interface ParkReportInput extends ParkInput {
  from: string;
  kind: string;
  replyExpect: string;
  scriptsDir: string;
}

export interface Backlog { count: string; condition: boolean; line: string; remedy: string }

export interface ParkReport {
  verdict: "ok";
  parked: Parked;
  /** The detached waiter launched (or was suppressed by `TAP_SPOOL_DISABLE_DELIVERER`). A
   *  false here is the incumbent's late park failure: the pair is published and retained,
   *  the canonical retired, and no waiter will redeliver it — the receipt says so. */
  spawned: boolean;
  backlog: Backlog | null;
  /** `unresolvedInjection`: a submit phase record says the id already reached the pane. */
  injected: string | null;
  injectedPhase: "harness-queued" | "injected-enter-unconfirmed" | null;
}

export interface ParkReportHooks {
  flash?: (input: FlashInput) => void;
  spawn?: (input: SpawnDelivererInput) => boolean;
}

/**
 * `tap_spool_park_placed` after its transaction: the cue, the waiter, the backlog
 * (its warning goes to stderr here, as the incumbent's did), and the injection facts
 * the receipt needs. Throws `ParkRefusal` for the transaction's two decided
 * refusals; the caller renders those as `tap_fail` did.
 */
export function parkAndReport(input: ParkReportInput, hooks: ParkReportHooks = {}): ParkReport {
  const env = input.env ?? process.env;
  const parked = parkPlaced(input);
  if (input.cueStyle === "green" || input.cueStyle === "red") {
    // COSMETIC, never load-bearing (the incumbent returned 0 on every failure): a tmux
    // that times out or cannot fork throws from the runner, and that must not stop the
    // waiter spawn below — the pair is already published and the canonical retired.
    try {
      (hooks.flash ?? flashPane)({ home: input.home, pane: input.pane, paneId: input.paneId, ownerId: input.id, style: `bg=${input.cueStyle}`, count: 1, env });
    } catch { /* the cue is best effort */ }
  }
  const spawned = (hooks.spawn ?? spawnDeliverer)({ scriptsDir: input.scriptsDir, home: input.home, spoolDir: input.spoolDir, id: input.id, env });
  // The incumbent's late failure (a bare `tap_spool_spawn_deliverer` under the send doors'
  // errexit) aborted after publication; native send reported the retained pair with this
  // warning. That receipt is now the one outcome on both doors.
  if (!spawned) process.stderr.write(`tap send: warning: parking '${input.id}' did not complete; inspect with tap show ${input.id}; automatic redelivery is not confirmed\n`);
  // `tap_spool_backlog_report "$TO" 2>/dev/null || true`: any failure is "no report".
  let backlog: Backlog | null = null;
  try {
    if (input.target) {
      const [countMin, probesMin] = backlogThresholds(env);
      const report = spoolBacklog(input.spoolDir, input.target, "", Math.floor(Date.now() / 1000), countMin, probesMin) as Record<string, unknown>;
      // Python's `r.get("count") or 0` / `"true" if r.get("condition") else "false"`.
      const count = report.count === undefined || report.count === null || report.count === 0 || report.count === "" || report.count === false ? "0" : String(report.count);
      backlog = { count, condition: !!report.condition, line: String(report.line ?? ""), remedy: String(report.remedy ?? "") };
      if (backlog.condition) process.stderr.write(`tap: WARNING — ${backlog.line}; next: ${backlog.remedy}\n`);
    }
  } catch { backlog = null; }
  const injected = unresolvedInjection(input.home, input.id) || null;
  const injectedPhase = injected ? (harnessQueued(input.home, input.id) ? "harness-queued" : "injected-enter-unconfirmed") : null;
  return { verdict: "ok", parked, spawned, backlog, injected, injectedPhase };
}

export interface ReceiptOptions {
  home: string;
  id: string;
  from: string;
  to: string;
  pane: string;
  kind: string;
  replyExpect: string;
  reason: string;
  policy: string;
  json: boolean;
  /** `TAP_VERBOSE=1`. */
  verbose: boolean;
  /** `tap_send_success_receipt`'s verb: `send`, or `assign` under `TAP_ASSIGN_VERB=1`. */
  verb: "send" | "assign";
  /** The verbose human receipt's readiness token (`tap_spool_display_state`); "" when the caller has none. */
  displayState?: string;
}

/**
 * The queued receipt, byte-for-byte the incumbent's: the harness-queued message, the
 * injected-enter-unconfirmed shapes, or the queued shapes (JSON with the backlog and
 * the queue explanation; human with the readiness token and the explanation line).
 * Every value in the JSON is a string, as `tap_json_obj` emitted them.
 */
export function renderParkReceipt(report: ParkReport, o: ReceiptOptions): string {
  const explanation = queueExplanation(o.home, o.id);
  const receipt = (klass: string, detail: string): string =>
    o.verbose ? `tap ${o.verb}: ${detail}\n` : `tap ${o.verb}: ${klass} ${o.id}\n`;
  if (!report.spawned) {
    // The late park failure: the pair is retained and named; no waiter is coming.
    if (o.json) {
      return `${jsonObj({ status: "queued", delivery: "spool", id: o.id, from: o.from, to: o.to, pane: o.pane, kind: o.kind,
        turn: "unconfirmed", path: report.parked.payload, meta: report.parked.meta, reason: "spool_park_failed", action: `tap show ${o.id}` })}\n`;
    }
    return receipt("queued", `accepted, queued ${o.id} for ${o.to}; reply ${o.replyExpect}. Delivery not confirmed. Inspect with tap show ${o.id}.`);
  }
  if (report.injected) {
    if (report.injectedPhase === "harness-queued") return harnessQueueMessage(o.home, o.id, o.json);
    if (o.json) {
      return `${jsonObj({ status: "queued", phase: "injected-enter-unconfirmed", delivery: "spool", id: o.id, from: o.from, to: o.to,
        pane: o.pane, kind: o.kind, turn: "unconfirmed", path: report.parked.payload, queue_explanation: report.injected })}\n`;
    }
    return `${receipt("injected-enter-unconfirmed", `accepted ${o.id} for ${o.to}; ${report.injected}`)}${report.injected}\n`;
  }
  if (o.json) {
    return `${jsonObj({ status: "queued", delivery: "spool", action: "deliver_when_clear_or_deadline",
      id: o.id, from: o.from, to: o.to, pane: o.pane, kind: o.kind, turn: "unconfirmed",
      path: report.parked.payload, meta: report.parked.meta, reason: o.reason, policy: o.policy, deadline_epoch: report.parked.deadlineEpoch,
      spool_backlog: report.backlog?.count ?? "0", spool_backlog_condition: report.backlog?.condition ? "true" : "false",
      queue_explanation: explanation })}\n`;
  }
  return `${receipt("queued", `accepted, queued ${o.id} for ${o.to}; reply ${o.replyExpect}. Delivery not confirmed. Inspect with tap show ${o.id}; tap resend ${o.id} requires proof that no attempt occurred. [${o.displayState ?? ""}]`)}${explanation}\n`;
}

// --- CLI (the Bash adapter's door) ---------------------------------------------------------
//   park-report <spool> <home> <id> <canonical> <from> <to> <kind> <reply> <acting> <reason> <timeout>
//               <pane> <pane_id> <to_team> <registry> <policy> <grace> <cue_style> <cue_red_at> <scripts_dir>
//     → ok\n<report json>\n | spool_busy\n<detail>\n | spool_publish_failed\n<detail>\n   (exit 0)
//   park-receipt <home> <report json> <id> <from> <to> <pane> <kind> <reply> <reason> <policy> <json 0|1> <verbose 0|1> <verb> <display-state>
//     → the receipt bytes on stdout (exit 0)
//   flash <home> <pane> <pane_id> <owner_id> <style> <count> [locked]
//   spawn-deliverer <scripts_dir> <home> <spool> <id> [<reown-token>]   → ok | failed
//   clear-verified <pane_id> <server_epoch>                              → yes | no
export function main(argv: string[], env: NodeJS.ProcessEnv = process.env): number {
  const [verb, ...rest] = argv;
  const at = (i: number): string => rest[i] ?? "";
  switch (verb) {
    case "park-report": {
      if (rest.length !== 20) { process.stderr.write("spool-park-report: park-report expects 20 positional facts\n"); return 2; }
      try {
        const report = parkAndReport({
          spoolDir: at(0), home: at(1), id: at(2), canonical: at(3), from: at(4), target: at(5), kind: at(6), replyExpect: at(7),
          acting: at(8), reason: at(9), timeoutSeconds: at(10), pane: at(11), paneId: at(12), toTeam: at(13), targetRegistry: at(14),
          policy: at(15), graceSeconds: at(16), cueStyle: at(17), cueRedAt: at(18), scriptsDir: at(19), env,
        });
        process.stdout.write(`ok\n${JSON.stringify(report)}\n`);
        return 0;
      } catch (error) {
        if (error instanceof ParkRefusal) { process.stdout.write(`${error.klass}\n${error.message}\n`); return 0; }
        process.stderr.write(`tap: ${error instanceof Error ? error.message : String(error)}\n`);
        return 1;
      }
    }
    case "park-receipt": {
      if (rest.length !== 14) { process.stderr.write("spool-park-report: park-receipt expects 14 positional facts\n"); return 2; }
      let report: ParkReport;
      try { report = JSON.parse(at(1)) as ParkReport; } catch { process.stderr.write("spool-park-report: report is not JSON\n"); return 2; }
      if (!report || report.verdict !== "ok" || !report.parked) { process.stderr.write("spool-park-report: report is not a park report\n"); return 2; }
      if (at(12) !== "send" && at(12) !== "assign") { process.stderr.write("spool-park-report: verb must be send|assign\n"); return 2; }
      process.stdout.write(renderParkReceipt(report, {
        home: at(0), id: at(2), from: at(3), to: at(4), pane: at(5), kind: at(6), replyExpect: at(7),
        reason: at(8), policy: at(9), json: at(10) === "1", verbose: at(11) === "1", verb: at(12) as "send" | "assign", displayState: at(13),
      }));
      return 0;
    }
    case "flash": {
      if (rest.length < 6) { process.stderr.write("spool-park-report: flash expects <home> <pane> <pane_id> <owner_id> <style> <count> [locked]\n"); return 2; }
      // `count` as the Bash loop read it: "" is the default 1; "0" tints zero times.
      const count = at(5) === "" ? 1 : Number(at(5));
      const input: FlashInput = { home: at(0), pane: at(1), paneId: at(2), ownerId: at(3), style: at(4) || "bg=red", count: Number.isInteger(count) && count >= 0 ? count : 1, env };
      if (at(6) === "locked") flashPaneLocked(input); else flashPane(input);
      return 0;
    }
    case "spawn-deliverer": {
      if (rest.length < 4) { process.stderr.write("spool-park-report: spawn-deliverer expects <scripts_dir> <home> <spool> <id> [<reown-token>]\n"); return 2; }
      const ok = spawnDeliverer({ scriptsDir: at(0), home: at(1), spoolDir: at(2), id: at(3), reownToken: at(4) || undefined, env });
      process.stdout.write(ok ? "ok\n" : "failed\n");
      return 0;
    }
    case "clear-verified": {
      process.stdout.write(paneEffectClearVerified(at(0), at(1), env) ? "yes\n" : "no\n");
      return 0;
    }
    default:
      process.stderr.write("spool-park-report: usage: park-report | park-receipt | flash | spawn-deliverer | clear-verified\n");
      return 2;
  }
}

if (import.meta.main) {
  process.stdout.on("error", (error: NodeJS.ErrnoException) => {
    process.stderr.write(`tap spool-park-report: stdout ${error.code ?? error.message}\n`);
    process.exitCode = 1;
  });
  process.exitCode = main(Bun.argv.slice(2));
}
