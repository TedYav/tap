// `tap done` is RETIRED: the public verb is an audited refusal alias (leader
// ruling L9 — "retire both with the body"). It changes no obligation state;
// its sole write is one append to receipts/done-alias-hits.jsonl. The real
// settler (verbs/done.ts) stays unreachable from the shipped router, and the
// private reply settlement primitive keeps living in
// skills/tap/scripts/tap-reply-settle.sh behind its --reply-payload gate.

import { closeSync, constants, existsSync, mkdirSync, openSync, readdirSync, readFileSync, writeFileSync, fsyncSync } from "node:fs";
import { basename, dirname, join } from "node:path";
import { spawnSync } from "node:child_process";
import { dlopen, FFIType } from "bun:ffi";

import { TapError, callingPane, resolveSelf, type Context } from "../context";
import { envelopeField, validateEnvelope } from "../envelope";
import { validId, validToken } from "../ids";
import { markerSelectedIndex } from "../index-home";
import { logicalId, resolvePayloadAddress, type Resolution } from "../payload-view";
import { currentInstance } from "../registry";
import { assertResetUnfenced } from "../reset";
import { resolveSelection } from "../team-selection";

const DEFAULT_REFUSAL = "tap done is retired; notes settle on read and asks settle by reply";

export function cmdDoneAlias(argv: string[]): number {
  let id = "";
  let actor = process.env.TAP_SELF ?? "";
  let epoch = process.env.TAP_EPOCH ?? "";
  let payload = "";
  let team = "";
  let malformed = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!;
    if (a === "--by" || a === "--epoch" || a === "--payload" || a === "--team") {
      // A value option with no operand is malformed, and the operand is
      // consumed unconditionally either way — even another flag-shaped token.
      if (i + 1 >= argv.length) { malformed = true; break; }
      const value = argv[++i]!;
      if (a === "--by") actor = value;
      else if (a === "--epoch") epoch = value;
      else if (a === "--payload") payload = value;
      else team = value;
    } else if (a.startsWith("--")) malformed = true;
    else if (!id) id = a;
    else malformed = true;
  }
  const pointer = payload;
  if (!id || !validId(id)) malformed = true;

  // lib.sh anchored the bus home before the alias body ran; mirror that. An
  // inherited TAP_HOME is the caller's pin only when its provenance says so —
  // rule "env", or absent (the native door's bare export). A derived rule
  // (dotdir/legacy/default) stays ambient so --team can retarget it, exactly
  // like tap_apply_team_override's env short-circuit (lib.sh:6834).
  const callerPin = process.env.TAP_HOME && ["", "env"].includes(process.env.TAP_BUS_RULE ?? "")
    ? process.env.TAP_HOME : "";
  if (team && !validToken(team)) throw new TapError(1, "usage_error", "tap help", `--team '${team}' fails charset ^[A-Za-z0-9][A-Za-z0-9._-]*$`);
  const selection = resolveSelection(callerPin, team);
  const busHome = selection.bus.home;

  // Identity resolves against the ACTING registry (caller pin > team > cwd),
  // before any team override, exactly like the incumbent's resolve-then-act
  // ordering. Unknown identity is never invented to make the counter complete.
  actor = resolveAliasActor(actor, selection.registryPath);
  if (!actor) {
    throw new TapError(2, "done_retired",
      "notes settle on read; answer an ask with tap reply <id> -f <file>",
      "tap done is retired");
  }

  let bus = busHome;
  let expectation = "";
  let detail = "";
  let status = 2;
  let klass = "done_retired";
  if (!malformed) {
    const ref = payload ? `path=${payload}` : id;
    const sel = markerSelectedIndex(process.env.TAP_INDEX_HOME);
    const indexPath = sel.marker === "invalid" ? "" : sel.path;
    let resolved: Resolution | null = null;
    try { resolved = resolvePayloadAddress(ref, bus, indexPath, "payloads", "", ""); } catch { resolved = null; }
    if (resolved?.status === "found") {
      bus = dirname(dirname(resolved.path));
      if (resolved.residency === "digest") {
        bus = dirname(bus);
        id = basename(resolved.path).slice(0, -5);
        expectation = "digest";
        status = 1;
        klass = "not_obligation";
      } else {
        id = logicalId(resolved.path, resolved.residency);
        try {
          const raw = readFileSync(resolved.path, "utf8");
          if (validateEnvelope(raw).ok) expectation = envelopeField(raw, "reply") || "expected";
        } catch { /* an unreadable payload keeps the generic show repair */ }
      }
    } else if (payload) {
      // A receipt survives payload GC; preserve the old already-settled guard.
      bus = dirname(dirname(payload));
    }
    if (existsSync(join(bus, "receipts", `${id}.done`))) {
      status = 1;
      klass = "already_settled";
      detail = alreadySettledDetail(id, actor, join(bus, "payloads"), join(bus, "receipts"), selection.team);
    }
  }

  let repair = repairCommand({ id, actor, epoch, expectation, malformed, pointer, team });
  if (klass === "already_settled") repair = "handle the open obligation(s) listed";

  requireBusRoot(busHome);
  // The fence refusal precedes the audit write, so a mid-reset bus records no hit.
  // Fence and audit follow the SELECTED AMBIENT bus: a resolved foreign payload
  // names where its receipt lives, not where this refusal audits.
  assertResetUnfenced(busHome, "tap done (audit)");

  let instance = "";
  try { instance = currentInstance(selection.registryPath, actor); } catch { instance = ""; }

  appendAliasAudit(join(busHome, "receipts", "done-alias-hits.jsonl"), {
    action: "done_alias_hit",
    at: utcIso(),
    actor,
    instance: instance || null,
    id: id || null,
    repair,
    fixture: Boolean(process.env.TAP_INDEX_HOME),
    rc: status,
  });

  throw new TapError(status, klass, repair, detail || DEFAULT_REFUSAL);
}

/** TAP_SELF, else a best-effort pane resolve; an unusable answer is no actor. */
function resolveAliasActor(explicit: string, registryPath: string): string {
  let actor = explicit;
  if (!actor) {
    try {
      const pane = callingPane();
      if (pane?.status === "ok") {
        const probe = {
          busRule: "env", team: "", registryPath,
          root: process.env.TAP_HOME ? dirname(process.env.TAP_HOME) : process.cwd(),
        } as unknown as Context;
        actor = resolveSelf(probe, pane, 1).handle;
      }
    } catch { actor = ""; }
  }
  return validToken(actor) ? actor : "";
}

/** Python shlex.quote: safe runs stay bare, the rest gets single quotes. */
function shlexQuote(s: string): string {
  if (!s) return "''";
  if (/^[\w@%+=:,./-]+$/.test(s)) return s;
  return `'${s.replace(/'/g, `'"'"'`)}'`;
}

function repairCommand(f: {
  id: string; actor: string; epoch: string; expectation: string;
  malformed: boolean; pointer: string; team: string;
}): string {
  const q = shlexQuote;
  const teamArg = f.team ? ` --team ${q(f.team)}` : "";
  const address = f.pointer ? `path=${f.pointer}` : f.id;
  if (f.malformed) return "notes settle on read; answer an ask with tap reply <id> -f <file>";
  if (f.expectation === "digest") return `tap read ${q(address)} --all${teamArg}`;
  if (f.expectation === "settle-only") {
    return `tap read ${q(address)} --by ${q(f.actor)}${f.epoch ? ` --epoch ${q(f.epoch)}` : ""}${teamArg}`;
  }
  if (f.expectation === "expected") {
    return `tap reply ${q(f.id)} --by ${q(f.actor)}${f.pointer ? ` --payload ${q(f.pointer)}` : ""}${teamArg} -f <file>`;
  }
  return `tap show ${q(address)}${teamArg}`;
}

/**
 * Shape guard for a caller-pinned bus (twins tap_require_bus_root): container
 * layouts ARE proof a path is not the bus, while a plain custom directory is a
 * documented layout and passes.
 */
function requireBusRoot(busHome: string): void {
  if (busHome.endsWith("/.tap/bus") || busHome.endsWith("/tmp/tap")) return;
  let expected = "";
  if (busHome.endsWith("/.tap")) expected = join(busHome, "bus");
  else if (isDir(join(busHome, ".tap", "bus"))) expected = join(busHome, ".tap", "bus");
  else if (isDir(join(busHome, "tmp", "tap"))) expected = join(busHome, "tmp", "tap");
  else if (busHome.endsWith("/tmp") && isDir(join(busHome, "tap"))) expected = join(busHome, "tap");
  else if (isDir(busHome)) {
    const repo = spawnSync("git", ["-C", busHome, "rev-parse", "--show-toplevel"], { encoding: "utf8" }).stdout.trim();
    if (repo && repo === busHome) expected = join(busHome, ".tap", "bus");
  }
  if (!expected) return;
  throw new TapError(1, "not_a_bus", "unset TAP_HOME or point it at the bus dir",
    `TAP_HOME='${busHome}' does not name a bus; expected '${expected}'`);
}

function isDir(path: string): boolean {
  try { return existsSync(path); } catch { return false; }
}

/**
 * Describe a replayed settlement and the actor's still-open inbound work, in
 * the incumbent's exact sentence (lib.sh tap_already_settled_detail). The
 * local team name is the ACTOR'S SELECTED TEAM — the incumbent's
 * tap_spool_team_name answer — not the resolved payload's bus.
 */
function alreadySettledDetail(id: string, actor: string, payloadsDir: string, receiptsDir: string, localTeam: string): string {
  const receiptAt = (path: string): string => {
    try {
      const at = (JSON.parse(readFileSync(path, "utf8")) as Record<string, unknown>).at;
      return typeof at === "string" && at ? at : "unknown";
    } catch { return "unknown"; }
  };
  const done = join(receiptsDir, `${id}.done`);
  const cancelled = join(receiptsDir, `${id}.cancelled`);
  let at = "unknown";
  if (existsSync(done)) at = receiptAt(done);
  else if (existsSync(cancelled)) at = receiptAt(cancelled);

  const open: string[] = [];
  if (actor) {
    let files: string[] = [];
    try { files = readdirSync(payloadsDir).sort(); } catch { /* no payloads dir: nothing open */ }
    for (const base of files) {
      if (!base.endsWith(".md") || base.startsWith("_")) continue;
      const openId = base.slice(0, -3);
      if (existsSync(join(receiptsDir, `${openId}.done`)) || existsSync(join(receiptsDir, `${openId}.cancelled`))) continue;
      let raw = "";
      try { raw = readFileSync(join(payloadsDir, base), "utf8"); } catch { continue; }
      if (!validateEnvelope(raw).ok) continue;
      if ((envelopeField(raw, "id") ?? "") !== openId) continue;
      if ((envelopeField(raw, "to") ?? "") !== actor) continue;
      const toTeam = envelopeField(raw, "to_team") ?? "";
      if (toTeam && toTeam !== localTeam) continue;
      open.push(openId);
    }
  }
  return open.length
    ? `id ${id} already settled at ${at}; you have ${open.length} open: ${open.join(" ")}`
    : `id ${id} already settled at ${at}; you have 0 open: none`;
}

const LOCK_EX = 2, LOCK_UN = 8;

let flockFn: ((fd: number, op: number) => number) | null | undefined;
function flock(): ((fd: number, op: number) => number) | null {
  if (flockFn !== undefined) return flockFn;
  for (const lib of ["libSystem.B.dylib", "libc.so.6", "libc.so"]) {
    try {
      const { symbols } = dlopen(lib, { flock: { args: [FFIType.i32, FFIType.i32], returns: FFIType.i32 } });
      return (flockFn = symbols.flock as (fd: number, op: number) => number);
    } catch { /* try the next name */ }
  }
  return (flockFn = null);
}

/** The audit append is the alias's sole write: one locked, fsynced JSON line. */
function appendAliasAudit(path: string, row: Record<string, unknown>): void {
  mkdirSync(dirname(path), { recursive: true });
  const fd = openSync(path, constants.O_WRONLY | constants.O_CREAT | constants.O_APPEND, 0o600);
  try {
    const fn = flock();
    if (!fn) throw new Error("done-alias audit requires flock(2) via FFI, which is unavailable on this host");
    // A failed acquisition appends NOTHING — the incumbent's fcntl.flock raises
    // before its write, and an unlocked audit line would understate exclusion.
    if (fn(fd, LOCK_EX) !== 0) {
      throw new Error("done-alias audit could not take its exclusive ledger lock; nothing was appended");
    }
    try {
      writeFileSync(fd, `${JSON.stringify(row)}\n`, "utf8");
      fsyncSync(fd);
    } finally { fn(fd, LOCK_UN); }
  } finally { closeSync(fd); }
}

/** The incumbent's `datetime.now(timezone.utc).isoformat()` shape (+00:00). */
function utcIso(): string {
  const d = new Date();
  const pad = (n: number, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}` +
    `T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}.${pad(d.getUTCMilliseconds(), 3)}+00:00`;
}
