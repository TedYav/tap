import { readFileSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { createInterface } from "node:readline/promises";
import { callingPane, resolveContext, resolveSelf, TapError } from "../context";
import { draftEntries, inputBackupBody } from "../input-backup";
import { validToken } from "../ids";

interface DraftIO {
  tty: boolean;
  out(text: string): void;
  err(text: string): void;
  ask(): Promise<string>;
  copy(text: string): boolean;
}
function options(argv: string[]) {
  let list = false, id = "";
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!;
    if (arg === "--list") list = true;
    else if (arg === "--" && i === argv.length - 1) break;
    else if (arg.startsWith("--") || id || !validToken(arg)) throw new TapError(1, "usage_error", "tap help draft", `unexpected argument '${arg}'`);
    else id = arg;
  }
  if (list && id) throw new TapError(1, "usage_error", "tap help draft", "--list cannot be combined with a backup id");
  return { list, id };
}
const display = (text: Buffer) => text.toString().replace(/[\x00-\x1f\x7f-\x9f]/g, " ");

export async function recoverDraft(argv: string[], directory: string, handle: string, io: DraftIO): Promise<number> {
  const { list, id } = options(argv);
  const entries = draftEntries(directory, handle);
  if (list) {
    io.out(entries.length ? "CREATED\tPAYLOAD_ID\n" + entries.slice(0, 10).map(e => `${e.created}\t${e.payload}\n`).join("") : `tap draft: no drafts backed up for ${handle}\n`);
    return 0;
  }
  let selected = id ? entries.find(e => e.payload.equals(Buffer.from(id))) : entries[0];
  if (!selected) throw new TapError(2, "no_draft", "tap draft --list", `no backed-up draft${id ? ` for '${id}'` : ""} for '${handle}'`);
  if (!id && io.tty) {
    const recent = entries.slice(0, 10);
    io.err(recent.map((e, i) => `${i + 1}. ${display(e.created)}  ${display(e.payload)}\n`).join(""));
    const answer = (await io.ask()).trim();
    if (!answer || answer.toLowerCase() === "q") return 0;
    if (!/^[1-9][0-9]*$/.test(answer) || Number(answer) > recent.length) {
      io.err("tap draft: invalid selection; nothing copied\n"); return 1;
    }
    selected = recent[Number(answer) - 1]!;
  }
  const body = inputBackupBody(readFileSync(selected.path, "utf8"));
  if (!io.copy(body)) io.err("tap draft: clipboard unavailable; printed draft only\n");
  else if (io.tty) io.err("tap draft: copied to clipboard\n");
  io.out(body);
  return 0;
}

export async function cmdDraft(argv: string[]): Promise<number> {
  options(argv);
  const ctx = resolveContext();
  const pane = callingPane();
  if (!pane) throw new TapError(1, "not_in_tmux", "tap whoami", "tap draft needs the caller's registered tmux pane");
  const self = resolveSelf(ctx, pane, 2);
  return recoverDraft(argv, join(ctx.bus.home, "input-backups"), self.handle, {
    tty: !!process.stdin.isTTY,
    out: text => { process.stdout.write(text); },
    err: text => { process.stderr.write(text); },
    ask: async () => {
      const prompt = createInterface({ input: process.stdin, output: process.stderr });
      try { return await prompt.question("Copy draft number (Enter/q cancels): "); }
      finally { prompt.close(); }
    },
    copy: text => spawnSync("pbcopy", [], { input: text }).status === 0,
  });
}
