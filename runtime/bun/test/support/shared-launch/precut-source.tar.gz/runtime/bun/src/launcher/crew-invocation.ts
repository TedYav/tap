// The internal preparation child of `tap crew add`: fresh argv and row-bound tuning.
import { spawnSync } from "node:child_process";
import { accessSync, constants, readFileSync, realpathSync } from "node:fs";
import { basename, dirname, isAbsolute, join, resolve } from "node:path";
import { parseArgs } from "node:util";
import { atomicWrite } from "../fsatomic";
import { pyDumpIndent } from "../lossless-json";
import { acquireRegistryLock } from "../panelock";
import { facadeSecureRead } from "../slices/preset-api";
import { verbose } from "../verbose";
import { dumps, isMap, loads, pyTruthy, type JsonMap, type JsonValue } from "../watch-detect";
import { buildHarnessInvocation } from "./adapters";
import { paramsToArgv, spliceTokensIfAbsent, spliceVerbatimParams } from "./argv-splice";
import { configDirectory, environment, HARNESSES, isRegularFile, refuse, resolveHarnessPolicy } from "./catalog";
import { loadPresetCatalog, requirePreset } from "./catalog-listing";
import { pyBlank } from "./catalog-metadata";
import { Notices } from "./catalog-notices";
import { parseEnvAssignments } from "./overrides";
import { enforcePermissions } from "./permissions";
import { applyLaunchEnv } from "./plan";
import { LauncherError } from "./types";

const quote = (s: string): string => /^[\w@%+=:,./-]+$/.test(s) ? s : `'${s.replace(/'/g, `'"'"'`)}'`;

function realpathLenient(path: string): string {
  const suffix: string[] = [];
  let prefix = resolve(path);
  for (;;) {
    try { return join(realpathSync(prefix), ...suffix); }
    catch {
      if (dirname(prefix) === prefix) return resolve(path);
      suffix.unshift(basename(prefix));
      prefix = dirname(prefix);
    }
  }
}

function loginShell(env: NodeJS.ProcessEnv): string {
  for (const candidate of [env.TAP_LAUNCH_SHELL, env.SHELL, "zsh", "bash", "sh", "/bin/sh"]) {
    if (!candidate) continue;
    let found: string | null = null;
    if (isAbsolute(candidate)) {
      try { accessSync(candidate, constants.X_OK); found = candidate; } catch { /* try PATH */ }
    }
    found ??= Bun.which(candidate, { PATH: env.PATH });
    if (found && ["sh", "bash", "zsh", "dash", "ksh", "ash"].includes(basename(found).replace(/\.exe$/, ""))) return found;
  }
  return "/bin/sh";
}

class ChildFailure extends Error {
  constructor(readonly status: number, detail: string) { super(detail); }
}

/** Keep the existing alias policy in its native owner; only project and transport. */
function supersede(doc: JsonMap, seats: JsonMap, env: NodeJS.ProcessEnv): void {
  const forwardings = doc.get("seat_forwardings");
  if (!Array.isArray(forwardings) || !forwardings.length) return;
  const instances = new Map<string, JsonValue>();
  for (const [handle, row] of seats) instances.set(handle, new Map([["instance", isMap(row) ? row.get("instance") ?? null : null]]));
  const door = join(import.meta.dir, "../forwarding.ts");
  const child = spawnSync("bun", [door, "supersede"], {
    input: dumps(new Map<string, JsonValue>([["seats", instances], ["seat_forwardings", forwardings]]), true),
    env, encoding: "utf8", stdio: ["pipe", "pipe", "pipe"],
  });
  if (child.error) throw child.error;
  if (child.status !== 0) throw new ChildFailure(child.status ?? 1, `command failed (exit ${child.status ?? 1}): bun ${door} supersede`);
  const result = loads(child.stdout);
  if (!isMap(result) || !Array.isArray(result.get("seat_forwardings"))) throw new Error("invalid forwarding supersede response");
  doc.set("seat_forwardings", result.get("seat_forwardings")!);
}

export function crewInvocation(args: string[], env: NodeJS.ProcessEnv = process.env): string {
  const { values, positionals } = parseArgs({ args, allowPositionals: true, options: {
    cwd: { type: "string" }, model: { type: "string" }, preset: { type: "string" },
    "preset-digest": { type: "string" }, env: { type: "string", multiple: true },
    "record-pane": { type: "string" }, "record-registry": { type: "string" },
  } });
  const [harness, name] = positionals;
  if (positionals.length !== 2 || !harness || !HARNESSES.includes(harness) || name === undefined || values.cwd === undefined) {
    throw new LauncherError("usage: crew-invocation <harness> <name> --cwd <path> [--preset <name> | --model <model>]");
  }
  const notices = new Notices();
  notices.suppress(env.TAP_JSON === "1");
  let model: string | null = values.model ?? null;
  let seatEnv: Record<string, string> = {};
  let passthrough: string[] = [];
  let preset: { name: string; source_path: string; config_digest: string } | null = null;
  if (values.preset !== undefined) {
    const catalog = loadPresetCatalog(env, notices.sink, facadeSecureRead, configDirectory(env), isRegularFile);
    const selected = requirePreset(catalog, values.preset);
    if (values["preset-digest"] && selected.provenance.config_digest !== values["preset-digest"]) {
      refuse("preset_config_changed", `preset '${values.preset}' resolved against a different catalog than this launch was planned with (config digest changed mid-launch)`,
        "re-run the command; the catalog changed while this seat was starting");
    }
    const combined = [values.model !== undefined ? "--model" : "", values.env !== undefined ? "--env" : ""].filter(Boolean);
    if (combined.length) refuse("preset_not_composable", `preset '${values.preset}' is complete; ${combined.join(" and ")} cannot override it`,
      `drop ${combined.join(" and ")}, or add the crew without --preset and pass tuning by flag`);
    if (harness !== selected.harness) refuse("preset_harness_mismatch", `preset '${values.preset}' uses harness '${selected.harness}', not requested harness '${harness}'`,
      `use --harness ${selected.harness}, or choose a preset whose harness is '${harness}'`);
    model = selected.model;
    seatEnv = selected.env;
    passthrough = selected.harness_passthrough;
    preset = selected.provenance;
  } else {
    // Parsing precedes model validation; model precedes the environment fence.
    const rawEnv = parseEnvAssignments(values.env);
    if (model !== null) {
      if (pyBlank(model)) refuse("launch_arg_invalid", "--model must be a non-empty string", "fix the --model value");
      if (/[\x00-\x1f\x7f]/.test(model)) refuse("launch_arg_invalid", "--model contains a control character", "fix the --model value");
    }
    seatEnv = environment(rawEnv, "launch_env_forbidden", {
      notTable: () => refuse("launch_arg_invalid", "--env values must be supplied as KEY=VALUE pairs", "pass environment as --env KEY=VALUE"),
      keyInvalid: key => refuse("launch_arg_invalid", `--env key '${key}' is not a valid environment variable name`, `fix the --env key '${key}'`),
      forbidden: key => refuse("launch_env_forbidden", `--env key '${key}' crosses the identity, transport, process, credential, or policy fence`, `remove --env ${key}=... from the command`),
      fieldError: (field, problem) => refuse("launch_arg_invalid", `--env ${field.slice(4)} ${problem}`, `fix the --env ${field.slice(4)} value`),
    });
  }
  if (model === null) refuse("launch_arg_invalid", "crew add requires an explicit validated launch model; harness defaults cannot establish model identity",
    "use a preset with params.model, or pass --model <model>");

  // Crew has no conversation id. Bind permissions once for argv, checks and persistence.
  const policy = resolveHarnessPolicy(harness, env, notices, facadeSecureRead);
  const permissions = ["claude", "codex"].includes(harness) ? policy.permissions : "bypass";
  const record = { name, harness, cwd: realpathLenient(values.cwd), base: name.split("/", 1)[0]!, model, harness_env: seatEnv };
  const invocation = applyLaunchEnv(buildHarnessInvocation("new", record, null, null, env, permissions), record, env, notices.sink, () => {
    const current = resolveHarnessPolicy(harness, env, notices, facadeSecureRead);
    for (const notice of current.notices) notices.emit(notice);
    return current.env;
  });
  let argv = passthrough.length
    ? spliceTokensIfAbsent(invocation.argv, passthrough, { floor: preset !== null, configKeys: harness === "codex" }) : invocation.argv;
  const params = resolveHarnessPolicy(harness, env, notices, facadeSecureRead).params;
  for (const source of [passthrough, paramsToArgv(params), argv.slice(1)]) enforcePermissions(harness, permissions, source);
  argv = spliceVerbatimParams(argv, params, { configKeys: harness === "codex" });
  if (harness === "opencode") {
    const clean: string[] = [];
    for (let i = 0; i < argv.length; i++) {
      const token = argv[i]!, key = token.split("=", 1)[0]!;
      if (key === "--session" || key === "-s") {
        if (!token.includes("=") && i + 1 < argv.length && !argv[i + 1]!.startsWith("-")) i++;
      } else if (key !== "--continue" && key !== "-c") clean.push(token);
    }
    argv = clean;
  }

  const pane = values["record-pane"];
  if (pane) {
    const path = values["record-registry"];
    if (!path) throw new LauncherError("crew recipe persistence requires its acting registry");
    const handle = name.slice(name.indexOf("/") + 1);
    // Match flock(LOCK_EX), including contention beyond the native five-second default.
    const lock = acquireRegistryLock(path, Infinity, env);
    if (!lock) throw new LauncherError("could not obtain crew recipe registry lock");
    try {
      const doc = loads(readFileSync(path, "utf8"));
      if (!isMap(doc)) throw new LauncherError("crew registry is not an object");
      const seats = doc.get("seats"), agents = doc.get("agents");
      const rows = isMap(seats) ? seats : isMap(agents) ? agents : new Map<string, JsonValue>();
      const row = rows.get(handle);
      if (!isMap(row) || !pyTruthy(row.get("crew")) || row.get("pane_id") !== pane || row.get("harness") !== harness) {
        throw new LauncherError(`crew launch row changed before recipe persistence for ${handle}; expected crew pane ${pane} with harness ${harness}`);
      }
      for (const [key, value] of Object.entries({ model, permissions, harness_env: seatEnv, passthrough,
        passthrough_from_config: preset !== null, preset })) row.set(key, loads(JSON.stringify(value)));
      supersede(doc, rows, env);
      verbose("state_write", { path }, env);
      atomicWrite(path, `${pyDumpIndent(doc, 0)}\n`);
    } finally { lock.release(); }
  }
  const effectiveEnv = { ...invocation.env };
  for (const key of ["TAP_INDEX_HOME", "TAP_TMUX_SOCKET_PATH", "TAP_TMUX_SOCKET"]) if (env[key]) effectiveEnv[key] = env[key]!;
  const command = Object.keys(effectiveEnv).length
    ? ["/usr/bin/env", ...Object.keys(effectiveEnv).sort().map(key => `${key}=${effectiveEnv[key]}`), ...argv] : argv;
  return [loginShell(env), "-lic", 'exec "$0" "$@"', ...command].map(quote).join(" ");
}

export function crewInvocationCli(args: string[]): number {
  try { process.stdout.write(`${crewInvocation(args)}\n`); return 0; }
  catch (error) {
    if (error instanceof ChildFailure) { process.stderr.write(`tap session: ${error.message}\n`); return error.status; }
    if (!(error instanceof LauncherError) && (error as NodeJS.ErrnoException).code === "ENOENT") {
      process.stderr.write(`tap session: missing command: ${(error as NodeJS.ErrnoException & { path?: string }).path ?? "bun"}\n`); return 127;
    }
    const known = error instanceof LauncherError ? error : null;
    // The Python permissions check was a LauncherError, not a PresetError.
    const presetError = known?.errorClass && known.errorClass !== "harness_permissions_conflict";
    const detail = presetError ? known!.detail ?? known!.message : (error as Error).message;
    if (process.env.TAP_JSON === "1") process.stdout.write(JSON.stringify({ ok: false,
      error_class: presetError ? known!.errorClass : "session_error",
      action: presetError ? known!.action ?? "tap help session" : "tap help session", detail }) + "\n");
    else process.stderr.write(`tap session: ${detail}${presetError ? `; next: ${known!.action ?? "tap help session"}` : ""}\n`);
    return 2;
  }
}

if (import.meta.main) process.exitCode = crewInvocationCli(process.argv.slice(2));
