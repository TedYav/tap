// The lossless indent-2 registry serializer (python `json.dump(indent=2,
// sort_keys=True)` over the lossless parse): shared by the retirement and
// registration transactions so unknown wide-number metadata survives every
// locked rewrite. Extracted verbatim from out-retire.ts's private copy.
import { ensureAscii } from "./fsatomic";
import { pyFloatRepr } from "./spool-publication";
import type { JsonFloat, JsonValue } from "./watch-detect";
import { isMap } from "./watch-detect";

export function pyDumpIndent(v: JsonValue, depth: number): string {
  const pad = "  ".repeat(depth + 1);
  if (typeof v === "string") return ensureAscii(JSON.stringify(v));
  if (typeof v === "bigint") return v.toString();
  if (typeof v === "boolean" || v === null) return String(v);
  if (typeof v === "number") return pyFloatRepr(v);
  if (Array.isArray(v)) return v.length === 0 ? "[]" : `[\n${v.map(x => `${pad}${pyDumpIndent(x, depth + 1)}`).join(",\n")}\n${"  ".repeat(depth)}]`;
  if (isMap(v)) return v.size === 0 ? "{}" : `{\n${[...v.entries()].sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0)).map(([k, x]) => `${pad}${ensureAscii(JSON.stringify(k))}: ${pyDumpIndent(x, depth + 1)}`).join(",\n")}\n${"  ".repeat(depth)}}`;
  return (v as JsonFloat).float;
}
