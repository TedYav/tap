import { lifecycleDiagnostic } from "../lifecycle-diagnostics";
import { startupTrace, startupTransition, withStartupTrace } from "../startup-trace";

import { spawnSync } from "node:child_process";
import { resolve } from "node:path";
import { isatty } from "node:tty";
import { attachReady, captureAttachIntent } from "./attach";
import { randomUUID } from "node:crypto";
import { withActingRegistry } from "../registry-tx";
import { resolveContext, type ResolvedContext } from "../context";
import { saveRegistry, ensureSeatInstance, type Seat } from "../registry";
import { acquireResetMutationLock, markResetGenerationReused } from "../reset";
import { bootId, legacyBootId, serverEpochFromRaw, tmuxReadOnly } from "../tmux";
import { validToken } from "../ids";
import { parseLaunch, type LaunchRequest } from "./request";
import { refuse } from "./catalog";
import { reservationExpired } from "../reservation";
import { harnessCommand, execReachedHarness, observeLaunchPane, onOwnedPane, parseLaunchPane,
  sameLaunchPane, shellQuote, tmuxEffect, LAUNCH_PANE_FORMAT, type LaunchPane } from "./effects";

// Under heavy load a healthy start may exceed this bound. Refuse with evidence;
// never relaunch or weaken the readiness predicate to make the deadline pass.
export const HARNESS_START_TIMEOUT_MS = 5_000;
export const DETACHED_SESSION_SIZE = { columns: 200, rows: 60 } as const;
export class LaunchInterrupted extends Error {
  constructor(readonly exitCode: number) { super("launcher_interrupted: launch cancelled"); }
}

export type LaunchClaim = { handle: string; session: string; harness: string; token: string; instance: string };

export function stableHarnessStep(
  previous: string | null,
  pane: LaunchPane,
  reachedHarness: boolean,
): { identity: string | null; ready: boolean } {
  if (!reachedHarness) return { identity: null, ready: false };
  const identity = [pane.paneId, pane.epoch, pane.pid, pane.command].join("\t");
  return { identity, ready: previous === identity };
}

function owns(row: Seat | undefined, claim: LaunchClaim): row is Seat {
  return !!row && row.launch_id === claim.token && row.instance === claim.instance && row.session === claim.session && row.harness === claim.harness;
}

export function reserveLaunch(ctx: ResolvedContext, request: LaunchRequest): LaunchClaim {
  const snapshot = tmuxReadOnly(["list-sessions", "-F", "#{session_name}"], process.env);
  const sessions = snapshot.code === 0 ? new Set(snapshot.stdout.trim().split("\n").filter(Boolean))
    : /no server running|no sessions|error connecting.*No such file/.test(snapshot.stderr) ? new Set<string>() : null;
  if (sessions === null) refuse("launcher_tmux_unobservable", "cannot inspect existing sessions; check tmux and retry");
  const currentBoot = bootId() || null;
  const legacy = legacyBootId() || null;
  return withActingRegistry(ctx, (doc, seats) => {
    const handle = request.handle;
    const session = `${ctx.team}/${handle}`;
    if (sessions.has(session) || (Object.hasOwn(seats, handle) &&
        !reservationExpired(seats[handle]!, sessions, Date.now() / 1000, currentBoot, legacy))) {
      return refuse("native_launcher_unsupported", `${handle} is already claimed; use TAP_LAUNCHER=python tap session launch or choose another name`);
    }
    const token = randomUUID();
    const now = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
    const row: Seat = {
      session, base: ctx.team, tag: handle, index: 1, harness: request.harness, model: request.model,
      permissions: request.permissions, passthrough: request.passthrough, history: [], adopted_from_manual: false,
      ...(request.sessionId ? { harness_session_id: request.sessionId } : {}),
      identity_capture: { mode: "launcher_new", ...(request.sessionId ? { expected_harness_session_id: request.sessionId } : {}) },
      status: "pending", registered_from_worktree: ctx.selection!.rootReal, registered_at: now, last_launched: now,
      launch_id: token,
    };
    if (request.unsetEnv?.length) row.harness_unset_env = request.unsetEnv;
    if (request.harnessTail?.length) row.harness_tail = request.harnessTail;
    if (Object.keys(request.storedEnv).length) row.harness_env = request.storedEnv;
    if (request.preset) row.preset = request.preset;
    if (request.passthroughFromConfig) row.passthrough_from_config = true;
    if (currentBoot) row.boot_id = currentBoot;
    const instance = ensureSeatInstance(row, handle);
    seats[handle] = row;
    saveRegistry(ctx.registryPath, doc);
    return { handle, session, harness: request.harness, token, instance };
  });
}

export function bindLaunch(ctx: ResolvedContext, claim: LaunchClaim, expected: LaunchPane, ready: boolean): void {
  withActingRegistry(ctx, (doc, seats) => {
    const row = seats[claim.handle];
    const alreadyReady = ready && row?.status === "active" && row.status_reason === "" && !row.launch_id &&
      row.instance === claim.instance && row.session === claim.session && row.harness === claim.harness && row.pane_id === expected.paneId;
    if (alreadyReady) return;
    if (!owns(row, claim)) refuse("launcher_claim_lost", `reservation changed for ${claim.handle}`);
    if (ready ? row.status !== "active" || row.status_reason !== "launching" || row.pane_id !== expected.paneId
      : row.status !== "pending") refuse("launcher_claim_lost", `reservation stage changed for ${claim.handle}`);
    if (!/^%[0-9]+$/.test(expected.paneId)) refuse("launcher_identity_unverified", "invalid pane_id at registry boundary");
    const observed = observeLaunchPane(expected.paneId, process.env);
    if (!sameLaunchPane(expected, observed) || observed.dead) refuse("launcher_identity_changed", `pane identity changed for ${claim.handle}`);
    if (ready && !execReachedHarness(observed, String(row.harness))) refuse("launcher_not_started", `harness is not running for ${claim.handle}`);
    row.delivery = "pane";
    row.status = "active";
    row.status_reason = ready ? "" : "launching";
    row.pane = observed.address;
    row.pane_id = observed.paneId;
    row.pane_current_command = observed.command;
    if (observed.epoch) row.server_epoch = observed.epoch; else delete row.server_epoch;
    const namespace = tmuxReadOnly(["display-message", "-p", "#{pid}:#{start_time}\t#{socket_path}"], process.env);
    const [rawEpoch, socket] = namespace.stdout.trim().split("\t");
    if (namespace.code === 0 && rawEpoch && socket?.startsWith("/") && serverEpochFromRaw(rawEpoch) === observed.epoch) row.server_socket = socket;
    else delete row.server_socket;
    const currentBoot = bootId();
    if (currentBoot) row.boot_id = currentBoot; else delete row.boot_id;
    row.registered_at = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
    if (ready) delete row.launch_id;
    saveRegistry(ctx.registryPath, doc);
  });
}

/** A late failure cannot remove a new incarnation or a launch already committed ready. */
export function rollbackLaunch(ctx: ResolvedContext, claim: LaunchClaim, pane?: LaunchPane): boolean {
  return withActingRegistry(ctx, (doc, seats) => {
    if (!owns(seats[claim.handle], claim)) return false;
    if (pane && !onOwnedPane(pane, `kill-pane -t ${shellQuote(pane.paneId)}`, process.env, true)) {
      process.stderr.write(`tap session: cleanup left ${pane.paneId} untouched because its identity changed\n`);
    }
    const before = seats[claim.handle];
    delete seats[claim.handle];
    saveRegistry(ctx.registryPath, doc);
    startupTransition(ctx.registryPath, claim.handle, before, null, false);
    return true;
  });
}

export function launch(args: string[]): Promise<number> {
  return withStartupTrace(() => launchOperation(args));
}

async function launchOperation(args: string[]): Promise<number> {
  const request = parseLaunch(args);
  const ctx = resolveContext(request.cwd);
  // Pane-anchored selection (tap-7s1r) is context, not enrollment: the
  // launcher must never treat a pane-selected team as permission to launch
  // into an unenrolled linked worktree.
  if (ctx.selection?.authority !== "enrolled" || ctx.selection?.source === "pane") refuse("launcher_unenrolled", "Bun launch requires an enrolled cwd; use tap init or TAP_LAUNCHER=python");
  if (!validToken(ctx.team) || ctx.team.includes(".")) refuse("launcher_team_invalid", "enrolled team name must be a valid token without dots");
  // Qualify the builder's name without interpreting the operator's literal tail.
  if (request.harness === "claude") {
    const baseline = request.argv.slice(0, request.argv.length - (request.harnessTail?.length ?? 0));
    request.argv[baseline.lastIndexOf("--name") + 1] = `${ctx.team}/${request.handle}`;
  }
  if (request.dryRun) {
    process.stdout.write(request.json ? JSON.stringify({ name: `${ctx.team}/${request.handle}`, harness: request.harness,
      cwd: request.cwd, argv: request.argv, env: request.env, unset_env: request.unsetEnv ?? [], preset: request.preset }) + "\n"
      : `tap session: native launcher (bun) would launch ${ctx.team}/${request.handle} (${request.harness}) in ${request.cwd}\n`);
    return 0;
  }
  lifecycleDiagnostic("launch_request", { cwd: request.cwd, session: `${ctx.team}/${request.handle}`, harness: request.harness, attach: request.attach });
  startupTrace("launch_start", { verb: "launch", cwd: request.cwd, session: `${ctx.team}/${request.handle}`, harness: request.harness, boot_id: bootId() }, true);

  const bootstrap = spawnSync("python3", ["-B", resolve(import.meta.dir, "../../../../skills/tap/scripts/tmux_bootstrap.py")], {
    encoding: "utf8", env: process.env, timeout: 20_000,
  });
  if (bootstrap.status !== 0) refuse("tmux_bootstrap_failed", bootstrap.stderr.trim() || "tmux bootstrap failed; next: tap doctor");
  const attachIntent = request.attach !== "never" && (request.attach === "always" || (isatty(0) && isatty(1)))
    ? captureAttachIntent(process.env) : null;
  if (attachIntent?.kind === "outside" && typeof process.execve !== "function") {
    refuse("native_launcher_unsupported", "outside native attach requires Bun process.execve; use --detach or TAP_LAUNCHER=python");
  }
  const fence = acquireResetMutationLock(ctx.bus.home, "session launch");
  let claim: LaunchClaim | undefined;
  let pane: LaunchPane | undefined;
  let creationStarted = false;
  let interruptCode = 0;
  const onInt = () => { interruptCode = 130; };
  const onTerm = () => { interruptCode = 143; };
  process.on("SIGINT", onInt);
  process.on("SIGTERM", onTerm);
  const checkpoint = async () => {
    await Bun.sleep(0);
    if (interruptCode) throw new LaunchInterrupted(interruptCode);
  };
  try {
    claim = reserveLaunch(ctx, request);
    markResetGenerationReused(ctx.bus.home, "session-launch");
    await checkpoint();
    creationStarted = true;
    startupTrace("create_session", { session: claim.session, launch_id: claim.token });
    const output = tmuxEffect(["new-session", "-d", "-x", String(DETACHED_SESSION_SIZE.columns),
      "-y", String(DETACHED_SESSION_SIZE.rows), "-s", claim.session, "-c", request.cwd, "-P", "-F",
      LAUNCH_PANE_FORMAT,
      "exec /bin/sleep 2147483647"], process.env);
    pane = parseLaunchPane(output, process.env) ?? undefined;
    if (!pane) refuse("launcher_identity_unverified", `cannot identify new pane for ${claim.session}`);
    if (pane.session !== claim.session) refuse("launcher_identity_changed", `tmux changed session name ${claim.session} to ${pane.session}`);
    bindLaunch(ctx, claim, pane, false);
    await checkpoint();
    const command = harnessCommand(request, process.env);
    startupTrace("respawn_pane", { session: claim.session, pane: pane.paneId, server_epoch: pane.epoch });
    const priorRemain = tmuxEffect(["show-options", "-p", "-v", "-t", pane.paneId, "remain-on-exit"], process.env).trim();
    if (!["", "on", "off", "failed"].includes(priorRemain)) refuse("launcher_tmux_failed", "unrecognized remain-on-exit setting");
    onOwnedPane(pane, `set-option -p -t ${shellQuote(pane.paneId)} remain-on-exit on ; respawn-pane -k -t ${shellQuote(pane.paneId)} -c ${shellQuote(request.cwd)} ${shellQuote(command)}`, process.env);
    const deadline = Date.now() + HARNESS_START_TIMEOUT_MS;
    let priorHarnessIdentity: string | null = null;
    while (true) {
      if (interruptCode) throw new LaunchInterrupted(interruptCode);
      const current = observeLaunchPane(pane.paneId, process.env);
      if (!sameLaunchPane(pane, current) || current.dead) refuse("launcher_not_started", `harness exited or pane changed for ${claim.handle}`);
      const stable = stableHarnessStep(
        priorHarnessIdentity,
        current,
        execReachedHarness(current, request.harness),
      );
      priorHarnessIdentity = stable.identity;
      const now = Date.now();
      if (stable.ready) break;
      if (now >= deadline) refuse("launcher_not_started", `harness did not start for ${claim.handle}`);
      await Bun.sleep(50);
    }
    await checkpoint();
    onOwnedPane(pane, priorRemain ? `set-option -p -t ${shellQuote(pane.paneId)} remain-on-exit ${priorRemain}`
      : `set-option -p -u -t ${shellQuote(pane.paneId)} remain-on-exit`, process.env);
    bindLaunch(ctx, claim, pane, true);
  } catch (error) {
    lifecycleDiagnostic("launch_failure", { session: claim?.session, phase: pane ? "respawn_or_readiness" : "create_session", error: (error as Error).name });
    startupTrace("launch_failure", { session: claim?.session, phase: pane ? "respawn_or_readiness" : "create_session", error: (error as Error).name });
    if (pane) {
      try {
        if (sameLaunchPane(pane, observeLaunchPane(pane.paneId, process.env))) {
          const tail = tmuxEffect(["capture-pane", "-p", "-J", "-t", pane.paneId], process.env).trim();
          if (tail) process.stderr.write(`tap session: failed pane tail:\n${tail}\n`);
        }
      } catch { /* The original failure remains the command result. */ }
    }
    if (claim && creationStarted && !pane && !/duplicate session/.test((error as Error).message)) {
      process.stderr.write(`tap session: creation outcome unverified; pending reservation retained for ${claim.session}. Inspect the session before recovery.\n`);
    } else if (claim) {
      try { rollbackLaunch(ctx, claim, pane); }
      catch (cleanup) { process.stderr.write(`tap session: rollback incomplete: ${(cleanup as Error).message}\n`); }
    }
    throw error;
  } finally {
    process.off("SIGINT", onInt);
    process.off("SIGTERM", onTerm);
    fence.release();
  }
  startupTrace("launch_complete", { session: claim.session, pane: pane!.paneId, exit_code: 0 });
  let attachReason: string | null = "detached";
  if (attachIntent) {
    try { attachReason = attachReady(attachIntent, pane!, request.harness, process.env); }
    catch (error) { attachReason = `attach failed: ${(error as Error).message}`; }
  }
  process.stdout.write(request.json ? JSON.stringify({ ok: true, runtime: "bun", handle: claim.handle, name: claim.session, pane: pane!.address, pane_id: pane!.paneId }) + "\n"
    : `tap session: native launcher (bun) launched ${claim.session} (${request.harness}); ${attachReason === null ? "attached" : attachReason === "detached" ? "detached" : `running detached (${attachReason}); next: tmux attach -t ${claim.session}`}\n`);
  return 0;
}
