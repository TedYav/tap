import { deliveryClockStamp } from "../delivery-clock";
import { recordedPermissions } from "../delivery-permissions";
import { clobberBand, DARK_EFFECTS } from "../deliver";
import {recordHarnessQueued,harnessQueueMessage} from "../harness-queue";
import { unverifiedSend } from "../queue-explanation";
import { deliveryBand, deliveryDisposition, type DeliveryBand } from "../slices/delivery-disposition";
import { isOrderShaped } from "../slices/order-shape";
import { validateLockedRegistryAuthority } from "../slices/registry-authority";
import { bodySourceRefusal, effectiveKind, guardApplies, parseSendArgs, refusalError, resolveId, resolveObligation, stageSource, tokenRefusal, type Obligation } from "../slices/message-construction";
// `tap send <to> (-m "text" | -f <file> | <payload-file>) [--from me] [--kind k]`
//
// The courier verb. Its exit codes are a contract, not a convenience:
//
//   0  durably accepted. `injected`/`pane` means the sentinel was verified out of
//      the input band. It does NOT claim the recipient processed anything.
//      After placement, a certified pre-effect identity_mismatch or pane_gone
//      is also 0: queued/poll, canonical and `.placed` kept.
//   1  terminal refusal (usage, validation, unknown seat) — NO canonical exists.
//   3  pane gone — checked BEFORE the canonical is placed, so nothing exists.
//   5  submit-unverified — the canonical STAYS on the bus for the recipient to
//      poll, and no `.sent` is written. Effect-ambiguous post-placement
//      failures stay here.
//
// The rule underneath all of them: a caller must never see a terminal refusal
// while an untracked payload from that send is outstanding. After canonical
// placement, no ordinary send path deletes the canonical.

import { spawnSync } from "node:child_process";
import { existsSync, lstatSync, realpathSync, rmSync, statSync } from "node:fs";
import { driverConfigPath, parseToml } from "../digest-window";
import { readSecureBytes } from "../launcher/catalog";
import { archiveRows } from "../bus-archive-index";
import { basename, dirname, join } from "node:path";

import { authorizePaneEffect, boundBootRefusal, canonicalPlaceLocked, evaluateBoundHarness, evaluateHarnessEvidence, inspectClearFenceRecord, observeHarnessPid, submitVerify } from "../courier";
import { noticeExpiredAtSendDoor } from "../clear-fence";
import { DelegateToBash, TapError, callingPane, observeCallingPane, refuseUnanchoredPane, resolveContext, resolveSelf, teamRootFromBus } from "../context";
import { COURIER_IDENTITY, HELP_HANDLE, WATCH_IDENTITY, utcStamp, validToken } from "../ids";
import { forwardingRoute } from "../forwarding";
import { loadRegistry, seatMap, type RegistryDoc } from "../registry";
import { DENYLIST } from "../observe";
import { loadGlobalRegistry, flipMarkerState, legacyTeamsPath } from "../index-home";
import { atomicWrite, jsonObj } from "../fsatomic";
import { renderSentinel } from "../sentinel";
import { cancelCopyMode, observePaneResult, paneAddress, paneCurrentCommand, serverEpochFromRaw, tmuxReadOnly } from "../tmux";
import { beginDeliveryAttempt } from "../delivery-attempt";
import { listEntries } from "../spool-state";
import { lockRoot, acquireObligationLock, acquirePaneLock, acquirePathLock, acquireRegistryLock, type PaneLock, type RegistryLock } from "../panelock";
import { bindExplicitRemoteRegistry, bindRemoteTeam, remoteRecipientRow, senderIndexEvidence, splitSendTarget, TOKEN_RE, type RemoteTeam } from "../remote-target";
import { acquireResetMutationLock, assertResetUnfenced, markResetGenerationReused } from "../reset";
import { recoveryHold } from "../recovery/state";
import { ParkRefusal } from "../spool-park";
import { parkAndReport, renderParkReceipt, type ParkReport } from "../spool-park-report";

import { encodePreview } from "../sentinel-preview";
import { InvalidHeaderEncoding } from "../envelope";
import { appendRegistryEventOrWarn, registryEventsPath } from "../events";

export type SendDisposition = "delivered" | "queued-poll" | "queued-spool" | "queued-harness" | "unverified";
export interface SendOutcome {
  rc: number;
  disposition: SendDisposition;
}
interface SendOptions {
  resetCustodyHeld?: boolean; inReplyTo?: string; noAutoReplyTo?: boolean; quiet?: boolean;
  recipientInstance?: string; historicalRecipient?: boolean; adoptedFrom?: string;
  expectedSenderInstance?: string; reauthorize?: (registry: RegistryDoc) => void; explicitTeam?: string;
}

export function cmdSend(
  argv: string[],
  scriptsDir: string,
  agentFamilies: ReadonlySet<string>,
  opts?: SendOptions,
): number {
  return cmdSendOutcome(argv, scriptsDir, agentFamilies, opts).rc;
}

export function cmdSendOutcome(
  argv: string[],
  scriptsDir: string,
  agentFamilies: ReadonlySet<string>,
  opts?: SendOptions,
): SendOutcome {
  // --- construction, shared with the Bash door (slices/message-construction) ---
  // The parse, its usage refusals and the body-source count are the module's;
  // the refusals it returns for a later site are raised here at that site.
  // Bash's TAP_JSON is process-global from the moment `--json` is parsed:
  // every later refusal is a JSON error object (main.ts nativeError reads it
  // back), an earlier one is a human line.
  const args = parseSendArgs(argv, process.env.TAP_ASSIGN_VERB === "1", { onJson: () => { process.env.TAP_JSON = "1"; } });
  // Bash's success receipt names the verb the caller typed (tap_send_success_receipt).
  const receiptVerb = process.env.TAP_ASSIGN_VERB === "1" ? "assign" : "send";
  const sourcesRefusal = bodySourceRefusal(args);
  if (sourcesRefusal) throw refusalError(sourcesRefusal);
  // --- team-qualified addressing (D2, member 2 of the reply stack) ------------
  // `<team>:<handle>` normalizes and `<team>/<handle>` splits here with the
  // incumbent's refusals (tap-send.sh:168-172, tap_resolve_team_target); `to`
  // is the BARE handle from here on, as Bash's TO is after :270. The team is
  // bound through the machine index once the caller's own team is known.
  const target = splitSendTarget(args.to);
  let to = target.handle;
  const preview = args.preview;
  let from = args.from;
  const note = args.note;
  const json = args.json;
  // --- delivery classes, send side (D3a, reply stack member 3) ---------------
  // `--polite` parks before any attempt with the polite policy and its timeout
  // (tap-send.sh:1661); a retryable defer under polite carries the same pair
  // (:136-148); the clearing park is `standard` regardless (:1650). `--no-spool`
  // turns every pre-effect park into the `delivery_refused` refusal (:108-113).
  // U4: the interrupt class (`--urgent`, `--delivery interrupt`, `--kind
  // escalate`) is native end to end — the courier owns the interrupt sequence
  // and its safety ordering; `--wake` is a parsed no-op.
  const polite = args.polite;
  const noSpool = args.noSpool;
  const retryablePolicy = polite ? "polite" : "standard";
  const retryableTimeout = polite ? args.politeTimeout : "";

  // send-reply-r2 checkpoint A (U1): the PUBLIC argv forms of the options that
  // reply already passes through opts ride the same opts — argv wins, the
  // caller's opts stay the default (tap-send.sh parses these today; the
  // stamps they feed were already native).
  const inReplyTo = args.inReplyTo || opts?.inReplyTo || undefined;
  const noAutoReplyTo = args.noAutoReplyTo || opts?.noAutoReplyTo || false;
  const recipientInstance = args.recipientInstance || opts?.recipientInstance || undefined;
  const historicalRecipient = args.historicalRecipient || opts?.historicalRecipient || false;
  const adoptedFrom = args.adoptedFrom || opts?.adoptedFrom || undefined;
  const expectedSenderInstance = args.expectedSenderInstance || opts?.expectedSenderInstance || undefined;

  // A composing reply passes its `--team` selection down (D4d): the incumbent's
  // `tap send` child inherits the override's exported TAP_HOME and is TAP_HOME-
  // first, where a native cwd walk under a live marker would re-select the
  // cwd team. send-reply-r2 checkpoint A (U1): the public `--team` form joins
  // the same selection — the incumbent applies the flag before its own cwd
  // walk (tap_apply_team_override, tap-send.sh:216) and ignores it for a
  // TAP_HOME caller, exactly as reply's own explicitTeam handling does.
  // With an explicit --team the caller named their bus; the pane arm is only
  // for a cwd-derived send that found no acting registry. Send's documented
  // refusal code is 1, and the pane arm's re-anchor names the enrolled seat.
  // Anything else keeps the generic unanchored refusal.
  const teamFlag = args.team && !process.env.TAP_HOME ? args.team : "";
  let ctx: ReturnType<typeof resolveContext>;
  try {
    ctx = resolveContext(process.cwd(), process.env, opts?.explicitTeam || teamFlag ? { explicitTeam: opts?.explicitTeam || teamFlag } : undefined);
  } catch (error) {
    if (opts?.explicitTeam || !(error instanceof TapError) || error.errorClass !== "unanchored_bus") throw error;
    const seen = observeCallingPane();
    if (seen.state === "inside") {
      refuseUnanchoredPane(seen.paneId, process.cwd(), 1,
        { session: seen.session, serverEpoch: seen.serverEpoch }, process.env, seen.paneId, true);
    }
    throw error;
  }

  // --- resolve the sender -------------------------------------------------
  // `from` = --from > TAP_SELF > pane-derived handle > fail loud. The resolved
  // sender must name an ACTIVE seat: an unknown --from is refused rather than
  // stamped, because a forged author is invisible to every downstream reader.
  if (!from) from = process.env.TAP_SELF || "";
  if (!from) {
    const pane = callingPane();
    if (!pane) {
      throw new TapError(1, "identity_unverified", "tap register in this pane, or pass --from",
        "sender identity could not be derived and --from was not given");
    }
    from = resolveSelf(ctx, pane, 1).handle;
  }
  if (!validToken(from)) throw new TapError(1, "usage_error", "tap help send", `--from '${from}' is not a valid token`);
  refuseReservedIdentity(to, "to", ctx.bus.home);
  refuseReservedIdentity(from, "from", ctx.bus.home);

  // --- stage the body, then resolve kind and id from the staged source -------
  // Bash's order: the source is staged (not_found / cap / unreadable refuse
  // here, before any recipient question), `--kind` beats the source's own
  // `kind:` beats `discuss`, and `--id` beats the source's `id:` beats a mint.
  // Staging is in memory on this door: nothing under the bus is created before
  // authorization. The staged bytes are BYTES — a `-f` body that is not valid
  // UTF-8 used to delegate to Bash and now stays here unchanged.
  // Sender paths only observe queued siblings; the explicit waiter owns draining.
  // Refuse a reset fence before staging so a fenced send never consumes stdin.
  assertResetUnfenced(ctx.bus.home, "tap send");
  // A qualified destination on the caller's own team is a local send (Bash's
  // `local` scope). Any other team is the remote route, bound in the incumbent's
  // order — after the sender's fence (:244), before anything is staged (:264):
  // the recipient's acting registry and bus come from the index (marker live;
  // the router keeps an absent marker on Bash), the canonical stays on THIS bus,
  // and the recipient's own reset fence is checked as Bash checks it (:301).
  // The caller's own team must be a token before anything is staged or
  // placed: `tap_resolve_team_target` refuses it first (lib.sh:7265), for a
  // bare handle as much as for a qualified one, and it is the `from_team`
  // stamp and the sentinel's prefix on the remote route.
  if (!validToken(ctx.team)) {
    throw new TapError(1, "usage_error", "tap help", `local team '${ctx.team}' is not a valid token (${TOKEN_RE})`);
  }
  let remote: RemoteTeam | null = null;
  // send-reply-r2 checkpoint A (U2): the explicit `--remote-registry <path>`
  // override (tap-send.sh:293-303, 671-678) pins the recipient's acting
  // registry, so it takes the destination checks before the index bind would
  // and binds without sampling any marker. A bare-handle `--cross-worktree`
  // destination with no override is the MANUAL relay (:788-820): its pane is
  // mandatory and session-designated, resolved below with the recipient
  // questions it replaces.
  let manualRelay = false;
  // The hermes queue prefix (lib.sh:9096-9100): `/queue ` rides the INJECTED
  // sentinel only (lib.sh:11011), never the canonical or its preview.
  let queuePrefix = "";
  // The incumbent's from_team and sentinel `from` team half come from its
  // target resolver's LOCAL answer (tap-send.sh:307, :1000, :1682), whose
  // derivation is tap_resolve_team_target's TAP_TT_LOCAL_TEAM
  // (lib.sh:6972-6988): the bus's own registry.json `team.name` when that
  // file parses (any read/parse fault falls through), else the bus-anchor
  // root's basename (TAP_TT_SENDER_ROOT = the git toplevel of
  // dirname(TAP_HOME); teamRootFromBus is the native twin of that climb).
  // Review round 3: never a literal — the fixture's old worktree basename
  // `team` made the round-2 short-circuit look like parity.
  const relayTeamName = (() => {
    try {
      const doc = loadRegistry(join(ctx.bus.home, "registry.json")) as unknown as { team?: { name?: unknown } };
      return String(doc.team?.name ?? "").trim();
    } catch {
      return "";
    }
  })() || basename(teamRootFromBus(ctx.bus.home));
  if (args.remoteRegistry) {
    if (!target.qualified) {
      throw new TapError(1, "usage_error", "tap help send", "--remote-registry requires a <team>/<handle> destination");
    }
    let overrideIsFile = false;
    try { overrideIsFile = statSync(args.remoteRegistry).isFile(); } catch { overrideIsFile = false; }
    if (!overrideIsFile) {
      throw new TapError(1, "not_found", "tap help send", `--remote-registry path not found: ${args.remoteRegistry}`);
    }
    if (!validToken(target.team)) {
      throw new TapError(1, "usage_error", "tap help send", `team '${target.team}' is not a valid token (${TOKEN_RE})`);
    }
    if (!validToken(to)) {
      throw new TapError(1, "usage_error", "tap help send", `handle '${to}' is not a valid token (${TOKEN_RE})`);
    }
    remote = bindExplicitRemoteRegistry(target.team, to, args.remoteRegistry);
    assertResetUnfenced(remote.busHome, "tap send (recipient bus)");
  } else if (target.qualified && target.team !== ctx.team) {
    if (ctx.marker !== "live") throw new DelegateToBash(ctx.bus.home);
    remote = bindRemoteTeam(target.team, to, process.env.TAP_INDEX_HOME);
    assertResetUnfenced(remote.busHome, "tap send (recipient bus)");
  } else if (args.crossWorktree && !target.qualified) {
    manualRelay = true;
  }
  // Bash's IDENTITY_ACTION for a remote seat (tap-send.sh:944-946): one action
  // for every drift, before and after placement, naming the team the seat must
  // re-bind from. Reads `to` late, after forwarding has settled it.
  const identityAction = (local: string): string => remote ? `target seat '${to}' must run 'tap in' from team '${remote.team}'` : local;
  // stageSource keeps the incumbent's order: a source's own refusals (a missing
  // file, the cap) come before the usage line for a missing destination.
  const staged = stageSource(args, { inlineMaxBytes: process.env.TAP_INLINE_MAX_BYTES });
  // Every delegation from here on happens AFTER the source may have been read
  // from stdin; the bytes ride the DelegateToBash so the Bash door gets them.
  const delegate = () => new DelegateToBash(ctx.bus.home, staged.stdinConsumed);
  const kind = effectiveKind(args, staged);
  // The interrupt class (U4): explicit --urgent, --delivery interrupt (the
  // parser folds it into urgent/urgentSet), or kind=escalate standing alone —
  // the incumbent's default (tap-send.sh:492-499): a stop-the-line message
  // interrupts by default, and only an explicit class choice overrides it
  // (an explicit --urgent is already 1; an explicit --polite parks later).
  const urgent = args.urgent || (kind === "escalate" && !args.urgentSet && !args.polite);
  const id = resolveId(args, staged, from);
  const charset = tokenRefusal(id, from, to, kind);
  if (charset) throw refusalError(charset);
  // tap-gyc91: a plain send is settle-only; --ask/--reply/--expect-reply request
  // a reply; --fyi is a no-op alias of the default. The obligation itself is
  // resolved inside the registry snapshot (U3) — its facts are the sender's
  // own row, which only the lock holds steady.
  const canonPath = ctx.bus.payloadPath(id);
  let replyExpect: Obligation["replyExpect"] = "settle-only";
  let pane = "";
  let authorizedPaneId = "";
  let authorizedEpoch = "";
  let authorizedHarness = "";
  let authorizedBoot = "";
  let authorizedInstance = "";
  let autoUrgent = false;
  let attemptAdmitted = false;
  let pollRecipient = false;
  let resetLock: PaneLock | null = null;
  let relaySession = "";
  let relayRouteMarker: "live" | "absent" | "invalid" = "invalid";
  let copyModeDefer = "";
  let copyModeRecoveryHeld = false;
  let siblingsQueued = 0;

  try {

  // Obligation first, then the acting registry's exact sidecar. Holding both
  // through `.placed` makes eligibility, routing identity, and canonical
  // placement one snapshot. A re-register may run immediately afterward, but
  // it cannot split one envelope across predecessor and successor rows.
  const obligationLock = acquireObligationLock(id);
  if (!obligationLock) {
    throw new TapError(1, "obligation_busy", `tap outstanding ${from}`,
      `obligation '${id}' is busy; refusing to place without exclusive eligibility`);
  }
  try {
    // A remote send holds the recipient's registry lock too — its row is read
    // and its instance stamped under the same snapshot — and takes the locks
    // in sorted realpath order, tap-send.sh:1030-1036's discipline, so two
    // cross-team sends in opposite directions never wait on each other.
    const registryLocks = acquireRegistryLocks(remote ? [ctx.registryPath, remote.registryPath] : [ctx.registryPath]);
    try {
      const registry = loadRegistry(ctx.registryPath);
      const seats = seatMap(registry);
      const recipientDoc = remote ? loadRemoteRegistry(remote.registryPath, target.original) : registry;
      const fromSeat = ownSeat(seats, from);
      // The reserved watcher identity is not a seat (lib.sh:9913 keeps it a
      // constant; tap-register refuses it), so the active-row precondition
      // below must not answer it — bash's sender facts read a missing row as
      // non-dischargeable and the supervisor branch licenses settle-only mail
      // (tap-send.sh:512-553). The instance check is likewise row-scoped.
      if (from !== WATCH_IDENTITY && (!fromSeat || String(fromSeat.status ?? "active") !== "active")) {
        throw unregisteredSenderRefusal(from, seats, ctx.registryPath);
      }
      if (fromSeat && expectedSenderInstance && fromSeat.instance !== expectedSenderInstance) {
        throw new TapError(1, "instance_replaced", "retry reply from the authorized successor", "responding seat changed after recipient authorization; no reply placed");
      }
      // Point-of-effect authority (sol-pinnacle-4, #xxxx): a reply's recipient
      // authorization — the addressee, a forwarding grant, an adoption grant —
      // was read before this lock; the caller re-runs the same predicate here,
      // under the held registry snapshot, before anything is placed. The
      // incumbent rechecks only the actor's instance (tap-send.sh:1046-1052),
      // which cannot see a revoked adoption — the same instance can lose
      // custody of its fork — so this door refuses where the incumbent places.
      opts?.reauthorize?.(registry);
      // U3 (checkpoint B): the incumbent's sender facts
      // (tap_registry_sender_facts, lib.sh:9608-9688) answer ONE question —
      // is this sender dischargeable: active_pane OR (active AND
      // delivery=poll). active needs an active row that is not launching;
      // active_pane additionally a nonempty pane, demoted only by
      // epoch/boot staleness (lib.sh:9639-9677: the stored stamp must be
      // non-empty AND differ from the live server generation / this boot) —
      // the facts never read pane_id, so a malformed stored pane_id or an
      // empty stored epoch never demotes. A poll sender stays
      // instance-unstamped (tap_send_optimistic_sender_instance,
      // tap-send.sh:1024-1053) and an unattended sender proceeds into the
      // obligation module's downgrade.
      const senderDelivery = String(fromSeat?.delivery ?? "pane");
      const fromPane = String(fromSeat?.pane ?? "");
      const senderPaneId = String(fromSeat?.pane_id ?? "");
      const senderEpoch = String(fromSeat?.server_epoch ?? "");
      const senderLaunching = String(fromSeat?.status_reason ?? "") === "launching";
      const senderActive = !senderLaunching;
      const storedBoot = String(fromSeat?.boot_id ?? "");
      const bootVerdict = storedBoot ? boundBootRefusal(storedBoot, "delivery") : null;
      if (bootVerdict?.reason === "boot_id_unobservable") {
        // The incumbent's sender_liveness_unobservable (tap-send.sh:535-538)
        // with the child-exit spelling dropped: there is no child process to
        // quote on this door, so the diagnostic rides the refusal alone.
        throw new TapError(1, "sender_liveness_unobservable", "bun --version",
          `'${from}' could not be observed: the send-time registry read did not finish, so whether this seat is live is unknown. This is an observation failure, not a registration one -- it does not establish that the handle is stale, so do not reclaim it; retry, and if it persists check that the Bun runtime runs`);
      }
      const nowEpoch = serverEpochNow();
      const epochStale = senderEpoch !== "" && nowEpoch !== "" && senderEpoch !== nowEpoch;
      const senderActivePane = senderActive && senderDelivery !== "poll" && fromPane !== "" && !epochStale && bootVerdict === null;
      const senderDischargeable = senderActivePane || (senderActive && senderDelivery === "poll");
      // The watch identity (tap-send.sh:512-522, :546-548): the reserved
      // sidecar has no pane and cannot register, so it is never
      // dischargeable — but settle-only mail IS its channel: --fyi with
      // kind probe/notice/progress bypasses the refusal, and reply-capable
      // mail keeps the reserved-identity refusal with the incumbent's bytes.
      const watchIdentity = WATCH_IDENTITY;
      const supervisorLicensed = from === watchIdentity && args.fyi &&
        new Set(["probe", "notice", "progress"]).has(kind);
      if (from === watchIdentity && !senderDischargeable && !supervisorLicensed) {
        throw new TapError(1, "unregistered_sender",
          `tap send ${args.to} -f <path> --from ${watchIdentity} --fyi --kind notice`,
          `'${watchIdentity}' is the reserved watch-sidecar identity: it has no pane and cannot register, so it may only send settle-only mail — pass --fyi with --kind probe, notice or progress. Mail that must carry a reply obligation is sent from a registered pane-backed seat`);
      }
      if (!senderDischargeable && !supervisorLicensed) throw unregisteredSenderRefusal(from, seats, ctx.registryPath);
      // Resolve once: only the effective, deliverable stamp grants an
      // unattended sender a reply obligation (tap-send.sh:582-623).
      const replyToStamp = args.replyToSet
        ? explicitReplyToStamp(args.replyTo, from, ctx)
        : noAutoReplyTo ? undefined : fromSeat ? autoReplyTo(from, fromSeat, seats, ctx.team, ctx) : undefined;
      const obligation = resolveObligation({ ...args, from }, kind, { unattended: fromSeat?.unattended === true, replyToStamped: !!replyToStamp }, process.env.TAP_ASSIGN_VERB === "1");
      if (obligation.refusal) throw refusalError(obligation.refusal);
      replyExpect = obligation.replyExpect;
      for (const warning of obligation.warnings) {
        process.stderr.write(`tap send: warning: ${warning}\n`);
      }
      // send-reply-r2 checkpoint A (U1): a qualified STORED reply_to no longer
      // delegates — the deliverability port below (seatDeliverable) answers
      // for it, exactly as the incumbent's tap_seat_deliverable did.
      // Bash prints $ORIGINAL_TO in the order-shape refusal: the target the
      // caller typed, before forwarding reduced it. Capture it here for parity.
      const originalTo = target.original;
      // --- the source payload: staged above, as bytes -----------------------
      // What the order-shape guard judges is Bash's staged $PAYLOAD: for -m/-f
      // the synthetic empty fence then the body bytes as staged, for a
      // positional file the file BEFORE any fenceless wrap. Canonicalization
      // stamps the wrapped bytes.
      const src = staged.wrapped;
      const judged = staged.judged.toString("utf8");

      // --- order-shaped-note guard (tap-oglkh), both doors, one predicate ------
      // Bash judges its staged $PAYLOAD (`judged` above): for -m/-f that is
      // exactly `src`, the synthetic empty fence then the body bytes as staged;
      // for a positional payload it is the file before any wrap. The exemptions are
      // Bash's, literally: an ask (the obligation is already tracked), --note
      // (the author's confirmation), the lane-request/probe/notice kinds, and a
      // reply-composed outbound. Not the autosettle carve-out set — a plain
      // `--kind digest` note is judged on Bash and is judged here too.
      // In-process there is no "could not classify" outcome: the predicate runs
      // on a string it already holds, and an exception would fail this send
      // loudly rather than read as not-shaped. The refusal spends no tmux
      // budget and creates nothing: it sits before the fence check and the
      // recipient observation, as Bash's sits before canonicalize.
      if (guardApplies({ expectReply: args.expectReply, note, inReplyTo: inReplyTo ?? "" }, kind)) {
        if (isOrderShaped(judged)) {
          // Bash appends the caller's explicit relay pane to the re-anchor
          // (tap-send.sh:443): the same note typed through the relay is routed
          // as work through the relay.
          const orderRoute = `tap assign ${originalTo} -f <path>${args.pane ? ` --cross-worktree --pane ${args.pane}` : ""}`;
          throw new TapError(2, "order_shaped_note", orderRoute,
            `this body reads like a work order (a bead id plus a work-order marker) but is being sent as a note, which mints no reply obligation and is how five dispatches went unanswered on 2026-09-03. Send it as work with: ${orderRoute}. If it really is a note, say so with: tap send ${originalTo} --note -f <path>`);
        }
      }

      let forwarded = { target: to, instance: "", adopted_from: "", source_instance: "" };
      let toSeat: Record<string, unknown> | null = null;
      if (manualRelay) {
        // --- the manual unbound relay (U2; tap-send.sh:788-820, 996-1001) ----
        // The relay's pane is MANDATORY (no implicit cross-worktree peer
        // discovery) and must be session-qualified; the unbound identity record
        // vouches that the session observes the pane as designated membership.
        // Nothing about the recipient is read from any registry: the sentinel
        // carries the SENDER's team on the from and a bare handle on the to,
        // `path=` rides, and the target binding stays unbound.
        if (!args.pane) {
          throw new TapError(1, "usage_error", "tap help send",
            "--cross-worktree requires --pane <tmux-target> (no implicit cross-worktree peer discovery)");
        }
        if (!args.pane.includes(":")) {
          throw new TapError(1, "identity_unverified", "pass --pane '<session>:<window>.<pane>'",
            `manual cross-worktree relay requires an exact session-qualified pane; bare target '${args.pane}' has ambient tmux meaning`);
        }
        relaySession = args.pane.slice(0, args.pane.indexOf(":"));
        // Route-time flip polarity (tap-send.sh:806-815, _XWT_ROUTE_MARKER):
        // the relay's place-time behavior keys on THIS sample, never a fresh
        // one — starting live keeps the unbound place behind only the invalid
        // belt; starting absent hands the place to the cutover barrier's
        // in-lock resample (teams.json.lock).
        relayRouteMarker = flipMarkerState(process.env.TAP_INDEX_HOME);
        if (relayRouteMarker === "invalid") {
          throw new TapError(1, "invalid_flip", "tap doctor",
            "manual cross-worktree send refused — global-registry.json is present but unreadable or wrong schema");
        }
        const record = unboundPaneIdentityRecord(relaySession, args.pane);
        if (record.state !== "match" || !record.paneId) {
          throw new TapError(1, "identity_unverified", "verify the exact tmux session and pane, then retry",
            `manual cross-worktree pane '${args.pane}' is not observable as designated membership (${record.state})`);
        }
        authorizedPaneId = record.paneId;
        authorizedEpoch = record.epoch;
        authorizedBoot = "";
        pane = args.pane;
        toSeat = { pane: args.pane, pane_id: record.paneId, server_epoch: record.epoch, instance: "", harness: "" };
        // The relay's route seam (tap-send.sh:818): fire-and-forget, as Bash's.
        const hook = process.env.TAP_SEND_AFTER_ROUTE_HOOK;
        // The incumbent executes the hook directly and ignores only its exit
        // status (tap-send.sh:816-820): no timeout, inherited stdio. This seam
        // is the deterministic U3 cutover handshake — a slow handshake must not
        // be killed and its observable output must not silently change.
        if (hook) spawnSync(hook, [], { stdio: "inherit" });
        // Review round 5 (r4056301888/r4056301891): the incumbent resolves
        // PANE_CMD only AFTER the route hook (tap-send.sh:1417-1418), through
        // tap_pane_harness_command (lib.sh:8726) — an unsupported shallow
        // command ("node", a version string) is resolved through the pane's
        // process evidence, so the family the relay binds is the REAL agent
        // family, not the wrapper's name — and its denylist gate
        // (:1569-1575) then owns a hook that parked a shell on the pane:
        // terminal refuse before publication, with the gate's bytes, while
        // the place-time identity guard keeps pane_id recycle.
        const routeObs = observePaneResult(args.pane, process.env);
        if (routeObs.status === "unobservable") {
          throw new TapError(1, "tmux_unreachable", "restore tmux observation, then retry", routeObs.reason);
        }
        if (routeObs.status === "pane_gone") {
          // Review round 6 (P2): the incumbent re-checks pane liveness after
          // the hook and BEFORE PANE_CMD classification (tap-send.sh:1413);
          // a pane the hook killed is the rc 3 human-relay outcome with zero
          // artifacts — not an unsupported-harness refusal for an empty
          // command.
          throw new TapError(3, "pane_gone", "human_relay", `pane '${args.pane}' gone`, "tap send");
        }
        if (routeObs.status === "rate_limited") {
          throw new TapError(1, "rate_limited", "retry the send",
            `tmux client budget exhausted before '${args.pane}' could be classified`);
        }
        const routeCommand = routeObs.observation.currentCommand;
        authorizedHarness = relayHarnessFamily(
          routeCommand,
          routeObs.observation.panePid,
          agentFamilies, scriptsDir,
        );
        toSeat.harness = authorizedHarness;
        if (DENYLIST.includes(authorizedHarness)) {
          throw new TapError(1, "unsafe_target", "escalate",
            `reason=denylist; pane '${args.pane}' runs '${routeCommand}' (not an agent REPL)`, "tap send");
        }
        if (!agentFamilies.has(authorizedHarness)) {
          throw new TapError(1, "unsupported_harness", "escalate",
            `reason=unsupported; pane '${args.pane}' runs unsupported harness '${routeCommand}'`, "tap send");
        }
      } else {
        forwarded = forwardingRoute(recipientDoc, to, recipientInstance, historicalRecipient);
        to = forwarded.target;
        // The remote row's verdicts (missing, pending, launching, suspended, poll,
        // no pane, unbound or malformed pane_id) are the incumbent's remote
        // refusals, raised here in its order; a row it answers FOUND continues
        // into the same checks a local row does.
        toSeat = remote ? remoteRecipientRow(recipientDoc, remote.team, to, ctx.team).seat : ownSeat(seats, to);
      }
      if (!toSeat) {
        throw new TapError(1, "unknown_recipient", `tap team`, `'${to}' is not an active seat on team '${ctx.team}'`);
      }
      if (!manualRelay && String(toSeat.delivery ?? "pane") === "poll" && args.pane) {
        throw new TapError(1, "poll_mode_member", `tap send ${to} <payload> --from <handle>`,
          `'${to}' is a poll member and has no pane; --pane cannot target it (poll entries omit pane)`);
      }
      if (!remote && String(toSeat.status ?? "active") === "suspended") {
        // The incumbent's suspended split (tap-send.sh:866-888): a poll
        // member refuses rc 1 with the register action; a pane seat refuses
        // rc 3 — an incapable seat names re-registration, a launcher-managed
        // seat names session resume, anything else re-opening the pane.
        if (String(toSeat.delivery ?? "pane") === "poll") {
          throw new TapError(1, "suspended", `tap register ${to} --delivery poll`, `'${to}' is suspended`);
        }
        if (String(toSeat.status_reason ?? "") === "incapable") {
          throw new TapError(3, "suspended",
            `re-register '${to}' from its pane: run 'tap in' there, or 'tap register ${to} --pane <tmux-target>'`,
            `'${to}' is suspended (incapable)`);
        }
        const supSession = String(toSeat.session ?? "");
        const supHarness = String(toSeat.harness ?? "");
        throw new TapError(3, "suspended",
          supSession !== "" && supHarness !== "" ? `tap session resume ${to}` : `re-open pane for '${to}' and run 'tap in'`,
          `'${to}' is suspended`);
      }
      if (!remote && String(toSeat.status ?? "active") !== "active") {
        throw new TapError(1, "unknown_recipient", `tap team`, `'${to}' is not an active seat on team '${ctx.team}'`);
      }
      // The hermes queue prefix rides the injected sentinel (lib.sh:9096-9100,
      // :11011) and its no_prompt_ok (lib.sh:10871) bypasses the rc-3
      // no-input-prompt defer — the bare prefix IS the handoff for a harness
      // with no visible idle prompt. Urgent zeroes it (U4).
      const toHarness = String(toSeat.harness ?? "");
      // Urgent zeroes the prefix (U4): the incumbent clears qprefix inside
      // submit_verify (lib.sh, "takes queue-prefix/bare-urgent delivery"),
      // but keeps the no_prompt_ok bypass hermes captured from it.
      if (toHarness.startsWith("hermes") && !urgent) queuePrefix = "/queue ";
      // Post-toSeat, pre-effect: launching and unbound pane_id are the
      // incumbent's refusals (tap-send.sh:879-880, :976-983). Poll/paneless
      // placement skips the pane_id guard — that check is injection-only.
      if (String(toSeat.status_reason ?? "") === "launching") {
        throw new TapError(1, "seat_launching", `tap team`, `'${to}' is bound but still launching`);
      }
      pollRecipient = String(toSeat.delivery ?? "pane") === "poll";
      if (!pollRecipient && !isTmuxPaneId(String(toSeat.pane_id ?? ""))) {
        const boundPaneId = String(toSeat.pane_id ?? "");
        const bindSession = String(toSeat.session ?? "");
        const bindHarness = String(toSeat.harness ?? "");
        const bindAction = bindSession !== "" && bindHarness !== ""
          ? `run 'tap session repair ${to}' to re-bind session`
          : `target seat '${to}' must run 'tap in' from its pane`;
        if (boundPaneId === "") {
          throw new TapError(1, "identity_unverified", bindAction,
            `registry row for '${to}' has no pane_id; refusing unbound delivery`);
        }
        throw new TapError(1, "identity_unverified", bindAction,
          `registry row for '${to}' has invalid pane_id '${boundPaneId}'; refusing delivery without changing seat status`);
      }
      // An empty stored server_epoch never refuses (lib.sh:9676): staleness
      // needs both stamps, enforced at the courier's evidence layer.
      // Only tmux remains wired. Refuse an unusable preference before parking
      // can hand the message to a different transport. Poll never injects.
      if (!pollRecipient && process.env.TAP_DRIVER_FORCE_TMUX !== "1") {
        if (!resolveConfiguredDriver(String(toSeat.harness ?? "")).ok) {
          throw new TapError(1, "driver_unavailable", "tap doctor",
            "the configured delivery driver for this recipient cannot be used; refusing before parking rather than queueing a message that would drain through tmux");
        }
      }

      if (!pollRecipient && !manualRelay) {
        // The explicit `--pane` override (tap-send.sh:895-902) confirms the
        // binding or refuses; it cannot bypass the registered pane identity.
        // The relay's own pane was resolved above and is not an override.
        if (args.pane) {
          const registeredPane = String(toSeat.pane ?? "");
          if (registeredPane && args.pane !== registeredPane) {
            const session = String(toSeat.session ?? "");
            const harness = String(toSeat.harness ?? "");
            const launcherManaged = session !== "" && harness !== "";
            throw new TapError(1, "identity_mismatch",
              launcherManaged ? `run 'tap session repair ${to}' to re-bind session` : `target seat '${to}' must run 'tap in' from its pane`,
              `explicit pane '${args.pane}' does not match registered pane '${registeredPane}' for '${to}'`);
          }
        }
        // The pane-drift heal (tap-send.sh:904-970): a live id-shaped address
        // field is resolved once, under this registry lock, so the first send
        // does not refuse pane_drift against `%N`. Epoch-stale rows are never
        // resolved — a recycled id would write the wrong address — and the
        // identity checks below report the staleness instead.
        const idPane = String(toSeat.pane ?? "");
        if (isTmuxPaneId(idPane) && String(toSeat.pane_id ?? "")) {
          const healed = healIdShapedPane(remote ? remote.registryPath : ctx.registryPath, to, idPane, String(toSeat.pane_id), String(toSeat.server_epoch ?? ""));
          if (healed) (toSeat as Record<string, unknown>).pane = healed;
        }
      }

      // The optimistic sender_instance stamp (tap-send.sh:1024-1053): a
      // pane-backed active sender stamps its row instance; a poll or demoted
      // sender stays unbound.
      const senderInstance = senderActivePane && typeof fromSeat?.instance === "string" ? fromSeat.instance : undefined;

      // Step A dead pane (tap-send.sh:1394-1414, lib.sh:8010-8015): a
      // registry-bound seat whose pane is gone is marked suspended
      // (pane_gone, exited_at stamped once) and refused rc 3; when the mark
      // cannot run — the tmux server is unreachable, "a dead socket is not
      // a dead pane" — the send refuses without touching the registry. The
      // copy-mode cancel ladder maps its empty reads to the same refusal.
      const refuseDeadPane = (): never => {
        if (manualRelay) throw new TapError(3, "pane_gone", "human_relay", `pane '${pane}' gone`, "tap send");
        // Remote pane loss never grants suspension authority over a local namesake.
        if (remote) {
          const fallback = `tap send ${to} <payload> --cross-worktree --pane <tmux-target>`;
          throw new TapError(1, "pane_gone", fallback, `pane '${pane}' for ${remote.team}/${to} is not alive. Fallback: ${fallback}`);
        }
        if (!markSuspendedLocked(ctx.registryPath, to)) {
          throw new TapError(1, "tmux_unreachable", "unset TMUX, restore tmux on PATH, or repair the server socket",
            `tmux server unreachable; refused to suspend '${to}' (a dead socket is not a dead pane)`);
        }
        const session = String(toSeat.session ?? "");
        const harness = String(toSeat.harness ?? "");
        throw new TapError(3, "pane_gone",
          session !== "" && harness !== "" ? `tap session resume ${to}` : `re-open pane for '${to}' and run 'tap in'`,
          `pane '${pane}' gone; marked '${to}' suspended`);
      };

      if (!pollRecipient && !manualRelay) {
        pane = String(toSeat.pane ?? "");
        if (!pane) throw new TapError(1, "unknown_recipient", "tap team", `'${to}' has no pane recorded`);

        // The clear fence is NOT read here: the incumbent reads it once, after
        // placement and the render (tap-send.sh:1639), and runs these identity
        // checks for a clearing seat too. A pre-placement sample used to decide
        // the later park class and missed both directions of the race.
        // Checked before placement and against the same registry snapshot.
        const observed = observePaneResult(pane);
        if (observed.status === "unobservable") {
          throw new TapError(1, "tmux_unreachable", "restore tmux observation, then retry", observed.reason);
        }
        if (observed.status === "rate_limited") {
          throw new TapError(1, "rate_limited", "retry the send",
            `tmux client budget exhausted before '${to}' could be authorized`);
        }
        if (observed.status === "pane_gone") {
          throw refuseDeadPane();
        }
        const obs = observed.observation;
        const boundPaneId = String(toSeat.pane_id ?? "");
        if (boundPaneId && boundPaneId !== obs.paneId) {
          throw new TapError(1, "identity_mismatch", identityAction(`tap register ${to}   (the recorded pane is stale; re-register to rebind)`),
            `'${to}' is bound to pane id ${boundPaneId}, but '${pane}' is now ${obs.paneId} — refusing to deliver to a pane that is not the addressed seat`);
        }
        const boundBoot = String(toSeat.boot_id ?? "");
        const bootRefuse = boundBootRefusal(boundBoot, "delivery");
        if (bootRefuse) {
          throw new TapError(1, "identity_mismatch", identityAction(`tap register ${to}   (the recorded pane is from a previous boot session)`),
            bootRefuse.detail);
        }
        const boundEpoch = String(toSeat.server_epoch ?? "");
        if (boundEpoch && obs.serverEpoch && boundEpoch !== obs.serverEpoch) {
          throw new TapError(1, "identity_mismatch", identityAction(`tap register ${to}   (the recorded pane is from a previous tmux server)`),
            `'${to}' was registered under server generation ${boundEpoch}, but the pane now reports ${obs.serverEpoch}`);
        }
        if (DENYLIST.includes(manualRelayFamily(obs.currentCommand, agentFamilies))) {
          throw new TapError(1, "unsafe_target", "escalate",
            `reason=denylist; pane '${pane}' runs '${obs.currentCommand}' (not an agent REPL)`, "tap send");
        }
        authorizedPaneId = boundPaneId || obs.paneId;
        authorizedEpoch = boundEpoch || obs.serverEpoch;
        authorizedHarness = String(toSeat.harness ?? "");
        authorizedBoot = boundBoot;
        authorizedInstance = typeof toSeat.instance === "string" ? toSeat.instance : "";
        const evidence = evaluateBoundHarness(obs, authorizedHarness, { scriptsDir, agentFamilies });
        if (evidence !== "alive") {
          throw new TapError(1, "identity_mismatch", identityAction(`tap register ${to}   (the recorded pane is stale; re-register to rebind)`),
            `harness evidence ${evidence} for bound family '${authorizedHarness}' (live command '${obs.currentCommand}')`);
        }
      }

      // Copy-mode cancellation BEFORE placement (tap-send.sh:1597-1643,
      // lib.sh:9001-9047): polite and auto recipients are never touched; an
      // in-mode --no-spool send refuses without cancelling (the same
      // spool_and_exit path, which for --no-spool is a refusal); everyone
      // else gets the cancel keystroke, an empty re-read maps to the dead
      // pane's rc 3, and a pane that stayed in copy mode places first and
      // defers with the typed copy-mode reason.
      const permissions = manualRelay ? "bypass" : recordedPermissions(remote?.registryPath ?? ctx.registryPath, to);
      autoUrgent = !pollRecipient && urgent && permissions === "auto";
      if (!pollRecipient && !polite && permissions === "bypass") {
        const copyTarget = authorizedPaneId || pane;
        const inModeRead = (): "gone" | "in" | "out" => {
          const read = tmuxReadOnly(["display-message", "-p", "-t", copyTarget, "#{pane_in_mode}"], process.env);
          const raw = read.stdout.trim();
          if (read.code === 0 && (raw === "0" || raw === "1")) return raw === "0" ? "out" : "in";
          if (observePaneResult(copyTarget).status === "pane_gone") return "gone";
          throw new TapError(1, "tmux_unreachable", "restore tmux observation, then retry",
            `copy-mode state for '${copyTarget}' is unobservable; no pane absence established`);
        };
        const first = inModeRead();
        if (first !== "out") {
          if (noSpool) {
            // The refusal bytes of tap_send_spool_and_exit's --no-spool arm
            // (tap-send.sh:148-153), which for copy-mode fires BEFORE the
            // cancel: nothing is published, nothing is cancelled.
            throw new TapError(1, "delivery_refused", "re-send when the recipient is ready",
              "--no-spool refused (copy-mode); no message queued; pane is in copy mode or unreadable", "tap send");
          }
          if (first === "gone") refuseDeadPane();
          const copyLock = acquirePaneLock(copyTarget);
          if (!copyLock) copyModeDefer = "another submit holds the pane -> defer copy-mode cancellation";
          else try {
            if (recoveryHold(copyTarget)) copyModeRecoveryHeld = true;
            else {
              if (manualRelay && unboundPaneIdentityRecord(relaySession, pane, {
                paneId: authorizedPaneId, harness: authorizedHarness, agentFamilies, scriptsDir,
              }).state !== "match") {
                throw new TapError(1, "identity_mismatch", "verify the exact tmux session and pane, then retry",
                  "rowless recipient identity drifted before copy-mode cancellation", "tap send");
              }
              const authorized = authorizePaneEffect(copyTarget, {
                paneId: authorizedPaneId, serverEpoch: authorizedEpoch, harness: authorizedHarness,
                bootId: authorizedBoot, handle: manualRelay ? "" : to, instance: authorizedInstance,
              }, DARK_EFFECTS, { scriptsDir, agentFamilies, registryPath: manualRelay ? undefined : remote?.registryPath ?? ctx.registryPath });
              if (authorized.status !== "ok") {
                throw new TapError(1, authorized.status, authorized.status === "rate_limited" ? "retry the send"
                  : identityAction(`tap register ${to}   (the recorded pane is stale; re-register to rebind)`), authorized.detail);
              }
              const lockedMode = inModeRead();
              if (lockedMode === "gone") refuseDeadPane();
              if (lockedMode === "in") {
                try {
                  if (beginDeliveryAttempt(ctx.bus.home, id) !== "created") throw new Error("prior delivery attempt");
                  attemptAdmitted = true;
                } catch {
                  throw new TapError(1, "attempt_evidence_unwritable", "tap doctor", "cannot record attempt before delivery");
                }
                const cancelled = cancelCopyMode(copyTarget);
                if (cancelled === "ok") DARK_EFFECTS.settle(0.05);
                const second = cancelled === "ok" ? inModeRead() : "in";
                if (second === "gone") refuseDeadPane();
                if (second === "in") copyModeDefer = "stayed in copy-mode after cancel -> defer";
              }
            }
          } finally { copyLock.release(); }
        }
      }

      // Review round 5 (r4056301887/r4056301888): the incumbent's placement
      // re-runs the rowless identity guard INSIDE tap_send_place_canonical
      // (tap_send_require_bound_identity, tap-send.sh:1217/1350-1360) and
      // keeps a live-route marker belt there too (:1226-1233) — a route seam
      // that flipped the pane's family or recycled its pane id since route is
      // refused BEFORE anything else moves, including the sender's own live
      // re-authorization: a self-relay whose pane id was recycled must answer
      // the guard's pane_recycled, not the sender check's mismatch. The
      // incumbent's pane-alive check (tap-send.sh:1413-1427) sits before this
      // point and answers an unobservable target with rc 3, so the gone
      // states map there. The submit-time guard below stays as defense in
      // depth, as does the courier's own evidence check.
      if (manualRelay) {
        const placeRecord = unboundPaneIdentityRecord(relaySession, args.pane, {
          paneId: authorizedPaneId, harness: authorizedHarness, agentFamilies, scriptsDir,
        });
        if (placeRecord.state === "session_absent" || placeRecord.state === "session_unobservable" ||
            placeRecord.state === "pane_set_unobservable" || placeRecord.state === "designated_pane_missing" ||
            placeRecord.state === "identity_incomplete" || placeRecord.state === "pane_outside_session") {
          throw new TapError(3, "pane_gone", "human_relay", `pane '${args.pane}' gone`, "tap send");
        }
        if (placeRecord.state !== "match") {
          process.stderr.write(`tap: rowless pane identity drifted before pane effect (${placeRecord.state})\n`);
          throw new TapError(1, "identity_mismatch", "verify the exact tmux session and pane, then retry",
            "rowless recipient identity drifted before delivery", "tap send");
        }
        // The optional belt (tap-send.sh:1227-1233): route-time polarity live,
        // fresh sample invalid — refuse, publish nothing.
        if (loadGlobalRegistry(process.env.TAP_INDEX_HOME).marker === "invalid") {
          throw new TapError(1, "invalid_flip", "tap doctor",
            "manual cross-worktree send refused — global-registry.json became invalid before place");
        }
      }

      if (manualRelay) {
        // The relay's sender-side pane identity stays observed: the sender may
        // BE the relay target (self-relay), and the courier's evidence check
        // binds the live stamps. An ordinary send has no sender live-pane
        // observation in the incumbent — its facts are registry + epoch/boot
        // only, and the stamp above is the sole consequence.
        const senderObserved = observePaneResult(fromPane);
        if (senderObserved.status !== "ok") throw delegate();
        const senderObs = senderObserved.observation;
        if (senderPaneId !== senderObs.paneId) throw delegate();
        if (boundBootRefusal(String(fromSeat?.boot_id ?? ""), "delivery")) throw delegate();
        if (senderEpoch !== senderObs.serverEpoch) throw delegate();
      }

      if (opts?.resetCustodyHeld) {
        assertResetUnfenced(ctx.bus.home, "tap send");
      } else {
        resetLock = acquireResetMutationLock(ctx.bus.home, "tap send");
      }
      ctx.bus.ensureDirs();
      // An explicit --id is native since D1, so the incumbent's placement
      // refusals for an id already on the bus are produced here with the
      // incumbent's bytes, in tap_canonical_place's order: a spool entry, an
      // archived id, an existing canonical, a settled receipt.
      // tap_send_place_canonical's own selector (tap-send.sh:1216-1262) picks
      // the recipient lock (:1057-1214, generic wrap — its case statement has
      // no branch for tap_fail's exit 1, so every refusal there, spooled_id
      // included, collapses to `die "tap send: locked place failed for
      // '<to>' (<line>)"`, class `error`, action `fix_command`) only for an
      // ORDINARY (non-manual-relay) send once the global flip marker is
      // live — an ordinary send that reaches this point is always
      // v0.20-bound already: an unbound local/remote target is refused
      // upstream (this file's own `identity_unverified`/"refusing unbound
      // delivery" throw a few lines above; tap-send.sh:976-983, :987 is the
      // same guarantee), so "live + ordinary" always means recipient-lock.
      // A manual cross-worktree relay (`--cross-worktree` + bare handle,
      // never registry-bound) takes neither branch of the marker check
      // either way: :1224-1234 places directly with NO wrapper when its
      // route-time marker sampled live, and the cutover barrier (:1271-1348,
      // default at :1341-1344 passing the underlying failure through
      // untouched — only its own sentinels 17/4 may introduce a new class)
      // when that sample was absent (an invalid sample already refused
      // above, at this file's `relayRouteMarker === "invalid"` throw) — so a
      // manual relay preserves spooled_id either way. `ctx.marker` is the
      // same flip-marker snapshot resolveContext already reads (context.ts
      // `caller.marker`).
      const lockedPlaceFailed = (innerDetail: string, innerAction: string): TapError =>
        new TapError(1, "error", "fix_command", `tap send: locked place failed for '${to}' (tap: ${innerDetail}; next: ${innerAction})`);
      const barrierPlacement = manualRelay || ctx.marker !== "live";
      const spoolPayload = join(ctx.bus.home, "spool", `${id}.md`);
      const spoolMeta = join(ctx.bus.home, "spool", `${id}.meta.json`);
      if (existsSync(spoolPayload) || existsSync(spoolMeta)) {
        const detail = `id '${id}' already has a spool entry: ${spoolPayload}`;
        throw barrierPlacement
          ? new TapError(1, "spooled_id", "wait_for_redelivery_or_remove_spool_entry", detail)
          : lockedPlaceFailed(detail, "wait for redelivery or remove spool entry");
      }
      if (archiveRows(ctx.bus.home, true).has(id)) {
        throw lockedPlaceFailed(`canonical_place: refusing duplicate archived id '${id}'`, "fix command");
      }
      if (existsSync(canonPath)) {
        throw lockedPlaceFailed(`canonical_place: refusing duplicate id '${id}' (payload already exists: ${canonPath})`, "fix command");
      }
      if (existsSync(ctx.bus.donePath(id))) {
        throw lockedPlaceFailed(`canonical_place: refusing duplicate id '${id}' (receipt already settled: ${ctx.bus.donePath(id)})`, "fix command");
      }
      // The recipient reset fence's SECOND check (tap-send.sh:699): the bus
      // about to receive the payload is re-read right before the publish — a
      // reset that landed during staging is refused before anything is placed.
      assertResetUnfenced(remote ? remote.busHome : ctx.bus.home, "tap send (recipient bus)");
      // The sibling census (tap-send.sh:1647-1649): every spool row for this
      // target — complete or not — counted before placement.
      siblingsQueued = listEntries(join(ctx.bus.home, "spool"), to, remote ? remote.registryPath : ctx.registryPath).length;
      try {
      const placeCanonical = () => canonicalPlaceLocked(ctx.bus, src, {
        id, from, to, kind, path: canonPath, reply: replyExpect,
        // A manual relay carries Bash's cross_worktree/from_team stamps and NO
        // to_team: the relay never learns the recipient's team
        // (tap-send.sh:996-1001).
        cross_worktree: remote || manualRelay ? "true" : undefined,
        from_team: remote ? ctx.team : manualRelay ? relayTeamName : undefined,
        to_team: remote ? remote.team : undefined,
        // The urgency stamp rides only --urgent (tap-send.sh:1003-1004,
        // :1234): a bare closed-set tag, present on the envelope and the
        // sentinel, absent otherwise.
        urgency: urgent && !autoUrgent ? "urgent" : undefined,
        sentinel_preview: encodePreview(preview) || undefined,
        in_reply_to: inReplyTo,
        reply_to: replyToStamp,
        recipient_instance: !manualRelay && typeof toSeat.instance === "string" ? toSeat.instance : undefined,
        sender_instance: senderInstance,
        to_adopted_from: forwarded.adopted_from || undefined,
        original_recipient_instance: forwarded.source_instance || undefined,
        adopted_from: adoptedFrom,
      });
      if (manualRelay && relayRouteMarker === "absent") {
        // The cutover barrier (tap-send.sh:1271-1348): the SAME sidecar flock
        // migrate holds across its marker write; the marker is re-sampled
        // under teams.json.lock, and only a still-absent marker places — a
        // flip that landed mid-send is refused so the retry binds v0.20
        // instances. Only the barrier sentinels introduce new error classes.
        const barrier = acquirePathLock(`${legacyTeamsPath(process.env.TAP_INDEX_HOME)}.lock`, 5_000, process.env);
        if (!barrier) {
          // Fail closed: placement must serialize with migrate, never race it.
          throw new TapError(1, "lock_busy", "retry the send",
            "the cutover barrier lock is held; retry so placement serializes with the flip");
        }
        try {
          const markerNow = flipMarkerState(process.env.TAP_INDEX_HOME);
          if (markerNow === "live") {
            throw new TapError(1, "flip_in_progress", "retry: tap send …",
              "flip marker published during pre-cutover send — retry so placement binds v0.20 instances (flip_live)");
          }
          if (markerNow === "invalid") {
            throw new TapError(1, "invalid_flip", "tap doctor",
              "global-registry.json is present but unreadable or wrong schema (invalid_flip)");
          }
          placeCanonical();
        } finally {
          barrier.release();
        }
      } else {
        // Route polarity live (tap-send.sh:1226-1234): the optional belt — a
        // fresh sample gone invalid refuses the unbound place.
        if (manualRelay && loadGlobalRegistry(process.env.TAP_INDEX_HOME).marker === "invalid") {
          throw new TapError(1, "invalid_flip", "tap doctor",
            "manual cross-worktree send refused — global-registry.json became invalid before place");
        }
        placeCanonical();
      }
      } catch (error) {
        // A positional payload whose own frontmatter is not valid UTF-8 is
        // refused, as the incumbent's awk refused to stamp it (sol-pinnacle-4,
        // D1 F5): the header is text, only the body is bytes.
        if (error instanceof InvalidHeaderEncoding) {
          throw lockedPlaceFailed(`canonical_place: stamp failed for ${args.payloadFile || "the staged source"}: frontmatter is not valid UTF-8`, "fix command");
        }
        if (error instanceof Error && !(error instanceof TapError) && error.message.startsWith("canonical_place:")) {
          throw lockedPlaceFailed(error.message, "fix command");
        }
        throw error;
      }
      markResetGenerationReused(ctx.bus.home, "send");
    } finally {
      registryLocks.release();
    }
  } finally {
    obligationLock.release();
  }

  interface ParkClass { policy?: string; timeout?: string; detail?: string }
  const parkQueued = (reason: string, grace = "", cue = "", cueRedAt = "", cls: ParkClass = {}): SendOutcome => {
    const supervisorGrace = process.env.TAP_SEND_GRACE_SECONDS ?? "";
    if (from === WATCH_IDENTITY && args.fyi && kind === "probe" && supervisorGrace !== "" && !/[^0-9]/.test(supervisorGrace)) {
      grace = supervisorGrace;
    }
    const policy = cls.policy ?? "standard";
    const timeoutSeconds = cls.timeout ?? "";
    // `--no-spool` refuses a proven pre-effect defer and never creates an owner
    // (tap-send.sh:108-113): the canonical and its `.placed` go, the refusal
    // names the reason and the defer's own detail.
    if (noSpool) {
      rmSync(canonPath, { force: true });
      rmSync(ctx.bus.placedPath(id), { force: true });
      throw new TapError(1, "delivery_refused", "re-send when the recipient is ready",
        `--no-spool refused (${reason}); no message queued${cls.detail ? `; ${cls.detail}` : ""}`, "tap send");
    }
    // The unbound manual relay never parks (tap-send.sh:152-157): its target is
    // no registry seat, so no spool row could ever redeliver — the canonical
    // goes and the refusal says so. This is the ONE convergence point: the
    // readiness defers, polite parks, recovery holds and clear fences all land
    // here, so the guard covers every spool-write path at once.
    if (manualRelay) {
      rmSync(canonPath, { force: true });
      rmSync(ctx.bus.placedPath(id), { force: true });
      throw new TapError(1, "identity_unverified", "register the recipient in its TAP team, then address it as <team>/<handle>",
        "unbound manual relay cannot be parked for later delivery", "tap send");
    }
    // The park's whole route in process (spool-park-report.ts `parkAndReport`: the A1b
    // transaction, the cue, the deliverer spawn, the backlog, the injection facts) —
    // the same export lib.sh's `tap_spool_park_placed` adapts. Resolved pane/pane_id
    // are captured HERE, at park time, from this send's own resolution; redelivery
    // replays against this exact pane. The environment the Bash route carried
    // (TAP_HOME, TAP_LOCK_DIR) still reaches the deliverer child it spawns. The
    // class's policy and timeout (D3a: the polite pair) travel as the park's own.
    const parkEnv = { ...process.env, TAP_LOCK_DIR: lockRoot(), TAP_HOME: ctx.bus.home };
    let report: ParkReport | null = null;
    try {
      report = parkAndReport({
        spoolDir: join(ctx.bus.home, "spool"), home: ctx.bus.home, id, canonical: canonPath, target: to, acting: ctx.team,
        reason, timeoutSeconds, pane, paneId: authorizedPaneId, toTeam: remote ? remote.team : "", targetRegistry: remote ? remote.registryPath : manualRelay ? "" : ctx.registryPath,
        policy, graceSeconds: grace, cueStyle: cue, cueRedAt, env: parkEnv,
        from, kind, replyExpect, scriptsDir,
      });
    } catch (error) {
      // A decided refusal (`spool_busy`, `spool_publish_failed`: the claim is released
      // and the canonical retained) reports as the adapter's `tap_fail` did on stderr;
      // any failure then takes the fallback below, exactly as a failed shell did.
      const detail = String(error instanceof Error ? error.message : error).replace(/[\r\n]/g, " ");
      process.stderr.write(error instanceof ParkRefusal ? `tap send: ${detail}; next: inspect with tap show ${id}\n` : `tap send: ${detail}\n`);
    }
    if (!report) {
      // A refusal after publication (the canonical could not be retired) leaves the pair;
      // it is reported exactly as a failed shell park was. (A failed waiter spawn is the
      // report's own `spawned: false` and renders below.)
      process.stderr.write(`tap send: warning: parking '${id}' did not complete; inspect with tap show ${id}; automatic redelivery is not confirmed\n`);
      const spoolPath = join(ctx.bus.home, "spool", `${id}.md`);
      const metaPath = join(ctx.bus.home, "spool", `${id}.meta.json`);
      const regular = (path: string): boolean => {
        try { return statSync(path).isFile(); } catch { return false; }
      };
      if (regular(spoolPath) && regular(metaPath)) {
        if (!opts?.quiet) {
          process.stdout.write(json
            ? `${jsonObj({ status: "queued", delivery: "spool", id, from, to, pane, kind,
                turn: "unconfirmed", path: spoolPath, meta: metaPath,
                reason: "spool_park_failed", action: `tap show ${id}` })}\n`
            : process.env.TAP_VERBOSE === "1"
              ? `tap ${receiptVerb}: accepted, queued ${id} for ${to}; reply ${replyExpect}. Delivery not confirmed. Inspect with tap show ${id}.\n`
              : `tap ${receiptVerb}: queued ${id}\n`);
        }
        return { rc: 0, disposition: "queued-spool" };
      }
      if (regular(canonPath)) return emitQueued("spool_park_failed", `tap show ${id}`);
      throw new TapError(1, "spool_park_failed", `tap show ${id}`,
        "parking failed and no complete spool entry or canonical payload could be confirmed", "tap send");
    }
    if (!opts?.quiet) {
      // The verbose human receipt's `[display state]` token is READINESS, still Bash
      // (`tap_spool_display_state` → `tap_spool_pane_ready`; ported with the drain's
      // attempt transaction once lane B's reader lands). It is read only for the one
      // form that prints it. A read, not a pane effect; "" when it cannot be read.
      let displayState = "";
      if (!json && process.env.TAP_VERBOSE === "1") {
        const probe = spawnSync("bash", ["-c", 'set -euo pipefail; . "$1/lib.sh"; tap_spool_display_state "$2"', "tap-native-park", scriptsDir, id],
          { encoding: "utf8", env: parkEnv });
        if (!probe.error && probe.status === 0) displayState = probe.stdout.replace(/\n$/, "");
      }
      process.stdout.write(renderParkReceipt(report, { home: ctx.bus.home, id, from, to, pane, kind, replyExpect, reason,
        policy, json, verbose: process.env.TAP_VERBOSE === "1", verb: receiptVerb, displayState }));
    }
    return { rc: 0, disposition: "queued-spool" };
  };

  const emitQueued = (reason?: string, action?: string, extra = "", detail?: string): SendOutcome => {
    if (!opts?.quiet) {
      if (json) {
        process.stdout.write(`${jsonObj({
          status: "queued", delivery: "poll", id, from, to, pane, kind,
          turn: "unconfirmed", path: canonPath,
          ...(reason ? { reason } : {}),
          ...(action ? { action } : {}),
          ...(detail ? { detail } : {}),
        })}\n`);
      } else {
        // Keep recovery for a pre-effect delivery fallback visible by default.
        process.stdout.write(
          process.env.TAP_VERBOSE === "1" ? `tap ${receiptVerb}: accepted, queued ${id} for ${to}; reply ${replyExpect}${extra}\n` : `tap ${receiptVerb}: queued ${id}\n`,
        );
        if (action) process.stderr.write(`tap send: ${reason}${detail ? `; ${detail}` : ""}; action: ${action}\n`);
      }
    }
    return { rc: 0, disposition: "queued-poll" };
  };

  // The copy-mode defer that outlived the cancel (tap-send.sh:1635-1636):
  // the canonical is placed FIRST (above), then the typed reason spools —
  // the same place-then-defer order as the incumbent's other-rc arm.
  if (autoUrgent) {
    process.stderr.write("tap send: warning: auto_mode_no_interrupt: auto seat cannot be interrupted; queued as ordinary delivery\n");
    return parkQueued("auto_mode_no_interrupt");
  }
  if (copyModeRecoveryHeld) return parkQueued("recovery-hold", "", "", "", { detail: "recovery owns the recipient; delivery parked" });
  if (copyModeDefer) return parkQueued("copy-mode", "", "", "", { detail: copyModeDefer });

  if (pollRecipient) {
    atomicWrite(ctx.bus.sentPath(id), `${jsonObj({
      id, from, to, pane, kind, turn: "unconfirmed", delivery: "poll",
    })}\n`);
    return emitQueued();
  }

  const dispositionFor = (band: DeliveryBand) => deliveryDisposition({
    band, harness: authorizedHarness, urgent: false, noSpool,
    // The manual relay's target binding is unbound (Bash TARGET_BINDING=0).
    recipientBound: !manualRelay,
    // The sibling census (tap-send.sh:1647-1649) counts EVERY spool row for
    // this target — complete or not (listEntries keeps incomplete rows) —
    // taken before placement, exactly where Bash pipes tap_spool_list.
    siblingsQueued,
  });
  const parkDisposition = (decision: ReturnType<typeof deliveryDisposition>, detail = "") => parkQueued(
    decision.parkReason!, decision.graceSeconds === null ? "" : String(decision.graceSeconds),
    decision.cue.initialStyle ?? "", decision.cue.redAtSecondsBeforeDeadline === null ? "" : String(decision.cue.redAtSecondsBeforeDeadline),
    { detail },
  );
  // Slash qualification is sentinel-only (tap-send.sh:1594-1612): a cross-team
  // sentinel names both teams, and carries `path=` exactly when the sender's
  // team does not resolve through the index (lib.sh:822-838). The manual
  // relay is the unindexed shape: the sender's team on the from, a bare
  // handle on the to, no sender-index question — so `path=` always rides.
  const sentinel = renderSentinel({
    from: remote ? `${ctx.team}/${from}` : manualRelay ? `${relayTeamName}/${from}` : from, to: remote ? `${remote.team}/${to}` : to,
    id, kind, reply: replyExpect, path: canonPath,
    urgency: urgent ? "urgent" : undefined,
    senderIndex: remote ? senderIndexEvidence(ctx.team, process.env.TAP_INDEX_HOME) : undefined,
  });
  // The incumbent's post-placement sequence, in its order (tap-send.sh:1617
  // render → :1632 recovery guard → :1639 clear-fence inspection → :1661
  // polite park → :1666 submit): the render first, so an index that turns
  // invalid at render refuses on both doors before any park; recovery owns the
  // recipient before a clearing fence does (a hold parks `recovery-hold`,
  // under the polite pair when polite); the fence is read ONCE, here, and that
  // read alone decides — live parks, expired warns and continues (on the
  // submit path the courier's own read prints that warning), absent continues.
  // Then `--polite` parks before any disposition, copy-mode or band question.
  if (recoveryHold(authorizedPaneId || pane)) {
    return parkQueued("recovery-hold", "", "", "", { policy: retryablePolicy, timeout: retryableTimeout, detail: "recovery owns the recipient; delivery parked" });
  }
  const fenceBus = remote ? remote.busHome : ctx.bus.home;
  const fence = inspectClearFenceRecord(fenceBus, to);
  if (fence.state === "live" && urgent) {
    // The incumbent refuses urgent outright on a live fence: a human is
    // actively clearing, and interrupting them would be worse than waiting
    // (tap-send.sh:1714-1729 — the canonical goes, nothing is queued or typed).
    rmSync(canonPath, { force: true });
    const rec = fence.rec ?? {};
    const pid = rec.pid === undefined || rec.pid === null || rec.pid === "" ? "unknown" : String(rec.pid);
    const since = rec.since_epoch === undefined || rec.since_epoch === null || rec.since_epoch === "" ? "unknown" : String(rec.since_epoch);
    throw new TapError(1, "recipient_clearing",
      `wait for '${to}' to finish clearing, then retry without --urgent`,
      `seat '${to}' is mid-clear (pid ${pid} since ${since})`, "tap send");
  }
  if (fence.state === "live") return parkQueued("clearing", "", "", "", { detail: `seat '${to}' is mid-clear` });
  if (fence.state === "expired" && polite && noticeExpiredAtSendDoor(fenceBus, to, fence.rec)) {
    process.stderr.write(`tap send: WARNING: clear fence for ${to} expired; delivering anyway (fail-open past the family await ceiling)\n`);
  }
  if (polite) return parkQueued("polite", "", "", "", { policy: "polite", timeout: args.politeTimeout });
  // Review round 2 (critical 1): the rowless relay re-observes its pane
  // immediately before effect, as the incumbent's courier does
  // (tap_harness_evidence, lib.sh:7207). The proof's identity bind is
  // re-checked: an observed miss is pane gone (terminal, rc 3) and a flipped
  // command family is harness_exited drift (terminal, rc 1). A rowless relay
  // defers NOWHERE — no spool row could redeliver — so both clean the
  // canonical and refuse instead of queueing.
  if (manualRelay) {
    const relayObs = observePaneResult(pane, process.env);
    if (relayObs.status === "unobservable") {
      rmSync(canonPath, { force: true });
      rmSync(ctx.bus.placedPath(id), { force: true });
      throw new TapError(1, "tmux_unreachable", "restore tmux observation, then retry", relayObs.reason);
    }
    if (relayObs.status === "pane_gone") {
      rmSync(canonPath, { force: true });
      rmSync(ctx.bus.placedPath(id), { force: true });
      // The incumbent's rowless pane-gone refusal (measured bash bytes for
      // this scenario: tap_fail 3 pane_gone human_relay "pane '$PANE' gone").
      throw new TapError(3, "pane_gone", "human_relay", `pane '${pane}' gone`, "tap send");
    }
    // Review round 5: the evidence re-check goes through the SAME record the
    // place-time guard uses, so the drift state in the incumbent's line is
    // the record's own verdict (harness_mismatch for an agent flip, not a
    // hardcoded exited).
    if (relayObs.status === "ok") {
      const drift = unboundPaneIdentityRecord(relaySession, pane, {
        paneId: authorizedPaneId, harness: authorizedHarness, agentFamilies, scriptsDir,
      });
      if (drift.state !== "match") {
        process.stderr.write(`tap: rowless pane identity drifted before pane effect (${drift.state})\n`);
        rmSync(canonPath, { force: true });
        rmSync(ctx.bus.placedPath(id), { force: true });
        throw new TapError(1, "identity_mismatch", "verify the exact tmux session and pane, then retry",
          "rowless recipient identity drifted before delivery", "tap send");
      }
    }
  }
  // The manual relay's submit is bound to the RESOLVED pane identity only: no
  // registry row is named (handle empty — the courier's row re-read is
  // skipped) and no permissions registry is consulted, matching Bash
  // TARGET_BINDING=0 and its bypassed tap_recorded_permissions. The authority
  // keeps the sender's bus so fences and failure capture still work.
  // The incumbent warns and records the registry event AFTER the red cue and
  // BEFORE the submit, unconditionally across harnesses including hermes
  // (tap-send.sh:1757-1760: `tap_warning send "urgent — interrupting …"` then
  // `tap_registry_event_append_or_warn "$FROM" urgent_interrupt "$TO" "$PANE"`).
  // The red cue itself fires inside the courier's urgent block, under the
  // pane's submit lock.
  if (urgent) {
    process.stderr.write(`tap send: warning: urgent — interrupting '${to}' (harness=${authorizedHarness}) before injecting\n`);
    appendRegistryEventOrWarn("tap send", {
      log: registryEventsPath(ctx.bus.home),
      actor: from, action: "urgent_interrupt", handle: to, pane, team: ctx.team, detail: "",
    });
  }
  const result = submitVerify(pane, id, queuePrefix + sentinel, manualRelay ? {
    paneId: authorizedPaneId,
    serverEpoch: authorizedEpoch,
    harness: authorizedHarness,
    bootId: "",
    handle: "",
    instance: "",
  } : {
    paneId: authorizedPaneId,
    serverEpoch: authorizedEpoch,
    harness: authorizedHarness,
    bootId: authorizedBoot,
    handle: to,
    instance: authorizedInstance,
  }, manualRelay ? {
    scriptsDir, agentFamilies, busHome: ctx.bus.home, recipient: to, attemptAdmitted,
    noPromptOk: authorizedHarness.startsWith("hermes"),
    deliveryFacts: { urgent, noSpool, recipientBound: false, siblingsQueued: 0, harness: authorizedHarness },
  } : {
    scriptsDir, agentFamilies, busHome: ctx.bus.home, recipientBusHome: remote?.busHome, recipient: to, attemptAdmitted,
    registryPath: remote ? remote.registryPath : ctx.registryPath,
    noPromptOk: authorizedHarness.startsWith("hermes"),
    deliveryFacts: { urgent, noSpool, recipientBound: true, siblingsQueued, harness: authorizedHarness },
  }, {
    ...DARK_EFFECTS,
    clobber: (target, command, bound, backup) => clobberBand(target, command, bound, DARK_EFFECTS, backup, ""),
  });

  if (result.status === "team_reset_fenced") {
    // Retraction is legitimate only because the reset fence blocks every
    // observer (poll, done, reply, send). If poll is ever unfenced, this
    // deletion retracts mail a recipient could already have read.
    rmSync(canonPath, { force: true });
    rmSync(ctx.bus.placedPath(id), { force: true });
    throw new TapError(1, "team_reset_fenced", result.action, result.detail, "tap send");
  }

  if (result.status === "recovery_held") {
    return parkQueued("recovery-hold", "", "", "", { policy: retryablePolicy, timeout: retryableTimeout, detail: "recovery owns the recipient; delivery parked" });
  }

  if (result.status === "clearing") {
    return parkQueued("clearing", "", "", "", { detail: `seat '${to}' is mid-clear` });
  }

  // A certified pre-effect refusal under `--no-spool` leaves nothing queued:
  // the incumbent's pre-submit identity recheck removes the canonical and
  // fails (tap-send.sh:1687-1695, `identity_mismatch`) whatever the class, and
  // the flag's contract is "no message queued". Measured for a pane_id drift
  // under the held submit lock; the pane-gone arm mirrors its pre-placement
  // refusal by reading (the fake cannot lose a pane between placement and the
  // band check — #xxxx's dropped row).
  const refuseUnqueued = (code: number, cls: string, action: string, detail: string): never => {
    rmSync(canonPath, { force: true });
    rmSync(ctx.bus.placedPath(id), { force: true });
    throw new TapError(code, cls, action, detail, "tap send");
  };

  if (result.status === "attempt_evidence_unwritable") {
    rmSync(canonPath, { force: true });
    try { rmSync(ctx.bus.placedPath(id), { force: true }); } catch { /* the receipt directory is already known unwritable */ }
    throw new TapError(1, "attempt_evidence_unwritable", "tap doctor", result.detail, "tap send");
  }

  if (result.status === "identity_mismatch") {
    // Review round 2 (critical 1): a rowless relay never queues a certified
    // pre-effect mismatch — it has no spool row and no poller; the canonical
    // goes and the refusal is terminal (the incumbent's rowless convergence).
    if (manualRelay) {
      rmSync(canonPath, { force: true });
      rmSync(ctx.bus.placedPath(id), { force: true });
      throw new TapError(1, "identity_mismatch", "verify the exact tmux session and pane, then retry",
        "rowless recipient identity drifted before delivery", "tap send");
    }
    if (noSpool) refuseUnqueued(1, "identity_mismatch", identityAction(`tap register ${to}   (the recorded pane is stale; re-register to rebind)`), result.detail);
    // Proven pre-effect: authorize refused before any keystroke. Canonical and
    // `.placed` stay so a poller who already saw the mail can still settle it.
    return emitQueued(
      "identity_mismatch",
      identityAction(`tap register ${to}   (the recorded pane is stale; re-register to rebind)`),
      result.detail ? `; ${result.detail}` : "",
      result.detail,
    );
  }

  if (result.status === "pane_gone") {
    // Rowless relay: pane gone is terminal, never queued (review round 2).
    if (manualRelay) {
      rmSync(canonPath, { force: true });
      rmSync(ctx.bus.placedPath(id), { force: true });
      throw new TapError(3, "pane_gone", "human_relay", result.detail, "tap send");
    }
    if (noSpool) refuseUnqueued(3, "pane_gone", "human_relay", result.detail);
    // submitVerify reports pane_gone only from the pre-inject band check, so
    // this is certified pre-effect. Mid-paste disappearance is `unverified`.
    return emitQueued(
      "pane_gone",
      "human_relay",
      result.detail ? `; ${result.detail}` : "",
      result.detail,
    );
  }

  if (result.status === "lock_busy" || result.status === "band_busy" || result.status === "rate_limited" || result.status === "copy_mode") {
    if (noSpool) {
      // The refusal names what the incumbent named: its pre-attempt copy-mode
      // sentence (tap-send.sh:1537), its driver's draft line for a band that
      // was READ as busy or queued under `tap_send_defer_reason`'s
      // `no-input-prompt` catch-all (lib.sh:11846, tap-send.sh:60-64),
      // OpenCode's `booting` hold for a composer it could not observe, its
      // pane-submit lock sentence (lib.sh:11040 — both doors wait the same
      // five seconds), its rc-4 defer line for a band that was unobservable
      // for any reason other than unreadable geometry — a human decision on
      // screen (lib.sh:11279; the geometry-unreadable reasons never reach here,
      // the courier injected); every other hold (a rate-limited read, a
      // permission policy that would not read, an auto seat's band) keeps this
      // door's own sentence under the same catch-all.
      const [reason, detail] = result.status === "copy_mode" ? ["copy-mode", "pane is in copy mode or unreadable"]
        : result.status === "lock_busy" ? ["no-input-prompt", `tap: another submit holds pane '${pane}' (waited 5s) -> park`]
        : result.status === "band_busy" && (result.bandState === "busy" || result.bandState === "queued") ? ["no-input-prompt", "tap: draft-preserving delivery refuses pending human input"]
        : result.status === "band_busy" && result.bandState === "unobservable" && authorizedHarness.startsWith("opencode") ? ["booting", result.detail]
        : result.status === "band_busy" && result.bandState === "unobservable" ? ["no-input-prompt", `tap: pane '${pane}' has no visible input prompt -> defer`]
        : ["no-input-prompt", result.detail];
      return parkQueued(reason, "", "", "", { detail });
    }
    if (result.status === "copy_mode") return parkQueued("copy-mode", "", "", "", { policy: retryablePolicy, timeout: retryableTimeout, detail: result.detail });
    if (result.status === "band_busy" && result.disposition) return parkDisposition(result.disposition, result.detail);
    // Urgent never parks through the ordinary disposition — its own
    // disposition row is an inject (no park reason to render). The incumbent's
    // rc-4 defer parks under the catch-all no-input-prompt reason and the
    // standard policy (lib.sh:11279, tap-send.sh:60-64), and its refusal
    // sentence rode STDERR next to the park — the park receipt renders the
    // canonical queue explanation, so the verbatim sentence goes here.
    if (urgent) {
      if (result.detail) process.stderr.write(`tap send: ${result.detail}\n`);
      return parkQueued("no-input-prompt", "", "", "", { detail: result.detail });
    }
    const band: DeliveryBand = result.status === "band_busy" && result.bandState === "queued" ? "queued"
      : result.status === "band_busy" && result.bandState === "busy"
        ? deliveryBand(result.bandText ?? "unsubmitted input", authorizedHarness, "") : "unobservable";
    return parkDisposition(dispositionFor(band), result.detail);
  }

  if (result.status === "harness_queued") {
    recordHarnessQueued(ctx.bus.home,id);
    if (!opts?.quiet) process.stdout.write(harnessQueueMessage(ctx.bus.home,id,json));
    return { rc: 0, disposition: "queued-harness" };
  }
  if (result.status === "unverified") {
    if (result.reprobePending && !noSpool && !manualRelay) {
      return parkQueued("pending-input", "30", "", "", {
        policy: urgent ? "urgent" : retryablePolicy, timeout: retryableTimeout, detail: result.detail,
      });
    }
    // The canonical STAYS. No `.sent` is written — that is the whole point of
    // exit 5: the recipient may still poll it, and the sender can see that the
    // submit went unconfirmed rather than being told either lie.
    appendSubmitUnverifiedEvent(ctx.bus.home, ctx.team, from, to, pane, id);
    if (!opts?.quiet) {
      const output = unverifiedSend(ctx.bus.home, id, from, to, canonPath, json);
      process.stdout.write(output.stdout); process.stderr.write(output.stderr);
    }
    return { rc: 5, disposition: "unverified" };
  }

  // `turn=unconfirmed` is UNCONDITIONAL and is never upgraded on this path. The
  // courier verified the id left the input band; no harness in the fleet exposes
  // a post-submit turn-boundary token, so nothing here may imply a turn began.
  atomicWrite(ctx.bus.sentPath(id), `${jsonObj({
    id, from, to, pane, kind, turn: "unconfirmed", delivery: "pane",
  })}\n`);

  // An empty registry is a no-op, not a fallback (lib.sh:1911-1916, ruling 43):
  // the manual unbound relay has no authoritative target registry and no clock
  // to stamp — the stamp is skipped outright, exactly as the empty-path call was.
  if (!manualRelay) deliveryClockStamp(remote ? remote.registryPath : ctx.registryPath, to);

  if (!opts?.quiet) {
    if (json) {
      process.stdout.write(`${jsonObj({
        status: "injected", delivery: "pane", id, from, to, pane, kind, turn: "unconfirmed", path: canonPath,
      })}\n`);
    } else {
      process.stdout.write(
        process.env.TAP_VERBOSE === "1" ? `tap ${receiptVerb}: accepted, injected ${id} to ${to}; reply ${replyExpect}\n` : `tap ${receiptVerb}: ok ${id}\n`,
      );
    }
  }
  return { rc: 0, disposition: "delivered" };
  } finally {
    resetLock?.release();
  }
}

export { utcStamp };

function refuseReservedIdentity(handle: string, role: "to" | "from", busHome: string): void {
  if (handle === COURIER_IDENTITY) {
    throw new TapError(
      1,
      "reserved_handle",
      role === "to" ? "tap send <a-teammate> …" : "tap send <a-teammate> --from <your-handle>",
      role === "to"
        ? `'${COURIER_IDENTITY}' is the reserved courier digest-envelope identity and can never receive a send (digests are delivery envelopes, not seats). Address a real teammate instead.`
        : `'${COURIER_IDENTITY}' is the reserved courier digest-envelope identity and cannot be a --from sender`,
    );
  }
  if (handle === HELP_HANDLE) {
    throw new TapError(
      1,
      "reserved_handle",
      "tap send <a-teammate> …",
      `'${HELP_HANDLE}' is the CLI help keyword (so 'tap <verb> help' is unambiguous for every verb) and cannot be a ${role === "to" ? "send destination" : "--from sender"}`,
    );
  }
  if (handle === WATCH_IDENTITY) {
    if (role === "from") {
      // The watch sidecar cannot register, so its one lawful use — settle-only
      // mail (`--fyi` with --kind probe, notice or progress) — is decided with
      // the sender facts inside the lock: an eligible watcher send proceeds,
      // an ineligible one is refused there with the incumbent's
      // reserved-identity bytes (tap-send.sh:541-553).
      return;
    }
    throw new TapError(
      1,
      "reserved_handle",
      "tap send <a-teammate> …",
      `'${WATCH_IDENTITY}' is the reserved watcher identity and can never receive a send`,
    );
  }
}

function isTmuxPaneId(value: string): boolean {
  return /^%[0-9]+$/.test(value);
}

/**
 * Every acting-registry lock one send holds, taken in the sorted realpath order
 * of the sidecars (tap-send.sh:1030-1036) and released together. One busy
 * sidecar releases what was taken and refuses as a single busy registry does.
 */
/**
 * The recipient's acting registry, read in-process. On the Bash door the first
 * reader of that file is the forwarding resolver (tap-send.sh:79-97, a
 * `forwarding.ts` child over the same `loadRegistry`), so a torn file or a
 * value outside the registry's number domain is `forwarding_unavailable`
 * there — the verdict both doors give; the reader's own sentence is not part
 * of it.
 */
function loadRemoteRegistry(registryPath: string, originalTo: string): RegistryDoc {
  try {
    return loadRegistry(registryPath);
  } catch {
    throw new TapError(1, "forwarding_unavailable", "tap team; retry with a current recipient",
      `cannot resolve pinned forwarding for '${originalTo}'; no payload was placed`);
  }
}

function acquireRegistryLocks(paths: string[]): { release(): void } {
  const key = (p: string): string => {
    const sidecar = `${p}.lock`;
    try { return realpathSync(sidecar); } catch { return join(realpathOrSelf(dirname(sidecar)), basename(sidecar)); }
  };
  const ordered = [...new Map(paths.map(p => [key(p), p])).entries()].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  const held: RegistryLock[] = [];
  const release = (): void => { while (held.length) held.pop()!.release(); };
  for (const [, path] of ordered) {
    const lock = acquireRegistryLock(path);
    if (!lock) {
      release();
      throw new TapError(1, "registry_lock_busy", "retry the send",
        `acting registry '${path}' is busy; refusing to place from an incoherent snapshot`);
    }
    held.push(lock);
  }
  return { release };
}

function realpathOrSelf(p: string): string {
  try { return realpathSync(p); } catch { return p; }
}

function ownSeat(seats: Record<string, unknown>, handle: string): Record<string, unknown> | null {
  if (!Object.hasOwn(seats, handle)) return null;
  const row = seats[handle];
  return typeof row === "object" && row !== null && !Array.isArray(row)
    ? row as Record<string, unknown>
    : null;
}

function deliverableLocal(seats: Record<string, unknown>, handle: string): boolean {
  const seat = ownSeat(seats, handle);
  if (!seat || String(seat.status ?? "active") !== "active") return false;
  // `tap_seat_deliverable` rejects a `launching` status_reason outright
  // (lib.sh:7337-7343); a launching row is not a deliverable target yet.
  if (String(seat.status_reason ?? "") === "launching") return false;
  const delivery = String(seat.delivery ?? "pane");
  return delivery === "poll" || !!String(seat.pane ?? "");
}

function autoReplyTo(
  from: string,
  fromSeat: Record<string, unknown>,
  seats: Record<string, unknown>,
  team: string,
  ctx: ReturnType<typeof resolveContext>,
): string | undefined {
  const stored = typeof fromSeat.reply_to === "string" ? fromSeat.reply_to : "";
  if (!stored) return undefined;
  if (stored === from) {
    selfReplyToWarning(stored);
    return undefined;
  }
  if (/[/:]/.test(stored)) {
    // send-reply-r2 checkpoint A (U1): the qualified stored form takes the
    // same deliverability port as an explicit stamp (tap-send.sh:582-613).
    // Scope resolves BEFORE the self test: a remote team naming the same
    // handle is a legitimate default and stamps; only an address that
    // resolves LOCAL to the sender is the self-pointing case.
    const answer = seatDeliverable(stored, ctx);
    if (answer.deliverable) {
      if (answer.local && answer.handle === from) {
        selfReplyToWarning(stored);
        return undefined;
      }
      return stored;
    }
    notDeliverableReplyToWarning(stored);
    return undefined;
  }
  if (deliverableLocal(seats, stored)) return `${team}/${stored}`;
  notDeliverableReplyToWarning(stored);
  return undefined;
}

function selfReplyToWarning(stored: string): void {
  process.stderr.write(
    `tap send: warning: this seat's registered reply_to '${stored}' points to itself — sending without it (register --reply-to <different-handle> to refresh it)\n`,
  );
}

function notDeliverableReplyToWarning(stored: string): void {
  process.stderr.write(
    `tap send: warning: this seat's registered reply_to '${stored}' is not currently deliverable — sending without it (register --reply-to <handle> to refresh it)\n`,
  );
}

interface DeliverableAnswer {
  deliverable: boolean;
  team: string;
  handle: string;
  /** How the address failed to resolve, when it did. */
  scope: "ok" | "unknown_team" | "other";
  detail: string;
  qualified: boolean;
  /** Whether the address resolves to the CALLER's own team — the scope the
   *  self-pointing tests key on, carried from the resolver itself. */
  local: boolean;
}

/**
 * `tap_seat_deliverable` (lib.sh:7307) over the native bind/row primitives
 * (send-reply-r2 checkpoint A, U1): resolve the address — bare means the
 * caller's own team, qualified binds through the machine index — then read one
 * seat row and report deliverability: active, not launching, and a poll member
 * or pane-backed, with the forwarding route applied as the incumbent's helper
 * does. The unresolvable index scopes answer not-deliverable and name their
 * scope, which is everything the explicit stamp's refusals need.
 */
function seatDeliverable(address: string, ctx: ReturnType<typeof resolveContext>): DeliverableAnswer {
  const slash = address.indexOf("/");
  if (slash !== -1) {
    const team = address.slice(0, slash);
    const handle = address.slice(slash + 1);
    if (team === ctx.team) return deliverableRow(ctx.registryPath, team, handle, true, ctx.team);
    let bound: RemoteTeam;
    try {
      bound = bindRemoteTeam(team, handle, process.env.TAP_INDEX_HOME);
    } catch (error) {
      if (!(error instanceof TapError)) throw error;
      if (error.errorClass === "unknown_team") {
        // The incumbent's explicit sentence reuses the bind detail's inner
        // clause: `--reply-to team 'T' is unknown (not in the machine index; …)`.
        const m = /^unknown team '([^']*)' \((.*)\)\. Fallback:/.exec(error.detail);
        return { deliverable: false, team, handle, scope: "unknown_team", detail: m ? m[2]! : error.detail, qualified: true, local: false };
      }
      return { deliverable: false, team, handle, scope: "other", detail: error.detail, qualified: true, local: false };
    }
    return deliverableRow(bound.registryPath, bound.team, handle, true, ctx.team);
  }
  return deliverableRow(ctx.registryPath, ctx.team, address, false, ctx.team);
}

function deliverableRow(registryPath: string, team: string, handle: string, qualified: boolean, ctxTeam: string): DeliverableAnswer {
  const local = !qualified || team === ctxTeam;
  try {
    const doc = loadRegistry(registryPath);
    // The forwarding route applies under the v20 marker (lib.sh:7345); a
    // refusal reads as not-deliverable, which the stamp sites map from here.
    const target = forwardingRoute(doc, handle).target;
    return { deliverable: deliverableLocal(seatMap(doc), target), team, handle, scope: "ok", detail: "", qualified, local };
  } catch {
    return { deliverable: false, team, handle, scope: "other", detail: `no registry at team '${team}' root`, qualified, local };
  }
}

/**
 * The explicit `--reply-to` stamp (send-reply-r2 checkpoint A, U1;
 * tap-send.sh:582-613): the caller names where the recipient's reply lands, so
 * every ambiguity is the caller's to fix — the refusals are hard and name the
 * scope, a deliverable address stamps `<team>/<handle>`, and only the
 * registry-DEFAULT form (autoReplyTo) falls back to a warning.
 */
function explicitReplyToStamp(raw: string, from: string, ctx: ReturnType<typeof resolveContext>): string {
  let address = raw;
  if (raw.includes(":") && !raw.includes("/")) {
    const team = raw.slice(0, raw.indexOf(":"));
    const handle = raw.slice(raw.indexOf(":") + 1);
    if (!validToken(team) || !validToken(handle)) {
      throw new TapError(1, "usage_error", "tap help send", `--reply-to '${raw}' is not a valid <team>:<handle> token (${TOKEN_RE})`);
    }
    address = `${team}/${handle}`;
  }
  const answer = seatDeliverable(address, ctx);
  if (!answer.deliverable) {
    if (answer.scope === "unknown_team") {
      throw new TapError(1, "unknown_team", "tap help send",
        `--reply-to team '${answer.team}' is unknown (${answer.detail})`);
    }
    throw new TapError(1, "not_found", "tap help send",
      `--reply-to handle '${answer.handle}' is not a deliverable seat in team '${answer.team}' right now (must be an active pane member or active poll member)`);
  }
  if (answer.local && answer.handle === from) {
    throw new TapError(1, "usage_error", "tap help send",
      `--reply-to names where the recipient's tap reply lands; as sender '${from}', replies already return to you — omit --reply-to. Use it to route answers to another seat's inbox`);
  }
  return `${answer.team}/${answer.handle}`;
}

/**
 * `tap_unbound_pane_identity_record` (lib.sh:7183), native (send-reply-r2
 * checkpoint A, U2): the manual relay's proof that the caller's tmux server
 * observes the given pane as designated membership of the named session. The
 * session observation must agree on one server epoch; the session's own pane
 * rows must parse six validated fields; the pane address must be among them.
 */
function unboundPaneIdentityRecord(
  session: string,
  pane: string,
  expected?: { paneId: string; harness: string; agentFamilies: ReadonlySet<string>; scriptsDir: string },
  env: NodeJS.ProcessEnv = process.env,
): { state: string; paneId: string; epoch: string } {
  if (!session || !pane) return { state: "identity_incomplete", paneId: "", epoch: "" };
  if (!pane.startsWith(`${session}:`)) return { state: "pane_outside_session", paneId: "", epoch: "" };
  const s = tmuxReadOnly(["list-sessions", "-F", "#{session_name}\t#{pid}:#{start_time}"], env);
  if (s.code !== 0) return { state: "session_unobservable", paneId: "", epoch: "" };
  let epoch = "";
  let wanted = false;
  for (const line of s.stdout.split("\n")) {
    if (!line) continue;
    const [name, raw] = line.split("\t");
    if (!name || !raw) return { state: "session_unobservable", paneId: "", epoch: "" };
    const e = serverEpochFromRaw(raw, env);
    if (!e || (epoch && epoch !== e)) return { state: "session_unobservable", paneId: "", epoch: "" };
    epoch = e;
    if (name === session) wanted = true;
  }
  if (!wanted) return { state: "session_absent", paneId: "", epoch: "" };
  const p = tmuxReadOnly(["list-panes", "-s", "-t", `=${session}`, "-F",
    "#{session_name}\t#{session_name}:#{window_index}.#{pane_index}\t#{pane_id}\t#{pane_current_command}\t#{pane_pid}\t#{pid}:#{start_time}"], env);
  if (p.code !== 0) return { state: "session_unobservable", paneId: "", epoch };
  let foundId = "";
  let foundCommand = "";
  let foundPid = "";
  for (const line of p.stdout.split("\n")) {
    if (!line) continue;
    const f = line.split("\t");
    if (f.length !== 6) return { state: "session_unobservable", paneId: "", epoch };
    const [name, address, id, command, pid, raw] = f;
    if (name !== session || !address || !address.includes(":") || !id || !id.startsWith("%") || !pid || !/^[0-9]+$/.test(pid)) {
      return { state: "session_unobservable", paneId: "", epoch };
    }
    const e = serverEpochFromRaw(raw ?? "", env);
    if (!e || e !== epoch) return { state: "session_unobservable", paneId: "", epoch };
    if (address === pane) {
      foundId = id!;
      foundCommand = command ?? "";
      foundPid = pid!;
    }
  }
  if (!foundId) return { state: "designated_pane_missing", paneId: "", epoch };
  // The incumbent's record carries the expected identity too
  // (lib.sh:6929-6990): a live pane_id that differs from the bound one is
  // pane_recycled, and harness evidence is re-evaluated — observation
  // confirms, never mints (tap_harness_evidence, lib.sh:8366-8395).
  if (expected?.paneId && foundId !== expected.paneId) return { state: "pane_recycled", paneId: foundId, epoch };
  if (expected?.harness) {
    const shallow = manualRelayFamily(foundCommand, expected.agentFamilies);
    const processObs = expected.agentFamilies.has(shallow) || DENYLIST.includes(shallow)
      ? null
      : observeHarnessPid(expected.scriptsDir, expected.agentFamilies, foundPid, env);
    const evidence = evaluateHarnessEvidence(expected.harness, foundCommand, foundPid, expected.agentFamilies, processObs);
    if (evidence === "mismatch") return { state: "harness_mismatch", paneId: foundId, epoch };
    if (evidence === "exited") return { state: "harness_exited", paneId: foundId, epoch };
    if (evidence !== "alive") return { state: "harness_unobservable", paneId: foundId, epoch };
  }
  return { state: "match", paneId: foundId, epoch };
}

/**
 * `tap_registry_mark_suspended` (lib.sh:4386-4441): under the registry's own
 * lock the seat's row is marked suspended with the reason, and a pane_gone
 * mark stamps exited_at (UTC, once). Preconditions: the tmux server must be
 * reachable — "a dead socket is not a dead pane" — and the acting registry
 * must still be the index's authority; either failing leaves the row
 * untouched and the caller refuses. The caller holds the registry lock
 * (registryLocks) — this helper must not re-acquire it.
 */
function markSuspendedLocked(registryPath: string, handle: string, reason = "pane_gone"): boolean {
  if (!serverEpochNow()) return false;
  const authority = validateLockedRegistryAuthority(registryPath, dirname(dirname(registryPath)), process.env.TAP_INDEX_HOME);
  if (!authority.ok) return false;
  try {
    const doc = loadRegistry(registryPath);
    const row = seatMap(doc)[handle];
    if (!row || typeof row !== "object" || Array.isArray(row)) return false;
    const ent = row as Record<string, unknown>;
    ent.status = "suspended";
    ent.status_reason = reason;
    if (reason === "pane_gone" && !ent.exited_at) {
      ent.exited_at = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
    }
    // Bash's heredoc wrote `json.dump(reg, indent=2, sort_keys=True)` + a
    // trailing newline; the replacer sorts at every depth.
    const sorter = (key: string, value: unknown): unknown =>
      value !== null && typeof value === "object" && !Array.isArray(value)
        ? Object.fromEntries(Object.entries(value as Record<string, unknown>).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)))
        : value;
    atomicWrite(registryPath, `${JSON.stringify(doc, sorter, 2)}\n`);
  } catch {
    return false;
  }
  return true;
}

/**
 * The incumbent's unregistered_sender remedy (tap_unregistered_sender_next,
 * lib.sh:9558-9606): the detail names the pane's situation and the action is
 * pasteable. An empty bus with a live pane is the cwd diagnosis FIRST — both
 * identity answers are wrong there, and registering would split the seat's
 * identity across buses.
 */
function unregisteredSenderRefusal(from: string, seats: Record<string, Record<string, unknown>>, registryPath: string): TapError {
  const seen = callingPane();
  if (!seen || seen.status !== "ok") {
    return new TapError(1, "unregistered_sender", `tap register ${from} --delivery poll [--team <team>]`,
      `'${from}' is not an active sender on this team; pane-less daemons/scripts must register a stable poll seat, then pass --team on send when cwd is unanchored`);
  }
  const calling = seen.paneId;
  if (Object.keys(seats).length === 0 && !existsSync(registryPath)) {
    let team = "";
    try {
      const session = tmuxReadOnly(["display-message", "-p", "-t", calling, "#{session_name}"], process.env).stdout.trim();
      team = session.includes("/") ? session.slice(0, session.indexOf("/")) : "";
    } catch {
      team = "";
    }
    if (!team || team.includes("#")) team = "<team>";
    return new TapError(1, "unregistered_sender", `tap send <to> --from ${from} --team ${team}`,
      `no seats are registered on the bus this cwd resolves to, so this is almost certainly not the bus ${from} belongs to — every git worktree carries a .tap/ directory and is therefore an empty bus anchor. Pass --team <team> to name the bus, or run this from the team's worktree. Do NOT register here: it would bind this pane to the wrong bus while other seats keep writing to the right one`);
  }
  if (seats[from]) {
    return new TapError(1, "unregistered_sender", `tap in ${from}`,
      `'${from}' is not an active sender on this team and a registry row already holds that handle; naming the handle explicitly is what authorizes reclaiming it. If the registration reports it minted '${from}-2', the incumbent row is STILL holding the address other seats write to — 'tap in ${from} --force' reclaims it, and is only safe once you know the incumbent is not a live teammate. --delivery poll is for pane-less daemons and scripts: a poll seat with a pane receives nothing while reporting success`);
  }
  return new TapError(1, "unregistered_sender", `tap in ${from}`,
    `'${from}' is not an active sender on this team; this caller is in a live pane, so register from the pane itself. --delivery poll is for pane-less daemons and scripts, and a poll seat with a pane receives nothing while reporting success`);
}

/**
 * `tap_pane_harness_command` (lib.sh:8726): a shallow command that already
 * classifies as an agent or denylist family is trusted as-is; anything else
 * (a wrapper like `node`, a version string) is resolved through the pane's
 * process evidence, falling back to the shallow family when the observation
 * finds nothing.
 */
function relayHarnessFamily(
  command: string,
  panePid: string,
  agentFamilies: ReadonlySet<string>,
  scriptsDir: string,
  env: NodeJS.ProcessEnv = process.env,
): string {
  const shallow = manualRelayFamily(command, agentFamilies);
  if (agentFamilies.has(shallow) || DENYLIST.includes(shallow) || !panePid) return shallow;
  const obs = observeHarnessPid(scriptsDir, agentFamilies, panePid, env);
  return obs.state === "observed" && obs.family ? obs.family : shallow;
}

/**
 * The relay pane's harness family, the courier's private classification
 * repeated here rather than exported: the family name is what submit evidence
 * binds, and a shell pane classifies to itself, which the courier's denylist
 * check refuses.
 */
function manualRelayFamily(command: string, agentFamilies: ReadonlySet<string>): string {
  const name = (command.split("/").pop() ?? command).toLowerCase();
  for (const fam of agentFamilies) {
    if (name === fam || name.startsWith(`${fam}-`)) return fam;
  }
  return name;
}

/**
 * The current tmux server epoch, `tap_server_epoch_now` (lib.sh:8082);
 * `serverEpochFromRaw` honours TAP_SERVER_EPOCH the same way, and an
 * unobservable server answers "" — which disables the heal, as Bash's
 * `|| true` empty answer did.
 */
function serverEpochNow(env: NodeJS.ProcessEnv = process.env): string {
  try {
    return serverEpochFromRaw(tmuxReadOnly(["display-message", "-p", "#{pid}:#{start_time}"], env).stdout.trim(), env);
  } catch {
    return "";
  }
}

/**
 * The pane-drift heal's one row rewrite (send-reply-r2 checkpoint A, U2;
 * tap-send.sh:904-970), called under the acting registry's held lock. An
 * epoch-stale row is never resolved (a recycled pane id would write the wrong
 * address); the resolved address must differ from the stored shape; the
 * rewrite is best-effort and sorted-key, as the incumbent's Python heredoc
 * wrote. The caller is told the new address so the send continues with it.
 */
function healIdShapedPane(registryPath: string, handle: string, idPane: string, paneId: string, storedEpoch: string): string {
  const now = serverEpochNow();
  if (storedEpoch && now && storedEpoch !== now) {
    process.stderr.write(`tap send: refusing id-shaped pane heal for ${handle} — pane_id epoch-stale (stored ${storedEpoch} ≠ now ${now})\n`);
    return "";
  }
  let address = "";
  try {
    address = paneAddress(paneId).trim();
  } catch {
    address = "";
  }
  if (!address || !address.includes(":") || address === idPane) return "";
  try {
    const doc = loadRegistry(registryPath);
    const row = seatMap(doc)[handle];
    if (!row || typeof row !== "object" || Array.isArray(row)) return "";
    if ((row as Record<string, unknown>).pane === address) return "";
    // Review round 2 (important 4): the write is a membership mutation under
    // a held lock, so the locked path must still be the index's acting
    // authority before anything is written (validate_locked_registry_authority
    // in the incumbent's locked rewrite). An authority move leaves the stale
    // registry byte-identical.
    const authority = validateLockedRegistryAuthority(registryPath, dirname(dirname(registryPath)), process.env.TAP_INDEX_HOME);
    if (!authority.ok) {
      // Best-effort, as the incumbent: authority retry/refuse print NOTHING
      // and leave the id-shaped field for the identity checks
      // (tap-send.sh:960-965 — "do not treat as send failure").
      return "";
    }
    (row as Record<string, unknown>).pane = address;
    // Bash's heredoc wrote `json.dump(reg, indent=2, sort_keys=True)` + a
    // trailing newline; the replacer sorts at every depth.
    const sorter = (key: string, value: unknown): unknown =>
      value !== null && typeof value === "object" && !Array.isArray(value)
        ? Object.fromEntries(Object.entries(value as Record<string, unknown>).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)))
        : value;
    atomicWrite(registryPath, `${JSON.stringify(doc, sorter, 2)}\n`);
  } catch {
    return "";
  }
  process.stderr.write(`tap send: healed id-shaped pane field for ${handle} → ${address}\n`);
  return address;
}

/**
 * Direct send's submit-unverified moment, matching Bash tap-send.sh:
 * `tap_registry_event_append_or_warn "$FROM" send_submit_unverified "$TO" "$PANE" "id=$ID"`.
 * The warning is the whole failure report — rc 5 is already earned and does not
 * change either way.
 */
function appendSubmitUnverifiedEvent(
  busHome: string,
  team: string,
  from: string,
  to: string,
  pane: string,
  id: string,
): void {
  appendRegistryEventOrWarn("tap send", {
    log: registryEventsPath(busHome),
    actor: from, action: "send_submit_unverified", handle: to, pane, team,
    detail: `id=${id}`,
  });
}

export function resolveConfiguredDriver(family: string, env: NodeJS.ProcessEnv = process.env): { ok: true; driver: string } | { ok: false } {
  if (env.TAP_DRIVER_FORCE_TMUX === "1" || !family) return { ok: true, driver: "tmux" };
  const refuse = (detail: string): { ok: false } => {
    process.stderr.write("tap: " + detail + "\n");
    return { ok: false };
  };
  const path = driverConfigPath(env);
  if (!path) return refuse('XDG_CONFIG_HOME is relative or unusable ("' + (env.XDG_CONFIG_HOME ?? "") + '"); the launcher\'s contract is an absolute config home, and a cwd-relative one would let the working directory choose the delivery door. Refusing.');
  const unusable = () => refuse(path + " is unusable (insecure source, malformed TOML, or a non-string driver value); refusing rather than silently selecting tmux");
  try {
    try {
      if (lstatSync(path).isSymbolicLink() && !existsSync(path)) {
        return refuse(path + " is a dangling symlink; refusing rather than silently selecting tmux for a config that is present but unreadable");
      }
    }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return { ok: true, driver: "tmux" };
      throw error;
    }
    const doc = parseToml(new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(readSecureBytes(path).bytes));
    const isTable = (value: unknown): value is Record<string, unknown> => !!value && typeof value === "object" && !Array.isArray(value);
    const table = doc.harness, harness = isTable(table) ? table[family] : null;
    if (!isTable(harness) || !Object.hasOwn(harness, "driver")) return { ok: true, driver: "tmux" };
    const driver = harness.driver;
    if (typeof driver !== "string" || /[\x00-\x1f\x7f]/.test(driver)) return unusable();
    const key = '[harness.' + family + '] driver = "' + driver + '" in ' + path;
    if (driver === "") return refuse(key + " names no driver; remove the key to use tmux");
    if (!/^[a-z][a-z0-9_]*$/.test(driver)) return refuse(key + " is not a legal driver name");
    if (driver !== "tmux") return refuse(key + " names no WIRED driver; remove the driver key or set it to tmux");
    return { ok: true, driver };
  } catch { return unusable(); }
}
