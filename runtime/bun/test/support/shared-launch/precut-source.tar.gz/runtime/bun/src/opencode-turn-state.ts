// M6 U1: the opencode turn-state read's one native owner; lib.sh adapts to this.
import { statSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";

export type TurnState = "in-turn" | "idle" | "dirty-end" | "unknown" | "error";

export function opencodeTurnState(sessionId: string, env: NodeJS.ProcessEnv = process.env): TurnState {
  if (!sessionId) return "error";
  const db = env.OPENCODE_DB_PATH || join(env.HOME ?? "", ".local/share/opencode/opencode.db");
  try {
    if (!statSync(db).isFile()) return "error";
  } catch {
    return "error";
  }
  // The sqlite3 CLI takes no bind parameters; the session id enters the SQL only
  // as a hex blob literal, so no byte of it can break out of the CAST.
  const hex = Buffer.from(sessionId, "utf8").toString("hex");
  const sql = `SELECT json_extract(data, '$.finish'), json_extract(data, '$.time.completed')
FROM message
WHERE json_extract(data, '$.role') = 'assistant' AND json_extract(data, '$.sessionID') = CAST(x'${hex}' AS TEXT)
ORDER BY json_extract(data, '$.time.created') DESC
LIMIT 1;`;
  const r = spawnSync("sqlite3", ["-readonly", db, sql], { encoding: "utf8" });
  if (r.error || r.status !== 0) return "error";
  const row = r.stdout.replace(/\n+$/, "");
  if (!row) return "unknown";
  const [finish, completed] = row.split("|");
  if (completed === "") return "in-turn";
  if (finish === "stop") return "idle";
  if (finish === "") return "dirty-end";
  return "idle";
}

export function main(argv: string[], env: NodeJS.ProcessEnv = process.env): number {
  const state = opencodeTurnState(argv[0] ?? "", env);
  process.stdout.write(`${state}\n`);
  return state === "error" ? 1 : 0;
}

if (import.meta.main) {
  try {
    process.exit(main(process.argv.slice(2)));
  } catch (e) {
    console.error(e instanceof Error ? e.message : String(e));
    process.exit(1);
  }
}
