// out-retire.ts — the ordinary `tap out|unregister` retirement owner (R3,
// tap-68lp.2.1): plain, dash (`-`), and `--kill` forms in one place. The
// router's out|unregister dispatches here for every non-forwarding form, so
// no second registry writer exists on either door.
import { existsSync, mkdirSync, readdirSync, readFileSync, realpathSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { basename, dirname, join } from "node:path";
import { Bus } from "./bus";
import { TapError, observeCallingPane, resolveContext } from "./context";
import { envelopeField, validateEnvelope } from "./envelope";
import { appendRegistryEventOrWarn, registryEventsPath } from "./events";
import { atomicWrite } from "./fsatomic";
import { pyDumpIndent } from "./lossless-json";
import { validToken } from "./ids";
import { flipMarkerState } from "./index-home";
import { acquireRegistryLock, type RegistryLock } from "./panelock";
import { destructiveSessionTarget, isPaneId, type LifecycleTmux } from "./lifecycle-target";
import { mintInstanceId, resolveHandleByPane } from "./registry";
import { acquireResetMutationLock, markResetGenerationReused, resetFenceRefusal } from "./reset";
import { assertSelectionCurrent, SelectorError, type Selection } from "./selector";
import { pyReadUtf8 } from "./spool-publication";
import { AGENT_FAMILIES } from "./verbs/team";
import { isMap, loads, type JsonMap, type JsonValue } from "./watch-detect";
import { serverEpochFromRaw, tmux, tmuxReadOnly, type Run } from "./tmux";

type Ctx = ReturnType<typeof resolveContext>;
export interface PlainForm { name: string | null; pane: string; kill: boolean; dash: boolean }

const isFile = (p: string) => { try { return statSync(p).isFile(); } catch { return false; } };
const str = (v: JsonValue | undefined): string => (typeof v === "string" ? v : "");

// Test-only pause between acting-registry selection and the transaction window,
// so a test can move the enrollment out from under the in-flight selection.
function publicationBarrier(stage: string, env: NodeJS.ProcessEnv): void {
  const path = env.TAP_OUT_RETIRE_TEST_BARRIER;
  if (!path || !env.TAP_SCRATCH_ONLY || env.TAP_OUT_RETIRE_TEST_STAGE !== stage) return;
  writeFileSync(path + ".ready", stage);
  const deadline = Date.now() + 10000;
  while (!existsSync(path + ".continue") && Date.now() < deadline) Bun.sleepSync(10);
  if (!existsSync(path + ".continue")) throw new Error("out-retire scratch barrier timed out");
}

export function parseOutForm(argv: string[]): PlainForm {
  const f: PlainForm = { name: null, pane: "", kill: false, dash: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!;
    if (a === "--pane") { const v = argv[++i]; if (v === undefined) throw new TapError(1, "usage_error", "tap help unregister", "--pane needs a value", "tap"); f.pane = v; }
    else if (a === "--json") process.env.TAP_JSON = "1";
    else if (a === "--kill") f.kill = true;
    else if (a.startsWith("--")) throw new TapError(1, "unknown_option", "tap help unregister", `unknown option '${a}'`, "tap");
    else if (f.name === null) f.name = a;
    else throw new TapError(1, "usage_error", "tap help unregister", `unexpected arg '${a}'`, "tap");
  }
  f.dash = f.name === "-";
  return f;
}

/** Router-door entry: every `out|unregister` form except `--forward-to`. */
export function cmdOutRetire(argv: string[]): number {
  const form = parseOutForm(argv);
  if (form.dash && form.kill) {
    throw new TapError(1, "usage_error", "tap help unregister", "'-' is incompatible with --kill (a dead seat has no session to kill)", "tap");
  }
  try {
    if (form.dash && !dashSelect(form, process.env)) return 0;
    if (!form.kill) return retireLeaf(form, process.env);
    return killEntry(form, process.env);
  } catch (e) {
    if (e instanceof TapError) throw e;
    // A tagged ordinary Error (e.g. a Bus structural refusal) declares its own
    // class/action; nativeError renders it. Only genuinely unclassified
    // unexpected errors fall back to registry_invalid.
    if (e instanceof Error) {
      const tagged = e as Error & { tapErrorClass?: unknown; tapAction?: unknown };
      if (typeof tagged.tapErrorClass === "string" && tagged.tapErrorClass !== "") {
        throw new TapError(1, tagged.tapErrorClass,
          typeof tagged.tapAction === "string" ? tagged.tapAction : "", e.message, "tap");
      }
    }
    throw new TapError(1, "registry_invalid", "repair_registry", String(e), "tap");
  }
}

function fenceOrThrow(ctx: Ctx): void {
  const fence = resetFenceRefusal(ctx.bus.home, "tap unregister");
  if (fence) throw new TapError(1, "team_reset_fenced", fence.action, fence.detail, "tap");
}

function noRegistry(): boolean {
  process.stdout.write("tap unregister: no registry — nothing to remove\n");
  return false;
}

// --- dash selection (`tap out -`): the most recently exited teammate ---------
// Scans the caller's acting registry for dead-pane candidates (pane-backed,
// active, identity-then-address probe dead; plus suspended/pane_gone), stamps
// missing exited_at facts, and publishes the stamps even when refusing, exactly
// as the incumbent inline scan did under the same lock.

function paneAlive(target: string, env: NodeJS.ProcessEnv): boolean {
  if (!target) return false;
  // Read-only incumbent probe on the unthrottled door: a drained courier
  // token bucket must never masquerade as pane absence here.
  const r = tmuxReadOnly(["display-message", "-p", "-t", target, "#{pane_id}"], env);
  return r.code === 0 && r.stdout.trim() !== "";
}

function dashSelect(form: PlainForm, env: NodeJS.ProcessEnv): boolean {
  let ctx = resolveContext(process.cwd(), env);
  fenceOrThrow(ctx);
  ctx.bus.ensureDirs();
  if (!isFile(ctx.registryPath)) return noRegistry();
  const resetLock = acquireResetMutationLock(ctx.bus.home, "tap unregister");
  try {
    const lock = acquireRegistryLock(ctx.registryPath, Infinity);
    if (!lock) throw new TapError(1, "registry_lock_busy", "tap out -", "acting registry is busy; no retirement published", "tap unregister");
    try {
      lockedAuthorityOrInvalid(ctx, env, lock);
      let doc: JsonValue;
      try { doc = loads(pyReadUtf8(ctx.registryPath)); }
      catch (e) { throw new TapError(1, "registry_invalid", "repair_registry", `tap unregister: registry '${ctx.registryPath}' is invalid JSON (${(e as Error).message})`, "tap"); }
      if (!isMap(doc)) {
        // A valid non-object document is refused with its bytes preserved —
        // publishing an empty seat map over it would be data loss.
        throw new TapError(1, "registry_invalid", "repair_registry", `tap unregister: registry '${ctx.registryPath}' is invalid JSON; refusing to touch it (not an object)`, "tap");
      }
      const seats = docSeats(doc);
      const now = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
      const candidates: Array<[string, string]> = [];
      let liveCount = 0;
      for (const handle of [...seats.keys()].sort()) {
        const ent = seats.get(handle);
        if (!isMap(ent)) continue;
        const delivery = str(ent.get("delivery")) || "pane";
        if (delivery === "poll") continue;
        // Missing-vs-present: the default "active" applies only when the key
        // is absent; an explicit null/false/number/object must not become a
        // candidacy status.
        const status: JsonValue = ent.has("status") ? ent.get("status")! : "active";
        const reason = str(ent.get("status_reason"));
        if (status === "active") {
          let paneId = ent.get("pane_id");
          if (paneId !== undefined && paneId !== null && paneId !== "" && !(typeof paneId === "string" && isPaneId(paneId))) continue;
          paneId = typeof paneId === "string" ? paneId : "";
          const paneAddr = str(ent.get("pane"));
          if ((paneId && paneAlive(paneId, env)) || (paneAddr && paneAlive(paneAddr, env))) { liveCount++; continue; }
          if (!str(ent.get("exited_at"))) ent.set("exited_at", now);
          candidates.push([handle, str(ent.get("exited_at"))]);
        } else if (status === "suspended" && reason === "pane_gone") {
          if (!str(ent.get("exited_at"))) ent.set("exited_at", now);
          candidates.push([handle, str(ent.get("exited_at"))]);
        }
      }
      const docMap: JsonMap = isMap(doc) ? doc : new Map<string, JsonValue>();
      // Publish the stamps over the document AS FOUND: when it has no usable
      // seats/agents map, the reserialization must not invent one.
      const publish = () => {
        if (isMap(docMap.get(seatsKey(docMap)))) docMap.set(seatsKey(docMap), seats);
        atomicWrite(ctx.registryPath, `${pyDumpIndent(docMap, 0)}\n`);
      };
      if (candidates.length === 0) {
        publish();
        throw new TapError(1, "not_found", "tap unregister <name>", `no dead seats (${liveCount} active pane(s)) — name one explicitly`, "tap");
      }
      if (candidates.length === 1) {
        publish();
        form.name = candidates[0]![0]!;
        return true;
      }
      const stamped = candidates.filter(([, ea]) => ea);
      if (stamped.length === candidates.length) {
        const latest = stamped.reduce((a, b) => (b[1]! > a[1]! ? b : a));
        if (stamped.filter(([, ea]) => ea === latest[1]).length === 1) {
          publish();
          form.name = latest[0]!;
          return true;
        }
      }
      publish();
      throw new TapError(1, "not_found", "tap unregister <name>",
        `${candidates.length} dead seats — name one explicitly (candidates: ${candidates.map(([h]) => h).join(" ")})`, "tap");
    } finally { lock.release(); }
  } finally { resetLock.release(); }
}

// --- shared row facts and narration -----------------------------------------

interface RowFacts {
  present: boolean; eventPane: string; storedSession: string;
  delivery: string; paneId: string; crew: boolean; serverEpoch: string; team: string;
}

const EMPTY_FACTS: RowFacts = { present: false, eventPane: "", storedSession: "", delivery: "pane", paneId: "", crew: false, serverEpoch: "", team: "" };

function docSeats(doc: JsonValue): JsonMap {
  if (isMap(doc)) {
    if (isMap(doc.get("seats"))) return doc.get("seats") as JsonMap;
    if (isMap(doc.get("agents"))) return doc.get("agents") as JsonMap;
  }
  return new Map<string, JsonValue>();
}

function seatsKey(doc: JsonValue): "seats" | "agents" {
  return isMap(doc) && isMap(doc.get("seats")) ? "seats" : "agents";
}

function rowFacts(ctx: Ctx, name: string): RowFacts {
  try {
    const doc = loads(pyReadUtf8(ctx.registryPath));
    const seats = docSeats(doc);
    const row = seats.get(name);
    if (!isMap(row)) return { ...EMPTY_FACTS };
    return {
      present: true,
      eventPane: str(row.get("pane")),
      storedSession: str(row.get("session")),
      delivery: str(row.get("delivery")) || "pane",
      paneId: str(row.get("pane_id")),
      crew: row.get("crew") === true,
      serverEpoch: str(row.get("server_epoch")),
      team: teamNameOf(doc),
    };
  } catch { /* unreadable registry: every fact empty; the transaction re-reads and refuses. */ }
  return { ...EMPTY_FACTS };
}

function teamNameOf(doc: JsonValue): string {
  if (!isMap(doc)) return "";
  const team = doc.get("team");
  return isMap(team) ? str(team.get("name")) : "";
}

function serverEpochNow(env: NodeJS.ProcessEnv): string {
  const pin = env.TAP_SERVER_EPOCH;
  if (pin !== undefined) return pin;
  const r = tmux(["display-message", "-p", "#{pid}:#{start_time}"], env);
  if (r.code !== 0) return "";
  return serverEpochFromRaw(r.stdout.trim(), env);
}

// The narration ladder: which session receipt/warning facts may name. Poll
// seats have no tmux lifecycle; stale-epoch ids may not label anything; a
// stable stored pane id must still answer to itself before its session or
// window may be quoted; stored provenance outranks a mutable pane address.
function narrationLadder(facts: RowFacts, kill: boolean, env: NodeJS.ProcessEnv): { sessionName: string; windowId: string } {
  let sessionName = "", windowId = "";
  const epochNow = serverEpochNow(env);
  const stale = facts.serverEpoch !== "" && epochNow !== "" && epochNow !== facts.serverEpoch;
  if (facts.delivery !== "poll") {
    if (stale) sessionName = facts.storedSession;
    else if (facts.paneId) {
      if (tmux(["display-message", "-p", "-t", facts.paneId, "#{pane_id}"], env).stdout.trim() === facts.paneId) {
        sessionName = tmux(["display-message", "-p", "-t", facts.paneId, "#{session_name}"], env).stdout.split("\n")[0]?.trim() ?? "";
        windowId = tmux(["display-message", "-p", "-t", facts.paneId, "#{window_id}"], env).stdout.split("\n")[0]?.trim() ?? "";
      }
    } else if (facts.storedSession) sessionName = facts.storedSession;
    else if (facts.eventPane) sessionName = tmux(["display-message", "-p", "-t", facts.eventPane, "#{session_name}"], env).stdout.split("\n")[0]?.trim() ?? "";
    if (!facts.paneId || !kill) sessionName = sessionName || facts.storedSession;
  }
  return { sessionName, windowId };
}

// Tri-state pane observation (pane id, session, generation) from ONE record.
// Absence requires the server to have answered: rc 0 with an empty expansion,
// or a nonzero exit whose stderr says "can't find" — the error IS the answer.
// Every other failure is unverifiable and proves nothing.
function observePaneIdentity(target: string, env: NodeJS.ProcessEnv): { gone: true } | { unverifiable: true } | { paneId: string; session: string; epoch: string } {
  const r = tmux(["display-message", "-p", "-t", target, "#{pane_id}\t#{session_name}\t#{pid}:#{start_time}"], env);
  if (r.rateLimited) return { unverifiable: true };
  if (r.code !== 0) {
    if ((r.stderr ?? "").includes("can't find")) return { gone: true };
    return { unverifiable: true };
  }
  const record = r.stdout.endsWith("\n") ? r.stdout.slice(0, -1) : r.stdout;
  if (record.includes("\n")) return { unverifiable: true };
  const [id, session, raw] = record.split("\t");
  if (!id) return { gone: true };
  if (!isPaneId(id)) return { unverifiable: true };
  const epoch = serverEpochFromRaw(raw ?? "", env);
  if (!epoch) return { unverifiable: true };
  return { paneId: id, session: session ?? "", epoch };
}

// The registered-handle resolution for a nameless call, symmetric with
// register: pane identity first, session-name derivation as fallback.
function resolveRetireName(ctx: Ctx, form: PlainForm, env: NodeJS.ProcessEnv): { name: string; callerRefusal: string } {
  const name = form.name;
  if (name !== null && name !== "-") return { name, callerRefusal: "" };
  let pane = form.pane;
  let callerRefusal = "";
  if (!pane) {
    const obs = observeCallingPane(env);
    if (obs.state === "inside") pane = obs.paneId;
    else callerRefusal = obs.state === "unobservable" ? obs.refusal : obs.detail;
  }
  let resolved: string | null = null;
  let sess = "";
  if (pane) {
    const rec = observePaneIdentity(pane, env);
    if ("unverifiable" in rec) {
      throw new TapError(1, "generation_unverifiable", "wait for tmux to answer and retry, or name the exact handle: tap out <handle>",
        "refusing session-name fallback because the tmux server generation is unavailable and the caller pane's registered identity cannot be verified", "tap");
    }
    if ("paneId" in rec) {
      sess = rec.session;
      resolved = resolveHandleByPane(ctx.registryPath, rec.paneId, pane, rec.epoch,
        env.TAP_CALLER_SELECTED_HANDLE || undefined, env.TAP_CALLER_SELECTED_INSTANCE || undefined)?.handle ?? null;
    }
    if (resolved === null && !sess) sess = tmux(["display-message", "-p", "-t", pane, "#{session_name}"], env).stdout.split("\n")[0]?.trim() ?? "";
  }
  let handle = resolved;
  if (handle === null) {
    handle = deriveHandle(sess, basename(gitRoot(env)));
    if (!handle) {
      let detail = "usage: tap unregister [<name>] [--pane <tmux-target>] [--kill]  (could not derive a handle from the tmux session name; pass one explicitly)";
      if (callerRefusal) detail += ` (caller pane observation: ${callerRefusal})`;
      throw new TapError(1, "usage_error", "tap help unregister", detail, "tap");
    }
  }
  return { name: handle, callerRefusal };
}

function deriveHandle(session: string, team: string): string {
  if (!session) return "";
  let s = session, idx = "";
  if (team && s.startsWith(`${team}/`)) {
    // The qualified form returns the validated remainder VERBATIM — no
    // suffix or harness stripping (the incumbent's early return).
    const rest = s.slice(team.length + 1);
    if (!rest.includes("/") && !/^\d+$/.test(rest) && validToken(rest)) return rest;
    return "";
  }
  // Unqualified team prefixes strip the actual team argument, not a literal.
  if (team) {
    if (s.startsWith(`${team}-`)) s = s.slice(team.length + 1);
    else if (s.startsWith(`${team}_`)) s = s.slice(team.length + 1);
  }
  const m = s.match(/^(.+)[-_]([0-9]+)$/);
  if (m) { s = m[1]!; if (Number(m[2]) >= 2) idx = m[2]!; }
  const dash = s.indexOf("-");
  if (dash > 0 && AGENT_FAMILIES.has(s.slice(0, dash)) && s.slice(dash + 1)) s = s.slice(dash + 1);
  if (/^\d+$/.test(s)) return "";
  if (idx) s = `${s}-${idx}`;
  return validToken(s) ? s : "";
}

function gitRoot(env: NodeJS.ProcessEnv): string {
  try { const r = Bun.spawnSync(["git", "rev-parse", "--show-toplevel"], { stdout: "pipe", stderr: "pipe", env }); if (r.exitCode === 0) return r.stdout.toString().trim(); } catch { /* fall through */ }
  return process.cwd();
}

function crewScan(bus: Bus, name: string, team: string): { blockers: string[]; queued: Array<[string, string]> } {
  const blockers: string[] = [], queued: Array<[string, string]> = [];
  for (const dir of [bus.payloadsDir, join(bus.home, "spool")]) {
    let names: string[] = [];
    try { names = readdirSync(dir).sort(); } catch { continue; }
    for (const fn of names) {
      if (fn.startsWith("_") || !fn.endsWith(".md")) continue;
      const id = fn.slice(0, -3);
      if (bus.isDone(id)) continue;
      let text: string;
      try { text = readFileSync(join(dir, fn), "utf8"); } catch { continue; }
      if (!validateEnvelope(text).ok) continue;
      const idF = envelopeField(text, "id") ?? "";
      if (idF !== id) continue;
      const from = envelopeField(text, "from") ?? "", to = envelopeField(text, "to") ?? "";
      const reply = envelopeField(text, "reply") || "expected";
      const toTeam = envelopeField(text, "to_team") ?? "";
      if (from === name) blockers.push(`  outbound ${from} id=${id}; next: tap outstanding ${name}`);
      else if (to === name && (toTeam === "" || toTeam === team)) {
        if (dir === bus.payloadsDir) blockers.push(`  inbound ${from} id=${id}; next: ${reply === "settle-only" ? `tap read ${id}` : `tap reply ${id} -m "..."`}`);
        else queued.push([id, from]);
      }
    }
  }
  return { blockers, queued };
}

function cloneJson(v: JsonValue): JsonValue {
  if (isMap(v)) return new Map([...v].map(([k, x]) => [k, cloneJson(x)]));
  if (Array.isArray(v)) return v.map(cloneJson);
  return v;
}

// In-lock acting-authority validation for the paths whose incumbent mapped a
// validation failure to registry_invalid (dash scan, kill transaction).
function lockedAuthorityOrInvalid(ctx: Ctx, env: NodeJS.ProcessEnv, lock: RegistryLock): void {
  if (!ctx.selection) return;
  try { assertSelectionCurrent(ctx.selection, lock, env.TAP_INDEX_HOME); }
  catch (e) {
    if (e instanceof SelectorError) {
      throw new TapError(1, "registry_invalid", "repair_registry",
        e.errorClass === "invalid_flip" ? e.detail : "unregister registry update failed", "tap unregister");
    }
    throw e;
  }
}

// --- plain retirement (explicit name, nameless, dash-selected) ---------------

function retireLeaf(form: PlainForm, env: NodeJS.ProcessEnv): number {
  let ctx = resolveContext(process.cwd(), env);
  publicationBarrier("after-select", env);
  const { name } = resolveRetireName(ctx, form, env);
  fenceOrThrow(ctx);
  ctx.bus.ensureDirs();
  if (!isFile(ctx.registryPath)) { noRegistry(); return 0; }

  // Row facts (pre-transaction narration + crew scan) from one preserving read.
  const facts = rowFacts(ctx, name);
  const narr = narrationLadder(facts, form.kill, env);
  let queuedInbound: Array<[string, string]> = [];

  if (!form.kill && facts.present && facts.crew) {
    const { blockers, queued } = crewScan(ctx.bus, name, ctx.team);
    if (blockers.length > 0) {
      process.stderr.write(`tap unregister: crew '${name}' has unresolved local obligations:\n${blockers.join("\n")}\n`);
      throw new TapError(1, "lifecycle_refused", `settle the listed obligations, then tap out ${name}`, `crew member '${name}' still has unresolved local transport obligations`, "tap");
    }
    queuedInbound = queued;
  }

  // Transaction: reset custody outside the registry lock; re-prove the selected
  // authority under it; ≤2 attempts with one rebind.
  let removed = false;
  for (let attempt = 1; attempt <= 2; attempt++) {
    let rebind = false;
    const resetLock = acquireResetMutationLock(ctx.bus.home, "tap unregister");
    try {
      const lock = acquireRegistryLock(ctx.registryPath, Infinity);
      if (!lock) throw new TapError(1, "registry_lock_busy", `tap out ${name}`, "acting registry is busy; no retirement published", "tap unregister");
      try {
        if (ctx.selection) {
          // Incumbent parity: an EXPLICIT bare-name retirement samples the
          // flip marker fresh under this lock and skips selector validation
          // only while the authority is absent at BOTH observations — the
          // selection was resolved pre-flip AND the marker is still absent
          // under this lock. Anything else revalidates: --kill keeps the
          // selector path (killEntry's absent/poll fallthrough), a dash
          // selection keeps it (form.name was just replaced by the scan, so
          // it is not an explicit name), a live-at-selection authority keeps
          // it (the live-to-absent team_moved fence), and a live or invalid
          // fresh marker keeps the full validation/rebind/refusal ladder.
          const plainBareName = !form.kill && !form.dash && form.name !== null && form.name !== "-";
          if (plainBareName && ctx.selection.marker === "absent" && flipMarkerState(env.TAP_INDEX_HOME) === "absent") {
            // no selection to revalidate: proceed with the resolved authority
          } else {
            try { assertSelectionCurrent(ctx.selection, lock, env.TAP_INDEX_HOME); }
            catch (e) {
              if (e instanceof SelectorError && e.errorClass === "invalid_flip") throw new TapError(1, "invalid_flip", "tap doctor", e.detail, "tap");
              if (e instanceof SelectorError && attempt < 2) rebind = true;
              else if (e instanceof SelectorError) throw new TapError(1, "flip_in_progress", `tap out ${name}`, e.detail, "tap");
              else throw e;
            }
          }
        }
        if (!rebind) {
          removed = retireRow(ctx, env, name);
          if (removed) postCommit(ctx, form, name, facts.eventPane, facts.crew, narr.windowId, narr.sessionName, queuedInbound);
          return 0;
        }
      } finally { lock.release(); }
    } finally { resetLock.release(); }
    ctx = resolveContext(process.cwd(), env);
  }
  return 0;
}

// Final tombstone row under team-history/. Mutates `row` to carry an instance
// id (the same mint-on-first-retirement the incumbent performed in-lock).
function writeTombstoneRow(ctx: Ctx, name: string, row: JsonMap): string {
  let instance = str(row.get("instance"));
  if (!instance) { instance = mintInstanceId(name); row.set("instance", instance); }
  const retiredBy = `out-${Buffer.from(crypto.getRandomValues(new Uint8Array(6))).toString("hex")}`;
  const now = new Date();
  const ts = now.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const tombPath = join(ctx.root, ".tap", "team-history", `${name}.${retiredBy.replace(/\//g, "_").replace(/ /g, "_")}.${ts}.json`);
  const payload: JsonMap = new Map<string, JsonValue>([["handle", name], ["instance", instance], ["retired_by", retiredBy],
    ["retired_at", now.toISOString().replace(/\.\d{3}Z$/, "Z")], ["row", row]]);
  mkdirSync(dirname(tombPath), { recursive: true });
  atomicWrite(tombPath, `${pyDumpIndent(payload, 0)}\n`);
  return tombPath;
}

function retireRow(ctx: Ctx, env: NodeJS.ProcessEnv, name: string): boolean {
  let text: string;
  try { text = pyReadUtf8(ctx.registryPath); } catch (e) { throw new TapError(1, "registry_invalid", "repair_registry", String(e), "tap"); }
  let doc: JsonValue;
  try { doc = loads(text); } catch (e) { throw new TapError(1, "registry_invalid", "repair_registry", `tap unregister: registry '${ctx.registryPath}' is invalid JSON; refusing to touch it (${(e as Error).message})`, "tap"); }
  if (!isMap(doc)) throw new TapError(1, "registry_invalid", "repair_registry", `tap unregister: registry '${ctx.registryPath}' is invalid JSON; refusing to touch it (not an object)`, "tap");
  const key = seatsKey(doc);
  const agents = docSeats(doc);
  const existing = agents.get(name);
  if (existing === undefined) { process.stdout.write(`tap unregister: '${name}' is not registered — nothing to remove\n`); return false; }
  let tombPath = "";
  // An existing NON-object row is deleted without history: the tombstone
  // requires the row's fields, and the incumbent discarded such rows bare.
  if (isMap(existing) && flipMarkerState(env.TAP_INDEX_HOME) === "live") {
    tombPath = writeTombstoneRow(ctx, name, existing);
  }
  try {
    agents.delete(name);
    doc.set(key, agents);
    if (env.TAP_TEST_UNREGISTER_SAVE_FAIL === "1") throw new Error("TAP_TEST_UNREGISTER_SAVE_FAIL");
    atomicWrite(ctx.registryPath, `${pyDumpIndent(doc, 0)}\n`);
  } catch (e) {
    if (tombPath) {
      try { if (env.TAP_TEST_UNREGISTER_UNLINK_FAIL === "1") throw new Error("TAP_TEST_UNREGISTER_UNLINK_FAIL"); unlinkSync(tombPath); }
      catch (ce) { process.stderr.write(`tap unregister: retirement failed; prepared history remains at ${tombPath}: ${(ce as Error).message}\n`); }
    }
    throw e;
  }
  process.stdout.write(`tap unregister: '${name}' removed from the registry\n`);
  return true;
}

function postCommit(ctx: Ctx, form: PlainForm, name: string, eventPane: string, crew: boolean, windowId: string, sessionName: string, queued: Array<[string, string]>): void {
  markResetGenerationReused(ctx.bus.home, "unregister");
  appendRegistryEventOrWarn("tap", { log: registryEventsPath(ctx.bus.home), actor: name, action: "unregistered", handle: name, pane: eventPane, team: ctx.team, detail: "" });
  if (form.dash) process.stdout.write(`tap unregister: '-' removed '${name}' (most recently exited)\n`);
  for (const [id, from] of queued) {
    process.stdout.write(`tap unregister: queued inbound spool '${id}' from '${from}' remains sender-owned\n`);
    process.stdout.write(`tap unregister: sender next: tap cancel ${id} --by ${from}\n`);
  }
  if (form.kill) return;
  if (crew && windowId && tmux(["display-message", "-p", "-t", windowId, "#{window_id}"], process.env).stdout.trim() === windowId) {
    process.stdout.write(`tap unregister: crew window '${windowId}' is still running\n`);
    process.stdout.write(`tap unregister: next: tmux kill-window -t '${windowId}'\n`);
  } else if (!crew && sessionName && tmux(["has-session", "-t", `=${sessionName}`], process.env).code === 0) {
    process.stdout.write(`tap unregister: tmux session '${sessionName}' is still running; conversation stays resumable\n`);
    process.stdout.write(`tap unregister: next: tmux kill-session -t '=${sessionName}'\n`);
  }
}

// --- `--kill` retirement ------------------------------------------------------

// The one adapter the destructive verifier needs over LIVE probes, matching
// the incumbent's per-question tmux queries (has-session / pane identity /
// session membership) so fixture mocks that implement those shapes keep
// working. A failed probe is absence of evidence, never evidence of absence.
function liveDestructiveView(env: NodeJS.ProcessEnv): LifecycleTmux {
  return {
    hasSession: name => tmux(["has-session", "-t", `=${name}`], env).code === 0,
    paneSession: id => {
      const r = tmux(["display-message", "-p", "-t", id, "#{pane_id}"], env);
      if (r.code !== 0 || r.stdout.trim() !== id) return null;
      const s = tmux(["display-message", "-p", "-t", id, "#{session_name}"], env);
      return s.code === 0 ? s.stdout.trim() : null;
    },
    sessionPaneIds: name => {
      const r = tmux(["list-panes", "-t", `=${name}`, "-F", "#{pane_id}"], env);
      return r.code === 0 ? r.stdout.split("\n").map(s => s.trim()).filter(Boolean) : [];
    },
  };
}

function tmuxValue(target: string, fmt: string, env: NodeJS.ProcessEnv): string {
  const r = tmux(["display-message", "-p", "-t", target, fmt], env);
  return r.code === 0 ? r.stdout.trim() : "";
}

// tap-2o38: TAP_SCRATCH_ONLY must cover --kill — a destructive session-
// terminating verb whose conversation is lost, NOT re-derivable state.
// `label` names the verb in the refusal's verbLabel slot; callers whose Bash
// twin set TAP_VERB (crew remove) pass their own.
export function scratchOnlyGuard(env: NodeJS.ProcessEnv, what: string, root: string, label = "tap unregister"): void {
  const declared = env.TAP_SCRATCH_ONLY;
  if (!declared) return;
  const canon = (p: string): string => {
    let r = p;
    try { r = realpathSync(p); } catch { /* keep the literal */ }
    return r.replace(/\/+$/, "") || "/";
  };
  const d = canon(declared);
  const r = canon(root);
  if (r === d || d === "/" || r.startsWith(`${d}/`)) return;
  throw new TapError(1, "scratch_only_refused", "unset TAP_SCRATCH_ONLY, or point it at the state root you actually meant to clear",
    `TAP_SCRATCH_ONLY declares '${d}' but ${what} resolved to '${r}' — refusing to clear state outside the declared scratch prefix`, label);
}

function killEntry(form: PlainForm, env: NodeJS.ProcessEnv): number {
  const ctx = resolveContext(process.cwd(), env);
  const { name } = resolveRetireName(ctx, form, env);
  fenceOrThrow(ctx);
  ctx.bus.ensureDirs();
  if (!isFile(ctx.registryPath)) { noRegistry(); return 0; }

  const facts = rowFacts(ctx, name);
  const epochNow = serverEpochNow(env);
  const proven = facts.serverEpoch !== "" && epochNow !== "" && epochNow === facts.serverEpoch;
  const narr = narrationLadder(facts, true, env);

  // Crew dismissal is refused outright: --kill is session-scoped and a crew
  // member shares its driver's session. Ordered BEFORE the kill-target
  // derivation on purpose — demanding identity proof for a categorically
  // refused action would only replace a precise message with a vague one.
  if (facts.present && facts.crew) {
    if (!narr.windowId) {
      throw new TapError(1, "pane_identity_gone", "repair_registration", `registered crew window for ${name} is gone; refusing to kill`, "tap unregister");
    }
    throw new TapError(1, "lifecycle_refused", `tmux kill-window -t '${narr.windowId}'`, `crew member '${name}' shares its driver's tmux session; --kill is session-scoped and refused`, "tap unregister");
  }

  // The --kill TARGET derives through the ONE verifier, decided here and
  // independently of the narration ladder above — which stays a fail-OPEN
  // reader, because DETECTION is safest seeing more while AUTHORIZATION is
  // safest permitting less. ONE observation decides the arm label: the epoch
  // observed once above is the same fact `proven` labels, so label and arm
  // agree by construction.
  let killTarget = "";
  let authority = "";
  if (facts.present && facts.delivery !== "poll") {
    const expected = facts.team ? `${facts.team}/${name}` : "";
    const decision = destructiveSessionTarget({ pane_id: facts.paneId, session: facts.storedSession }, expected, liveDestructiveView(env));
    if (decision.ok) {
      killTarget = decision.session;
      authority = proven ? "id" : "name";
    } else {
      const unproven = `registered pane identity ${facts.paneId} cannot be proven to belong to the current tmux server and no live session named '${facts.team || "?"}/${name}' vouches for the seat; run tap admin rebuild-registry to stamp live rows, then retry; refusing to kill`;
      const detail = decision.reason === "pane_identity_missing" ? `registered pane identity for ${name} is missing; refusing to kill`
        : decision.reason === "pane_live_elsewhere" ? `registered pane identity ${facts.paneId} is live in another session; refusing to kill`
        : decision.reason === "session_name_gone" ? `registered session '${facts.storedSession}' for ${name} is no longer live; refusing to kill`
        : unproven;
      throw new TapError(1, "pane_identity_gone", "repair_registration", detail, "tap unregister");
    }
  }
  // The verified target overrides narration: what --kill acts on is what the
  // verifier authorized, never what the reader happened to observe.
  if (killTarget) narr.sessionName = killTarget;

  scratchOnlyGuard(env, "a registry tap out --kill would stop a session on", ctx.bus.home);

  if (facts.delivery !== "poll" && facts.paneId) {
    if (!authority) {
      throw new TapError(1, "kill_authority_missing", `tap out ${name}`,
        `the registry disagreed with itself about whether '${name}' is registered while the stop was being authorized; nothing was changed`, "tap unregister");
    }
    const killed = killTransaction(ctx, env, name, facts.paneId, narr.sessionName, epochNow, authority);
    process.stdout.write(`tap unregister: '${name}' removed from the registry\n`);
    markResetGenerationReused(ctx.bus.home, "unregister");
    appendRegistryEventOrWarn("tap", { log: registryEventsPath(ctx.bus.home), actor: name, action: "unregistered", handle: name, pane: facts.eventPane, team: ctx.team, detail: "" });
    if (killed === 1) process.stdout.write(`tap unregister: stopped tmux session '${narr.sessionName}'\n`);
    return 0;
  }
  // The kill transaction did not retire this seat (absent handle or poll
  // fallthrough): the ordinary leaf owns it; its still-running tail is
  // suppressed because --kill owns that tail on this path.
  return retireLeaf(form, env);
}

function failIdentity(detail: string): never {
  throw new TapError(1, "pane_identity_gone", "repair_registration", detail, "tap unregister");
}

// Sibling rows may be demoted only through proven identity; a dead sibling
// identity falls through to stored provenance and never names the kill target.
function registrySessionOf(sib: JsonMap, nowEpoch: string, env: NodeJS.ProcessEnv): string | null {
  const paneId = sib.get("pane_id");
  const rowEpoch = str(sib.get("server_epoch"));
  const epochProven = Boolean(rowEpoch && nowEpoch && rowEpoch === nowEpoch);
  if (typeof paneId === "string" && paneId && epochProven) {
    if (tmuxValue(paneId, "#{pane_id}", env) === paneId) {
      const liveSession = tmuxValue(paneId, "#{session_name}", env);
      if (liveSession) return liveSession;
    }
  }
  const session = sib.get("session");
  if (typeof session === "string" && session) return session;
  const pane = sib.get("pane");
  if (typeof pane === "string" && pane.includes(":")) return pane.slice(0, pane.lastIndexOf(":"));
  return null;
}

// Minimal bash-%q-style quoting so metacharacters cannot reshape the remedy
// command aimed at a retained tombstone path.
function shellQuote(p: string): string {
  return /^[A-Za-z0-9_./:@+=,-]+$/.test(p) ? p : `'${p.replaceAll("'", `'\\''`)}'`;
}

function killTransaction(ctx: Ctx, env: NodeJS.ProcessEnv, name: string, expectedPaneId: string, expectedSession: string, authorizedEpoch: string, authority: string): 0 | 1 {
  let saveCalls = 0;
  const save = (payload: JsonValue): void => {
    saveCalls++;
    // TEST-ONLY fault injection. Must never be set in a live pane.
    if (env.TAP_TEST_UNREGISTER_SAVE_FAIL === "1") throw new Error("TAP_TEST_UNREGISTER_SAVE_FAIL");
    // Second save is the kill-fail rollback restore of `original`.
    if (env.TAP_TEST_UNREGISTER_RESTORE_FAIL === "1" && saveCalls >= 2) throw new Error("TAP_TEST_UNREGISTER_RESTORE_FAIL");
    atomicWrite(ctx.registryPath, `${pyDumpIndent(payload, 0)}\n`);
  };
  const resetLock = acquireResetMutationLock(ctx.bus.home, "tap unregister");
  try {
    const lock = acquireRegistryLock(ctx.registryPath, Infinity);
    if (!lock) throw new TapError(1, "registry_lock_busy", `tap out ${name}`, "acting registry is busy; no retirement published", "tap unregister");
    let tombPath = "";
    try {
      lockedAuthorityOrInvalid(ctx, env, lock);
      let doc: JsonValue;
      try { doc = loads(pyReadUtf8(ctx.registryPath)); }
      catch (e) { throw new TapError(1, "registry_invalid", "repair_registry", `tap unregister: registry '${ctx.registryPath}' is invalid JSON; refusing to touch it (${(e as Error).message})`, "tap unregister"); }
      if (!isMap(doc)) throw new TapError(1, "registry_invalid", "repair_registry", `tap unregister: registry '${ctx.registryPath}' is invalid JSON; refusing to touch it (not an object)`, "tap unregister");
      const key = seatsKey(doc);
      const agents = docSeats(doc);
      const entry = agents.get(name);
      if (!isMap(entry) || str(entry.get("pane_id")) !== expectedPaneId) {
        failIdentity(`registered pane identity for ${name} changed before kill; refusing to kill`);
      }
      // The epoch is observed HERE, inside the critical section, before
      // anything is dereferenced or destroyed. It is ONE of three generations
      // that must agree under id authority; the current one is re-observed
      // rather than assumed.
      const nowEpoch = serverEpochNow(env);
      if (authority === "id") {
        const rowEpoch = str(entry!.get("server_epoch"));
        if (!(rowEpoch && authorizedEpoch && nowEpoch && rowEpoch === authorizedEpoch && rowEpoch === nowEpoch)) {
          failIdentity(`registered pane identity ${expectedPaneId} is no longer proven against the current tmux server; refusing to kill`);
        }
        if (tmuxValue(expectedPaneId, "#{pane_id}", env) !== expectedPaneId || tmuxValue(expectedPaneId, "#{session_name}", env) !== expectedSession) {
          failIdentity(`registered pane identity ${expectedPaneId} changed before kill; refusing to kill`);
        }
      } else if (authority === "name") {
        if (str(entry!.get("session")) !== expectedSession) {
          failIdentity(`registered session provenance for ${name} changed before kill; refusing to kill`);
        }
        if (tmux(["has-session", "-t", `=${expectedSession}`], env).code !== 0) {
          failIdentity(`session ${expectedSession} for ${name} is no longer live; refusing to kill`);
        }
      } else {
        failIdentity(`kill authority for ${name} is unknown (${JSON.stringify(authority)}); refusing to kill`);
      }

      const original = cloneJson(doc);
      // Flip-live finding #7: publish the tombstone BEFORE kill-session.
      // Publish-after cannot run when --kill targets the caller session —
      // kill-session terminates this process before the rename lands.
      if (flipMarkerState(env.TAP_INDEX_HOME) === "live") {
        tombPath = writeTombstoneRow(ctx, name, entry!);
      }
      // Attempt unlink DIRECTLY; FileNotFoundError = already clean. Every
      // other OSError is a retained path.
      const unlinkTombstone = (): string | null => {
        if (!tombPath) return null;
        if (env.TAP_TEST_UNREGISTER_UNLINK_FAIL === "1") return "TAP_TEST_UNREGISTER_UNLINK_FAIL";
        try { unlinkSync(tombPath); } catch (e) {
          if ((e as NodeJS.ErrnoException)?.code === "ENOENT") return null;
          return String(e);
        }
        return null;
      };
      const rollbackKill = (): never => {
        let restoreErr: Error | null = null;
        try { save(original); } catch (e) { restoreErr = e as Error; }
        const unlinkErr = unlinkTombstone();
        if (restoreErr !== null) {
          if (unlinkErr !== null && tombPath) {
            throw new TapError(1, "registry_restore_failed", `rm -f ${shellQuote(tombPath)}; repair registry row for ${name}; then tap out ${name} --kill`,
              `tmux could not stop live session ${expectedSession}; registry restore failed and history remains at ${tombPath} (restore: ${restoreErr.message}; unlink: ${unlinkErr})`, "tap unregister");
          }
          throw new TapError(1, "registry_restore_failed", `repair registry row for ${name}; then tap out ${name} --kill`,
            `tmux could not stop live session ${expectedSession}; registry restore failed after history cleanup (${restoreErr.message})`, "tap unregister");
        }
        if (unlinkErr !== null && tombPath) {
          throw new TapError(1, "session_kill_failed", `rm -f ${shellQuote(tombPath)} && tap out ${name} --kill`,
            `tmux could not stop live session ${expectedSession}; registry restored but history remains at ${tombPath} (${unlinkErr})`, "tap unregister");
        }
        throw new TapError(1, "session_kill_failed", `tap out ${name} --kill`,
          `tmux could not stop live session ${expectedSession}; registry preserved`, "tap unregister");
      };

      agents.delete(name);
      for (const [, sibling] of agents) {
        if (!isMap(sibling)) continue;
        const delivery = str(sibling.get("delivery")) || "pane";
        // Same missing-vs-present rule as the dash scan: an explicit
        // non-string status never matches active/pending.
        const status: JsonValue = sibling.has("status") ? sibling.get("status")! : "active";
        if (delivery === "poll" || !(status === "active" || status === "pending")) continue;
        if (registrySessionOf(sibling, nowEpoch, env) === expectedSession) {
          sibling.set("status", "suspended");
          sibling.set("status_reason", "session_stopped");
        }
      }
      doc.set(key, agents);
      try {
        save(doc);
      } catch (e) {
        // Original registry file untouched (save is replace-atomic). Drop the
        // already-final tombstone so we never return row + retirement together.
        const unlinkErr = unlinkTombstone();
        if (unlinkErr !== null && tombPath) {
          throw new TapError(1, "history_cleanup_failed", `rm -f ${shellQuote(tombPath)} && tap out ${name} --kill`,
            `tap unregister: registry save failed after history publish; history remains at ${tombPath} (${(e as Error).message}; unlink: ${unlinkErr})`, "tap unregister");
        }
        throw new TapError(1, "registry_save_failed", `tap out ${name} --kill`,
          `tap unregister: registry save failed after history publish; history rolled back (${(e as Error).message})`, "tap unregister");
      }

      try {
        const killed = tmux(["kill-session", "-t", `=${expectedSession}`], env);
        // The classified refusal from rollbackKill must escape uncaught: this
        // is the ONE rollback owner and the ONE attempt, so the kill-outcome
        // handling sits outside the invocation catch.
        if (killed.code !== 0) {
          const stillLive = tmux(["has-session", "-t", `=${expectedSession}`], env).code === 0;
          if (stillLive) rollbackKill();
          // Session already gone — tombstone already published before the kill.
          return 0;
        }
        return 1;
      } catch (e) {
        if (e instanceof TapError) throw e;
        rollbackKill();
        throw new Error("unreachable: rollbackKill returned");
      }
    } finally {
      lock.release();
    }
  } finally { resetLock.release(); }
}
