/** Last reported request input, never cumulative usage or inferred model capacity. */
import { closeSync, constants, fstatSync, openSync, readSync } from "node:fs";
import { isAbsolute } from "node:path";

export interface TokenSample {
  input_tokens: number | null;
  observed_at: string | null;
  source: "codex_transcript" | "claude_transcript" | null;
  window_tokens: number | null;
  window_source: "codex_reported_window" | "claude_process_env" | "default_1m" | null;
  used_percent: number | null;
  percent_source: "footer" | "codex_reported_window" | "claude_process_env" | "default_1m" | null;
  unknown_reason: string | null;
}
const unknown = (reason: string): TokenSample => ({ input_tokens: null, observed_at: null, source: null,
  window_tokens: null, window_source: null, used_percent: null, percent_source: null, unknown_reason: reason });
const integer = (n: unknown): n is number => typeof n === "number" && Number.isSafeInteger(n) && n >= 0;
const timestamp = (n: unknown): string | null => typeof n === "string" && Number.isFinite(Date.parse(n)) ? n : null;
const obj = (n: unknown): Record<string, any> => n !== null && typeof n === "object" && !Array.isArray(n) ? n as Record<string, any> : {};
const lines = (text: string): Record<string, any>[] => text.split("\n").flatMap(line => {
  try { return [obj(JSON.parse(line))]; } catch { return []; }
});
const TAIL_BYTES = 2 * 1024 * 1024;

export function readContextTokens(harness: string, sessionId: string, path: string): TokenSample {
  if (!/^(codex|claude)(?:-|$)/.test(harness)) return unknown("unsupported_harness");
  if (!sessionId || !isAbsolute(path)) return unknown("unbound_transcript");
  let fd: number | undefined;
  try {
    fd = openSync(path, constants.O_RDONLY | constants.O_NONBLOCK);
    const stat = fstatSync(fd);
    if (!stat.isFile()) return unknown("unreadable_transcript");
    const read = (start: number, size: number) => {
      const bytes = Buffer.alloc(size);
      return bytes.subarray(0, readSync(fd!, bytes, 0, size, start)).toString("utf8");
    };
    const codex = harness.startsWith("codex");
    if (codex) {
      const meta = lines(read(0, Math.min(stat.size, 65536))).find(e => e.type === "session_meta");
      if (meta?.payload?.id !== sessionId) return unknown("session_mismatch");
    }
    const start = Math.max(0, stat.size - TAIL_BYTES);
    let tail = read(start, Math.min(stat.size, TAIL_BYTES));
    if (start) tail = tail.slice(tail.indexOf("\n") + 1);
    // Ignore an incomplete final JSONL record while the harness is appending.
    tail = tail.slice(0, tail.lastIndexOf("\n") + 1);
    for (const event of lines(tail).reverse()) {
      if (!codex && (event.sessionId !== sessionId || event.isSidechain === true)) continue;
      if (event.type === "compacted" || (event.type === "system" && event.subtype === "compact_boundary") ||
          (event.type === "event_msg" && event.payload?.type === "context_compacted")) return unknown("awaiting_usage_after_compact");
      let count: unknown, window: unknown = null;
      if (codex) {
        if (event.type !== "event_msg" || event.payload?.type !== "token_count") continue;
        const info = obj(event.payload.info);
        count = obj(info.last_token_usage).input_tokens;
        window = info.model_context_window;
      } else {
        if (event.type !== "assistant") continue;
        const usage = obj(event.message?.usage);
        if (!Object.keys(usage).length) continue;
        const parts = [usage.input_tokens, usage.cache_creation_input_tokens ?? 0, usage.cache_read_input_tokens ?? 0];
        count = parts.every(integer) ? parts.reduce((sum, n) => sum + n, 0) : null;
      }
      const at = timestamp(event.timestamp);
      if (!integer(count) || !at) return unknown("invalid_usage");
      const defaultWindow = codex && window == null;
      const size = defaultWindow ? 1_000_000 : integer(window) && window > 0 ? window : null;
      const windowSource = defaultWindow ? "default_1m" : size === null ? null : "codex_reported_window";
      return {input_tokens: count, observed_at: at, source: codex ? "codex_transcript" : "claude_transcript",
        window_tokens: size, window_source: windowSource,
        percent_source: windowSource,
        used_percent: size === null ? null : Math.round(count / size * 100), unknown_reason: null};
    }
    return unknown("usage_not_in_tail");
  } catch { return unknown("unreadable_transcript"); }
  finally { if (fd !== undefined) closeSync(fd); }
}

export function withClaudeWindow(sample: TokenSample, value: string | null): TokenSample {
  if (value === null) return {...sample, window_tokens: 1_000_000, window_source: "default_1m",
    percent_source: "default_1m", used_percent: sample.input_tokens === null ? null : Math.round(sample.input_tokens / 1_000_000 * 100)};
  // Noncanonical spellings and values outside the documented range remain unknown.
  if (sample.input_tokens === null || !value || !/^\d+$/.test(value)) return sample;
  const window = Number(value);
  if (!Number.isSafeInteger(window) || window < 100000 || window > 1000000) return sample;
  return {...sample, window_tokens: window, window_source: "claude_process_env", percent_source: "claude_process_env",
    used_percent: Math.round(sample.input_tokens / window * 100)};
}

function formatTokens(tokens: number): string {
  if (tokens >= 1_000_000) return `${Number((tokens / 1_000_000).toFixed(2))}M`;
  return tokens < 1000 ? String(tokens) : `${Math.round(tokens / 1000)}k`;
}

export function formatContextTokens(sample?: TokenSample): string {
  const count = sample?.input_tokens == null ? "?" : formatTokens(sample.input_tokens);
  return sample?.window_tokens == null ? count : `${count} / ${formatTokens(sample.window_tokens)}`;
}
