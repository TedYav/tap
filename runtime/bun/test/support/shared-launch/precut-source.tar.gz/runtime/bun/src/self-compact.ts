// Codex self-compact with durable proof. One detached worker: interrupt a busy
// turn with a single authorized Escape, submit bare `/compact` once through the
// locked submit seam, and gate the resume on a FRESH compacted record in the
// bound rollout. Missing, late, or unreadable proof is NOT COMPACTED: the
// handoff is preserved and nothing is sent.
import { appendFileSync, closeSync, constants, fstatSync, mkdirSync, openSync, readFileSync, readSync, writeFileSync } from "node:fs";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { homedir } from "node:os";
import { randomUUID } from "node:crypto";
import { resolveContext, resolveSelf, TapError, type ResolvedContext } from "./context";
import { loadRegistry, seatMap, type Seat } from "./registry";
import { atomicWrite } from "./fsatomic";
import { acquirePaneLock } from "./panelock";
import { authorizePaneEffect, inspectClearFenceRecord, submitVerifyLocked, REAL_EFFECTS, type BoundRecipient, type PaneEffects, type SubmitAuthority, type SubmitResult } from "./courier";
import { detectAgentState } from "./agent-state";
import { capturePane, observePane, pressEscape, settle, tmuxReadOnly } from "./tmux";
import { assertResetUnfenced, resetFenceRefusal } from "./reset";
import { recoveryHold } from "./recovery/state";
import { cmdSendOutcome, type SendOutcome } from "./verbs/send";
import { AGENT_FAMILIES } from "./verbs/team";
import { sameSeat, transcriptIdentity } from "./self-rebrief";

const scripts = resolve(import.meta.dir, "../../../skills/tap/scripts");
const HEAD_BYTES = 65536;
const TAIL_BYTES = 2 * 1024 * 1024;
const INTERRUPT_TIMEOUT_MS = 30000;
const DEFAULT_TIMEOUT_MS = 600000;

export interface Options { handoffPath: string; pane: string; resumePing?: string; focus: string }
export interface CompactRequest {
  id: string; registry: string; bus: string; team: string; handle: string; command: string;
  bound: BoundRecipient & { handle: string; instance: string };
  oldSession: string; oldTranscript: string; handoff: string; focus: string; resumePing?: string;
  /** The Codex turn observed at arm time; a different latest turn means new work and refuses every pane effect. */
  turnId: string;
}
export type CompactState = "armed" | "interrupted" | "submitted" | "submission-unverified" | "compacted" | "resume-sent" | "resume-miss" | "not-compacted" | "incomplete";
export interface CompactReceipt {
  state: CompactState; detail: string; handoff?: string; delivery?: string;
  compactedAt?: string; ordinal?: number;
}
export type SeatReadiness = "idle" | "working" | "blocked" | "booting" | "unknown";
export interface CompactEffects {
  row(): Seat | undefined;
  state(): SeatReadiness;
  /** Latest Codex turn id in the bound rollout, or null when it cannot be proven (fail closed). */
  turn(): string | null;
  escape(): boolean;
  submit(): { result: SubmitResult; submitAt: string; baselineOffset: number };
  send(body: string): SendOutcome;
  record(receipt: CompactReceipt): void;
  /** Called exactly once after fresh compaction proof, before settle/resume: releases the pane-submit lock so the resume send never parks behind the worker's own hold. Earlier exits keep the lock; the worker's finally releases it. */
  unlock?(): void;
  settle(seconds: number): void;
  wait(): Promise<void>;
  now(): number;
}

export function parseOptions(argv: string[]): Options {
  const out: Partial<Options> = {};
  for (let i = 0; i < argv.length; i++) {
    const key = argv[i];
    if (key === "--") {
      const focus = argv.slice(i + 1).join(" ").trim();
      if (!focus) throw new Error("focus text is required: run self.sh compact --handoff <file> -- '<focus>'");
      out.focus = focus;
      break;
    }
    if (!["--pane", "--handoff-path", "--resume-ping"].includes(key ?? "")) throw new Error(`unexpected argument: ${key}`);
    const value = argv[++i];
    if (!value || value.startsWith("--")) throw new Error(`${key} requires a value`);
    const field = ({ "--pane": "pane", "--handoff-path": "handoffPath", "--resume-ping": "resumePing" } as const)[key!]!;
    if (out[field] !== undefined) throw new Error(`duplicate ${key}`);
    out[field] = value;
  }
  if (!out.handoffPath) {
    throw new Error("Codex compaction needs a handoff written by you: run self.sh compact --handoff <file> -- '<focus>'");
  }
  if (!out.pane) throw new Error("self compact requires --pane <tmux-target>");
  if (!out.focus) throw new Error("focus text is required: run self.sh compact --handoff <file> -- '<focus>'");
  return out as Options;
}

function readSlice(fd: number, start: number, size: number): string {
  const bytes = Buffer.alloc(size);
  return bytes.subarray(0, readSync(fd, bytes, 0, size, start)).toString("utf8");
}

/**
 * The first qualifying compacted record strictly after the captured submit
 * boundary. The boundary is the byte offset captured immediately before the
 * real Enter: only complete JSONL records appended after that offset can be
 * proof, and their timestamp must clear `sinceIso`. Older rollouts without
 * top-level ordinals prove through the same gate (an ordinal, when present, is
 * carried for observability, never required). Fails closed: no bound
 * session_meta, a truncated or rewritten rollout, an unreadable offset
 * boundary, or an unparseable timestamp yields no proof.
 */
export function compactedAfter(path: string, session: string, sinceIso: string, sinceOffset: number): { timestamp: string; ordinal?: number } | null {
  if (!isAbsolute(path) || !session || !Number.isFinite(Date.parse(sinceIso)) || !Number.isSafeInteger(sinceOffset) || sinceOffset < 0) return null;
  let fd: number | undefined;
  try {
    fd = openSync(path, constants.O_RDONLY | constants.O_NONBLOCK);
    if (!fstatSync(fd).isFile()) return null;
    const size = fstatSync(fd).size;
    if (size < sinceOffset) return null;
    const head = readSlice(fd, 0, Math.min(size, HEAD_BYTES)).split("\n");
    let bound = false;
    for (const line of head) {
      let event; try { event = JSON.parse(line); } catch { continue; }
      if (event.type === "session_meta") { bound = event.payload?.id === session; break; }
    }
    if (!bound) return null;
    let region = readSlice(fd, sinceOffset, Math.min(size, sinceOffset + TAIL_BYTES) - sinceOffset);
    if (sinceOffset > 0) {
      const boundary = Buffer.alloc(1);
      readSync(fd, boundary, 0, 1, sinceOffset - 1);
      if (boundary[0] !== 0x0a) region = region.slice(region.indexOf("\n") + 1);
    }
    region = region.slice(0, region.lastIndexOf("\n") + 1);
    for (const line of region.split("\n")) {
      let event; try { event = JSON.parse(line); } catch { continue; }
      if (event.type !== "compacted" && !(event.type === "event_msg" && event.payload?.type === "context_compacted")) continue;
      const at = typeof event.timestamp === "string" ? event.timestamp : "";
      if (!at || !Number.isFinite(Date.parse(at))) continue;
      if (Date.parse(at) > Date.parse(sinceIso)) {
        const ordinal = event.ordinal;
        return Number.isSafeInteger(ordinal) ? { timestamp: at, ordinal } : { timestamp: at };
      }
    }
    return null;
  } catch { return null; } finally { if (fd !== undefined) closeSync(fd); }
}

/**
 * The latest Codex turn id in the bound rollout: `turn_context.payload.turn_id`
 * or a task event's `turn_id`, last one wins. The search walks backward in
 * bounded chunks with no tail ceiling — a long active turn can push its marker
 * past any fixed window — and reconstructs a marker record that straddles a
 * chunk boundary from both halves. A trailing fragment without its newline is
 * mid-write, never evidence — and when that record spans whole chunks, its
 * bytes stay discarded until the walk reaches the chunk holding its opening
 * boundary newline; reassembling them earlier would present mid-write bytes
 * as a finished record. A complete malformed record newer than the newest
 * valid marker also returns null: it could conceal that marker, and accepting
 * an older id would interrupt new work. Null when the rollout is unreadable,
 * malformed in that way, or exposes no complete turn marker; callers fail
 * closed on all of those.
 */
export function latestTurnId(path: string): string | null {
  const isTurnMarker = (line: string): string | null | "malformed" => {
    let event; try { event = JSON.parse(line); } catch { return "malformed"; }
    const payload = event.payload ?? {};
    if (typeof payload.turn_id !== "string" || !payload.turn_id) return null;
    if (event.type === "turn_context" || (event.type === "event_msg" && String(payload.type ?? "").startsWith("task_"))) return payload.turn_id;
    return null;
  };
  let fd: number | undefined;
  try {
    fd = openSync(path, constants.O_RDONLY | constants.O_NONBLOCK);
    if (!fstatSync(fd).isFile()) return null;
    const size = fstatSync(fd).size;
    let carry = "";
    let eofOpen = true;
    for (let end = size; end > 0;) {
      const start = Math.max(0, end - 262144);
      const chunk = readSlice(fd, start, end - start);
      const lines = chunk.split("\n");
      const trailing = lines.pop() ?? "";
      if (eofOpen) {
        // The file's final record has no newline yet: every byte down to the
        // first newline found in an older chunk belongs to it, and none of it
        // is complete evidence.
        if (!lines.length) { end = start; continue; }
        eofOpen = false;
      } else if (end !== size) {
        lines.push(trailing + carry);
      }
      if (start > 0) carry = lines.length ? lines.shift()! : trailing + carry;
      for (let i = lines.length - 1; i >= 0; i--) {
        if (!lines[i]) continue;
        const turn = isTurnMarker(lines[i]!);
        if (turn === "malformed") {
          // Chunk edges carry partial records out of the scan, so every line
          // scanned here is complete — and the walk is newest-first: a
          // malformed record newer than a marker conceals it, and accepting
          // the older id would interrupt new work.
          return null;
        }
        if (turn) return turn;
      }
      end = start;
    }
    return null;
  } catch { return null; } finally { if (fd !== undefined) closeSync(fd); }
}

function rolloutSize(path: string): number {
  try {
    const fd = openSync(path, constants.O_RDONLY | constants.O_NONBLOCK);
    try { return fstatSync(fd).isFile() ? fstatSync(fd).size : -1; } finally { closeSync(fd); }
  } catch { return -1; }
}

const resultDetail = (result: SubmitResult): string => "detail" in result && result.detail ? result.detail : result.status;
const msg = (error: unknown): string => error instanceof Error ? error.message : String(error);
/** Only actual final outcomes publish self-helper.log pointers; armed/observed phases stay out of the terminal surface. */
export const TERMINAL: ReadonlySet<CompactState> = new Set(["resume-sent", "resume-miss", "not-compacted", "incomplete"]);

/**
 * Custody holds that must refuse ANY pane effect — Escape, the locked submit,
 * and the real Enter: a live team reset fence, an in-flight recovery run owning
 * the pane, and a live clear fence on the recipient. One narrow seam so the
 * Escape path, the submit path and the Enter effect answer to the same
 * predicates — no second copies.
 */
export function escapeRefusal(
  authority: SubmitAuthority,
  paneId: string,
  probes: {
    resetFence: (busHome: string) => { detail: string } | null;
    recovery: (paneId: string) => boolean;
    clear: (busHome: string, handle: string) => { state: string };
  } = { resetFence: busHome => resetFenceRefusal(busHome, "self compact Escape"), recovery: paneId => recoveryHold(paneId), clear: inspectClearFenceRecord },
): string | null {
  const busHome = authority.busHome ?? "";
  const fence = probes.resetFence(busHome);
  if (fence) return fence.detail;
  if (probes.recovery(paneId)) return `recovery owns pane '${paneId}'; refusing the pane effect`;
  const clear = probes.clear(authority.recipientBusHome || busHome, authority.recipient ?? "");
  if (clear.state === "live") return `seat '${authority.recipient}' is mid-clear; refusing the pane effect`;
  return null;
}

/**
 * The locked Codex submit, gated by the one custody seam at BOTH effect
 * moments: before the courier stages anything, and at the real Enter — so a
 * recovery that appears after `/compact` is staged still sends no Enter. Each
 * gate throws once; the caller records the refusal and never retries.
 */
export function lockedCompactSubmit(
  request: CompactRequest,
  authority: SubmitAuthority,
  readiness: () => SeatReadiness,
  base: PaneEffects = REAL_EFFECTS,
  probes?: Parameters<typeof escapeRefusal>[2],
): { result: SubmitResult; submitAt: string; baselineOffset: number } {
  const hold = escapeRefusal(authority, request.bound.paneId, probes);
  if (hold) throw new Error(hold);
  let submitAt = "", baselineOffset = -1;
  const lockedFx: PaneEffects = { ...base, pressEnter: target => {
    if (latestTurnId(request.oldTranscript) !== request.turnId) {
      throw new Error("turn: a new Codex turn started after staging; refusing Enter; nothing interrupted");
    }
    if (readiness() !== "idle") {
      throw new Error("readiness: pane took new work after staging; refusing Enter; nothing interrupted");
    }
    const late = escapeRefusal(authority, request.bound.paneId, probes);
    if (late) throw new Error(late);
    submitAt = new Date().toISOString();
    baselineOffset = rolloutSize(request.oldTranscript);
    return base.pressEnter(target);
  } };
  const result = submitVerifyLocked(request.bound.paneId, request.id, "/compact", request.bound, lockedFx, authority);
  return { result, submitAt, baselineOffset };
}

export async function runCompact(request: CompactRequest, fx: CompactEffects, timeout = DEFAULT_TIMEOUT_MS): Promise<void> {
  let phase: CompactState = "armed";
  const finish = (state: CompactState, detail: string, extra: Partial<CompactReceipt> = {}) => {
    try { fx.record({ state, detail: `${phase}: ${detail}`, handoff: request.handoff, ...extra }); }
    catch (error) { console.error(`self: compact receipt unavailable: ${error}; ${detail}`); }
  };
  try {
    const row = fx.row();
    if (!sameSeat(request, row) || row?.harness_session_id !== request.oldSession ||
      !transcriptIdentity(request.oldTranscript, request.bound.harness, request.oldSession)) {
      return finish("incomplete", "identity: seat or bound rollout changed before any effect; nothing submitted");
    }
    const readiness = fx.state();
    if (readiness === "working") {
      if (fx.turn() !== request.turnId) {
        return finish("incomplete", "turn: a new Codex turn started since arming; refusing to interrupt it; handoff preserved; nothing submitted");
      }
      let escaped: boolean;
      try { escaped = fx.escape(); }
      catch (error) { return finish("incomplete", `interrupt refused before Escape: ${msg(error)}`); }
      if (!escaped) return finish("not-compacted", "interrupt-unobserved: Escape did not reach the pane; nothing submitted");
      phase = "interrupted";
      fx.record({ state: phase, detail: "one authorized Escape sent to a working pane", handoff: request.handoff });
      const deadline = fx.now() + INTERRUPT_TIMEOUT_MS;
      let idle = 0;
      while (fx.now() < deadline) {
        if (fx.state() === "idle") { idle++; if (idle >= 2) break; } else idle = 0;
        await fx.wait();
      }
      if (idle < 2) return finish("not-compacted", "interrupt-unobserved: pane never returned to idle; nothing submitted; queued work untouched");
    } else if (readiness !== "idle") {
      return finish("not-compacted", `${readiness}: seat is not compactable now; nothing submitted`);
    }
    const pre = fx.row();
    if (!sameSeat(request, pre) || pre?.harness_session_id !== request.oldSession) {
      return finish("incomplete", "identity: seat changed before Enter; nothing submitted");
    }
    if (fx.state() !== "idle") {
      return finish("incomplete", "readiness boundary lost: pane took new work before Enter; nothing submitted; queued work untouched");
    }
    if (fx.turn() !== request.turnId) {
      return finish("incomplete", "turn: a new Codex turn started since arming; refusing to compact stale work; handoff preserved; nothing submitted");
    }
    const submission = fx.submit();
    const accepted = submission.result.status === "injected" || submission.result.status === "harness_queued";
    const uncertain = submission.result.status === "unverified";
    if (!accepted && !uncertain) {
      return finish("incomplete", `submission ${submission.result.status}: ${resultDetail(submission.result)}; no automatic retry; nothing sent`);
    }
    phase = accepted ? "submitted" : "submission-unverified";
    fx.record({ state: phase, detail: accepted ? "bare /compact submitted; compaction proof pending" : `submission unverified (${resultDetail(submission.result)}); observing the transcript without resubmitting`, handoff: request.handoff });
    if (!submission.submitAt || !Number.isFinite(Date.parse(submission.submitAt))) {
      return finish("incomplete", "submission proof clock unavailable; refusing to guess the boundary");
    }
    const deadline = fx.now() + timeout;
    const tick = (): { timestamp: string; ordinal?: number } | null | "drift" => {
      const current = fx.row();
      if (!sameSeat(request, current) || current?.harness_session_id !== request.oldSession) return "drift";
      return compactedAfter(request.oldTranscript, request.oldSession, submission.submitAt, submission.baselineOffset);
    };
    let proof: { timestamp: string; ordinal?: number } | null = null;
    while (fx.now() < deadline && !proof) {
      const scanned = tick();
      if (scanned === "drift") return finish("incomplete", "identity: seat or conversation changed while awaiting compaction proof; nothing further sent");
      proof = scanned;
      if (!proof) await fx.wait();
    }
    if (!proof) {
      // Documented boundary scan: a record that landed during the final wait is
      // still fresh proof. The deadline is NOT extended by this pass.
      const scanned = tick();
      if (scanned === "drift") return finish("incomplete", "identity: seat or conversation changed at the proof deadline; nothing further sent");
      proof = scanned;
    }
    if (!proof) {
      return finish("not-compacted", "no fresh compacted record — NOT COMPACTED; handoff preserved; nothing sent");
    }
    phase = "compacted";
    fx.record({ state: phase, detail: "fresh compacted record observed", handoff: request.handoff, compactedAt: proof.timestamp, ordinal: proof.ordinal });
    fx.unlock?.();
    fx.settle(2);
    const post = fx.row();
    if (!sameSeat(request, post) || post?.harness_session_id !== request.oldSession) {
      return finish("resume-miss", "identity: seat changed before resume; handoff preserved for manual resume");
    }
    const body = request.resumePing?.trim()
      ? request.resumePing
      : `Context compacted for ${request.team}/${request.handle}. Read ${request.handoff} first; focus: ${request.focus}. Run 'tap poll ${request.handle}'.`;
    let outcome: SendOutcome;
    try { outcome = fx.send(body); }
    catch (error) { return finish("resume-miss", `resume send failed: ${msg(error)}; handoff preserved for manual resume`); }
    if (outcome.rc !== 0) {
      return finish("resume-miss", `resume send ${outcome.disposition}; handoff preserved for manual resume`, { delivery: outcome.disposition });
    }
    finish("resume-sent", `resume ${outcome.disposition}; acceptance does not prove the seat read it`, { delivery: outcome.disposition });
  } catch (error) { finish("incomplete", msg(error)); }
}

function readBounded(path: string, limit: number): string {
  const fd = openSync(path, constants.O_RDONLY | constants.O_NONBLOCK);
  try {
    const stat = fstatSync(fd);
    if (!stat.isFile() || stat.size > limit) throw new Error(`not a regular file within ${limit} bytes: ${path}`);
    return readSlice(fd, 0, stat.size);
  } finally { closeSync(fd); }
}

function timeoutFromEnv(): number {
  const raw = process.env.TAP_SELF_COMPACT_TIMEOUT_SECONDS;
  const value = raw === undefined || raw === "" ? Number.NaN : Number(raw);
  return Number.isSafeInteger(value) && value > 0 ? value * 1000 : DEFAULT_TIMEOUT_MS;
}

const workerPath = resolve(import.meta.dir, "self-compact.ts");

export async function worker(path: string): Promise<void> {
  const request: CompactRequest = JSON.parse(readBounded(path, 65536));
  const receiptPath = path.slice(0, -5) + ".receipt.json";
  const helperLog = join(process.env.TAP_INDEX_HOME || join(homedir(), ".tap"), "self-helper.log");
  const pointer = (state: CompactState) => {
    try {
      mkdirSync(dirname(helperLog), { recursive: true, mode: 0o700 });
      appendFileSync(helperLog, `self compact ${request.id}: ${state}; receipt: ${receiptPath}\n`, { mode: 0o600 });
    } catch (error) { console.error(`self: helper log pointer unavailable: ${error}`); }
  };
  const record = (receipt: CompactReceipt) => {
    let previous = {};
    try { previous = JSON.parse(readFileSync(receiptPath, "utf8")); } catch { /* first receipt */ }
    atomicWrite(receiptPath, JSON.stringify({ ...previous, ...receipt, id: request.id, at: new Date().toISOString(), handoff: request.handoff, oldSession: request.oldSession, oldTranscript: request.oldTranscript }) + "\n");
    if (TERMINAL.has(receipt.state)) pointer(receipt.state);
  };
  try { writeFileSync(`${path}.started`, new Date().toISOString(), { flag: "wx", mode: 0o600 }); }
  catch { console.error(`self: compact worker already ran for ${request.id}; refusing replay`); return; }
  const lock = acquirePaneLock(request.bound.paneId);
  if (!lock) {
    record({ state: "incomplete", detail: "armed: another submit holds this pane; nothing submitted" });
    return;
  }
  let released = false;
  const release = () => { if (!released) { released = true; lock.release(); } };
  try {
    const authority: SubmitAuthority = { registryPath: request.registry, recipient: request.handle, busHome: request.bus,
      agentFamilies: AGENT_FAMILIES, scriptsDir: scripts, expectedNativeSession: request.oldSession, singleEnter: true };
    const readiness = (): SeatReadiness => {
      const obs = observePane(request.bound.paneId);
      if (!obs || typeof obs === "string" || obs.serverEpoch !== request.bound.serverEpoch) return "unknown";
      const screen = capturePane(request.bound.paneId, true);
      const title = tmuxReadOnly(["display-message", "-p", "-t", request.bound.paneId, "#{pane_title}"]);
      if (screen.code !== 0 || title.code !== 0) return "unknown";
      return detectAgentState(request.bound.harness, screen.stdout, title.stdout.trim()).agentState as SeatReadiness;
    };
    await runCompact(request, {
      row: () => seatMap(loadRegistry(request.registry))[request.handle],
      state: readiness,
      turn: () => latestTurnId(request.oldTranscript),
      escape: () => {
        const check = authorizePaneEffect(request.bound.paneId, request.bound, REAL_EFFECTS, authority);
        if (check.status !== "ok") throw new Error(check.detail);
        const hold = escapeRefusal(authority, request.bound.paneId);
        if (hold) throw new Error(hold);
        const pressed = pressEscape(request.bound.paneId);
        if (pressed === "rate_limited") throw new Error("tmux client budget exhausted before Escape");
        return pressed;
      },
      submit: () => lockedCompactSubmit(request, authority, readiness),
      send: body => cmdSendOutcome(resumeSendArgs(request.handle, stageResumeBody(dirname(path), request.id, body)), scripts, AGENT_FAMILIES,
        { explicitTeam: request.team, expectedSenderInstance: request.bound.instance, quiet: true,
          reauthorize: registry => {
            const current = seatMap(registry)[request.handle];
            if (!sameSeat(request, current)) throw new Error("compact sender identity changed");
            if (current?.harness_session_id !== request.oldSession) throw new Error("compact native session changed before resume placement");
          } }),
      record,
      unlock: release,
      settle,
      now: Date.now,
      wait: () => Bun.sleep(1000),
    }, timeoutFromEnv());
  } finally { release(); }
}

/** The one production detachment seam: own process group, stdio to the worker log, never awaited. armSelfCompact and the process-lifetime test share it, so a detachment regression cannot hide behind a hand-rolled spawn in a test. */
export function spawnDetachedWorker(bun: string, workerScript: string, requestPath: string, logFd: number, env: NodeJS.ProcessEnv = process.env): void {
  const child = Bun.spawn([bun, workerScript, "--run", requestPath], { detached: true, stdin: "ignore", stdout: logFd, stderr: logFd, env: { ...env } });
  child.unref();
}

/**
 * The resume body rides a mode-0600 file beside the request, never inline: a
 * precomposed ping or a long focus has no inline guarantee, and
 * TAP_INLINE_MAX_BYTES may be far smaller than the text. File sourcing has no
 * size limit by design.
 */
export function stageResumeBody(dir: string, id: string, body: string): string {
  const path = join(dir, `${id}.compact.resume.txt`);
  writeFileSync(path, body, { mode: 0o600 });
  return path;
}

export function resumeSendArgs(handle: string, bodyPath: string): string[] {
  return [handle, "--from", handle, "--note", "--wake", "-f", bodyPath];
}

export function armSelfCompact(options: Options, context?: ResolvedContext): number {
  const bun = Bun.which("bun");
  if (!bun) throw new Error("Bun runtime is unavailable; nothing armed");
  const ctx = context ?? resolveContext();
  assertResetUnfenced(ctx.bus.home, "self compact");
  const self = resolveSelf(ctx, options.pane, 1);
  const seat = seatMap(loadRegistry(ctx.registryPath))[self.handle];
  if (!seat) throw new Error("seat is no longer registered; Codex compaction needs a registered seat with a bound rollout");
  const harness = String(seat.harness ?? "");
  if (!harness.startsWith("codex")) {
    throw new TapError(6, "compact_witness_unsupported", "unsupported harness", `self compact with transcript proof is Codex-only; '${self.handle}' runs '${harness}'`);
  }
  const handoff = resolve(options.handoffPath);
  let handoffText = "";
  try { handoffText = readBounded(handoff, 4 * 1024 * 1024); }
  catch { throw new Error(`handoff is missing or unreadable: ${options.handoffPath}; run self.sh compact --handoff <file> -- '<focus>'`); }
  if (!handoffText.trim()) throw new Error(`handoff is empty: ${options.handoffPath} — refusing, because an empty handoff reads as 'nothing was in progress'`);
  const oldSession = String(seat.harness_session_id ?? ""), oldTranscript = String(seat.transcript_path ?? "");
  if (!oldSession || !oldTranscript || !transcriptIdentity(oldTranscript, harness, oldSession)) {
    throw new Error("current native session/transcript identity is unverified; nothing armed");
  }
  if (!seat.instance || !seat.server_epoch) throw new Error("seat identity is incomplete");
  const turnId = latestTurnId(oldTranscript);
  if (!turnId) throw new Error(`cannot prove the current Codex turn from ${oldTranscript}; nothing armed`);
  const id = `${self.handle}-${new Date().toISOString().replace(/[-:.]/g, "")}-${randomUUID().slice(0, 8)}`;
  const request: CompactRequest = { id, registry: ctx.registryPath, bus: ctx.bus.home, team: ctx.team, handle: self.handle, command: "/compact",
    bound: { paneId: self.paneId, instance: String(seat.instance), serverEpoch: String(seat.server_epoch), bootId: String(seat.boot_id ?? ""), harness, handle: self.handle },
    oldSession, oldTranscript, handoff, focus: options.focus, resumePing: options.resumePing, turnId };
  const dir = join(ctx.bus.home, "handoff");
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  const path = join(dir, `${id}.compact.json`);
  writeFileSync(path, JSON.stringify(request) + "\n", { flag: "wx", mode: 0o600 });
  const receipt = join(dir, `${id}.compact.receipt.json`);
  atomicWrite(receipt, JSON.stringify({ state: "armed", id, at: new Date().toISOString(), handoff, oldSession, oldTranscript, detail: "armed: detached worker starting" }) + "\n");
  const log = openSync(join(dir, `${id}.compact.log`), "a", 0o600);
  try {
    spawnDetachedWorker(bun, workerPath, path, log);
  } catch (error) {
    atomicWrite(receipt, JSON.stringify({ state: "incomplete", id, handoff, detail: `worker spawn failed; nothing submitted: ${error}` }) + "\n");
    throw error;
  } finally { closeSync(log); }
  console.error(`self: compaction ARMED; completion unverified; end this turn now. Handoff: ${handoff}. Receipt: ${receipt}`);
  return 0;
}

if (import.meta.main) {
  try {
    const args = process.argv.slice(2);
    if (args[0] === "--run" && args.length === 2) await worker(args[1]!);
    else process.exitCode = armSelfCompact(parseOptions(args));
  } catch (error) {
    console.error(`self: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = error instanceof TapError ? error.code : 1;
  }
}
