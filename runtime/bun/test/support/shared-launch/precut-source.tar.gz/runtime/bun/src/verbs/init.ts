import { existsSync, readSync } from "node:fs";
import { basename, join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import { enrollmentAt, flipMarkerState } from "../index-home";
import { loadRegistry } from "../registry";
import { ensureRepoCharter } from "../first-run";

const scripts = resolve(import.meta.dir,"../../../../skills/tap/scripts");
function git(cwd: string, ...args: string[]): string | undefined {
  const result=spawnSync("git",["-C",cwd,...args],{encoding:"utf8"});
  return result.status===0 ? result.stdout.trim() : undefined;
}
function existing(root: string): {name:string;bus:string} | undefined {
  const enrollment=enrollmentAt(root);
  if(enrollment.status!=="ok" && (enrollment.status!=="missing" || flipMarkerState()!=="absent"))return;
  const path=enrollment.status==="ok" ? enrollment.registryLocation : join(root,".tap/bus/registry.json");
  if(!existsSync(path))return;
  const registry=loadRegistry(path);
  const object=(value: unknown): value is Record<string,unknown>=>value!==null && typeof value==="object" && !Array.isArray(value);
  if(!object(registry.team) || !(object(registry.seats) || object(registry.agents)))throw new Error(`Invalid registry document: ${path}`);
  return {name:enrollment.status==="ok" ? enrollment.name : typeof registry.team.name==="string" ? registry.team.name : basename(root),bus:join(root,".tap/bus")};
}
function failure(json: boolean, error_class: string, action: string, detail: string): void {
  if(json)console.log(JSON.stringify({ok:false,error_class,action,detail}));
  else console.error(`${detail}; next: ${action}`);
}
export function cmdInit(argv: string[]): number {
  const json=argv.includes("--json");
  if(argv.some(arg=>arg!=="--json")){failure(json,"usage_error","tap init [--json]","Unknown init argument");return 1;}
  const cwd=process.cwd(),gitRoot=git(cwd,"rev-parse","--show-toplevel"),root=gitRoot || cwd;
  // Initialization belongs to this checkout, regardless of primary enrollment.
  let found: ReturnType<typeof existing>;
  try {
    found=existing(root);
  } catch(error) { failure(json,"registry_invalid","tap doctor",String(error));return 1; }
  const legacy=existsSync(join(root,"tmp/tap"));
  if(found && !legacy){
    if(json) console.log(JSON.stringify({ok:true,already_initialized:true,team:{name:found.name,root},bus:found.bus,in_git:!!gitRoot,migrated:false,primary_counts:null,late:false,late_counts:null}));
    else console.log(`already initialized: team ${found.name}`);
    return 0;
  }
  let create=true;
  if(!existsSync(join(root,"AGENTS.md")) && !json && process.stdin.isTTY && process.stderr.isTTY){
    process.stderr.write("No AGENTS.md here — create one with the TAP signpost? [Y/n] ");
    const byte=Buffer.alloc(1);let answer="";
    while(readSync(0,byte,0,1,null)>0 && byte[0]!==10)answer+=byte.toString();
    create=!/^(n|no)$/i.test(answer.trim());
  }
  const result=spawnSync("bash",[join(scripts,"init-storage.sh"),"--json"],{cwd:root,env:{...process.env,TAP_SETUP_REPO_PENDING:"1"},encoding:"utf8",stdio:["inherit","pipe","pipe"]});
  if(result.status!==0){
    process.stderr.write(result.stderr || "");
    if(json)process.stdout.write(result.stdout || "");
    else {
      try { const error=JSON.parse(result.stdout);failure(false,error.error_class,error.action,error.detail); }
      catch { process.stderr.write(result.stdout || "tap init: storage failed; run tap doctor\n"); }
    }
    return result.status ?? 1;
  }
  process.stderr.write(result.stderr || "");
  let receipt: any;
  try{receipt=JSON.parse(result.stdout);}catch{process.stderr.write("tap init: invalid storage receipt; run tap doctor\n");return 1;}
  if(create && process.env.TAP_SETUP_REPO_PENDING!=="1")ensureRepoCharter(root,!!gitRoot);
  else if(!create)console.error("tap init: project signpost skipped; run tap setup --repo when ready.");
  if(!gitRoot)console.error("tap init: not a git repository; skipped .gitignore setup.");
  if(json)console.log(JSON.stringify({...receipt,already_initialized:false}));
  else console.log(`successfully initialized team: ${receipt.team.name}\nbus: ${receipt.bus}`);
  return 0;
}
if(import.meta.main)process.exitCode=cmdInit(process.argv.slice(2));
