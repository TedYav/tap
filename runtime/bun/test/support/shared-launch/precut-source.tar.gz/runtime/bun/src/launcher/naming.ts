// Session naming. Port of completion.sanitize_component plus
// launcher.session_name_for_handle / allocate_name / named_session_name.
//
// Reservation (RESERVED_HANDLES / TAP_RESERVED_HANDLES) is a caller concern —
// not copied here, so this module does not create a third lockstep.

const ND_ZEROS: readonly number[] = [
  0x0030, 0x0660, 0x06f0, 0x07c0, 0x0966, 0x09e6, 0x0a66, 0x0ae6, 0x0b66,
  0x0be6, 0x0c66, 0x0ce6, 0x0d66, 0x0de6, 0x0e50, 0x0ed0, 0x0f20, 0x1040,
  0x1090, 0x17e0, 0x1810, 0x1946, 0x19d0, 0x1a80, 0x1a90, 0x1b50, 0x1bb0,
  0x1c40, 0x1c50, 0xa620, 0xa8d0, 0xa900, 0xa9d0, 0xa9f0, 0xaa50, 0xabf0,
  0xff10, 0x104a0, 0x10d30, 0x10d40, 0x11066, 0x110f0, 0x11136, 0x111d0,
  0x112f0, 0x11450, 0x114d0, 0x11650, 0x116c0, 0x116d0, 0x116da, 0x11730,
  0x118e0, 0x11950, 0x11bf0, 0x11c50, 0x11d50, 0x11da0, 0x11f50, 0x16130,
  0x16a60, 0x16ac0, 0x16b50, 0x16d70, 0x1ccf0, 0x1d7ce, 0x1d7d8, 0x1d7e2,
  0x1d7ec, 0x1d7f6, 0x1e140, 0x1e2f0, 0x1e4f0, 0x1e5f1, 0x1e950, 0x1fbf0,
];

function unicodeDecimalValue(cp: number): number | null {
  for (const zero of ND_ZEROS) {
    if (cp >= zero && cp <= zero + 9) return cp - zero;
  }
  return null;
}

/** Python `int(s)` over a `\d+` match (Unicode Nd, not JS ASCII `\d`). */
export function parseUnicodeDecimal(s: string): number | null {
  if (!s) return null;
  let n = 0;
  for (const ch of s) {
    const cp = ch.codePointAt(0);
    if (cp === undefined) return null;
    const v = unicodeDecimalValue(cp);
    if (v === null) return null;
    n = n * 10 + v;
  }
  return n;
}

/**
 * Python `$` in default `re.match`: end of string, or just before a single
 * trailing newline (not `\r\n`, not two newlines).
 */
function pythonDollarBody(name: string): string {
  if (name.endsWith("\n\n")) return name;
  if (name.endsWith("\n")) return name.slice(0, -1);
  return name;
}

export function sanitizeComponent(value: string): string {
  const cleaned = value
    .trim()
    .replace(/[^A-Za-z0-9_-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-+|-+$/g, "");
  return cleaned || "agent";
}

export function sessionNameForHandle(base: string, handle: string): string {
  return `${sanitizeComponent(base)}/${handle}`;
}

export function namedSessionName(base: string, handle: string): string {
  return sessionNameForHandle(base, sanitizeComponent(handle));
}

export function allocateName(
  base: string,
  harness: string,
  tag: string | null,
  existingNames: Iterable<string>,
  literalHandle = false,
): string {
  const raw = tag || harness;
  const handle = literalHandle && tag ? raw : sanitizeComponent(raw);
  const prefix = `${sanitizeComponent(base)}/${handle}`;
  const used = new Set<number>();
  const hyphenPrefix = `${prefix}-`;
  for (const name of existingNames) {
    if (name === prefix) {
      used.add(1);
      continue;
    }
    const body = pythonDollarBody(name);
    if (!body.startsWith(hyphenPrefix)) continue;
    const parsed = parseUnicodeDecimal(body.slice(hyphenPrefix.length));
    if (parsed === null) continue;
    used.add(parsed === 0 ? 1 : parsed);
  }
  let index = 1;
  while (used.has(index)) index += 1;
  return index === 1 ? prefix : `${prefix}-${index}`;
}
