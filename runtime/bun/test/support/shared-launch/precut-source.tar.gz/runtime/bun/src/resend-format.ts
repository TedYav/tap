import { readFileSync } from "node:fs";
import { ensureAscii } from "./fsatomic";

/** Format the one successor's receipt; this never selects or retries a send. */
export function formatResendResult(output: Uint8Array, returncode: number, id: string,
  newId: string, json: boolean, verbose = process.env.TAP_VERBOSE === "1"): Uint8Array {
  let receipt: Record<string, unknown>;
  try {
    receipt = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(output));
  } catch {
    return output;
  }
  if (!receipt || typeof receipt !== "object" || Array.isArray(receipt)) {
    throw new TypeError("resend receipt must be an object");
  }
  receipt.resend_of = id;
  receipt.delivery_semantics = "at-least-once";
  let text: string;
  if (json) {
    // Preserve json.dumps' ASCII escaping and separator spacing without changing
    // punctuation inside quoted strings (including escaped quotes).
    text = ensureAscii(JSON.stringify(receipt)).replace(/\x7f/g, "\\u007f")
      .replace(/"(?:[^"\\]|\\.)*"|[:,]/g, token => token === ":" || token === "," ? `${token} ` : token);
  } else if (returncode === 0 && !verbose) {
    text = `tap resend: ${receipt.status === "queued" ? "queued" : "ok"} ${newId}`;
  } else {
    text = `tap resend: RESEND ${newId} from ${id}; explicit at-least-once; ${receipt.status ?? "unconfirmed"}`;
  }
  return Buffer.from(`${text}\n`);
}

if (import.meta.main) {
  const [id, newId, json, code] = process.argv.slice(2);
  const returncode = Number(code);
  process.stdout.write(formatResendResult(readFileSync(0), returncode, id!, newId!, json === "1"));
  process.exitCode = returncode;
}
