import { isPasteCollapse } from "../pane-state";

/** Small writes avoid Claude's paste-collapse heuristic; pacing proves nothing. */
export function controlPayloadChunks(payload: string): string[] {
  const chunks: string[] = [];
  let chunk = "", bytes = 0;
  for (const character of payload) {
    const size = Buffer.byteLength(character);
    if (bytes + size > 250) { chunks.push(chunk); chunk = ""; bytes = 0; }
    chunk += character;
    bytes += size;
  }
  if (chunk) chunks.push(chunk);
  return chunks;
}

/** Incumbent ordered tail check, not a checksum or an incremental acknowledgement. */
export function controlTailReady(harness: string, rendered: string, expected: string) {
  // Python str.split() whitespace, including its four information separators.
  const compact = (text: string) => text.replace(/[\p{White_Space}\u001c-\u001f]/gu, "");
  const tail = Array.from(compact(expected)).slice(-128).join("");
  return {
    ready: !isPasteCollapse(harness, rendered) && tail.length > 0 && compact(rendered).endsWith(tail),
    renderedBytes: Buffer.byteLength(rendered),
    expectedBytes: Buffer.byteLength(expected),
  };
}

if (import.meta.main) {
  const [mode, ...args] = process.argv.slice(2);
  if (mode === "chunks" && args.length === 1) {
    console.log(JSON.stringify(controlPayloadChunks(args[0]!)));
  } else if (mode === "tail" && args.length === 2) {
    const result = controlTailReady(args[0]!, await Bun.stdin.text(), args[1]!);
    console.log(`rendered_bytes=${result.renderedBytes} expected_bytes=${result.expectedBytes}`);
    // A refused observation is a normal decision, not a runtime failure.
    console.log(result.ready ? "ready" : "wait");
  } else {
    console.error("control-payload: expected chunks <payload> or tail <harness> <payload>");
    process.exit(2);
  }
}
