import { spawnSync } from "node:child_process";
import { existsSync, readFileSync, realpathSync } from "node:fs";
import { basename, dirname, join, resolve } from "node:path";

import { TapError, callingPane, observeCallingPane, requireActingRegistry, resolveContext, resolveSelf, type ResolvedContext } from "../context";
import { renderRefusals } from "../error-line";
import { helpArgv } from "../help";
import { readContextTokens, withClaudeWindow, formatContextTokens, type TokenSample } from "../context-tokens";
import { claudeWindows } from "../context-window";
import { contextUsedPercent, contextQueueFacts } from "../context-census";
import {
  actingRegistryForTeamOverride,
  flipMarkerState,
  globalRegistryPath,
  legacyTeamsPath,
  resolveEnrolledTeamRoot,
  resolveTeamFromGlobal,
} from "../index-home";
import { applyTeamOverride } from "../team-override";
import { assertResetUnfenced } from "../reset";
import { busHomeForEnrolled } from "../selector";
import { runTeamStop, type RegistryPolicy, type StopEffects } from "../team/stop";
import type { StopVerb } from "../team/stop-plan";
import { crewSelectGate, noSelection, parseSelection, registryRoster, rosterGate, selectConflictGate, selectedHandles, selectionBlob } from "../team/selection";
import { teamStopQueueSummary } from "../team-stop-queue";
import { seatMap } from "../registry";
import { disarm, readLoose } from "../watch-lease";
import { clearTints } from "../watch-sidecar";
import { armPath } from "../watch-notice";
import type { LifecycleTmux } from "../lifecycle-target";
import { REGISTRY_MAX_BUFFER } from "../spawn";
import { observeRows, type ObserveEngine, type ObservePayload } from "../observe";
import { clockFields, gather } from "../observe-gather";
import { ensureAscii } from "../fsatomic";
import { detectAgentState, type AgentState } from "../agent-state";
import { ServerUnresponsive, serverEpochFromRaw, tmuxReadOnly } from "../tmux";
import { repoSetupHeadsUp } from "../first-run";
import { archiveNudge } from "../bus-archive-index";
import { cmdRefresh } from "./refresh";
import { effectiveWindows, windowsDoc } from "../digest-window";
import { configDirectory, isRegularFile, readSecureBytes } from "../launcher/catalog";
import { rosterDisplayFacts, tryLoadCatalogForDisplay } from "../launcher/catalog-listing";
import { Notices } from "../launcher/catalog-notices";
import { PyInt } from "../spool-publication";
import { cmdTeamDoctor } from "../team/doctor";
import { cmdTeamAttach } from "../team/attach";
import { cmdTeamReset } from "../team/reset";
import { cmdTeamRestore } from "../team/restore";
import { cmdTeamPurge } from "../team/purge";
import { cmdTeamDetach } from "../team/detach";
import { calibrationView, writeRoutingResult } from "../routing";

type HumanAgentState = AgentState | "offline" | "unbound" | "incapable";

const US = "\x1f";
const ANSI = /\x1b\[[0-?]*[ -/]*[@-~]/g;
const AGENT_COLOR: Record<HumanAgentState, number> = {
  working: 32,
  blocked: 31,
  idle: 34,
  booting: 36,
  unknown: 33,
  unbound: 33,
  offline: 90,
  incapable: 35,
};
export const TEAM_SUBCOMMANDS = ["doctor", "list", "roster", "calibration", "attach", "detach", "refresh", "shutdown", "down", "up", "reset", "purge", "restore"];
const AGENT_FAMILIES = new Set(["claude", "codex", "opencode", "cursor", "hermes", "agy"]);
export { AGENT_FAMILIES };
const DENYLIST = new Set([
  "bash", "zsh", "sh", "fish", "dash", "ksh", "tcsh", "less", "more", "man",
  "vi", "vim", "view", "nvim", "nano", "emacs", "ssh", "cat", "pager", "git",
]);
export { DENYLIST };


export interface RegistryRow {
  team: unknown;
  handle: unknown;
  harness: unknown;
  pane: unknown;
  status: unknown;
  status_reason: unknown;
  delivery: unknown;
  pane_id: unknown;
  unattended: unknown;
  session: unknown;
  registered_at: unknown;
  crew: unknown;
  server_epoch: unknown;
  server_socket?: unknown;
  boot_id: unknown;
  preset: unknown;
  harness_session_id?: unknown;
  transcript_path?: unknown;
}

interface RegistryRead {
  ok: boolean;
  team?: unknown;
  rows?: RegistryRow[];
  error?: string;
  rawError?: boolean;
  rawOutput?: string;
}

interface ObservedRow {
  handle: string;
  session: string;
  harness: string;
  pane: string;
  observedPaneId: string;
  observedServerEpoch: string;
  serverSocket?: string;
  foreignNamespace?: boolean;
  delivery: string;
  status: string;
  statusReason: string;
  attached: string;
  unattended: boolean;
  crew: boolean;
  preset: string;
  digestWindow?: number;
  askWindow?: number;
  agentState: AgentState;
  agentStateReason: string;
  harnessSessionId?: string;
  transcriptPath?: string;
  tokenSample?: TokenSample;
  contextUsedPercent?: number | null;
  contextSampledAt?: string | null;
}

interface TeamOptions {
  json: boolean;
  all: boolean;
  names: boolean;
  active: boolean;
  team?: string;
}

function str(value: unknown): string {
  return typeof value === "string" ? value : "";
}

function humanAction(action: string): string {
  const flat = action.replace(/[\r\n]/g, " ");
  return /[ /]/.test(flat) ? flat : flat.replace(/_/g, " ");
}

function jsonRefusal(error: TapError): void {
  const fields: [string, string][] = [
    ["ok", "false"],
    ["error_class", JSON.stringify(error.errorClass)],
    ["action", JSON.stringify(error.action)],
  ];
  if (error.detail) fields.push(["detail", JSON.stringify(error.detail)]);
  const body = fields.map(([k, v]) => `${JSON.stringify(k)}:${v}`).join(",");
  process.stdout.write(`${ensureAscii(`{${body}}`)}\n`);
}

function genericRegistryRefusal(): TapError {
  return new TapError(
    1,
    "registry_unreachable",
    "tap doctor",
    "acting registry unreachable — refusing tap team against a bus decoy",
  );
}

function teamContext(explicitTeam?: string): ResolvedContext {
  let ctx: ResolvedContext;
  try {
    ctx = resolveContext(process.cwd(), process.env, explicitTeam ? { explicitTeam } : undefined);
  } catch (error) {
    if (error instanceof TapError) {
      if (!explicitTeam && error.errorClass !== "not_a_bus") throw genericRegistryRefusal();
      throw error;
    }
    throw error;
  }
  if (!explicitTeam && ctx.marker === "live" && (!ctx.registryPath || !existsSync(ctx.registryPath))) {
    throw genericRegistryRefusal();
  }
  return ctx;
}

function initialArgs(argv: string[]): string[] {
  const first = argv[0] ?? "";
  if (!first) return argv.length > 0 ? argv.slice(1) : argv;
  if (first.startsWith("--")) {
    if (first && !["--json", "--all", "--names", "--active"].includes(first)) {
      throw new TapError(1, "unknown_option", "tap help team", `unknown option '${first}'`);
    }
    return argv;
  }
  if (!TEAM_SUBCOMMANDS.includes(first)) {
    throw new TapError(
      1,
      "unknown_subcommand",
      "tap help team",
      `unknown subcommand '${first}' (usage: tap team [list|roster|calibration|attach|detach|down|up|refresh|shutdown|reset|restore|purge] [--json|--all])`,
    );
  }
  return first === "roster" ? argv.slice(1) : argv;
}

function parseOptions(argv: string[], allowTeamPositional: boolean = false): TeamOptions {
  const out: TeamOptions = { json: false, all: false, names: false, active: false };
  for (const arg of argv) {
    if (arg === "--json") out.json = true;
    else if (arg === "--all") out.all = true;
    else if (arg === "--names") out.names = true;
    else if (arg === "--active") out.active = true;
    else if (arg.startsWith("--")) {
      throw new TapError(1, "unknown_option", "tap help team", `unknown option '${arg}'`);
    } else if (allowTeamPositional && !out.team) {
      if (!arg) throw new TapError(1, "usage_error", "tap help team", "team name cannot be empty");
      out.team = arg;
    } else {
      throw new TapError(1, "usage_error", "tap help team", `unexpected arg '${arg}'`);
    }
  }
  if (out.names && out.json) {
    throw new TapError(
      1,
      "usage_error",
      "tap team --names   (or: tap team --json)",
      "--names and --json are alternative output shapes — pick one",
    );
  }
  if (out.active && !out.names) {
    throw new TapError(
      1,
      "usage_error",
      "tap team --names --active",
      "--active only narrows the --names list; bare 'tap team' already shows each seat's status",
    );
  }
  return out;
}

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// Python's `or` treats empty lists and dictionaries as false. Keep that rule
// before validating container shapes; JavaScript's object truthiness differs.
function pythonOr(value: unknown, fallback: unknown): unknown {
  if (value === undefined || value === null || value === false || value === "" || value === 0) return fallback;
  if (Array.isArray(value) && value.length === 0) return fallback;
  if (record(value) && Object.keys(value).length === 0) return fallback;
  return value;
}

export function readRegistry(path: string, wantJson: boolean, crewOnly: boolean): RegistryRead {
  try {
    // loadRegistry's write-safe numeric restrictions are intentionally not
    // imposed on this display-only projection. Invalid UTF-8 still refuses.
    // Missing is not empty: this path names the enrolled acting authority, so
    // ENOENT is an observation failure just like malformed bytes.
    const reg: unknown = JSON.parse(
      new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(readFileSync(path)),
    );
    if (!record(reg)) throw new Error("registry document must be an object");
    const teamRecord = pythonOr(reg.team, {});
    if (!record(teamRecord)) throw new Error("registry team must be an object");
    const team = Object.hasOwn(teamRecord, "name") ? teamRecord.name : "";
    const agents = record(reg.seats) ? reg.seats : pythonOr(reg.agents, {});
    if (!record(agents)) throw new Error("registry agents must be an object");
    const rows: RegistryRow[] = [];
    // Python sorted() compares code points, including JSON-escaped surrogates.
    const handles = Object.keys(agents).sort((a, b) => {
      const left = Array.from(a, c => c.codePointAt(0)!);
      const right = Array.from(b, c => c.codePointAt(0)!);
      for (let i = 0; i < Math.min(left.length, right.length); i++) {
        if (left[i] !== right[i]) return left[i]! - right[i]!;
      }
      return left.length - right.length;
    });
    for (const handle of handles) {
      const ent = agents[handle];
      if (!record(ent) || (crewOnly && ent.crew !== true)) continue;
      const get = (key: string, fallback: unknown = "") => Object.hasOwn(ent, key) ? ent[key] : fallback;
      rows.push({
        team, handle,
        harness_session_id: ent.harness_session_id, transcript_path: ent.transcript_path,
        harness: get("harness"), pane: get("pane"), status: get("status", "active"),
        status_reason: pythonOr(ent.status_reason, ""), delivery: pythonOr(ent.delivery, "pane"),
        pane_id: pythonOr(ent.pane_id, ""), unattended: ent.unattended === true,
        session: pythonOr(ent.session, ""), registered_at: pythonOr(ent.registered_at, ""),
        crew: ent.crew === true, server_epoch: pythonOr(ent.server_epoch, ""),
        ...(ent.server_socket ? {server_socket: ent.server_socket} : {}),
        boot_id: pythonOr(ent.boot_id, ""), preset: record(ent.preset) ? pythonOr(ent.preset.name, "") : "",
      });
    }
    return { ok: true, team, rows };
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    // Keep the existing public error envelope and exit path. Native diagnostics
    // name the bad input rather than reproducing an incidental Python traceback.
    return wantJson
      ? { ok: false, rawError: true, rawOutput: ensureAscii(JSON.stringify({ team: null, agents: [], error: detail })) + "\n" }
      : { ok: false, rawError: true, error: `tap team: registry unreadable (${detail}) — run: tap doctor\n` };
  }
}

/**
 * ONE tmux/process snapshot, classified by the shared engine.
 *
 * Exported (tap-nyvty) so `tap team refresh` consumes the SAME observation the
 * roster does rather than growing a second answer to "is this seat gone". The
 * The incumbent made the same choice in bash: lib.sh's N=1 wrapper and the
 * roster's batch call both reached tap_observe_seats.py. Both now reach
 * `observe.ts` — the N=1 wrapper as a child through `tap_bun_call`, this door
 * in-process — and the rule the comment at lib.sh stated still holds: agreement
 * between roster, attach and refresh is mechanical, not two implementations
 * that happen to match.
 */
export function observe(
  rows: RegistryRow[],
  scriptsDir: string,
  fast = false,
  diagnostic: (text: string) => void = text => { process.stderr.write(text); },
  engine: ObserveEngine = observeRows,
): { code: number; rows: Map<string, string[]>; serverEpoch: string; panePids?: Map<string,string> } {
  const g = gather({ fast, env: process.env });
  const serverEpoch = g.serverEpoch;

  const payload: Record<string, unknown> = {
    rows: rows.map((row) => ({
      key: str(row.handle),
      status: str(row.status),
      delivery: str(row.delivery),
      pane: str(row.pane),
      pane_id: str(row.pane_id),
      session: str(row.session),
      registered_at: str(row.registered_at),
      row_epoch: str(row.server_epoch),
      row_boot: str(row.boot_id),
      harness: str(row.harness),
      status_reason: str(row.status_reason),
    })),
    sessions_rc: g.sessions_rc,
    sessions_text: g.sessions_text,
    panes_rc: g.panes_rc,
    panes_text: g.panes_text,
    ps_rc: g.ps_rc,
    ps_text: g.ps_text,
    ...clockFields({ env: process.env }),
  };
  if (process.env.TAP_SERVER_EPOCH !== undefined) payload.server_epoch_pin = process.env.TAP_SERVER_EPOCH;

  // The classification runs HERE. It was a `python3 -B tap_observe_seats.py`
  // child fed this payload as JSON on stdin; the payload keeps its wire shape
  // because the Bash door still sends exactly these fields to `observe.ts`, and
  // a differential compares the two on it.
  //
  // WHAT THE PROCESS BOUNDARY TOOK WITH IT, stated rather than discovered at
  // review: the two doors no longer share a failure. The Bash door still spawns
  // a child (`tap_bun_call` → `bun observe.ts --from-env`) and can see it exit
  // nonzero; this door can only see the engine throw. An assertion that they
  // fail byte-identically would be asserting a property production does not
  // have, so the arm that made that comparison is deleted rather than re-aimed.
  // The two agree on the CODE — `tap_bun_call` reports 1, and so does a throw —
  // but that is agreement, not a shared mechanism.
  const out = new Map<string, string[]>();
  let records: string[];
  try {
    records = engine(payload as ObservePayload);
  } catch (error) {
    // A classification that could not complete never becomes a roster. The
    // failure is a diagnostic, never part of a caller's JSON receipt, and `out`
    // stays empty so no half-answer can be read as rows.
    diagnostic(`${error instanceof Error ? error.message : String(error)}\n`);
    return { code: 1, rows: out, serverEpoch };
  }
  for (const line of records) {
    const fields = line.split(US);
    const key = fields.shift() ?? "";
    if (key) out.set(key, fields);
  }
  const panePids = new Map(g.panes_text.split("\n").map(line => line.split("\t")).filter(f => f.length >= 6).map(f => [f[2]!, f[4]!]));
  return { code: 0, rows: out, serverEpoch, panePids };
}

function presetFacts(
  rows: RegistryRow[],
): Record<string, Record<string, unknown>> {
  const handles = rows.map((row) => str(row.handle)).filter(Boolean);
  const recorded = Object.fromEntries(
    rows.map((row) => [str(row.handle), str(row.preset)]).filter(([, preset]) => preset),
  );
  let facts: Record<string, Record<string, unknown>>;
  try {
    const catalog = tryLoadCatalogForDisplay(new Notices(() => {}), process.env,
      readSecureBytes, configDirectory(process.env), isRegularFile);
    facts = rosterDisplayFacts(handles, { recorded, catalog });
  } catch {
    // An invalid config location has the same display-only fallback as an unreadable catalog.
    facts = rosterDisplayFacts(handles, { recorded, catalog: null });
  }
  // The windows are read here, in-process, one config read for the roster —
  // not once per handle through the Python forwarder, which spawned the native
  // reader per row (A1a: the 2,000-seat `tap team --json` arm reddened on it).
  // A digit string past 2^53 travelled as JSON digits before and rounded on
  // parse; `Number(source)` is that same rounding.
  const team = str(rows[0]?.team);
  const doc = windowsDoc(process.env);
  const plain = (value: number | PyInt): number => (value instanceof PyInt ? Number(value.source) : value);
  for (const handle of handles) {
    const windows = effectiveWindows(team, handle, process.env, doc);
    facts[handle] = { ...(facts[handle] ?? {}), digest_window_seconds: plain(windows.digest_window_seconds), ask_window_seconds: plain(windows.ask_window_seconds) };
  }
  return facts;
}

export function observedRows(
  rows: RegistryRow[],
  observations: Map<string, string[]>,
  observedServerEpoch: string,
  facts: Record<string, Record<string, unknown>>,
  callerSocket = "",
): ObservedRow[] {
  const out: ObservedRow[] = [];
  for (const row of rows) {
    const handle = str(row.handle);
    if (!handle) continue;
    const observation = observations.get(handle) ?? ["unknown", "observation_missing", "", "", "", "0"];
    const foreignNamespace = str(row.delivery) !== "poll" && !!callerSocket && !!str(row.server_socket) && str(row.server_socket) !== callerSocket;
    const status = foreignNamespace ? "offline" : observation[0] || "unknown";
    let attached = observation[5] || "";
    const delivery = str(row.delivery) || "pane";
    if (delivery !== "poll") {
      if (attached === "true" || attached === "yes") attached = "1";
      else if (!/^[0-9]+$/.test(attached)) attached = "0";
      if (status !== "active") attached = "0";
    } else {
      attached = "";
    }
    let harness = str(row.harness);
    if (row.crew === true && status === "active" && observation[4]) harness = observation[4]!;
    const fact = facts[handle] ?? {};
    let preset = str(fact.preset);
    if (preset && fact.preset_inferred === true) preset += "?";
    out.push({
      handle,
      session: str(row.session),
      harnessSessionId: str(row.harness_session_id), transcriptPath: str(row.transcript_path),
      harness,
      pane: str(row.pane),
      observedPaneId: observation[3] || "",
      observedServerEpoch,
      delivery,
      status,
      statusReason: foreignNamespace ? "foreign_namespace" : observation[1] || "",
      serverSocket: str(row.server_socket), foreignNamespace,
      attached,
      unattended: row.unattended === true,
      crew: row.crew === true,
      preset,
      digestWindow: Number(fact.digest_window_seconds ?? 10),
      askWindow: Number(fact.ask_window_seconds ?? 10),
      agentState: "unknown",
      agentStateReason: "not_observed",
    });
  }
  return out;
}

// Exported for tap health (tap-diagnostics-u1): the health roster renders the
// SAME live seat-state ladder the roster does, never a second answer to "what
// is this seat doing right now".
export function withAgentStates(rows: ObservedRow[]): ObservedRow[] {
  return rows.map((row) => {
    let percent: number | null = null, sampledAt: string | null = null;
    let result = { agentState: "unknown" as AgentState, reason: "no_pane" };
    if (row.delivery === "pane" && row.pane) {
      result = detectAgentState(row.harness, "");
      if (result.reason !== "unrecognized_harness") {
        if (row.status === "unknown") {
          result = { agentState: "unknown", reason: "lifecycle_unreadable" };
        } else if (row.status !== "active") {
          result = { agentState: "unknown", reason: "lifecycle_inactive" };
        } else if (!row.observedPaneId) {
          result = { agentState: "unknown", reason: "capture_failed" };
        } else {
          const codex = /^codex(?:-|$)/.test(row.harness);
          const capture = tmuxReadOnly(["capture-pane", ...(codex ? ["-e"] : []), "-p", "-t", row.observedPaneId]);
          if (capture.code === 0) {
            const title = codex ? tmuxReadOnly(["display-message", "-p", "-t", row.observedPaneId, "#{pane_title}"]) : null;
            const generation = tmuxReadOnly(["display-message", "-p", "#{pid}:#{start_time}"]);
            const currentEpoch = generation.code === 0
              ? serverEpochFromRaw(generation.stdout.trim())
              : "";
            result = (!title || title.code === 0) && row.observedServerEpoch && currentEpoch === row.observedServerEpoch
              ? detectAgentState(row.harness, capture.stdout, title?.stdout.trimEnd())
              : { agentState: "unknown", reason: "capture_failed" };
            if (result.reason !== "capture_failed") {
              percent = contextUsedPercent(row.harness, capture.stdout);
              sampledAt = new Date().toISOString();
            }
          } else {
            result = { agentState: "unknown", reason: "capture_failed" };
          }
        }
      }
    }
    return { ...row, agentState: result.agentState, agentStateReason: result.reason, contextUsedPercent: percent, contextSampledAt: sampledAt };
  });
}

function withTokenSamples(rows: ObservedRow[], panePids = new Map<string,string>()): ObservedRow[] {
  const active = rows.filter(row => row.status === "active" && !row.foreignNamespace);
  const windows = claudeWindows(active.filter(row => /^claude(?:-|$)/.test(row.harness)).map(row => panePids.get(row.observedPaneId) ?? "").filter(Boolean));
  return rows.map(row => {
    if (!active.includes(row)) return row;
    let tokenSample = readContextTokens(row.harness, row.harnessSessionId ?? "", row.transcriptPath ?? "");
    if (/^claude(?:-|$)/.test(row.harness)) {
      const window = windows.get(panePids.get(row.observedPaneId) ?? "");
      if (window?.state === "set") tokenSample = withClaudeWindow(tokenSample, window.value);
      else if (window?.state === "unset") tokenSample = withClaudeWindow(tokenSample, null);
    }
    return {...row, tokenSample};
  });
}

function width(value: string): number { return Array.from(value.replace(ANSI, "")).length; }

function truncate(value: string, size: number): string {
  const chars = Array.from(value);
  if (chars.length <= size) return value;
  if (size <= 3) return chars.slice(0, size).join("");
  return `${chars.slice(0, size - 3).join("")}...`;
}

export function table(headers: string[], records: string[][]): string {
  const rows = [headers, ...records];
  const widths = headers.map((_, i) => Math.max(...rows.map((row) => width(row[i] ?? ""))));
  let terminal = /^[0-9]+$/.test(process.env.COLUMNS ?? "")
    ? Number(process.env.COLUMNS)
    : process.stdout.columns ?? 80;
  if (terminal <= 0) terminal = 80;
  const last = headers.length - 1;
  const fixed = widths.slice(0, last).reduce((sum, n) => sum + n, 2 * last);
  widths[last] = Math.min(widths[last]!, Math.max(3, terminal - fixed));
  return rows.map((row) => row.map((cell = "", i) => {
    const shown = i === last ? truncate(cell, widths[i]!) : cell;
    return i === last ? shown : shown.padEnd(widths[i]! + shown.length - width(shown)) + "  ";
  }).join("") + "\n").join("");
}

function humanAgent(row: ObservedRow): string {
  const state: HumanAgentState = row.status === "suspended" && row.statusReason === "incapable"
    ? "incapable"
    : row.status === "active"
    ? row.agentState
    : row.status === "unbound" ? "unbound" : "offline";
  const dot = process.stdout.isTTY && process.env.NO_COLOR === undefined
    ? `\x1b[${AGENT_COLOR[state]}m●\x1b[0m`
    : "●";
  return `${dot} ${state}`;
}

function rosterJson(team: string, rows: ObservedRow[], facts: Record<string, Record<string, unknown>>, queue: Record<string, unknown> = {}): string {
  const agents = rows.map((row) => {
    const tokenSample = row.tokenSample?.input_tokens == null ? null : row.tokenSample;
    const item: Record<string, unknown> = {
      handle: row.handle,
      harness: row.harness,
      pane: row.pane,
      status: row.status,
      status_reason: row.statusReason,
      agent_state: row.agentState,
      agent_state_reason: row.agentStateReason,
      context_tokens: tokenSample,
      context_used_percent: row.contextUsedPercent ?? null,
      context_source: row.contextUsedPercent == null ? null : "footer",
      sampled_at: row.contextSampledAt ?? null,
      ...(queue[row.handle] as object ?? {}),
      attached: row.attached,
      unattended: row.unattended,
      crew: row.crew,
      digest_window_seconds: row.digestWindow ?? 10,
      ask_window_seconds: row.askWindow ?? 10,
    };
    if (row.serverSocket) item.server_socket = row.serverSocket;
    const fact = facts[row.handle];
    if (fact) {
      if (typeof fact.preset === "string" && fact.preset) item.preset = fact.preset;
      for (const key of [
        "preset_inferred", "preset_absent_from_catalog", "preset_catalog_unavailable", "metadata",
      ]) if (key in fact) item[key] = fact[key];
    }
    return item;
  });
  return `${ensureAscii(JSON.stringify({ team: team || null, agents }))}\n`;
}

function teamUp(args: string[], scriptsDir: string): number {
  return renderRefusals("tap team up", () => {
    let selection = noSelection(); const rest: string[] = [];
    for (let i = 0; i < args.length; i++) {
      const flag = args[i]!;
      if (flag !== "--only" && flag !== "--except") { rest.push(flag); continue; }
      if (selection.mode && selection.mode !== flag) selectConflictGate("team up");
      const value = args[++i];
      if (value === undefined) throw new TapError(1, "usage_error", `tap team up ${flag} <handles>`, `${flag} was given no value`, "tap team up");
      selection = parseSelection("team up", value, flag);
    }
    const ctx = teamContext(); requireActingRegistry(ctx, 1);
    rosterGate("team up", selection, registryRoster(ctx.registryPath));
    crewSelectGate("team up", selection, ctx.registryPath);
    const env = { ...process.env };
    delete env.TAP_TEAM_EXCEPT_HANDLES; delete env.TAP_TEAM_ONLY_HANDLES;
    if (selection.mode) env[selection.mode === "--only" ? "TAP_TEAM_ONLY_HANDLES" : "TAP_TEAM_EXCEPT_HANDLES"] = selectionBlob(selectedHandles(selection));
    // Launcher complements the positive only-set against its actual resume
    // candidates, which can include records absent from the registry roster.
    return spawnSync("python3", ["-B", join(scriptsDir, "session/launcher.py"), "resume", "--all", ...rest], { env, stdio: "inherit" }).status ?? 1;
  }, { ...process.env, TAP_JSON: args.includes("--json") ? "1" : process.env.TAP_JSON });
}

function calibration(roster: string, strongest: boolean): number {
  // Window activity is only an idle hint: an unresponsive server must not
  // turn an already-observed roster into a failed calibration view.
  let activity: ReturnType<typeof tmuxReadOnly> | undefined;
  try {
    activity = tmuxReadOnly(["list-panes", "-a", "-F", "#{pane_id}\t#{session_name}:#{window_index}.#{pane_index}\t#{window_activity}"]);
  } catch (error) {
    if (!(error instanceof ServerUnresponsive)) throw error;
  }
  return writeRoutingResult(calibrationView(JSON.parse(roster), activity?.code === 0 ? activity.stdout : "", strongest));
}

interface DisplayItem {
  row: ObservedRow;
  prefix: string;
}

function parseSessionAndWindow(row: ObservedRow): { session: string; windowIndex: number } {
  const pane = row.pane || "";
  let session = row.session || "";
  let windowIndex = 0;
  const colon = pane.indexOf(":");
  if (colon !== -1) {
    const paneSession = pane.slice(0, colon);
    if (paneSession) session = paneSession;
    const rest = pane.slice(colon + 1);
    const dot = rest.indexOf(".");
    const windowStr = dot === -1 ? rest : rest.slice(0, dot);
    const num = Number.parseInt(windowStr, 10);
    if (!Number.isNaN(num)) windowIndex = num;
  }
  return { session, windowIndex };
}

function buildHumanRosterRows(rows: ObservedRow[]): DisplayItem[] {
  const sessionParents = new Map<string, ObservedRow[]>();
  for (const row of rows) {
    if (!row.crew) {
      const { session } = parseSessionAndWindow(row);
      if (session) {
        const list = sessionParents.get(session) ?? [];
        list.push(row);
        sessionParents.set(session, list);
      }
    }
  }

  const childrenByParent = new Map<string, { row: ObservedRow; windowIndex: number }[]>();
  const rootlessCrew: { row: ObservedRow; session: string }[] = [];
  const rootlessSet = new Set<ObservedRow>();
  const ambiguousSessions = new Map<string, { parent: ObservedRow; candidateCount: number }>();

  for (const row of rows) {
    if (row.crew) {
      const { session, windowIndex } = parseSessionAndWindow(row);
      const candidateParents = session ? sessionParents.get(session) : undefined;
      if (!candidateParents || candidateParents.length === 0) {
        rootlessCrew.push({ row, session });
        rootlessSet.add(row);
      } else {
        const parent = candidateParents[0]!;
        if (candidateParents.length > 1 && !ambiguousSessions.has(session)) {
          ambiguousSessions.set(session, { parent, candidateCount: candidateParents.length });
        }
        const children = childrenByParent.get(parent.handle) ?? [];
        children.push({ row, windowIndex });
        childrenByParent.set(parent.handle, children);
      }
    }
  }

  // Diagnostic class 1: rootless crew defect — at most ONE stderr line per invocation
  if (rootlessCrew.length === 1) {
    const c = rootlessCrew[0]!;
    process.stderr.write(`tap team: warning: crew seat '${c.row.handle}' has no parent seat in session '${c.session}' — see tap-zhx82\n`);
  } else if (rootlessCrew.length > 1) {
    const seats = rootlessCrew.map((c) => `'${c.row.handle}' (session '${c.session}')`).join(", ");
    process.stderr.write(`tap team: warning: crew seats ${seats} have no parent seat — see tap-zhx82\n`);
  }

  // Diagnostic class 2: ambiguous session parents — at most ONE stderr line per invocation
  if (ambiguousSessions.size === 1) {
    const [session, info] = [...ambiguousSessions.entries()][0]!;
    process.stderr.write(`tap team: warning: multiple parent seats for session '${session}' — nesting under '${info.parent.handle}'; see tap-7ph7f\n`);
  } else if (ambiguousSessions.size > 1) {
    const summary = [...ambiguousSessions.entries()].map(([s, info]) => `'${s}' (nesting under '${info.parent.handle}')`).join(", ");
    process.stderr.write(`tap team: warning: multiple parent seats for sessions ${summary}; see tap-7ph7f\n`);
  }

  // Sort children by window index under each parent; stable sort preserves roster order for equal window indices
  for (const children of childrenByParent.values()) {
    children.sort((a, b) => a.windowIndex - b.windowIndex);
  }

  const display: DisplayItem[] = [];
  for (const row of rows) {
    if (!row.crew) {
      display.push({ row, prefix: "" });
      const children = childrenByParent.get(row.handle);
      if (children && children.length > 0) {
        for (let i = 0; i < children.length; i++) {
          const isLast = i === children.length - 1;
          const prefix = isLast ? "`-- " : "|-- ";
          display.push({ row: children[i]!.row, prefix });
        }
      }
    } else if (rootlessSet.has(row)) {
      display.push({ row, prefix: "" });
    }
  }

  return display;
}

function socketLabel(path: string): string {
  // TMUX_TMPDIR namespaces commonly all end in "default"; retain that path.
  return basename(path) === "default" ? path : basename(path);
}

function renderHuman(team: string, rows: ObservedRow[], all: boolean): void {
  process.stdout.write(`tap ${process.env.TAP_TEAM_LIST_VERB || "team"}: ${team || "(unnamed)"}\n`);
  if (all) {
    process.stdout.write(table(
      ["handle", "kind", "harness", "pane", "status", "attached", "unattended", "reason", "notes/asks"],
      rows.map((row) => [
        row.handle, row.crew ? "CREW" : "SEAT", row.harness, row.pane, row.status,
        row.attached && row.attached !== "0" ? "yes" : "no", row.unattended ? "yes" : "no", row.foreignNamespace ? `bound under ${socketLabel(row.serverSocket!)}` : row.statusReason, `${row.digestWindow ?? 10}s/${row.askWindow ?? 10}s`,
      ]),
    ));
  } else {
    const displayItems = buildHumanRosterRows(rows);
    process.stdout.write(table(
      ["handle", "harness", "state", "context", "preset"],
      displayItems.map(({ row, prefix }) => [
        prefix + row.handle, row.harness, humanAgent(row) + (row.foreignNamespace ? ` (bound under ${socketLabel(row.serverSocket!)})` : ""),
        row.tokenSample?.input_tokens == null ? "—" : formatContextTokens(row.tokenSample),
        row.preset || "-",
      ]),
    ));
  }
}

/**
 * `tap team shutdown [<team>]` positional scan (H1 tap-team.sh L22-135): a
 * pure pre-parse of the arguments after the subcommand. Option-shaped tokens
 * (including -h) are never team names; --except/--only CONSUME the next token
 * as their value; the first bare token is the target team and a second bare
 * token is an extra-argument error. The target is removed from the arguments
 * handed to the engine — the engine's own bare-arg refusal still guards the
 * remainder.
 */
export function scanShutdownPositional(args: readonly string[]): { target?: string; extra: boolean; rest: string[] } {
  let target: string | undefined;
  let extra = false;
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const arg = args[i]!;
    if (!arg.startsWith("-")) {
      if (target === undefined) {
        target = arg;
        continue; // positional never reaches the engine
      }
      extra = true;
      rest.push(arg);
      continue;
    }
    rest.push(arg);
    if (arg === "--except" || arg === "--only") {
      const value = args[i + 1];
      if (value !== undefined) {
        rest.push(value);
        i++;
      }
    }
  }
  return { target, extra, rest };
}

function realPathOrSelf(path: string): string {
  try {
    return realpathSync(path);
  } catch {
    return path;
  }
}

/** The pane-observe record `tap_pane_observe` returns (lib.sh L8236): first
 * line of the display-message fields; an empty pane_id is a failed
 * observation. Consumers read the SECOND tab field as the session key. */
function paneObserve(paneTarget: string): string | null {
  const result = spawnSync("tmux", ["display-message", "-p", "-t", paneTarget, "#{pane_id}\t#{session_name}\t#{pid}:#{start_time}"], {
    encoding: "utf8", env: process.env,
  });
  const line = (result.stdout ?? "").split("\n")[0] ?? "";
  const paneId = line.split("\t")[0] ?? "";
  if (result.status !== 0 || !line || !paneId) return null;
  return line;
}

function liveLifecycleTmux(): LifecycleTmux {
  return {
    hasSession: name => spawnSync("tmux", ["has-session", "-t", `=${name}`], { env: process.env }).status === 0,
    // Liveness-first, matching lib.sh tap_pane_alive: a pane that answers no
    // pane_id is GONE — never read a session name off it (a stale tip would
    // classify a dead row as pane_live_elsewhere instead of unproven). And a
    // tip that answers a DIFFERENT pane id is gone too (the tip moved or the
    // id was recycled): the answer must EXACTLY equal the requested paneId,
    // or the row is treated as unproven — a name-keyed stop on the canonical
    // session still authorizes, per the incumbent authorizer (U4B driver
    // ruling on the crew-late blocker).
    paneSession: paneId => {
      const probe = spawnSync("tmux", ["display-message", "-p", "-t", paneId, "#{pane_id}"], { encoding: "utf8", env: process.env });
      if (probe.status !== 0 || (probe.stdout ?? "").trim() !== paneId) return null;
      const result = spawnSync("tmux", ["display-message", "-p", "-t", paneId, "#{session_name}"], { encoding: "utf8", env: process.env });
      const name = (result.stdout ?? "").trim();
      return result.status === 0 && name ? name : null;
    },
    sessionPaneIds: name => {
      const result = spawnSync("tmux", ["list-panes", "-t", `=${name}`, "-F", "#{pane_id}"], { encoding: "utf8", env: process.env });
      if (result.status !== 0) return [];
      return (result.stdout ?? "").split("\n").filter(l => l.trim().length > 0);
    },
  };
}

export function cmdTeamShutdown(args: string[], _scriptsDir: string): number {
  return runTeamStopDoor("shutdown", args);
}

export function cmdTeamDown(args: string[], _scriptsDir: string): number {
  return runTeamStopDoor("down", args);
}

// The one shared body behind every public stop door — `tap team down`,
// `tap team shutdown [<team>]`, and the private `reset-stop` CLI — so no
// lifecycle decision exists twice. The module CLI in stop.ts decodes its own
// argv and lands here.
export function runTeamStopDoor(verb: StopVerb, args: string[]): number {
  const entrance = verb === "shutdown" ? applyShutdownEntrance(args) : { target: undefined, rest: args };
  const ctx = verb === "shutdown"
    ? resolveContext(process.cwd(), process.env, { explicitTeam: entrance.target })
    : resolveContext(process.cwd(), process.env);
  // The internal reset-stop door has no fence: it runs INSIDE the reset's own
  // fenced window (U3). The public doors carry the incumbent's full
  // `tap team <verb>` label in the fence refusal (H1 tap_reset_fence_guard).
  if (verb !== "reset-stop") assertResetUnfenced(ctx.bus.home, `tap team ${verb}`);
  const roster = registryRoster(ctx.registryPath);
  // Entrance policies are the incumbent's: down suspends, shutdown clears,
  // and reset-stop runs policy `none` — reset owns the registry itself.
  const policy: RegistryPolicy = verb === "down" ? "suspend" : verb === "shutdown" ? "clear" : "none";
  return runTeamStop({
    verb,
    policy,
    argv: entrance.rest,
    ctx,
    roster,
    effects: productionStopEffects(ctx),
    fenced: verb !== "reset-stop",
  });
}

// applyShutdownEntrance holds the H1 door precedence for
// `tap team shutdown [<team>]`: positional scan (selector values are skipped,
// so a selector still applies within the named team), then the JSON export +
// invalid-flip gate (corrupt authority refuses before anything else), then
// named-target validation.
function applyShutdownEntrance(args: string[]): { target?: string; rest: string[] } {
  const scan = scanShutdownPositional(args);
  const target = scan.target;
  if (args.includes("--json")) process.env.TAP_JSON = "1";
  if (flipMarkerState() === "invalid") {
    throw new TapError(
      1,
      "invalid_flip",
      "tap doctor",
      "tap team shutdown refused — global-registry.json is present but unreadable or wrong schema",
      "tap team",
    );
  }
  if (target) {
    if (scan.extra) {
      throw new TapError(1, "usage_error", "tap help team shutdown", `unexpected extra argument after team '${target}'`, "tap team");
    }
    const sel = process.env.TAP_TEAM_SELECT;
    if (sel && sel !== target) {
      throw new TapError(1, "usage_error", "tap help team shutdown", `TAP_TEAM_SELECT='${sel}' conflicts with named target '${target}'`, "tap team");
    }
    if (process.env.TAP_BUS_RULE === "env") {
      const enrolled = resolveEnrolledTeamRoot(target);
      if (enrolled.kind !== "ok") {
        throw new TapError(
          1,
          "not_found",
          "tap register",
          `team '${target}' is not enrolled in the machine index — cannot match it against the pinned TAP_HOME`,
          "tap team",
        );
      }
      const pinBus = busHomeForEnrolled(enrolled.root);
      if (realPathOrSelf(pinBus) !== realPathOrSelf(process.env.TAP_HOME ?? "")) {
        const abs = realPathOrSelf(process.env.TAP_HOME ?? "");
        throw new TapError(
          1,
          "usage_error",
          "tap help team shutdown",
          `pinned TAP_HOME '${abs}' is not team '${target}' bus ('${pinBus}') — refusing to override a caller pin`,
          "tap team",
        );
      }
      // lib.sh derives TAP_REGISTRY="$TAP_HOME/registry.json" for every
      // exported TAP_HOME, so that exact value carries no caller intent — only
      // a DIFFERENT TAP_REGISTRY is a genuine acting-registry pin and must be
      // honored (H1 compares the raw value, not a canonical one).
      const pinRegistry = process.env.TAP_REGISTRY;
      if (pinRegistry && pinRegistry !== `${process.env.TAP_HOME ?? ""}/registry.json`) {
        const acting = actingRegistryForTeamOverride(target, pinBus);
        const pinRegAbs = `${realPathOrSelf(dirname(pinRegistry))}/${basename(pinRegistry)}`;
        if (pinRegAbs !== acting) {
          throw new TapError(
            1,
            "usage_error",
            "tap help team shutdown",
            `pinned TAP_REGISTRY '${pinRegAbs}' is not team '${target}' acting registry ('${acting}') — refusing to override a caller pin`,
            "tap team",
          );
        }
      }
    } else {
      applyTeamOverride(target);
    }
    // The named positional became TAP_TEAM_SELECT (landed H1): downstream
    // same-process helpers keep the incumbent env contract, and the explicit
    // context parameter below does not erase it.
    process.env.TAP_TEAM_SELECT = target;
  }
  return { target, rest: scan.rest };
}

export function productionStopEffects(ctx: ResolvedContext): StopEffects {
  const identityObservation = observeCallingPane(process.env);
  return {
    tmux: liveLifecycleTmux(),
    killSession: session => spawnSync("tmux", ["kill-session", "-t", `=${session}`], { env: process.env }).status === 0,
    hasSession: session => spawnSync("tmux", ["has-session", "-t", `=${session}`], { env: process.env }).status === 0,
    paneCount: session => liveLifecycleTmux().sessionPaneIds(session).length,
    observeSpare: paneObserve,
    queueSummary: handles => teamStopQueueSummary(ctx.bus.payloadsDir, ctx.bus.receiptsDir, ctx.team, handles),
    watch: {
      isArmed: () => Boolean(readLoose(armPath(ctx.bus.home))),
      clearTints: () => clearTints(ctx.bus.home),
      disarm: () => disarm(armPath(ctx.bus.home)),
    },
    identity: {
      tmuxActive: Boolean(process.env.TMUX),
      callingPaneId: identityObservation.state === "inside" ? identityObservation.paneId : "",
      callingPaneRefusal: identityObservation.state === "unobservable" ? identityObservation.refusal
        : identityObservation.state === "outside" ? identityObservation.detail : "",
      selfRefusal: identityObservation.state === "unobservable" && identityObservation.unverifiable ? "generation_unverifiable" : "",
      resolveSelf: () => {
        const observation = callingPane(process.env);
        if (!observation || observation.status !== "ok") return null;
        try {
          const self = resolveSelf(ctx, observation, 2);
          return { handle: self.handle, pane: self.pane, paneId: self.paneId };
        } catch {
          return null;
        }
      },
      displaySession: paneTarget => {
        const result = spawnSync("tmux", ["display-message", "-p", "-t", paneTarget, "#{session_name}"], { encoding: "utf8", env: process.env });
        return result.status === 0 ? (result.stdout ?? "").trim() : "";
      },
    },
    runId: process.env.TAP_TEAM_STOP_RUN_ID || String(process.pid),
    eventLog: join(ctx.bus.home, "registry-events.log"),
    io: {
      stdout: line => process.stdout.write(`${line}\n`),
      stderr: line => process.stderr.write(`${line}\n`),
      // The stop engine emits complete `tap team <verb>: warning: ...` lines;
      // pass them through unchanged or every warning would be double-prefixed.
      warn: line => process.stderr.write(`${line.endsWith("\n") ? line : `${line}\n`}`),
    },
  };
}

export function cmdTeam(argv: string[], scriptsDir: string): number {
  if (argv.length <= 2 && ["help", "-h", "--help"].includes(argv.at(-1) ?? "")) {
    const result = helpArgv(["team", ...argv]);
    process.stdout.write(result.stdout); process.stderr.write(result.stderr); return result.exit;
  }
  const withContextDetails = argv.includes("--context");
  argv = argv.filter(arg => arg !== "--context");
  // Machine-wide discovery must work before resolving the caller's cwd bus.
  if (argv[0] === "list") {
    const args = argv.slice(1);
    const name = args[0];
    if (name && !name.startsWith("-")) return cmdTeam(["roster", ...args], scriptsDir);
    const result = spawnSync("bun", [resolve(scriptsDir, "../../../runtime/bun/src/routing.ts"), "teams", ...args], {
      encoding: "utf8", env: process.env, maxBuffer: REGISTRY_MAX_BUFFER,
    });
    if (result.stdout) process.stdout.write(result.stdout);
    if (result.stderr) process.stderr.write(result.stderr);
    const rc = result.status ?? 1;
    if (rc === 0) process.stdout.write("to see seats on this team: tap team (or tap team roster)\n");
    return rc;
  }

  // `refresh` is its own verb file: it MUTATES the registry, where every other
  // form here reads. Dispatching before the roster's option parser also keeps
  // refresh's own refusal vocabulary (`tap help team refresh`) intact rather
  // than laundering it through the roster's.
  if (argv[0] === "refresh") return cmdRefresh(argv.slice(1), scriptsDir);
  // `attach` opens viewers: its own option grammar and refusal vocabulary,
  // dispatched before the roster parser for the same reason refresh is.
  if (argv[0] === "doctor") return cmdTeamDoctor(argv.slice(1));
  if (argv[0] === "attach") return cmdTeamAttach(argv.slice(1), scriptsDir);
  if (argv[0] === "detach") return cmdTeamDetach(argv.slice(1));
  if (argv[0] === "up") return teamUp(argv.slice(1), scriptsDir);
  if (argv[0] === "purge") {
    const ctx = teamContext();
    return cmdTeamPurge(argv.slice(1), join(ctx.bus.home, "archive/team-reset"));
  }
  if (argv[0] === "reset") return cmdTeamReset(argv.slice(1));
  if (argv[0] === "restore") return cmdTeamRestore(argv.slice(1));
  // `shutdown` is the destructive clear and `down` the suspend stop: both are
  // the engine's own grammar, dispatched before the roster parser so the
  // stop's refusal vocabulary stays its own (H1 tap-team.sh L22-135).
  if (argv[0] === "shutdown") return cmdTeamShutdown(argv.slice(1), scriptsDir);
  if (argv[0] === "down") return cmdTeamDown(argv.slice(1), scriptsDir);

  const rosterAlias = argv[0] === "roster";
  const calibrating = argv[0] === "calibration";
  if (calibrating && argv.slice(1).some(arg => arg !== "--strongest")) throw new TapError(1, "usage_error", "tap help team", "usage: tap team calibration [--strongest]", "tap team calibration");
  const args = calibrating ? ["--json"] : initialArgs(argv);
  let options: TeamOptions;
  try {
    options = parseOptions(args, rosterAlias);
  } catch (error) {
    if (rosterAlias && error instanceof TapError) {
      process.stderr.write(`tap team roster: ${error.detail}; next: ${humanAction(error.action)}\n`);
      return error.code;
    }
    throw error;
  }

  let ctx: ResolvedContext;
  try {
    ctx = teamContext(options.team);
  } catch (error) {
    if (error instanceof TapError) {
      if (options.json) {
        jsonRefusal(error);
        return error.code;
      }
      let detail = error.detail;
      if (error.errorClass === "live_unreachable" && options.team) {
        try {
          const indexHome = process.env.TAP_INDEX_HOME;
          const globalPath = globalRegistryPath(indexHome);
          const r = resolveTeamFromGlobal(globalPath, options.team);
          if (r.root) {
            const cleanRoot = r.root.replace(/\r/g, "\\r").replace(/\n/g, "\\n");
            const cleanTeam = options.team.replace(/\r/g, "\\r").replace(/\n/g, "\\n");
            detail = `acting registry for team '${cleanTeam}' (root '${cleanRoot}') is unreachable`;
          }
        } catch {
          // Keep existing detail if index cannot be read
        }
      }
      const label = rosterAlias ? "tap team roster" : "tap team";
      process.stderr.write(`${label}: ${detail}; next: ${humanAction(error.action)}\n`);
      return error.code;
    }
    throw error;
  }
  if (!options.team) {
    ctx.bus.ensureDirs();
  }
  const crewOnly = process.env.TAP_TEAM_CREW_ONLY === "1";
  const registry = readRegistry(ctx.registryPath, options.json, crewOnly);
  if (!registry.ok) {
    if (calibrating) {
      process.stderr.write(`tap team calibration: acting registry unreadable; repair or restore the acting registry file (tap doctor names it), then retry\n`);
    } else if (registry.rawError) {
      process.stdout.write(registry.rawOutput || "");
      process.stderr.write(registry.error || (registry.rawOutput ? "" : "registry reader failed\n"));
    } else if (options.json) {
      process.stdout.write(`${ensureAscii(JSON.stringify({ team: null, agents: [], error: registry.error || "" }))}\n`);
    } else {
      process.stderr.write(`tap team: registry unreadable (${registry.error || "unknown error"}) — run: tap doctor\n`);
    }
    return 42;
  }

  if (!options.team && !options.json && !options.names && !crewOnly) repoSetupHeadsUp(ctx.root);

  const renderedTeam = options.team ? ctx.team : str(registry.team);
  const archiveHint = !options.json && !options.names && !crewOnly ? archiveNudge(ctx.bus.home) : "";
  const sourceRows = registry.rows ?? [];
  if (options.names && sourceRows.length === 0) return 0;
  if (options.names && !options.active) {
    for (const row of sourceRows) {
      const handle = str(row.handle);
      if (handle) process.stdout.write(`${handle}\n`);
    }
    return 0;
  }
  if (sourceRows.length === 0) {
    if (calibrating) return calibration(JSON.stringify({ team: ctx.team, agents: [] }), argv.includes("--strongest"));
    if (options.json) process.stdout.write(`${JSON.stringify({ team: options.team ? ctx.team : null, agents: [] })}\n`);
    else if (crewOnly) process.stdout.write("tap crew list: no crew registered\n");
    else process.stdout.write("tap team: no agents registered yet — start one: tap session launch <preset|harness> [name]\n");
    if(archiveHint)process.stdout.write(archiveHint+"\n");
    return 0;
  }

  const observation = observe(sourceRows, scriptsDir);
  if (observation.code !== 0) {
    if (options.json) jsonRefusal(new TapError(observation.code, "classifier_failed", "tap doctor",
      "seat classifier failed; roster unavailable"));
    return observation.code;
  }
  const facts = options.names ? {} : presetFacts(sourceRows);
  const socket = sourceRows.some(row => str(row.server_socket)) ? tmuxReadOnly(["display-message", "-p", "#{socket_path}"]) : null;
  const callerSocket = socket?.code === 0 && socket.stdout.trim().startsWith("/") ? socket.stdout.trim() : "";
  const rows = observedRows(sourceRows, observation.rows, observation.serverEpoch, facts, callerSocket);
  if (options.names) {
    for (const row of rows) {
      if (row.delivery !== "poll" && row.status === "active") process.stdout.write(`${row.handle}\n`);
    }
  } else if (options.json) {
    const queue = withContextDetails ? contextQueueFacts(ctx.bus.home, ctx.marker === "live" ? globalRegistryPath() : legacyTeamsPath(), renderedTeam, rows.map(row => row.handle), Number(process.env.TAP_WATCH_NOW || Math.trunc(Date.now() / 1000))) : {};
    const json = rosterJson(renderedTeam, withTokenSamples(withAgentStates(rows), observation.panePids), facts, queue);
    if (calibrating) return calibration(json, argv.includes("--strongest"));
    process.stdout.write(json);
  } else {
    const all = options.all || crewOnly;
    const sampledRows = all ? rows : withTokenSamples(withAgentStates(rows), observation.panePids);
    renderHuman(renderedTeam, sampledRows, all);
    if (!all) {
      const missingSamples = sampledRows.filter((row) => row.status === "active" && row.delivery === "pane" &&
        !row.foreignNamespace && /^(claude|codex)(?:-|$)/.test(row.harness) &&
        row.tokenSample?.input_tokens == null).map((row) => row.handle);
      if (missingSamples.length) process.stdout.write(`Warning: stats unavailable for ${missingSamples.join(", ")}. Session bindings may be stale. Run \`tap team doctor\` to diagnose.\n`);
    }
    if(archiveHint)process.stdout.write(archiveHint+"\n");
  }
  return 0;
}
