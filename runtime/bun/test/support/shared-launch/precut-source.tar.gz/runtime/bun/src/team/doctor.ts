import { renderRefusals } from "../error-line";
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { TapError } from "../context";
import { atomicWrite } from "../fsatomic";
import { loadRegistry, pyJson, seatMap, type Seat } from "../registry";
import { acquireRegistryLock } from "../panelock";
import { acquireResetMutationLock, markResetGenerationReused } from "../reset";
import { assertSelectionCurrent, selectCaller, SelectorError } from "../selector";
import { bootId, observePaneResult, physicalSocketPath, type PaneObservation } from "../tmux";
import { defaultProc, processStore, type Attribution } from "../session-store";
import { duplicateIdentityOwner } from "../session-identity-owner";
import { loads, type JsonMap } from "../watch-detect";

export interface Binding { pane: PaneObservation; identity: Attribution }
export type BindingResult = { binding: Binding; reason?: never } | { binding?: never; reason: string };

/** No caller environment IDs, directory guesses, or newest-file heuristics. */
export function observeBinding(row: Seat): BindingResult {
  if (!row || typeof row !== "object" || Array.isArray(row)) return { reason: "malformed registry row" };
  if (row.delivery === "poll" || (Object.hasOwn(row, "status") && row.status !== "active") || row.status_reason || row.launch_token)
    return { reason: "seat is not an active pane seat" };
  if (row.harness !== "claude" && row.harness !== "codex") return { reason: "harness does not expose a process-held transcript" };
  if (!row.server_socket || row.server_socket !== physicalSocketPath() || !row.boot_id || row.boot_id !== bootId())
    return { reason: "pane namespace or boot identity is unavailable or different" };
  if (typeof row.pane_id !== "string" || !/^%\d+$/.test(row.pane_id)) return { reason: "pane identity is missing" };
  const before = observePaneResult(row.pane_id);
  if (before.status !== "ok") return { reason: "pane is unavailable" };
  const pane = before.observation;
  if (pane.paneId !== row.pane_id || pane.session !== row.session || pane.serverEpoch !== row.server_epoch)
    return { reason: "pane generation differs from registration" };
  if (typeof row.registered_from_worktree !== "string" || !row.registered_from_worktree)
    return { reason: "registered worktree is unavailable" };
  try {
    const identity = processStore(defaultProc, row.harness, row.registered_from_worktree, homedir(), pane.panePid);
    const after = observePaneResult(row.pane_id);
    if (!identity || after.status !== "ok" || JSON.stringify(after.observation) !== JSON.stringify(pane))
      return { reason: "current session identity is ambiguous or unavailable" };
    return { binding: { pane, identity } };
  } catch { return { reason: "current session identity is unavailable" }; }
}

export function bindingDiffers(row: Seat, binding: Binding): boolean {
  return row.harness_session_id !== binding.identity.harness_session_id || row.transcript_path !== binding.identity.store_path;
}

/** Operator repair changes only session attribution, retaining seat instance and custody. */
export function applyBinding(row: Seat, binding: Binding): void {
  const identity = binding.identity;
  const previous = { harness_session_id: row.harness_session_id ?? null, transcript_path: row.transcript_path ?? null,
    identity_capture: row.identity_capture ?? null, identity_capture_result: row.identity_capture_result ?? null };
  row.harness_session_id = identity.harness_session_id;
  row.transcript_path = identity.store_path;
  row.session_store_path = identity.store_path;
  row.session_store_kind = identity.store_kind;
  row.session_attribution_trust = "process";
  row.session_attribution_detail = identity.detail;
  row.session_attribution_candidates = identity.candidates;
  row.derived_at = identity.derived_at || new Date().toISOString();
  row.identity_capture_result = { decision: "accepted", mode: "operator_rebind", observed_harness_session_id: identity.harness_session_id,
    previous, observed_at: new Date().toISOString() };
  // A repaired binding supersedes the old launch expectation, not seat ownership.
  delete row.identity_capture;
  delete row.quarantined_harness_session_id;
  delete row.quarantined_transcript_path;
  delete row.identity_quarantine_reason;
}

export function cmdTeamDoctor(argv: string[], observe: (row: Seat) => BindingResult = observeBinding): number {
  if (argv.includes("--json")) process.env.TAP_JSON = "1";
  let dryRun = true, json = false;
  let only: string | undefined;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--fix") dryRun = false;
    else if (arg === "--json") json = true;
    else if (arg === "--only" && only === undefined && argv[i + 1] && !argv[i + 1]!.startsWith("-")) {
      only = argv[++i]!;
      if (only !== "session-binding") throw new TapError(1, "usage_error", "tap help team", `unknown check '${only}'; available: session-binding`);
    } else throw new TapError(1, "usage_error", "tap help team", `unexpected argument '${arg}'`);
  }
  let selection;
  try { selection = selectCaller({ cwd: process.cwd(), verbClass: "lifecycle" }); }
  catch (error) {
    if (error instanceof SelectorError) throw new TapError(error.code, error.errorClass, error.action, error.detail);
    throw error;
  }
  const initialDoc = loadRegistry(selection.registryLocation);
  if (!initialDoc.seats || typeof initialDoc.seats !== "object" || Array.isArray(initialDoc.seats))
    throw new TapError(1, "old_store", "tap doctor", "team doctor requires a current seats registry; no migration performed");
  const initial = seatMap(initialDoc);
  const handles = Object.keys(initial).sort();
  const results: { handle: string; outcome: string; detail: string }[] = [];
  for (const handle of handles) {
    const row = initial[handle]!;
    const observed = observe(row);
    if (!observed.binding) { results.push({ handle, outcome: "skipped", detail: observed.reason }); continue; }
    if (!bindingDiffers(row, observed.binding)) { results.push({ handle, outcome: "unchanged", detail: "session and transcript match" }); continue; }
    const reset = acquireResetMutationLock(selection.busHome, "tap team doctor");
    try {
      const lock = acquireRegistryLock(selection.registryLocation);
      if (!lock) throw new TapError(1, "registry_busy", "retry tap team doctor", "registry lock unavailable");
      try {
        assertSelectionCurrent(selection, lock);
        const doc = loadRegistry(selection.registryLocation), current = seatMap(doc)[handle];
        if (!current || pyJson(current, 0) !== pyJson(row, 0)) {
          results.push({ handle, outcome: "skipped", detail: "registration changed during observation" }); continue;
        }
        const fresh = observe(current);
        if (!fresh.binding || fresh.binding.identity.harness_session_id !== observed.binding.identity.harness_session_id ||
            fresh.binding.identity.store_path !== observed.binding.identity.store_path ||
            JSON.stringify(fresh.binding.pane) !== JSON.stringify(observed.binding.pane)) {
          results.push({ handle, outcome: "skipped", detail: "pane or session changed during observation" }); continue;
        }
        const owner = duplicateIdentityOwner(fresh.binding.identity.harness_session_id, handle, String(current.harness),
          selection.registryLocation, loads(readFileSync(selection.registryLocation, "utf8")) as JsonMap,
          process.env.TAP_INDEX_HOME || join(homedir(), ".tap"));
        if (owner) { results.push({ handle, outcome: "skipped", detail: `session is already owned by ${owner}` }); continue; }
        if (!dryRun) {
          applyBinding(current, fresh.binding);
          markResetGenerationReused(selection.busHome, "tap team doctor");
          atomicWrite(selection.registryLocation, `${pyJson(doc, 0)}\n`);
        }
        results.push({ handle, outcome: dryRun ? "would_repair" : "repaired", detail: `${row.harness_session_id || "?"} -> ${fresh.binding.identity.harness_session_id}` });
      } finally { lock.release(); }
    } finally { reset.release(); }
  }
  // Like tap doctor, diagnostic warnings do not turn a sound bus into an error.
  const findings = results.map(result => ({
    severity: result.outcome === "would_repair" || result.outcome === "skipped" ? "warning" : "info",
    name: "session-binding", detail: { ...result, ...(result.outcome === "would_repair" ? { next: "tap team doctor --fix --only session-binding" } : {}) },
  }));
  if (json) process.stdout.write(`${JSON.stringify({ ok: true, bus: { home: selection.busHome, rule: selection.busRule },
    findings, summary: { torn: 0, unattributed: 0, clean: true } })}\n`);
  else for (const result of results) process.stdout.write(`tap team doctor: ${result.handle}: ${result.outcome} (${result.detail})\n`);
  return 0;
}

if (import.meta.main) {
  const args = process.argv.slice(2);
  process.exitCode = renderRefusals("tap team doctor", () => cmdTeamDoctor(args),
    {...process.env, TAP_JSON: args.includes("--json") ? "1" : process.env.TAP_JSON});
}
