import { LauncherError } from "./types";

export type PermissionMode = "bypass" | "auto";
export function permissionMode(value: unknown): PermissionMode {
  if (value === undefined) return "bypass";
  if (value === "bypass" || value === "auto") return value;
  throw new LauncherError('harness_permissions_invalid: permissions must be "bypass" or "auto"', "harness_permissions_invalid");
}
export function permissionArgv(harness: string, mode: PermissionMode): string[] {
  return harness === "claude"
    ? mode === "auto" ? ["--permission-mode", "auto"] : ["--dangerously-skip-permissions"]
    : mode === "auto" ? ["--approve-for-me"] : ["--dangerously-bypass-approvals-and-sandbox"];
}

/** Check each source before composition can hide an option behind a builder default. */
export function enforcePermissions(harness: string, mode: PermissionMode, args: string[]): void {
  if (mode !== "auto" || !["claude", "codex"].includes(harness)) return;
  for (let i = 0; i < args.length; i++) {
    const token = args[i]!;
    if (token === "--") break;
    const at = token.indexOf("=");
    const attached = harness === "codex" && /^-[csa].+/.test(token);
    const key = attached ? token.slice(0, 2) : at < 0 ? token : token.slice(0, at);
    const value = attached ? token.slice(2).replace(/^=/, "") : at < 0 ? args[i + 1] : token.slice(at + 1);
    const bypass = key === "--dangerously-skip-permissions" || key === "--dangerously-bypass-approvals-and-sandbox" || key === "--yolo";
    const conflict = harness === "claude"
      ? key === "--permission-mode" && value !== "auto"
      : (["--sandbox", "-s"].includes(key) && value !== "workspace-write") ||
        ["--ask-for-approval", "-a"].includes(key) ||
        (["--config", "-c"].includes(key) && /^(?:["\']?(?:sandbox_mode|approval_policy)["\']?)\s*=/.test((value ?? "").trim()));
    if (bypass || conflict) throw new LauncherError(`harness_permissions_conflict: ${key} contradicts [harness.${harness}] permissions = "auto"`, "harness_permissions_conflict");
  }
}
