// `tap team attach` — open viewers onto the current team's unattached live
// tmux sessions. Port of tap-team-attach.sh, deleted in the same PR.
//
// Shape, in order: options → selection gates → team root → session catalog
// snapshot → partition (live / unavailable / spared) → one client snapshot per
// live session (the seats already being viewed are skipped) → layout → the
// AppleScript plan → the four exits (empty plan, nothing new, dry-run, open)
// → a bounded proof that a NEW tmux client appeared for every planned seat.
//
// Reads the registry and asks tmux; never writes either. The only effect is
// osascript, and a successful osascript exit alone is not taken as proof: the
// verify loop looks for a client tty that was not in the pre-open snapshot.

import { spawnSync } from "node:child_process";
import { resolve } from "node:path";

import { TapError, resolveContext, type ResolvedContext } from "../context";
import { loadRegistry, seatMap } from "../registry";
import { REGISTRY_MAX_BUFFER } from "../spawn";
import { pythonStrip } from "../clear-fence";
import { physicalSocketPath, tmuxReadOnly } from "../tmux";
import { PartitionRefusal, partitionSnapshot, type Partitioned } from "../launcher/attach-partition";
import { renderRefusals, runEntry } from "../error-line";
import { itermViewerScript } from "../iterm-viewer";
import {
  crewSelectGate, lenientSeats, noSelection, parseSelection, registryRoster, rosterGate, selectConflictGate,
  selectFlag, selectOperand, selectSummary, selectTyped, type Selection,
} from "./selection";

const VERB = "team attach";
const LABEL = `tap ${VERB}`;

function fail(klass: string, action: string, detail: string): never {
  throw new TapError(1, klass, action, detail, LABEL);
}

function receipt(text: string, stream: NodeJS.WriteStream = process.stdout): void {
  stream.write(`${LABEL}: ${text}\n`);
}

interface Options {
  dryRun: boolean;
  tabs: boolean;
  exceptRaw?: string;
  onlyRaw?: string;
}

function parseArgs(argv: string[]): Options {
  let dryRun = false;
  let tabs = false;
  let exceptRaw: string | undefined;
  let onlyRaw: string | undefined;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!;
    switch (arg) {
      case "--dry-run": dryRun = true; break;
      case "--tabs": tabs = true; break;
      case "--except":
        if (i + 1 >= argv.length) {
          fail("usage_error", "tap team attach --except <handle>[,<handle>...]",
            "--except was given no value; name at least one handle to spare");
        }
        exceptRaw = argv[++i]!;
        break;
      case "--only":
        if (i + 1 >= argv.length) {
          fail("usage_error", "tap team attach --only <handle>[,<handle>...]",
            "--only was given no value; name at least one handle to act on");
        }
        onlyRaw = argv[++i]!;
        break;
      default:
        fail("usage_error", "tap help team", `unexpected argument '${arg}'`);
    }
  }
  // The gates run AFTER the whole argv is parsed, as the incumbent's did: a
  // usage error in a later token wins over a roster refusal from an earlier
  // one, and both flags together is checked before either value is parsed.
  return { dryRun, tabs, exceptRaw, onlyRaw };
}

/**
 * --except / --only (tap-nt4c, tap-sttl): parse + roster-gate before any
 * session snapshot, through the same shared path detach/down/up use. The
 * positive --only set travels to the planner, which applies it against the
 * snapshot it is about to act on — precomputing a complement here would freeze
 * an answer from an earlier registry read (sol-prepull P1).
 */
function gateSelection(ctx: ResolvedContext, exceptRaw: string | undefined, onlyRaw: string | undefined): Selection {
  if (exceptRaw !== undefined && onlyRaw !== undefined) selectConflictGate(VERB);
  if (exceptRaw !== undefined) {
    const selection = parseSelection(VERB, exceptRaw, "--except");
    rosterGate(VERB, selection, registryRoster(ctx.registryPath));
    crewSelectGate(VERB, selection, ctx.registryPath);
    return selection;
  }
  if (onlyRaw !== undefined) {
    const selection = parseSelection(VERB, onlyRaw, "--only");
    rosterGate(VERB, selection, registryRoster(ctx.registryPath));
    crewSelectGate(VERB, selection, ctx.registryPath);
    return selection;
  }
  return noSelection();
}

/**
 * The worktree the team's sessions were launched from — the registry's own
 * `team.worktree_root` when it says, else derived from the bus path the way
 * the incumbent did (`<root>/.tap/bus`, legacy `<root>/tmp/tap`, else the git
 * toplevel or cwd). The LOGICAL path is kept, not a realpath: it is handed to
 * `launcher.py list --cwd` and spelled into the AppleScript's `cd`, and the
 * incumbent spelled it exactly as the registry/bus had it.
 */
function teamRoot(ctx: ResolvedContext): string {
  let root = "";
  try {
    const doc = loadRegistry(ctx.registryPath);
    const team = doc.team;
    if (typeof team === "object" && team !== null && !Array.isArray(team)) {
      const raw = (team as Record<string, unknown>).worktree_root;
      // Python's `.strip()`, not JS `trim()`: the two disagree at both ends of
      // the whitespace set (U+FEFF is trimmed by JS and kept by Python; U+0085
      // and U+001C are kept by JS and stripped by Python), and a root that ends
      // in one of them selects a DIFFERENT DIRECTORY, not a different message
      // (sol-pinnacle-7 F1).
      if (typeof raw === "string") root = pythonStrip(raw);
    }
  } catch {
    // An unreadable registry is what the incumbent's `2>/dev/null || true`
    // swallowed: the bus-derived fallback answers instead.
  }
  if (root) return root;
  const home = ctx.bus.home;
  if (home.endsWith("/.tap/bus")) root = home.slice(0, -"/.tap/bus".length);
  else if (home.endsWith("/tmp/tap")) root = home.slice(0, -"/tmp/tap".length);
  else {
    const top = spawnSync("git", ["rev-parse", "--show-toplevel"], { encoding: "utf8", env: process.env });
    root = top.status === 0 ? top.stdout.replace(/\n$/, "") : process.cwd();
  }
  return root || "/";
}

/** `bun src/launcher/list.ts --json --cwd <root>`: the native producer's catalog — the python `list` subcommand was deleted with the S1 list port, and this bridge now consumes the same bytes the router serves. */
function catalogSnapshot(root: string): Uint8Array {
  const result = spawnSync("bun", [resolve(import.meta.dir, "../launcher/list.ts"), "--json", "--cwd", root], {
    env: process.env, maxBuffer: REGISTRY_MAX_BUFFER,
  });
  if (result.status !== 0) {
    // `$(cat "$sessions_err")` dropped the trailing newlines; tap_error_line
    // then flattened the embedded ones to spaces. The router's renderer does
    // not flatten, so the same two steps happen here to keep both doors
    // printing the incumbent's line.
    let detail = (result.stderr?.toString("utf8") ?? "").replace(/\n+$/, "");
    if (!detail) detail = "could not read the current team session catalog";
    fail("session_list_unavailable", "tap session list --json", detail.replace(/[\r\n]/g, " "));
  }
  return result.stdout ?? new Uint8Array();
}

interface ClientRow {
  session: string;
  handle: string;
  /** Comma-joined client ttys viewing the session at snapshot time. */
  clients: string;
}

function listClientTtys(session: string): string[] | null {
  const run = tmuxReadOnly(["list-clients", "-t", `=${session}`, "-F", "#{client_tty}"]);
  if (run.code !== 0) return null;
  return run.stdout.split("\n").filter(line => line.length > 0);
}

export interface Disclosures {
  clientRows: ClientRow[];
  rows: Partitioned;
  selection: Selection;
  /** The acting registry's path: the mark reader's only input. */
  registryPath: string;
}

function printAttachCommands(planned: readonly ClientRow[], stream: NodeJS.WriteStream, onlyHandles?: readonly string[]): void {
  for (const row of planned) {
    if (onlyHandles && !onlyHandles.includes(row.handle)) continue;
    stream.write(`  tmux attach -t '=${row.session}'\n`);
  }
}

export function printDisclosures(d: Disclosures, stream: NodeJS.WriteStream): void {
  const already = d.clientRows.filter(row => row.clients).map(row => `${row.handle} (${row.clients})`).join(", ");
  const spared = d.rows.excluded.map(row => `${row.handle} (${row.third})`).join(", ");
  // An incapable mark is the operator's statement, not a revive candidate:
  // advertising `tap session resume` for it would promise an action the
  // invariant forbids. Rows the acting registry carries as the exact
  // suspended/incapable pair get their own disclosure line pointing at
  // re-registration instead; every other unavailable row keeps the
  // incumbent's resume-tier line byte for byte. lenientSeats is the
  // incumbent's own softness: an unreadable registry reads as no marks, so
  // this stays a pure disclosure and never invents state.
  const incapable = new Set<string>();
  for (const [handle, row] of Object.entries(lenientSeats(d.registryPath))) {
    if (row.status === "suspended" && row.status_reason === "incapable") incapable.add(handle);
  }
  const suspended = d.rows.unavailable.filter(row => incapable.has(row.handle))
    .map(row => `${row.handle} is suspended (incapable); re-register from its pane: run 'tap in' there, or 'tap register ${row.handle} --pane <tmux-target>'`).join(", ");
  const unavailable = d.rows.unavailable
    .filter(row => !incapable.has(row.handle))
    .map(row => `${row.handle} (resume tier ${row.third}; next: tap session resume ${row.handle})`).join(", ");
  receipt(`skipped because already attached: ${already || "none"}`, stream);
  if (suspended) receipt(`incapable: ${suspended}`, stream);
  receipt(`unavailable: ${unavailable || "none"}`, stream);
  if (spared) {
    receipt(`spared by ${selectFlag(d.selection)}${selectOperand(d.selection, spared)}`, stream);
  } else if (selectFlag(d.selection) === "--only") {
    // Whole-roster --only spares nobody, and a receipt gated on a nonempty
    // spared list would then leave no trace of the selector at all — making a
    // whole-team attach indistinguishable from an unselected one
    // (sol-prepull P2; stop had this fix, these three did not).
    receipt(`--only ${selectTyped(d.selection)} matched every seat — none spared`, stream);
  }
}

interface Verification {
  verified: number;
  unverified: string[];
  postUnobservable: string[];
}

/** One pass: has every planned session gained a client tty it did not have before? */
function verifyNewClients(planned: readonly ClientRow[]): Verification {
  const out: Verification = { verified: 0, unverified: [], postUnobservable: [] };
  for (const row of planned) {
    const after = listClientTtys(row.session);
    if (after === null) {
      out.unverified.push(row.handle);
      out.postUnobservable.push(row.handle);
      continue;
    }
    const before = new Set(row.clients.split(","));
    if (after.some(tty => !before.has(tty))) out.verified++;
    else out.unverified.push(row.handle);
  }
  return out;
}

const VERIFY_ATTEMPT_LIMIT = 25;
const VERIFY_INTERVAL_MS = 200;

function iTermAutomationAvailable(): boolean {
  const which = spawnSync("osascript", ["-e", 'id of application "iTerm"'], { stdio: ["ignore", "ignore", "ignore"], env: process.env });
  return which.status === 0;
}

export function cmdTeamAttach(argv: string[], scriptsDir: string): number {
  return renderRefusals(LABEL, () => teamAttach(argv, scriptsDir));
}

function teamAttach(argv: string[], scriptsDir: string): number {
  const { dryRun, tabs, exceptRaw, onlyRaw } = parseArgs(argv);

  const ctx = attachContext();
  ctx.bus.ensureDirs();
  const team = ctx.team;
  if (!team) fail("registry_invalid", "tap register", "current team name is unavailable");

  const selection = gateSelection(ctx, exceptRaw, onlyRaw);

  const root = teamRoot(ctx);
  const snapshot = catalogSnapshot(root);

  let rows: Partitioned;
  try {
    rows = partitionSnapshot(snapshot, team, new Set(selection.except), new Set(selection.only));
  } catch (error) {
    // The planner's own sentence is the diagnostic, spelled as its CLI entry
    // spelled it (a refusal by its message, anything else by `String(error)`,
    // which keeps the `TypeError:` prefix); the exit class is the contract the
    // incumbent mapped every nonzero to.
    process.stderr.write(`${error instanceof PartitionRefusal ? error.message : String(error)}\n`);
    fail("session_list_invalid", "tap session list --json", "the current session snapshot could not be planned");
  }

  const clientRows: ClientRow[] = [];
  const planned: ClientRow[] = [];
  const disclosures: Disclosures = { clientRows, rows, selection, registryPath: ctx.registryPath };
  for (const row of rows.live) {
    const ttys = listClientTtys(row.name);
    if (ttys === null) {
      printDisclosures(disclosures, process.stderr);
      fail("session_unobservable", "retry tap team attach after tmux is observable",
        `could not snapshot existing viewers for '${row.name}'; no iTerm window was opened`);
    }
    const clientRow = { session: row.name, handle: row.handle, clients: ttys.join(",") };
    clientRows.push(clientRow);
    if (!clientRow.clients) planned.push(clientRow);
  }

  const liveCount = clientRows.length;
  const plannedCount = planned.length;
  const excludedLive = rows.excluded.filter(row => row.third === "live").length;

  const script = plannedCount > 0
    ? itermViewerScript(
        planned.map(row => ({ session: row.session, handle: row.handle })),
        root, physicalSocketPath(process.env), tabs)
    : "";

  if (liveCount === 0) {
    // Design call 4: when the exclusions are what emptied the live set, that
    // is a legal no-op (exit 0) with a line that names the set — not the "no
    // live seats" failure, which would blame the team for the operator's own
    // instruction. The gate is a spared LIVE seat: a team that had none to
    // begin with still fails.
    if (excludedLive > 0) {
      receipt(`no seats matched after ${selectSummary(selection)}`);
      printDisclosures(disclosures, process.stdout);
      return 0;
    }
    receipt(`no live seats for team '${team}'; no iTerm window was opened`);
    printDisclosures(disclosures, process.stdout);
    return 1;
  }

  if (plannedCount === 0) {
    receipt(`no new viewers needed for team '${team}'; all ${liveCount} live seat(s) were already attached`);
    printDisclosures(disclosures, process.stdout);
    return 0;
  }

  if (dryRun) {
    receipt(`plan for team '${team}' (${plannedCount} new viewer(s))`);
    printAttachCommands(planned, process.stdout);
    process.stdout.write(`${LABEL}: generated AppleScript:\n`);
    process.stdout.write(script);
    receipt("dry-run cannot prove attachment; no iTerm window was opened");
    printDisclosures(disclosures, process.stdout);
    return 0;
  }

  if (iTermAutomationAvailable()) {
    const run = spawnSync("osascript", ["-"], { input: script, stdio: ["pipe", "ignore", "inherit"], env: process.env });
    if (run.status !== 0) {
      process.stderr.write(`${LABEL}: iTerm automation failed; attach manually:\n`);
      printAttachCommands(planned, process.stderr);
      printDisclosures(disclosures, process.stderr);
      fail("automation_failed", "run the printed tmux attach commands", "iTerm did not accept the generated viewer plan");
    }
    let attempt = 1;
    let verification = verifyNewClients(planned);
    while (verification.unverified.length > 0 && attempt < VERIFY_ATTEMPT_LIMIT) {
      Bun.sleepSync(VERIFY_INTERVAL_MS);
      attempt++;
      verification = verifyNewClients(planned);
    }
    if (verification.unverified.length > 0) {
      receipt(`no new tmux client observed after ${attempt} bounded probe(s) for: ${verification.unverified.join(", ")}`, process.stderr);
      if (verification.postUnobservable.length > 0) {
        receipt(`post-open client probe unavailable for: ${verification.postUnobservable.join(", ")}`, process.stderr);
      }
      process.stderr.write(`${LABEL}: attachment proof incomplete; attach manually:\n`);
      printAttachCommands(planned, process.stderr, verification.unverified);
      printDisclosures(disclosures, process.stderr);
      fail("attachment_unverified", "run the printed tmux attach commands", "a new tmux client was not observed for every planned seat");
    }
    receipt(`verified ${verification.verified} new iTerm viewer(s) for team '${team}'`);
  } else {
    receipt("iTerm automation unavailable; run these attach commands");
    printAttachCommands(planned, process.stdout);
    receipt(`printed ${plannedCount} attach command(s) for team '${team}'`);
  }

  printDisclosures(disclosures, process.stdout);
  return 0;
}

/**
 * The bus and acting registry, through the shared selector. The incumbent's
 * `tap_ensure_dirs` + `tap_spool_team_name` + best-effort rebind reached the
 * same three facts (bus home, team name, acting registry path) by three
 * different roads; the selector answers all three at once.
 */
function attachContext(): ResolvedContext {
  try {
    return resolveContext(process.cwd(), process.env);
  } catch (error) {
    if (error instanceof TapError) throw new TapError(error.code, error.errorClass, error.action, error.detail, LABEL);
    throw error;
  }
}

if (import.meta.main) {
  const scriptsDir = resolve(import.meta.dir, "../../../../skills/tap/scripts");
  process.exitCode = runEntry(LABEL, () => cmdTeamAttach(process.argv.slice(2), scriptsDir));
}
