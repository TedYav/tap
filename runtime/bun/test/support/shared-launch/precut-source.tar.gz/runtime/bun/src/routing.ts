// Read-only ledger and fleet views. Preset metadata and seat observation belong
// to the native roster; the Markdown ledger supplies calibration only.
import { spawn } from "node:child_process";
import { existsSync, readdirSync, statSync } from "node:fs";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import { isRegularFile, legacyTeamsPath, loadGlobalRegistry, readIndexJson, resolveTeamFromDoc } from "./index-home";
import { seatMap } from "./registry";
import { PY_STRIP } from "./payload-fields";
import { pyFloatString, pyReadUtf8, pyTruthy } from "./spool-publication";
import { pyRepr, unicodeInt } from "./watch-detect";

type Result = { exit: number; stdout: string; stderr: string };
type Row = Record<"handle" | "model" | "harness" | "family" | "tier" | "speed" | "cost" | "voice" | "one_liner", string>;
type ObjectRow = Record<string, unknown>;
type Ledger = { banner: string; rows: Row[]; dispositions: Map<string, string> };
const HEADING = "## Routing table";
const REQUIRED = ["handle", "model @ harness", "family", "tier"];
const DEFAULT_VOICE = "sole-eligible";
const HARNESS_FAMILY = new Map([["claude", "anthropic"], ["codex", "openai"], ["agy", "google"]]);
const TIERS = new Map([["frontier", 3], ["advanced", 2], ["basic", 1]]);
const SPACE = "[\\u0009-\\u000d\\u001c-\\u0020\\u0085\\u00a0\\u1680\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000]";
const DISPOSITION = new RegExp(`^###${SPACE}+(.+?)${SPACE}*$`, "u");
const DATE = new RegExp(`(20\\p{Decimal_Number}{2})-(\\p{Decimal_Number}{2})-(\\p{Decimal_Number}{2})(?:${SPACE}*[\\u2013\\u2014-]${SPACE}*(\\p{Decimal_Number}{2})-(\\p{Decimal_Number}{2}))?`, "gu");
const strip = (s: string) => s.replace(PY_STRIP, "");
const length = (s: string) => Array.from(s).length;
const object = (v: unknown): v is ObjectRow => typeof v === "object" && v !== null && !Array.isArray(v);
const text = (v: unknown): string => typeof v === "string" ? v : "";
const success = (stdout: string): Result => ({ exit: 0, stdout, stderr: "" });
const failure = (stderr: string, exit = 1): Result => ({ exit, stdout: "", stderr });

function ledgerPath(): string {
  const raw = process.env.TAP_MODELS_LEDGER || join(homedir(), ".tap/seat-calibration.md");
  // Pathlib removes '.' and repeated separators, but never resolves '..'.
  const prefix = raw.startsWith("//") && !raw.startsWith("///") ? "//" : raw.startsWith("/") ? "/" : "";
  return prefix + raw.split("/").filter(part => part && part !== ".").join("/") || ".";
}

function readText(path: string): string {
  return pyReadUtf8(path).replace(/\r\n?/g, "\n");
}

function splitLines(s: string): string[] {
  const lines = s.split(/\r\n|[\n\v\f\r\u001c-\u001e\u0085\u2028\u2029]/);
  if (lines.at(-1) === "") lines.pop();
  return lines;
}

class LedgerError extends Error {}

function parseLedger(path: string): Ledger {
  if (!existsSync(path)) throw new LedgerError(`seat-calibration ledger not found: ${path}`);
  const lines = splitLines(readText(path));
  const start = lines.findIndex(line => strip(line).startsWith(HEADING));
  if (start < 0) throw new LedgerError(`'${HEADING}' section not found in ${path} — the ledger has no routing table to render (expected the pipe table \`tap models\` reads).`);
  let banner = "";
  for (let i = start + 1; i < lines.length && !strip(lines[i]!).startsWith("|"); i++) {
    const line = strip(lines[i]!);
    if (line && !line.startsWith("#")) { banner = line.split(". ", 1)[0]!.replace(/\.+$/, "") + "."; break; }
  }
  const rows: Row[] = [];
  let headers: Map<string, number> | undefined;
  for (const raw of lines.slice(start + 1)) {
    if (raw.startsWith("## ")) break;
    const line = strip(raw);
    if (!line.startsWith("|")) continue;
    const cells = line.replace(/^\|+|\|+$/g, "").split("|").map(strip);
    if (!headers) {
      headers = new Map(cells.map((name, i) => [name.toLowerCase(), i]));
      const missing = REQUIRED.filter(name => !headers!.has(name));
      if (missing.length) throw new LedgerError(`Routing table in ${path} is missing required column(s): ${missing.join(", ")} — header row is [${cells.join(" | ")}]. A renamed/removed routing column would silently mis-route a consumer, so this fails loud rather than rendering blanks.`);
      continue;
    }
    if (/^[-: ]*$/.test(cells.join(""))) continue;
    const columns = headers;
    const col = (name: string) => cells[columns.get(name) ?? -1] ?? "";
    const handle = col("handle");
    if (!handle) continue;
    const modelHarness = col("model @ harness"), at = modelHarness.indexOf(" @ ");
    rows.push({ handle, model: at < 0 ? modelHarness : strip(modelHarness.slice(0, at)),
      harness: at < 0 ? "" : strip(modelHarness.slice(at + 3)), family: col("family"),
      tier: col("tier"), speed: col("speed"), cost: col("cost"), voice: col("voice") || DEFAULT_VOICE,
      one_liner: col("one-liner") });
  }
  if (!headers) throw new LedgerError(`'${HEADING}' section in ${path} has no pipe table — nothing to render (expected a \`| handle | model @ harness | family | tier | … |\` row).`);
  const dispositions = new Map<string, string>();
  let current: string | undefined, buffer: string[] = [];
  const flush = () => { if (current !== undefined) dispositions.set(current, strip(buffer.join("\n"))); };
  for (const line of lines) {
    const match = DISPOSITION.exec(line);
    if (match) { flush(); current = match[1]!; buffer = []; }
    else if (current !== undefined) {
      if (line.startsWith("## ")) { flush(); current = undefined; buffer = []; }
      else buffer.push(line);
    }
  }
  flush();
  return { banner, rows, dispositions };
}

// The roster table truncates its last column; these views deliberately do not.
function table(headers: string[], body: string[][]): string {
  const widths = headers.map(length);
  for (const row of body) for (let i = 0; i < row.length - 1; i++) widths[i] = Math.max(widths[i]!, length(row[i]!));
  return [headers, ...body].map(row => row.map((cell, i) => i === row.length - 1 ? cell : cell + " ".repeat(widths[i]! - length(cell)))
    .join("  ").replace(/[\u0009-\u000d\u001c-\u0020\u0085\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]+$/u, "") + "\n").join("");
}

function catalog(rows: Row[]): string {
  return table(["HANDLE", "MODEL @ HARNESS", "FAMILY", "TIER", "SPEED", "COST", "VOICE", "ROUTES TO"],
    rows.map(row => [row.handle, `${row.model} @ ${row.harness}`, row.family, row.tier, row.speed, row.cost, row.voice, row.one_liner]));
}

const MODELS_USAGE = "usage: tap models [-h] [--all] [--full] [handle]\n";
const MODELS_HELP = MODELS_USAGE + "\npositional arguments:\n  handle\n\noptions:\n  -h, --help         show this help message and exit\n  --all\n  --full, --verbose\n";
const modelOptions = ["--help", "--all", "--full", "--verbose"];

function parseModels(argv: string[]): Result | { all: boolean; full: boolean; handle: string } {
  let all = false, full = false, handle = "", positional = false, ended = false;
  const extra: string[] = [];
  const optionError = (detail: string) => failure(`${MODELS_USAGE}tap models: error: ${detail}\n`, 2);
  for (const arg of argv) {
    if (!ended && arg === "--") { ended = true; continue; }
    if (!ended && arg.startsWith("-h=")) return optionError(`argument -h/--help: ignored explicit argument ${pyRepr(arg.slice(3))}`);
    if (!ended && arg.startsWith("-h")) return success(MODELS_HELP);
    if (!ended && arg.startsWith("--")) {
      const equal = arg.indexOf("="), name = equal < 0 ? arg : arg.slice(0, equal);
      const matches = modelOptions.filter(option => option.startsWith(name));
      if (matches.length > 1) return optionError(`ambiguous option: ${arg} could match ${matches.join(", ")}`);
      const option = matches[0];
      if (!option) { extra.push(arg); continue; }
      if (equal >= 0) return optionError(`argument ${option === "--help" ? "-h/--help" : option === "--all" ? "--all" : "--full/--verbose"}: ignored explicit argument ${pyRepr(arg.slice(equal + 1))}`);
      if (option === "--help") return success(MODELS_HELP);
      if (option === "--all") all = true;
      else full = true;
    } else if (!ended && arg.startsWith("-") && arg !== "-" && !/^-(?:\d+|\d*\.\d+)$/.test(arg)) extra.push(arg);
    else if (!positional) { handle = arg; positional = true; }
    else extra.push(arg);
  }
  // Preserve the existing deterministic error, including the legacy private
  // subparser name. Retiring an implementation does not change its exit/text API.
  if (extra.length) return failure(`usage: tap [-h] {models,team-calibration,teams} ...\ntap: error: unrecognized arguments: ${extra.join(" ")}\n`, 2);
  return { all, full, handle };
}

export function modelsView(argv: string[], path = ledgerPath()): Result {
  const args = parseModels(argv);
  if ("exit" in args) return args;
  if (args.full) return existsSync(path) ? success(readText(path)) : failure(`tap models: seat-calibration ledger not found: ${path}\n`);
  let ledger: Ledger;
  try { ledger = parseLedger(path); }
  catch (error) { if (error instanceof LedgerError) return failure(`tap models: ${error.message}\n`); throw error; }
  const { banner, rows, dispositions } = ledger;
  if (args.handle) {
    const match = rows.find(row => row.handle === args.handle);
    if (!match) return failure(`tap models: no catalog row for '${args.handle}' (known: ${rows.map(row => row.handle).join(", ")}); seats are \`tap team calibration\`\n`);
    const disposition = dispositions.get(args.handle);
    return success(catalog([match]) + (disposition ? `\n${disposition}\n` : "") + `\nHistory: see ${path}\n`);
  }
  let out = (banner ? `${banner}\n\n` : "") + catalog(rows);
  if (args.all) {
    out += "\nDispositions:\n";
    for (const row of rows) { const d = dispositions.get(row.handle); if (d) out += `\n### ${row.handle}\n${d}\n`; }
  } else out += "\ntap models --all for dispositions; <handle> for one; --full for the ledger. Who is on your team and reachable right now: tap team calibration.\n";
  return success(out);
}

export function compactAge(seconds: number): string {
  if (seconds < 90) return "just now";
  const [unit, suffix] = seconds < 90 * 60 ? [60, "m"] as const : seconds < 36 * 3600 ? [3600, "h"] as const : [86400, "d"] as const;
  const value = seconds / unit, floor = Math.floor(value);
  if (!Number.isFinite(value)) throw new Error("cannot round non-finite activity age");
  return `${value - floor === 0.5 && floor % 2 === 0 ? floor : Math.round(value)}${suffix}`;
}

function compare(a: string, b: string): number {
  const aa = Array.from(a, ch => ch.codePointAt(0)!), bb = Array.from(b, ch => ch.codePointAt(0)!);
  for (let i = 0; i < Math.min(aa.length, bb.length); i++) if (aa[i] !== bb[i]) return aa[i]! - bb[i]!;
  return aa.length - bb.length;
}

export function latestObservation(disposition: string): [string, string] {
  let bestRank = "", bestShown = "", bestText = "";
  for (const raw of splitLines(disposition)) {
    const line = strip(raw);
    if (!line.startsWith("- ")) continue;
    let rank = "", shown = "";
    for (const match of line.matchAll(DATE)) {
      const [, year, month, day, endMonth, endDay] = match;
      const date = endMonth ? `${unicodeInt(year!) + (compare(endMonth + endDay, month! + day!) < 0 ? 1n : 0n)}-${endMonth}-${endDay}` : `${year}-${month}-${day}`;
      if (compare(date, rank) > 0 || (date === rank && compare(match[0], shown) > 0)) { rank = date; shown = match[0]; }
    }
    if (rank && compare(rank, bestRank) >= 0) { bestRank = rank; bestShown = shown; bestText = strip(line.slice(2)); }
  }
  return [bestShown, bestText];
}

function attachedCell(value: unknown): string {
  if (value === "" || value === null || value === undefined) return "-";
  if (value === true || value === "true" || value === "yes") return "yes";
  if (typeof value === "number" && Number.isInteger(value)) return value > 0 ? "yes" : "no";
  if (typeof value === "string" && /^\p{Decimal_Number}+$/u.test(value)) return unicodeInt(value) > 0n ? "yes" : "no";
  return "no";
}

export function calibrationView(roster: ObjectRow, activity: string, strongest: boolean, path = ledgerPath(), now?: number): Result {
  let ledger: Ledger;
  try { ledger = parseLedger(path); }
  catch (error) { if (error instanceof LedgerError) return failure(`tap team calibration: ${error.message}\n`); throw error; }
  const clock = now ?? (process.env.TAP_WATCH_NOW ? pyFloatString(process.env.TAP_WATCH_NOW) : Date.now() / 1000);
  if (clock === null) throw new Error(`could not convert TAP_WATCH_NOW to float: ${pyRepr(process.env.TAP_WATCH_NOW || "")}`);
  const { banner, rows, dispositions } = ledger;
  const byHandle = new Map(rows.map(row => [row.handle, row]));
  const idle = new Map<string, number>();
  for (const line of splitLines(activity)) {
    const [pane, address, stamp] = line.split("\t");
    if (!stamp || !/^\p{Decimal_Number}+$/u.test(stamp)) continue;
    for (const key of [pane, address]) if (key) idle.set(key, Number(unicodeInt(stamp)));
  }
  const agents = Array.isArray(roster.agents) ? roster.agents : [];
  const joined = agents.filter((agent): agent is ObjectRow => object(agent) && !!agent.handle).map(agent => {
    const handle = text(agent.handle), harness = text(agent.harness);
    let base = byHandle.get(handle), how = base ? "exact" : "", mismatch = "";
    if (!base) {
      for (const [name, row] of byHandle) if (handle.startsWith(`${name}-`) && (!base || length(name) > length(base.handle))) { base = row; how = "prefix"; }
    }
    if (base && harness && base.harness && harness !== base.harness) {
      mismatch = `harness ${harness} does not match ${base.handle}'s ${base.harness}`;
      base = undefined; how = "";
    }
    const family = HARNESS_FAMILY.get(harness);
    const metadata = object(agent.metadata) ? agent.metadata : {};
    const roles = (key: string) => Array.isArray(metadata[key]) ? metadata[key].filter((r: unknown): r is string => typeof r === "string").join(", ") : "";
    const primary = roles("primary_roles"), secondary = roles("secondary_roles");
    const stamp = idle.get(text(agent.pane));
    return { handle, base: base?.handle || "", how, model: base?.model || "", harness: harness || base?.harness || "",
      family: base ? base.family : family ? `${family} (INFERRED)` : "", tier: base?.tier || "", voice: base?.voice || "",
      one_liner: base?.one_liner || "", roles: primary + (secondary ? `${primary ? " " : ""}(${secondary})` : ""),
      status: text(agent.status) || "unknown", attached: attachedCell(agent.attached),
      // Python max(0.0, nan) keeps its first operand, just like a future stamp.
      idle: stamp ? compactAge(clock - stamp > 0 ? clock - stamp : 0) : "-", mismatch };
  });
  if (strongest) {
    const reachable = new Map<string, string>();
    for (const row of [...joined.filter(row => row.status === "active"), ...rows.filter(row => row.harness === "Agent tool")]) {
      if (!reachable.has(row.handle)) reachable.set(row.handle, row.tier);
    }
    const tier = (name: string) => TIERS.get(name) || 0;
    const best = Math.max(...[...reachable.values()].map(tier));
    return success([...reachable].filter(([, t]) => tier(t) === best).map(([handle]) => `${handle}\n`).join(""));
  }
  let out = `tap team calibration: ${text(roster.team) || "(unnamed)"}\n`;
  if (!joined.length) return success(out + "no seats registered yet — run: tap register\n");
  if (banner) out += `${banner}\n`;
  out += "\n" + table(["HANDLE", "BASE", "MODEL @ HARNESS", "FAMILY", "TIER", "VOICE", "ROLES", "STATUS", "ATTACHED", "IDLE"],
    joined.map(row => [row.handle, row.base || "-", row.model ? `${row.model} @ ${row.harness}` : `- @ ${row.harness || "-"}`,
      row.family || "-", row.tier || "-", row.voice || "-", row.roles || "-", row.status, row.attached, row.idle]));
  const unjoined = joined.filter(row => !row.base);
  if (unjoined.length) {
    out += "\nSeated, no calibration row (the handle joins nothing — that is a gap in the ledger, not a dead seat):\n";
    for (const row of unjoined) out += `  ${row.handle} — ${row.status}${row.harness ? `, ${row.harness}` : ""}` +
      (row.mismatch ? `; ${row.mismatch} — the name matches but the harness contradicts it, so the calibration is NOT inherited` : "; add a routing entry to calibrate") + "\n";
  }
  const routed = joined.filter(row => row.base);
  if (routed.length) {
    out += "\nRoutes to, and the latest dated observation:\n";
    for (const row of routed) {
      out += `  ${row.handle}${row.how === "exact" ? "" : ` (via ${row.base})`} — ${row.one_liner || "no route line in the ledger"}\n`;
      const [date, observation] = latestObservation(dispositions.get(row.base) || "");
      if (date) out += `      ${date} · ${observation}\n`;
    }
  }
  return success(out + `\nIDLE is tmux window activity — a hint, not a work signal (incoming traffic bumps it). Catalog: tap models. Ledger: ${path}\n`);
}

export function writeRoutingResult(result: Result): number {
  process.stdout.write(result.stdout);
  process.stderr.write(result.stderr);
  return result.exit;
}

export function cmdModels(argv: string[]): number {
  return writeRoutingResult(modelsView(argv));
}

const TEAMS_USAGE = "usage: tap teams [-h] [--all] [--details]\n";
const TEAMS_HELP = TEAMS_USAGE + "\noptions:\n  -h, --help  show this help message and exit\n  --all\n  --details\n";

function parseTeams(argv: string[]): Result | { all: boolean; details: boolean } {
  let all = false, details = false, ended = false;
  const extra: string[] = [];
  const explicit = (option: string, value: string) => failure(`${TEAMS_USAGE}tap teams: error: argument ${option}: ignored explicit argument ${pyRepr(value)}\n`, 2);
  for (const arg of argv) {
    if (!ended && arg === "--") ended = true;
    if (!ended && arg.startsWith("-h")) {
      const tail = arg.replace(/^-h+/, "");
      if (tail.startsWith("=")) return explicit("-h/--help", tail.slice(1));
      if (tail.startsWith("-")) return explicit("-h/--help", tail);
      return success(TEAMS_HELP);
    }
    if (!ended && arg.startsWith("--")) {
      const equal = arg.indexOf("="), name = equal < 0 ? arg : arg.slice(0, equal);
      const matches = ["--help", "--all", "--details"].filter(option => option.startsWith(name));
      if (matches.length > 1) return failure(`${TEAMS_USAGE}tap teams: error: ambiguous option: ${arg} could match ${matches.join(", ")}\n`, 2);
      const option = matches[0];
      if (option) {
        if (equal >= 0) return explicit(option === "--help" ? "-h/--help" : option, arg.slice(equal + 1));
        if (option === "--help") return success(TEAMS_HELP);
        if (option === "--all") all = true;
        else details = true;
        continue;
      }
    }
    extra.push(arg);
  }
  if (extra.length) return failure(`usage: tap [-h] {models,team-calibration,teams} ...\ntap: error: unrecognized arguments: ${extra.join(" ")}\n`, 2);
  return { all, details };
}

function readObject(path: string): ObjectRow {
  try { const doc = isRegularFile(path) ? readIndexJson(path) : null; return object(doc) ? doc : {}; }
  catch { return {}; }
}

// Keep the native roster as observation authority, bounded independently for each team.
function observedRoster(team: string, scriptsDir: string): Promise<ObjectRow[] | null> {
  return new Promise(resolveResult => {
    const child = spawn("bun", [resolve(scriptsDir, "../../../runtime/bun/src/team-roster-json.ts"), "roster", team, "--json"], {
      cwd: resolve(scriptsDir, "../../.."), env: process.env,
      stdio: ["ignore", "pipe", "ignore"], timeout: 10_000, killSignal: "SIGKILL",
    });
    const chunks: Buffer[] = [];
    child.stdout.on("data", chunk => chunks.push(Buffer.from(chunk)));
    child.on("error", () => resolveResult(null));
    child.on("close", code => {
      if (code !== 0) { resolveResult(null); return; }
      try {
        const doc: unknown = JSON.parse(new TextDecoder("utf-8", {fatal:true, ignoreBOM:true}).decode(Buffer.concat(chunks)));
        resolveResult(object(doc) && !pyTruthy(doc.error) && Array.isArray(doc.agents) ? doc.agents.filter(object) : null);
      } catch { resolveResult(null); }
    });
  });
}

export function teamStatus(states: string[], unobserved = false, colored = !!process.stdout.isTTY && !process.env.NO_COLOR): string {
  const kinds: [string, number][] = unobserved ? [["unknown", 33]] : [];
  if (!unobserved) {
    if (states.includes("blocked")) kinds.push(["blocked", 31]);
    if (states.includes("working")) kinds.push(["working", 32]);
    if (!kinds.length) kinds.push(["idle", 34]);
  }
  return kinds.map(([label, color]) => `${colored ? `\x1b[${color}m●\x1b[0m` : "●"} ${label}`).join(" ");
}

function spoolWarning(root: string, now: number): string {
  if (!root) return "";
  const spool = join(root, ".tap/bus/spool");
  let entries: string[];
  try { entries = readdirSync(spool).filter(name => name.endsWith(".md") && name !== ".md" && isRegularFile(join(spool, name))); }
  catch { return ""; }
  if (!entries.length) return "";
  let oldest = Infinity;
  for (const name of entries) {
    try { oldest = Math.min(oldest, statSync(join(spool, name)).mtimeMs / 1000); } catch { /* Entry disappeared. */ }
  }
  return `spool ${entries.length}${oldest === Infinity ? "" : `/${compactAge(Math.max(0, now - oldest))}`}`;
}

export async function teamsView(argv: string[], scriptsDir = resolve(import.meta.dir, "../../../skills/tap/scripts")): Promise<Result> {
  const args = parseTeams(argv);
  if ("exit" in args) return args;
  const now = Date.now() / 1000, snapshot = loadGlobalRegistry();
  const doc = snapshot.marker === "live" ? snapshot.doc : snapshot.marker === "absent" ? readObject(legacyTeamsPath()) : null;
  const teams = doc && object(doc.teams) ? doc.teams : {};
  type TeamRow = { name: string; root: string; active: number; total: number; attached: number; warn: string; status: string; unobserved: boolean };
  const rows: TeamRow[] = [], pending: {name: string; root: string; stored: ObjectRow}[] = [];
  for (const name of Object.keys(teams).sort(compare)) {
    const meta = teams[name];
    if (!object(meta) || meta.state === "historical") continue;
    const root = text(meta.root);
    let path = "";
    if (root && snapshot.marker === "live") {
      const acting = resolveTeamFromDoc(snapshot.doc!, name);
      if (acting.status !== "ok") {
        rows.push({name, root, active:0, total:0, attached:0, warn:"acting_unreachable", status:teamStatus([], true), unobserved:true});
        continue;
      }
      path = acting.registryLocation;
    } else if (root) {
      path = [join(root, ".tap/bus/registry.json"), join(root, "tmp/tap/registry.json")].find(isRegularFile) || "";
    }
    pending.push({name, root, stored:seatMap(readObject(path))});
  }
  let next = 0;
  await Promise.all(Array.from({length:Math.min(8, pending.length)}, async () => {
    while (next < pending.length) {
      const {name, root, stored} = pending[next++]!;
      const observed = await observedRoster(name, scriptsDir);
      const active = observed?.filter(row => row.status === "active") ?? [];
      const total = observed?.length ?? Object.values(stored).filter(object).length;
      const attached = active.filter(row => pyTruthy(row.attached) && !["0", "no", "false"].includes(String(row.attached))).length;
      const states = active.map(row => row.agent_state === "idle-at-prompt" ? "idle" : text(row.agent_state));
      const warn = [observed === null ? "roster_unreadable" : "", spoolWarning(root, now),
        observed !== null && total > active.length ? `${total - active.length} dormant` : ""].filter(Boolean).join(" · ") || "-";
      rows.push({name, root, active:active.length, total, attached, warn, status:teamStatus(states, observed === null), unobserved:observed === null});
    }
  }));
  const visible = rows.filter(row => args.all || row.active || row.unobserved).sort((a,b) => compare(a.name,b.name));
  if (!visible.length) return success(`tap teams (machine-wide): no ${args.all ? "enrolled" : "active"} teams\n`);
  return success(args.details
    ? table(["TEAM", "SEATS", "ATTACHED", "WARN", "WORKDIR"], visible.map(row => [row.name, `${row.active}/${row.total}`, String(row.attached), row.warn, row.root]))
    : table(["TEAM", "SEATS", "STATUS"], visible.map(row => [row.name, `${row.active}/${row.total}`, row.status])));
}

// One parser and summary owner for both public teams and synchronous team list.
if (import.meta.main) process.exitCode = writeRoutingResult(await teamsView(process.argv.slice(3)));
