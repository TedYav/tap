// darwin-residue-gate — the macOS residue gate (tap-1bus0 piece 2).
//
// Real-process control of the candidate checkout's skills/tap/scripts/reply_send.py on the
// actual macOS Python 3.11 floor: normal child completion, then cancellation while a real child
// is held (the child is stopped before the wrapper returns; no later child effect; reaping itself
// is not observed). Linux CI cannot run this: its Python has
// os.waitid, and the 2026-09-08/09 specimens (tap-7r3fn.128; #xxx's Cellar-ordered export) were
// Mac-only regressions that passed a green Linux full. The same deadline also covers actual
// Bash 3.2 parsing/negative syntax and the health fixture PATH/socket guard parity arms.
//
// Contract: exit 0 PASS, 1 FAIL (an assertion failed), 2 INCOMPLETE (no 3.11 interpreter, dirty
// worktree, timeout, or a broken instrument). INCOMPLETE is never a silent pass. One receipt line
// on stdout records candidate HEAD + TREE, interpreter path + version + waitid presence, measured
// wall, and any override that was used, so a reviewer can tell what was tested.
//
// Not a slot, not a lock, no queue: rerunning is cheaper than coordinating (AGENTS.md § Contributing).
import { existsSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";

const DEFAULT_DEADLINE_MS = 9000; // hard bound; the order says under 10 s wall, all arms share this bound
const HOLD_SECONDS = 4; // the held child's own sleep; the gate never waits it out

type Outcome = { code: 0 | 1 | 2; verdict: string };

function git(root: string, ...args: string[]): string {
  const r = Bun.spawnSync(["git", "-C", root, ...args], { stdout: "pipe", stderr: "pipe" });
  if (r.exitCode !== 0) throw new Error(`git ${args.join(" ")}: ${r.stderr.toString().trim()}`);
  return r.stdout.toString().trim();
}

/** Homebrew floor first (the interpreter install.sh recommends), PATH python3.11 last. Each probe is
 *  bounded by the remaining deadline so a hanging shim cannot hold the gate past its refusal. */
export function resolveInterpreter(env: NodeJS.ProcessEnv = process.env, timeoutMs = 5000): { path: string; version: string; waitid: boolean; source: string } | null {
  const deadline = Date.now() + timeoutMs;
  const candidates: [string, string][] = env.TAP_RESIDUE_PYTHON
    ? [[env.TAP_RESIDUE_PYTHON, "override TAP_RESIDUE_PYTHON"]]
    : [["/opt/homebrew/opt/python@3.11/bin/python3.11", "homebrew"], ["/usr/local/opt/python@3.11/bin/python3.11", "homebrew"], ["python3.11", "PATH"]];
  for (const [candidate, source] of candidates) {
    const remaining = deadline - Date.now();
    if (remaining <= 0) return null;
    let out = "";
    try {
      const probe = Bun.spawnSync([candidate, "-c", "import os,sys; print(sys.executable); print('%d.%d.%d' % sys.version_info[:3]); print(int(hasattr(os,'waitid')))"], { stdout: "pipe", stderr: "pipe", env, timeout: remaining, killSignal: "SIGKILL" });
      if (probe.exitCode !== 0) continue;
      out = probe.stdout.toString().trim();
    } catch { continue; } // ENOENT: not installed at this path
    const [path, version, waitid] = out.split("\n");
    if (!path || !version?.startsWith("3.11.")) continue;
    return { path, version, waitid: waitid === "1", source };
  }
  return null;
}

export function runPlatformProbes(root: string, env: NodeJS.ProcessEnv, deadline: number): Outcome {
  const remaining = deadline - Date.now();
  if (remaining <= 0) return { code: 2, verdict: "INCOMPLETE: timeout before platform probes" };
  // Keep the private tmux socket below its macOS pathname limit.
  const work = mkdtempSync(join(env.TMUX_TMPDIR ?? "/tmp", "dr-"));
  try {
    const result = Bun.spawnSync(["/bin/bash", join(root, "scripts/darwin-platform-probes.sh"), root, work], {
      env, stdout: "pipe", stderr: "pipe", timeout: remaining, killSignal: "SIGKILL",
    });
    if (Date.now() >= deadline) return { code: 2, verdict: "INCOMPLETE: timeout in platform probes" };
    const detail = result.stdout.toString().trim().replaceAll("\n", " | ");
    if (result.exitCode === 0) return { code: 0, verdict: detail };
    return { code: result.exitCode === 1 ? 1 : 2,
      verdict: detail || `INCOMPLETE: platform probe failed: ${result.stderr.toString().trim().replaceAll("\n", " | ")}` };
  } finally { rmSync(work, { recursive: true, force: true }); }
}

async function waitFor(predicate: () => boolean, deadline: number, label: string): Promise<void> {
  while (!predicate()) {
    if (Date.now() > deadline) throw new Error(`INCOMPLETE: timeout waiting for ${label}`);
    await Bun.sleep(10);
  }
}

function alive(pid: number): boolean {
  try { process.kill(pid, 0); return true; } catch (error) { return (error as NodeJS.ErrnoException).code !== "ESRCH"; }
}

export async function runGate(root: string, env: NodeJS.ProcessEnv = process.env): Promise<Outcome> {
  const started = performance.now();
  const deadline = Date.now() + Number(env.TAP_RESIDUE_DEADLINE_MS ?? DEFAULT_DEADLINE_MS);
  const recorded: string[] = [];
  const stop: number[] = []; // only pids this run started or read from its own child's marker
  const finish = (code: 0 | 1 | 2, tail: string): Outcome => {
    const wall = Math.round(performance.now() - started);
    const line = `darwin-residue: ${recorded.join(" ")} wall=${wall}ms — ${tail}`;
    return { code, verdict: line };
  };
  let head = "", tree = "";
  try {
    head = git(root, "rev-parse", "HEAD"); tree = git(root, "rev-parse", "HEAD^{tree}");
    recorded.push(`head=${head}`, `tree=${tree}`);
    const dirty = git(root, "status", "--porcelain", "--untracked-files=all");
    if (dirty) return finish(2, "INCOMPLETE: worktree dirty; the tree id would not name the tested bytes");
    recorded.push("worktree=clean");
  } catch (error) { return finish(2, `INCOMPLETE: ${(error as Error).message}`); }

  // The residue is macOS-only: a Linux 3.11 usually has os.waitid and would pass without exercising it.
  if (process.platform !== "darwin") return finish(2, `INCOMPLETE: not macOS (platform=${process.platform}); this gate only means something on the Darwin floor; floor arm not exercised`);
  recorded.push("platform=darwin");
  const interpreter = resolveInterpreter(env, deadline - Date.now());
  if (!interpreter && Date.now() >= deadline) return finish(2, "INCOMPLETE: timeout while probing Python 3.11 candidates (a hanging shim?); floor arm not exercised");
  if (!interpreter) return finish(2, "INCOMPLETE: no Python 3.11 interpreter (Homebrew python@3.11 or python3.11 on PATH); install the floor before gating; floor arm not exercised");
  recorded.push(`interpreter=${interpreter.path}`, `version=${interpreter.version}`, `waitid=${interpreter.waitid}`, `source=${interpreter.source}`);

  if (interpreter.waitid) recorded.push("floor arm not exercised (waitid available)");

  const replySend = env.TAP_RESIDUE_REPLY_SEND ?? join(root, "skills/tap/scripts/reply_send.py");
  if (env.TAP_RESIDUE_REPLY_SEND) recorded.push(`reply_send=override:${replySend}`);
  if (!existsSync(replySend) || !statSync(replySend).isFile()) return finish(2, `INCOMPLETE: ${replySend} is not a file`);

  const work = mkdtempSync(join(env.TMPDIR ?? tmpdir(), "tap-darwin-residue-"));
  const childEnv = { ...env, PYTHONDONTWRITEBYTECODE: "1" };
  const wrapper = (childArgs: string[]) => Bun.spawn([interpreter.path, "-B", replySend, interpreter.path, "-c", ...childArgs], { cwd: work, env: childEnv, stdin: "ignore", stdout: "pipe", stderr: "pipe" });
  try {
    // 1. normal completion: the wrapper must reap a finished child and pass its status through.
    const normal = wrapper(["import sys; sys.exit(0)"]);
    stop.push(normal.pid);
    const normalRace = await Promise.race([normal.exited, Bun.sleep(Math.max(0, deadline - Date.now())).then(() => "timeout" as const)]);
    if (normalRace === "timeout") return finish(2, "INCOMPLETE: timeout in the normal-completion case");
    const normalErr = await new Response(normal.stderr).text();
    if (normal.exitCode !== 0) return finish(1, `FAIL: normal completion exited ${normal.exitCode}: ${normalErr.trim().split("\n").at(-1) ?? ""}`);
    recorded.push("normal=ok");

    // 2. cancellation while a real child is held: the child publishes its pid, then sleeps and
    //    would write an effect. TERM the wrapper mid-hold; it must exit 143, the child must be
    //    dead by the time the wrapper has returned, and the effect must never appear. Whether the
    //    wrapper itself reaped the child is not observed here (init reaps an orphan just as fast).
    const ready = join(work, "ready"), effect = join(work, "effect");
    const held = wrapper([`import os,sys,time; from pathlib import Path; Path(sys.argv[1]).write_text(str(os.getpid())); time.sleep(${HOLD_SECONDS}); Path(sys.argv[2]).write_text("delivered")`, ready, effect]);
    stop.push(held.pid);
    await waitFor(() => existsSync(ready), deadline, "the held child's ready marker");
    const childPid = Number(readFileSync(ready, "utf8").trim());
    if (!Number.isInteger(childPid) || childPid <= 0) return finish(2, "INCOMPLETE: held child published an unparseable pid");
    stop.push(childPid);
    held.kill("SIGTERM");
    const heldRace = await Promise.race([held.exited, Bun.sleep(Math.max(0, deadline - Date.now())).then(() => "timeout" as const)]);
    if (heldRace === "timeout") return finish(2, "INCOMPLETE: timeout waiting for the cancelled wrapper to exit");
    // Liveness and effect are checked before any stderr read: the held child inherits the
    // wrapper's stderr pipe, so reading it first would wait out the child's hold and hide the
    // still-alive verdict. stderr is read only on the exit-code failure, after stopping the child.
    if (held.exitCode !== 143) {
      try { process.kill(childPid, "SIGKILL"); } catch { /* already gone */ }
      const heldErr = await new Response(held.stderr).text();
      return finish(1, `FAIL: cancelled wrapper exited ${held.exitCode}, expected 143: ${heldErr.trim().split("\n").at(-1) ?? ""}`);
    }
    if (alive(childPid)) return finish(1, `FAIL: held child ${childPid} still alive after the wrapper returned`);
    if (existsSync(effect)) return finish(1, "FAIL: held child wrote its effect after cancellation");
    recorded.push("cancel=ok");
    const platform = runPlatformProbes(root, { ...env, TAP_PYTHON: interpreter.path }, deadline);
    if (platform.code !== 0) return finish(platform.code, platform.verdict);
    recorded.push(platform.verdict);
    return finish(0, "PASS");
  } catch (error) {
    const message = (error as Error).message;
    return finish(2, message.startsWith("INCOMPLETE") ? message : `INCOMPLETE: ${message}`);
  } finally {
    for (const pid of stop) { try { process.kill(pid, "SIGKILL"); } catch { /* already gone */ } }
    rmSync(work, { recursive: true, force: true });
  }
}

if (import.meta.main) {
  const root = process.argv[2] ?? process.cwd();
  const outcome = await runGate(root);
  process.stdout.write(outcome.verdict + "\n");
  process.exit(outcome.code);
}
