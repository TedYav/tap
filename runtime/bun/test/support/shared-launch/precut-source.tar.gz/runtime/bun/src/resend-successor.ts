// One successor invocation after durable resend preparation. Delegation here
// runs send, never resend; any other failure leaves the original withdrawn.
import { spawnSync } from "node:child_process";
import { dirname } from "node:path";
import { DelegateToBash } from "./context";
import { cmdSend } from "./verbs/send";
import { AGENT_FAMILIES } from "./verbs/team";
import { runNative, sendUsesBash } from "../main";

const emitted: string[] = JSON.parse(process.argv[2]!);
const [command, script, ...args] = emitted;
const staticBash = /[/:]/.test(args[0] ?? "") || args.some(arg => ["--note", "--reply-to", "--in-reply-to"].includes(arg));
function bashSend(): number {
  // The successor's Bash send is internal, like reply's nested send: it must
  // not re-enter the entry selector, or the resend double-routes.
  const result = spawnSync(command!, [script!, ...args], { stdio: "inherit", env: { ...process.env, TAP_INTERNAL_OVERDUE_CHECKED: "1" } });
  return result.status ?? 1;
}
let rc: number;
if (staticBash || sendUsesBash()) rc = bashSend();
else {
  try { rc = runNative("send", argv => cmdSend(argv, dirname(script!), AGENT_FAMILIES), args); }
  catch (error) {
    if (!(error instanceof DelegateToBash)) throw error;
    rc = bashSend();
  }
}
process.exitCode = rc;
