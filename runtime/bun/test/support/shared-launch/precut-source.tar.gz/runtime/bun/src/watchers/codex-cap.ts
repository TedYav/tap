#!/usr/bin/env bun
//
// codex-cap.ts — swap the Codex credential at the cap and relaunch the fleet.
//
// THE INCIDENT THIS AUTOMATES (tap-834qn). Codex reads ~/.codex/auth.json once,
// at startup. When the active account hits its weekly cap every Codex seat on
// the machine wedges at `busy:pending`, and swapping the credential underneath
// them changes nothing, because no running process re-reads that file. The
// recovery has always been manual and slow: notice, run `cxswap switch`, then
// visit every Codex pane. Twenty-two percent of a week's budget burned in four
// and a half hours behind exactly that latency.
//
// WHAT THIS FILE IS, AND MOSTLY IS NOT. It is a tick: read the meter, and at
// the cap run two commands. Everything hard about replacing a live seat —
// serialization, the clearing fence, per-seat refusal isolation, excluding the
// caller's own pane — belongs to `tap session relaunch --harness codex` and is
// deliberately not reimplemented here. This file must therefore never speak to
// tmux. runtime/bun/src/tmux.ts is read-only and says why: the next
// write-shaped call added there repeats the 2026-08-23 default-server class.
//
// A TICK, NOT A DAEMON. launchd runs it every 30 seconds (cron cannot tick
// under a minute) and a kernel flock keeps two ticks from overlapping. Nothing
// here loops, sleeps, or supervises, so a wedged invocation is a missed tick
// rather than a silent no-op that looks alive.
//
// NO SHELL, ANYWHERE. Every child is started from an argv array. The reason
// text handed to `-m` is prose written by a human and is never expanded by
// anything, which retires the whole backtick-in-a-message class for this path.

import { existsSync, mkdirSync, appendFileSync, readFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { homedir } from "node:os";
import { dirname, join } from "node:path";

import { atomicWrite } from "../fsatomic";
import { acquirePathLock } from "../panelock";

/** The meter is an out-of-repo cache reader; pin the shape we know how to read. */
export const METER_HEADER = "agent-meter/v7";

/**
 * DELIMITED, not prefix-matched. `startsWith(METER_HEADER)` also accepts
 * `agent-meter/v70` and `agent-meter/v7.1` — a future schema this parser has
 * never seen, admitted by the very check that exists to fail closed on schema
 * drift. The header's own separator is a space, so require it.
 */
const HEADER_RE = new RegExp(`^${METER_HEADER.replace(/[.*+?^$\\{}()|[\]]/g, "\\$&")}(?:\\s|$)`);

/**
 * Ruled by the conductor, 2026-08-28: the default is the spec's 100 and the
 * acceptance controls assert it. Preserving headroom below the cap is a policy
 * choice rather than a measured correction, so it belongs to `--at` — an
 * explicit operator override — and never to the default.
 */
export const DEFAULT_THRESHOLD = 100;

/** How long one recorded fire suppresses the next, in milliseconds. */
export const DEFAULT_COOLDOWN_MS = 900_000;

/**
 * EVERY CHILD IS BOUNDED, because an unbounded one does not cost a tick — it
 * costs all of them. launchd skips a StartInterval firing while the job is
 * still running, so one hung collaborator holds this process, and with it the
 * kernel lock, for as long as it hangs: the watcher stops watching and every
 * later tick is silently dropped. "A wedged invocation is a missed tick" is
 * only true if the invocation actually ends.
 *
 * The bounds are sized to the command rather than uniform. The meter is a
 * cache reader (measured 0.03s). cxswap edits one credential file. The
 * relaunch is the outlier and deliberately generous: seats are replaced
 * SERIALIZED and each one may wait out `CLEAR_REBIND_TIMEOUT_SECONDS` (45s,
 * launcher.py:7832). Measured on this machine 2026-08-28, `--harness codex
 * --dry-run` selects 19 resumable seats against 40 refusals, so the worst case
 * is ~14 minutes and thirty is roughly twice it. That bound is not a latency
 * budget; it is the line past which a hang is likelier than a slow fleet.
 */
export type TimeoutName = "meter" | "cxswapRead" | "cxswapSwitch" | "relaunch" | "notify";

export const TIMEOUT_MS: Record<TimeoutName, number> = {
  meter: 20_000,
  cxswapRead: 15_000,
  cxswapSwitch: 60_000,
  relaunch: 1_800_000,
  notify: 20_000,
};

export interface Gauge {
  name: string;
  pct: number;
}

/**
 * The stale flag is the ONE field whose loss fails toward FIRING.
 *
 * The producer emits it as a bare presence flag — `fields.push('stale:yes')`,
 * usage.mjs:191 — and emits no negative form at all, so `stale:yes` is the only
 * value this schema ever carries. Anything else under that name is drift or a
 * truncated read, and both were silently ignored: `stale:`, `stale:y` and
 * `stale:ye` all parsed cleanly, dropped the guard, and fired on a cached past.
 *
 * A truncation caught one field earlier (a missing label/provider/state) already
 * refuses. This is the same failure two fields later, and the required-field
 * check could not see it because the damage lands inside an OPTIONAL field.
 *
 * Deliberately narrow, and not out of caution alone: `active:` and `usable:`
 * truncate toward IDLE — an unrecognised `active:ye` makes the row inactive and
 * the watcher stands down — which is blind but safe. Only this one can start a
 * credential swap on a reading it was told not to trust. The adjacent fields are
 * reported rather than folded in.
 */
const STALE_FIELD = /^stale:/;
const STALE_TRUE = "stale:yes";

export interface MeterRow {
  label: string;
  provider: string;
  state: string;
  active: boolean;
  stale: boolean;
  gauges: Gauge[];
}

export interface WatcherState {
  fired?: {
    at: string;
    label: string;
    alias: string;
    // `phase` is the SUPPRESSION marker — whether the next tick may re-enter.
    // `outcome` is what actually happened, recorded separately because a tick
    // can complete without relaunching anything, and a durable record that
    // says "relaunched" when nothing was is the class of claim this whole
    // review is about.
    // "no-effect" is a FAILED attempt that observation proved changed nothing:
    // the switch failed AND `cxswap status` still reports the original alias.
    // It is recorded separately because it is the one failure the next tick may
    // safely re-enter.
    phase: "intent" | "relaunched" | "failed" | "no-effect";
    outcome?: RelaunchOutcome["kind"];
  };
  note?: { at: string; key: string };
}

/** The quiet console is for people; recovery decisions require a complete JSON receipt. */
function relaunchReceipt(output: string): { resumed: number; excluded: number; skipped: number; refused: number; hard: number; code: number } | null {
  let doc: any;
  try { doc = JSON.parse(output); } catch { return null; }
  if (!doc || doc.harness !== "codex" || doc.dry_run !== false || !Number.isSafeInteger(doc.candidates) || doc.candidates < 0 ||
      !Array.isArray(doc.results) || doc.results.length !== doc.candidates ||
      !Array.isArray(doc.excluded_caller) || !Array.isArray(doc.excluded_inactive) || !Array.isArray(doc.skipped_teams)) return null;
  const keys = new Set<string>();
  let resumed = 0, refused = 0, hard = 0;
  for (const row of doc.results) {
    if (!row || typeof row.team !== "string" || !row.team || typeof row.handle !== "string" || !row.handle ||
        !Number.isSafeInteger(row.code) || row.code < 0 ||
        (row.code === 0 ? row.status !== "resumed" : row.status !== "failed")) return null;
    const key = JSON.stringify([row.team, row.handle]);
    if (keys.has(key)) return null;
    keys.add(key);
    if (row.code === 0) resumed++;
    else if (row.code === 2) refused++;
    else hard++;
  }
  for (const row of [...doc.excluded_caller, ...doc.excluded_inactive, ...doc.skipped_teams]) {
    if (!row || typeof row.team !== "string" || typeof row.handle !== "string" || typeof row.reason !== "string" || !row.reason) return null;
  }
  if (doc.excluded_caller.some((row: any) => row.reason !== "caller-pane")) return null;
  const code = refused + hard > 0 ? 1 : 0;
  if (doc.code !== code || doc.ok !== (code === 0)) return null;
  return { resumed, excluded: doc.excluded_caller.length, skipped: doc.skipped_teams.length, refused, hard, code };
}

export function countResumed(output: string): number { return relaunchReceipt(output)?.resumed ?? 0; }
export function countExcluded(output: string): number { return relaunchReceipt(output)?.excluded ?? 0; }

export type RelaunchOutcome =
  | { kind: "complete"; resumed: number; excluded: number }
  | { kind: "partial"; resumed: number; excluded: number }
  | { kind: "none-found"; resumed: 0; excluded: number }
  | { kind: "degraded"; resumed: number; excluded: number }
  | { kind: "failed"; resumed: number; excluded: number };

export function classifyRelaunch(rc: number, output: string, timedOut: boolean): RelaunchOutcome {
  const receipt = relaunchReceipt(output);
  const resumed = receipt?.resumed ?? 0, excluded = receipt?.excluded ?? 0;
  // Empty, truncated, dry-run and malformed JSON can never mean "none found".
  if (!receipt || timedOut || rc !== receipt.code || receipt.hard > 0) return { kind: "failed", resumed, excluded };
  if (receipt.refused > 0 || receipt.skipped > 0) return { kind: resumed > 0 ? "partial" : "degraded", resumed, excluded };
  if (excluded > 0) return { kind: "partial", resumed, excluded };
  return resumed > 0 ? { kind: "complete", resumed, excluded } : { kind: "none-found", resumed: 0, excluded };
}

export type Decision =
  | { act: "idle"; reason: string }
  | { act: "refuse"; reason: string; key: string }
  | { act: "fire"; label: string; gauge: Gauge };

/**
 * Parse `usage.mjs --compact`, or refuse.
 *
 * FAIL CLOSED ON FORMAT DRIFT. The meter lives outside this repo and can change
 * shape without warning here. A best-effort parser that silently finds no gauges
 * would read every future format as a calm board — the watcher would go blind
 * and still exit 0 forever. An unrecognised header is therefore `null`, which
 * the caller reports rather than swallows.
 */
export function parseMeter(text: string): MeterRow[] | null {
  const lines = text.split("\n");
  if (!lines[0] || !HEADER_RE.test(lines[0])) return null;

  const rows: MeterRow[] = [];
  for (const line of lines.slice(1)) {
    // Rows are pipe-delimited; the `hidden-accounts:N` trailer is not a row.
    if (!line.includes("|")) continue;
    // TRIMMED, and the trim is load-bearing in ONE direction that matters.
    // Fields are compared exactly, so a trailing `\r` on the last field of a
    // CRLF line makes that field stop matching. Two shapes fail toward idle,
    // which is blind but harmless; the third fails toward FIRING — with
    // `stale:yes` last, the guard that stops the watcher acting on a cached
    // past is silently absent and the fleet is replaced on a stale number.
    const fields = line.split("|").map((f) => f.trim());
    const [label, provider, state] = fields;
    // A ROW TOO SHORT TO CLASSIFY IS NOT AN ABSENT ROW. Skipping it silently
    // turns a truncated cache read — `Codex: DT|codex|` — into "no active codex
    // account", which reads as a calm board and logs an ordinary idle tick. The
    // whole point of refusing an unknown header is that the watcher must not go
    // blind quietly; a malformed row is the same failure one line down.
    if (!label || !provider || !state) return null;

    const gauges: Gauge[] = [];
    for (const field of fields.slice(3)) {
      // The percent is followed by `@resets <time>` or `regen:<rate>/<window>`
      // on most real gauges, so anchor at the start and stop at the sign.
      if (!field.startsWith("g:")) continue;
      const m = /^g:([^=]+)=(\d+)%/.exec(field);
      // A FIELD ANNOUNCING ITSELF AS A GAUGE MUST PARSE AS ONE. Dropping
      // `g:weekly=100` (a cache read truncated after the digits) left the row
      // with no gauges, which `decide` reports as an ordinary idle tick — a
      // capped account reading as a calm board, which is the blindness the
      // fail-closed header check exists to prevent.
      if (!m || !m[1] || !m[2]) return null;
      gauges.push({ name: m[1], pct: Number(m[2]) });
    }
    // A field NAMED stale but not spelled exactly `stale:yes` means this row
    // cannot answer the question the guard asks, so the whole read is refused
    // rather than the row being treated as fresh.
    if (fields.some((f) => STALE_FIELD.test(f) && f !== STALE_TRUE)) return null;

    rows.push({
      label,
      provider,
      state,
      active: fields.includes("active:yes"),
      stale: fields.includes(STALE_TRUE),
      gauges,
    });
  }
  return rows;
}

/**
 * The highest gauge on a row, named.
 *
 * WHY THE MAX RATHER THAN A NAMED GAUGE. Codex exposes only `weekly` today, but
 * a five-hour gauge wedges seats exactly as hard, and hard-coding `weekly` would
 * make the watcher quietly blind to it. Reporting the gauge's name keeps the log
 * honest about which limit actually fired.
 */
export function peakGauge(row: MeterRow): Gauge | null {
  let best: Gauge | null = null;
  for (const g of row.gauges) if (!best || g.pct > best.pct) best = g;
  return best;
}

export function decide(o: {
  rows: MeterRow[] | null;
  threshold: number;
  now: Date;
  state: WatcherState | null;
  cooldownMs: number;
}): Decision {
  if (o.rows === null) {
    return {
      act: "refuse",
      key: "meter-unreadable",
      reason: `the meter did not start with ${METER_HEADER}; refusing to read it as a calm board`,
    };
  }

  const live = o.rows.filter((r) => r.provider === "codex" && r.state === "ready" && r.active);
  if (live.length === 0) return { act: "idle", reason: "no active, ready codex account on the meter" };
  if (live.length > 1) {
    return {
      act: "refuse",
      key: "ambiguous-active",
      reason: `the meter reports two active codex accounts (${live.map((r) => r.label).join(", ")}); refusing to guess which one is live`,
    };
  }

  const row = live[0]!;
  // A cached reading is a past, and the fire path acts on the present: swapping
  // the credential and replacing every Codex process on the strength of a stale
  // number is the one mistake that costs more than the cap it answers.
  if (row.stale) {
    return { act: "refuse", key: "stale", reason: `the reading for ${row.label} is marked stale` };
  }

  const gauge = peakGauge(row);
  if (!gauge) return { act: "idle", reason: `${row.label} reports no gauges` };
  if (gauge.pct < o.threshold) {
    return { act: "idle", reason: `${row.label} ${gauge.name} at ${gauge.pct}%, below ${o.threshold}%` };
  }

  // SUPPRESSION IS WHAT MAKES THE INTENT RECORD WORTH WRITING. The record is
  // stamped before the credential moves, so a tick that dies mid-sequence still
  // leaves the next one unable to re-enter it. Without this branch the record
  // would be a diary entry rather than a guard.
  // SUPPRESSION IS FOR ATTEMPTS THAT MAY HAVE TAKEN EFFECT — and only those.
  //
  // The repo's no-retry rule guards "payload delivery and state mutation" and
  // requires `effect: none` before a retry, and its check flags "any
  // classification that MERGES pre-effect and post-effect failures". Suppressing
  // a `no-effect` attempt is exactly that merge: `cxswap switch` failed and
  // `cxswap status` then confirmed the original alias is still live, so no
  // credential moved and no seat was replaced. Treating it like a possibly-
  // effective attempt left a capped fleet wedged for the full cooldown after a
  // transient failure — the outage this watcher exists to end, extended by the
  // guard meant to make it safe.
  //
  // Every other phase still suppresses. `failed` covers the switch whose status
  // could not be read, which is unproven rather than proven-clean.
  const fired = o.state?.fired;
  if (fired && fired.label === row.label && fired.phase !== "no-effect") {
    const age = o.now.getTime() - Date.parse(fired.at);
    if (Number.isFinite(age) && age >= 0 && age < o.cooldownMs) {
      return {
        act: "idle",
        reason: `suppressed: a relaunch for ${row.label} was recorded ${Math.round(age / 1000)}s ago (phase ${fired.phase})`,
      };
    }
  }

  return { act: "fire", label: row.label, gauge };
}

// --------------------------------------------------------------------- shell

interface Options {
  account: string;
  threshold: number;
  cooldownMs: number;
  meter: string[];
  cxswap: string;
  tap: string;
  notify: string;
  statePath: string;
  logPath: string;
  lockPath: string;
  dryRun: boolean;
  timeouts: Record<TimeoutName, number>;
}

class Refusal extends Error {}

const USAGE = `usage: codex-cap.ts --account <cxswap-alias> [--at <percent>] [--dry-run]
                    [--timeout <name>=<seconds>]
                    [--cooldown <seconds>] [--meter <path>] [--cxswap <path>]
                    [--tap <path>] [--notify <path>] [--state <path>]
                    [--log <path>] [--lock <path>]`;

export function parseArgs(argv: string[], env: NodeJS.ProcessEnv = process.env): Options {
  const home = env.HOME || homedir();
  const watchers = join(home, ".tap", "watchers");
  const o: Options = {
    account: "",
    threshold: DEFAULT_THRESHOLD,
    cooldownMs: DEFAULT_COOLDOWN_MS,
    meter: ["node", join(home, ".claude", "skills", "agent-meter", "scripts", "usage.mjs"), "--compact"],
    cxswap: "cxswap",
    tap: "tap",
    notify: "notify-user",
    statePath: join(watchers, "codex-cap.state.json"),
    logPath: join(watchers, "codex-cap.log"),
    lockPath: join(watchers, "codex-cap.lock"),
    dryRun: false,
    timeouts: { ...TIMEOUT_MS },
  };

  const value = (flag: string, next: string | undefined): string => {
    if (next === undefined) throw new Refusal(`${flag} needs a value\n${USAGE}`);
    return next;
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]!;
    switch (arg) {
      case "--account": o.account = value(arg, argv[++i]); break;
      case "--at": {
        const raw = value(arg, argv[++i]);
        // Reject by SHAPE, not by Number()'s generosity: `Number("1e3")` and
        // `Number(" 97 ")` both succeed and neither is an operator typing a
        // percentage.
        if (!/^\d+$/.test(raw)) throw new Refusal(`--at takes a whole percentage, got ${JSON.stringify(raw)}`);
        const n = Number(raw);
        if (n < 1 || n > 500) throw new Refusal(`--at must be between 1 and 500, got ${n}`);
        o.threshold = n;
        break;
      }
      case "--cooldown": {
        const raw = value(arg, argv[++i]);
        if (!/^\d+$/.test(raw)) throw new Refusal(`--cooldown takes whole seconds, got ${JSON.stringify(raw)}`);
        o.cooldownMs = Number(raw) * 1000;
        break;
      }
      case "--meter": o.meter = [value(arg, argv[++i])]; break;
      case "--cxswap": o.cxswap = value(arg, argv[++i]); break;
      case "--tap": o.tap = value(arg, argv[++i]); break;
      case "--notify": o.notify = value(arg, argv[++i]); break;
      case "--state": o.statePath = value(arg, argv[++i]); break;
      case "--log": o.logPath = value(arg, argv[++i]); break;
      case "--lock": o.lockPath = value(arg, argv[++i]); break;
      // A real operator knob, not a test seam: a large serialized fleet or a
      // slow box legitimately needs a longer relaunch bound, and naming the
      // bound is better than raising every bound together. It is also what
      // makes the hang behaviour testable in under a second.
      case "--timeout": {
        const raw = value(arg, argv[++i]);
        const eq = raw.indexOf("=");
        const name = eq < 0 ? "" : raw.slice(0, eq);
        const secs = eq < 0 ? "" : raw.slice(eq + 1);
        if (!(name in o.timeouts)) {
          throw new Refusal(`--timeout names one of ${Object.keys(o.timeouts).join(", ")}, got ${JSON.stringify(raw)}`);
        }
        if (!/^\d+$/.test(secs) || Number(secs) < 1 || Number(secs) > 86_400) {
          throw new Refusal(`--timeout ${name} takes whole seconds between 1 and 86400, got ${JSON.stringify(secs)}`);
        }
        o.timeouts[name as TimeoutName] = Number(secs) * 1000;
        break;
      }
      case "--dry-run": o.dryRun = true; break;
      case "-h": case "--help": throw new Refusal(USAGE);
      default: throw new Refusal(`unknown option ${arg}\n${USAGE}`);
    }
  }

  // Ruled by the conductor, 2026-08-28: never guess an alias, and never
  // synthesize `cxswap auto` — the installed CLI has no such operation. The
  // refusal names the next step instead of pretending selection happened.
  if (!o.account) {
    throw new Refusal(
      `--account <cxswap-alias> is required: this watcher switches to a named account and never picks one for you.\n` +
      `next: run 'cxswap list' and pass the alias of the standby account`,
    );
  }
  return o;
}

/** Aliases cxswap knows, in listing order, from `cxswap list`. */
export function parseAliases(listOutput: string): string[] {
  const found: string[] = [];
  for (const line of listOutput.split("\n")) {
    const m = /\(([^)]+)\)/.exec(line);
    if (m && m[1]) found.push(m[1]);
  }
  return found;
}

/** The alias cxswap currently serves, from `cxswap status`. */
export function parseCurrentAlias(statusOutput: string): string | null {
  const m = /\(([^)]+)\)/.exec(statusOutput);
  return m && m[1] ? m[1] : null;
}

interface Ran {
  rc: number;
  out: string;
  err: string;
  timedOut: boolean;
}

function run(path: string, args: string[], timeoutMs: number): Ran {
  // SIGKILL, NOT THE DEFAULT SIGTERM — the bound must be the bound.
  //
  // `spawnSync`'s `timeout` sends `killSignal` and then keeps waiting, so a
  // child that traps or ignores TERM overruns it freely. Measured on this host
  // with the exact option shape: a 100ms bound against `trap '' TERM; sleep 2`
  // returned after 2015ms with status 0 and signal null; with
  // `killSignal: "SIGKILL"` the same child returned in 103ms with signal
  // SIGKILL. During an overrun this process — and the kernel lock it holds —
  // stay alive, so launchd goes on dropping every later StartInterval firing:
  // the precise failure the bounds were added to prevent, surviving inside
  // them.
  //
  // Nothing here is resumable or transactional: every child is a read or a
  // single delegated command whose effect is confirmed afterwards by
  // observation, so there is no cleanup a graceful signal would buy.
  const r = spawnSync(path, args, { encoding: "utf8", timeout: timeoutMs, killSignal: "SIGKILL" });
  if (r.error) {
    const timedOut = (r.error as NodeJS.ErrnoException).code === "ETIMEDOUT";
    // Preserve partial stdout for diagnostics on timeout; only a complete JSON
    // receipt can establish how many replacements were verified.
    return {
      rc: -1,
      out: r.stdout ?? "",
      err: timedOut ? `timed out after ${timeoutMs}ms` : String(r.error),
      timedOut,
    };
  }
  return { rc: r.status ?? -1, out: r.stdout ?? "", err: r.stderr ?? "", timedOut: false };
}

function loadState(path: string): WatcherState | null {
  try {
    return JSON.parse(readFileSync(path, "utf8")) as WatcherState;
  } catch {
    // A missing or corrupt record means no suppression, which is the safe
    // direction: the worst case is one extra relaunch, never a missed cap.
    return null;
  }
}

/**
 * THE RECORD OF INTENT IS AN AUTHORITY, SO IT IS NEVER TRUNCATED IN PLACE.
 * The phase updates below happen AFTER the credential moved and after seats
 * were replaced; a torn rewrite there would destroy a valid `phase: "intent"`,
 * and loadState reads corruption as "no suppression" — so the failure mode of
 * a bad write is the next tick re-entering a sequence that already took
 * effect. `atomicWrite` (fsatomic.ts) is the repo's existing temp+rename in
 * the destination directory; there is no second implementation here.
 */
function saveState(path: string, state: WatcherState): void {
  atomicWrite(path, `${JSON.stringify(state, null, 2)}\n`);
}

function logger(path: string) {
  mkdirSync(dirname(path), { recursive: true });
  return (fields: Record<string, string | number>): void => {
    const parts = [new Date().toISOString()];
    for (const [k, v] of Object.entries(fields)) {
      // logfmt: quote only what needs it, so `grep event=fire` finds the line a
      // reader would expect it to. A logger that quotes everything is greppable
      // only by someone who has already read the logger.
      const raw = String(v);
      const safe = raw.length > 0 && !/[\s"=]/.test(raw);
      parts.push(`${k}=${safe ? raw : JSON.stringify(raw)}`);
    }
    appendFileSync(path, `${parts.join(" ")}\n`);
  };
}

const REASON =
  "Your Codex account reached its usage cap, so TAP switched the machine to the standby " +
  "account and relaunched this seat in place. Same conversation, new process — nothing was " +
  "cleared. Re-read the last payload on your bus before continuing, then carry on where you " +
  "left off.";

export function main(argv: string[], env: NodeJS.ProcessEnv = process.env): number {
  let o: Options;
  try {
    o = parseArgs(argv, env);
  } catch (e) {
    process.stderr.write(`${(e as Error).message}\n`);
    return 2;
  }

  // One tick at a time. launchd already declines to start a second copy of a
  // job that is still running, but this file is also an operator command, and
  // the sequence below must never interleave with itself.
  const lock = acquirePathLock(o.lockPath, 1000, env);
  if (!lock) {
    process.stdout.write("codex-cap: another tick holds the lock; standing down\n");
    return 0;
  }

  try {
    const log = logger(o.logPath);
    const notified = { count: 0 };
    const state = loadState(o.statePath);
    // Returns whether the human was actually reached.
    const notify = (priority: string, message: string): boolean => {
      notified.count += 1;
      const r = run(o.notify, ["--priority", priority, message], o.timeouts.notify);
      if (r.rc !== 0) {
        log({ event: "notify-failed", rc: r.rc, timed_out: r.timedOut ? "yes" : "no", err: r.err.trim() });
        return false;
      }
      return true;
    };
    // Recurring conditions say so once per cooldown. A watcher that reports a
    // blind meter every thirty seconds trains the reader to stop reading it.
    const noteOnce = (key: string, priority: string, message: string): void => {
      const prev = state?.note;
      const fresh = prev && prev.key === key && Date.now() - Date.parse(prev.at) < o.cooldownMs;
      if (!fresh) {
        // ONLY A DELIVERED ALERT EARNS THE QUIET THAT FOLLOWS IT. Recording the
        // note unconditionally meant a notifier that timed out or exited nonzero
        // still bought fifteen minutes of silence about the condition it failed
        // to report — the outage and the report of it lost together.
        if (notify(priority, message)) {
          saveState(o.statePath, { ...(state ?? {}), note: { at: new Date().toISOString(), key } });
        }
      }
    };

    const listed = run(o.cxswap, ["list"], o.timeouts.cxswapRead);
    // BOTH OF THESE ARE UNATTENDED FAULTS, so neither may be only a stderr
    // line in a ledger nobody opens. The fixed-standby edge makes an alias
    // being renamed or removed ordinary operational drift, and the watcher is
    // then permanently unable to fire while looking healthy. Reported once per
    // cooldown, and never accompanied by a switch or a relaunch.
    if (listed.rc !== 0) {
      const why = listed.timedOut ? listed.err : `exit ${listed.rc}: ${listed.err.trim()}`;
      log({ event: "refuse", key: "cxswap-list-failed", reason: why });
      noteOnce("cxswap-list-failed", "high", `TAP codex-cap cannot read the account list ('cxswap list' ${why}); the cap watcher cannot fire.`);
      process.stderr.write(`codex-cap: 'cxswap list' failed (${why})\n`);
      return 2;
    }
    const aliases = parseAliases(listed.out);
    if (!aliases.includes(o.account)) {
      const known = aliases.join(", ") || "nothing";
      log({ event: "refuse", key: "alias-unknown", reason: `${o.account} not in [${known}]` });
      noteOnce("alias-unknown", "high", `TAP codex-cap is configured for the account ${o.account}, which cxswap does not know (it knows: ${known}). The cap watcher cannot fire.`);
      process.stderr.write(
        `codex-cap: cxswap does not know the alias ${JSON.stringify(o.account)}; it knows: ${known}\n`,
      );
      return 2;
    }

    const meter = run(o.meter[0]!, o.meter.slice(1), o.timeouts.meter);
    if (meter.rc !== 0) {
      const why = meter.timedOut ? meter.err : `exit ${meter.rc}: ${meter.err.trim()}`;
      log({ event: "refuse", key: "meter-failed", reason: why });
      noteOnce("meter-failed", "normal", `TAP codex-cap: the usage meter ${why}; the cap watcher is blind.`);
      return 0;
    }

    const d = decide({
      rows: parseMeter(meter.out),
      threshold: o.threshold,
      now: new Date(),
      state,
      cooldownMs: o.cooldownMs,
    });

    if (d.act === "idle") {
      log({ event: "idle", reason: d.reason });
      return 0;
    }
    if (d.act === "refuse") {
      log({ event: "refuse", key: d.key, reason: d.reason });
      noteOnce(d.key, "normal", `TAP codex-cap is not watching: ${d.reason}`);
      return 0;
    }

    // ---- the fire path ----------------------------------------------------

    const before = run(o.cxswap, ["status"], o.timeouts.cxswapRead);
    const current = before.rc === 0 ? parseCurrentAlias(before.out) : null;
    if (current === null) {
      log({ event: "refuse", key: "status-unreadable", rc: before.rc, reason: "cxswap status named no alias" });
      noteOnce("status-unreadable", "high", "TAP codex-cap: cxswap status named no alias; the cap swap cannot proceed.");
      return 2;
    }
    // ONE STANDBY IS ONE SWAP. `--account` names a fixed destination, so once
    // the machine is already serving it there is nothing left to switch to and
    // relaunching would replace every Codex process for no gain. A human picks
    // the next account.
    if (current === o.account) {
      log({ event: "refuse", key: "standby-live", reason: `${o.account} is already the live account` });
      noteOnce(
        "standby-live",
        "high",
        `TAP codex-cap: ${d.label} is capped and the standby account ${o.account} is already live. Pick another account.`,
      );
      process.stderr.write(`codex-cap: ${o.account} is already the live cxswap account; nothing to switch to\n`);
      return 2;
    }

    if (o.dryRun) {
      process.stdout.write(
        `codex-cap: would fire — ${d.label} ${d.gauge.name} at ${d.gauge.pct}% (threshold ${o.threshold}%); ` +
        `would switch ${current} -> ${o.account} and run: ${o.tap} session relaunch --harness codex --team=*\n`,
      );
      log({ event: "dry-run", label: d.label, gauge: d.gauge.name, pct: d.gauge.pct, from: current, to: o.account });
      return 0;
    }

    // THE RECORD OF INTENT IS WRITTEN BEFORE THE FIRST EFFECT. Everything below
    // this line can change the machine, and a tick that dies partway leaves no
    // other trace. With the record in place the next tick reads a suppression;
    // without it the next tick re-enters a sequence that may already have taken
    // effect, which is the class the repo's no-retry rule exists to prevent.
    const fired: NonNullable<WatcherState["fired"]> = {
      at: new Date().toISOString(),
      label: d.label,
      alias: o.account,
      phase: "intent",
    };
    saveState(o.statePath, { ...(state ?? {}), fired });
    log({ event: "fire", label: d.label, gauge: d.gauge.name, pct: d.gauge.pct, threshold: o.threshold, from: current, to: o.account });

    const switched = run(o.cxswap, ["switch", o.account], o.timeouts.cxswapSwitch);
    // THE SWITCH IS CONFIRMED BY OBSERVATION, NOT BY ITS EXIT CODE. Relaunching
    // every Codex seat onto a credential that did not actually move costs the
    // whole fleet's context and fixes nothing, so status is the arbiter.
    const after = run(o.cxswap, ["status"], o.timeouts.cxswapRead);
    const now = after.rc === 0 ? parseCurrentAlias(after.out) : null;
    if (now !== o.account) {
      const event = switched.rc === 0 ? "switch-unconfirmed" : "switch-failed";
      // PROVEN CLEAN vs MERELY FAILED. `now === current` means status was read
      // after the attempt AND still names the alias that was live before it, so
      // nothing moved. An unreadable status yields null, which cannot equal
      // `current` — `current` is a non-null alias by construction, since a null
      // one already returned at the `status-unreadable` branch above. That is
      // why there is no `now !== null` conjunct here: it could never be the
      // deciding term, and a mutation run proved it (removing it changed no
      // arm). A redundant guard that reads as the safety property is worse than
      // none — it invites the next reader to trust the wrong line.
      const provenNoEffect = now === current;
      log({
        event, rc: switched.rc, timed_out: switched.timedOut ? "yes" : "no",
        err: switched.err.trim(), observed: now ?? "unreadable",
        effect: provenNoEffect ? "none" : "unproven",
      });
      saveState(o.statePath, {
        ...(state ?? {}),
        fired: { ...fired, phase: provenNoEffect ? "no-effect" : "failed" },
      });
      notify(
        "high",
        `TAP codex-cap: ${d.label} is capped but the switch to ${o.account} did not take (cxswap now reports ${now ?? "nothing"}). No seats were relaunched.`,
      );
      return 1;
    }

    const relaunch = run(o.tap, ["session", "relaunch", "--harness", "codex", "--team=*", "--json", "-m", REASON], o.timeouts.relaunch);
    for (const line of `${relaunch.out}${relaunch.err}`.split("\n")) {
      if (line.trim()) log({ event: "relaunch-line", line });
    }

    // Decided on the JSON receipt, not the console or exit code — see classifyRelaunch.
    const outcome = classifyRelaunch(relaunch.rc, relaunch.out, relaunch.timedOut);
    const ok = outcome.kind === "complete" || outcome.kind === "partial" || outcome.kind === "none-found";
    log({
      event: "relaunched",
      outcome: outcome.kind,
      resumed: outcome.resumed,
      excluded: outcome.excluded,
      relaunch_rc: relaunch.rc,
      timed_out: relaunch.timedOut ? "yes" : "no",
    });
    saveState(o.statePath, {
      ...(state ?? {}),
      fired: { ...fired, phase: ok ? "relaunched" : "failed", outcome: outcome.kind },
    });

    // THE MESSAGE SAYS WHAT HAPPENED TO SEATS, not what the exit code was. The
    // credential HAS moved by this point, so a run that resumed nothing leaves
    // the fleet wedged against an account it will never read — the one outcome
    // that must never be reported as recovery.
    const cap = `${d.label} hit ${d.gauge.pct}% (${d.gauge.name}); switched to ${o.account}`;
    // THE EXCLUSION CONSEQUENCE IS APPENDED ONCE, TO WHATEVER MESSAGE IS SENT.
    //
    // Caller exclusions remain unrecovered seats even on a failed/degraded run.
    const excludedNote = outcome.excluded > 0
      ? ` ${outcome.excluded} seat(s) were excluded as the calling pane and are STILL on the old account — relaunch them from another pane.`
      : "";
    const base = {
      complete: `TAP codex-cap: ${cap} and resumed ${outcome.resumed} Codex seat(s).`,
      partial: `TAP codex-cap: ${cap} and resumed ${outcome.resumed} Codex seat(s) — PARTIAL: others refused, were excluded, or a team was skipped (exit ${relaunch.rc}). The named seats need a human.`,
      "none-found": `TAP codex-cap: ${cap}. No relaunchable Codex seat was found, so none was resumed.`,
      degraded: `TAP codex-cap: ${cap}, but NO Codex seat resumed (exit ${relaunch.rc}) — every seat refused, or a team could not be read. The seats are still on the old process and cannot see the new account.`,
      failed: relaunch.timedOut
        ? `TAP codex-cap: ${cap}, but 'tap session relaunch --harness codex --team=*' ${relaunch.err} after resuming ${outcome.resumed} seat(s). It was not retried.`
        : `TAP codex-cap: ${cap}, but 'tap session relaunch --harness codex --team=*' exited ${relaunch.rc} after resuming ${outcome.resumed} seat(s). The remaining seats are still on the old process.`,
    }[outcome.kind];
    notify(ok ? "normal" : "high", `${base}${excludedNote}`);
    return ok ? 0 : 1;
  } finally {
    lock.release();
  }
}

if (import.meta.main) {
  process.exit(main(process.argv.slice(2)));
}
