import { POSIX_LOCALE_SPACE, codexPlaceholder, dimPlaceholder } from "./terminal-text";
import { opencodeBoxText } from "./opencode-composer";
// A submission decision uses one joined frame, never an id's disappearance alone.
import { capturePane, isOpenCodeCommand, normalizeInputMatch, promptLineRe, promptRowReAwk, tmux } from "./tmux";
import { classifyPane, claudeBox, claudeFeedbackOverlay, claudeQueuedRows, isPasteCollapse } from "./pane-state";
import { approvalPrompt, detectAgentState } from "./agent-state";
import { parseStuckSentinel } from "./stuck-sentinel";

export type SubmitFrame = { state: "staged" | "empty" | "queued" | "changed" | "unobservable"; mode: "idle" | "working" | "mid-turn"; width: string; fused?: boolean };

/** Cursor warning tints recolor the composer; only its closed borders bound it. */
export function cursorComposer(frame: string): string | null {
  const raw = frame.split("\n");
  const lines = raw.map(line => line.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").trimEnd());
  let end = -1, start = -1;
  for (let i = lines.length - 1; i >= 0; i--) if (/^\s*▀{10,}\s*$/.test(lines[i]!)) { end = i; break; }
  if (end < 0 || lines.slice(end + 1).some(line => /^\s*(?:→|▄{10,})/.test(line))) return null;
  for (let i = end - 1; i >= 0; i--) if (/^\s*▄{10,}\s*$/.test(lines[i]!)) { start = i; break; }
  if (start < 0) return null;
  const box = lines.slice(start + 1, end);
  const prompt = box.findIndex(line => /^\s*→/.test(line));
  if (prompt < 0 || box.slice(0, prompt).some(line => line.trim())) return null;
  const rows = box.slice(prompt);
  rows[0] = rows[0]!.replace(/^\s*→\s*/, "");
  while (rows.length && !rows.at(-1)!.trim()) rows.pop();
  const text = rows.join("\n").trim();
  if (/^(Add a follow-up|Plan, search, build anything)(\s+ctrl\+c to stop)?$/.test(text)
      && dimPlaceholder(raw[start + 1 + prompt]!, text)) return "";
  return text;
}

/** One shared Antigravity band anchor for input and post-band modal chrome. */
function agyBand(frame: string): { lines: string[]; top: number; bottom: number } | null {
  const lines = frame.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").split("\n");
  const rule = (line: string) => /^─{10,}$/.test(line.trim());
  let bottom = -1, top = -1;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (!rule(lines[i]!)) continue;
    if (bottom < 0) { bottom = i; continue; }
    let first = i + 1;
    while (first < bottom && !lines[first]!.trim()) first++;
    if (first < bottom && /^\s*>/.test(lines[first]!)) { top = i; break; }
    bottom = i;
  }
  if (top < 0) return null;
  return { lines, top, bottom };
}

/** Preserved CLI 1.1.16 survey: terminal question/options immediately above
 * the Gemini footer. Quoted transcript or composer text cannot supply this tail.
 */
export function agySurveyOverlay(frame: string): boolean {
  const lines = frame.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").split("\n").map(line => line.trim()).filter(Boolean);
  if (lines.length < 3) return false;
  const footer = lines.at(-1)!;
  return /^(?:\? for shortcuts|esc to cancel)\s+Gemini \S.* · \S.*$/.test(footer)
    && /^\[1\] Good\s+\[2\] Fine\s+\[3\] Bad\s+\[0\] Skip$/.test(lines.at(-2)!)
    && /^(?:How's|How is) the CLI experience so far\? Help us improve:$/.test(lines.at(-3)!);
}

/** Existing Antigravity prompt-pair geometry; footer/task cards are outside input. */
export function agyComposer(frame: string): string | null {
  const band = agyBand(frame);
  if (!band) return null;
  const { lines, top, bottom } = band;
  const rows = lines.slice(top + 1, bottom);
  while (rows.length && !rows.at(-1)!.trim()) rows.pop();
  const typed = rows.map(line => line.replace(/^\s*>\s?/, ""));
  return typed.some(line => line.trim()) ? typed.join("\n") : "";
}

/** Full AGY wire equality modulo renderer-only padding and visual wrapping.
 * The caller separately requires a successfully parsed matching sentinel id,
 * so whitespace inserted into the wire grammar cannot create authority. */
export function agyReprobeInputMatches(actual: string, expected: string): boolean {
  return normalizeInputMatch(actual) === normalizeInputMatch(expected);
}

/** Modal chrome only: transcript above the band and task-card commands are data.
 * The six-row window preserves the constructed Bash control; tap-lslrc owns
 * calibration against a real permission overlay (fleet prompts are disabled).
 */
export function agyPermissionOverlay(frame: string): boolean {
  const band = agyBand(frame);
  if (!band) return false;
  let ask = -1;
  for (let i = band.bottom + 1; i < band.lines.length; i++) {
    const line = band.lines[i]!;
    if (/^\s*[●○]\s*\[\d{2}:\d{2}:\d{2}\]/.test(line)) continue;
    const lower = line.toLowerCase();
    if (lower.includes("requesting permission for:")) ask = i;
    if (ask >= 0 && i - ask <= 6 && (lower.includes("do you want to proceed?") || lower.includes("tab amend"))) return true;
  }
  return false;
}

/** Full equality modulo corroborated Claude word wrapping of an emitted control. */
export function claudeWrappedControlMatches(frame: string, expected: string): boolean {
  const want = expected.normalize("NFC").trim();
  // Unknown cell widths and intentionally multiline input retain exact matching.
  if (!/^[\x20-\x7e]+$/.test(want)
      || !/^\/(?:compact|goal|loop) .* \[\[sv:[A-Za-z0-9_-]+\]\]$/.test(want)) return false;
  const box = claudeBox(frame);
  if (!box || !box.typed.includes("\n")) return false;
  // Captured Claude controls reserve two columns on each side of the box.
  const capacity = box.columns - 4;
  const rows = box.typed.normalize("NFC").trim().split("\n");
  let offset = 0;
  for (const [index, rendered] of rows.entries()) {
    let row = rendered;
    if (index) {
      if (!row.startsWith("  ") || want[offset] !== " " || want[offset + 1] === " ") return false;
      row = row.slice(2);
      offset++;
    }
    row = row.replace(/ +$/, "");
    if (!row || row.length > capacity || !want.startsWith(row, offset)) return false;
    offset += row.length;
    if (index < rows.length - 1) {
      const nextWord = want.slice(offset + 1).split(" ")[0]!;
      // A short hard split could be an actual typed newline, not a visual wrap.
      if (want[offset] !== " " || !nextWord || row.length + 1 + nextWord.length <= capacity) return false;
    }
  }
  return offset === want.length;
}

/** Closed OpenCode input band; footer is its last nonempty left-border row. */
/**
 * The OpenCode composer, through the ONE reader in `opencode-composer.ts`.
 *
 * This used to be a second, simpler scanner: box borders, trailing blanks, a
 * `Build|Plan ·` footer row, a dim-placeholder check. It disagreed with the
 * Bash/Python reader on 8 of the 16 captured OpenCode fixtures in the repo
 * (tap-dcsg4), and every disagreement was a rule it did not have — the
 * command-palette popup leaked into the draft, the right-aligned cwd/branch
 * overlay came back AS a draft (so an idle wide pane classified as occupied and
 * native delivery parked instead of injecting), and per-row padding survived.
 * Since this feeds `readFrame` -> `classifyPane` -> `paneState`/`observePaneKind`
 * -> `deliver.ts`/`courier.ts`, those were live native-delivery answers, not a
 * dark path.
 */
function opencodeInput(frame: string): string | null {
  return opencodeBoxText(frame);
}

function readFrame(frame: string, command: string, expected: string, width = "unknown"): SubmitFrame & { text: string | null } {
  if (approvalPrompt(command, frame)) return { state: "unobservable", mode: "idle", width, text: null };
  const lines = frame.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").split("\n");
  const re = promptLineRe(command);
  let start = -1;
  for (let i = lines.length - 1; i >= 0; i--) if (re.test(lines[i]!)) { start = i; break; }
  const region = start < 0 ? [] : lines.slice(start);
  const queue = region.some(line => /^\s*tab to queue(?: message)?(?:\s+\d+% context left)?\s*$/.test(line));
  const before = start < 0 ? lines : lines.slice(0, start);
  const terminal = lines.filter(line => line.trim()).at(-1) ?? "";
  const working = before.filter(line => line.trim()).slice(-4).some(line => /^\s*[•*]\s*Working\b.*esc to interrupt/.test(line))
    || (!/^codex(?:-|$)/.test(command) && /esc to (?:interrupt|cancel)\)?\s*$/.test(terminal));
  let mode: SubmitFrame["mode"] = queue ? "mid-turn" : working ? "working" : "idle";
  if (isOpenCodeCommand(command)) {
    const actual = opencodeInput(frame);
    return { state: actual === null ? "unobservable" : actual === expected ? "staged" : actual ? "changed" : "empty", mode, width, text: actual };
  }
  if (start < 0) {
    if (normalizeInputMatch(frame).includes(normalizeInputMatch(expected))) mode = "idle";
    return { state: "unobservable", mode, width, text: null };
  }
  let actual: string;
  if (command.startsWith("claude")) {
    const box = claudeBox(frame);
    if (!box) return { state: "unobservable", mode, width, text: null };
    actual = box.typed;
  } else if (command === "agy") {
    const box = agyComposer(frame);
    if (box === null) return { state: "unobservable", mode, width, text: null };
    actual = box;
  } else if (command.startsWith("cursor")) {
    const box = cursorComposer(frame);
    if (box === null) return { state: "unobservable", mode, width, text: null };
    actual = box;
  } else if (/^codex(?:-|$)/.test(command) && expected === "/clear"
      && region[0]?.replace(re, "").trim() === expected
      && region.slice(1).filter(line => line.trim()).length === 1
      && /^\s*\/clear\s+clear the terminal and start a new chat\s*$/.test(region.slice(1).find(line => line.trim()) ?? "")) {
    // Observed Codex /clear autocomplete: one exact owned command, one matching menu row.
    actual = expected;
  } else if (/^codex(?:-|$)/.test(command)
      && codexPlaceholder(frame.split("\n")[start] ?? "")) {
    // The painted placeholder proves the composer is empty; rows below it
    // belong to the UI, even when a new footer shape is not in our grammar.
    actual = "";
  } else {
    region[0] = region[0]!.replace(re, "");
    // Only complete known Codex footer rows are chrome; arbitrary text remains.
    if (/^codex(?:-|$)/.test(command)) {
      while (region.length && !region.at(-1)!.trim()) region.pop();
      const cue = /^\s*(?:tab to queue(?: message)?(?:\s+\d+% context left)?|shift\s*\+\s*←\s+edit last queued message|\d+% context left)\s*$/;
      const status = /^\s*[^\s·]+\s+(?:low|medium|high|xhigh|max|ultra)(?: fast)?\s+·\s+(?:Context\s+\d+% left|[^·\r\n]+\s+·\s+weekly\s+\d+% left)(\s+·.*|\s+Goal paused \(\/goal resume\)|…)?\s*$/;
      // Recover a physically wrapped footer skeleton, never the prompt row.
      // A separator/ellipsis suffix (capture 1) completes an intermediate row;
      // later rows remain ambiguous input. A bare Context-left row may still
      // wrap into a separator on the next row, but never arbitrary human text.
      for (let count = 1; count <= Math.min(4, region.length - 1); count++) {
        const start = region.length - count;
        // A footer starts after the prompt or a blank separator, not inside a
        // wrapped model token whose suffix happens to match the status grammar.
        if (start > 1 && region[start - 1]!.trim() && !cue.test(region[start - 1]!)) continue;
        const rows = region.slice(-count);
        if (rows.some(row => !row.trim())) continue;
        const joins = ["", " "];
        if (joins.some(separator => status.test(rows.join(separator))
            && !rows.slice(0, -1).some((_, i) => !!status.exec(rows.slice(0, i + 1).join(separator))?.[1]))) {
          region.splice(-count);
          break;
        }
      }
      while (region.length && !region.at(-1)!.trim()) region.pop();
      if (cue.test(region.at(-1) ?? "")) region.pop();
    }
    actual = region.join("\n").trim();
  }
  if (actual && !isPasteCollapse(command, actual) && dimPlaceholder(frame.split("\n")[start] ?? "", actual, command)) actual = "";
  const bare = /^\[\[TAP v0\.23 (ask|note) [A-Za-z0-9_./-]+(?: (?:urgent|escalate|digest))?\]\]$/.test(expected);
  const matches = actual === expected || (bare && normalizeInputMatch(actual) === normalizeInputMatch(expected))
    || (command.startsWith("claude") && claudeWrappedControlMatches(frame, expected));
  return { state: matches ? "staged" : actual ? "changed" : "empty", mode, width, text: actual };
}

/**
 * The harness dispatch `tap_composer_input` used to hold, with its three
 * outcomes intact: TEXT (possibly empty, meaning a readable empty composer),
 * UNKNOWN (geometry absent — never evidence of a clear band), and BLOCKED (a
 * modal or unreadable-geometry case where the caller must not use a
 * chrome-rich region as if it were input).
 *
 * The ORDER is the contract and it is not `readFrame`'s order, which is why
 * this is its own function rather than a call into that one:
 *   - the approval check runs for claude and codex ONLY, not every harness;
 *   - claude's feedback overlay blocks before its box is read;
 *   - the generic path requires a prompt region to EXIST before cursor's box
 *     reader is consulted, so a cursor pane with no prompt row is UNKNOWN
 *     while a cursor pane with a prompt row but unreadable box geometry is
 *     BLOCKED;
 *   - nothing here collapses a dim placeholder to empty. That belongs to the
 *     caller (`tap_dim_prompt_input`), and folding it in would change what the
 *     pending-input backup preserves.
 */
export type ComposerInput = { state: "text"; text: string } | { state: "unknown" } | { state: "blocked" };

const stripCsi = (text: string): string => text.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "");

export function composerInput(frame: string, command: string): ComposerInput {
  const unknown: ComposerInput = { state: "unknown" };
  const blocked: ComposerInput = { state: "blocked" };
  const text = (value: string | null): ComposerInput => value === null ? unknown : { state: "text", text: value };

  // A leading U+FEFF survives the GENERIC path and not the delegated ones, and
  // that asymmetry is the incumbent's, not a choice. Every branch below that
  // reads through a former `tap_bun_call` — the approval check, claude's
  // overlay and box, codex, cursor, agy, opencode — crossed a process boundary
  // whose stdin decode dropped a leading byte-order mark. The generic branch
  // was `awk` and `sed` inside the same shell, so it saw the byte, and U+FEFF
  // is in no selector's space class, so a BOM-prefixed row was absent geometry
  // there. Measured: with the BOM preserved everywhere, 2 of 1593 differential
  // cases diverged on the codex branch; with it stripped everywhere, the
  // generic branch diverged instead. The frame is handed on accordingly.
  const delegated = frame.replace(/^\ufeff/, "");

  if ((command.startsWith("claude") || /^codex(?:-|$)/.test(command)) && approvalPrompt(command, delegated)) return blocked;
  if (command.startsWith("claude")) {
    if (claudeFeedbackOverlay(delegated)) return blocked;
    // `raw`, not `typed`. The Bash door returned whatever the `claude-box` CLI
    // mode prints, and that mode prints `box.raw` — trailing spaces on every
    // row preserved. `typed` additionally strips per-row trailing blanks and
    // trims the whole string, which is what `readFrame` wants for comparison
    // and NOT what this door has ever emitted. The differential caught it on 12
    // captured frames (`/compact /goal ` versus `/compact /goal`), and this
    // reader feeds the pending-input backup, where the bytes are the point.
    const box = claudeBox(delegated);
    return text(box === null ? null : box.raw);
  }
  if (/^codex(?:-|$)/.test(command)) return text(readComposerFrame(delegated, command));
  // EXACT names, as the incumbent's `[ "$cmd" = opencode ]` / `= agy` were.
  if (command === "opencode") return text(opencodeBoxText(delegated));
  // The agy reader saw an ANSI-stripped frame through the Bash pipe, so it does
  // here too rather than being handed the raw one.
  if (command === "agy") return text(agyComposer(stripCsi(delegated)));

  // Generic: the LAST prompt row and everything after it. The incumbent's awk
  // reset its accumulator at every match, which is what makes it the last — and
  // `promptRowReAwk`, not `promptLineRe`, because awk IS the oracle here and its
  // space class accepts U+00A0 where JS's `[ \t]` does not. The claude and
  // codex branches above have already returned; their oracle is the previously
  // ported module, so they keep `promptLineRe` (tap-6zzsk).
  const re = promptRowReAwk(command);
  const lines = stripCsi(frame).split("\n");
  let start = -1;
  for (let i = lines.length - 1; i >= 0; i--) if (re.test(lines[i]!)) { start = i; break; }
  if (start < 0) return unknown;
  if (command.startsWith("cursor")) {
    const box = cursorComposer(delegated);
    // Cursor box geometry unavailable: the caller must not fall back to the
    // chrome-rich region, so this is BLOCKED rather than the region's text.
    return box === null ? blocked : { state: "text", text: box };
  }
  // Hermes paints a full-width rule bar under the live composer; the rows
  // from that bar down are footer and spinner chrome, never input. The bar
  // must be real footer geometry — pane scale (>= 40 columns) and paired
  // with the composer's matching top rule — so a user's line of box-drawing
  // characters is never mistaken for the bar and truncated. Text below the
  // bar is NOT corroboration: a draft row after a user's own wide rule is
  // input too. Both real Hermes fixtures paint the matching top rule.
  // Other generic harnesses keep the unbounded region.
  let end = lines.length;
  if (command.startsWith("hermes")) {
    const barWidth = (line: string): number => {
      const t = line.trim();
      return t.length >= 40 && /^─+$/.test(t) ? t.length : -1;
    };
    for (let i = start + 1; i < lines.length; i++) {
      const width = barWidth(lines[i]!);
      if (width < 0) continue;
      const twin = lines.slice(0, start).some(l => barWidth(l) === width);
      if (twin) { end = i; break; }
    }
  }
  const region = lines.slice(start, end);
  // `sed -E "1{s/${prompt_re}[[:space:] ]*//;}"`: the row's leading padding is
  // part of the prompt pattern, and the run after the glyph is the locale's
  // space class. The two instruments disagree — awk SELECTED this row with a
  // narrower class than sed STRIPS with (`terminal-text.ts` has the table) — so
  // the padding is trimmed on both sides of the glyph in sed's wider class,
  // which is what the incumbent's pipeline did to the row awk had chosen.
  const sedStart = new RegExp(`^[${POSIX_LOCALE_SPACE}]+`);
  region[0] = region[0]!.replace(sedStart, "").replace(re, "").replace(sedStart, "");
  // Drop trailing blank rows only — NOT a whole-string trim. A blank row above
  // text stays, and so does the leading padding of every row after the first.
  const blank = new RegExp(`^[${POSIX_LOCALE_SPACE}]*$`);
  let last = region.length;
  while (last > 0 && blank.test(region[last - 1]!)) last--;
  // The incumbent's tail was `awk { print line[i] }`, which terminates EVERY
  // row it prints — so a non-empty generic region ends with a newline and an
  // empty one is empty. Every caller captures this through `$(…)`, which strips
  // trailing newlines, so the byte is invisible to them; reproducing it anyway
  // costs one conditional and removes a judgement about who is looking. Only
  // the generic path had it: the claude, codex, cursor, agy and opencode
  // branches all end in `printf '%s'`.
  const rows = region.slice(0, last);
  return { state: "text", text: rows.length ? rows.join("\n") + "\n" : "" };
}

export function readComposerFrame(frame: string, command: string): string | null {
  return readFrame(frame, command, "\0").text;
}

/** Only ordinary wire gets containment; slash/exact controls keep ownership proof. */
export function isOrdinarySentinel(expected: string): boolean {
  return /^\[\[TAP v0\.23 (?:ask|note) [\s\S]+\]\]$/.test(expected);
}

const isCodexCommand = (command: string): boolean => /^codex(?:-|$)/.test(command);
const withoutCodexPaint = (text: string): string => text.replace(/[\u2800-\u28ff]/g, " ");
const hasMintedSentinelId = (wire: string): boolean =>
  /^\[\[TAP\s+v0\.23\s+(?:ask|note)\s+(?:[A-Za-z0-9][A-Za-z0-9._-]*\/)?[A-Za-z0-9][A-Za-z0-9._-]*-[0-9]{8}T[0-9]{6}Z-[0-9a-f]{12}(?=\s|\]\])/s.test(wire);

/** Localize first, independently of modal classification or complete chrome. */
export function sentinelInputTail(frame: string, command: string): string | null {
  const lines = frame.replace(/\x1b\][\s\S]*?(?:\x07|\x1b\\)/g, "")
    .replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").split("\n");
  if (isOpenCodeCommand(command)) {
    let end = -1;
    for (let i = lines.length - 1; i >= 0; i--) {
      if (/^\s*(?:┃|╹▀)/.test(lines[i]!)) { end = i; break; }
    }
    if (end < 0) return null;
    let start = end;
    while (start > 0 && /^\s*┃/.test(lines[start - 1]!)) start--;
    return lines.slice(start, end + 1).map(line => line.replace(/^\s*┃\s?/, "")).join("\n");
  }
  const prompt = promptLineRe(command);
  let start = -1;
  for (let i = lines.length - 1; i >= 0; i--) if (prompt.test(lines[i]!)) { start = i; break; }
  if (start < 0) return null;
  // Prefer bounded geometry only when it belongs to this last prompt. A missing
  // bottom border or a modal-aware reader's null does not erase visible input.
  const bounded = command.startsWith("claude") ? claudeBox(frame)?.typed
    : command.startsWith("cursor") ? cursorComposer(frame)
    : command === "agy" ? agyComposer(frame) : null;
  if (bounded) {
    // A stale closed box above a newer prompt must never supply transcript text.
    const normalized = normalizeInputMatch(lines.slice(start).join("\n"));
    if (normalized.includes(normalizeInputMatch(bounded))) return bounded;
  }
  const tail = lines.slice(start);
  tail[0] = tail[0]!.replace(prompt, "");
  return tail.join("\n");
}

export type SentinelDecision = { action: "submit" } | { action: "withhold"; reason: "dialog" | "url" | "chip" | "not-visible" };

/** Existing active modal witnesses; footer URLs and transcript words are data. */
function obviousDialog(frame: string, command: string): boolean {
  if (command.startsWith("claude") && claudeFeedbackOverlay(frame)) return true;
  if (command === "agy" && agyPermissionOverlay(frame)) return true;
  if (detectAgentState(command, frame).agentState === "blocked") return true;
  if (isOpenCodeCommand(command)) {
    const tail = sentinelInputTail(frame, command);
    if (tail && /^\s*\/\S+\s+[^\n]*┃\s*$/m.test(tail)) return true;
  }
  return false;
}

export function sentinelSubmitDecision(frame: string, command: string, expected: string, harnessAlive = false): SentinelDecision {
  if (approvalPrompt(command, frame)) return { action: "withhold", reason: "dialog" };
  const input = sentinelInputTail(frame, command);
  const want = normalizeInputMatch(expected);
  const visible = input !== null && (normalizeInputMatch(input).includes(want) ||
    (isCodexCommand(command) && hasMintedSentinelId(expected) && normalizeInputMatch(withoutCodexPaint(input)).includes(want)));
  if (!want || !visible) {
    return { action: "withhold", reason: input !== null && isPasteCollapse(command, input) ? "chip" : "not-visible" };
  }
  if (obviousDialog(frame, command) && !harnessAlive) return { action: "withhold", reason: "dialog" };
  return { action: "submit" };
}

/** Extract, never reconstruct, one complete wire for nudge's canonical-id checks. */
export function visibleSentinel(frame: string, command: string): string | null {
  const input = sentinelInputTail(frame, command);
  if (input === null) return null;
  const matches = [...(isCodexCommand(command) ? withoutCodexPaint(input) : input).matchAll(/\[\[TAP\s[\s\S]*?\]\]/g)];
  if (matches.length !== 1) return null;
  if (!isCodexCommand(command) || hasMintedSentinelId(matches[0]![0])) return matches[0]![0];
  const raw = [...input.matchAll(/\[\[TAP\s[\s\S]*?\]\]/g)];
  return raw.length === 1 ? raw[0]![0] : null;
}

/**
 * Return the canonical visible wire id only while submission is safe. Unlike
 * the ordinary staged comparison, this deliberately compares only the parsed
 * id and ignores every other wire field plus volatile surrounding rendering;
 * nudge samples it twice after an OpenCode repaint before one Enter.
 */
export function visibleSentinelId(frame: string, command: string, harnessAlive = false): string | null {
  if (approvalPrompt(command, frame)) return null;
  if (obviousDialog(frame, command) && !harnessAlive) return null;
  const wire = visibleSentinel(frame, command);
  if (wire === null) return null;
  const parsed = parseStuckSentinel(wire, command);
  return parsed.ok ? parsed.fields.id : null;
}

export function classifySubmitFrame(frame: string, command: string, expected: string, width = "unknown", harnessAlive = false, soleContent = false): SubmitFrame {
  const read = readFrame(frame, command, expected, width);
  const { text: _text, ...result } = read;
  if (soleContent || !isOrdinarySentinel(expected)) return result;
  // tap-maavp effect 2: inside a READABLE BOUNDED composer every byte is
  // composer content, so our wire plus other non-space bytes is the
  // recipient's own input fused around it — Enter would submit that input
  // with the wire. Flag it `fused` and keep it `changed`; the caller backs up
  // the foreign bytes, clears, re-injects, then Enters. #xxx's promotion
  // stays for its own case: unknown chrome rows, or the wire visible while
  // the composer itself is unreadable or unbounded (generic regions).
  const boundedRead = read.text !== null && (isOpenCodeCommand(command)
    || command.startsWith("claude") || command.startsWith("cursor") || command === "agy");
  if (boundedRead && result.state === "changed") {
    const actual = normalizeInputMatch(read.text!);
    const want = normalizeInputMatch(expected);
    if (actual.includes(want) && actual.replace(want, "").length > 0) {
      return { ...result, state: "changed", fused: true };
    }
  }
  // A Claude delivered-but-unconsumed message parks as an indented prompt row
  // above the active box's fence while the live composer holds newer input or
  // sits empty. The Claude Bar footer hides esc-to-interrupt, so working
  // chrome is absent exactly when this queue shape appears; acceptance is the
  // bounded queue-row geometry itself (claudeQueuedRows), never transcript
  // prose at column 0. A wire still in the composer is THIS attempt, not a
  // prior queue, so composer containment stays with staged/fused handling.
  if (command.startsWith("claude") && !normalizeInputMatch(read.text ?? "").includes(normalizeInputMatch(expected))
      && claudeQueuedRows(frame).some((row) => normalizeInputMatch(row).includes(normalizeInputMatch(expected)))) {
    return { ...result, state: "queued", mode: "working" };
  }
  const decision = sentinelSubmitDecision(frame, command, expected, harnessAlive);
  // A complete wire outside an observed empty composer, while the harness is
  // working, is accepted queue state. It never authorizes another Enter.
  if (result.state === "empty" && normalizeInputMatch(frame).includes(normalizeInputMatch(expected))
      && (/^codex(?:-|$)/.test(command) ? result.mode === "working"
        : detectAgentState(command, frame.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "")).agentState === "working")) {
    return { ...result, state: "queued", mode: "working" };
  }
  return decision.action === "submit" ? { ...result, state: "staged" }
    : result.state === "staged" ? { ...result, state: "changed" } : result;
}

/** Bash supplies its existing exact-control reader's bytes; comparison lives here. */
export function composerMatches(frame: string, command: string, expected: string, allowChip = false, actual?: string, harnessAlive = false): boolean {
  if (isOrdinarySentinel(expected)) return sentinelSubmitDecision(frame, command, expected, harnessAlive).action === "submit";
  actual ??= readComposerFrame(frame, command) ?? "";
  if (!actual) return false;
  const norm = (s: string) => s.normalize("NFC").trim();
  return norm(actual) === norm(expected)
    || (command.startsWith("claude") && claudeWrappedControlMatches(frame, expected))
    || (allowChip && isPasteCollapse(command, actual) && /^\s*\[[^\]\n]+\]\s*$/.test(actual));
}

/**
 * The whole Enter-readiness decision, frame in and one token out.
 *
 * The composer read used to be a SECOND process: `tap_submit_enter_ready` piped
 * the frame to `tap_composer_input`, which spawned `submit-frame.ts
 * composer-input`, then spawned this verb with the answer as argv. Both halves
 * always read the same frame, so the second process only moved bytes. Reading
 * it in-process here is the same `composerInput` on the same input.
 *
 * `observable` is why the rc split in `tap_composer_input` does not survive the
 * move. That reader answers three ways — text, unknown (rc 3), blocked (rc 4) —
 * but its one caller here collapsed both refusals into the same pair, `actual=""`
 * and `observable=unobservable`, because `|| { ... }` cannot see which rc it
 * caught. The distinction is real and the reader keeps it for its other two
 * callers; it was never legible at this seam.
 *
 * A throw is caught rather than fatal, and that is the incumbent's shape, not a
 * defensive habit: a crashing composer reader was one process dying, which the
 * `||` read as unobservable and carried on from. Letting it kill this process
 * would turn a readable-frame-with-an-unreadable-composer into rc 5.
 *
 * TWO VIEWS, and they are not interchangeable (astra-pinnacle-reviewer-2, #xxxx).
 * The composer reader and the enter-ready predicates never saw the same bytes,
 * because they never shared a process: the CLI hands `composer-input` a
 * BOM-PRESERVING decode (`readStdinFrame`) and every other verb a BOM-STRIPPING
 * one (`Bun.stdin.text()`). `composerInput`'s generic branch is built on that —
 * it strips U+FEFF for the delegated readers and leaves it for the generic one,
 * so a BOM-prefixed prompt is deliberately absent geometry there. Reading one
 * frame and passing it to both hands the composer a view it never had, turning
 * an unobservable composer into a readable one and an rc 5 withhold into an rc 0
 * ready or an rc 2 consumed. Those reach `tap_submit_existing_verify` at
 * lib.sh:11478 and :11506, so it is effect authorization, not an internal token.
 * Collapsing the process boundary must not collapse the decode boundary with it.
 *
 * `gated` and `unread` are decided before a single frame semantic is consumed,
 * and they are separate tokens because they are separate reasons, not because
 * the caller does anything different with them. The auto-permission refusal used
 * to sit in the adapter, ahead of the capture, so a gated call issued no
 * `capture-pane` at all. It lives here now and the capture is taken
 * unconditionally: one extra read-only tmux round trip on the gated path, taken
 * deliberately so the adapter holds no decision. `captured` is how the adapter
 * reports a capture that failed without deciding what the failure means.
 */
export function enterReady(
  composerFrame: string, matchFrame: string, command: string, expected: string, id: string,
  chip: boolean, entered: boolean, alive: boolean, permissions: string,
  autoReady: boolean, captured: boolean,
): "ready" | "consumed" | "withhold" | "gated" | "unread" {
  // Order is the incumbent's: the gate was ahead of the capture, so it answers
  // first even when the capture that now precedes it failed.
  if (permissions === "auto" && !autoReady) return "gated";
  if (!captured) return "unread";

  // `actual` is only assigned where `observable` becomes true, so the two never
  // disagree and a guarded read here would be dead. The incumbent carried the
  // same redundancy across the process boundary — Bash set `actual=""` in the
  // same `||` that set `observable=unobservable`, and the module then re-applied
  // `argv[10] === "unobservable" ? "" : actual`. Dropping it is not a behavior
  // change and no differential can show that it is; the equality is structural.
  // `observable` stays load-bearing BELOW, where an unreadable composer must not
  // read as a consumed one.
  let actual = "";
  let observable = false;
  try {
    const read = composerInput(composerFrame, command);
    if (read.state === "text") { actual = read.text; observable = true; }
  } catch { /* unobservable, as the crashed subprocess was */ }

  if (permissions === "auto"
    ? readFrame(matchFrame, command, expected).state === "staged"
    : composerMatches(matchFrame, command, expected, chip, actual, alive)) return "ready";
  if (entered && observable && !normalizeInputMatch(actual).includes(normalizeInputMatch(id))
    && (!chip || !isPasteCollapse(command, actual))) return "consumed";
  return "withhold";
}

export function observeSubmitFrame(target: string, command: string, expected: string, harnessAlive = false, soleContent = false): SubmitFrame {
  const size = tmux(["display-message", "-p", "-t", target, "#{pane_width}"]);
  const width = size.code === 0 && /^\d+$/.test(size.stdout.trim()) ? size.stdout.trim() : "unknown";
  const frame = capturePane(target, true, !isOpenCodeCommand(command));
  if (frame.code !== 0 || frame.rateLimited || size.rateLimited) return { state: "unobservable", mode: "idle", width };
  return classifySubmitFrame(frame.stdout, command, expected, width, harnessAlive, soleContent);
}

// The Bash and native paths share this reader; no theme-specific second parser.
if (import.meta.main) {
  // BYTE-TRANSPARENT for `composer-input` only. `Bun.stdin.text()` strips a
  // leading U+FEFF as a byte-order mark, and the Bash pipeline this mode
  // replaces passed every byte through — U+FEFF is in no selector's space
  // class, so the incumbent read a BOM-prefixed row as absent geometry while a
  // stripped BOM turns it into a readable band. The other modes keep
  // `text()`: each one's Bash door is its own parity question and changing
  // them all here would be a behavior change this slice did not measure
  // (tap-amfle carries the census).
  // One read, both views, and each view is the decoder that actually produced it
  // rather than a reconstruction of one.
  //
  // My first attempt asserted `Bun.stdin.text()` was "the UTF-8 decode minus a
  // leading BOM" and derived the matching view with `replace(/^\ufeff/, "")`.
  // That is false and astra-pinnacle-reviewer-2 measured it: `Bun.stdin.text()`
  // also sniffs a UTF-16LE marker, so bytes `ff fe 3e 00` decode to ">" there and
  // to two U+FFFD, ">", NUL under the reconstruction. Reachable through the real
  // adapter with a NUL-free mixed-encoding capture, where it flipped rc 5
  // withhold to rc 0 ready — Enter authorization, not a decoder curiosity.
  //
  // `new Blob([bytes]).text()` is the one candidate that reproduces
  // `Bun.stdin.text()` byte-for-byte across no marker, a UTF-8 BOM, `ff fe` and
  // `fe ff`. Using it keeps every non-composer verb's decoding exactly what it
  // was, so this member changes no verb but its own.
  const bytes = await Bun.stdin.bytes();
  const raw = new TextDecoder("utf-8", { ignoreBOM: true }).decode(bytes);
  const matched = await new Blob([bytes]).text();
  const input = process.argv[2] === "composer-input" ? raw : matched;
  if (process.argv[2] === "submit-state") {
    const result = classifySubmitFrame(input, process.argv[3] ?? "", process.argv[4] ?? "", "unknown", process.argv[5] === "1");
    process.stdout.write(`${result.state}\t${result.mode}\t${result.fused ? 1 : 0}`);
  } else if (process.argv[2] === "frame-mode") {
    process.stdout.write(classifySubmitFrame(input, process.argv[3] ?? "", "\0").mode);
  } else if (process.argv[2] === "sentinel-tail") {
    const tail = sentinelInputTail(input, process.argv[3] ?? "");
    if (tail === null) process.exit(3);
    process.stdout.write(tail);
  } else if (process.argv[2] === "visible-sentinel") {
    const wire = visibleSentinel(input, process.argv[3] ?? "");
    if (wire === null) process.exit(3);
    process.stdout.write(wire);
  } else if (process.argv[2] === "auto-ready") {
    process.stdout.write(classifyPane(input, process.argv[3] ?? "", false).kind === "ready" ? "ready" : "hold");
  } else if (process.argv[2] === "auto-match") {
    process.stdout.write(readFrame(input, process.argv[3] ?? "", process.argv[4] ?? "").state === "staged" ? "yes" : "no");
  } else if (process.argv[2] === "composer-match") {
    process.stdout.write(composerMatches(input, process.argv[3] ?? "", process.argv[4] ?? "", process.argv[5] === "1", process.argv[6], process.argv[7] === "1") ? "yes" : "no");
  } else if (process.argv[2] === "enter-ready") {
    const [, , , command = "", expected = "", id = "", chip, entered, alive, permissions, autoReady, captured] = process.argv;
    process.stdout.write(enterReady(raw, matched, command, expected, id, chip === "1", entered === "1", alive === "1",
      permissions ?? "bypass", autoReady === "1", captured === "1"));
  } else if (process.argv[2] === "approval-prompt") {
    process.stdout.write(approvalPrompt(process.argv[3] ?? "", input) ? "blocked" : "clear");
  } else if (process.argv[2] === "claude-feedback-overlay") {
    process.stdout.write(claudeFeedbackOverlay(input) ? "blocked" : "clear");
  } else if (process.argv[2] === "claude-box") {
    const box = claudeBox(input);
    process.stdout.write(box === null ? "unknown" : `known:${box.raw}`);
  } else if (process.argv[2] === "codex-placeholder") {
    process.stdout.write(codexPlaceholder(input.trimEnd()) ? "yes" : "no");
  } else if (process.argv[2] === "composer-input") {
    const result = composerInput(input, process.argv[3] ?? "");
    process.stdout.write(result.state === "text" ? `text\x1f${result.text}` : result.state);
  } else if (process.argv[2] === "codex-composer") {
    const text = readComposerFrame(input, "codex");
    process.stdout.write(text === null ? "unknown" : `known:${text}`);
  } else if (process.argv[2] === "claude-wrapped-match") {
    process.stdout.write(claudeWrappedControlMatches(input, process.argv[3] ?? "") ? "yes" : "no");
  } else if (process.argv[2] === "agy-survey-overlay") {
    process.stdout.write(agySurveyOverlay(input) ? "yes" : "no");
  } else if (process.argv[2] === "agy-permission-overlay") {
    process.stdout.write(agyPermissionOverlay(input) ? "yes" : "no");
  } else if (process.argv[2] === "agy-reprobe-match") {
    process.stdout.write(agyReprobeInputMatches(input, process.argv[3] ?? "") ? "yes" : "no");
  } else {
    const reader = process.argv[2] === "cursor-composer" ? cursorComposer
      : process.argv[2] === "agy-composer" ? agyComposer : null;
    if (!reader) process.exit(2);
    const text = reader(input);
    if (text === null) process.exit(3);
    process.stdout.write(text);
  }
}
