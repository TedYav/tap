import { realpathSync, statSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, join, resolve } from "node:path";

// Resolve one skill through explicit roots, without directory discovery.
function main(argv: string[]): number {
  const name = argv[0];
  if (argv.length !== 1 || !name || !/^[A-Za-z0-9]/.test(name) || /[^A-Za-z0-9_-]/.test(name)) {
    console.error("tap help skill: expected one simple skill name");
    return 2;
  }
  const home = process.env.HOME === "" ? "/" : homedir();
  const roots = [resolve(dirname(realpathSync(import.meta.path)), "../../../skills"),
    join(home, ".agents/skills"), join(home, ".claude/skills"), join(home, ".codex/skills")];
  for (const root of roots) {
    const candidate = join(root, name, "SKILL.md");
    try {
      if (!statSync(candidate).isFile()) continue;
    } catch (error) {
      // Keep Python 3.11's missing-path cases. Unlike Python 3.14 is_file,
      // permission and I/O errors must not select a lower-priority skill.
      if (["ENOENT", "ENOTDIR", "EBADF", "ELOOP"].includes((error as NodeJS.ErrnoException).code ?? "")) continue;
      throw error;
    }
    console.log(realpathSync(candidate));
    return 0;
  }
  console.error(`tap help skill: no SKILL.md for ${name} in ${roots.join(", ")}`);
  return 1;
}

try {
  process.exitCode = main(process.argv.slice(2));
} catch (error) {
  console.error(`tap help skill: ${error}`);
  process.exitCode = 1;
}
