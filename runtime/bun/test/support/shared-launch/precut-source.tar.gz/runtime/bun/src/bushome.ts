// Bus resolution. CONTRACT.md §Bus layout, resolution order — one place, so the
// deciding rule is reportable by `whoami --verbose` and `doctor`.

import { existsSync, realpathSync, statSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { basename, dirname, join } from "node:path";

export type BusRule = "env" | "dotdir" | "legacy" | "default";

export interface BusResolution {
  home: string;
  rule: BusRule;
}

/**
 * 1. TAP_HOME set            → use it (rule `env`; a custom home is unindexable)
 * 2. <root>/.tap/bus exists  → v0.3 layout (rule `dotdir`)
 * 3. <root>/tmp/tap exists   → legacy v0.2 layout (rule `legacy`)
 * 4. neither                 → default to <root>/.tap/bus, created on demand
 *
 * Split-brain is impossible by construction: while a non-empty legacy tmp/tap
 * holds live state the `legacy` rule keeps using it, and only `tap init`
 * migrates.
 */
/**
 * PATHS THAT ARE PRINTED ARE RESOLVED, because the incumbent prints resolved
 * ones and the rubric is byte fidelity.
 *
 * Note the direction is the OPPOSITE of `displayCwd`, and that is not an
 * inconsistency to tidy away: the incumbent prints `$PWD` for the caller's
 * location (the logical name the operator typed) and a realpath for the bus
 * (the location a payload actually lives at, which a second process must be
 * able to open). One is where you are; the other is where a file is.
 */
function resolved(p: string): string {
  return realOrSelf(p.replace(/\/+$/, "") || "/");
}

export function resolveBus(repoRoot: string, env: NodeJS.ProcessEnv = process.env): BusResolution {
  const home = env.TAP_HOME;
  if (home) return { home: resolved(home), rule: "env" };
  if (existsSync(join(repoRoot, ".tap", "bus"))) return { home: join(repoRoot, ".tap", "bus"), rule: "dotdir" };
  if (existsSync(join(repoRoot, "tmp", "tap"))) return { home: join(repoRoot, "tmp", "tap"), rule: "legacy" };
  return { home: join(repoRoot, ".tap", "bus"), rule: "default" };
}

/**
 * Reject a TAP_HOME that names a CONTAINER rather than a bus, BEFORE any write.
 *
 * Why this is a real guard and not defensive noise: an arbitrary custom home is
 * a supported layout and may legitimately bootstrap, so absence of a registry
 * proves nothing. Container SHAPES are proof. Pointing TAP_HOME at a git root
 * that already holds `.tap/bus` and letting it bootstrap creates a SECOND,
 * internally consistent bus underneath the real one — mail lands in a location
 * nothing else reads, and the empty queue at the real bus looks like a quiet
 * peer rather than a split.
 *
 * Verified against the incumbent: `TAP_HOME=<git-root> tap poll x` refuses,
 * names the nested bus, and writes nothing.
 *
 * Returns the expected bus path when the value is a container, else null.
 */
export function containerRefusal(home: string): string | null {
  // Resolve physically first so aliases and trailing separators cannot bypass
  // the check by spelling the same directory differently.
  const p = realOrSelf(home.replace(/\/+$/, ""));

  // Already a canonical bus: accepted.
  if (p.endsWith("/.tap/bus") || p.endsWith("/tmp/tap")) return null;

  // `.tap` itself — its bus is one level down.
  if (basename(p) === ".tap") return join(p, "bus");

  // A root that already CONTAINS a canonical bus.
  if (existsSync(join(p, ".tap", "bus"))) return join(p, ".tap", "bus");
  if (existsSync(join(p, "tmp", "tap"))) return join(p, "tmp", "tap");

  // A legacy `tmp` container whose bus is `tmp/tap`.
  if (basename(p) === "tmp" && existsSync(join(p, "tap"))) return join(p, "tap");

  // A git worktree root, even one with no bus yet: the bus belongs beside it.
  if (isDir(p) && gitToplevel(p) === p) return join(p, ".tap", "bus");

  return null;
}

function isDir(p: string): boolean {
  try {
    return statSync(p).isDirectory();
  } catch {
    return false;
  }
}

/** Git worktree root of `cwd`, or `cwd` itself when git cannot name one. */
export function repoRoot(cwd: string = process.cwd()): string {
  return gitToplevel(cwd) || cwd;
}

function gitToplevel(p: string): string {
  const r = spawnSync("git", ["-C", p, "rev-parse", "--show-toplevel"], { encoding: "utf8" });
  return r.status === 0 ? realOrSelf(r.stdout.trim()) : "";
}

function realOrSelf(p: string): string {
  try {
    return realpathSync(p);
  } catch {
    // A not-yet-created custom home is legitimate; resolve its parent so an
    // alias in the parent chain still normalizes.
    const parent = dirname(p);
    try {
      return join(realpathSync(parent), basename(p));
    } catch {
      return p;
    }
  }
}
