// Native `tap worktree check` (tap-fni3j R12 U1): ports the deleted
// tap-worktree.sh. The verdict contract, incident history, and the
// fail-closed query ruling live in
// docs/solutions/best-practices/worktree-gc-guidelines.md and
// skills/drive/references/worktree-gc.md; branch-backed completion requires
// PR corroboration before preservation may decide (tap-dg8g).
//
// Verdict order is deliberate: identity refusals BEFORE state holds BEFORE
// evidence. Exit 0 every path reclaim / 2 any non-reclaim / 1 usage.

import { spawnSync } from "node:child_process";
import { statSync } from "node:fs";

import { TapError } from "../context";
import { physicalPath } from "../clear-fence";
import { ensureAscii } from "../fsatomic";
import { globalRegistryPath, isRegularFile, readIndexJson } from "../index-home";
import { REGISTRY_MAX_BUFFER, spawnOutcome } from "../spawn";

const USAGE = "tap help worktree";
const USAGE_LINE = "usage: tap worktree check <path>... [--json]";

type Verdict = "reclaim" | "keep" | "hold" | "refuse";
interface Row { verdict: Verdict; path: string; evidence: string }

const isObj = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v);

function usageError(detail: string): TapError {
  return new TapError(1, "usage_error", USAGE, detail);
}

// One git child in the target worktree. `unusable` (could not run, killed,
// ENOBUFS) is failure — it never counts as a successful query.
function git(path: string, args: string[]): { code: number; out: string; ok: boolean } {
  const r = spawnSync("git", ["-C", path, ...args], { encoding: "utf8", maxBuffer: REGISTRY_MAX_BUFFER });
  const ok = spawnOutcome(r) === "ran";
  return { code: r.status ?? -1, out: (r.stdout ?? "").trim(), ok };
}

export function cmdWorktree(argv: string[]): number {
  const sub = argv[0] ?? "";
  if (sub !== "check") {
    throw usageError(sub === "" || sub === "-h" || sub === "--help" ? USAGE_LINE : `unknown subcommand '${sub}'`);
  }
  const paths: string[] = [];
  let json = false;
  for (const arg of argv.slice(1)) {
    if (arg === "--json") json = true;
    else if (arg.startsWith("-")) throw usageError(`unknown flag '${arg}'`);
    else paths.push(arg);
  }
  if (paths.length === 0) throw usageError("need at least one path");

  const rows: Row[] = paths.map(checkPath);
  if (json) {
    // ensureAscii matches python json.dumps ensure_ascii=True byte for byte.
    process.stdout.write(`${ensureAscii(JSON.stringify({ ok: true, results: rows }))}\n`);
  } else {
    for (const row of rows) process.stdout.write(`${row.verdict}\t${row.path}\t${row.evidence}\n`);
  }
  return rows.every(row => row.verdict === "reclaim") ? 0 : 2;
}

function checkPath(target: string): Row {
  const row = (verdict: Verdict, evidence: string): Row => ({ verdict, path: target, evidence });
  try {
    if (!statSync(target).isDirectory()) throw new Error();
  } catch {
    return row("refuse", "no such directory");
  }
  if (!git(target, ["rev-parse", "--is-inside-work-tree"]).ok) {
    return row("refuse", "not a git worktree");
  }
  // Empty --show-prefix IFF <path> is its worktree's top level (tap-zp5zj).
  const prefix = git(target, ["rev-parse", "--show-prefix"]);
  if (!prefix.ok) return row("keep", "could not resolve worktree prefix (fail-closed)");
  if (prefix.out !== "") {
    const top = git(target, ["rev-parse", "--show-toplevel"]);
    return row("refuse", `not a worktree top level (enclosing worktree ${top.ok ? top.out : "?"})`);
  }
  // Primary discriminator: in a linked worktree --git-dir lives under the
  // primary's .git/worktrees/<name>, so the two differ; in the primary they
  // resolve to the same directory. Never a path-name comparison.
  const gd = git(target, ["rev-parse", "--absolute-git-dir"]);
  const common = git(target, ["rev-parse", "--path-format=absolute", "--git-common-dir"]);
  if (!gd.ok || !common.ok) return row("keep", "could not resolve git dirs (fail-closed)");
  if (gd.out === common.out) return row("refuse", "primary checkout");

  const claim = indexClaim(target);
  if (claim === null) return row("keep", "machine index unreadable (fail-closed)");
  if (claim !== "") return row("refuse", claim);

  // R1: the lock probe is its OWN git-dir lookup, and a failed lookup keeps —
  // "lookup failed" is not "no lock" (a single shared lookup would delete this
  // ruled branch and its arm).
  const lockDir = git(target, ["rev-parse", "--absolute-git-dir"]);
  if (!lockDir.ok) return row("keep", "could not resolve git dir for lock probe (fail-closed)");
  if (isRegularFile(`${lockDir.out}/locked`)) return row("hold", "worktree locked");
  const status = git(target, ["status", "--porcelain"]);
  if (!status.ok) return row("keep", "git status failed (fail-closed)");
  if (status.out !== "") return row("hold", "working tree dirty");

  const head = git(target, ["rev-parse", "--verify", "--quiet", "HEAD"]);
  if (!head.ok) return row("keep", "could not read HEAD (fail-closed)");
  const tip = head.out;
  // rc 1 from --quiet symbolic-ref is the LEGITIMATE detached answer; every
  // other not-ok result — rc > 1 or an unusable child (null status maps to
  // code -1) — must keep, or an unreadable HEAD walks into a reclaim heuristic
  // wearing the detached answer (arms 12/12b).
  const sym = git(target, ["symbolic-ref", "--quiet", "--short", "HEAD"]);
  if (!sym.ok && sym.code !== 1) return row("keep", "could not read HEAD (fail-closed)");
  const branch = sym.ok ? sym.out : "";

  let evidence = "";
  if (branch !== "") {
    // R1: every query on the way to completion evidence fails closed, and a
    // failed gh call DISCARDS its partial stdout — a MERGED line followed by a
    // non-zero exit is not evidence.
    const url = git(target, ["remote", "get-url", "origin"]);
    if (!url.ok) return row("keep", "origin remote unresolvable (fail-closed)");
    const facts = prFacts(url.out, branch);
    if (facts.kind === "unusable") return row("keep", `gh unavailable (fail-closed; branch ${branch})`);
    if (facts.kind === "failed") return row("keep", `no usable PR answer for branch ${branch} (gh exit ${facts.code}; fail-closed)`);
    if (facts.kind === "answer" && (facts.state === "MERGED" || facts.state === "CLOSED")) {
      // R3 (tap-dg8g): a branch name is a locator, not an identification — the
      // name is reusable and the tree may hold NEW work the merged row knows
      // nothing about. Corroborate HEAD against the PR's own oids before the
      // row counts as completion. M (the squash commit) is EQUALITY only: it
      // never contains the branch tip. Missing headRefOid, rc 1 (tip ahead of
      // or diverged from the PR head), and any other/unusable ancestry result
      // keep — the checker never removes on an uncorroborated row.
      if (facts.head === tip || (facts.merge !== "" && facts.merge === tip)) {
        evidence = facts.state === "MERGED" ? `PR MERGED (branch ${branch}), HEAD corroborated` : `PR CLOSED — abandoned (branch ${branch}), HEAD corroborated`;
      } else if (facts.head === "") {
        return row("keep", `PR ${facts.state} (branch ${branch}) lacks head corroboration (fail-closed)`);
      } else {
        const mb = git(target, ["merge-base", "--is-ancestor", tip, facts.head]);
        if (mb.ok) evidence = `PR ${facts.state} (branch ${branch}), branch tip contained by PR head`;
        else if (mb.code === 1) {
          return row("keep", `PR ${facts.state} (branch ${branch}), but branch tip ${tip.slice(0, 7)} is ahead of or diverged from PR head ${facts.head.slice(0, 7)} (fail-closed)`);
        } else {
          return row("keep", `PR head ${facts.head.slice(0, 7)} object unavailable locally (fail-closed); fetch and re-check`);
        }
      }
    }
  } else {
    // Detached: ref containment first (tap-6a4ao) — local, deterministic, and
    // it must make NO gh lookup, so the stub-counting arm can prove the order.
    const reach = git(target, ["for-each-ref", "--format=%(refname)", "--contains", "HEAD", "refs/heads/", "refs/remotes/"]);
    if (!reach.ok) return row("keep", "ref-containment query failed (fail-closed)");
    if (reach.out !== "") {
      const refs = reach.out.split("\n");
      return row("reclaim", `detached HEAD contained by ${refs[0]} (${refs.length} ref(s)); the tree holds nothing a ref does not`);
    }
    // Name recovery: the tree name gives a CANDIDATE PR; only the oids make it
    // an identification (arm 10).
    const base = target.replace(/\/+$/, "").split("/").pop() ?? "";
    const num = /^[A-Za-z]+([0-9]+)$/.exec(base)?.[1];
    if (num !== undefined) {
      // R1: the ordinal route's gh queries keep the same fail-closed rows.
      const url = git(target, ["remote", "get-url", "origin"]);
      if (!url.ok) return row("keep", "origin remote unresolvable (fail-closed)");
      const facts = prFacts(url.out, num);
      if (facts.kind === "unusable") return row("keep", `gh unavailable (fail-closed; branch ${num})`);
      if (facts.kind === "failed") return row("keep", `no usable PR answer for branch ${num} (gh exit ${facts.code}; fail-closed)`);
      if (facts.kind === "answer" && (facts.state === "MERGED" || facts.state === "CLOSED")) {
        // Detached name-recovery keeps the EXACT-equality identification: the
        // name gave a candidate, and only the tree's HEAD being one of that
        // PR's own commits makes it an identification (arm 10).
        const corroborated = (facts.merge !== "" && facts.merge === tip) || (facts.head !== "" && facts.head === tip);
        if (corroborated) {
          evidence = facts.state === "MERGED" ? `PR #${num} MERGED, HEAD corroborated` : `PR #${num} CLOSED — abandoned, HEAD corroborated`;
        }
      }
    }
  }
  if (evidence === "") {
    return row("keep", branch !== ""
      ? `no completion evidence (branch ${branch}: no merged or closed PR)`
      : "no completion evidence (detached: HEAD contained by no branch or remote-tracking ref, and no PR recovered from the tree name or its commits do not match this HEAD)");
  }
  // Preservation is the LAST conjunct and never the evidence (tap-t7rk).
  const published = git(target, ["branch", "-r", "--contains", "HEAD"]);
  if (!published.ok) return row("keep", "remote-containment query failed (fail-closed)");
  if (published.out !== "") return row("reclaim", `${evidence}; commits published on a remote`);
  const landed = git(target, ["diff", "--quiet", "origin/main", "HEAD"]);
  if (landed.ok && landed.code === 0) return row("reclaim", `${evidence}; content already on origin/main (squash catch)`);
  // rc 1 is the healthy "content differs" answer; rc >= 2 or an unusable child
  // (code -1) is a BROKEN comparison and keeps with its own evidence (25b).
  if (!landed.ok && landed.code === 1) return row("keep", `${evidence}, but the tree holds unpublished content differing from origin/main`);
  return row("keep", `${evidence}, but the origin/main comparison failed (fail-closed)`);
}

type PrAnswer =
  | { kind: "answer"; state: string; merge: string; head: string }
  | { kind: "unusable" }
  | { kind: "failed"; code: number };

// gh pr view <ref>: one TSV line "<state>\t<mergeCommit-oid>\t<headRefOid>".
// UNUSABLE (absent, killed, ENOBUFS) learned nothing; FAILED (exit n) had its
// partial stdout discarded (R1); neither is "no PR" — the caller keeps on all.
function prFacts(remote: string, ref: string): PrAnswer {
  const r = spawnSync("gh",
    ["-R", remote, "pr", "view", ref, "--json", "state,mergeCommit,headRefOid",
      "-q", '[.state, (.mergeCommit.oid // ""), (.headRefOid // "")] | @tsv'],
    { encoding: "utf8", maxBuffer: REGISTRY_MAX_BUFFER });
  const outcome = spawnOutcome(r);
  if (outcome === "unusable") return { kind: "unusable" };
  if (r.status !== 0) return { kind: "failed", code: r.status ?? -1 };
  const [state = "", merge = "", head = ""] = (r.stdout ?? "").trim().split("\t");
  return { kind: "answer", state, merge, head };
}

// The machine index's claims on <target>: "" unclaimed, a reason when claimed,
// null when the index exists but cannot be read (caller keeps, never "unclaimed").
// Historical teams contribute nothing (tap-zp5zj); roots compare by EQUALITY,
// never containment; seat occupancy is the UNION of `seats` and `agents`.
function indexClaim(target: string): string | null {
  const index = globalRegistryPath();
  if (!isRegularFile(index)) return "";
  let doc: Record<string, unknown>;
  try {
    doc = readIndexJson(index);
  } catch {
    return null;
  }
  if (!isObj(doc) || !isObj(doc.teams)) return null;
  const targetPhys = physicalPath(target);
  for (const [name, team] of Object.entries(doc.teams)) {
    if (!isObj(team)) continue;
    // Only the literal string "historical" skips the team (arm 16). A wrong
    // JSON type must never suppress claims: python str() renders a malformed
    // singleton array "['historical']" — not historical — and a JS String()
    // would read it AS historical, failing open toward reclaim (arm 16b).
    if (team.state === "historical") continue;
    const root = team.root;
    if (typeof root === "string" && root !== "" && physicalPath(root) === targetPhys) {
      return `enrolled team root (${name})`;
    }
    const reg = team.registry_location;
    if (typeof reg !== "string" || reg === "") continue;
    let acting: Record<string, unknown>;
    try {
      acting = readIndexJson(reg);
    } catch (error) {
      // A missing acting registry is "no bound tree here", not a read failure.
      if ((error as NodeJS.ErrnoException).code === "ENOENT") continue;
      return null;
    }
    if (!isObj(acting)) return null;
    const bound = isObj(acting.team) ? acting.team.worktree_root : undefined;
    if (typeof bound === "string" && bound !== "" && physicalPath(bound) === targetPhys) {
      return `enrolled team root (${name} via acting registry)`;
    }
    for (const axis of ["seats", "agents"] as const) {
      const occ = acting[axis];
      if (!isObj(occ)) continue;
      for (const [handle, seat] of Object.entries(occ)) {
        if (!isObj(seat)) continue;
        const wt = seat.registered_from_worktree;
        if (typeof wt !== "string" || wt === "") continue;
        const phys = physicalPath(wt);
        if (phys === targetPhys || phys.startsWith(`${targetPhys.replace(/\/+$/, "")}/`)) {
          return `registered seat cwd (${name}/${handle})`;
        }
      }
    }
  }
  return "";
}
