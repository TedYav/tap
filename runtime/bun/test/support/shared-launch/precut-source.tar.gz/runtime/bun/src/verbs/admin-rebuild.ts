// `tap admin rebuild-registry` (admin-r7 U5): the audit-write that re-anchors
// seat rows to panes actually observed in tmux. The plan is built from ONE
// machine-wide pane sweep; every mutation is gated on a server-generation
// recheck, a scratch-prefix guard, a full-plan validation, and a per-registry
// lock — and publishes through a complete-write+fsync+rename (amendment 3).
import { spawnSync } from "node:child_process";
import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync, realpathSync, renameSync, statSync, unlinkSync, writeSync } from "node:fs";
import { basename, dirname, join } from "node:path";
import { randomBytes } from "node:crypto";

import { ensureAscii } from "../fsatomic";
import { isFlipLive, markerSelectedIndex } from "../index-home";
import { pyReadUtf8 } from "../spool-publication";
import { isMap, loads, type JsonMap, type JsonValue } from "../watch-detect";
import { acquirePathLock } from "../panelock";
import { serverEpochNow } from "../spool-park-report";
import { serverEpochFromRaw, tmuxReadOnly } from "../tmux";
import { agentFamilies, classifyHarness, harnessFamily, isPaneId, observeProcessHarness, parsePsTable } from "../observe";
import { ensureSeatInstance, type Seat } from "../registry";
import { HELP_HANDLE, WATCH_IDENTITY, validToken } from "../ids";
import { TapError } from "../context";
import { pythonLoadErrorText, pythonProbeLoadError, readMachineIndex, serializeRegistryDocument } from "./admin";

const LABEL = "tap admin rebuild-registry";
const SWEEP_FORMAT = "#{session_name}:#{window_index}.#{pane_index}\t#{pane_id}\t#{pane_current_command}\t#{pid}:#{start_time}\t#{pane_current_path}";

interface PlanItem {
  team: string; root: string; registry: string; handle: string; pane: string;
  paneId: string; paneCmd: string; harness: string; registeredAt: string; sweepEpoch: string;
  paneMatch: boolean;
}

const cmdSubst = (text: string): string => text.replace(/\0/g, "").replace(/\n+$/, "");
const isFileTwin = (path: string): boolean => { try { return statSync(path).isFile(); } catch { return false; } };

/** registry_v20.resolve_team_registry_for_root: the marker-aware acting path,
 * resolved from the ONE machine-index row the sweep already read — root and
 * acting location come back together, so an A-root/B-registry mix cannot be
 * built. An empty or non-file live location is live_unreachable, never the bus
 * decoy beneath it; pre-flip derives the bus candidate from that same root. */
function resolveTeamRegistryForRow(marker: "live" | "absent", row: { name: string; root: string; registryLocation: string }): { state: string; path: string } {
  if (marker === "live") {
    if (row.registryLocation && isFileTwin(row.registryLocation)) return { state: "live", path: row.registryLocation };
    return { state: "live_unreachable", path: row.registryLocation };
  }
  for (const candidate of [join(row.root, ".tap", "bus", "registry.json"), join(row.root, "tmp", "tap", "registry.json")]) {
    if (isFileTwin(candidate)) return { state: "absent", path: candidate };
  }
  return { state: "absent", path: "" };
}

/** lib.sh tap_derive_handle: session → seat handle, '' when unusable. */
function deriveHandle(session: string, team: string, families: readonly string[]): string {
  if (!session) return "";
  let s = session;
  if (s.startsWith(`${team}/`)) {
    s = s.slice(team.length + 1);
    if (s.includes("/")) return "";
    if (/^[0-9]+$/.test(s)) return "";
    return validToken(s) ? s : "";
  }
  for (const prefix of [`${team}-`, `${team}_`]) {
    if (s.startsWith(prefix)) { s = s.slice(prefix.length); break; }
  }
  let keepIndex = "";
  const numbered = /^(.+)[-_]([0-9]+)$/.exec(s);
  if (numbered) {
    s = numbered[1]!;
    // 0/1 are legacy pane-numbering noise; 2+ is a deliberate sibling suffix.
    if (Number.parseInt(numbered[2]!, 10) >= 2) keepIndex = numbered[2]!;
  }
  if (!s) return "";
  if (s.includes("-")) {
    const head = s.slice(0, s.indexOf("-"));
    const rest = s.slice(s.indexOf("-") + 1);
    if (rest && classifyHarness(harnessFamily(head, families), families) !== "unsupported") s = rest;
  }
  if (/^[0-9]+$/.test(s)) return "";
  if (keepIndex) s = `${s}-${keepIndex}`;
  return validToken(s) ? s : "";
}

function reservedHandleReason(handle: string): string {
  if (handle === WATCH_IDENTITY) return "the reserved watcher identity";
  if (handle === HELP_HANDLE) return "the CLI help keyword (so 'tap <verb> help' is unambiguous for every verb)";
  return "";
}

/** tap_pane_harness_command: pane command family, with the process fallback. */
function paneHarness(pane: string, paneCmd: string, families: readonly string[]): string {
  const family = harnessFamily(paneCmd, families);
  if (classifyHarness(family, families) !== "unsupported") return family;
  const pidRun = tmuxReadOnly(["display-message", "-p", "-t", pane, "#{pane_pid}"]);
  const pid = pidRun.code === 0 ? cmdSubst(pidRun.stdout) : "";
  if (!pid) return family;
  const ps = spawnSync("ps", ["-o", "pid=,pgid=,tpgid=,comm=,command=", "-p", pid], { encoding: "utf8" });
  const observation = observeProcessHarness(pid, ps.status === 0 ? parsePsTable(ps.stdout ?? "") : null, ps.status === 0, families);
  return observation.state === "observed" ? observation.family : family;
}

function malformedPaneId(paneId: string): TapError {
  return new TapError(1, "identity_unverified", "verify tmux and retry the registry write",
    `tmux returned invalid pane_id${paneId ? ` '${paneId}'` : ""}; refusing registry write`, LABEL);
}

function refuse(detail: string, action = "repair the named registry, then rerun tap admin rebuild-registry"): TapError {
  return new TapError(1, "registry_invalid", action, detail, LABEL);
}

function applyFailure(detail: string): TapError {
  return refuse(detail || "rebuild plan could not be applied");
}

function scratchCanon(path: string): string {
  let p = path;
  if (!p.startsWith("/")) p = join(process.cwd(), p);
  try {
    if (statSync(p).isDirectory()) p = realpathSync(p);
    else p = join(realpathSync(dirname(p)), basename(p));
  } catch { /* keep the lexical path when the leaf cannot be canonicalized */ }
  return p.length > 1 ? p.replace(/\/+$/, "") : p;
}

function scratchGuard(declared: string, what: string, root: string): void {
  const canonDeclared = scratchCanon(declared);
  const canonRoot = scratchCanon(root);
  if (canonDeclared === "/" || canonRoot === canonDeclared || canonRoot.startsWith(`${canonDeclared}/`)) return;
  throw new TapError(1, "scratch_only_refused", "unset TAP_SCRATCH_ONLY, or point it at the state root you actually meant to clear",
    `TAP_SCRATCH_ONLY declares '${declared}' but ${what} resolved to '${canonRoot}' — refusing to clear state outside the declared scratch prefix`, LABEL);
}

/** registry_v20.load_registry: a missing file is an empty legacy-shaped doc. */
function loadRegistryTwin(path: string, team: string): JsonMap {
  if (!existsSync(path)) {
    return new Map<string, JsonValue>([["team", new Map<string, JsonValue>([["name", team]])], ["agents", new Map<string, JsonValue>()]]);
  }
  let raw: string;
  try { raw = pyReadUtf8(path); } catch {
    throw refuse(`tap admin rebuild-registry: registry '${path}' is invalid JSON (${pythonProbeLoadError(path)})`);
  }
  let doc: JsonValue;
  try { doc = loads(raw); } catch {
    throw refuse(`tap admin rebuild-registry: registry '${path}' is invalid JSON (${pythonLoadErrorText(Buffer.from(raw, "utf8"))})`);
  }
  if (!isMap(doc)) throw refuse(`tap admin rebuild-registry: registry '${path}' has no agents object`);
  const seatsRaw = doc.get("seats");
  // The incumbent refuses when the seats axis is not a dict AND the agents
  // axis (defaulting to {} when absent) is not a dict: a missing agents value
  // is the legacy shape, a PRESENT malformed one is evidence, never replaced.
  const agentsRaw = doc.get("agents");
  const agentsDefaulted = agentsRaw === undefined ? new Map<string, JsonValue>() : agentsRaw;
  if (!isMap(seatsRaw) && !isMap(agentsDefaulted)) {
    throw refuse(`tap admin rebuild-registry: registry '${path}' has no agents object`);
  }
  return doc;
}

/** registry_v20.seat_store: seats axis wins; agents created when absent. */
function seatStoreTwin(doc: JsonMap): { key: string; seats: JsonMap } {
  const seatsRaw = doc.get("seats");
  if (isMap(seatsRaw)) return { key: "seats", seats: seatsRaw };
  const agentsRaw = doc.get("agents");
  if (isMap(agentsRaw)) return { key: "agents", seats: agentsRaw };
  const created = new Map<string, JsonValue>();
  doc.set("agents", created);
  return { key: "agents", seats: created };
}

const mapToRecord = (m: JsonMap): Record<string, JsonValue> => Object.fromEntries(m);
const recordToMap = (r: Record<string, JsonValue>): JsonMap => new Map(Object.entries(r));

function publishDurably(doc: JsonMap, registry: string): void {
  const body = serializeRegistryDocument(doc);
  const dir = dirname(registry);
  const tmp = join(dir, `.registry.${process.pid}.${randomBytes(6).toString("hex")}`);
  let fd = -1;
  let published = false;
  try {
    fd = openSync(tmp, "wx", 0o600);
    const bytes = Buffer.from(body, "utf8");
    let written = 0;
    while (written < bytes.length) written += writeSync(fd, bytes, written, bytes.length - written);
    fsyncSync(fd);
    closeSync(fd);
    fd = -1;
    renameSync(tmp, registry);
    published = true;
    const dirFd = openSync(dir, "r");
    try { fsyncSync(dirFd); } finally { closeSync(dirFd); }
  } finally {
    if (fd !== -1) { try { closeSync(fd); } catch { /* already closed */ } }
    if (!published) { try { unlinkSync(tmp); } catch { /* best-effort reaping */ } }
  }
}

export function cmdAdminRebuild(argv: string[], scriptsDir: string): number {
  void scriptsDir;
  process.env.TAP_JSON = "0";
  let yes = false;
  for (const arg of argv) {
    if (arg === "--yes") yes = true;
    else if (arg === "--json") process.env.TAP_JSON = "1";
    else if (arg.startsWith("--")) throw new TapError(1, "unknown_option", "tap help admin rebuild-registry", `unknown option '${arg}'`, LABEL);
    else throw new TapError(1, "usage_error", "tap help admin rebuild-registry", `unexpected arg '${arg}'`, LABEL);
  }
  const selected = markerSelectedIndex();
  if (selected.marker === "invalid") {
    throw new TapError(1, "invalid_flip", "tap doctor",
      "global-registry.json is present but unreadable or wrong schema — refusing admin index ops", LABEL);
  }

  // ONE machine-wide sweep feeds every team: pane, pane_id, command, epoch raw, path.
  const sweep = tmuxReadOnly(["list-panes", "-a", "-F", SWEEP_FORMAT]);
  const paneRows = (sweep.code === 0 ? sweep.stdout : "").split("\n").filter(line => line.length > 0);
  const rebuildNow = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
  const families = agentFamilies();
  const live = selected.marker === "live";

  const plan: PlanItem[] = [];
  const skippedTeams: string[] = [];
  for (const row of readMachineIndex(selected.path)) {
    if (!row.exists) continue;
    const resolved = resolveTeamRegistryForRow(selected.marker, row);
    let registry = resolved.path;
    // invalid / live_unreachable / no path all mean "no acting registry to
    // trust" — never the bus decoy beneath it.
    if (resolved.state === "live_unreachable" || !registry) {
      if (live || resolved.state === "invalid") {
        process.stderr.write(`tap admin rebuild-registry: skipping team '${row.name}' — acting registry unreachable/invalid (refuse bus decoy)\n`);
        skippedTeams.push(row.name);
        continue;
      }
      // Pre-flip: a registry-less root still gets its minimum bus created on apply.
      const busRegistry = join(row.root, ".tap", "bus", "registry.json");
      const legacyRegistry = join(row.root, "tmp", "tap", "registry.json");
      registry = existsSync(busRegistry) ? busRegistry : existsSync(legacyRegistry) ? legacyRegistry : busRegistry;
    }
    for (const line of paneRows) {
      const [pane = "", paneId = "", paneCmd = "", paneEpoch = "", panePath = ""] = line.split("\t");
      if (!pane || !paneId) continue;
      if (!isPaneId(paneId)) throw malformedPaneId(paneId);
      if (!(panePath === row.root || panePath.startsWith(`${row.root}/`))) continue;
      const session = pane.slice(0, pane.indexOf(":"));
      const handle = deriveHandle(session, row.name, families);
      if (!handle) continue;
      const reserved = reservedHandleReason(handle);
      if (reserved) {
        process.stderr.write(`tap admin rebuild-registry: skipping pane '${pane}' — derived handle '${handle}' is ${reserved} and cannot be a seat handle\n`);
        continue;
      }
      const harness = paneHarness(pane, paneCmd, families);
      if (classifyHarness(harness, families) === "unsupported") continue;
      let sweepEpoch = "";
      try { sweepEpoch = serverEpochFromRaw(paneEpoch, process.env); } catch { sweepEpoch = ""; }
      plan.push({
        team: row.name, root: row.root, registry, handle, pane, paneId, paneCmd,
        harness, registeredAt: rebuildNow, sweepEpoch, paneMatch: false,
      });
    }
  }

  // The scratch interlock gates the APPLY, never the preview.
  if (yes && process.env.TAP_SCRATCH_ONLY) {
    const seen: string[] = [];
    for (const item of plan) {
      if (!seen.includes(item.registry)) seen.push(item.registry);
    }
    for (const registry of seen) {
      scratchGuard(process.env.TAP_SCRATCH_ONLY, "a registry tap admin rebuild-registry would rewrite", registry);
    }
  }

  const sweepEpochs = [...new Set(plan.map(item => item.sweepEpoch).filter(epoch => epoch))];
  if (sweepEpochs.length > 1) {
    const [a, b] = [...sweepEpochs].sort();
    throw applyFailure(`tap admin rebuild-registry: pane sweep reported two server generations (${a} and ${b}); rerun`);
  }
  const sweepEpoch = sweepEpochs[0] ?? "";
  const recheckEpoch = process.env.TAP_REBUILD_SERVER_EPOCH !== undefined ? process.env.TAP_REBUILD_SERVER_EPOCH : serverEpochNow();
  if (sweepEpoch && recheckEpoch && sweepEpoch !== recheckEpoch) {
    throw new TapError(1, "server_epoch_moved", LABEL,
      `tmux server generation moved during the sweep (${sweepEpoch} -> ${recheckEpoch}); nothing was written`, LABEL);
  }

  // VALIDATE THE WHOLE PLAN BEFORE THE FIRST WRITE.
  const registryOrder: string[] = [];
  for (const item of plan) if (!registryOrder.includes(item.registry)) registryOrder.push(item.registry);
  const registryTeams = new Map(registryOrder.map(registry => [registry, plan.find(item => item.registry === registry)!.team]));
  const paneHandles = new Map<string, { handle: string; proven: boolean }>();
  for (const registry of registryOrder) {
    const team = registryTeams.get(registry)!;
    const doc = loadRegistryTwin(registry, team);
    const { seats } = seatStoreTwin(doc);
    for (const [handle, seat] of seats) {
      if (!isMap(seat)) continue;
      const storedPaneId = seat.get("pane_id");
      if (typeof storedPaneId !== "string" || !storedPaneId) continue;
      const item = plan.find(candidate => candidate.registry === registry && candidate.paneId === storedPaneId);
      const proven = Boolean(item?.sweepEpoch && typeof seat.get("server_epoch") === "string" && seat.get("server_epoch") === item.sweepEpoch);
      const key = `${team}\u0000${storedPaneId}`;
      const known = paneHandles.get(key);
      if (known && known.handle !== handle) {
        throw applyFailure(`tap admin rebuild-registry: registry '${registry}' maps pane ${storedPaneId} to multiple handles`);
      }
      paneHandles.set(key, { handle, proven });
    }
  }
  for (const item of plan) {
    const known = paneHandles.get(`${item.team}\u0000${item.paneId}`);
    if (known && (known.proven || known.handle === item.handle)) {
      item.handle = known.handle;
      item.paneMatch = true;
    }
  }

  // Suffixing keeps sibling panes that derive the same base handle distinct.
  const usedByTeam = new Map<string, Set<string>>();
  for (const registry of registryOrder) {
    const team = registryTeams.get(registry)!;
    const used = usedByTeam.get(team) ?? new Set<string>();
    for (const handle of seatStoreTwin(loadRegistryTwin(registry, team)).seats.keys()) used.add(handle);
    usedByTeam.set(team, used);
  }
  for (const item of plan) {
    const used = usedByTeam.get(item.team) ?? new Set<string>();
    used.add(item.handle);
    usedByTeam.set(item.team, used);
  }
  const groups = new Map<string, PlanItem[]>();
  for (const item of plan) {
    const key = `${item.team}\u0000${item.handle}`;
    const group = groups.get(key);
    if (group) group.push(item); else groups.set(key, [item]);
  }
  for (const group of groups.values()) {
    if (group.length < 2) continue;
    // A proven pane match keeps its stored handle first; the rest get -2, -3, …
    group.sort((a, b) => Number(b.paneMatch) - Number(a.paneMatch) || (a.paneId < b.paneId ? -1 : a.paneId > b.paneId ? 1 : 0));
    const used = usedByTeam.get(group[0]!.team)!;
    for (const sibling of group.slice(1)) {
      let suffix = 2;
      while (used.has(`${sibling.handle}-${suffix}`)) suffix++;
      sibling.handle = `${sibling.handle}-${suffix}`;
      used.add(sibling.handle);
    }
  }

  const applied: PlanItem[] = [];
  if (yes) {
    for (const registry of registryOrder) {
      const items = plan.filter(item => item.registry === registry);
      mkdirSync(dirname(registry), { recursive: true });
      const lock = acquirePathLock(`${registry}.lock`);
      if (!lock) throw applyFailure(`tap admin rebuild-registry: could not lock registry '${registry}'`);
      try {
        const team = registryTeams.get(registry)!;
        const doc = loadRegistryTwin(registry, team);
        const { seats } = seatStoreTwin(doc);
        for (const item of items) {
          const existing = seats.get(item.handle);
          // A JSON null row is the incumbent's `existing is None` / `dict(
          // existing or {})`: treated as empty, not as corrupt evidence.
          // String/number/list rows stay refusals.
          if (existing !== undefined && existing !== null && !isMap(existing)) {
            throw applyFailure(`tap admin rebuild-registry: registry '${registry}' entry '${item.handle}' is not an object`);
          }
          // Plain-object world for ensureSeatInstance; lossless values survive
          // the Map↔Record round trip untouched.
          const record = mapToRecord(isMap(existing) ? existing : new Map());
          const preserve = record.status === "suspended" && record.status_reason === "incapable";
          record.delivery = "pane";
          record.harness = item.harness;
          record.pane = item.pane;
          record.pane_current_command = item.paneCmd;
          record.pane_id = item.paneId;
          record.registered_at = item.registeredAt;
          record.status = preserve ? "suspended" : "active";
          record.status_reason = preserve ? "incapable" : "";
          if (!record.registered_from_worktree) record.registered_from_worktree = item.root;
          if (item.sweepEpoch) record.server_epoch = item.sweepEpoch; else delete record.server_epoch;
          if (isFlipLive()) ensureSeatInstance(record as unknown as Seat, item.handle);
          seats.set(item.handle, recordToMap(record));
          applied.push(item);
        }
        publishDurably(doc, registry);
      } finally {
        lock.release();
      }
    }
  }

  const receipt = {
    ok: skippedTeams.length === 0,
    dry_run: !yes,
    planned: plan.map(item => ({ team: item.team, handle: item.handle, pane: item.pane, pane_id: item.paneId, harness: item.harness })),
    applied: applied.map(item => ({ team: item.team, handle: item.handle, pane: item.pane, pane_id: item.paneId, harness: item.harness })),
    ...(skippedTeams.length ? { skipped: skippedTeams, skipped_reason: "acting_registry_unreachable_or_invalid" } : {}),
  };
  if (process.env.TAP_JSON === "1") {
    process.stdout.write(`${ensureAscii(JSON.stringify(receipt))}\n`);
    if (skippedTeams.length) return 1;
    return 0;
  }
  const verb = yes ? "rebuilt" : "would rebuild";
  for (const item of yes ? applied : plan) {
    process.stdout.write(`tap admin rebuild-registry: ${verb} ${item.team}/${item.handle} from ${item.pane}\n`);
  }
  if (skippedTeams.length) {
    for (const name of skippedTeams) {
      process.stderr.write(`tap admin rebuild-registry: skipped team '${name}' — acting registry unreachable/invalid (refuse bus decoy)\n`);
    }
    throw new TapError(1, "acting_registry_unreachable", "repair acting team-registry (or tap doctor), then rerun tap admin rebuild-registry",
      `skipped ${skippedTeams.length} enrolled team(s) with unreachable/invalid acting registry: ${skippedTeams.join(" ")}`, LABEL);
  }
  return 0;
}
