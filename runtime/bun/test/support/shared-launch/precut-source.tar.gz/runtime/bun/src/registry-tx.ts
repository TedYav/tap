import type { ResolvedContext } from "./context";
import { acquireRegistryLock } from "./panelock";
import { assertSelectionCurrent } from "./selector";
import { loadRegistry, seatMap, type RegistryDoc, type Seat } from "./registry";
import { refuse } from "./launcher/catalog";

export function withActingRegistry<T>(ctx: ResolvedContext, action: (doc: RegistryDoc, seats: Record<string, Seat>) => T): T {
  const lock = acquireRegistryLock(ctx.registryPath);
  if (!lock) return refuse("launcher_registry_busy", "could not obtain registry lock");
  try {
    assertSelectionCurrent(ctx.selection!, lock);
    const doc = loadRegistry(ctx.registryPath);
    const seats = seatMap(doc);
    if (!doc.seats && !doc.agents) doc.seats = seats;
    return action(doc, seats);
  } finally { lock.release(); }
}
