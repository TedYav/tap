// One compact orchestrator. Shared focus, identity, submit and self policy stays
// with its existing owners; the Bash calls below only forward arguments.
import { existsSync, mkdirSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { constants as osConstants } from "node:os";
import { TapError } from "../context";
import { Bus } from "../bus";
import { repoRoot, resolveBus } from "../bushome";
import { stampEnvelope, validateEnvelope } from "../envelope";
import { atomicWrite, ensureAscii } from "../fsatomic";
import { mintId, utcStamp, validToken } from "../ids";
import { seatMap, type Seat } from "../registry";
import { lockRoot } from "../panelock";
import { pyReadUtf8, pyStrCompare } from "../spool-publication";
import { hasControlCharacter } from "../pane/reader";

const err = (message: string) => process.stderr.write(`${message}\n`);
const usage = (surface: string, detail: string): never => {
  throw new TapError(1, "usage_error", `tap help ${surface}`, detail, `tap ${surface}`);
};
class Cancelled extends Error { constructor(readonly code: number) { super("compact cancelled"); } }
type Result = { code: number; out: string };
type Audit = { id: string; payload: string; receipt: string; dest: string; done: string };

export async function cmdCompact(argv: string[], scripts: string, alias = false): Promise<number> {
  const surface = alias ? "command" : "compact";
  const label = alias && !process.env.TAP_CONTEXT_ENTRY ? "tap command" : "tap compact";
  const args = [...argv];

  // Cancellation covers the whole fan-out, including gaps between children.
  // Each child owns a group so a shell exiting first cannot orphan its submit.
  let cancelled = 0;
  let notifyCancel!: () => void;
  const cancellation = new Promise<void>(resolve => { notifyCancel = resolve; });
  const signals = {
    SIGINT: () => { cancelled ||= 130; notifyCancel(); },
    SIGTERM: () => { cancelled ||= 143; notifyCancel(); },
    SIGHUP: () => { cancelled ||= 129; notifyCancel(); },
  };
  for (const signal of Object.keys(signals) as (keyof typeof signals)[]) process.on(signal, signals[signal]);
  let childEnv: NodeJS.ProcessEnv = { ...process.env, TAP_VERB: "tap command", TAP_LOCK_DIR: lockRoot() };
  const checkCancelled = () => { if (cancelled) throw new Cancelled(cancelled); };
  async function run(command: string[], input?: string, quiet = false): Promise<Result> {
    checkCancelled();
    const child = Bun.spawn(command, { env: childEnv, detached: true, stdin: input === undefined ? "ignore" : Buffer.from(input), stdout: "pipe", stderr: quiet ? "ignore" : "inherit" });
    const output = new Response(child.stdout).text();
    const finished = Promise.all([child.exited, output]);
    await Promise.race([finished, cancellation]);
    if (cancelled) {
      const signal = (name: NodeJS.Signals) => {
        try { process.kill(-child.pid, name); }
        catch (error) { if ((error as NodeJS.ErrnoException).code !== "ESRCH") throw error; }
      };
      signal("SIGTERM");
      const deadline = performance.now() + 1000;
      while (performance.now() < deadline) {
        try { process.kill(-child.pid, 0); }
        catch (error) { if ((error as NodeJS.ErrnoException).code === "ESRCH") break; throw error; }
        await Bun.sleep(20);
      }
      signal("SIGKILL");
      await finished;
      throw new Cancelled(cancelled);
    }
    const [code, out] = await finished;
    return { code: child.signalCode ? 128 + osConstants.signals[child.signalCode] : code, out };
  }
  const lib = (name: string, args: string[] = [], input?: string, quiet = false) =>
    run(["bash", "-c", 'set -euo pipefail; . "$1/lib.sh"; shift; "$@" || exit "$?"', "tap-compact-shared", scripts, name, ...args], input, quiet)
      .then(result => ({ ...result, out: result.out.replace(/\n+$/, "") }));
  const discard = (audit: Audit) => { rmSync(audit.payload, { force: true }); rmSync(audit.receipt, { force: true }); };
  try {
    // Preserve tap.sh's best-effort pre-dispatch reconciliation on the native door.
    if (!args.includes("--dry-run")) await lib("tap_registry_invalidate_server_restart");
    if (alias) {
      const verb = args.shift();
      if (verb === "clear") throw new TapError(1, "usage_error", "tap help clear", "'tap command clear' is retired: it was the injection clear, and process replacement supersedes it. Use 'tap clear <seat> [-m <instruction>]' — same target, a fresh process rather than a cleared context, and it fixes harness-process rot that injection cannot", "tap command");
      if (verb !== "compact") usage(surface, "usage: tap command compact <seat>...|--all [--focus <one-line text>]  (tap command clear is retired; use tap clear)");
      if (!process.env.TAP_CONTEXT_ENTRY) err("tap command: note — 'tap command compact' is deprecated; use 'tap compact <seat>... [-m <focus>]' (same behavior, and -m is the same flag tap send uses)");
    }
    let all = false, focus = "", focusSet = false;
    const targets: string[] = [];
    for (let i = 0; i < args.length; i++) {
      const arg = args[i]!;
      if (arg === "--all") {
        if (all) usage(surface, "--all may be passed once");
        all = true;
      } else if (arg === "--focus" || (!alias && arg === "-m")) {
        if (i + 1 === args.length) usage(surface, alias ? "--focus needs text" : "-m needs one line of focus text");
        if (!alias && focusSet) usage(surface, "-m may be passed once");
        focus = args[++i]!; focusSet = true;
      } else if (!alias && (arg === "-f" || arg === "--body-file")) {
        usage(surface, '-f is not a focus flag here: unlike tap send, compact takes its focus as literal text, so -f would have injected the FILENAME. Use -m \'<focus>\' (or -m "$(cat <file>)" for a file you wrote)');
      } else if (!alias && arg === "--") continue;
      else if (arg.startsWith("--")) throw new TapError(1, "unknown_option", `tap help ${surface}`, `unknown option '${arg}'`, `tap ${surface}`);
      else {
        if (!validToken(arg)) usage(surface, `invalid seat '${arg}'`);
        targets.push(arg);
      }
    }
    if (all && targets.length) usage(surface, "choose explicit seats or --all, not both");
    if (!all && !targets.length) usage(surface, alias
      ? "usage: tap command compact <seat>...|--all [--focus <one-line text>]  (tap command clear is retired; use tap clear)"
      : "usage: tap compact <seat>...|--all [-m <one-line focus>]");
    const flag = alias ? "--focus" : "-m";
    if (/[\r\n]/.test(focus)) usage(surface, `${flag} must be one line`);
    // UTF-8 POSIX space, as in the retained Bash surface (not JS's NBSP/BOM).
    if (/^[\t-\r \u1680\u2000-\u2006\u2008-\u200a\u2028\u2029\u205f\u3000]*\//.test(focus)) usage(surface, `${flag} is context text, not a slash command`);
    if (hasControlCharacter(focus)) usage(surface, `${flag} must not contain control characters`);
    if (focus) {
      const narrowed = await lib("tap_compact_focus_narrowing", [focus]);
      if (narrowed.code > 1) throw new Error("compact focus policy unavailable");
      if (narrowed.out) throw new TapError(1, "usage_error", "tap help compact", `tap compact: focus contains exclusive/destructive phrasing: '${narrowed.out}'. A focus SUPPLEMENTS the summarizer — enumerate what to PRESERVE instead`, "tap command");
    }
    const fence = await lib("tap_reset_fence_guard", ["tap command"]);
    if (fence.code) { if (fence.out) process.stdout.write(`${fence.out}\n`); return fence.code; }
    const dirs = await lib("tap_ensure_dirs");
    if (dirs.code) { if (dirs.out) process.stdout.write(`${dirs.out}\n`); return dirs.code; }
    const pane = await lib("tap_calling_pane_id", [], undefined, true);
    const initiatorPane = pane.code === 0 ? pane.out : "";
    const actor = initiatorPane ? await lib("tap_resolve_self_handle", [initiatorPane], undefined, true) : { code: 1, out: "" };
    const initiator = actor.code === 0 ? actor.out : "";
    if (!initiator || !initiatorPane) {
      const result = await lib("tap_fail_no_actor", ["tap command", "tap command must run from a registered pane"]);
      if (result.out) process.stdout.write(`${result.out}\n`);
      return result.code || 1;
    }
    const registry = await lib("tap_acting_registry");
    if (registry.code || !registry.out || !existsSync(registry.out)) throw new TapError(1, "registry_unreachable", "tap doctor", "acting registry unreachable for tap command", "tap command");
    // Match the retained lib.sh bus owner, including an explicit custom home;
    // the acting registry above has its own authority and is not bus/registry.
    const bus = new Bus(resolveBus(repoRoot()).home);
    childEnv = { ...childEnv, TAP_HOME: bus.home };
    const rows = () => seatMap(JSON.parse(pyReadUtf8(registry.out)));
    if (all) {
      for (const [handle, row] of Object.entries(rows()).sort(([a], [b]) => pyStrCompare(a, b))) {
        if (row && typeof row === "object" && !Array.isArray(row) && (row.status === undefined ? "active" : row.status) === "active" && row.delivery !== "poll" && row.pane && typeof row.pane_id === "string" && row.pane_id && row.pane_id !== initiatorPane && handle !== initiator) targets.push(handle);
      }
      if (!targets.length) throw new TapError(1, "not_found", "tap register", "--all found no active peer pane seats", "tap command");
    }
    function prepare(target: string): Audit {
      const id = mintId(initiator);
      mkdirSync(bus.stagingDir, { recursive: true });
      const audit = { id, payload: join(bus.stagingDir, `.tap-command-success.${id}`), receipt: join(bus.receiptsDir, `.tap-command-success.${id}`), dest: bus.payloadPath(id), done: bus.donePath(id) };
      let payloadOwned = false, receiptOwned = false;
      try {
        if ([audit.dest, audit.done, join(bus.home, "spool", `${id}.md`), join(bus.home, "spool", `${id}.meta.json`)].some(existsSync)) throw new Error(`could not reserve unique durable audit '${id}'`);
        const source = `---\ncommand_target: ${target}\ncommand_verb: compact\ncommand_status: success\n---\n\ntap command compact ${target}: success\n`;
        const payload = stampEnvelope(source, { id, from: initiator, to: initiator, kind: "command", path: audit.dest, reply: "settle-only" });
        const valid = validateEnvelope(payload);
        if (!valid.ok) throw new Error(valid.reason);
        writeFileSync(audit.payload, payload, { flag: "wx", mode: 0o600 });
        payloadOwned = true;
        writeFileSync(audit.receipt, `${ensureAscii(JSON.stringify({ id, status: "done", at: utcStamp(), by: initiator, via: "done", auto: true, command_status: "success" }))}\n`, { flag: "wx", mode: 0o600 });
        receiptOwned = true;
        return audit;
      } catch (error) {
        if (payloadOwned) rmSync(audit.payload, { force: true });
        if (receiptOwned) rmSync(audit.receipt, { force: true });
        throw error;
      }
    }
    async function commit(audit: Audit): Promise<boolean> {
      checkCancelled();
      try {
        if (!existsSync(audit.payload) || !existsSync(audit.receipt)) throw new Error("prepared audit is incomplete; refusing to claim success");
        if (existsSync(audit.dest) || existsSync(audit.done)) throw new Error(`prepared audit '${audit.id}' collided before commit`);
        renameSync(audit.payload, audit.dest);
        try { atomicWrite(bus.placedPath(audit.id), `${JSON.stringify({ id: audit.id, via: "command", at: utcStamp() })}\n`); }
        catch { err(`tap command: warning: placed receipt not written for ${audit.id}`); }
        renameSync(audit.receipt, audit.done);
        await lib("tap_reset_generation_touch", ["command"]);
        return true;
      } catch (error) {
        if (error instanceof Cancelled) throw error;
        err(`tap command: ${error instanceof Error ? error.message : error}`);
        return false;
      }
    }
    async function harness(pane: string): Promise<string> {
      const current = await lib("tmux", ["display-message", "-p", "-t", pane, "#{pane_current_command}"], undefined, true);
      const detected = await lib("tap_pane_harness_command", [pane, current.out]);
      return (await lib("tap_harness_family", [detected.out])).out;
    }
    async function self(target: string): Promise<number> {
      if ((await harness(initiatorPane)).startsWith("codex")) {
        err("tap compact: Codex seats compact themselves: write a handoff, then run self.sh compact --handoff <file> -- '<focus>'"); return 1;
      }
      if (!focus) { err(`tap compact: refusing to compact '${target}' (yourself) with no -m: the focus is the only thing you can add that the default summarizer cannot, and you are the only caller who knows it. Pass -m '<live threads, paths, unresolved decisions>'.`); return 1; }
      const path = join(scripts, "../../self/scripts/self.sh");
      if (!existsSync(path)) { err(`tap compact: self-compaction needs the self skill's injector at ${path}; it is missing (run ./install.sh from the primary checkout)`); return 1; }
      const result = await run(["bash", path, "compact", "--", focus]);
      if (result.out) process.stdout.write(result.out);
      if (!result.code) { process.stdout.write(`${label}: compact ${target}: ok (self)\n`); return 0; }
      if (result.code === 6) return 6;
      if (result.code === 7) { await lib("tap_attention", ["command", "degraded", `self-compact of '${target}' landed but its resume ping did NOT; this seat may stop after compacting — any inbound message restarts it`]); return 6; }
      err(`tap compact: self-compaction of '${target}' failed (self.sh rc=${result.code})`); return 1;
    }
    async function one(target: string): Promise<number> {
      if (target === initiator) return self(target);
      let row: Seat | undefined;
      try { row = rows()[target]; } catch { /* incumbent reports unknown seat */ }
      if (!row || typeof row !== "object" || Array.isArray(row)) { err(`tap command: unknown seat '${target}'`); return 1; }
      if (["status", "pane", "pane_id", "harness", "delivery", "cost_mode", "include_policy", "reply_to", "session", "server_epoch", "boot_id", "registered_at"].some(key => row![key] !== undefined && typeof row![key] !== "string") || (row.status_reason && typeof row.status_reason !== "string")) { err(`tap command: unknown seat '${target}'`); return 1; }
      const field = (key: string, fallback = "") => row![key] === undefined ? fallback : typeof row![key] === "string" ? row![key] as string : "";
      let pane = field("pane"), paneId = field("pane_id"), session = field("session");
      if (paneId && paneId === initiatorPane) return self(target);
      const status = field("status", "active"), delivery = field("delivery", "pane"), rowHarness = field("harness");
      if (status !== "active" || delivery === "poll" || !pane) { err(`tap command: '${target}' is not an active pane seat`); return 1; }
      if (!paneId) { err(`tap command: '${target}' has no stable pane identity; refusing`); return 1; }
      const epoch = await lib("tap_server_epoch_now", [], undefined, true), boot = await lib("tap_boot_id", [], undefined, true);
      const observation = await lib("tap_seat_observed_record", [status, delivery, pane, paneId, session, field("registered_at"), field("server_epoch"), epoch.out, field("boot_id"), boot.out, rowHarness, field("status_reason")]);
      const [state, reason, resolvedPane, resolvedId] = observation.out.split("\x1f");
      if (observation.code || state !== "active" || !resolvedPane || !resolvedId) { err(`tap command: '${target}' pane identity is not usable (${state ?? "unknown"}${reason ? `: ${reason}` : ""}); refusing`); return 1; }
      pane = resolvedPane; paneId = resolvedId;
      if (!session && pane.includes(":")) session = pane.split(":", 1)[0]!;
      if (paneId === initiatorPane) return self(target);
      const family = await harness(pane);
      if ((await lib("tap_classify_harness", [family])).out !== "agent") { err(`tap command: '${target}' uses unsupported harness '${family}'`); return 1; }
      if (family === "codex") { err(`tap compact: '${target}' is a Codex seat; ask it to checkpoint and self-trigger (self.sh compact --handoff FILE -- FOCUS)`); return 1; }
      const mode = await lib("tap_compact_focus_mode", [family]);
      if (mode.code || !["inline", "deferred", "unsupported"].includes(mode.out)) throw new Error("compact focus capability unavailable");
      if (mode.out === "unsupported") {
        await lib("tap_attention", ["command", "degraded", family === "hermes"
          ? `compact unavailable for '${target}' (${family}); use a manual keep-list, then 'tap clear ${target}' and re-brief it over the bus — hermes takes no -m, so a keep-list passed there is discarded — or leave the context alone`
          : `compact unavailable for '${target}' (${family}); use a manual keep-list, then 'tap clear ${target} -m <keep-list>' or leave the context alone`]);
        return 6;
      }
      const submit = (text: string) => {
        const id = mintId(initiator);
        // Fidelity ruling: OpenCode PEER keeps this suffix; SELF remains bare.
        return lib("tap_submit_verify", [pane, family, `${text} [[sv:${id}]]`, id, target, "0", "id", "", target, paneId, session, rowHarness]);
      };
      let audit: Audit;
      try { audit = prepare(target); }
      catch (error) { err(`tap command: compact audit preparation failed for '${target}'; refusing before pane input (${error})`); return 1; }
      {
        const result = await submit(`/compact${focus && mode.out === "inline" ? ` ${focus}` : ""}`);
        if (result.code) { discard(audit); err(`tap command: 'compact' submit failed for '${target}' (rc=${result.code})`); return 1; }
        let pingRc = 0;
        if (focus) {
          const body = join(bus.stagingDir, `.tap-compact-focus.${mintId(initiator)}`);
          try {
            writeFileSync(body, `Post-compaction focus for ${target}, written before the compaction by ${initiator}.\n\nYour context was just compacted by \`tap compact\`. Your summary is lossy;\nthese bytes are not. This payload is settle-only — settling it is how ${initiator}\nlearns the focus reached you, so settle it even if you were already working.\n\nFOCUS: ${focus}\n\nThen check your task list for work already claimed. If work is in progress\nor owed, continue it without waiting to be asked.\n`, { flag: "wx", mode: 0o600 });
            pingRc = (await run(["bash", join(scripts, "tap-send.sh"), target, "-f", body, "--from", initiator, "--fyi", "--wake"])).code;
          } catch (error) { if (error instanceof Cancelled) throw error; err(`tap command: could not stage the focus message for '${target}'`); pingRc = 1; }
          finally { rmSync(body, { force: true }); }
        } else {
          const ping = await lib("tap_handoff_ping", ["", target, pane]);
          pingRc = ping.code || (await submit(ping.out)).code;
        }
        if (pingRc) {
          await commit(audit);
          if (focus) {
            err(`tap command: the focus that did NOT reach '${target}' was:\n  ${focus}`);
            err(`tap command: re-send it by hand — put that text in a file and run: tap send ${target} -f <file> --fyi --wake`);
          }
          await lib("tap_attention", ["command", "degraded", `compact reached '${target}' but its wake did NOT land (rc=${pingRc}); that seat may stop after compacting${focus ? ", and its focus never arrived" : ""} — send it any message to restart it — use 'tap send --wake'`]);
          return 6;
        }
        if (!await commit(audit)) { err(`tap command: 'compact' reached '${target}', but its terminal success audit failed`); return 1; }
        process.stdout.write(`${label}: compact ${target}: ok\n`);
        return 0;
      }
    }
    let hard = false, degraded = false;
    for (const target of targets) {
      checkCancelled();
      const code = await one(target);
      if (code === 6) degraded = true;
      else if (code) hard = true;
    }
    return hard ? 1 : degraded ? 6 : 0;
  } catch (error) {
    if (error instanceof Cancelled) return error.code;
    throw error;
  } finally {
    for (const signal of Object.keys(signals) as (keyof typeof signals)[]) process.off(signal, signals[signal]);
  }
}
