import { readFileSync, readdirSync, statSync } from "node:fs";

/** Test content without changing the bytes retained or pasted. */
export function hasInputText(text: string): boolean { return text.trim().length > 0; }

/** The backup writer adds exactly one newline after the original draft. */
export function inputBackupBody(raw: string): string {
  const fence = raw.indexOf("\n---\n", 4);
  const marker = "\n## Backed-up input\n\n";
  const bodyAt = fence + "\n---\n".length;
  if (!raw.startsWith("---\n") || fence < 0
      || !raw.slice(4, fence).split("\n").includes("schema_version: 1")
      || !raw.startsWith(marker, bodyAt) || raw.length <= bodyAt + marker.length || !raw.endsWith("\n")) {
    throw new Error("invalid input backup body");
  }
  return raw.slice(bodyAt + marker.length, -1);
}

type DraftEntry = { created: Buffer; payload: Buffer; path: Buffer; key: Buffer };

/** Match the old field reader: first value before the second exact fence. */
function draftFields(raw: Buffer): Map<string, Buffer> {
  const fields = new Map<string, Buffer>();
  let fences = 0;
  // latin1 is a lossless byte view; malformed UTF-8 must not alter C-sort order.
  for (const line of raw.toString("latin1").split("\n")) {
    if (line === "---" && ++fences === 2) break;
    for (const field of ["handle", "created_at", "payload_id"]) {
      if (!fields.has(field) && line.startsWith(`${field}: `)) {
        fields.set(field, Buffer.from(line.slice(field.length + 2).replace(/\0/g, ""), "latin1"));
      }
    }
  }
  return fields;
}

export function draftEntries(directory: string, handle: string): DraftEntry[] {
  try { if (!statSync(directory).isDirectory()) return []; } catch { return []; }
  const entries: DraftEntry[] = [];
  const owner = Buffer.from(handle);
  for (const name of readdirSync(directory, { encoding: "buffer" })) {
    if (name[0] === 46 || !name.subarray(-3).equals(Buffer.from(".md"))) continue;
    const path = Buffer.concat([Buffer.from(directory.endsWith("/") ? directory : `${directory}/`), name]);
    try { if (!statSync(path).isFile()) continue; } catch { continue; }
    const fields = draftFields(readFileSync(path));
    if (!fields.get("handle")?.equals(owner)) continue;
    const created = fields.get("created_at");
    const payload = fields.get("payload_id");
    if (!created?.length || !payload?.length) continue;
    // sort -r compares the complete record: timestamp, payload id, then path.
    const key = Buffer.concat([created, Buffer.from("\t"), payload, Buffer.from("\t"), path]);
    entries.push({ created, payload, path, key });
  }
  return entries.sort((a, b) => Buffer.compare(b.key, a.key));
}

export function draftView(directory: string, handle: string, list: boolean, requested = ""): Buffer {
  const entries = draftEntries(directory, handle);
  if (list) {
    if (!entries.length) return Buffer.from(`tap draft: no drafts backed up for ${handle}\n`);
    return Buffer.concat([Buffer.from("CREATED\tPAYLOAD_ID\n"), ...entries.slice(0, 10).map(entry =>
      Buffer.concat([entry.created, Buffer.from("\t"), entry.payload, Buffer.from("\n")]))]);
  }
  return (requested ? entries.find(entry => entry.payload.equals(Buffer.from(requested))) : entries[0])?.path ?? Buffer.alloc(0);
}

if (import.meta.main) {
  try {
    if (Bun.argv[2] === "content" && Bun.argv.length === 3) {
      process.stdout.write(hasInputText(await Bun.stdin.text()) ? "yes" : "no");
    } else if (Bun.argv[2] === "body" && Bun.argv.length === 4) {
      process.stdout.write(inputBackupBody(readFileSync(Bun.argv[3]!, "utf8")));
    } else if (Bun.argv[2] === "drafts" && Bun.argv.length === 7 && ["0", "1"].includes(Bun.argv[5]!)) {
      process.stdout.write(draftView(Bun.argv[3]!, Bun.argv[4]!, Bun.argv[5] === "1", Bun.argv[6]!));
    } else throw new Error("invalid input backup operation");
  } catch (error) { console.error(String(error)); process.exit(2); }
}
