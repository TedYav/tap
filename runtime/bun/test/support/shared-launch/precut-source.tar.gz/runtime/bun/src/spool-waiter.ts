// Stamp before loading the loop, as watch-run does. Refresh preserves PID, lease and cadence.
import { join } from "node:path";
import { makeRefresh } from "./watch-run";

// Checked against the import closure by spool-waiter.test.ts.
export const WAITER_SOURCES: readonly string[] = [
  "agent-state.ts", "agy-survey.ts", "bus-archive-index.ts", "bus.ts", "bushome.ts", "clear-fence.ts",
  "context-census.ts", "context-tokens.ts", "context-window.ts", "context.ts", "courier-contract.ts",
  "courier.ts", "debug-capture.ts", "delivery-attempt.ts", "delivery-clock.ts",
  "delivery-permissions.ts", "digest-window.ts", "envelope.ts", "error-line.ts", "events.ts", "first-run.ts",
  "fsatomic.ts", "help.ts", "harness-queue.ts", "ids.ts", "index-home.ts", "injection-behavior.ts", "input-backup.ts",
  "iterm-viewer.ts", "latest-outbound.ts", "launcher/attach-partition.ts",
  "launcher/catalog-listing.ts", "launcher/catalog-metadata.ts", "launcher/catalog-notices.ts",
  "launcher/catalog.ts", "launcher/config-args.ts", "launcher/effects.ts", "launcher/naming.ts",
  "launcher/permissions.ts",
  "launcher/types.ts", "lifecycle-diagnostics.ts",
  "lifecycle-target.ts", "lossless-json.ts", "native-error.ts", "notice-submit.ts", "notice.ts", "observe-gather.ts",
  "observe.ts", "opencode-composer.ts", "out-retire.ts", "pane-state.ts", "pane/geometry.ts",
  "pane/reader.ts", "panelock.ts", "payload-fields.ts", "pending-reservation.ts",
  "pyint.ts", "queue-explanation.ts", "recovery-policy.ts", "recovery/state.ts",
  "registry-tx.ts", "registry.ts", "remind-job.ts", "remind-lock.ts", "remind.ts", "reset.ts", "routing.ts",
  "seat-adopt.ts", "selector.ts", "sentinel-preview.ts", "sentinel.ts", "slices/delivery-disposition.ts",
  "slices/waiter-scope.ts", "spawn.ts", "spool-backlog.ts", "spool-deadline.ts", "spool-grace.ts",
  "spool-park-report.ts", "spool-park.ts", "spool-publication.ts", "spool-reown.ts", "spool-sidecar.ts",
  "spool-state.ts", "spool-waiter-loop.ts", "spool-waiter.ts", "startup-trace.ts", "stuck-sentinel.ts",
  "submit-frame.ts", "submit-phase.ts", "team-override.ts", "team-stop-queue.ts", "team/doctor.ts", "team/purge.ts", "session-store.ts", "session-identity-owner.ts", "team/attach.ts", "team/detach.ts",
  "team/reset-components.ts", "team/reset.ts", "team/restore.ts", "team/selection.ts", "team/stop-clear.ts", "team/stop-plan.ts", "team/stop-tx.ts", "team/stop.ts",
  "terminal-text.ts", "tmux.ts", "verbose.ts", "verbs/refresh.ts", "verbs/team.ts", "watch-detect.ts",
  "watch-lease.ts", "watch-loop.ts", "watch-notice.ts", "watch-registry.ts", "watch-run.ts",
  "watch-sidecar.ts",
];

if (import.meta.main) {
  const scriptsDir = join(import.meta.dir, "../../../skills/tap/scripts");
  let resume: string[] = [], token = process.env.TAP_SPOOL_REOWN_TOKEN || "";
  const refresh = makeRefresh([
    ...WAITER_SOURCES.map(file => join(import.meta.dir, file)),
    join(scriptsDir, "lib.sh"), join(scriptsDir, "style.sh"),
  ], process.argv[1]!, line => process.stderr.write(`${line}\n`), () => {
    process.execve!(process.execPath, [process.execPath, process.argv[1]!, process.argv[2]!, ...resume],
      { ...process.env, TAP_SPOOL_REOWN_TOKEN: token });
  });
  try {
    const { runWaiter } = await import("./spool-waiter-loop");
    process.exitCode = await runWaiter({ argv: process.argv.slice(2), scriptsDir, refresh: (last, remaining, owned) => {
      resume = ["--resume-cadence", last, ...remaining]; token = owned;
      return refresh();
    } });
  } catch (error) {
    process.stderr.write(`tap spool waiter: ${(error as Error).message}\n`);
    process.exitCode = 1;
  }
}
