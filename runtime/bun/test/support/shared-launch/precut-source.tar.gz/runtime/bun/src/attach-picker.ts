import { existsSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { StringDecoder } from "node:string_decoder";
import { loadGlobalRegistry, legacyTeamsPath, readIndexJson, resolveTeamFromDoc } from "./index-home";
import { resolveBus } from "./bushome";
import { TapError } from "./context";
import { pyReadUtf8 } from "./spool-publication";
import { tmuxReadOnly } from "./tmux";

export interface PickerSeat { handle: string; harness: string; session: string; crew: boolean }
export interface PickerTeam { name: string; state: string; detail: string; seats: PickerSeat[] }
const object = (v: unknown): v is Record<string, any> => !!v && typeof v === "object" && !Array.isArray(v);
const text = (v: unknown): string => typeof v === "string" ? v : "";
const safe = (v: string) => v.replace(/[\x00-\x1f\x7f-\x9f]/g, " ");

/** One index and tmux snapshot; the final attach still revalidates the selected seat. */
export function pickerModel(env = process.env): { teams: PickerTeam[]; observable: boolean } {
  const snapshot = loadGlobalRegistry(env.TAP_INDEX_HOME);
  if (snapshot.marker === "invalid") throw new TapError(1, "invalid_flip", "tap doctor", "invalid machine registry");
  const legacy = legacyTeamsPath(env.TAP_INDEX_HOME);
  const index = snapshot.marker === "live" ? snapshot.doc : existsSync(legacy) ? readIndexJson(legacy) : {};
  const members = object(index?.teams) ? index.teams : {};
  const live = tmuxReadOnly(["list-sessions", "-F", "#{session_name}"], env);
  const sessions = new Set(live.code === 0 ? live.stdout.trimEnd().split("\n") : []);
  const teams: PickerTeam[] = [];
  for (const name of Object.keys(members).sort()) {
    const meta = members[name]; if (!object(meta)) continue;
    const team: PickerTeam = { name, state: "ok", detail: "", seats: [] };
    teams.push(team);
    if (meta.state === "historical") { team.state = "historical"; team.detail = "no live seats"; continue; }
    if (!text(meta.root)) { team.state = "no_root"; team.detail = "index entry names no worktree"; continue; }
    let path: string;
    if (snapshot.marker === "live") {
      const found = resolveTeamFromDoc(snapshot.doc!, name);
      if (found.status !== "ok") { team.state = "unreachable"; team.detail = "acting registry unreachable"; continue; }
      path = found.registryLocation;
    } else path = join(resolveBus(meta.root, {}).home, "registry.json");
    let registry: unknown;
    try { registry = JSON.parse(pyReadUtf8(path)); }
    catch (error) {
      team.state = error instanceof SyntaxError ? "corrupt" : "unreadable";
      team.detail = error instanceof SyntaxError ? "acting registry is not valid JSON" : "acting registry cannot be read";
      continue;
    }
    const seats = object(registry) ? ("seats" in registry ? registry.seats : registry.agents) : null;
    if (!object(seats)) { team.state = "corrupt"; team.detail = "acting registry has no seat map"; continue; }
    for (const handle of Object.keys(seats).sort()) {
      const row = seats[handle];
      if (!object(row) || row.status !== "active" || row.delivery === "poll") continue;
      const session = text(row.session) || text(row.pane).split(":", 1)[0] || "";
      if (session && sessions.has(session)) team.seats.push({ handle, session, harness: text(row.harness), crew: row.crew === true });
    }
  }
  return { teams, observable: live.code === 0 };
}

export class Picker {
  layer = 1; cursor = 0; teamCursor = 0; showAll = false; filtering = false;
  teamQuery = ""; seatQuery = ""; status = ""; action: "" | "quit" | "attach" = ""; target = "";
  team!: PickerTeam;
  constructor(readonly teams: PickerTeam[]) {}
  get query() { return this.layer === 1 ? this.teamQuery : this.seatQuery; }
  set query(value: string) { if (this.layer === 1) this.teamQuery = value; else this.seatQuery = value; this.cursor = 0; }
  teamView() { return this.teams.filter(t => (this.showAll || t.state === "ok" && t.seats.length > 0) && t.name.toLocaleLowerCase().includes(this.teamQuery.toLocaleLowerCase())); }
  seatView() { return this.team.seats.filter(s => `${s.handle} ${s.harness} ${s.session}`.toLocaleLowerCase().includes(this.seatQuery.toLocaleLowerCase())); }
  selectedTeam() { return this.teamView()[this.cursor]!; }
  step(key: string) {
    this.status = "";
    if (key === "eof" || key === "interrupt") { this.action = "quit"; return; }
    if (this.filtering) {
      if (key === "esc") { this.filtering = false; return; }
      if (key === "backspace") { this.query = [...this.query].slice(0, -1).join(""); return; }
      if (key === "clear") { this.query = ""; return; }
      if ([...key].length === 1 && !/[\x00-\x1f\x7f]/.test(key)) { this.query += key; return; }
    } else {
      if (key.toLowerCase() === "f") { this.filtering = true; return; }
      if (key.toLowerCase() === "q") { this.action = "quit"; return; }
      if (key.toLowerCase() === "i") key = "up";
      if (key.toLowerCase() === "j") key = "down";
      if (key.toLowerCase() === "a" && this.layer === 1) { this.showAll = !this.showAll; this.cursor = 0; return; }
    }
    const count = this.layer === 1 ? this.teamView().length : this.seatView().length;
    if (key === "up" || key === "down") {
      if (count) this.cursor = (this.cursor + (key === "up" ? -1 : 1) + count) % count;
    } else if (key === "esc" || key === "left") {
      if (this.layer === 1) { if (key === "esc") this.action = "quit"; }
      else { this.layer = 1; this.cursor = this.teamCursor; this.filtering = false; }
    } else if (key === "enter" || key === "right" && this.layer === 1) {
      if (!count) { this.status = "no matching rows"; return; }
      if (this.layer === 1) {
        const selected = this.selectedTeam();
        if (selected.state !== "ok") { this.status = `${selected.name}: ${selected.state} — ${selected.detail}`; return; }
        this.team = selected; this.teamCursor = this.cursor; this.cursor = 0; this.seatQuery = ""; this.layer = 2; this.filtering = false;
      } else { this.target = `${this.team.name}/${this.seatView()[this.cursor]!.handle}`; this.action = "attach"; }
    }
  }
}

export function seatRow(seat: PickerSeat, team: string, pad = 0, harnessPad = 0) {
  const session = seat.session !== `${team}/${seat.handle}`;
  return `${safe(seat.handle).padEnd(pad)}  ${safe(seat.harness).padEnd(session ? harnessPad : 0)}${session ? `  ${safe(seat.session)}` : ""}${seat.crew ? " (crew)" : ""}`;
}

export function renderPicker(p: Picker, rows = 24, observable = true): string {
  const list = p.layer === 1 ? p.teamView() : p.seatView();
  const height = Math.max(3, rows - 8), start = Math.max(0, Math.min(p.cursor - Math.floor(height / 2), list.length - height));
  const visible = list.slice(start, start + height);
  const heading = p.layer === 1 ? "pick a team" : safe(p.team.name);
  const out = [`\x1b[H\x1b[2Jtap attach -- ${heading}    [i up | j down | arrows | Enter select | f filter | Esc back | q quit]`,
    `${p.filtering ? "Filter (Esc finishes)" : "Filter"}: ${safe(p.query)}`, ""];
  if (start) out.push(`    ... ${start} more above`);
  if (!list.length) out.push("    (no matching teams or live seats)");
  const pad = p.layer === 2 ? Math.max(0, ...visible.map(s => (s as PickerSeat).handle.length)) : 28;
  visible.forEach((row, i) => {
    let body: string;
    if (p.layer === 1) {
      const t = row as PickerTeam;
      body = `${safe(t.name).padEnd(pad)} ${t.state === "ok" ? `${t.seats.length} live seat${t.seats.length === 1 ? "" : "s"}` : `-- ${t.state} (${safe(t.detail)})`}`;
    } else body = seatRow(row as PickerSeat, p.team.name, pad);
    out.push(`${start + i === p.cursor ? "  > " : "    "}${body}`);
  });
  if (start + visible.length < list.length) out.push(`    ... ${list.length - start - visible.length} more below`);
  if (p.layer === 1) {
    const hidden = p.teams.filter(t => t.state !== "ok" || !t.seats.length).length;
    if (hidden) out.push(`\n  ${p.showAll ? "showing all teams -- a to hide" : `${hidden} idle or unavailable teams hidden -- a to show`}`);
  }
  if (!observable) out.push("  tmux reports no live sessions -- nothing is attachable right now");
  if (p.status) out.push(`  ${safe(p.status)}`);
  return out.join("\n") + "\n";
}

export function decodeKeys(input: string, flush = false): { keys: string[]; rest: string } {
  const keys: string[] = []; let pos = 0;
  while (pos < input.length) {
    const char = String.fromCodePoint(input.codePointAt(pos)!);
    if (char === "\x1b") {
      const remaining = input.slice(pos);
      if (remaining === "\x1b" || remaining === "\x1b[" || remaining === "\x1bO") {
        if (!flush) break;
        if (remaining === "\x1b") keys.push("esc");
        pos = input.length; break;
      }
      const arrow = /^\x1b(?:\[|O)([ABCD])/.exec(remaining);
      if (arrow) { keys.push(({ A: "up", B: "down", C: "right", D: "left" } as Record<string,string>)[arrow[1]!]!); pos += arrow[0].length; continue; }
      const sequence = /^\x1b\[[0-?]*[ -/]*[@-~]/.exec(remaining);
      if (sequence) { pos += sequence[0].length; continue; }
      keys.push("esc"); pos++; continue;
    }
    keys.push(char === "\r" || char === "\n" ? "enter" : char === "\x7f" || char === "\b" ? "backspace" : char === "\x15" ? "clear" : char === "\x03" ? "interrupt" : char === "\x04" ? "eof" : char);
    pos += char.length;
  }
  return { keys, rest: input.slice(pos) };
}

export async function runPicker(argv: string[], scriptsDir = join(import.meta.dir, "../../../skills/tap/scripts")): Promise<number> {
  let keys: string | undefined;
  if (argv[0] === "--keys" && argv.length === 2) keys = argv[1];
  else if (argv.length) throw new TapError(1, "usage_error", "tap attach --interactive", "interactive picker takes no target or competing selector");
  if (keys === undefined && (!process.stdin.isTTY || !process.stdout.isTTY)) throw new TapError(1, "no_terminal", "tap attach <team/handle>", "interactive picker needs a terminal on stdin and stdout");
  const model = pickerModel(), picker = new Picker(model.teams);
  const render = () => process.stdout.write(renderPicker(picker, process.stdout.rows || 24, model.observable));
  if (keys !== undefined) { for (const key of keys.split(/\s+/)) { picker.step(key); if (picker.action) break; } render(); }
  else {
    const wasRaw = process.stdin.isRaw; const decoder = new StringDecoder("utf8"); let pending = "";
    let timer: ReturnType<typeof setTimeout> | undefined;
    let interrupted = false;
    const restore = () => { if (timer) clearTimeout(timer); process.stdin.setRawMode(wasRaw); process.stdin.pause(); process.stdout.write("\x1b[?25h\x1b[?1049l"); };
    const signals = { SIGINT: 130, SIGTERM: 143, SIGHUP: 129 } as const;
    const handlers = Object.entries(signals).map(([signal, code]) => { const fn = () => { restore(); process.exit(code); }; process.on(signal, fn); return [signal, fn] as const; });
    process.stdin.setRawMode(true); process.stdin.resume(); process.stdout.write("\x1b[?1049h\x1b[?25l"); render();
    try {
      await new Promise<void>(done => {
        const apply = (flush = false) => {
          const decoded = decodeKeys(pending, flush); pending = decoded.rest;
          for (const key of decoded.keys) { if (key === "interrupt") interrupted = true; picker.step(key); if (picker.action) { finish(); return; } }
          render();
          if (pending) timer = setTimeout(() => apply(true), 100);
        };
        const data = (chunk: Buffer) => { if (timer) clearTimeout(timer); pending += decoder.write(chunk); apply(); };
        const end = () => { picker.step("eof"); finish(); };
        const resize = () => render();
        const finish = () => { process.stdin.off("data", data); process.stdin.off("end", end); process.stdout.off("resize", resize); done(); };
        process.stdin.on("data", data); process.stdin.on("end", end); process.stdout.on("resize", resize);
      });
    } finally { restore(); for (const [signal, handler] of handlers) process.off(signal, handler); }
    if (interrupted) return 130;
  }
  if (picker.action === "attach") return spawnSync("bash", [join(scriptsDir, "tap.sh"), "attach", "--no-resume", picker.target], { stdio: "inherit" }).status ?? 1;
  console.log("tap attach: picker closed without selecting a seat"); return 0;
}

if (import.meta.main) {
  try { process.exitCode = await runPicker(process.argv.slice(2)); }
  catch (error) {
    if (error instanceof TapError && process.env.TAP_JSON === "1") console.log(JSON.stringify({ ok: false, error_class: error.errorClass, action: error.action, detail: error.detail }));
    else console.error(`tap attach: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  }
}
