// Native `tap nudge` (tap-voys3): re-submit a STUCK sentinel in a peer's pane — NOT a wake; waking comes from DELIVERY (`tap send --wake`).

import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";

import { resolveSelf, TapError } from "../context";
import { classifyHarness, harnessFamily, observeProcessHarness, readProcessTable } from "../observe";
import { captureInputFrame, pendingInputText, realPaneIo } from "../pane/reader";
import { envelopeField } from "../envelope";
import { harnessQueueMessage, recordHarnessQueued } from "../harness-queue";
import { validId } from "../ids";
import { isRegularFile, resolveEnrolledTeamRoot } from "../index-home";
import { recoveryPolicy } from "../recovery-policy";
import { recordedCopyCancel } from "../recovery/copy-mode";
import { recoveryCli } from "../recovery/cli";
import { loadRegistry, seatMap } from "../registry";
import { parseTarget, selectTarget, SelectorError, type TargetSelection } from "../selector";
import { sentinelInputTail, visibleSentinel } from "../submit-frame";
import { stuckSentinelFieldsFromRegion } from "../stuck-sentinel";
import { paneCurrentCommand, tmuxReadOnly } from "../tmux";
import { resolveSelection } from "../team-selection";
import { TOKEN_RE } from "../remote-target";

const USAGE = "tap help nudge";
const USAGE_LINE = "usage: tap nudge <peer|team/peer> [--pane tmux-target]";

interface Binding { status: string; pane: string; paneId: string; delivery: string; }

// A present legacy row defaults status/delivery like `tap_registry_pane_binding`; a missing row stays all-empty.
function binding(registryLocation: string, handle: string): Binding {
  const row = seatMap(loadRegistry(registryLocation))[handle] as { status?: unknown; pane?: unknown; pane_id?: unknown; delivery?: unknown } | undefined;
  if (!row) return { status: "", pane: "", paneId: "", delivery: "" };
  const text = (value: unknown): string => (typeof value === "string" ? value : "");
  return { status: text(row.status) || "active", pane: text(row.pane), paneId: text(row.pane_id), delivery: text(row.delivery) || "pane" };
}

// Port of the deleted lib.sh `tap_refuse_if_terminal`/`tap_refuse_if_cancelled` gates: residency is not
// liveness, absence is its own class (never identity_mismatch), and receipt paths use the regular-file
// predicate so a directory/FIFO is not a receipt and a FIFO is never opened (which would hang).
function terminalityRefusal(bus: string, id: string): TapError | null {
  if (isRegularFile(`${bus}/receipts/${id}.done`)) {
    return new TapError(1, "already_settled", `tap show ${id}`, `'${id}' is already settled (.done exists on ${bus}); it must not be re-submitted`);
  }
  const cancelPath = `${bus}/receipts/${id}.cancelled`;
  if (!isRegularFile(cancelPath)) return null;
  let doc: Record<string, unknown> = {}; try { doc = JSON.parse(readFileSync(cancelPath, "utf8")) as Record<string, unknown>; } catch {}
  const via = typeof doc.via === "string" && doc.via !== "" ? doc.via : "cancelled";
  if (via !== "withdrawn") {
    return new TapError(1, "already_settled", `tap show ${id}`, `'${id}' is already terminal (via: ${via}); it cannot be answered or settled again`);
  }
  const reason = typeof doc.reason === "string" ? doc.reason : ""; const successor = typeof doc.superseded_by === "string" ? doc.superseded_by : "";
  return new TapError(1, "withdrawn", successor ? `tap read ${successor}` : `tap show ${id}`,
    `'${id}' was withdrawn by its sender — superseded: ${reason || "no reason given"}` +
    (successor ? `; answer '${successor}' instead` : "; the sender named no successor") + `. Nothing is owed on '${id}'.`);
}

// The recorded submit boundary: re-declare the tmux wrapper so send-keys — an effect, never an observation — records through the recovery engine.
const VERIFY_SCRIPT = [
  "set -euo pipefail",
  '. "$1/lib.sh"',
  'NUDGE_CLI="$9"',
  'eval "$(declare -f tmux | sed \'1s/^tmux /_nudge_original_tmux /\')"',
  `tmux() { case "\${1:-}" in send-keys) recovery_rc=0; command bun "$NUDGE_CLI" tmux "$@" || recovery_rc=$?;`,
  `  [ "$recovery_rc" != 125 ] || TAP_RECOVERY_EFFECT_NONE=1; return "$recovery_rc" ;; *) _nudge_original_tmux "$@" ;; esac; }`,
  '_TAP_TMUX_BODY="$(declare -f tmux)"',
  'tap_submit_existing_verify "$2" "$3" "$4" 1 id "$5" "$6" "$7" 6 "" "" "$8" || exit $?',
].join("\n");

// lib.sh `tap_bound_pane_identity_state`: `match` means registry row and live pane agree. The distinct
// "nudge-identity-state" marker keeps a probe interception keyed "recovery-identity" from catching this in-process preflight.
function boundPaneIdentityState(scriptsDir: string, registryLocation: string, handle: string, pane: string, paneId: string): string {
  const probe = spawnSync("bash", ["-c", '. "$1/lib.sh"; shift; tap_bound_pane_identity_state "$@"', "nudge-identity-state", scriptsDir, registryLocation, handle, pane, paneId], { encoding: "utf8", timeout: 10000, maxBuffer: 16384 });
  return probe.stdout.trim();
}

export function cmdNudge(argv: string[], scriptsDir: string, families: ReadonlySet<string>): number {
  try {
    return nudge(argv, scriptsDir, families);
  } catch (error) {
    if (error instanceof TapError) throw error;
    if (error instanceof SelectorError) throw new TapError(error.code, error.errorClass, error.action, error.detail);
    throw new TapError(1, "recovery_failed", "tap debug recovery", String(error));
  }
}

// Nudge-local translation of the shared selector's ARGV-TARGET verdicts into the incumbent's public
// classes/actions/details; sentinel re-resolution keeps its own mapping, and shared selector policy is untouched.
function argvTargetRefusal(parsed: { team: string }, error: SelectorError): TapError {
  const team = parsed.team;
  const incumbent: Record<string, [string, string, string?]> = {
    historical_team: ["tap doctor", `team '${team}' is historical — not delivery-addressable (${error.detail})`],
    live_unreachable: ["tap doctor", `team '${team}' registry_location is unreachable (${error.detail})`, "unreachable_team"],
    invalid_flip: ["tap doctor", `registry flip marker is present but invalid — refusing legacy delivery (${error.detail})`],
    ambiguous_team: ["enroll the intended '" + team + "' worktree in the machine index", `team '${team}' matches multiple worktree roots: ${error.detail}`],
    unknown_team: ["enroll team '" + team + "' by registering a seat from that worktree", `unknown team '${team}' (not in the machine index)`],
  };
  const hit = incumbent[error.errorClass];
  return new TapError(error.code, hit?.[2] ?? error.errorClass, hit?.[0] ?? error.action, hit?.[1] ?? error.detail);
}

function nudge(argv: string[], scriptsDir: string, families: ReadonlySet<string>): number {
  let to = "";
  let pane = "";
  let override: string | undefined;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!;
    if (arg === "--aggressiveness") {
      if (i + 1 >= argv.length) throw new TapError(1, "usage_error", USAGE, "--aggressiveness needs a value");
      override = argv[++i];
    } else if (arg === "--pane") {
      if (i + 1 >= argv.length || argv[i + 1] === "") throw new TapError(1, "usage_error", USAGE, "--pane needs a value");
      pane = argv[++i]!;
    } else if (arg.startsWith("--")) { throw new TapError(1, "unknown_option", USAGE, `unknown option '${arg}'`); }
    else if (to === "") { to = arg; } else { throw new TapError(1, "usage_error", USAGE, `unexpected arg '${arg}'`); }
  }
  if (to === "" && pane === "") throw new TapError(1, "usage_error", USAGE, USAGE_LINE);
  const policy = recoveryPolicy("aggressive", override);
  process.stderr.write(`tap nudge: aggressiveness=${policy.mode} source=${policy.source}\n`);
  // Caller-pin precedence: an explicit TAP_HOME outranks the cwd walk, so a foreign enrolled cwd cannot steal the inspected team from a pinned bus.
  const ctx = resolveSelection(process.env.TAP_HOME ?? "", "");
  const toLabel = to;
  let argvTeam = "";
  let argvHandle = "";
  let argvSel: TargetSelection | undefined;
  let registry = ctx.registryPath;
  let argvBinding: Binding = { status: "", pane: "", paneId: "", delivery: "" };
  if (to !== "") {
    const parsed = parseTarget(to);
    try {
      argvSel = selectTarget(ctx.selection!, parsed);
    } catch (error) {
      if (!(error instanceof SelectorError)) throw error;
      throw argvTargetRefusal(parsed, error);
    }
    registry = argvSel.registryLocation;
    argvTeam = argvSel.team;
    argvHandle = argvSel.handle;
    to = argvSel.handle;
    argvBinding = binding(registry, to);
    if (argvSel.scope === "remote" && argvBinding.status === "suspended") {
      throw new TapError(1, "suspended", `run 'tap register ${to} --pane <tmux-target>' from team '${argvTeam}'`, `handle '${toLabel}' is suspended — re-register it (a suspended seat is not a delivery target)`);
    }
    if (argvBinding.delivery === "poll") {
      throw new TapError(1, "poll_mode_member", `tap send ${toLabel} -m "..." (poll members discover work via tap poll, never injection)`, `'${toLabel}' is a registered poll-mode member — nudge (bare Enter into a pane) does not apply`);
    }
  }
  if (pane === "") pane = argvBinding.pane;
  if (pane === "") throw new TapError(1, "not_found", `register '${toLabel}' with its current pane, then retry`, `no registered pane for '${toLabel}'`);
  // Bash tap_pane_alive semantics: one successful pane_id display means alive.
  const alive = tmuxReadOnly(["display-message", "-p", "-t", pane, "#{pane_id}"]);
  if (alive.code !== 0 || alive.stdout.trim() === "") {
    process.stderr.write(`tap nudge: pane '${pane}' gone\n`);
    return 3;
  }
  if (policy.mode === "report-only") return recoveryCli(["report", registry, to, pane, toLabel]);

  // Shallow fast path for a known family; an unsupported shallow value such as `node` defers to the observed process table.
  const shallow = harnessFamily(paneCurrentCommand(pane), [...families]);
  let paneCmd = shallow;
  let klass = classifyHarness(shallow, [...families]);
  if (klass === "unsupported") {
    const panePid = tmuxReadOnly(["display-message", "-p", "-t", pane, "#{pane_pid}"]).stdout.trim();
    const { table, ok } = readProcessTable();
    const deep = observeProcessHarness(panePid, table, ok, [...families]);
    if (deep.state === "observed" && deep.family) paneCmd = deep.family;
    klass = classifyHarness(paneCmd, [...families]);
  }
  if (klass !== "agent") {
    const detail = klass === "denylist"
      ? `pane '${pane}' runs '${paneCmd}' (not an agent REPL) — refusing bare Enter`
      : `pane '${pane}' runs unsupported harness '${paneCmd}' — refusing bare Enter`;
    throw new TapError(1, "unsupported_harness", `tap send ${toLabel} -m "..."`, detail);
  }
  const captured = captureInputFrame(realPaneIo, pane, paneCmd, true);
  if (!captured.ok) return 1;
  let frame = captured.frame;
  if (paneCmd === "opencode" && pendingInputText(realPaneIo, pane, paneCmd, frame).status === "overprint") {
    let repaintHandle = to, repaintPaneId = argvBinding.paneId, repaintRegistry = registry;
    if (repaintHandle !== "") {
      if (argvBinding.status !== "active" || argvBinding.pane !== pane || repaintPaneId === "") {
        throw new TapError(1, "identity_mismatch", "tap nudge <registered-opencode-seat>", "OpenCode overprint recovery requires the target's active registered pane binding");
      }
    } else {
      try {
        const self = resolveSelf(ctx, pane, 1); repaintHandle = self.handle; repaintPaneId = self.paneId;
      } catch {
        throw new TapError(1, "identity_mismatch", "tap nudge <registered-opencode-seat>", `OpenCode overprint recovery requires exactly one active binding for pane '${pane}'`);
      }
      repaintRegistry = ctx.registryPath;
    }
    const probe = spawnSync(process.execPath, [resolve(import.meta.dir, "../recovery/cli.ts"), "repaint-probe", repaintRegistry, repaintHandle, pane, repaintPaneId], { encoding: "utf8" });
    if (probe.status !== 0) {
      throw new TapError(1, "resolution_error", `tap detective ${toLabel} --aggressiveness aggressive`, "OpenCode terminal overprint repaint could not be verified; nothing submitted");
    }
    frame = probe.stdout;
    process.stderr.write("tap nudge: repainted OpenCode terminal overprint before composer classification\n");
  }
  const region = sentinelInputTail(frame, paneCmd);
  if (region === null || region === "") {
    throw new TapError(1, "usage_error", "inspect the active composer before retrying", "Input region is unavailable; nothing submitted");
  }
  if (!region.includes("[[TAP")) {
    process.stdout.write(`tap nudge: no stuck sentinel in ${toLabel}'s input — no-op (send them anything to wake a stopped peer; a plain send is a note settled by their tap read, --ask requests a reply)\n`);
    return 0;
  }
  const expected = visibleSentinel(frame, paneCmd);
  if (expected === null) {
    throw new TapError(1, "usage_error", "inspect the composer; preserve incomplete or ambiguous text and use tap read for the canonical message", "no single complete TAP sentinel is visible in the active input; nothing submitted");
  }
  const stored = stuckSentinelFieldsFromRegion(expected, paneCmd);
  if (!stored.ok) {
    throw new TapError(1, "usage_error", "inspect the complete sentinel and use tap read for the canonical message", "the visible TAP sentinel is malformed; nothing submitted");
  }
  let id = stored.fields.id;
  let sentinelTo = stored.fields.to;
  const wire = stored.fields.wire;
  let sentinelIdTeam = "";
  if (id.includes("/")) { sentinelIdTeam = id.slice(0, id.indexOf("/")); id = id.slice(id.indexOf("/") + 1); }
  if (id === "") throw new TapError(1, "usage_error", USAGE, "stuck sentinel is missing id");
  if (!validId(id)) throw new TapError(1, "usage_error", USAGE, `stuck sentinel id '${id}' fails charset ${TOKEN_RE}`);
  let bus = "";
  if (wire === "pre023") {
    if (sentinelTo === "") throw new TapError(1, "identity_mismatch", `tap send ${toLabel} -m "..."`, "stuck sentinel is missing its bound to= identity");
    bus = ctx.bus.home;
  } else {
    // v0.23 re-keys on the payload the id names; argv only chooses the BUS, and a wrong bus yields ABSENCE (not_found).
    if (sentinelIdTeam !== "") {
      const enrolled = resolveEnrolledTeamRoot(sentinelIdTeam, process.env.TAP_INDEX_HOME);
      if (enrolled.kind !== "ok") {
        throw new TapError(1, "unknown_team", `enroll team '${sentinelIdTeam}' in the machine index`, `stuck sentinel id names team '${sentinelIdTeam}', which the machine index cannot resolve`);
      }
      bus = `${enrolled.root}/.tap/bus`;
    } else if (argvSel?.scope === "remote" && argvSel.rootReal !== "") {
      bus = `${argvSel.rootReal}/.tap/bus`;
    }
    const payloadPath = bus !== "" ? `${bus}/payloads/${id}.md` : ctx.bus.payloadPath(id);
    if (bus === "") bus = dirname(dirname(payloadPath));
    if (!isRegularFile(payloadPath)) {
      throw new TapError(1, "not_found", `tap show ${id}`, `stuck sentinel id '${id}' has no payload on ${bus} — it may already be settled or reaped; nothing was submitted`);
    }
    const refusal = terminalityRefusal(bus, id); if (refusal) throw refusal;
    const payload = readFileSync(payloadPath, "utf8");
    sentinelTo = envelopeField(payload, "to") ?? "";
    const toTeam = envelopeField(payload, "to_team") ?? "";
    if (sentinelTo === "") throw new TapError(1, "identity_mismatch", `tap show ${id}`, `payload '${payloadPath}' carries no to: — it cannot corroborate the argv target`);
    if (toTeam !== "") sentinelTo = `${toTeam}/${sentinelTo}`;
  }
  let sentinelTarget = sentinelTo; if (!sentinelTarget.includes("/") && !sentinelTarget.includes(":") && argvTeam !== "") sentinelTarget = `${argvTeam}/${sentinelTo}`;
  const parsedSentinel = parseTarget(sentinelTarget);
  let sel2: TargetSelection;
  try {
    sel2 = selectTarget(ctx.selection!, parsedSentinel);
  } catch (error) {
    if (!(error instanceof SelectorError)) throw error;
    if (error.errorClass === "unknown_team") {
      throw new TapError(1, "unknown_team", `tap send ${toLabel} -m "..."`, `stuck sentinel names unknown team '${parsedSentinel.team}'`);
    }
    if (error.errorClass === "ambiguous_team") {
      throw new TapError(1, "ambiguous_team", `enroll team '${parsedSentinel.team}' in the machine index`, `stuck sentinel team '${parsedSentinel.team}' matches multiple worktree roots: ${error.detail}`);
    }
    throw new TapError(1, "resolution_error", `tap send ${toLabel} -m "..."`, `could not resolve stuck sentinel identity '${sentinelTo}' (${error.detail})`);
  }
  const sentinelTeam = sel2.team; const sentinelHandle = sel2.handle;
  const drift = (when: string): TapError => new TapError(1, "identity_mismatch", `run 'tap register ${sentinelHandle} --pane <tmux-target>' from team '${sentinelTeam}'`, `stuck sentinel recipient identity drifted ${when}`);
  if (argvHandle !== "" && (argvTeam !== sentinelTeam || argvHandle !== sentinelHandle)) {
    throw new TapError(1, "identity_mismatch", `tap nudge ${sentinelTeam}/${sentinelHandle}`, `argv target '${argvTeam}/${argvHandle}' disagrees with stuck sentinel to='${sentinelTeam}/${sentinelHandle}'`);
  }
  const sentinelBinding = binding(sel2.registryLocation, sentinelHandle);
  if (sentinelBinding.status !== "active" || sentinelBinding.delivery === "poll") {
    throw new TapError(1, "identity_mismatch", `tap send ${sentinelTeam}/${sentinelHandle} -m "..."`, "stuck sentinel recipient is missing, inactive, or not pane-backed");
  }
  if (pane !== sentinelBinding.pane) {
    throw new TapError(1, "identity_mismatch", `tap nudge ${sentinelTeam}/${sentinelHandle}`, `candidate pane '${pane}' is not the sentinel recipient's bound pane '${sentinelBinding.pane}'`);
  }
  const identity = boundPaneIdentityState(scriptsDir, sel2.registryLocation, sentinelHandle, sentinelBinding.pane, sentinelBinding.paneId);
  if (identity !== "match") throw drift(`(${identity})`);
  const effectBus = bus || ctx.bus.home; const lateRefusal = terminalityRefusal(effectBus, id); if (lateRefusal) throw lateRefusal;
  const cliPath = resolve(import.meta.dir, "../recovery/cli.ts");
  const started = spawnSync(process.execPath, [cliPath, "nudge-start", policy.mode, sel2.registryLocation, sentinelHandle, pane, sentinelBinding.paneId, id, effectBus, String(process.pid), expected], { encoding: "utf8" });
  if (started.status !== 0) {
    // Relay the child's own diagnostics: a start failure must name its reason, not exit silently.
    if (started.stdout) process.stdout.write(started.stdout);
    if (started.stderr) process.stderr.write(started.stderr);
    return 1;
  }
  const runId = started.stdout.trim(); process.stderr.write(`tap nudge: recovery=${runId} (tap debug recovery ${runId})\n`);
  let exitCode = 0;
  try {
    const copyRc = recordedCopyCancel(runId);
    if (copyRc === 6) throw drift("before copy-mode cancel");
    if (copyRc !== 0) { exitCode = copyRc; return copyRc; }
    const verifyEnv: NodeJS.ProcessEnv = { ...process.env, TAP_RECOVERY_RUN: runId, TAP_NUDGE_SINGLE_ENTER: "1", TAP_VERB: "tap nudge", TAP_HOME: effectBus };
    if (frame !== captured.frame && paneCmd === "opencode") verifyEnv.TAP_NUDGE_REPAINTED = "1"; else delete verifyEnv.TAP_NUDGE_REPAINTED;
    const verify = spawnSync("bash", ["-c", VERIFY_SCRIPT, "nudge-verify", scriptsDir, pane, paneCmd, id, sel2.registryLocation, sentinelHandle, sentinelBinding.paneId, expected, cliPath], { encoding: "utf8", env: verifyEnv });
    // Incumbent's child inherited stdio; guard evidence (status=7, ETIMEDOUT) is the refusal's stderr record.
    if (verify.stdout) process.stdout.write(verify.stdout);
    if (verify.stderr) process.stderr.write(verify.stderr);
    const submitRc = verify.status ?? 1;
    if (submitRc === 6) throw drift("before submit");
    if (submitRc === 7) {
      recordHarnessQueued(effectBus, id);
      process.stdout.write(harnessQueueMessage(effectBus, id, process.env.TAP_JSON === "1", "tap nudge"));
      return 0;
    }
    if (submitRc !== 0) { exitCode = submitRc; return submitRc; }
    process.stdout.write(`tap nudge: re-submitted a stuck sentinel for ${toLabel} (${pane})\n`);
    return 0;
  } catch (error) {
    exitCode = error instanceof TapError ? error.code : 1;
    throw error;
  } finally {
    try { recoveryCli(["nudge-finish", runId, String(exitCode)]); } catch {}
  }
}
