#!/usr/bin/env bun
// Scheduled proof of a completed goalie tick: no model or TAP machinery.
// Bun is required; this leaf cannot diagnose its own missing interpreter.
// Installation belongs to the operator. Only the notifier is a child process.
import { readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { pythonInt } from "../pyint";

function isFile(path: string): boolean {
  try { return statSync(path).isFile(); } catch { return false; }
}

function seconds(text: string, signed = false): number | null {
  if (!(signed ? /^[+-]?[0-9]+$/ : /^[0-9]+$/).test(text) || text.includes("\n")) return null;
  const value = Number(text);
  return Number.isSafeInteger(value) ? value : null;
}

function intervalSeconds(value: unknown): number {
  let interval = 60;
  if (typeof value === "number" && value) interval = Math.trunc(value);
  else if (typeof value === "string" && value) interval = Number(pythonInt(value, true) ?? NaN);
  else if (value === true) interval = 1;
  return Number.isSafeInteger(interval) && Number.isSafeInteger(interval * 3) ? interval : 60;
}

function main(argv: string[]): number {
  let home = process.env.TAP_HOME || "", maxAgeText = "", quiet = false;
  const usageError = (message: string, status = 64) => {
    process.stderr.write(`tap-goalie-heartbeat: ${message}\n`);
    return status;
  };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!;
    switch (arg) {
      case "--home":
      case "--max-age": {
        const value = argv[++i];
        if (!value) return usageError(`${arg} needs ${arg === "--home" ? "a path" : "seconds"}`, 1);
        if (arg === "--home") home = value;
        else maxAgeText = value;
        break;
      }
      case "--quiet": quiet = true; break;
      case "-h":
      case "--help":
        console.log("usage: goalie-heartbeat.ts [--home <TAP_HOME>] [--max-age <seconds>] [--quiet]");
        console.log("  Ages the goalie tick stamp and wakes the human when it stops. No LLM, no bus.");
        return 0;
      default: return usageError(`unexpected arg '${arg}'`);
    }
  }
  if (!home) return usageError("set TAP_HOME or pass --home");
  const say = (message: string) => { if (!quiet) console.log(`tap-goalie-heartbeat: ${message}`); };
  const armPath = join(home, "goalie/arm.json"), stampPath = join(home, "goalie/heartbeat");
  // Disarmed takes precedence over clock/limit validation and notifier discovery.
  if (!isFile(armPath)) { say("goalie is disarmed; nothing to watch"); return 0; }

  const now = seconds(process.env.TAP_GOALIE_NOW || String(Math.floor(Date.now() / 1000)), true);
  if (now === null) return usageError("TAP_GOALIE_NOW must be safe integer decimal seconds");
  const override = maxAgeText ? seconds(maxAgeText, true) : undefined;
  if (override === null) return usageError("--max-age must be safe integer decimal seconds");
  let arm: Record<string, unknown> = {};
  try {
    // Keep BOM visible to JSON.parse and reject invalid UTF-8, as Python did.
    const value = JSON.parse(new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(readFileSync(armPath)));
    if (value && typeof value === "object" && !Array.isArray(value)) arm = value;
  } catch { /* An unreadable interval uses the incumbent's 60-second fallback. */ }
  const interval = intervalSeconds(arm.tick_interval_seconds);
  const maxAge = override ?? Math.max(300, interval * 3);
  const alarm = (detail: string): number => {
    detail = detail.replaceAll("\0", "\\0"); // NUL cannot be passed in a notifier argument.
    say(`STALE — ${detail}`);
    const requested = process.env.TAP_NOTIFY_USER_BIN || "notify-user";
    const notify = Bun.which(requested);
    if (!notify) { say(`notifier '${requested}' not found; the human was NOT reached`); return 2; }
    // SIGTERM can be ignored; pipes can outlive the notifier. Kill at the bound
    // and discard child output so neither can prevent the next scheduled check.
    const result = spawnSync(notify, ["--template", "question", "--",
      `TAP goalie tick is not running: ${detail} — the board has no deadlock detector right now`],
    { stdio: "ignore", timeout: 20_000, killSignal: "SIGKILL" });
    if (result.error || result.status !== 0) {
      say((result.error as NodeJS.ErrnoException | undefined)?.code === "ETIMEDOUT"
        ? "notifier timed out after 20s; notification is unconfirmed"
        : "notifier failed; the human was NOT reached");
      return 2;
    }
    return 1;
  };
  if (!isFile(stampPath)) {
    const armedAt = arm.armed_at === null ? "None" : arm.armed_at === true ? "True" : arm.armed_at === false ? "False" : String(arm.armed_at ?? "");
    return alarm(`armed since ${armedAt.replace(/\n+$/, "")} but has never completed a fire`);
  }
  let text = "";
  try { text = readFileSync(stampPath, "utf8").split("\n", 1)[0] ?? ""; } catch { /* Alarm below. */ }
  const stamp = seconds(text);
  if (stamp === null) return alarm(`stamp file is unreadable ('${text}')`);
  const age = now - stamp;
  if (!Number.isSafeInteger(age)) return alarm("stamp age is outside the safe integer range");
  if (age < 0) return alarm(`stamp is in the future (clock skew: ${age}s)`);
  if (age > maxAge) return alarm(`last fire was ${age}s ago (limit ${maxAge}s, tick interval ${interval}s)`);
  say(`ok — last fire ${age}s ago (limit ${maxAge}s)`);
  return 0;
}

if (import.meta.main) process.exit(main(process.argv.slice(2)));
