// Validate the current guide tree; historical page reconstruction was retired
// by tap-fjlcy. Protocol pages remain editable within these structural bounds.
import { existsSync, readFileSync, readdirSync, realpathSync, statSync } from "node:fs";
import { basename, dirname, extname, isAbsolute, join, relative, resolve } from "node:path";
import { physicalPath } from "./clear-fence";

const ROOT = physicalPath(process.argv[2] ?? resolve(dirname(realpathSync(import.meta.path)), "../../.."));
const PROTOCOL = join(ROOT, "skills/tap/protocol");
const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
// Python whitespace includes 1C–1F and excludes BOM; JS \s does the opposite.
const SPACE = "[\\t-\\r \\x1c-\\x1f\\x85\\xa0\\u1680\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000]";
const LEADING_SPACE = new RegExp(`^${SPACE}+`);
const HEADING = new RegExp(`^#{1,6}${SPACE}+(.+?)${SPACE}*#*${SPACE}*$`);
const WORD = new RegExp(`[^${SPACE.slice(1, -1)}]+`, "g");

function fail(message: string): never { throw new Error(`FAIL: ${message}`); }
function text(path: string): string { return decoder.decode(readFileSync(path)).replace(/\r\n?/g, "\n"); }
function lines(raw: string): string[] {
  const result = raw.split(/\r\n|[\n\r\v\f\x1c-\x1e\x85\u2028\u2029]/);
  if (result.at(-1) === "") result.pop();
  return result;
}
function* walk(dir: string): Generator<string> {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    yield path;
    if (entry.isDirectory()) yield* walk(path);
  }
}
function pages(): string[] { return [...walk(PROTOCOL)].filter(path => extname(path) === ".md"); }

function localLinks(path: string): string[] {
  const found: string[] = [];
  for (const match of text(path).matchAll(/\[[^\]]+\]\(([^)]+)\)/g)) {
    const raw = match[1]!;
    const target = raw.split("#", 1)[0]!;
    if (!target || target.includes("://") || target.startsWith("mailto:") || target.startsWith("#")) continue;
    const dest = physicalPath(isAbsolute(target) ? target : `${dirname(path)}/${target}`);
    if (!existsSync(dest)) fail(`broken local link ${relative(ROOT, path)} -> ${raw}`);
    const physical = realpathSync(dest);
    if (statSync(physical).isFile() && extname(physical) === ".md") found.push(physical);
  }
  return found;
}

function markdownAnchors(path: string): Map<string, string> {
  const anchors = new Map<string, string>();
  const counts = new Map<string, number>();
  let fence = "";
  for (const line of lines(text(path))) {
    const stripped = line.replace(LEADING_SPACE, "");
    if (stripped.startsWith("```") || stripped.startsWith("~~~")) {
      const marker = stripped.slice(0, 3);
      fence = fence === marker ? "" : fence || marker;
      continue;
    }
    if (fence) continue;
    const heading = HEADING.exec(stripped)?.[1];
    if (heading === undefined) continue;
    const base = heading.toLowerCase().replace(/[^\p{L}\p{N}_ -]/gu, "").replaceAll(" ", "-");
    const count = counts.get(base) ?? 0;
    counts.set(base, count + 1);
    anchors.set(count === 0 ? base : `${base}-${count}`, heading);
  }
  return anchors;
}

function mapRows(): Record<string, string | null>[] {
  const records: string[][] = [];
  let row: string[] = [], field = "", quoted = false, start = true;
  // csv.DictReader consumes splitlines(), so quoted fields spanning input
  // lines concatenate without inserting a newline. Quotes double inside fields.
  for (const line of lines(text(join(ROOT, "docs/artifacts/agent-guide-migration-map.tsv")))) {
    if (line.startsWith("# ")) continue;
    if (!line && !quoted) continue;
    for (let i = 0; i < line.length; i++) {
      const char = line[i]!;
      if (quoted) {
        if (char !== '"') field += char;
        else if (line[i + 1] === '"') { field += '"'; i++; }
        else quoted = false;
      } else if (start && char === '"') { quoted = true; start = false; }
      else if (char === "\t") { row.push(field); field = ""; start = true; }
      else { field += char; start = false; }
    }
    if (!quoted) { records.push([...row, field]); row = []; field = ""; start = true; }
  }
  if (quoted) records.push([...row, field]); // csv's default non-strict EOF behavior
  const header = records.shift();
  if (!header || !records.length) fail("migration map has no rows");
  for (const key of ["record_type", "source_id", "new_path", "new_heading", "new_anchor"]) {
    if (!header.includes(key)) throw new Error(`missing migration map column: ${key}`);
  }
  return records.map(record => Object.fromEntries(header.map((key, i) => [key, record[i] ?? null])));
}

function validateAnchors(): void {
  const rows = mapRows();
  for (const row of rows) {
    if (row.record_type === "anchor" && !row.new_anchor) fail(`anchor destination empty: ${row.source_id}`);
  }
  for (const row of rows) {
    if (!row.new_anchor) continue;
    const page = isAbsolute(row.new_path!) ? row.new_path! : `${ROOT}/${row.new_path}`;
    if (markdownAnchors(page).get(row.new_anchor) !== (row.new_heading ?? undefined)) {
      fail(`anchor destination missing or fenced: ${row.source_id} -> ${row.new_path}#${row.new_anchor}`);
    }
  }
  const sentinel = markdownAnchors(join(PROTOCOL, "delivery/sentinel-the-wire-poke-zero-authority-part-01.md"));
  if (sentinel.get("sentinel-the-wire-poke--zero-authority") !== "Sentinel (the wire poke — zero authority)") {
    fail("GitHub per-space anchor semantics drifted");
  }
}

function validateBounds(): void {
  const contract = join(ROOT, "skills/tap/scripts/CONTRACT.md");
  const size = readFileSync(contract).length;
  if (size > 4096) fail(`CONTRACT exceeds 4096 bytes: ${size}`);
  const words = text(contract).match(WORD)?.length ?? 0;
  if (words > 600) fail(`CONTRACT exceeds 600 words: ${words}`);
  for (const [rel, limit] of Object.entries({
    "skills/tap/GUIDE.md": 6 * 1024,
    "skills/tap/protocol/README.md": 6 * 1024,
    "skills/tap/SKILL.md": 8 * 1024,
    "skills/tap/QUICK-REFERENCE.md": 8 * 1024,
    "skills/tap/USAGE.md": 4 * 1024,
  })) {
    const bytes = statSync(join(ROOT, rel)).size;
    if (bytes > limit) fail(`${rel} exceeds ${limit} bytes: ${bytes}`);
  }
  for (const page of pages()) {
    const limit = basename(page) === "README.md" ? 16 * 1024 : 12 * 1024;
    if (statSync(page).size > limit) fail(`${relative(ROOT, page)} exceeds ${limit} bytes`);
  }
}

function validateReachability(): void {
  const queue = [join(ROOT, "skills/tap/GUIDE.md"), join(PROTOCOL, "README.md")];
  const seen = new Set<string>();
  for (let i = 0; i < queue.length; i++) {
    const path = realpathSync(queue[i]!);
    if (seen.has(path)) continue;
    seen.add(path);
    queue.push(...localLinks(path));
  }
  const missing = pages().filter(page => !seen.has(realpathSync(page)));
  if (missing.length) fail(`unreachable protocol pages: ${missing.slice(0, 5).map(page => relative(ROOT, page)).join(", ")}`);
  for (const surface of [
    "skills/tap/scripts/CONTRACT.md", "skills/tap/SKILL.md", "skills/tap/USAGE.md",
    "skills/tap/QUICK-REFERENCE.md", "skills/tap/GUIDE.md", "skills/tap/guide/getting-started.md",
    ...pages().filter(page => basename(page) === "README.md"),
  ]) localLinks(resolve(ROOT, surface));
}

function validateNamedRoutes(): void {
  const quick = text(join(ROOT, "skills/tap/QUICK-REFERENCE.md"));
  for (const required of [
    "tap remind me --when-done '<cmd>'", "different from that notification target", "UNOBSERVABLE",
    "`cancel` stops notices but leaves the child running", "tap remind kill <id>", "There is no implicit timeout or cleanup",
  ]) if (!quick.includes(required)) fail(`quick reference lost reminder semantic: ${required}`);
  for (const verb of ["send", "reply", "escalate"]) {
    if (!quick.includes(`tap ${verb} `) || !quick.includes("-f - <<'EOF'")) fail(`quick reference lost literal ${verb} heredoc`);
  }
  for (const [rel, requiredValues] of Object.entries({
    "skills/tap/SKILL.md": ["tap teams [--all] [--details]", "TEAM | SEATS | STATUS"],
    "skills/tap/QUICK-REFERENCE.md": ["tap teams --details"],
    "skills/tap/GUIDE.md": ["teams summary", "--details", "tap help teams"],
  })) {
    const raw = text(join(ROOT, rel));
    for (const required of requiredValues) if (!raw.includes(required)) fail(`compact guide lost teams lede: ${rel}: ${required}`);
  }
  const advisory = text(join(ROOT, "skills/tap/templates/advisory.md"));
  for (const required of ["tap help skill tap", "GUIDE.md", "QUICK-REFERENCE.md", "not required detours"]) {
    if (!advisory.includes(required)) fail(`advisory lost direct guide route: ${required}`);
  }
  const receipt = text(join(ROOT, "docs/artifacts/agent-guide-findability.md"));
  if (receipt.split("| PASS |").length - 1 !== 10) fail("findability receipt does not contain ten passing task rows");
  for (const required of ["Fixed startup baseline", "Locator output", "14,105 bytes", "10/10 correct"]) {
    if (!receipt.includes(required)) fail(`findability receipt lost accounting evidence: ${required}`);
  }
}

function validateMarkdownSafety(): void {
  for (const page of pages()) {
    if (basename(page) === "README.md") continue;
    const fences = lines(text(page)).filter(line => /^(?:```|~~~)/.test(line.replace(LEADING_SPACE, ""))).length;
    if (fences % 2) fail(`unbalanced Markdown fence: ${relative(ROOT, page)}`);
  }
  const legacy = new RegExp(`CONTRACT(?:\\.md)?${SPACE}*§`);
  const liveGuidance = [...walk(join(ROOT, "skills")), ...[ROOT, join(ROOT, "docs")].flatMap(dir =>
    readdirSync(dir).filter(name => name.endsWith(".md")).map(name => join(dir, name)))];
  for (const page of liveGuidance) {
    if (![".md", ".toml"].includes(extname(page)) || page.startsWith(PROTOCOL + "/") || page === join(ROOT, "skills/tap/scripts/CONTRACT.md")) continue;
    if (legacy.test(text(page))) fail(`live guidance retains a removed CONTRACT section reference: ${relative(ROOT, page)}`);
  }
  for (const rel of [
    "skills/lead/references/choreography-best-practices.md", "skills/lead/references/strategies/conductor-collaboration.md",
    "skills/lead/references/routines/convergence-loop.md", "skills/tap/scripts/smoke/README.md", "CONCEPTS.md", "docs/ARCHITECTURE.md",
  ]) localLinks(join(ROOT, rel));
}

if (import.meta.main) {
  try {
    validateAnchors();
    validateBounds();
    validateReachability();
    validateNamedRoutes();
    validateMarkdownSafety();
    console.log("agent-guide: anchors, bounds, links, routes: ok");
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  }
}
