// Dark C9 shell-body lexer (tap-oymdg). Not a public TAP verb: the production
// PreToolUse hook and NATIVE_HANDLERS stay untouched. Later units layer
// segments, heredoc stripping, and the lint-body --json decision on this
// tokenizer. Tokenization matches hooks/tap-shell-body-guard.py, including
// Python str.isspace() — not Bash IFS and not ASCII-only whitespace. A
// narrower splitter merges `tap` and `send` across U+00A0 and command
// substitution in a later token never reaches tool-equality denial.

export type ShellToken = {
  value: string;
  unsafe: boolean;
  raw: string;
};

/** `$(` is command substitution; `$((` is arithmetic and must not trip unsafe. */
export function commandSubstitutionAt(text: string, index: number): boolean {
  return text.startsWith("$(", index) && !text.startsWith("$((", index);
}

/** Odd-length backslash run immediately before `index` escapes that character. */
export function shellEscaped(text: string, index: number): boolean {
  let backslashes = 0;
  let i = index - 1;
  while (i >= 0 && text[i] === "\\") {
    backslashes += 1;
    i -= 1;
  }
  return backslashes % 2 === 1;
}

/**
 * Python 3 `str.isspace()` as a closed code-point set (29 BMP scalars;
 * CPython 3.14 measured 2026-09-01). Not Bash IFS (space/tab/newline) and
 * not Unicode general-category Zs alone: U+001C..U+001F and U+0085 are Cc.
 */
export const PYTHON_ISSPACE: ReadonlySet<number> = new Set<number>([
  0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x85, 0xa0,
  0x1680, 0x2000, 0x2001, 0x2002, 0x2003, 0x2004, 0x2005, 0x2006, 0x2007,
  0x2008, 0x2009, 0x200a, 0x2028, 0x2029, 0x202f, 0x205f, 0x3000,
]);

export function isSpace(char: string): boolean {
  return char.length === 1 && PYTHON_ISSPACE.has(char.charCodeAt(0));
}

/**
 * One shell segment → tokens of (value, has_unsafe_expansion, raw).
 *
 * Quotes are stripped from `value` and kept in `raw`. A backslash outside
 * single quotes consumes the next character into `value` without the slash,
 * so `\$()` is not unsafe: the `$` never occupies a scan index. `#` ends
 * the segment only when it would start a new unquoted token.
 */
export function shellTokens(segment: string): ShellToken[] {
  const tokens: ShellToken[] = [];
  let value: string[] = [];
  let unsafe = false;
  let rawStart: number | null = null;
  let quote: "'" | '"' | null = null;
  let i = 0;

  const finish = (end: number): void => {
    if (rawStart === null) return;
    tokens.push({ value: value.join(""), unsafe, raw: segment.slice(rawStart, end) });
    value = [];
    unsafe = false;
    rawStart = null;
  };

  while (i < segment.length) {
    const char = segment[i]!;
    const next = segment[i + 1];
    if (char === "\\" && quote !== "'" && next !== undefined) {
      if (rawStart === null) rawStart = i;
      value.push(next);
      i += 2;
      continue;
    }
    if (char === "#" && quote === null && rawStart === null) break;
    if (char === "'" || char === '"') {
      if (rawStart === null) rawStart = i;
      if (quote === null) {
        quote = char;
        i += 1;
        continue;
      }
      if (quote === char) {
        quote = null;
        i += 1;
        continue;
      }
    }
    if (quote === null && isSpace(char)) {
      finish(i);
      i += 1;
      continue;
    }
    if (rawStart === null) rawStart = i;
    if (quote !== "'" && (char === "`" || commandSubstitutionAt(segment, i))) {
      unsafe = true;
    }
    value.push(char);
    i += 1;
  }
  finish(segment.length);
  return tokens;
}

/**
 * Split on top-level `;`, `|`, `&`, and newline. `2>&1`, `>|`, and `&>` stay
 * inside the segment: those ampersands and pipes are redirection, not
 * separators. Quote and backslash state match the Python guard, including
 * the empty middle segment `&&` produces.
 */
export function shellSegments(command: string): string[] {
  const segments: string[] = [];
  let start = 0;
  let quote: "'" | '"' | null = null;
  let escaped = false;
  for (let i = 0; i < command.length; i++) {
    const char = command[i]!;
    if (escaped) {
      escaped = false;
      continue;
    }
    if (char === "\\" && quote !== "'") {
      escaped = true;
      continue;
    }
    if (char === "'" || char === '"') {
      if (quote === null) quote = char;
      else if (quote === char) quote = null;
      continue;
    }
    const prev = i > 0 ? command[i - 1] : "";
    const next = command[i + 1];
    const redirectionPart =
      (char === "&" && (prev === "<" || prev === ">" || next === ">")) ||
      (char === "|" && prev === ">");
    if (quote === null && ";|&\n".includes(char) && !redirectionPart) {
      segments.push(command.slice(start, i));
      start = i + 1;
    }
  }
  segments.push(command.slice(start));
  return segments;
}

type HeredocOpener = { stripTabs: boolean; delimiter: string };

const HEREDOC_PREFIX = /^(?:(?:[0-9]+|\{[A-Za-z_][A-Za-z0-9_]*\})?)<<(-?)/;

function openerFromAttachedRaw(raw: string): HeredocOpener | null {
  const quoted = /^(?:(?:[0-9]+|\{[A-Za-z_][A-Za-z0-9_]*\})?)<<(-?)(['"])(.*?)\2$/.exec(raw);
  if (quoted && quoted[3] !== undefined && quoted[3].length > 0) {
    return { stripTabs: quoted[1] === "-", delimiter: quoted[3] };
  }
  const backslash = /^(?:(?:[0-9]+|\{[A-Za-z_][A-Za-z0-9_]*\})?)<<(-?)\\(\S+)$/.exec(raw);
  if (backslash && backslash[2] !== undefined && backslash[2].length > 0) {
    return { stripTabs: backslash[1] === "-", delimiter: backslash[2] };
  }
  return null;
}

function quotedDelimiterToken(raw: string): string | null {
  const quoted = /^(['"])(.*?)\1$/.exec(raw);
  if (quoted && quoted[2] !== undefined && quoted[2].length > 0) return quoted[2];
  const backslash = /^\\(\S+)$/.exec(raw);
  if (backslash && backslash[1] !== undefined && backslash[1].length > 0) return backslash[1];
  return null;
}

/**
 * First quoted or backslash-quoted `<<` / `<<-` opener that is a shell
 * redirection token, not a substring of a quoted mention.
 *
 * `re.search` on the raw line treats `echo "see <<'EOF' below"` as an opener
 * and swallows following executable lines (under-block). Token-shaped
 * detection: only a token whose raw IS the opener (or `<<` plus the next
 * quoted token) can open. Unquoted `<<EOF` is intentionally not an opener.
 */
function quotedHeredocOpener(line: string): HeredocOpener | null {
  const tokens = shellTokens(line);
  for (let i = 0; i < tokens.length; i++) {
    const raw = tokens[i]!.raw;
    const attached = openerFromAttachedRaw(raw);
    if (attached) return attached;
    const bare = HEREDOC_PREFIX.exec(raw);
    if (bare && bare[0] === raw) {
      const delim = tokens[i + 1] ? quotedDelimiterToken(tokens[i + 1]!.raw) : null;
      if (delim) return { stripTabs: bare[1] === "-", delimiter: delim };
    }
  }
  return null;
}

function splitCommandLines(command: string): string[] {
  if (command === "") return [];
  const lines = command.split("\n");
  if (lines.at(-1) === "") lines.pop();
  return lines;
}

function leadingTabsStripped(line: string): string {
  let i = 0;
  while (i < line.length && line[i] === "\t") i += 1;
  return line.slice(i);
}

/** Remove literal (quoted / backslash-quoted) heredoc data before scanning. */
export function withoutQuotedHeredocBodies(command: string): string {
  const kept: string[] = [];
  let delimiter: string | null = null;
  let stripTabs = false;
  for (const line of splitCommandLines(command)) {
    if (delimiter !== null) {
      const closing = stripTabs ? leadingTabsStripped(line) : line;
      if (closing === delimiter) delimiter = null;
      continue;
    }
    kept.push(line);
    const opener = quotedHeredocOpener(line);
    if (opener) {
      stripTabs = opener.stripTabs;
      delimiter = opener.delimiter;
    }
  }
  return kept.join("\n");
}

export const TAP_BODY_FLAGS: ReadonlySet<string> = new Set(["-m", "--message"]);
// --notes-contains filters existing prose and is not a body flag (tap-rij69).
export const BD_BODY_FLAGS: ReadonlySet<string> = new Set([
  "-d",
  "--description",
  "--notes",
  "--append-notes",
  "--design",
  "--acceptance",
  "--body",
]);

const ASSIGNMENT = /^[A-Za-z_][A-Za-z0-9_]*=.*$/;
const REDIRECTION =
  /^(?:(?:[0-9]+|\{[A-Za-z_][A-Za-z0-9_]*\})?(?:<<<|<<-|<<|<>|<&|>>|>\||>&|<|>)|&>>|&>)(.*)$/;

type WrapperGrammar = {
  shortOptions: string;
  longOptions: string[];
  optionalLong: ReadonlySet<string>;
  bareDashIsI: boolean;
};

const WRAPPERS: Record<string, WrapperGrammar> = {
  command: {
    shortOptions: "pVv",
    longOptions: [],
    optionalLong: new Set(),
    bareDashIsI: false,
  },
  env: {
    shortOptions: "0a:ivC:P:S:u:",
    longOptions: [
      "argv0=",
      "ignore-environment",
      "null",
      "unset=",
      "chdir=",
      "split-string=",
      "block-signal",
      "default-signal",
      "ignore-signal",
      "list-signal-handling",
      "debug",
      "help",
      "version",
    ],
    optionalLong: new Set(["block-signal", "default-signal", "ignore-signal"]),
    bareDashIsI: true,
  },
  bash: {
    shortOptions: "abefhkmnptuvxBCEHPTilrsDc:O:o:",
    longOptions: [
      "debug",
      "debugger",
      "dump-po-strings",
      "dump-strings",
      "help",
      "init-file=",
      "login",
      "noediting",
      "noprofile",
      "norc",
      "posix",
      "pretty-print",
      "rcfile=",
      "restricted",
      "verbose",
      "version",
    ],
    optionalLong: new Set(),
    bareDashIsI: false,
  },
  sh: {
    shortOptions: "abefhkmnptuvxBCHPirsDc:O:o:",
    longOptions: [
      "debug",
      "debugger",
      "dump-po-strings",
      "dump-strings",
      "help",
      "init-file=",
      "login",
      "noediting",
      "noprofile",
      "norc",
      "posix",
      "protected",
      "rcfile=",
      "restricted",
      "verbose",
      "version",
      "wordexp",
    ],
    optionalLong: new Set(),
    bareDashIsI: false,
  },
};

function shortTakesArg(shortOptions: string, opt: string): boolean | null {
  for (let i = 0; i < shortOptions.length; ) {
    const name = shortOptions[i]!;
    const takes = shortOptions[i + 1] === ":";
    if (name === opt) return takes;
    i += takes ? 2 : 1;
  }
  return null;
}

function longSpec(longOptions: string[], name: string): "flag" | "arg" | null {
  for (const spec of longOptions) {
    if (spec === name) return "flag";
    if (spec === `${name}=`) return "arg";
  }
  return null;
}

/** Python getopt.getopt for these wrapper grammars: options stop at the first non-option. */
function getoptRemaining(args: string[], grammar: WrapperGrammar): string[] | null {
  const remaining = [...args];
  while (remaining.length > 0) {
    const arg = remaining[0]!;
    if (arg === "--") {
      remaining.shift();
      break;
    }
    if (arg === "-" || !arg.startsWith("-")) break;
    if (arg.startsWith("--")) {
      const eq = arg.indexOf("=");
      const name = eq === -1 ? arg.slice(2) : arg.slice(2, eq);
      const spec = longSpec(grammar.longOptions, name);
      if (spec === null) return null;
      remaining.shift();
      if (spec === "arg" && eq === -1) {
        if (remaining.length === 0) return null;
        remaining.shift();
      }
      continue;
    }
    let cluster = arg.slice(1);
    remaining.shift();
    while (cluster.length > 0) {
      const opt = cluster[0]!;
      const takes = shortTakesArg(grammar.shortOptions, opt);
      if (takes === null) return null;
      cluster = cluster.slice(1);
      if (takes) {
        if (cluster.length > 0) {
          cluster = "";
        } else {
          if (remaining.length === 0) return null;
          remaining.shift();
        }
      }
    }
  }
  return remaining;
}

function wrapperAndGrammar(value: string): { name: string; grammar: WrapperGrammar } | null {
  for (const name of Object.keys(WRAPPERS)) {
    if (value === name || value.endsWith(`/${name}`)) {
      return { name, grammar: WRAPPERS[name]! };
    }
  }
  return null;
}

function consumeWrapperOptions(values: string[], grammar: WrapperGrammar): number | null {
  const normalized = [...values];
  if (grammar.bareDashIsI && normalized[0] === "-") normalized[0] = "-i";
  for (let index = 0; index < normalized.length; index++) {
    const value = normalized[index]!;
    if (!value.startsWith("--") || !value.includes("=")) continue;
    const name = value.slice(2).split("=", 1)[0]!;
    if (grammar.optionalLong.has(name)) normalized[index] = `--${name}`;
  }
  const remaining = getoptRemaining(normalized, grammar);
  if (remaining === null) return null;
  return values.length - remaining.length;
}

export type CommandWord = { tokenIndex: number; value: string };

/** Original-index words after Bash removes redirections. */
export function commandWords(tokens: ShellToken[]): CommandWord[] {
  const words: CommandWord[] = [];
  let skipTarget = false;
  for (let index = 0; index < tokens.length; index++) {
    const token = tokens[index]!;
    if (skipTarget) {
      skipTarget = false;
      continue;
    }
    const match = REDIRECTION.exec(token.raw);
    if (match && match[0] === token.raw) {
      skipTarget = !match[1];
      continue;
    }
    words.push({ tokenIndex: index, value: token.value });
  }
  return words;
}

/**
 * First simple-command word after assignments and the named wrappers.
 * This is the command-position test tap-oymdg proved a character class cannot do.
 */
export function resolveCommand(tokens: ShellToken[]): CommandWord | null {
  const words = commandWords(tokens);
  const values = words.map((w) => w.value);
  let index = 0;
  while (index < values.length && ASSIGNMENT.test(values[index]!)) index += 1;
  while (index < values.length) {
    const wrapper = wrapperAndGrammar(values[index]!);
    if (!wrapper) break;
    index += 1;
    const consumed = consumeWrapperOptions(values.slice(index), wrapper.grammar);
    if (consumed === null) return null;
    index += consumed;
    if (wrapper.name === "env") {
      while (index < values.length && ASSIGNMENT.test(values[index]!)) index += 1;
    }
  }
  return words[index] ?? null;
}

export type ToolHit = { tokenIndex: number; flags: ReadonlySet<string> };

export function toolAndFlags(tokens: ShellToken[]): ToolHit | null {
  const command = resolveCommand(tokens);
  if (!command) return null;
  const words = commandWords(tokens);
  const start = words.findIndex((w) => w.tokenIndex === command.tokenIndex);
  if (start < 0) return null;
  const value = command.value;
  if (value === "tap" || value.endsWith("/tap") || value.endsWith("/tap.sh")) {
    const verb = words[start + 1]?.value;
    if (verb === "send" || verb === "reply" || verb === "escalate" || verb === "assign") {
      return { tokenIndex: command.tokenIndex, flags: TAP_BODY_FLAGS };
    }
    return null;
  }
  if (value === "bd" || value.endsWith("/bd")) {
    return { tokenIndex: command.tokenIndex, flags: BD_BODY_FLAGS };
  }
  return null;
}

const PYTHON_VALUES = new Set([
  "python3",
  "$PY",
  "${PY}",
  "$REAL_PYTHON3",
  "$TAP_PYTHON",
  "${TAP_PYTHON:-python3}",
]);

export function isPythonCommand(value: string): boolean {
  if (PYTHON_VALUES.has(value)) return true;
  return value.endsWith("/python3");
}

const UNQUOTED_ATTACHED =
  /^(?:(?:[0-9]+|\{[A-Za-z_][A-Za-z0-9_]*\})?)<<(-?)(?!<)([A-Za-z_][A-Za-z0-9_]*)$/;
const UNQUOTED_DELIM = /^[A-Za-z_][A-Za-z0-9_]*$/;

type LocatedHeredoc = { opener: HeredocOpener; quoted: boolean };

/** Every token-shaped heredoc opener in shell order, quoted and unquoted. */
function allHeredocOpeners(tokens: ShellToken[]): LocatedHeredoc[] {
  const openers: LocatedHeredoc[] = [];
  for (let i = 0; i < tokens.length; i++) {
    const raw = tokens[i]!.raw;
    const attachedQuoted = openerFromAttachedRaw(raw);
    if (attachedQuoted) {
      openers.push({ opener: attachedQuoted, quoted: true });
      continue;
    }
    const attached = UNQUOTED_ATTACHED.exec(raw);
    if (attached && attached[2] !== undefined && attached[2].length > 0) {
      openers.push({
        opener: { stripTabs: attached[1] === "-", delimiter: attached[2] },
        quoted: false,
      });
      continue;
    }
    const bare = HEREDOC_PREFIX.exec(raw);
    if (bare && bare[0] === raw) {
      const next = tokens[i + 1];
      if (!next) continue;
      const quotedDelim = quotedDelimiterToken(next.raw);
      if (quotedDelim) {
        openers.push({
          opener: { stripTabs: bare[1] === "-", delimiter: quotedDelim },
          quoted: true,
        });
        i += 1;
        continue;
      }
      if (UNQUOTED_DELIM.test(next.raw)) {
        openers.push({
          opener: { stripTabs: bare[1] === "-", delimiter: next.raw },
          quoted: false,
        });
        i += 1;
      }
    }
  }
  return openers;
}

function unquotedHeredocOpeners(tokens: ShellToken[]): HeredocOpener[] {
  return allHeredocOpeners(tokens)
    .filter((item) => !item.quoted)
    .map((item) => item.opener);
}

function unquotedHeredocOpener(tokens: ShellToken[]): HeredocOpener | null {
  return unquotedHeredocOpeners(tokens)[0] ?? null;
}

function takeHeredocBody(
  lines: string[],
  start: number,
  opener: HeredocOpener,
): { body: string[]; closed: boolean; next: number } {
  const body: string[] = [];
  for (let j = start; j < lines.length; j++) {
    const candidate = lines[j]!;
    const closing = opener.stripTabs ? leadingTabsStripped(candidate) : candidate;
    if (closing === opener.delimiter) {
      return { body, closed: true, next: j + 1 };
    }
    body.push(candidate);
  }
  return { body, closed: false, next: lines.length };
}

function bodyHasUnsafeExpansion(body: string[]): boolean {
  for (const line of body) {
    for (let i = 0; i < line.length; i++) {
      const char = line[i]!;
      if ((char === "`" || commandSubstitutionAt(line, i)) && !shellEscaped(line, i)) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Unquoted `<<EOF` bodies expand in Bash. Token-shaped like U2: a quoted
 * mention of `<<EOF` is not an opener. Requires a tap/bd simple command on
 * the same line (the production scan's tool_and_flags gate).
 */
export function unquotedHeredocIsUnsafe(command: string): boolean {
  const lines = splitCommandLines(command);
  for (let index = 0; index < lines.length; index++) {
    const line = lines[index]!;
    const tokens = shellTokens(line);
    if (!toolAndFlags(tokens)) continue;
    const openers = allHeredocOpeners(tokens);
    let cursor = index + 1;
    for (const item of openers) {
      const taken = takeHeredocBody(lines, cursor, item.opener);
      cursor = taken.next;
      if (!item.quoted && taken.closed && bodyHasUnsafeExpansion(taken.body)) return true;
    }
  }
  return false;
}

export type GrammarGap =
  | "pipeline"
  | "bang_prefix"
  | "time_prefix"
  | "coproc"
  | "backslash_continuation_before_heredoc"
  | "env_split_string"
  | "shell_dash_c"
  | "unclosed_heredoc";

function topLevelSeparators(command: string): string[] {
  const seps: string[] = [];
  let quote: "'" | '"' | null = null;
  let escaped = false;
  for (let i = 0; i < command.length; i++) {
    const char = command[i]!;
    if (escaped) {
      escaped = false;
      continue;
    }
    if (char === "\\" && quote !== "'") {
      escaped = true;
      continue;
    }
    if (char === "'" || char === '"') {
      if (quote === null) quote = char;
      else if (quote === char) quote = null;
      continue;
    }
    const prev = i > 0 ? command[i - 1] : "";
    const next = command[i + 1];
    const redirectionPart =
      (char === "&" && (prev === "<" || prev === ">" || next === ">")) ||
      (char === "|" && prev === ">");
    if (quote === null && ";|&\n".includes(char) && !redirectionPart) seps.push(char);
  }
  return seps;
}

function firstCommandWord(segment: string): string | undefined {
  const words = commandWords(shellTokens(segment));
  const values = words.map((w) => w.value);
  let index = 0;
  while (index < values.length && ASSIGNMENT.test(values[index]!)) index += 1;
  return values[index];
}

function valuesOf(command: string): string[] {
  return commandWords(shellTokens(command)).map((w) => w.value);
}

function isEnvWord(value: string): boolean {
  return value === "env" || value.endsWith("/env");
}

function isShellWord(value: string): boolean {
  return (
    value === "bash" ||
    value === "sh" ||
    value.endsWith("/bash") ||
    value.endsWith("/sh")
  );
}

/**
 * Best-effort parser disclosure. These shapes are not silently allowed:
 * they are named out-of-grammar so a later decision layer cannot treat
 * "no unsafe hit" as "in grammar." Not a public lint-body verb.
 */
export function grammarGaps(command: string): GrammarGap[] {
  const gaps = new Set<GrammarGap>();
  if (topLevelSeparators(command).includes("|")) gaps.add("pipeline");
  const firstSeg = shellSegments(command)[0] ?? command;
  const first = firstCommandWord(firstSeg);
  if (first === "!") gaps.add("bang_prefix");
  if (first === "time") gaps.add("time_prefix");
  if (first === "coproc") gaps.add("coproc");

  const values = valuesOf(command);
  if (values.some(isEnvWord) && values.some((v) => v === "-S" || v === "--split-string" || v.startsWith("--split-string="))) {
    gaps.add("env_split_string");
  }
  if (values.some(isShellWord) && values.includes("-c")) gaps.add("shell_dash_c");

  const lines = splitCommandLines(command);
  for (let i = 0; i < lines.length - 1; i++) {
    const last = shellTokens(lines[i]!).at(-1);
    if (last?.raw !== "\\") continue;
    const next = shellTokens(lines[i + 1]!);
    if (quotedHeredocOpener(lines[i + 1]!) || unquotedHeredocOpener(next)) {
      gaps.add("backslash_continuation_before_heredoc");
    }
  }

  // A tap/bd heredoc with no terminator still runs; Bash takes the rest of
  // the command as the body and expands it when the opener is unquoted.
  // Name that instead of silent allow. Quoted mentions are not openers.
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;
    const tokens = shellTokens(line);
    if (!toolAndFlags(tokens)) continue;
    const openers = allHeredocOpeners(tokens);
    let cursor = i + 1;
    for (const item of openers) {
      const taken = takeHeredocBody(lines, cursor, item.opener);
      cursor = taken.next;
      if (!taken.closed) gaps.add("unclosed_heredoc");
    }
  }
  return [...gaps];
}
