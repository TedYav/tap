// `resolve-target` — the pure "what would this request resolve to?" probe the
// crew and launch preflights call before doing any work (launcher.py
// cmd_resolve_target + resolve_new_preset_args, deleted in the same PR). It
// answers as ONE compact JSON line on stdout and must be argv/catalog-decidable:
// it writes nothing, runs no harness, and its only side channel is preset
// notices on stderr (suppressed under TAP_JSON=1).
//
// Errors split like the incumbent's _main: preset-shaped refusals
// (LauncherError with an errorClass) honor TAP_JSON=1 and render
// {error_class,action,detail} on stdout, else prose
// `{verb}: {detail}; next: {action}` on stderr; a bare usage LauncherError is
// a session_error envelope under TAP_JSON=1 only. Three intentional deviations,
// all driver-ruled in the Unit 2 plan: argparse prefix abbreviations are gone
// (same precedent as `session complete`); an explicitly requested preset
// against a version-1 catalog refuses preset_config_retired instead of reading
// the retired document; and the hidden subparser's nonstandard argv `--json`
// is dropped — it was never the crew door's contract (TAP_JSON is), so a
// literal `--json` is an unknown argument.
import { ensureAscii } from "../fsatomic";
import { errorJson } from "../native-error";
import {
  configDirectory,
  HARNESSES,
  isRegularFile,
  readSecureBytes,
} from "./catalog";
import { isDocumentedRetiredCatalog, loadPresetCatalog, requirePreset, type ResolvedPreset } from "./catalog-listing";
import { Notices } from "./catalog-notices";
import { LauncherError } from "./types";

type Row = Record<string, unknown>;
type Env = NodeJS.ProcessEnv;

const RESERVED_HANDLES = new Set(["help"]);

function presetError(errorClass: string, action: string, detail: string): LauncherError {
  return new LauncherError(`${errorClass}: ${detail}`, errorClass, action, detail);
}

/** _ambiguous_harness_or_preset: an IMPLICIT request may name either space. */
function ambiguous(requested: string, presetDetail: string, usage: string): LauncherError {
  const harnesses = [...HARNESSES].sort().join(", ");
  return presetError(
    "harness_or_preset_not_found",
    usage,
    `'${requested}' is neither a known harness nor a known preset; canonical harnesses: ${harnesses}; ${presetDetail}`,
  );
}

/** presets.metadata_notice: `verb: name — roles — summary`, halves as present. */
function metadataNotice(name: string, metadata: ResolvedPreset["metadata"], verb: string): string | null {
  if (!metadata) return null;
  const roles = metadata.primary_roles.join(", ");
  const summary = (metadata.summary ?? "").trim();
  if (!roles && !summary) return null;
  const extra = roles && summary ? `${roles} — ${summary}` : roles || summary;
  return `${verb}: ${name} — ${extra}`;
}

export interface ResolveTargetArgs {
  preset?: string; // the explicitly requested preset (--preset)
  first?: string; // first positional: harness (fast path) or implicit request
  second?: string; // second positional: the seat label
  usage: string;
  verb: string;
}

export function resolveTarget(env: Env, notices: Notices, args: ResolveTargetArgs): {
  harness: string; preset: string | null; handle: string; configDigest: string | null; model: string | null;
} {
  const requested = args.preset;
  const first = args.first;
  const second = args.second;
  // Harness fast path: a bare known harness never consults the config, so a
  // malformed catalog cannot break the plainest crew add (the incumbent's
  // resolve_new_preset_args returns before load_preset_catalog). The reserved
  // handle still refuses here: the incumbent checks RESERVED_HANDLES in
  // cmd_resolve_target, AFTER resolution, so `claude help` refuses without
  // ever opening the catalog.
  if (requested === undefined && first !== undefined && HARNESSES.includes(first)) {
    const handle = second || first;
    if (RESERVED_HANDLES.has(handle)) {
      throw presetError(
        "reserved_handle",
        "pass an explicit seat name, or rename the preset",
        `handle '${handle}' is reserved as the CLI help keyword and cannot name a seat`,
      );
    }
    return { harness: first, preset: null, handle, configDigest: null, model: null };
  }
  if (requested === undefined && !first) throw new LauncherError(`usage: ${args.usage}`);

  // Arm mapping: a leading positional is a request unless --preset made the
  // request explicit; then it is a compatibility harness, and the trailing
  // positional (if any) is the label.
  let compat: string | null = null;
  let label: string | null = null;
  let implicitRequested: string;
  if (requested === undefined) {
    implicitRequested = first!;
    label = second ?? null;
  } else if (second !== undefined) {
    compat = first ?? null;
    label = second;
  } else if (first !== undefined && HARNESSES.includes(first)) {
    compat = first;
  } else {
    label = first ?? null;
  }
  const name = requested ?? implicitRequested!;

  let catalog;
  try {
    catalog = loadPresetCatalog(env, notices.sink, readSecureBytes, configDirectory(env), isRegularFile);
  } catch (error) {
    // An implicit request against a MISSING config is an ambiguity answer
    // ("neither harness nor preset"), not a config error; an explicit --preset
    // wants the real refusal.
    if (requested === undefined && (error as LauncherError).errorClass === "preset_config_missing") {
      const missing = error as LauncherError;
      throw ambiguous(name, `no preset config was loaded (${missing.detail})`, args.usage);
    }
    throw error;
  }
  if (requested !== undefined && isDocumentedRetiredCatalog(catalog.version)) {
    // Ruled deviation: the launch projection already refuses version-1
    // catalogs; resolve-target now agrees instead of reading a retired one.
    throw new LauncherError(
      `preset_config_retired: ${catalog.source_path}: version 1 is retired; migrate the catalog to version 2 or 3`,
      "preset_config_retired",
      `migrate ${catalog.source_path} to version 2 or 3`,
      `${catalog.source_path}: version 1 is retired; migrate the catalog to version 2 or 3`,
    );
  }
  const resolved = catalog.presets.get(name);
  if (!resolved) {
    if (requested !== undefined) requirePreset(catalog, name); // throws
    const available = [...catalog.presets.keys()].sort().join(", ") || "none";
    throw ambiguous(name, `configured presets in ${catalog.source_path}: ${available}`, args.usage);
  }
  if (compat !== null && compat !== resolved.harness) {
    throw presetError(
      "preset_harness_mismatch",
      `omit '${compat}' or use harness '${resolved.harness}'`,
      `preset '${name}' uses harness '${resolved.harness}', not compatibility harness '${compat}'`,
    );
  }

  // Success notices render exactly once each, in incumbent order: the family
  // note first, then the metadata line.
  if (resolved.note) notices.emit(`${args.verb || "tap session"}: ${resolved.provenance.name} — ${resolved.note}`);
  const metadataLine = metadataNotice(resolved.provenance.name, resolved.metadata, args.verb || "tap session");
  if (metadataLine) notices.emit(metadataLine);

  const handle = label || resolved.provenance.name;
  if (RESERVED_HANDLES.has(handle)) {
    throw presetError(
      "reserved_handle",
      "pass an explicit seat name, or rename the preset",
      `handle '${handle}' is reserved as the CLI help keyword and cannot name a seat`,
    );
  }
  return {
    harness: resolved.harness,
    preset: resolved.provenance.name,
    handle,
    configDigest: resolved.provenance.config_digest,
    model: resolved.model,
  };
}

export function cmdResolveTarget(argv: string[]): number {
  // The verb label colors prose and notices; it must be readable even when the
  // argv is too malformed to parse, so the scan mirrors the parser's operand
  // rule: a missing or flag-shaped operand leaves the default verb standing
  // and the parse refusal below carries it.
  let verb = "tap session";
  const verbIndex = argv.indexOf("--verb");
  const scanned = verbIndex !== -1 ? argv[verbIndex + 1] : undefined;
  if (scanned !== undefined && !scanned.startsWith("-")) verb = scanned;
  const helpAction = verb === "tap clear" ? "tap help clear" : "tap help session";

  let usage = "tap session launch <preset|harness> [name]";
  let preset: string | undefined;
  let positionals: string[] = [];
  const notices = new Notices();
  notices.suppress(process.env.TAP_JSON === "1");
  try {
    // The hidden subparser took no --json, so an argv --json is an unknown
    // argument here (ruled; the live door speaks TAP_JSON). Split-form flags
    // refuse a missing operand instead of eating the next option, the way
    // argparse did; the inline `--flag=value` spelling stays literal.
    const operand = (index: number): string => {
      const value = argv[index];
      if (value === undefined || value.startsWith("-")) throw new LauncherError(`usage: ${usage}`);
      return value;
    };
    for (let i = 0; i < argv.length; i++) {
      const arg = argv[i]!;
      const valued = arg.match(/^--(preset|usage)(?:=(.*))?$/);
      if (valued) {
        let value = valued[2];
        if (value === undefined) {
          value = operand(i + 1);
          i++;
        }
        if (valued[1] === "preset") preset = value; // argparse last-wins
        else usage = value;
        continue;
      }
      if (arg === "--verb") {
        operand(i + 1);
        i++;
        continue;
      }
      if (arg.startsWith("-")) throw new LauncherError(`usage: ${usage}`);
      if (positionals.length >= 2) throw new LauncherError(`usage: ${usage}`);
      positionals.push(arg);
    }
    const resolved = resolveTarget(process.env, notices, {
      preset,
      first: positionals[0],
      second: positionals[1],
      usage,
      verb,
    });
    const row: Row = {
      ok: true,
      harness: resolved.harness,
      preset: resolved.preset,
      handle: resolved.handle,
      config_digest: resolved.configDigest,
      model: resolved.model,
    };
    process.stdout.write(`${ensureAscii(JSON.stringify(row))}\n`);
    return 0;
  } catch (error) {
    if (!(error instanceof LauncherError)) throw error;
    if (error.errorClass !== null) {
      if (process.env.TAP_JSON === "1") {
        process.stdout.write(errorJson(error.errorClass, error.action ?? "", error.detail ?? error.message));
      } else {
        process.stderr.write(`${verb}: ${error.detail ?? error.message}; next: ${error.action}\n`);
      }
      return 2;
    }
    if (process.env.TAP_JSON === "1") {
      process.stdout.write(errorJson("session_error", helpAction, error.message));
    } else {
      process.stderr.write(`${verb}: ${error.message}\n`);
    }
    return 2;
  }
}

if (import.meta.main) process.exitCode = cmdResolveTarget(process.argv.slice(2));
