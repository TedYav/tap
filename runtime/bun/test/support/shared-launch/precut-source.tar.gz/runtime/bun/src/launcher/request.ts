import { applyOverrides } from "./overrides";
import { enforcePermissions } from "./permissions";
import { realpathSync, statSync } from "node:fs";
import { resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { buildHarnessInvocation } from "./adapters";
import { Notices } from "./catalog-notices";
import { applyLaunchEnv } from "./plan";
import { addParams, HARNESSES, refuse, resolveCatalog, type Preset } from "./catalog";

export type LaunchRequest = {
  handle: string;
  permissions: "auto" | "bypass";
  cwd: string;
  harness: string;
  model: string | null;
  sessionId?: string;
  argv: string[];
  env: Record<string, string>;
  storedEnv: Record<string, string>;
  unsetEnv?: string[];
  harnessTail?: string[];
  passthrough: string[];
  passthroughFromConfig: boolean;
  preset?: Preset["provenance"];
  attach: "auto" | "always" | "never";
  dryRun: boolean;
  json: boolean;
};

export function parseLaunch(args: string[], env: NodeJS.ProcessEnv = process.env): LaunchRequest {
  const positional: string[] = [];
  const values = new Map<string, string>();
  const envValues: Record<string, string> = Object.create(null);
  const unsetEnv: string[] = [];
  let passthrough: string[] | undefined;
  let attach: LaunchRequest["attach"] = "auto";
  let dryRun = false, json = env.TAP_JSON === "1";
  for (let i = 0; i < args.length; i++) {
    const arg = args[i]!;
    const key = arg.split("=", 1)[0]!;
    // L2 re-decides attachment; verify-then-attach is the default design, not an async failure hook.
    if (["--fresh", "--new", "--machine", "--singleton", "--resume", "--tag", "--unique"].includes(key)) {
      refuse("native_launcher_unsupported", `${key} is not in the Bun launch slice; use TAP_LAUNCHER=python tap session launch`);
    }
    if (key === "--teams") refuse("retired_flag", "--teams is retired; use --env");
    if (arg === "--dry-run") { dryRun = true; continue; }
    if (arg === "--json") { json = true; continue; }
    if (["--attach", "--detach", "--detached"].includes(arg)) {
      const mode = arg === "--attach" ? "always" : "never";
      if (attach !== "auto" && attach !== mode) refuse("launch_arg_invalid", "--attach and --detach conflict");
      attach = mode; continue;
    }
    if (["--preset", "--model", "--effort", "--env", "--unset-env", "--cwd"].includes(key)) {
      const value = arg.includes("=") ? arg.slice(arg.indexOf("=") + 1) : args[++i];
      if (!value || /[\x00-\x1f\x7f]/.test(value)) refuse("launch_arg_invalid", `${key} requires a nonempty value`);
      if (key === "--unset-env") unsetEnv.push(value);
      else if (key === "--env") {
        const at = value.indexOf("=");
        if (at < 1) refuse("launch_arg_invalid", "--env requires KEY=VALUE");
        envValues[value.slice(0, at)] = value.slice(at + 1);
      } else {
        if (values.has(key)) refuse("launch_arg_invalid", `${key} specified twice`);
        values.set(key, value);
      }
      continue;
    }
    if (positional.length === 2 && !arg.startsWith("-")) refuse("launch_arg_invalid", "unexpected third positional; use -- before harness arguments");
    if (arg.startsWith("-") || positional.length === 2) {
      const tail = args.slice(arg === "--" ? i + 1 : i);
      passthrough = tail.length ? tail : undefined;
      break;
    }
    positional.push(arg);
  }
  if (passthrough?.some(arg => arg === "--preset" || arg.startsWith("--preset="))) refuse("preset_passthrough", "--preset belongs before harness arguments");
  if (passthrough?.some(arg => arg.includes("\0"))) refuse("launch_arg_invalid", "NUL in harness argument");
  let requested = values.get("--preset");
  let harness: string | undefined;
  let name: string | undefined;
  if (requested) {
    if (positional[0] && HARNESSES.includes(positional[0])) { harness = positional[0]; name = positional[1]; }
    else { name = positional[0]; if (positional[1]) refuse("launch_arg_invalid", "too many seat names"); }
  } else {
    const target = positional[0];
    if (!target) refuse("launch_arg_invalid", "expected <preset|harness> [name]");
    if (HARNESSES.includes(target)) harness = target;
    else requested = target;
    name = positional[1];
  }
  if (requested && (values.has("--model") || values.has("--effort"))) refuse("preset_not_composable", "a preset cannot accompany --model or --effort");
  if (values.has("--effort") && passthrough !== undefined) refuse("launch_arg_invalid", "--effort cannot accompany harness passthrough");
  // Prefix ownership sits on ONE side, and for catalog notices that side is the
  // reader. It emits `tap config: ...` and `tap session: ...` already, matching
  // the incumbent's wording exactly; prefixing again produced
  // `tap session: tap config: version 4 is newer than ...` for every operator
  // whose catalog had anything to say. This file still owns the prefix for the
  // messages it writes itself.
  // ONE notice generation for the whole command, because the command reads the
  // catalog TWICE: once here and once inside `applyLaunchEnv`, which rereads
  // policy fresh on every launch and resume. That second read is survivable only
  // because identical text says itself once per COMMAND — a comment this file
  // already carried while handing both reads a raw sink with no dedup, so a
  // stable `version = 4` config printed its notice twice
  // (sol-pinnacle-6, S2 exact-head read). Asserting an invariant in prose does
  // not create it.
  const notices = new Notices((message: string) => {
    if (!json) process.stderr.write(`${message}\n`);
  });
  notices.suppress(json);
  const emit = (message: string) => notices.emit(message);
  const notice = (message: string) => emit(`tap session: ${message}`);
  const catalog = resolveCatalog(requested, harness, env, emit);
  harness = catalog.preset?.harness ?? harness!;
  if (harness !== "claude" && harness !== "codex") refuse("native_launcher_unsupported", `${harness} is not yet enabled in the Bun launcher; use TAP_LAUNCHER=python tap session launch`);
  const handle = name ?? requested ?? harness;
  if (!requested && name && /^\d+$/.test(name)) refuse("native_launcher_unsupported", "numeric resume shorthand requires TAP_LAUNCHER=python tap session launch");
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(handle) || handle === "help") refuse("launch_arg_invalid", `invalid or reserved handle ${handle}`);
  if (handle.includes(".")) refuse("native_launcher_unsupported", "dotted handles require a different name; choose a handle without a period because tmux versions normalize dots differently");
  const cwd = realpathSync(resolve(values.get("--cwd") ?? process.cwd()));
  if (!statSync(cwd).isDirectory()) refuse("launch_arg_invalid", "cwd must be a directory");
  const model = values.get("--model") ?? (typeof catalog.preset?.params.model === "string" ? catalog.preset.params.model : null);
  const sessionId = harness === "claude" ? randomUUID() : undefined;
  let argv = buildHarnessInvocation("new", { name: handle, harness, cwd, base: "", model, harness_session_id: sessionId }, null, null, env, catalog.permissions).argv;
  const effort = values.get("--effort");
  let effortArgs: string[] = [];
  if (effort) {
    if (harness === "claude" && !["low", "medium", "high", "xhigh", "max"].includes(effort)) refuse("launch_arg_invalid", "Claude effort must be low|medium|high|xhigh|max");
    effortArgs = harness === "codex" ? ["-c", `model_reasoning_effort="${effort}"`] : ["--effort", effort];
    argv.push(...effortArgs);
  }
  const storedParams = { ...catalog.preset?.params };
  if (typeof storedParams.model === "string") delete storedParams.model;
  const configKeys = harness === "codex";
  const presetTail = addParams([], storedParams, configKeys);
  const storedTail = presetTail;
  for (const source of [presetTail, passthrough ?? [], addParams([], catalog.policyParams, configKeys)]) {
    enforcePermissions(harness, catalog.permissions, source);
  }
  argv = addParams(argv, storedParams, configKeys);
  argv = addParams(argv, catalog.policyParams, configKeys);
  argv.push(...passthrough ?? []);
  enforcePermissions(harness, catalog.permissions, argv.slice(1));
  const recipe = applyOverrides({ harness_env: catalog.preset?.env }, {
    env: Object.entries(envValues).map(([key, value]) => `${key}=${value}`),
    unset_env: unsetEnv, argv: passthrough,
  });
  const storedEnv = recipe.harness_env;
  // `applyLaunchEnv` owns the policy tier and the collision warnings now.
  //
  // This used to pass `catalog.policyEnv` as the INVOCATION env, which defeated
  // the whole point: the composition order is policy, then `invocation.env`, so
  // this caller's FIRST snapshot outranked the fresh read and a config edited
  // between the two reads lost. "Read fresh on every launch and resume" was true
  // of the function and false of its only live caller
  // (sol-pinnacle-6's S2 early read, finding 3).
  //
  // The sink is `emit`, not `notice`: catalog notices own their own `tap config:`
  // / `tap session:` prefix, and adding a second one is the double-prefix defect
  // PR #xxxx removed. The collision loop that used to live here is gone with it —
  // it read the stale snapshot, skipped `invocation.env`, and did not sort.
  const effective = applyLaunchEnv({ argv, env: {} },
    { name: handle, harness, cwd, base: "", harness_env: storedEnv }, env, emit).env;
  for (const key of recipe.harness_unset_env) delete effective[key];
  if (json && attach === "always") refuse("launch_arg_invalid", "--attach and --json conflict");
  return { attach: json ? "never" : attach, handle, permissions: catalog.permissions, cwd, harness, model, sessionId, argv, env: effective,
    storedEnv, unsetEnv: recipe.harness_unset_env, harnessTail: recipe.harness_tail, passthrough: [...effortArgs, ...storedTail],
    passthroughFromConfig: !!catalog.preset, preset: catalog.preset?.provenance, dryRun, json };
}
