// The entry sidecar: everything that reads or mutates `spool/<id>.meta.json`
// and its two neighbours, `<id>.meta.json.lock` and `<id>.claim`. Ported from
// lib.sh as a strangler-fig slice; the Bash bodies are deleted in the same PR.
//
// FOUR DIFFERENT LOCKING DISCIPLINES LIVE HERE, and they are not
// interchangeable. Collapsing any pair of them would be a silent correctness
// change, so each one says which it is and why:
//
//   - `remove` WAITS for the meta lock, as the incumbent did, and holds it
//     across payload + meta + lease so a concurrent re-own cannot mint an owner
//     for an entry being terminalized — see `removeEntry` for why this wait is
//     not bounded like publication's;
//   - `bumpAttempts` takes NO lock, matching the incumbent, because a lost
//     increment delays accounting while a blocked courier stalls delivery;
//   - `claimAcquire` is an O_EXCL create with a staleness steal — a DIFFERENT
//     transaction from the meta lock and from the pane lock, and one of this
//     repo's three standing refusals: it is not redundant with either;
//   - `reapStaleSidecars` uses non-blocking flock throughout, because a sweeper
//     that blocks is a sweeper that can wedge whatever it was tidying up after.
//
// `.reown` (the owner lease) is deliberately NOT in this module. It is the
// waiter-handoff protocol, and it ports with the handoff arm that proves an
// in-flight lease survives a source change — a slice of its own.

import { closeSync, existsSync, lstatSync, mkdirSync, openSync, readFileSync, readdirSync, renameSync, rmSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { basename, dirname, join } from "node:path";

import { KERNEL_LOCK, acquirePathLock, kernelLockAvailable } from "./panelock";
import { PyFloat, PyInt, metaBytes, parseMetaPreservingFloats, pyInt, pyTruthy } from "./spool-publication";

/** Matches the incumbent's `${TAP_SPOOL_CLAIM_STALE_SECONDS:-300}`. */
const CLAIM_STALE_DEFAULT = 300;

function staleSeconds(env: NodeJS.ProcessEnv): number {
  const raw = env.TAP_SPOOL_CLAIM_STALE_SECONDS;
  if (!raw) return CLAIM_STALE_DEFAULT;
  // The incumbent passes this through Python `int()`, which raises on junk and
  // takes the whole program down — so a malformed value is a hard refusal
  // there, not a default. Reproduce the refusal rather than inventing a
  // fallback the incumbent does not have.
  const value = pyInt(raw);
  if (value === null) throw new Error(`TAP_SPOOL_CLAIM_STALE_SECONDS is not an integer: ${raw}`);
  return value;
}

/**
 * Can this lock NAME exist on this filesystem? The incumbent's
 * `open(meta + ".lock", "w")` raised ENAMETOOLONG for a 245-byte id — the meta
 * name fits the 255-byte filename limit, its `.lock` does not — and every
 * caller caught that and fell through in milliseconds. `acquirePathLock` hands
 * the same path to the kernel lock helper and, by design, never inspects the
 * child's exit, so an uncreatable path costs the FULL timeout (spool-retired's
 * 245-byte boundary arm, red in CI at `fc6c4a351`).
 *
 * ONLY ENAMETOOLONG is answered `false`. It is the one failure that proves no
 * lock inode can exist and therefore that no holder can exist. Every other
 * open failure propagates: EACCES can be an existing, HELD lock whose mode
 * changed, and EMFILE is this process's own limit while another process holds
 * the inode — classifying either as "no lock possible" would be the unlocked
 * fallback CONTRACT.md forbids, wearing a probe's clothes (sol-pinnacle-1,
 * #xxxx S1 shape correction).
 */
export function lockNameFits(path: string): boolean {
  try { closeSync(openSync(path, "a")); return true; }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENAMETOOLONG") return false;
    throw error;
  }
}

export function metaPath(spoolDir: string, id: string): string {
  return join(spoolDir, `${id}.meta.json`);
}
export function payloadPath(spoolDir: string, id: string): string {
  return join(spoolDir, `${id}.md`);
}
export function claimPath(spoolDir: string, id: string): string {
  return join(spoolDir, `${id}.claim`);
}

/**
 * One field, or "". Every failure is "" — a missing file, unreadable JSON, a
 * missing key, and a key whose value is falsy all read the same, because the
 * incumbent's `.get(key) or ""` cannot tell them apart either and its callers
 * are written against that.
 */
export function metaField(spoolDir: string, id: string, key: string): string {
  try {
    const text = readFileSync(metaPath(spoolDir, id), "utf8");
    const row = parseMetaPreservingFloats(text);
    // Python `or ""`: every falsy value — 0, 0.0, -0.0, False, "", None, [],
    // {} — and an absent key all yield "".
    const value = row[key];
    if (!pyTruthy(value)) return "";
    return pyPrint(value);
  } catch { return ""; }
}

/**
 * What Python's `print(value)` puts on stdout, which is what the incumbent's
 * callers have always read. `JSON.stringify` is the wrong function here in
 * three separate ways, and each one produces a plausible-looking string rather
 * than an obvious failure: `true` prints as `True`, a whole float prints as
 * `1.0` rather than `1`, and a container prints in Python's repr with single
 * quotes. Only scalars are reachable through today's callers, but "unreachable"
 * is a claim about callers, not about the function.
 */
export function pyPrint(value: unknown): string {
  if (value instanceof PyFloat) return value.repr();
  if (value instanceof PyInt) return value.source;
  if (typeof value === "string") return value;
  if (typeof value === "boolean") return value ? "True" : "False";
  if (typeof value === "number") return String(value);
  if (value === null) return "None";
  if (Array.isArray(value)) return `[${value.map(pyPrint2).join(", ")}]`;
  if (typeof value === "object") {
    return `{${Object.entries(value as Record<string, unknown>).map(([k, v]) => `${pyPrint2(k)}: ${pyPrint2(v)}`).join(", ")}}`;
  }
  return String(value);
}

/** Python reprs a string INSIDE a container, and prints it bare at top level. */
function pyPrint2(value: unknown): string {
  if (typeof value === "string") return `'${value.replace(/\\/g, "\\\\").replace(/'/g, "\\'")}'`;
  return pyPrint(value);
}

/**
 * Best-effort +1 after a delivery attempt. UNLOCKED, exactly as the incumbent:
 * a concurrent whole-meta replace can drop this increment, and that is the
 * accepted direction — a lost increment delays accounting, while blocking here
 * would stall the courier on a held lock. The live-probe counter is the writer
 * that DOES take the lock, and it stays where it is.
 */
export function bumpAttempts(spoolDir: string, id: string): void {
  const path = metaPath(spoolDir, id);
  try {
    if (!statSync(path).isFile()) return;
    const row = parseMetaPreservingFloats(readFileSync(path, "utf8"));
    const current = pyInt(row.attempts ?? 0);
    row.attempts = current === null ? 1 : current + 1;
    // The incumbent writes `<path>.tmp` and replaces; same fixed name, because
    // a crashed writer's leftover must be overwritten rather than accumulate.
    //
    // NO TRAILING NEWLINE, unlike the publication writer: this site's
    // `json.dump` has no `fh.write("\n")` after it, so a bumped sidecar ends at
    // `}`. The two writers genuinely differ, and matching the wrong one changes
    // the file's bytes on every delivery attempt.
    const tmp = `${path}.tmp`;
    writeFileSync(tmp, metaBytes(row as Record<string, never>).replace(/\n$/, ""));
    renameSync(tmp, path);
  } catch { /* best effort: an attempt was made whether or not the count lands */ }
}

export type ClaimResult = "acquired" | "held";

/**
 * The publication/drain claim: an O_EXCL create, with one steal of a claim
 * older than the staleness horizon.
 *
 * NOT the meta lock and NOT the pane lock. It spans a canonical-to-spool
 * custody transfer that outlives any single critical section, which is why a
 * pane lock cannot stand in for it and why `.claim` is one of the three
 * refusals this repo keeps written down.
 *
 * `noSteal` is the readers' mode: a reader must never reclaim a live claim,
 * because the holder is mid-transfer and the reader only wants to look.
 */
export function claimAcquire(spoolDir: string, id: string, noSteal = false, env: NodeJS.ProcessEnv = process.env): ClaimResult {
  const path = claimPath(spoolDir, id);
  const stale = staleSeconds(env);
  const now = Math.floor(Date.now() / 1000);
  // Two passes: create, and — after a successful steal — create again. A third
  // pass would be a retry loop against a live competitor, which is how two
  // holders end up believing they won.
  for (let attempt = 0; attempt < 2; attempt++) {
    let fd: number;
    try {
      mkdirSync(dirname(path), { recursive: true });
      fd = openSync(path, "wx", 0o600);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") return "held";
      if (noSteal) return "held";
      let age: number;
      try { age = now - Math.floor(statSync(path).mtimeMs / 1000); } catch { continue; }
      if (age <= stale) return "held";
      try { unlinkSync(path); } catch { return "held"; }
      continue;
    }
    try {
      // Python's `json.dump` default separators, `", "` and `": "` — this file
      // is written without `indent`, so it is the one place in the spool where
      // the spaced form is correct.
      const body = `{"v": 1, "id": ${JSON.stringify(id)}, "owner_pid": ${process.pid}, "claimed_at_epoch": ${now}}`;
      writeFileSync(fd, `${body}\n`);
    } finally { closeSync(fd); }
    return "acquired";
  }
  return "held";
}

export function claimRelease(spoolDir: string, id: string): void {
  rmSync(claimPath(spoolDir, id), { force: true });
}

/**
 * Read-only claim observation for the reader's bounded wait (tap-4b7ib). The
 * verdict separates REAL contention — a well-formed claim some process is
 * holding through a custody transfer — from broken evidence no holder can ever
 * release: a non-regular file, junk bytes, a foreign id (`invalid`) or a valid
 * claim already past the steal horizon (`stale`). A reader must refuse the
 * broken shapes immediately instead of waiting out the ceiling on them.
 * `acquire` keeps its own meaning for its callers: under no-steal it still
 * refuses every EEXIST, so an `invalid` observation only skips the wait, never
 * widens what a claim holder may do. Nothing here writes or steals.
 */
export function claimObserve(spoolDir: string, id: string, env: NodeJS.ProcessEnv = process.env): "free" | "held" | "stale" | "invalid" {
  const path = claimPath(spoolDir, id);
  let stat: { isFile(): boolean; mtimeMs: number };
  // No-follow on purpose: a symlink alias to a real claim is still not a
  // regular claim file — observation classifies the name, not the target.
  try { stat = lstatSync(path); } catch { return "free"; }
  if (!stat.isFile()) return "invalid";
  let parsed: { v?: unknown; id?: unknown; owner_pid?: unknown; claimed_at_epoch?: unknown };
  try { parsed = JSON.parse(readFileSync(path, "utf8")); } catch { return "invalid"; }
  if (typeof parsed !== "object" || parsed === null || parsed.v !== 1 || parsed.id !== id) return "invalid";
  // Only the minted shape counts as a live holder: a reader that waits on
  // anything less is waiting on nothing.
  if (typeof parsed.owner_pid !== "number" || !Number.isInteger(parsed.owner_pid) || parsed.owner_pid <= 0) return "invalid";
  if (typeof parsed.claimed_at_epoch !== "number" || !Number.isFinite(parsed.claimed_at_epoch)) return "invalid";
  const age = Math.floor(Date.now() / 1000) - Math.floor(stat.mtimeMs / 1000);
  return age > staleSeconds(env) ? "stale" : "held";
}

/**
 * Payload, metadata and the `.reown` lease are unlinked TOGETHER, under the
 * entry's meta lock, after the metadata is archived — the incumbent's shape,
 * and CONTRACT.md's ("Removing a spool entry is one locked step").
 *
 * Separate unlinks leave a window in which a re-own observes a payload being
 * terminalized and mints a successor owner for an entry about to stop existing
 * — a waiter spawned for a dead id, and a fresh lease written after the unlink.
 * Under the lock the re-own runs either entirely before this (and its lease is
 * unlinked here) or entirely after (and finds no payload). Calling that window
 * small does not change the invariant.
 *
 * THE WAIT IS NOT BOUNDED THE WAY PUBLICATION'S IS, and the reason is the
 * callers, not the lock. Publication's bound was ratified because a refused
 * park produces a receipt where an unbounded wait produces a stalled courier.
 * Removal's Bash callers — the retained drain engine, `tap-send.sh`, `tap-cancel.sh`
 * — run `set -euo pipefail` and call `tap_spool_remove` as a bare statement,
 * written against an incumbent that could not return nonzero (its trailing
 * `rm -f` belt). A removal that REFUSES on timeout therefore does not surface
 * as a receipt: it aborts the caller after `ln` has hard-linked the payload to
 * canonical and before the spool copy is gone, and the next drain delivers it
 * again. A removal that PROCEEDS unlocked on timeout is the re-own race above
 * (sol-pinnacle-1 S1, with a real holder). The only shape that is both safe
 * for those callers and faithful to the contract is the incumbent's: wait. A
 * holder that keeps this lock for longer than its millisecond critical section
 * is a wedged process, and a courier wedged behind it is the documented
 * diagnosis ("band wedged: check the flock first"), not a new failure. The
 * helper's grammar needs a number, so the wait is a day — "without bound" for
 * any hold that is not already an incident. Do not "fix" the asymmetry with
 * publication without re-reading the callers.
 *
 * Refusals that DO exist: a missing lock helper (panelock throws; the entry
 * is retained and the caller sees `slice_failed`, exactly as it would for a
 * missing runtime) and the day elapsing. The one unlocked path is a lock NAME
 * the filesystem cannot hold — `lockNameFits` — where no holder can exist.
 */
export const REMOVAL_LOCK_WAIT_MS = 86_400_000;

export function removeEntry(spoolDir: string, id: string, env: NodeJS.ProcessEnv = process.env, lockWaitMs = REMOVAL_LOCK_WAIT_MS): void {
  const meta = metaPath(spoolDir, id);
  const payload = payloadPath(spoolDir, id);
  const archiveAndUnlink = (): void => {
    try {
      if (statSync(meta).isFile()) {
        const archive = join(dirname(dirname(meta)), "archive");
        mkdirSync(archive, { recursive: true });
        writeFileSync(join(archive, basename(meta)), readFileSync(meta));
      }
    } catch { /* an unarchivable or absent sidecar must not block the removal */ }
    // Each unlink swallows its own error, as the incumbent's per-path
    // `except OSError: pass` did. `force` only forgives ENOENT: at the 245-byte
    // boundary the `.reown` name is 261 bytes and raises ENAMETOOLONG, which
    // must not abort the removal after payload and meta are already gone.
    for (const path of [payload, meta, `${meta}.reown`]) {
      try { rmSync(path, { force: true }); } catch { /* the incumbent's own tolerance */ }
    }
  };
  if (!lockNameFits(`${meta}.lock`)) { archiveAndUnlink(); return; }
  const lock = acquirePathLock(`${meta}.lock`, lockWaitMs, env);
  if (!lock) throw new Error(`spool_remove: metadata lock for '${id}' still held after ${lockWaitMs} ms; entry retained`);
  try { archiveAndUnlink(); } finally { lock.release(); }
}

/**
 * Sweep inert writer locks, stale claims, and metadata orphaned by a crashed
 * post-submit cleanup.
 *
 * NON-BLOCKING throughout. A sweeper that waits on a lock is a sweeper that can
 * wedge behind the very writer it exists to clean up after; every acquisition
 * here either succeeds immediately or the candidate is skipped until next time.
 *
 * The stale-lock pass does NOT go through `acquirePathLock`. That primitive is
 * built for holding: it spawns a helper, waits through a 100 ms handshake
 * allowance to learn whether the helper got the lock, and on success keeps the
 * child alive until release. Probing N candidates with it costs N of those
 * round trips — ~20 ms each unheld, ~100 ms each held (sol-pinnacle-1, #xxxx
 * S5, measured against the incumbent's in-process `LOCK_NB`: 172 ms vs 2121
 * ms for twenty held locks). A sweep only needs "take it if nobody has it,
 * then unlink it", so it hands the whole batch to ONE helper invocation per
 * chunk, in which each candidate is a non-blocking attempt (`-t 0` /
 * `--nonblock`) whose command unlinks the file while the lock is still held.
 * A held lock refuses in the time it takes the helper to fail `flock(2)`,
 * and the lock stays.
 */
export function reapStaleSidecars(spoolDir: string, payloadsDir: string, env: NodeJS.ProcessEnv = process.env): void {
  let entries: string[];
  try { entries = readdirSync(spoolDir); } catch { return; }
  const stale = staleSeconds(env);
  const now = Date.now() / 1000;

  const inertLocks: string[] = [];
  for (const name of entries) {
    if (!name.endsWith(".meta.json.lock") && !name.endsWith(".claim")) continue;
    const path = join(spoolDir, name);
    try {
      if (now - statSync(path).mtimeMs / 1000 <= stale) continue;
      if (name.endsWith(".claim")) unlinkSync(path);
      else inertLocks.push(path);
    } catch { /* another sweeper got there first */ }
  }
  sweepUnheldLocks(inertLocks);

  // A redelivery claim owns the brief spool -> canonical move. Once that claim
  // is stale or gone, a canonical payload is authoritative and its metadata is
  // an orphan from a crashed post-submit cleanup, not a second obligation.
  for (const name of entries) {
    if (!name.endsWith(".meta.json")) continue;
    const id = name.slice(0, -".meta.json".length);
    const meta = join(spoolDir, name);
    const orphaned = (): boolean =>
      !existsSync(payloadPath(spoolDir, id)) && !existsSync(claimPath(spoolDir, id)) && isFile(join(payloadsDir, `${id}.md`));
    if (!orphaned()) continue;
    // The incumbent's `open(lock_path, "a+")` raised for an uncreatable path and
    // the candidate was skipped; a bounded acquire on the same path would wait.
    // This loop keeps its per-path acquire: the orphan decision below has to
    // be re-taken UNDER the lock, which a fire-and-unlink helper cannot do.
    let fits: boolean;
    try { fits = lockNameFits(`${meta}.lock`); } catch { continue; }
    if (!fits) continue;
    try {
      const lock = acquirePathLock(`${meta}.lock`, 0, env);
      if (!lock) continue;
      try {
        // Re-checked UNDER the lock: the first look was a filter, this is the
        // decision, and between them an entry can be re-parked.
        //
        // NOT COVERED BY A TEST, and deliberately recorded as such. Deleting
        // this line leaves both differentials green, because reaching it
        // requires another process to re-park the entry inside the window
        // between the filter and this line — a race a single-threaded fixture
        // cannot construct. The guard is kept because the incumbent has it and
        // the window is real, not because anything here proves it fires.
        if (!orphaned()) continue;
        unlinkSync(meta);
      } finally { lock.release(); }
      rmSync(`${meta}.lock`, { force: true });
    } catch { /* leave it for the next sweep */ }
  }
}

/**
 * One helper invocation per chunk: each path is a non-blocking acquire whose
 * command unlinks the file while the lock is held. On macOS `lockf` without
 * `-k` removes the lock file itself after the command; on Linux `flock` does
 * not, so `rm` is the command. A held lock fails the acquire and survives; a
 * path the helper cannot open is skipped, as the incumbent's `open` failure
 * was. Chunked so a long-neglected bus cannot overflow one argv.
 */
function sweepUnheldLocks(paths: string[]): void {
  if (paths.length === 0) return;
  if (!kernelLockAvailable()) throw new Error(`spool reap requires ${KERNEL_LOCK}, which is not present on this host`);
  const loop = process.platform === "linux"
    ? 'for f; do "$0" --exclusive --nonblock "$f" rm -f -- "$f"; done'
    : 'for f; do "$0" -s -t 0 "$f" true; done';
  for (let i = 0; i < paths.length; i += 256) {
    Bun.spawnSync(["sh", "-c", loop, KERNEL_LOCK, ...paths.slice(i, i + 256)], { stdout: "ignore", stderr: "ignore" });
  }
}

function isFile(path: string): boolean {
  try { return statSync(path).isFile(); } catch { return false; }
}

if (import.meta.main) {
  const [mode, ...rest] = Bun.argv.slice(2);
  try {
    // `print()`, not `write()`: the incumbent's reader is a Python `print`, so
    // the value carries a trailing newline and an empty result is a bare one.
    // Every caller uses `$(...)`, which strips it — which is exactly how a byte
    // difference like this survives until something stops using a subshell.
    if (mode === "field" && rest.length === 3) process.stdout.write(`${metaField(rest[0]!, rest[1]!, rest[2]!)}\n`);
    else if (mode === "bump" && rest.length === 2) bumpAttempts(rest[0]!, rest[1]!);
    else if (mode === "claim" && rest.length >= 2) {
      // The word is the receipt, and BOTH words exit 0. A held claim is routine
      // contention, not a failure: exiting nonzero for it made `tap_bun_call`
      // print a slice-failure line on every drain tick, and silencing that
      // line also silenced `runtime_missing`, which a missing `bun` must still
      // report loudly. So the status carries the runtime's health and the word
      // carries the verdict. A runtime that exits 0 having written nothing — a
      // stub, a crashed startup — produces neither word, and the adapter
      // refuses that shape rather than reading rc 0 as a held claim.
      process.stdout.write(`${claimAcquire(rest[0]!, rest[1]!, rest[2] === "no-steal")}\n`);
    } else if (mode === "release" && rest.length === 2) claimRelease(rest[0]!, rest[1]!);
    else if (mode === "observe" && rest.length === 2) process.stdout.write(`${claimObserve(rest[0]!, rest[1]!)}\n`);
    else if (mode === "remove" && rest.length === 2) removeEntry(rest[0]!, rest[1]!);
    else if (mode === "reap" && rest.length === 2) reapStaleSidecars(rest[0]!, rest[1]!);
    else {
      process.stderr.write("spool-sidecar: expected field|bump|claim|observe|release|remove|reap with its arguments\n");
      process.exit(2);
    }
  } catch (error) {
    process.stderr.write(`tap: ${error instanceof Error ? error.message : String(error)}\n`);
    process.exit(1);
  }
}
