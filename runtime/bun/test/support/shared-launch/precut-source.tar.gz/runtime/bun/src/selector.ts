// One Bun selector authority for caller-bus and target selection (tap-1t0h.1).
//
// THIS FILE IS THE AUTHORITY. context.ts consumes selectCaller for caller-bus
// resolution: under a live marker, native verbs that go through resolveContext
// inherit the cwd enrollment walk and TAP_HOME-last fallback. Target selection,
// lock-held revalidation, and child-pin comparison are library capability —
// no production mutation site or router --team flag is wired in this stage.
// There is no second Python implementation, no TAP_TEAM pin, and no new env.
//
// Deferred caller route / deletion accounting (Stage 0 does not cut these over):
//   skills/tap/scripts/lib.sh              tap_apply_team_override, tap_authority_context,
//                                          tap_resolve_team_target (still TAP_HOME-first)
//   skills/tap/scripts/tap-register.sh     --team vs TAP_HOME team_home_conflict
//   skills/tap/scripts/session/launcher.py _team_bus_home, root_for_cwd
//   hooks / tap-resolve-session-root       walk_up_session_root (boolean is_session_root)
//   runtime/bun/src/verbs/done.ts          applyTeamOverride (TAP_HOME still wins;
//                                          --team remains Bash-owned on the router)
// A CLI that printed one JSON Selection is planned for those callers; it is
// not in this tree. Native send/reply `DelegateToBash` fallback sets TAP_HOME
// to the selected caller bus; `--team` remains Bash-owned on the router.

import { accessSync, constants, realpathSync, statSync } from "node:fs";
import { basename, dirname, join } from "node:path";
import { spawnSync } from "node:child_process";

import { containerRefusal, repoRoot, resolveBus, type BusRule } from "./bushome";
import { pyReadUtf8 } from "./spool-publication";
import { validToken } from "./ids";
import {
  enrollmentAt,
  enrollmentAtFromDoc,
  flipMarkerState,
  globalRegistryPath,
  loadGlobalRegistry,
  resolveEnrolledTeamRoot,
  resolveTeamFromDoc,
  resolveTeamFromGlobal,
  type FlipState,
} from "./index-home";
import { isRegistryLock, type RegistryLock } from "./panelock";

export class SelectorError extends Error {
  constructor(
    readonly code: number,
    readonly errorClass: string,
    readonly action: string,
    readonly detail: string,
  ) {
    super(detail);
    this.name = "SelectorError";
  }
}

export type SelectorSource = "explicit-team" | "cwd" | "pinned-root" | "env" | "pane";
export type AuthorityMode = "enrolled" | "bus";
export type VerbClass = "send" | "lifecycle";

export interface Selection {
  team: string;
  rootReal: string;
  /** Index-recorded acting registry path. Lock sidecar and effects use this. */
  registryLocation: string;
  /** Canonical realpath of the acting registry. Equality only — not lock identity. */
  registryLocationReal: string;
  busHome: string;
  busRule: BusRule;
  source: SelectorSource;
  /** Machine flip marker observed at select time. */
  marker: "absent" | "live";
  /**
   * Where this pin is authoritative.
   * `enrolled` revalidates through the global index.
   * `bus` is an unindexed custom/scratch bus — even when the machine marker is
   * live — and must never be forced through globalRegistry.
   */
  authority: AuthorityMode;
}

export interface TargetSelection {
  team: string;
  handle: string;
  rootReal: string;
  registryLocation: string;
  registryLocationReal: string;
  scope: "local" | "remote";
}

export interface SelectorInput {
  cwd: string;
  env?: NodeJS.ProcessEnv;
  /** Caller-axis `--team`. */
  explicitTeam?: string;
  /** Target-axis raw address: bare handle or `team/handle`. */
  explicitTarget?: string;
  /** Detached child: run as if cwd were this enrolled root. */
  pinnedRoot?: string;
  /** Lifecycle verbs treat `--team` and `team/handle` as the same axis. */
  verbClass?: VerbClass;
}

export interface SelectorResult {
  caller: Selection;
  target?: TargetSelection;
}

export interface ParsedTarget {
  team: string;
  handle: string;
  qualified: boolean;
}

/**
 * Parse a seat address. `team:handle` normalizes to `team/handle`.
 * More than one slash, empty parts, or a bad charset refuse — they never
 * fall through to cwd or TAP_HOME.
 */
export function parseTarget(raw: string): ParsedTarget {
  const value = raw.trim();
  if (!value) {
    throw new SelectorError(1, "usage_error", "tap help", "address is empty");
  }
  let normalized = value;
  if (value.includes(":") && !value.includes("/")) {
    const team = value.slice(0, value.indexOf(":"));
    const handle = value.slice(value.indexOf(":") + 1);
    if (!team || !handle) {
      throw new SelectorError(1, "usage_error", "tap help",
        `address '${value}' is not a valid <team>:<handle> token`);
    }
    normalized = `${team}/${handle}`;
  }
  if (normalized.includes("/")) {
    const team = normalized.slice(0, normalized.indexOf("/"));
    const handle = normalized.slice(normalized.indexOf("/") + 1);
    if (!team || !handle || handle.includes("/")) {
      throw new SelectorError(1, "usage_error", "tap help",
        `address '${value}' must be <team>/<handle> with one slash`);
    }
    if (!validToken(team)) {
      throw new SelectorError(1, "usage_error", "tap help",
        `team '${team}' is not a valid token (^[A-Za-z0-9][A-Za-z0-9._-]*$)`);
    }
    if (!validToken(handle)) {
      throw new SelectorError(1, "usage_error", "tap help",
        `handle '${handle}' is not a valid token (^[A-Za-z0-9][A-Za-z0-9._-]*$)`);
    }
    return { team, handle, qualified: true };
  }
  if (!validToken(normalized)) {
    throw new SelectorError(1, "usage_error", "tap help",
      `handle '${normalized}' is not a valid token (^[A-Za-z0-9][A-Za-z0-9._-]*$)`);
  }
  return { team: "", handle: normalized, qualified: false };
}

export function resolveSelector(input: SelectorInput): SelectorResult {
  const env = input.env ?? process.env;
  const verbClass = input.verbClass ?? "send";
  const parsed = input.explicitTarget !== undefined ? parseTarget(input.explicitTarget) : undefined;

  if (verbClass === "lifecycle" && input.explicitTeam && parsed?.qualified) {
    throw new SelectorError(1, "selector_conflict", "pass --team OR a team/handle target, not both",
      `lifecycle --team '${input.explicitTeam}' and qualified target '${input.explicitTarget}' are the same axis`);
  }

  const caller = selectCaller(input);
  if (!parsed) return { caller };
  const target = selectTarget(caller, parsed, env);
  return { caller, target };
}

export function selectCaller(input: SelectorInput): Selection {
  const env = input.env ?? process.env;
  const indexHome = env.TAP_INDEX_HOME;
  const marker = requireMarker(indexHome);

  if (input.explicitTeam !== undefined && input.explicitTeam === "") {
    throw new SelectorError(1, "usage_error", "tap help", "--team needs a value");
  }

  if (input.pinnedRoot !== undefined) {
    if (input.pinnedRoot === "") {
      throw new SelectorError(1, "usage_error", "tap help", "pinned root needs a value");
    }
    const pinned = bindPinnedRoot(
      canonicalDir(input.pinnedRoot, "pinned_root"),
      marker,
      indexHome,
      env,
    );
    if (input.explicitTeam) {
      const explicit = selectExplicitTeam(input.explicitTeam, marker, indexHome, env);
      if (pinned.team !== explicit.team || pinned.registryLocation !== explicit.registryLocation) {
        throw new SelectorError(1, "selector_conflict", "pass --team OR a pinned root, not both",
          `explicit --team '${explicit.team}' disagrees with pinned root team '${pinned.team}'`);
      }
      return explicit;
    }
    return pinned;
  }

  if (input.explicitTeam) {
    return selectExplicitTeam(input.explicitTeam, marker, indexHome, env);
  }
  return selectFromWalk(canonicalDir(input.cwd, "cwd"), marker, indexHome, env, "cwd");
}

export function selectTarget(caller: Selection, parsed: ParsedTarget, env: NodeJS.ProcessEnv = process.env): TargetSelection {
  const handle = parsed.handle;
  if (!parsed.qualified || parsed.team === caller.team) {
    return {
      team: caller.team,
      handle,
      rootReal: caller.rootReal,
      registryLocation: caller.registryLocation,
      registryLocationReal: caller.registryLocationReal,
      scope: "local",
    };
  }
  const bound = bindTeam(parsed.team, caller.marker, env.TAP_INDEX_HOME, env);
  return {
    team: bound.team,
    handle,
    rootReal: bound.rootReal,
    registryLocation: bound.registryLocation,
    registryLocationReal: bound.registryLocationReal,
    scope: "remote",
  };
}

/**
 * Recheck the pinned triple under the acting registry lock. A caller that
 * mutates the acting registry can invoke this immediately before the write.
 * Stage 0 does not wire a production mutation site.
 *
 * `lock` must be the branded token `acquireRegistryLock` minted for this file.
 */
export function assertSelectionCurrent(
  selection: Selection,
  lock: RegistryLock,
  indexHome?: string,
): void {
  if (!isRegistryLock(lock as object)) {
    throw new SelectorError(1, "lock_required", "acquire the acting registry lock, then retry",
      "selection revalidation requires the acting registry lock");
  }
  if (lock.registryLocation !== selection.registryLocation) {
    throw new SelectorError(1, "lock_mismatch", "acquire the acting registry lock for the selected file",
      `held lock is for '${lock.registryLocation}', selection is '${selection.registryLocation}'`);
  }

  if (selection.authority === "enrolled") {
    const snap = loadGlobalRegistry(indexHome);
    if (snap.marker === "invalid") {
      throw new SelectorError(1, "invalid_flip", "tap doctor",
        "registry flip marker is present but invalid; refusing rather than skipping a v0.20 obligation");
    }
    if (selection.marker === "live") {
      if (snap.marker !== "live" || !snap.doc) {
        throw new SelectorError(1, "team_moved", "tap doctor",
          `team '${selection.team}' enrollment is no longer live (marker ${snap.marker})`);
      }
      const r = resolveTeamFromDoc(snap.doc, selection.team);
      if (r.status !== "ok") {
        throw new SelectorError(1, "team_moved", "tap doctor",
          `team '${selection.team}' is no longer a live enrollment (${r.status})`);
      }
      if (r.registryLocation !== selection.registryLocation) {
        throw new SelectorError(1, "team_moved", "tap doctor",
          `team '${selection.team}' acting path moved (literal ${selection.registryLocation} -> ${r.registryLocation})`);
      }
      const rootNow = realOrSelf(r.root);
      const locRealNow = realOrSelf(r.registryLocation);
      if (rootNow !== selection.rootReal || locRealNow !== selection.registryLocationReal) {
        throw new SelectorError(1, "team_moved", "tap doctor",
          `team '${selection.team}' moved (root ${selection.rootReal} -> ${rootNow}; registry ${selection.registryLocationReal} -> ${locRealNow})`);
      }
    } else if (snap.marker === "live") {
      throw new SelectorError(1, "team_moved", "tap doctor",
        `team '${selection.team}' enrollment became live after a pre-flip pin`);
    }
  }

  assertActingRegistryMatches(selection);
}

function assertActingRegistryMatches(selection: Selection): void {
  let raw: unknown;
  try {
    raw = JSON.parse(pyReadUtf8(selection.registryLocation));
  } catch {
    throw new SelectorError(1, "team_moved", "tap doctor",
      `acting registry '${selection.registryLocation}' is gone or unreadable`);
  }
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) {
    throw new SelectorError(1, "team_moved", "tap doctor",
      `acting registry is present but malformed`);
  }
  const doc = raw as Record<string, unknown>;
  if (!("team" in doc) || doc.team === undefined) return;
  const team = doc.team;
  if (typeof team !== "object" || team === null || Array.isArray(team)) {
    throw new SelectorError(1, "team_moved", "tap doctor",
      `acting registry team identity is present but malformed`);
  }
  const t = team as Record<string, unknown>;
  if ("name" in t && t.name !== undefined) {
    if (typeof t.name !== "string") {
      throw new SelectorError(1, "team_moved", "tap doctor",
        `acting registry team.name is present but malformed`);
    }
    if (t.name !== selection.team) {
      throw new SelectorError(1, "team_moved", "tap doctor",
        `acting registry team.name '${t.name}' is not selection team '${selection.team}'`);
    }
  }
  if ("worktree_root" in t && t.worktree_root !== undefined && t.worktree_root !== "") {
    if (typeof t.worktree_root !== "string") {
      throw new SelectorError(1, "team_moved", "tap doctor",
        `acting registry worktree_root is present but malformed`);
    }
    if (realOrSelf(t.worktree_root) !== selection.rootReal) {
      throw new SelectorError(1, "team_moved", "tap doctor",
        `acting registry worktree_root '${t.worktree_root}' is not selection root '${selection.rootReal}'`);
    }
  }
}

/** Parent of a detached child compares the receipt against the pin it dispatched. */
export function validateChildSelection(parent: Selection, child: Selection): void {
  if (
    parent.team !== child.team
    || parent.rootReal !== child.rootReal
    || parent.registryLocation !== child.registryLocation
    || parent.registryLocationReal !== child.registryLocationReal
  ) {
    throw new SelectorError(1, "identity_mismatch", "pass --team or pin the child's cwd to the parent root",
      `child resolved team='${child.team}' root='${child.rootReal}' registry='${child.registryLocation}'; parent pinned team='${parent.team}' root='${parent.rootReal}' registry='${parent.registryLocation}'`);
  }
}

function requireMarker(indexHome?: string): FlipState {
  const marker = flipMarkerState(indexHome);
  if (marker === "invalid") {
    throw new SelectorError(1, "invalid_flip", "tap doctor",
      "registry flip marker is present but invalid; refusing rather than skipping a v0.20 obligation");
  }
  return marker;
}

function selectExplicitTeam(team: string, marker: FlipState, indexHome: string | undefined, env: NodeJS.ProcessEnv): Selection {
  if (!validToken(team) || team.includes("/")) {
    throw new SelectorError(1, "usage_error", "tap help",
      `--team '${team}' fails charset ^[A-Za-z0-9][A-Za-z0-9._-]*$`);
  }
  const bound = bindTeam(team, marker, indexHome, env);
  return { ...bound, source: "explicit-team", marker: marker === "live" ? "live" : "absent" };
}

function bindTeam(
  team: string,
  marker: FlipState,
  indexHome: string | undefined,
  env: NodeJS.ProcessEnv,
): Pick<Selection, "team" | "rootReal" | "registryLocation" | "registryLocationReal" | "busHome" | "busRule" | "authority"> {
  if (marker === "live") {
    const r = resolveTeamFromGlobal(globalRegistryPath(indexHome), team);
    if (r.status === "invalid") {
      throw new SelectorError(1, "invalid_flip", "tap doctor", r.detail || "global registry unreadable");
    }
    if (r.status === "historical") {
      throw new SelectorError(1, "historical_team", "tap doctor",
        `team '${team}' is historical (not delivery-addressable)`);
    }
    if (r.status === "missing") {
      throw new SelectorError(1, "unknown_team", "tap register",
        `--team '${team}' is not enrolled in the machine index`);
    }
    if (r.status === "unreachable" || !r.registryLocation || !readableFile(r.registryLocation)) {
      throw new SelectorError(1, "live_unreachable", "tap doctor",
        `acting registry for team '${team}' is unreachable`);
    }
    const rootReal = realOrSelf(r.root);
    const pin = actingPin(r.registryLocation);
    const busHome = busHomeForEnrolled(rootReal);
    return {
      team,
      rootReal,
      ...pin,
      busHome,
      busRule: busRuleForHome(busHome),
      authority: "enrolled",
    };
  }
  const enrolled = resolveEnrolledTeamRoot(team, indexHome);
  if (enrolled.kind === "invalid") {
    throw new SelectorError(1, "invalid_flip", "tap doctor",
      "registry flip marker is present but invalid; refusing rather than skipping a v0.20 obligation");
  }
  if (enrolled.kind === "not_authoritative") {
    throw new SelectorError(1, "live_unreachable", "tap doctor",
      `acting registry for team '${team}' is unreachable (${enrolled.status})`);
  }
  if (enrolled.kind !== "ok") {
    throw new SelectorError(1, "unknown_team", "tap register",
      `--team '${team}' is not enrolled in the machine index`);
  }
  const rootReal = realOrSelf(enrolled.root);
  const { home, rule } = resolveBus(rootReal, withoutTapHome(env));
  return {
    team,
    rootReal,
    ...actingPin(join(home, "registry.json")),
    busHome: home,
    busRule: rule,
    authority: "enrolled",
  };
}

function bindPinnedRoot(
  rootReal: string,
  marker: FlipState,
  indexHome: string | undefined,
  env: NodeJS.ProcessEnv,
): Selection {
  if (marker === "live") {
    const at = enrollmentAt(rootReal, indexHome);
    if (at.status === "invalid") {
      throw new SelectorError(1, "invalid_flip", "tap doctor",
        "registry flip marker is present but invalid; refusing rather than skipping a v0.20 obligation");
    }
    if (at.status === "ambiguous") {
      throw new SelectorError(1, "ambiguous_team", "tap doctor",
        `more than one enrolled team realpaths to '${rootReal}'`);
    }
    if (at.status === "unreachable") {
      throw new SelectorError(1, "live_unreachable", "tap doctor",
        `enrolled team '${at.name}' at '${rootReal}' has an unreachable acting registry`);
    }
    if (at.status !== "ok") {
      throw new SelectorError(1, "unanchored_bus", "pin an enrolled team root, or pass --team",
        `pinned root '${rootReal}' is not an enrolled team (no ancestor or TAP_HOME fallback)`);
    }
    const pin = actingPin(at.registryLocation);
    const busHome = busHomeForEnrolled(at.rootReal);
    return {
      team: at.name,
      rootReal: at.rootReal,
      ...pin,
      busHome,
      busRule: busRuleForHome(busHome),
      source: "pinned-root",
      marker: "live",
      authority: "enrolled",
    };
  }
  const { home, rule } = resolveBus(rootReal, withoutTapHome(env));
  const expected = containerRefusal(home);
  if (expected) {
    throw new SelectorError(1, "not_a_bus", "pin a readable enrolled root",
      `pinned root bus '${home}' does not name a bus; expected '${expected}'`);
  }
  const registryPath = join(home, "registry.json");
  return {
    team: teamNameFromActingFile(registryPath) || basename(rootReal),
    rootReal,
    ...actingPin(registryPath),
    busHome: home,
    busRule: rule,
    source: "pinned-root",
    marker: "absent",
    authority: "bus",
  };
}

function selectFromWalk(
  startReal: string,
  marker: FlipState,
  indexHome: string | undefined,
  env: NodeJS.ProcessEnv,
  source: SelectorSource,
): Selection {
  if (marker === "live") {
    const hit = nearestEnrollment(startReal, indexHome);
    if (hit) {
      const pin = actingPin(hit.registryLocation);
      const busHome = busHomeForEnrolled(hit.rootReal);
      return {
        team: hit.name,
        rootReal: hit.rootReal,
        ...pin,
        busHome,
        busRule: busRuleForHome(busHome),
        source,
        marker: "live",
        authority: "enrolled",
      };
    }
  }
  return tapHomeOrDefault(startReal, marker, indexHome, env);
}

function tapHomeOrDefault(
  startReal: string,
  marker: FlipState,
  indexHome: string | undefined,
  env: NodeJS.ProcessEnv,
): Selection {
  const homeEnv = env.TAP_HOME;
  if (homeEnv) {
    const { home, rule } = resolveBus(startReal, env);
    const expected = containerRefusal(home);
    if (expected) {
      throw new SelectorError(1, "not_a_bus", "unset TAP_HOME or point it at the bus dir",
        `TAP_HOME='${home}' does not name a bus; expected '${expected}'`);
    }
    const root = rule === "env" ? teamRootFromBus(home) : startReal;
    if (marker === "live") {
      const at = enrollmentAt(root, indexHome);
      if (at.status === "ok") {
        const pin = actingPin(at.registryLocation);
        const actingBus = busHomeForEnrolled(at.rootReal);
        if (realOrSelf(home) !== realOrSelf(actingBus)) {
          throw new SelectorError(1, "bus_not_acting", "unset TAP_HOME or point it at the team's acting bus",
            `TAP_HOME='${home}' is not the acting bus '${actingBus}' for enrolled team '${at.name}'`);
        }
        return {
          team: at.name,
          rootReal: at.rootReal,
          ...pin,
          busHome: actingBus,
          busRule: "env",
          source: "env",
          marker: "live",
          authority: "enrolled",
        };
      }
      if (at.status === "unreachable") {
        throw new SelectorError(1, "live_unreachable", "tap doctor",
          `TAP_HOME names enrolled team '${at.name}' whose acting registry is unreachable`);
      }
      if (at.status === "ambiguous") {
        throw new SelectorError(1, "ambiguous_team", "tap doctor",
          `TAP_HOME names a root with more than one enrolled team`);
      }
      if (at.status === "invalid") {
        throw new SelectorError(1, "invalid_flip", "tap doctor",
          "registry flip marker is present but invalid; refusing rather than skipping a v0.20 obligation");
      }
    }
    const registryPath = join(home, "registry.json");
    const team = teamNameFromActingFile(registryPath) || basename(realOrSelf(root));
    return {
      team,
      rootReal: realOrSelf(root),
      ...actingPin(registryPath),
      busHome: home,
      busRule: rule,
      source: "env",
      marker: marker === "live" ? "live" : "absent",
      authority: "bus",
    };
  }

  const busRoot = repoRoot(startReal);
  const { home, rule } = resolveBus(busRoot, withoutTapHome(env));
  const expected = containerRefusal(home);
  if (expected) {
    throw new SelectorError(1, "not_a_bus", "unset TAP_HOME or point it at the bus dir",
      `resolved bus '${home}' does not name a bus; expected '${expected}'`);
  }
  const registryPath = join(home, "registry.json");
  const rootReal = realOrSelf(busRoot);
  if (marker === "live") {
    if (!readableFile(registryPath)) {
      throw new SelectorError(1, "unanchored_bus", "pass --team <team>  OR  set TAP_HOME to the bus directory",
        `cwd-derived bus has no acting registry (${startReal})`);
    }
    return {
      team: teamNameFromActingFile(registryPath) || basename(rootReal),
      rootReal,
      ...actingPin(registryPath),
      busHome: home,
      busRule: rule,
      source: "cwd",
      marker: "live",
      authority: "bus",
    };
  }
  return {
    team: teamNameFromActingFile(registryPath) || basename(rootReal),
    rootReal,
    ...actingPin(registryPath),
    busHome: home,
    busRule: rule,
    source: "cwd",
    marker: "absent",
    authority: "bus",
  };
}

function canonicalDir(path: string, kind: "cwd" | "pinned_root"): string {
  const action = kind === "cwd" ? "cd to a readable enrolled directory" : "pin a readable enrolled root";
  const unreachable = (detail: string) =>
    new SelectorError(1, "cwd_unreachable", action, detail);
  const proveUsable = (p: string): { dev: number; ino: number } => {
    const st = statSync(p);
    if (!st.isDirectory()) throw unreachable(`${kind} '${path}' is not a directory`);
    accessSync(p, constants.R_OK | constants.X_OK);
    return { dev: st.dev, ino: st.ino };
  };
  try {
    let real: string;
    try {
      real = realpathSync(path);
    } catch (error) {
      if ((error as NodeJS.ErrnoException)?.code !== "ENOENT") throw error;
      // Bun 1.4's realpathSync throws ENOENT for an existing directory whose
      // path carries a backslash (tap-e05cw), so every verb would refuse
      // cwd_unreachable where Bash resolves. Recover the physical path through
      // the native platform — after proving the input is a real, readable,
      // searchable directory, and before trusting that the result names the
      // same directory by dev/ino and is itself readable/searchable.
      const input = proveUsable(path);
      real = nativePhysicalPath(path);
      const physical = proveUsable(real);
      if (physical.dev !== input.dev || physical.ino !== input.ino) {
        throw unreachable(`${kind} '${path}' does not match its physical path '${real}'`);
      }
    }
    proveUsable(real);
    return real;
  } catch (error) {
    if (error instanceof SelectorError) throw error;
    throw unreachable(`${kind} '${path}' is deleted or unreadable`);
  }
}

/** Physical path per the native platform when Bun's own realpath throws ENOENT. */
function nativePhysicalPath(path: string): string {
  const probe = spawnSync("/bin/pwd", ["-P"], {
    cwd: path,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "ignore"],
  });
  const out = probe.status === 0 ? probe.stdout.trim() : "";
  if (!out.startsWith("/")) {
    throw new Error(`native pwd -P failed for '${path}'`);
  }
  return out;
}

function ancestors(start: string, stop?: string): string[] {
  const out: string[] = [];
  let dir = start;
  while (dir) {
    out.push(dir);
    if (dir === stop) break;
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return out;
}

export function busHomeForEnrolled(rootReal: string): string {
  rootReal = realOrSelf(rootReal);
  // CONTRACT: the enrolled bus belongs to the root, not registry_location.
  const dot = join(rootReal, ".tap", "bus");
  const legacy = join(rootReal, "tmp", "tap");
  if (isDir(dot)) return realOrSelf(dot);
  if (isDir(legacy)) return realOrSelf(legacy);
  return dot;
}

function busRuleForHome(home: string): BusRule {
  const p = realOrSelf(home);
  if (p.endsWith("/.tap/bus")) return "dotdir";
  if (p.endsWith("/tmp/tap")) return "legacy";
  return "default";
}

function teamRootFromBus(busHome: string): string {
  const parent = realOrSelf(dirname(busHome));
  const base = basename(parent);
  return base === ".tap" || base === "tmp" ? dirname(parent) : parent;
}

export function teamNameFromActingFile(registryPath: string): string {
  try {
    const doc = JSON.parse(pyReadUtf8(registryPath)) as Record<string, unknown>;
    const t = doc.team;
    if (typeof t !== "object" || t === null) return "";
    const name = (t as Record<string, unknown>).name;
    return typeof name === "string" ? name : "";
  } catch {
    return "";
  }
}

function withoutTapHome(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv {
  const next = { ...env };
  delete next.TAP_HOME;
  return next;
}

function readableFile(p: string): boolean {
  try {
    accessSync(p, constants.R_OK);
    return statSync(p).isFile();
  } catch {
    return false;
  }
}

function isDir(p: string): boolean {
  try {
    return statSync(p).isDirectory();
  } catch {
    return false;
  }
}

function realOrSelf(p: string): string {
  try {
    return realpathSync(p);
  } catch {
    return p;
  }
}

/** Index/path literal for lock identity; canonical realpath for equality only. */
function actingPin(literal: string): { registryLocation: string; registryLocationReal: string } {
  return {
    registryLocation: literal,
    registryLocationReal: readableFile(literal) ? realOrSelf(literal) : literal,
  };
}

function nearestEnrollment(
  startReal: string,
  indexHome?: string,
): Extract<ReturnType<typeof enrollmentAt>, { status: "ok" }> | undefined {
  const snap = loadGlobalRegistry(indexHome);
  if (snap.marker === "absent") return undefined;
  if (snap.marker === "invalid" || !snap.doc) {
    throw new SelectorError(1, "invalid_flip", "tap doctor",
      "registry flip marker is present but invalid; refusing rather than skipping a v0.20 obligation");
  }
  // A checkout owns its enrollment boundary, including nested linked worktrees.
  // Outside Git there is no checkout boundary, so retain the full ancestor walk.
  const git = spawnSync("git", ["-C", startReal, "rev-parse", "--show-toplevel"], { encoding: "utf8" });
  const stop = git.status === 0 ? realOrSelf(git.stdout.trim()) : undefined;
  const candidates = ancestors(startReal, stop);
  for (const dir of candidates) {
    const at = enrollmentAtFromDoc(snap.doc, dir);
    if (at.status === "invalid") {
      throw new SelectorError(1, "invalid_flip", "tap doctor",
        "registry flip marker is present but invalid; refusing rather than skipping a v0.20 obligation");
    }
    if (at.status === "ambiguous") {
      throw new SelectorError(1, "ambiguous_team", "tap doctor",
        `more than one enrolled team realpaths to '${dir}'`);
    }
    if (at.status === "unreachable") {
      throw new SelectorError(1, "live_unreachable", "tap doctor",
        `enrolled team '${at.name}' at '${dir}' has an unreachable acting registry`);
    }
    if (at.status === "ok") return at;
  }
  return undefined;
}
