import { existsSync, lstatSync, mkdirSync, readlinkSync, rmSync, statSync, symlinkSync } from "node:fs";
import { join } from "node:path";

/** The uninstall manifest owns the literal target, including dangling links. */
export function removeOwnedLink(path: string, target: string): string {
  try {
    if (!lstatSync(path).isSymbolicLink() || readlinkSync(path) !== target) return "preserved changed target";
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return "already missing";
    throw error;
  }
  rmSync(path);
  return "removed";
}

export function installSkillLinks(repo: string, label: string, home: string, skills: string[], retired: string[], local: string[], reapOnly = false): void {
  if (!existsSync(home) || !statSync(home).isDirectory()) {
    if (!reapOnly) console.log(`install: skipped ${label} — ${home} does not exist (no ${label} install detected)`);
    return;
  }
  const directory = join(home, "skills");
  if (reapOnly && (!existsSync(directory) || !statSync(directory).isDirectory())) return;
  if (!reapOnly) mkdirSync(directory, { recursive: true });
  for (const name of [...retired, ...local]) {
    const path = join(directory, name);
    let target: string;
    try { target = readlinkSync(path); } catch (error) {
      if (["ENOENT", "EINVAL"].includes((error as NodeJS.ErrnoException).code || "")) continue;
      throw error;
    }
    if (!target.startsWith(repo + "/")) {
      console.error(`install: left ${label} skill ${name} alone — not a link into ${repo}`);
      continue;
    }
    if (removeOwnedLink(path, target) !== "removed") continue;
    const reason = local.includes(name) ? "repo-local; machine-wide share removed — the skill still ships from any checkout of this repo" : "renamed; stale link removed";
    console.log(`install: unlinked retired ${label} skill ${name} (${reason})`);
  }
  if (reapOnly) return;
  for (const name of skills) {
    const path = join(directory, name), target = join(repo, "skills", name);
    let current: string | undefined;
    try {
      if (!lstatSync(path).isSymbolicLink()) {
        console.error(`install: skipped ${label} skill ${name} — ${path} exists and is not a symlink (refusing to replace)`);
        continue;
      }
      current = readlinkSync(path);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    }
    if (current !== target) {
      if (current !== undefined) removeOwnedLink(path, current);
      symlinkSync(target, path);
    }
    console.log(`install: linked ${label} skill ${path} -> ${target}`);
  }
}

if (import.meta.main) {
  const [mode, repo, label, home, ...args] = process.argv.slice(2);
  const groups: Record<string,string[]> = { "--skills": [], "--retired": [], "--repo-local": [] };
  let group: string | undefined;
  try {
    if (!["install", "reap"].includes(mode || "") || !repo || !label || !home) throw new Error("invalid skill-link arguments");
    for (const arg of args) {
      if (Object.hasOwn(groups, arg)) group = arg;
      else if (group && /^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(arg)) groups[group]!.push(arg);
      else throw new Error(`invalid skill-link argument: ${arg}`);
    }
    installSkillLinks(repo, label, home, groups["--skills"]!, groups["--retired"]!, groups["--repo-local"]!, mode === "reap");
  } catch (error) { console.error(`install: skill links failed: ${error}`); process.exitCode = 1; }
}
