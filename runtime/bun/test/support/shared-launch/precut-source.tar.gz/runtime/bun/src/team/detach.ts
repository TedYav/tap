import { requireActingRegistry, resolveContext, TapError, type ResolvedContext } from "../context";
import { renderRefusals, runEntry } from "../error-line";
import { validToken } from "../ids";
import { withActingRegistry } from "../registry-tx";
import { loadRegistry, seatMap } from "../registry";
import { ServerUnresponsive, tmux } from "../tmux";
import { isFile } from "../watch-lease";
import { crewSelectGate, noSelection, parseSelection, rosterGate, selectAny, selectConflictGate, selectSummary, selectTyped, spared, type Selection } from "./selection";

export interface DetachOptions { handle: string; selection: Selection }
const label = "tap team detach";
function fail(klass: string, detail: string, action = "tap help team detach"): never {
  throw new TapError(1, klass, action, detail, label);
}

export function parseDetachOptions(args: string[]): DetachOptions {
  const out = { handle: "", selection: noSelection() };
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === "--handle") {
      const value = args[++i];
      if (!value || !validToken(value)) fail("usage_error", "--handle needs one valid bare handle");
      out.handle = value;
    } else if (arg === "--only" || arg === "--except") {
      if (out.selection.mode && out.selection.mode !== arg) selectConflictGate("team detach");
      const value = args[++i];
      if (value === undefined) fail("usage_error", `${arg} was given no value`);
      out.selection = parseSelection("team detach", value, arg);
    } else fail(arg?.startsWith("--") ? "unknown_option" : "usage_error", `unexpected argument '${arg}'`);
  }
  if (out.handle && out.selection.mode === "--except") fail("usage_error", "--handle and --except are opposite selectors — pick one");
  if (out.handle && out.selection.mode === "--only") fail("usage_error", "--handle and --only both name the seats to act on — pass one of them",
    "tap team detach --only <h,...>   (--handle targets one row; --only is session-granular)");
  return out;
}

export function runTeamDetach(ctx: ResolvedContext, options: DetachOptions, run = tmux, write = (line: string) => console.log(line)): number {
  const { handle, selection } = options;
  requireActingRegistry(ctx, 1);
  const object = (value: unknown): value is Record<string, unknown> => value !== null && typeof value === "object" && !Array.isArray(value);
  let rows: ReturnType<typeof seatMap>;
  try { rows = seatMap(loadRegistry(ctx.registryPath)); }
  catch { return fail("registry_invalid", "acting registry unreadable", "tap doctor"); }
  const roster = Object.keys(rows).filter(h => object(rows[h])).sort();
  rosterGate("team detach", selection, roster);
  crewSelectGate("team detach", selection, ctx.registryPath);
  if (handle && (!Object.hasOwn(rows, handle) || !object(rows[handle]))) fail("not_found", `no registry row for '${handle}'`, "tap team");
  const groups = new Map<string, string[]>();
  const counts = { detached: 0, already_detached: 0, session_gone: 0, no_session: 0, excluded: 0 };
  for (const h of handle ? [handle] : roster) {
    const row = rows[h]!;
    const session = typeof row.session === "string" ? row.session : "";
    if (row.delivery === "poll" || !session) {
      const result = spared(h, selection) ? "excluded" : "no_session";
      counts[result]++; write(`${label}: ${h}  ${result}`);
    } else groups.set(session, [...(groups.get(session) ?? []), h]);
  }
  for (const [session, handles] of [...groups].sort(([a], [b]) => a.localeCompare(b))) {
    if (handles.some(h => spared(h, selection))) {
      counts.excluded++; write(`${label}: ${handles.join(",")}  session=${session}  excluded`); continue;
    }
    let result: "late_spared" | "session_gone" | "already_detached" | "detached";
    try {
      result = withActingRegistry(ctx, (doc, current) => {
        // Keep the lock through the tmux action: a spared co-tenant cannot join
        // between this reread and detach-client. --handle intentionally targets a row.
        // A registry deleted after planning rereads as {} rather than throwing
        // (loadRegistry's missing-file case) — a doc with no `team` is otherwise
        // legitimate (restore's own comment relies on that), so check the file's
        // actual presence rather than inferring deletion from a missing field.
        if (!isFile(ctx.registryPath)) fail("registry_invalid", `acting registry unreadable (session ${session})`, "tap doctor");
        if (Object.entries(current).some(([h, row]) => object(row) && row.session === session && spared(h, selection))) return "late_spared";
        if (run(["has-session", "-t", `=${session}`]).code !== 0) return "session_gone";
        const clients = run(["list-clients", "-t", `=${session}`, "-F", "#{client_tty}"]);
        if (clients.code !== 0) fail("tmux_error", `could not inspect clients of '${session}'`);
        if (!clients.stdout.trim()) return "already_detached";
        if (run(["detach-client", "-s", `=${session}`]).code !== 0) fail("tmux_error", `could not detach clients from session '${session}'`);
        return "detached";
      });
    } catch (error) {
      if (error instanceof TapError || error instanceof ServerUnresponsive) throw error;
      return fail("registry_invalid", `acting registry unreadable (session ${session})`, "tap doctor");
    }
    if (result === "late_spared") {
      counts.excluded++; write(`${label}: ${handles.join(",")}  session=${session}  excluded (late co-tenant joined after planning)`);
    } else {
      counts[result]++; write(`${label}: ${handles.join(",")}  session=${session}  ${result}`);
    }
  }
  const actionable = counts.detached + counts.already_detached + counts.session_gone;
  if (selectAny(selection) && counts.excluded && !actionable) write(`${label}: no seats matched after ${selectSummary(selection)}`);
  else if (selection.mode === "--only" && !counts.excluded) write(`${label}: --only ${selectTyped(selection)} matched every seat — none spared`);
  write(`${label}: ${Object.entries(counts).map(([key, count]) => `${key}=${count}`).join(" ")}`);
  return 0;
}

export function cmdTeamDetach(args: string[]): number {
  return renderRefusals(label, () => {
    const options = parseDetachOptions(args);
    return runTeamDetach(resolveContext(), options);
  });
}

if (import.meta.main) process.exitCode = runEntry(label, () => cmdTeamDetach(process.argv.slice(2)));
