// Per-entry scheduling only. The retained Bash drain owns every delivery decision.
import { lstatSync, statSync } from "node:fs";
import { join } from "node:path";
import { repoRoot, resolveBus } from "./bushome";
import { spoolTeamName } from "./context";
import { appendRegistryEventOrWarn } from "./events";
import { validId } from "./ids";
import { pythonInt } from "./pyint";
import { waiterScope } from "./slices/waiter-scope";
import { registryMatchesTeam } from "./spool-deadline";
import { heldSpoolClass } from "./spool-grace";
import { pyFloatString, pyReadUtf8, pyTruthy } from "./spool-publication";
import { reownClaim, reownRefresh, reownRelease } from "./spool-reown";
import { metaPath, payloadPath } from "./spool-sidecar";
import { scheduleProbe } from "./spool-state";
import { pendingReprobe } from "./submit-phase";
import { atLeast, BUN_FLOOR } from "./watch-run";

type Meta = Record<string, unknown>;
function readMeta(path: string): Meta | null {
  try {
    const value = JSON.parse(pyReadUtf8(path));
    return value && typeof value === "object" && !Array.isArray(value) ? value : null;
  } catch { return null; }
}
function isFile(path: string): boolean { try { return statSync(path).isFile(); } catch { return false; } }
function number(value: unknown): number {
  const n = typeof value === "string" ? pyFloatString(value)
    : typeof value === "number" || typeof value === "boolean" ? Number(value) : null;
  if (n === null || !Number.isFinite(n)) throw new Error("invalid time");
  return n;
}

/** Present unknown lifetime values never inherit deadline_source ownership. */
export function waiterDeadline(meta: Meta | null): number {
  if (!meta) return 0;
  const owned = Object.hasOwn(meta, "waiter_lifetime")
    ? ["readiness-gate", "autosettle-hold", "grace-window", "window"].includes(meta.waiter_lifetime as string)
    : ["readiness-gate", "autosettle-hold"].includes(meta.deadline_source as string);
  if (!owned || !pyTruthy(meta.deadline_epoch)) return 0;
  try {
    const value = meta.deadline_epoch;
    return typeof value === "string" ? Number(pythonInt(value, true) ?? 0n) : Math.trunc(number(value));
  } catch { return 0; }
}

/** Cadence truncated to the next drain boundary; unreadable facts retain cadence. */
export function deliveryWait(delay: number, meta: Meta | null, now: number): number {
  try {
    if (!meta) return delay;
    const deadline = number(meta.deadline_epoch);
    const boundaries = [deadline];
    if (now < deadline - 10) boundaries.push(deadline - 10);
    if (meta.hold_until_epoch != null && number(meta.hold_until_epoch) > now) boundaries.push(number(meta.hold_until_epoch));
    if (meta.policy === "polite") {
      const degrade = number(meta.first_spooled_epoch) + number(meta.timeout_seconds);
      if (degrade > now) boundaries.push(degrade);
    }
    return Math.max(0, Math.min(delay, Math.min(...boundaries) - now));
  } catch { return delay; }
}

export async function runWaiter(input: {
  argv: string[]; scriptsDir: string; env?: NodeJS.ProcessEnv;
  refresh: (last: string, remaining: string[], token: string) => { status: number } | null;
}): Promise<number> {
  const env = { ...(input.env ?? process.env) };
  const [id, ...args] = input.argv;
  if (!id || !validId(id)) { process.stderr.write("tap spool waiter: valid id required\n"); return 2; }
  const home = resolveBus(repoRoot(), env).home;
  env.TAP_HOME = home;
  const spool = join(home, "spool"), meta = metaPath(spool, id), payload = payloadPath(spool, id);
  let token = env.TAP_SPOOL_REOWN_TOKEN || "";
  const release = () => { if (token) reownRelease(spool, id, token, env); };
  let engine: Bun.Subprocess | undefined, stopping = false;
  const handlers = (["SIGINT", "SIGTERM", "SIGHUP"] as const).map(signal => {
    const stop = () => {
      stopping = true;
      if (engine && engine.exitCode === null) {
        // Only this parent's live child group is stop authority. Include the shell's
        // foreground helpers; otherwise they can keep writing after the waiter exits.
        try { process.kill(-engine.pid, signal); } catch { /* raced child exit */ }
      } else { release(); process.exit(0); }
    };
    process.on(signal, stop);
    return [signal, stop] as const;
  });
  try {
    // Even an unsupported runtime or an entry gone before startup must release its inherited lease.
    if (!atLeast(Bun.version, BUN_FLOOR) || typeof process.execve !== "function") {
      process.stderr.write(`tap spool waiter: needs bun ${BUN_FLOOR} or newer (process.execve); this is ${Bun.version}\n`);
      return 1;
    }
    let resume = args[0] === "--resume-cadence";
    let last = resume ? args[1] ?? "" : "15";
    const remaining = resume ? args.slice(2) : (env.TAP_SPOOL_DELIVERER_DELAYS || "0.25 0.5 1 2 4 8 15").trim().split(/\s+/).filter(Boolean);
    for (const delay of [last, ...remaining]) {
      // Invalid cadence must fail instead of creating an immortal hot waiter.
      if (number(delay) < 0) throw new Error("negative cadence");
    }
    if (!isFile(payload)) return 0;
    const binding = readMeta(meta);
    const fields = [binding?.target ?? "", binding?.target_registry ?? "", binding?.to_team ?? ""];
    const wellFormed = binding !== null && fields.every(v => typeof v === "string" && !/[\x00-\x1f\x7f]/.test(v));
    const [target, registry, team] = fields as string[];
    const scope = wellFormed ? waiterScope({ target: target!, targetRegistry: registry!, registryMatchesTeam: registryMatchesTeam(registry!, team!) }) : null;
    if (!scope?.ok) {
      const reason = scope?.refusal ?? "slice_failed";
      process.stderr.write(`tap: waiter_scope_refused id=${id} reason=${reason}\n`);
      appendRegistryEventOrWarn("tap", { log: join(home, "registry-events.log"), actor: "courier", action: "waiter_scope_refused",
        handle: id, pane: "", team: spoolTeamName(home, join(home, "registry.json"), env.TAP_INDEX_HOME), detail: `reason=${reason}`, env });
      return 1;
    }
    const held = (): boolean => {
      const current = readMeta(meta);
      if (!current) return false;
      let possible = true;
      try { lstatSync(join(home, "receipts", `${id}.attempted`)); }
      catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") possible = false; }
      return heldSpoolClass(current, possible, typeof current.id === "string" && !!current.id && pendingReprobe(home, current.id));
    };
    const helperNow = () => env.TAP_SPOOL_NOW && /^[0-9]+$/.test(env.TAP_SPOOL_NOW) ? Number(env.TAP_SPOOL_NOW) : Date.now() / 1000;
    if (held()) {
      if (token) { if (!reownRefresh(spool, id, token, helperNow(), env)) return 0; }
      else { token = reownClaim(spool, id, env.TAP_SPOOL_REOWN_LEASE_SECONDS || "20", helperNow(), env) || ""; if (!token) return 0; }
    }
    while (isFile(payload)) {
      const delayText = resume ? last : remaining.shift() ?? last;
      last = delayText;
      const delay = number(delayText);
      const wait = resume ? 0 : deliveryWait(delay, readMeta(meta), Date.now() / 1000);
      resume = false;
      try { scheduleProbe(spool, id, String(wait), helperNow(), env); } catch { /* best effort, as before */ }
      if (wait > 0) await Bun.sleep(wait * 1000);
      const refreshed = input.refresh(last, remaining, token);
      if (refreshed) return refreshed.status;
      if (held() && token && !reownRefresh(spool, id, token, helperNow(), env)) return 0;
      const started = Math.floor(Date.now() / 1000);
      // Transport only: exactly one engine call per tick. All attempt/verify decisions stay in lib.sh.
      engine = Bun.spawn(["bash", "-c", 'set -euo pipefail; . "$1/lib.sh"; tap_spool_drain_once "" "" "$2" "$3" || exit $?',
        "tap-spool-waiter", input.scriptsDir, scope.target, scope.targetRegistry],
      { env, detached: true, stdin: "inherit", stdout: "inherit", stderr: "inherit" });
      const rc = await engine.exited;
      engine = undefined;
      if (stopping) return 0;
      if (rc === 1) return 1;
      if (!isFile(payload)) return rc === 5 ? 5 : 0;
      const current = readMeta(meta);
      if (current && pyTruthy(current.escalated_at)) return 0;
      const deadline = waiterDeadline(current);
      if (deadline !== 0 && Math.floor(Date.now() / 1000) >= deadline) {
        // A drain that crossed expiry still owes one post-expiry tick. Reuse this cadence
        // value, refresh again, and let that tick be the final boundary observation.
        if (started < deadline) { resume = true; continue; }
        await Bun.sleep(delay * 1000);
      }
      if (deadline === 0 && remaining.length === 0) return 0;
    }
    return 0;
  } finally {
    for (const [signal, stop] of handlers) process.off(signal, stop);
    release();
  }
}
