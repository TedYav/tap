import { spawnSync, type SpawnSyncReturns, type SpawnSyncOptionsWithStringEncoding } from "node:child_process";
import { resolve } from "node:path";
import type { RecoveryTarget } from "./state";

export interface IdentityGuardEvidence {
  outcome: "authorized" | "timeout" | "signal" | "spawn-error" | "refused";
  status: number | null; signal: string | null; errorCode: string | null;
  durationMs: number; stderr: string; stderrTruncated: boolean;
}
type Execute = (command: string, args: string[], options: SpawnSyncOptionsWithStringEncoding) => SpawnSyncReturns<string>;
const scripts = resolve(import.meta.dir, "../../../../skills/tap/scripts");
/** Fixed source and argv data. Evidence contains no argv, environment or stdout. */
export function checkIdentityGuard(target: RecoveryTarget, record?: (e: IdentityGuardEvidence) => void, execute: Execute = spawnSync): string | null {
  const started = performance.now();
  const result = execute("bash", ["-c", '. "$1/lib.sh"; shift; tap_submit_identity_guard "$@"', "recovery-identity",
    scripts, target.registry, target.handle, target.pane, target.paneId], { encoding: "utf8", timeout: 10_000, maxBuffer: 16_384 });
  const raw = result.stderr || "";
  const cleaned = raw.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").replace(/[\x00-\x08\x0b-\x1f\x7f]/g, "");
  const errorCode = (result.error as NodeJS.ErrnoException | undefined)?.code || null;
  const evidence: IdentityGuardEvidence = {
    outcome: errorCode === "ETIMEDOUT" ? "timeout" : result.error ? "spawn-error" : result.signal ? "signal" : result.status === 0 ? "authorized" : "refused",
    status: result.status, signal: result.signal, errorCode, durationMs: Math.round(performance.now() - started),
    stderr: cleaned.slice(0, 1024), stderrTruncated: cleaned.length > 1024,
  };
  record?.(evidence);
  if (evidence.outcome === "authorized") return null;
  return `identity guard ${evidence.outcome}: status=${evidence.status ?? "null"} signal=${evidence.signal ?? "none"} error=${evidence.errorCode ?? "none"} duration_ms=${evidence.durationMs}${evidence.stderr ? `; ${evidence.stderr.trim()}` : ""}`;
}
