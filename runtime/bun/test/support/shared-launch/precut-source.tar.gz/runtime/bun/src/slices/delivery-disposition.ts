/** One policy for immediate delivery, draft warning, and queued-input holds. */
export type DeliveryBand = "bare" | "draft" | "queued" | "staged" | "busy" | "unobservable";
export interface DeliveryFacts {
  band: DeliveryBand;
  harness?: string;
  urgent: boolean;
  noSpool: boolean;
  recipientBound: boolean;
  siblingsQueued: number;
}
export interface DeliveryDisposition {
  action: "inject" | "park";
  parkReason: "pending-input" | "queued-input" | "window" | "no-input-prompt" | "booting" | null;
  graceSeconds: number | null;
  cue: { initialStyle: "green" | "red" | null; redAtSecondsBeforeDeadline: number | null };
}
export function deliveryDisposition(input: DeliveryFacts): DeliveryDisposition {
  const result: DeliveryDisposition = {
    action: "inject", parkReason: null, graceSeconds: null,
    cue: { initialStyle: null, redAtSecondsBeforeDeadline: null },
  };
  if (!input.recipientBound || input.noSpool) return result;
  // Interrupt keeps its existing direct path, including queued siblings or a
  // missing composer. Only a positively observed human draft earns a red cue.
  if (input.urgent) return { ...result, graceSeconds: input.band === "draft" ? 0 : null,
    cue: { initialStyle: input.band === "draft" ? "red" : null, redAtSecondsBeforeDeadline: null } };
  // Hermes supplies its own safe /queue prefix without requiring a visible band.
  if (input.harness?.startsWith("hermes") && input.band === "unobservable") return result;
  if (input.band === "bare" && input.siblingsQueued === 0) return result;
  if (input.band === "draft") return {
    ...result, action: "park", parkReason: "pending-input", graceSeconds: 30,
    cue: { initialStyle: "green", redAtSecondsBeforeDeadline: 10 },
  };
  if (input.band === "staged") return { ...result, action: "park", parkReason: "no-input-prompt", graceSeconds: 0 };
  if (input.band === "queued") return { ...result, action: "park", parkReason: "queued-input" };
  if (input.band === "bare") return { ...result, action: "park", parkReason: "window" };
  return { ...result, action: "park", parkReason: input.harness?.startsWith("opencode") ? "booting" : "no-input-prompt" };
}

/** A footer advertises an action; only actual queued rows establish a queue. */
export function codexQueuedRows(frame: string): string[] {
  const lines = frame.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").split("\n");
  let prompt = -1;
  for (let i = lines.length - 1; i >= 0; i--) if (/^\s*[›❯»]/.test(lines[i]!)) { prompt = i; break; }
  if (prompt < 0 || !lines.slice(prompt + 1).some(line => /^\s*shift\s*\+\s*←\s+edit last queued message\s*$/.test(line))) return [];
  const queued: string[] = [];
  for (let i = prompt - 1; i >= 0; i--) {
    const line = lines[i]!;
    if (!line.trim() || /^\s*─{10,}\s*$/.test(line)) continue;
    const row = /^\s*↳\s+(.+)$/.exec(line);
    if (!row) break;
    queued.unshift(row[1]!);
  }
  return queued;
}

export function deliveryBand(composer: string | null, harness: string, frame: string): DeliveryBand {
  if (composer === null) return "unobservable";
  if (composer.trim()) return composer.trim().startsWith("[[TAP") ? "staged" : "draft";
  return /^codex/.test(harness) && codexQueuedRows(frame).length ? "queued" : "bare";
}

if (import.meta.main) {
  try {
    const facts = JSON.parse(await Bun.stdin.text()) as DeliveryFacts & { composer?: string | null; harness?: string; frame?: string };
    if ("composer" in facts) facts.band = deliveryBand(facts.composer ?? null, facts.harness ?? "", facts.frame ?? "");
    if (!["bare", "draft", "queued", "staged", "busy", "unobservable"].includes(facts.band)
      || ![facts.urgent, facts.noSpool, facts.recipientBound].every(v => typeof v === "boolean")
      || !Number.isInteger(facts.siblingsQueued) || facts.siblingsQueued < 0) throw new Error("invalid delivery facts");
    console.log(JSON.stringify({ band: facts.band, ...deliveryDisposition(facts) }));
  } catch (error) { console.error(String(error)); process.exit(2); }
}
