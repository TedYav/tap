import { applyOverrides, type Overrides } from "./overrides";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { TapError } from "../context";
import { loadGlobalRegistry } from "../index-home";
import { observe, observedRows, type RegistryRow } from "../verbs/team";
import { tmuxReadOnly } from "../tmux";

const scripts = resolve(import.meta.dir, "../../../../skills/tap/scripts");
const object = (v: unknown): v is Record<string, any> => !!v && typeof v === "object" && !Array.isArray(v);
export interface Options { seat?: string; harness?: string; team?: string; message?: string; json: boolean; dryRun: boolean; overrides?: Overrides }
export interface Exclusion { team: string; handle: string; reason: string }
export interface Member { team: string; handle: string; root: string; team_doc: Record<string, unknown>; row: Record<string, any>; expect?: unknown; expect_resume?: unknown; prepare_error?: string }
export interface BridgeResult { code?: number; reason?: string; stdout?: string; stderr?: string; elapsed?: number; members?: Member[]; team?: string; caller_pane?: string }
export function parseOptions(argv: string[]): Options {
  const out: Options = { json: process.env.TAP_JSON === "1", dryRun: false };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!;
    if (arg === "--") {
      (out.overrides ??= {}).argv = argv.slice(i + 1);
      break;
    }
    if (arg === "--json") out.json = true;
    else if (arg === "--dry-run") out.dryRun = true;
    else if (["--harness", "--team", "-m", "--message", "--env", "--unset-env"].includes(arg.split("=")[0]!)) {
      const key = arg.split("=")[0]!;
      const value = arg.includes("=") ? arg.slice(arg.indexOf("=") + 1) : argv[++i];
      if (value === undefined) throw new Error(`${key} needs a value`);
      if (key === "--env" || key === "--unset-env") {
        const field = key === "--env" ? "env" : "unset_env";
        ((out.overrides ??= {})[field] ??= []).push(value);
      } else if (key === "--harness") out.harness = value;
      else if (key === "--team") out.team = value.trim();
      else out.message = value;
    } else if (!arg.startsWith("-") && !out.seat) out.seat = arg;
    else throw new Error(`unexpected argument ${arg}`);
  }
  if (!!out.seat === !!out.harness) throw new Error("supply a team/handle OR --harness <claude|codex|cursor|opencode>");
  if (out.harness && !["claude", "codex", "cursor", "opencode"].includes(out.harness)) throw new Error("unsupported relaunch harness");
  if (out.team === "") throw new Error("empty --team refuses; use a team name or '*' for all teams");
  if (out.seat && (!/^[^/\s]+(?:\/[^/\s]+)?$/.test(out.seat) || out.team !== undefined)) throw new Error("single-seat relaunch requires [team/]handle without --team");
  if (out.overrides) applyOverrides({}, out.overrides);
  return out;
}

async function bridge(request: Record<string, unknown>): Promise<BridgeResult> {
  const child = Bun.spawn(["python3", "-B", resolve(scripts, "session/relaunch_bridge.py")], {
    stdin: "pipe", stdout: "pipe", stderr: "pipe", env: { ...process.env, TAP_JSON: "0", TAP_VERBOSE: "0" },
  });
  child.stdin.write(JSON.stringify(request));
  child.stdin.end();
  const [stdout, stderr, code] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited]);
  if (code !== 0) return { code: code || 1, reason: "replacement worker failed", stdout, stderr };
  try { return JSON.parse(stdout); }
  catch { return { code: 1, reason: "invalid replacement receipt", stdout, stderr }; }
}

/** One authority snapshot; unreadable teams remain visible in the structured receipt. */
export function census(options: Options, scope: string, teams: Record<string, unknown>, read = (path: string) => JSON.parse(readFileSync(path, "utf8"))): { members: Member[]; skipped_teams: Exclusion[]; excluded_inactive: Exclusion[] } {
  const members: Member[] = [], skipped_teams: Exclusion[] = [], excluded_inactive: Exclusion[] = [];
  const target = options.seat?.split("/");
  if (scope !== "*" && !Object.hasOwn(teams, scope)) throw new Error(`team '${scope}' is not enrolled`);
  for (const [team, enrollment] of Object.entries(teams).sort(([a], [b]) => a.localeCompare(b))) {
    if (scope !== "*" && team !== scope) continue;
    const skip = (reason: string) => skipped_teams.push({ team, handle: "*", reason });
    if (!object(enrollment)) { skip("invalid enrollment"); continue; }
    if (enrollment.state === "historical") { skip("historical team"); continue; }
    if (typeof enrollment.registry_location !== "string" || typeof enrollment.root !== "string") { skip("missing registry location or root"); continue; }
    let doc;
    try { doc = read(enrollment.registry_location); }
    catch (error) { skip(`registry unreadable: ${String(error)}`); continue; }
    const seats = object(doc) && (object(doc.seats) ? doc.seats : doc.agents);
    if (!object(seats)) { skip("registry has no seats/agents map"); continue; }
    for (const [handle, row] of Object.entries(seats).sort(([a], [b]) => a.localeCompare(b))) {
      if (target && handle !== target[1]) continue;
      const exclude = (reason: string) => excluded_inactive.push({ team, handle, reason });
      if (!object(row)) { exclude("invalid seat row"); continue; }
      if (typeof row.harness !== "string" || !row.harness) { exclude("unknown harness"); continue; }
      if (options.harness && row.harness !== options.harness) { exclude("harness mismatch"); continue; }
      if ((row.crew === true || row.crew === 1)) { exclude("crew"); continue; }
      if (row.delivery === "poll") { exclude("poll"); continue; }
      members.push({ team, handle, row, root: enrollment.root, team_doc: object(doc.team) ? doc.team : {} });
    }
    if (target && !Object.hasOwn(seats, target[1]!)) throw new TapError(1, "unknown_seat", `tap team roster ${team}`, `seat '${options.seat}' is not registered`);
  }
  return { members, skipped_teams, excluded_inactive };
}

/** Exactly the roster observation and socket-namespace policy, without preset/UI work. */
export function classify(members: Member[], diagnostics: string[]): { member: Member; status: string; reason: string; pane: string }[] {
  const rows = members.map((m, i) => ({ ...m.row, team: m.team, handle: String(i),
    status: m.row.status ?? "active", delivery: m.row.delivery || "pane" } as RegistryRow));
  if (!rows.length) return [];
  const observation = observe(rows, scripts, false, text => diagnostics.push(text));
  if (observation.code !== 0) throw new Error("seat classifier failed; run tap doctor");
  const socket = rows.some(row => row.server_socket) ? tmuxReadOnly(["display-message", "-p", "#{socket_path}"]) : null;
  const currentSocket = socket?.code === 0 && socket.stdout.trim().startsWith("/") ? socket.stdout.trim() : "";
  return observedRows(rows, observation.rows, observation.serverEpoch, {}, currentSocket).map(row => ({
    member: members[Number(row.handle)]!, status: row.status, reason: row.statusReason, pane: row.observedPaneId,
  }));
}

// .149's file-only lifecycleDiagnostic seam will consume these same structured
// receipts when that tier lands. Keep JSON complete independently of the logger.
const diagnostic = (_event: string, _fields: Record<string, unknown>): void => {};
const short = (text: string) => text.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").replace(/[\r\n\x00-\x1f\x7f]+/g, " ").trim().slice(0, 140);
export async function relaunch(options: Options, deps = { bridge, classify, load: loadGlobalRegistry, write: (text: string) => { process.stdout.write(text); }, color: !!process.stdout.isTTY }): Promise<number> {
  const context = await deps.bridge({ op: "context" });
  if (context.code) throw new Error(context.reason || "cannot resolve caller");
  if (options.seat && !options.seat.includes("/")) {
    if (!context.team) throw new Error("current team unresolved; pass team/handle");
    options = { ...options, seat: `${context.team}/${options.seat}` };
  }
  const scope = options.seat?.split("/")[0] ?? options.team ?? context.team;
  if (!scope) throw new Error("current team unresolved; pass --team <name> or --team='*'");
  const global = deps.load();
  if (global.marker !== "live") throw new Error("global registry unreadable; run tap doctor");
  const data = census(options, scope, (global.doc?.teams ?? {}) as Record<string, unknown>);
  const diagnostics: unknown[] = [context];
  const classifierDiagnostics: string[] = [];
  const selected: Member[] = [];
  const excluded_caller: Exclusion[] = [];
  for (const observed of deps.classify(data.members, classifierDiagnostics)) {
    const { team, handle } = observed.member;
    if (observed.status !== "active") data.excluded_inactive.push({ team, handle, reason: observed.reason || observed.status });
    else if (context.caller_pane && observed.pane === context.caller_pane) excluded_caller.push({ team, handle, reason: "caller-pane" });
    else selected.push(observed.member);
  }
  diagnostics.push(...classifierDiagnostics);
  const label = options.harness ? `${options.harness} seats` : "seats";
  const where = scope === "*" ? "on all teams" : `on team ${short(scope)}`;
  if (!options.json) deps.write(selected.length
    ? `${options.dryRun ? "Would relaunch" : "Relaunching"} ${selected.length} active ${label} ${where}\n`
    : `No active ${label} ${where}; nothing to relaunch.\n`);
  const prepared = selected.length ? await deps.bridge({ op: "prepare", members: selected }) : { members: [] };
  diagnostics.push({ ...prepared, members: undefined });
  // Finish the census's resume identities before any replacement starts. The
  // worker binds these exact expectations to its existing locked effect guard.
  const runMember = async (member: Member, i: number) => {
    let result: BridgeResult;
    try {
      result = prepared.code || !prepared.members?.[i] || prepared.members[i]?.prepare_error
        ? { code: 1, reason: prepared.members?.[i]?.prepare_error || prepared.reason || "resume census failed" }
        : await deps.bridge({ op: "run", member: prepared.members[i], message: options.message, dry_run: options.dryRun, overrides: options.overrides });
    } catch (error) { result = { code: 1, reason: String(error) }; }
    const code = result.code ?? 1;
    const errorLine = result.stderr?.trim().split("\n").findLast(line => line.startsWith("tap session relaunch:"));
    const reason = code === 0 ? "" : short(result.reason || errorLine || result.stderr || `exit ${code}; inspect the pane`);
    return { ...result, team: member.team, handle: member.handle, code, reason, status: code === 0 ? (options.dryRun ? "would-resume" : "resumed") : "failed" };
  };
  // Bound Python workers as the incumbent thread pool did; a large fleet must
  // not start one interpreter per row simultaneously.
  const results: Awaited<ReturnType<typeof runMember>>[] = [];
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(8, selected.length) }, async () => {
    while (next < selected.length) {
      const i = next++;
      results[i] = await runMember(selected[i]!, i);
    }
  }));
  for (const result of results) {
    if (!options.json) {
      const dot = deps.color && process.env.NO_COLOR === undefined && !options.dryRun ? `\x1b[${result.code === 0 ? 32 : 31}m●\x1b[0m` : "●";
      deps.write(`${dot} ${short(result.team)}/${short(result.handle)}${result.code === 0 ? "" : ` — ${short(result.reason || "replacement failed")}`}\n`);
    }
  }
  const code = results.some(result => result.code !== 0) ? 1 : 0;
  const receipt = { ok: code === 0, code, harness: options.harness ?? null, team: scope, dry_run: options.dryRun,
    candidates: selected.length, results, excluded_inactive: data.excluded_inactive, skipped_teams: data.skipped_teams,
    excluded_caller, counts: { candidates: selected.length, excluded_inactive: data.excluded_inactive.length,
      skipped_teams: data.skipped_teams.length, excluded_caller: excluded_caller.length }, diagnostics };
  diagnostic("relaunch", receipt);
  if (options.json) deps.write(JSON.stringify(receipt) + "\n");
  return code;
}

if (import.meta.main) {
  const argv = process.argv.slice(2);
  const ownArgv = argv.slice(0, argv.includes("--") ? argv.indexOf("--") : argv.length);
  if (ownArgv.some(arg => arg === "--help" || arg === "-h")) {
    console.log("tap session relaunch <[team/]handle>|--harness <claude|codex|cursor|opencode> [--team <name>|--team='*'] [-m <instruction>] [--env KEY=VALUE] [--unset-env KEY] [--dry-run] [--json] [-- harness-flags...]");
  } else {
    try { process.exitCode = await relaunch(parseOptions(argv)); }
    catch (error) {
      const detail = short(error instanceof TapError ? error.detail : String(error));
      const code = error instanceof TapError ? error.code : 2;
      const action = error instanceof TapError ? error.action : "tap help session";
      if (ownArgv.includes("--json") || process.env.TAP_JSON === "1") console.log(JSON.stringify({ ok: false, code, error_class: error instanceof TapError ? error.errorClass : "session_error", detail, action }));
      else console.error(`tap session relaunch: ${detail}; next: ${action}`);
      process.exitCode = code;
    }
  }
}
