/*
 * Agent-state rule mechanics and selected rule data are adapted from Herdr
 * 4a3b04f59ba3b7d8a15cea187b23e1e80c343b0c, licensed Apache-2.0.
 *
 * TAP modifications: rewritten in TypeScript; fixed to bundled screen rules
 * and a Codex pane-title working signal; removed remote updates, manifests,
 * and temporal fallback; added TAP harness aliases and fail-closed unknown
 * results. See
 * runtime/bun/third_party/herdr/README.md for provenance.
 */

import { codexPlaceholder } from "./terminal-text";

const CODEX_QUEUED_MESSAGES = /(?:^|\n)([•*] Messages to be submitted after next tool call \(press esc to\s+interrupt and send immediately\)\n(?:[ \t]+↳[^\n]*(?:\n[ \t]{4,}[^\n]*)*\n)+)[ \t\n\u2800-\u28ff]*$/;

export type AgentState = "working" | "blocked" | "idle" | "booting" | "unknown";

export interface AgentStateResult {
  agentState: AgentState;
  reason: string;
}

interface Gate {
  contains?: string[];
  regex?: RegExp[];
  lineRegex?: RegExp[];
  all?: Gate[];
  any?: Gate[];
  not?: Gate[];
}

type Region =
  | { kind: "bottom_non_empty_lines"; count: number }
  | { kind: "last_non_empty_line" }
  | { kind: "claude_live_input" }
  | { kind: "claude_live_footer" }
  | { kind: "claude_live_modal" }
  | { kind: "codex_live_composer" }
  | { kind: "codex_before_composer" }
  | { kind: "cursor_live_composer" }
  | { kind: "cursor_live_modal" }
  | { kind: "opencode_live_input" }
  | { kind: "opencode_live_modal" }
  | { kind: "agy_live_input" }
  | { kind: "agy_live_modal" }
  | { kind: "hermes_live_input" }
  | { kind: "hermes_live_modal" };

interface Rule extends Gate {
  id: string;
  state: Exclude<AgentState, "unknown">;
  priority: number;
  region: Region;
}

type Harness = "claude" | "codex" | "cursor" | "opencode" | "agy" | "hermes";

const tail = (count: number): Region => ({ kind: "bottom_non_empty_lines", count });
const live = (kind: Exclude<Region["kind"], "bottom_non_empty_lines">): Region => ({ kind });

const RULES: Record<Harness, Rule[]> = {
  claude: [
    {
      id: "permission_prompt",
      state: "blocked",
      priority: 900,
      region: live("claude_live_modal"),
      contains: ["do you want to proceed?"],
      all: [{ any: [{ contains: ["yes"] }, { contains: ["no"] }] }],
      not: [{ contains: ["conversation interrupted"] }],
    },
    {
      id: "interrupt_hint_working",
      state: "working",
      priority: 500,
      region: live("claude_live_footer"),
      lineRegex: [/esc to interrupt(?:\s|·|$)/i],
    },
    {
      id: "prompt_idle",
      state: "idle",
      priority: 100,
      region: live("claude_live_input"),
      lineRegex: [/^\s*❯(?:\s| |$)/],
    },
  ],
  codex: [
    {
      id: "screen_working",
      state: "working",
      priority: 200,
      region: live("codex_before_composer"),
      any: [
        { lineRegex: [/^\s*[•*]\s*Working\b.*esc to interrupt/] },
        { regex: [CODEX_QUEUED_MESSAGES] },
      ],
    },
    {
      id: "live_strong_blocker",
      state: "blocked",
      priority: 900,
      region: live("last_non_empty_line"),
      any: [
        { contains: ["press enter to confirm or esc to cancel"] },
        { contains: ["enter to submit answer"] },
        { contains: ["allow command?"] },
      ],
    },
    {
      id: "weak_blocker",
      state: "blocked",
      priority: 600,
      region: live("last_non_empty_line"),
      any: [
        { contains: ["[y/n]"] },
        { contains: ["yes (y)"] },
      ],
    },
    {
      id: "prompt_idle",
      state: "idle",
      priority: 100,
      region: live("codex_live_composer"),
      lineRegex: [/^\s*[›❯»](?:\s|$)/],
    },
  ],
  cursor: [
    {
      id: "approval_prompt",
      state: "blocked",
      priority: 300,
      region: live("cursor_live_modal"),
      contains: ["waiting for approval"],
      any: [
        { contains: ["run this command?"] },
        { contains: ["skip (esc or n)"] },
      ],
    },
    {
      id: "stop_hint_working",
      state: "working",
      priority: 100,
      region: live("cursor_live_composer"),
      contains: ["ctrl+c to stop"],
    },
    {
      id: "prompt_idle",
      state: "idle",
      priority: 50,
      region: live("cursor_live_composer"),
      lineRegex: [/^\s*→\s+(?:Add a follow-up|Plan, search, build anything)\s*$/],
    },
  ],
  opencode: [
    {
      id: "permission_required",
      state: "blocked",
      priority: 300,
      region: live("opencode_live_modal"),
      contains: ["permission required"],
      any: [
        { contains: ["enter confirm"] },
        { contains: ["enter submit"] },
        { contains: ["esc dismiss"] },
      ],
    },
    {
      id: "interrupt_hint_working",
      state: "working",
      priority: 110,
      region: live("opencode_live_input"),
      any: [
        { contains: ["esc interrupt"] },
        { contains: ["esc to interrupt"] },
        { regex: [/(?:■|⬝){4,}/] },
      ],
    },
    {
      id: "composer_idle",
      state: "idle",
      priority: 50,
      region: live("opencode_live_input"),
      contains: ["╹▀", "ctrl+p commands"],
      not: [{ contains: ["esc interrupt"] }, { contains: ["esc to interrupt"] }],
    },
  ],
  agy: [
    {
      id: "permission_prompt",
      state: "blocked",
      priority: 300,
      region: live("agy_live_modal"),
      contains: ["requesting permission for:"],
      any: [
        { contains: ["do you want to proceed?"] },
        { contains: ["tab amend"] },
      ],
    },
    {
      id: "generating_working",
      state: "working",
      priority: 100,
      region: live("agy_live_input"),
      any: [{ contains: ["generating"] }, { contains: ["esc to cancel"] }],
    },
    {
      id: "shortcuts_idle",
      state: "idle",
      priority: 50,
      region: live("agy_live_input"),
      contains: ["? for shortcuts"],
      not: [{ contains: ["generating"] }, { contains: ["esc to cancel"] }],
    },
  ],
  hermes: [
    {
      id: "dangerous_command_approval",
      state: "blocked",
      priority: 900,
      region: live("hermes_live_modal"),
      contains: ["dangerous"],
      all: [{
        any: [
          { contains: ["enter to confirm"] },
          { contains: ["allow once"] },
        ],
      }],
    },
    {
      id: "interrupt_status_working",
      state: "working",
      priority: 500,
      region: tail(2),
      any: [{ contains: ["msg=interrupt"] }, { contains: ["ctrl+c cancel"] }],
    },
    {
      id: "prompt_idle",
      state: "idle",
      priority: 50,
      region: live("hermes_live_input"),
      lineRegex: [/^\s*(?:[A-Za-z0-9._-]+\s+)?❯\s*$/],
    },
  ],
};

function normalizeHarness(value: string): Harness | null {
  const name = value.split("/").pop()?.toLowerCase() ?? "";
  const exact: Record<string, Harness> = {
    "claude-code": "claude",
    "cursor-agent": "cursor",
    "open-code": "opencode",
    antigravity: "agy",
    "antigravity-cli": "agy",
    "hermes-agent": "hermes",
  };
  if (exact[name]) return exact[name];
  for (const harness of Object.keys(RULES) as Harness[]) {
    if (name === harness || name.startsWith(`${harness}-`)) return harness;
  }
  return null;
}

function bottomNonEmptyLines(screen: string, count: number): string {
  const lines = screen.split("\n");
  let remaining = count;
  let start = lines.length;
  for (let i = lines.length - 1; i >= 0 && remaining > 0; i--) {
    if (lines[i]!.trim()) {
      start = i;
      remaining--;
    }
  }
  return start === lines.length ? "" : lines.slice(start).join("\n");
}

function bracketedRegion(screen: string, prompt: RegExp): { input: string; footer: string } | null {
  const lines = screen.split("\n");
  const isRule = (line: string): boolean => /^\s*─{10,}(?:\s+[^─\n]+\s+─+)?\s*$/u.test(line);
  let bottom = -1;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (!isRule(lines[i]!)) continue;
    if (bottom < 0) {
      bottom = i;
      continue;
    }
    let first = i + 1;
    while (first < bottom && !lines[first]!.trim()) first++;
    if (first < bottom && prompt.test(lines[first]!)) return { input: lines.slice(i).join("\n"), footer: lines.slice(bottom + 1).join("\n") };
    bottom = i;
  }
  return null;
}

function bracketedInput(screen: string, prompt: RegExp): string {
  return bracketedRegion(screen, prompt)?.input ?? "";
}

function codexLiveComposer(screen: string): string {
  const lines = screen.split("\n");
  const composer = /^\s*[›❯»]/;
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i]!.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "");
    if (!composer.test(line)) continue;
    // A painted placeholder proves empty input. Everything below it is UI,
    // including user-configurable or entirely absent status lines.
    return codexPlaceholder(lines[i]!) ? "› Ask Codex to do anything" : "";
  }
  return "";
}

function cursorLiveComposer(screen: string): string {
  const lines = screen.split("\n");
  const composer = /^\s*→\s+(?:Add a follow-up|Plan, search, build anything)(?:\s+ctrl\+c to stop)?\s*$/i;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (composer.test(lines[i]!)) return lines.slice(i).join("\n");
  }
  return "";
}

function opencodeLiveInput(screen: string): string {
  const lines = screen.split("\n");
  for (let i = lines.length - 1; i > 0; i--) {
    if (/^\s*╹▀/u.test(lines[i]!) && /^\s*┃/u.test(lines[i - 1]!)) {
      return lines.slice(i).join("\n");
    }
  }
  return "";
}

function modalWithoutInput(screen: string, input: string, footer: RegExp, lines: number = 6): string {
  if (input) return "";
  return footer.test(bottomNonEmptyLines(screen, 1)) ? bottomNonEmptyLines(screen, lines) : "";
}

function regionText(screen: string, region: Region): string {
  const raw = screen;
  screen = screen.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "");
  switch (region.kind) {
    case "bottom_non_empty_lines":
      return bottomNonEmptyLines(screen, region.count);
    case "last_non_empty_line":
      return bottomNonEmptyLines(screen, 1);
    case "claude_live_input":
      return bracketedInput(screen, /^\s*❯(?:\s| |$)/u);
    case "claude_live_footer": {
      const band = bracketedRegion(screen, /^\s*❯(?:\s| |$)/u);
      // Draft text is not a working hint; wrapped footer chrome may occupy three rows.
      return bottomNonEmptyLines(band ? band.footer : screen, 3);
    }
    case "claude_live_modal": {
      const footer = /esc to cancel.*tab to amend/i;
      const rows = screen.trimEnd().split("\n");
      let lastFooter = -1;
      for (let i = rows.length - 1; i >= 0; i--) if (footer.test(rows[i]!)) { lastFooter = i; break; }
      const tail = rows.slice(lastFooter + 1).filter(row => row.trim());
      const width = Math.max(0, ...rows.filter(row => /^\s*─{10,}\s*$/.test(row)).map(row => row.trim().length));
      let queued = lastFooter >= 0 && tail.length > 0;
      for (let i = 0; i < tail.length; i++) {
        const row = tail[i]!;
        if (/^\s*❯\s+\S/.test(row)) continue;
        // An unindented continuation must follow a full-width physical row;
        // otherwise arbitrary output after an old prompt is not a queue.
        if (i === 0 || /[❯›─]/.test(row) || !(width > 0 && tail[i - 1]!.length >= width)) queued = false;
      }
      const modal = queued ? rows.slice(0, lastFooter + 1).join("\n") : screen;
      return modalWithoutInput(modal, bracketedInput(modal, /^\s*❯(?:\s| |$)/u), footer, 15);
    }
    case "codex_live_composer":
      return codexLiveComposer(raw);
    case "codex_before_composer": {
      if (!codexLiveComposer(raw)) return "";
      const rows = screen.split("\n");
      const start = rows.findLastIndex(row => /^\s*[›❯»]/.test(row));
      // The painted hint establishes a live composer; quoted draft rows cannot.
      if (start < 0) return "";
      const before = rows.slice(0, start).join("\n");
      // A wrapped queue may hide the working row. Require the queue block to
      // reach this composer, with only animation/blank padding after its items.
      const queue = before.match(CODEX_QUEUED_MESSAGES);
      return queue?.[1] ?? bottomNonEmptyLines(before, 4);
    }
    case "cursor_live_composer":
      return cursorLiveComposer(screen);
    case "cursor_live_modal":
      return modalWithoutInput(screen, cursorLiveComposer(screen), /skip \(esc or n\)/i);
    case "opencode_live_input":
      return opencodeLiveInput(screen);
    case "opencode_live_modal":
      return modalWithoutInput(
        screen,
        opencodeLiveInput(screen),
        /enter (?:confirm|submit)|esc dismiss/i,
      );
    case "agy_live_input":
      return bracketedInput(screen, /^\s*>/);
    case "agy_live_modal":
      return modalWithoutInput(screen, bracketedInput(screen, /^\s*>/), /tab amend/i);
    case "hermes_live_input":
      return bracketedInput(screen, /^\s*(?:[A-Za-z0-9._-]+\s+)?❯(?:\s|$)/);
    case "hermes_live_modal":
      return modalWithoutInput(
        screen,
        bracketedInput(screen, /^\s*(?:[A-Za-z0-9._-]+\s+)?❯(?:\s|$)/),
        /enter to confirm|allow once/i,
      );
  }
}

function gateMatches(gate: Gate, text: string): boolean {
  const lower = text.toLowerCase();
  if (!(gate.contains ?? []).every((needle) => lower.includes(needle.toLowerCase()))) return false;
  if (!(gate.regex ?? []).every((regex) => regex.test(text))) return false;
  if (!(gate.lineRegex ?? []).every((regex) => text.split("\n").some((line) => regex.test(line)))) {
    return false;
  }
  if (!(gate.all ?? []).every((nested) => gateMatches(nested, text))) return false;
  if ((gate.any?.length ?? 0) > 0 && !gate.any!.some((nested) => gateMatches(nested, text))) {
    return false;
  }
  if ((gate.not ?? []).some((nested) => gateMatches(nested, text))) return false;
  return true;
}

export function detectAgentState(harnessName: string, screen: string, paneTitle = ""): AgentStateResult {
  const harness = normalizeHarness(harnessName);
  if (!harness) return { agentState: "unknown", reason: "unrecognized_harness" };

  let matched: Rule | null = null;
  for (const rule of RULES[harness]) {
    if (!gateMatches(rule, regionText(screen, rule.region))) continue;
    if (!matched || rule.priority > matched.priority) matched = rule;
  }
  // Permission dialogs remain blocked even if the last title still spins.
  if (harness === "codex" && matched?.state !== "blocked" && /^[\u2800-\u28ff]/u.test(paneTitle)) {
    return { agentState: "working", reason: "title_working" };
  }
  if (matched) return { agentState: matched.state, reason: matched.id };
  if (harness === "opencode" && !opencodeLiveInput(screen)) {
    return { agentState: "booting", reason: "input_band_absent" };
  }
  return { agentState: "unknown", reason: "no_matching_rule" };
}


// Bash activity observers reuse the roster reader; this is not input safety.
if (import.meta.main) {
  if (process.argv[2] !== "claude-seat-state") process.exit(2);
  console.log(detectAgentState("claude", await Bun.stdin.text()).agentState);
}

/** Human approval is a deliberate stop even when the harness process is healthy. */
export function approvalPrompt(harness: string, screen: string): boolean {
  if (!harness.startsWith("claude") && !harness.startsWith("codex")) return false;
  return detectAgentState(harness.startsWith("claude") ? "claude" : "codex", screen).agentState === "blocked";
}
