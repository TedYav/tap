import {harnessQueued,hasTerminalQueueReceipt} from "./harness-queue";
// Positive submission evidence only. These rows never authorize a retry.
import { closeSync, fsyncSync, mkdirSync, openSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { validId } from "./ids";
import { readRun } from "./recovery/state";

export type SubmitPhase = "injected-text-confirmed" | "Enter-intent" | "Enter-sent" | "verify-result";
export interface PhaseRow {
  v: 1; id: string; attempt: string; phase: SubmitPhase; at: string;
  recipient: string; enter_count: number; ordinal?: number; result?: string; recovery_id?: string;
}
const phases = new Set<SubmitPhase>(["injected-text-confirmed", "Enter-intent", "Enter-sent", "verify-result"]);
function phasePath(home: string, id: string): string {
  if (!validId(id)) throw new Error("invalid submission evidence id");
  return join(home, "receipts", `${id}.submit-phases.jsonl`);
}
export function recordPhase(home: string, row: Omit<PhaseRow, "v" | "at">): void {
  if (!row.attempt || !phases.has(row.phase) || !Number.isSafeInteger(row.enter_count) || row.enter_count < 0) throw new Error("invalid submission phase");
  let evidenceHome = home, recoveryId = row.recovery_id;
  if (process.env.TAP_RECOVERY_RUN) {
    const run = readRun(process.env.TAP_RECOVERY_RUN);
    const payload = run.submission?.id === row.id ? run.submission : run.payloads.find(p => p.id === row.id);
    if (payload && run.target.handle === row.recipient) { evidenceHome = payload.home; recoveryId = run.id; }
  }
  const path = phasePath(evidenceHome, row.id);
  mkdirSync(join(evidenceHome, "receipts"), { recursive: true });
  const fd = openSync(path, "a", 0o600);
  try { writeFileSync(fd, JSON.stringify({ ...row, recovery_id: recoveryId, v: 1, at: new Date().toISOString() }) + "\n"); fsyncSync(fd); }
  finally { closeSync(fd); }
  const dir = openSync(join(evidenceHome, "receipts"), "r");
  try { fsyncSync(dir); } finally { closeSync(dir); }
}
export function phaseRows(home: string, id: string): PhaseRow[] {
  let raw: string;
  try { raw = readFileSync(phasePath(home, id), "utf8"); } catch { return []; }
  const rows: PhaseRow[] = [];
  // A torn final row is not positive evidence. Preserve earlier complete rows.
  for (const line of raw.split("\n").slice(0, -1)) {
    try {
      const row = JSON.parse(line);
      if (row.v === 1 && row.id === id && typeof row.attempt === "string" && row.attempt &&
          phases.has(row.phase) && typeof row.recipient === "string" && Number.isSafeInteger(row.enter_count) && row.enter_count >= 0) rows.push(row);
    } catch { /* unknown row */ }
  }
  return rows;
}
export function pendingReprobe(home: string, id: string): boolean {
  if (!validId(id)) return false;
  let meta: unknown;
  try { meta = JSON.parse(readFileSync(join(home, "spool", `${id}.meta.json`), "utf8")); }
  catch { return false; }
  if (!meta || typeof meta !== "object" || Array.isArray(meta) || (meta as Record<string, unknown>).reason !== "pending-input") return false;
  const rows = phaseRows(home, id);
  const injected = rows.findLast(row => row.phase === "injected-text-confirmed");
  if (!injected) return false;
  const attempt = rows.filter(row => row.attempt === injected.attempt);
  const result = attempt.findLast(row => row.phase === "verify-result");
  if (result?.result !== "unverified" || result.enter_count !== 0) return false;
  return !attempt.some(row => row.phase === "Enter-intent" || row.phase === "Enter-sent");
}
export function unresolvedInjection(home: string, id: string): string | null {
  if (harnessQueued(home,id)) return "queued in harness; recipient processing unconfirmed";
  const rows = phaseRows(home, id);
  const injected = rows.findLast(row => row.phase === "injected-text-confirmed");
  if (!injected) return null;
  const result = rows.findLast(row => row.attempt === injected.attempt && row.phase === "verify-result");
  if (result?.result === "verified") return null;
  if (result?.result === "queued") return hasTerminalQueueReceipt(home,id) ? null : "queued in harness; recipient processing unconfirmed";
  // Canonical receipts from a later nudge/read supersede an unfinished attempt.
  for (const suffix of ["sent", "read", "done", "cancelled"]) {
    try { const receipt = JSON.parse(readFileSync(join(home, "receipts", `${id}.${suffix}`), "utf8"));
      if (receipt && typeof receipt === "object") return null;
    } catch { /* no positive settlement/delivery record */ }
  }
  if (pendingReprobe(home, id)) return "injected; Enter pending re-probe.";
  const recipient = /^[A-Za-z0-9_.-]+$/.test(injected.recipient) ? injected.recipient : "<seat>";
  return `injected; Enter unconfirmed (possible effect). If the sentinel is still staged, run tap nudge ${recipient}.`;
}
if (import.meta.main) {
  try {
    const args = Bun.argv.slice(2);
    if (args[0] === "reprobe-pending") {
      if (!args[1] || !args[2]) throw new Error("reprobe evidence arguments required");
      console.log(pendingReprobe(args[1], args[2]) ? "yes" : "no");
      process.exit(0);
    }
    const [home, id, attempt, phase, recipient = "", count = "0", ordinal, result] = args;
    if (!home || !id || !attempt || !phase) throw new Error("submission evidence arguments required");
    recordPhase(home, { id, attempt, phase: phase as SubmitPhase, recipient, enter_count: Number(count), ordinal: ordinal ? Number(ordinal) : undefined, result });
  } catch (error) { console.error(`tap: submission evidence unavailable: ${error}`); process.exitCode = 1; }
}
