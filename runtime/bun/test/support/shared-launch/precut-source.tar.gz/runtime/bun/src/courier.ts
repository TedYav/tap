import { archiveRows } from "./bus-archive-index";
import { recordedPermissions } from "./delivery-permissions";
import { recoverAgySurvey, SURVEY_EFFECTS, type SurveyEffects } from "./agy-survey";
import { recoveryHold } from "./recovery/state";
import { randomUUID } from "node:crypto";
import { recordPhase, type SubmitPhase } from "./submit-phase";
import { deliveryBand, deliveryDisposition, type DeliveryFacts, type DeliveryDisposition } from "./slices/delivery-disposition";
import { captureCourierFailure } from "./debug-capture";
import { beginDeliveryAttempt } from "./delivery-attempt";
// The courier: place the canonical, then submit-verify the sentinel into a real
// pane.
//
// TWO INVARIANTS THIS FILE EXISTS TO HOLD.
//
// 1. FAILED-SEND ATOMICITY. A caller must never see a terminal refusal while an
//    untracked payload from that send is outstanding. So: the pane check runs
//    BEFORE the canonical is placed (exit 3 leaves nothing), and stamping or
//    validation failure removes the staging file (exit 1 leaves nothing).
//
// 2. THE RECEIPT NEVER CLAIMS MORE THAN THE INSTRUMENT SAW. Submit-verify proves
//    the minted id left the input band. It does NOT prove a turn began — no
//    harness in the fleet exposes a post-submit turn-boundary token — so every
//    exit-0 send is stamped `turn=unconfirmed`, always, on every path.

import { existsSync, lstatSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";

import type { Bus } from "./bus";
import { stampEnvelope, stampEnvelopeBytes, validateEnvelope, type Routing } from "./envelope";
import { atomicWrite, jsonObj } from "./fsatomic";
import { renderSentinel } from "./sentinel";
import { acquireObligationLock, acquirePaneLock } from "./panelock";
import { observeProcessHarness, readProcessTable } from "./observe";
import { observeCopyMode, observeInputId, paneState, claudeFeedbackOverlay, type CopyModeObservation, type InputObservation, type PaneBand } from "./pane-state";
import { approvalPrompt } from "./agent-state";
import { bootId, bootIdsMatch, capturePane, injectText, inputHasId, observePaneResult, pressEnter, pressKeys, settle, type PaneObservation } from "./tmux";
import { observeSubmitFrame, agyPermissionOverlay, type SubmitFrame } from "./submit-frame";
import { flashPaneLocked } from "./spool-park-report";
import type { ClobberBackupReq, ClobberVerdict } from "./deliver";
import { inputBackupBody } from "./input-backup";
import { utcStamp } from "./ids";
import { loadRegistry, seatMap } from "./registry";
import { resetFenceRefusal } from "./reset";
import { DENYLIST } from "./verbs/team";
import { noticeExpiredAtSendDoor, readClearFence, type ClearFenceRead, type ClearFenceState } from "./clear-fence";

/**
 * Stamp into a private staging file on the SAME filesystem as payloads/, validate
 * the staged envelope, then rename into place. A half-written, zero-byte, or
 * validation-failed payload never appears in payloads/.
 */
export function canonicalPlace(bus: Bus, src: string, routing: Routing): void {
  const lock = acquireObligationLock(routing.id);
  if (!lock) {
    throw new Error(`canonical_place: obligation '${routing.id}' is busy; refusing to place without exclusive eligibility`);
  }
  try {
    canonicalPlaceLocked(bus, src, routing);
  } finally {
    lock.release();
  }
}

export function canonicalPlaceLocked(bus: Bus, src: string | Buffer, routing: Routing): void {
  const dest = bus.payloadPath(routing.id);
  if (existsSync(dest)) throw new Error(`canonical_place: refusing duplicate id '${routing.id}' (payload already exists)`);
  const archived = archiveRows(bus.home, true); // Publication must not reuse an id hidden by corrupt index data.
  // Placement owns an occupied-slot (`-e`) guard, broader than Bus.isDone's
  // settlement predicate (`-f`). A directory is not settlement, but it still
  // cannot license reuse of the same receipt address.
  if (existsSync(bus.donePath(routing.id)) || existsSync(bus.cancelPath(routing.id)) || archived.has(routing.id)) {
    throw new Error(`canonical_place: refusing duplicate id '${routing.id}' (receipt already settled)`);
  }

  mkdirSync(bus.stagingDir, { recursive: true });
  const staging = join(bus.stagingDir, `.tap.${process.pid.toString(36)}${Math.random().toString(36).slice(2, 8)}`);
  try {
    // A byte source (D1's staged body) keeps its body bytes verbatim; only the
    // header is text, and it is the header TEXT the stamp built that is
    // validated — validateEnvelope reads nothing past the closing fence, and a
    // lossy decode of the body would make the verdict about bytes never written.
    let stamped: string | Buffer;
    let validated: string;
    if (typeof src === "string") { stamped = stampEnvelope(src, routing); validated = stamped; }
    else { const out = stampEnvelopeBytes(src, routing); stamped = out.bytes; validated = out.header; }
    writeFileSync(staging, stamped, { mode: 0o600 });
    const v = validateEnvelope(validated);
    if (!v.ok) throw new Error(`canonical_place: envelope invalid after stamp: ${v.reason}`);
    renameSync(staging, dest);
  } catch (e) {
    rmSync(staging, { force: true });
    throw e;
  }
  writePlaced(bus, routing.id);
}

/**
 * Place-time courier attribution, written on EVERY successful rename — including
 * the submit-unverified paths that deliberately never reach `.sent`. This is the
 * authority for "this file is courier mail"; `.sent` is telemetry.
 */
export function writePlaced(bus: Bus, id: string): void {
  try {
    atomicWrite(bus.placedPath(id), `${jsonObj({ id, via: "courier", at: utcStamp() })}\n`);
  } catch {
    // Non-fatal: the payload is already on the bus. Poll LABELS an unattributed
    // payload rather than hiding it, so a missing receipt degrades to a warning
    // instead of losing mail.
    process.stderr.write(`tap: warning: placed receipt not written for ${id} (payload is on the bus; poll will label unattributed)\n`);
  }
}

export type SubmitResult =
  | { status: "injected" }
  | { status: "harness_queued" }
  /** A recovery effect was ready, but its required attempt receipt could not be admitted. */
  | { status: "attempt_evidence_unwritable"; detail: string }
  | { status: "pane_gone"; detail: string }
  | { status: "unverified"; detail: string; reprobePending?: boolean }
  /** The per-socket client budget was exhausted before a pane effect. */
  | { status: "rate_limited"; detail: string }
  /** No sentinel was injected. A bounded survey Skip may precede this hold. */
  | { status: "band_busy"; bandState?: "busy" | "queued" | "unobservable"; bandText?: string; disposition?: DeliveryDisposition; detail: string }
  /** `#{pane_in_mode}=1`. NO pane effect. Send queued/polls; owner uses observePaneKind. */
  | { status: "copy_mode"; cause: "copy-mode"; detail: string }
  /** Another submit holds this pane. NO pane effect was taken. */
  | { status: "lock_busy"; detail: string }
  | { status: "recovery_held"; detail: string }
  /** The live pane is not the seat we were addressing. NO pane effect taken. */
  | { status: "identity_mismatch"; detail: string }
  /** Reset fence appeared after placement. NO pane effect taken. */
  | { status: "team_reset_fenced"; detail: string; action: string }
  /** Clear fence appeared after placement. NO pane effect taken; canonical stays. */
  | { status: "clearing"; detail: string };

/**
 * Inject the sentinel and verify the minted id leaves the input band.
 *
 * Enter is attempted once. If the TUI swallows it while committing a paste,
 * read-back returns unverified; a possible effect is never retried.
 *
 * Failure is reported as UNVERIFIED, never as failure-to-deliver: the canonical
 * stays on the bus and the recipient may still poll it.
 */
/**
 * The identity a submit is authorized against.
 *
 * Carried INTO the locked path rather than checked once before it. The lock can
 * wait five seconds, and a pane address is positional: within that window a
 * session can be replaced and the same address can name a DIFFERENT pane.
 * Reproduced — hold the lock, swap %1 for %2 at the same address, release: the
 * sentinel went to %2 and the send exited 0.
 */
export interface BoundRecipient {
  paneId: string;
  serverEpoch: string;
  harness: string;
  /** Registered `boot_id`. Empty skips the axis, matching Bash. */
  bootId?: string;
  /** Recipient handle captured before placement. Absent skips the row reread. */
  handle?: string;
  /** Recipient instance captured before placement. */
  instance?: string;
}

export type BoundBootRefusal = {
  reason: "boot_id_stale" | "boot_id_unobservable";
  detail: string;
};

/**
 * Bash polarity for a registered boot stamp: skip when the row has none;
 * fail closed when the current boot is unreadable or cannot be related;
 * `boot_id_stale` when the boots positively differ. Reuses `bootId` /
 * `bootIdsMatch` — no second oracle.
 */
export function boundBootRefusal(
  rowBoot: string,
  when: "delivery" | "submit" = "delivery",
  env: NodeJS.ProcessEnv = process.env,
): BoundBootRefusal | null {
  if (!rowBoot) return null;
  const now = bootId(env);
  if (!now) {
    return {
      reason: "boot_id_unobservable",
      detail: `bound recipient identity drifted before ${when} (boot_id_unobservable): stored boot_id cannot be attested because the current boot session is unreadable`,
    };
  }
  const relation = bootIdsMatch(rowBoot, now, env);
  if (relation === "match") return null;
  if (relation === "unknown") {
    return {
      reason: "boot_id_unobservable",
      detail: `bound recipient identity drifted before ${when} (boot_id_unobservable): stored boot_id cannot be related to the current boot session`,
    };
  }
  return {
    reason: "boot_id_stale",
    detail: `bound recipient identity drifted before ${when} (boot_id_stale): stored boot_id does not attest the current boot session`,
  };
}

export type HarnessEvidenceClass = "alive" | "mismatch" | "exited" | "unattested" | "unobservable";

export type SubmitAuthority = {
  /** This invocation already admitted its first effect (copy-mode cancellation). */
  attemptAdmitted?: boolean;
  /** Send policy consumes the same authorized band sample as the verifier. */
  deliveryFacts?: Omit<DeliveryFacts, "band">;
  scriptsDir: string;
  agentFamilies: ReadonlySet<string>;
  /** When set, recheck reset/clear fences after authorize and before inject. */
  busHome?: string;
  /**
   * A cross-team recipient's own bus (D2): its clear fence lives there, and its
   * reset fence is checked beside the sender's. Unset means one bus.
   */
  recipientBusHome?: string;
  recipient?: string;
  /** Acting registry reread at every point-of-effect authorize. */
  registryPath?: string;
  /** Reset callers bind the pre-effect conversation; the post-Enter check keeps seat identity only. */
  expectedNativeSession?: string;
  /** Reset controls submit once; a still-staged command is not permission to repeat Enter. */
  singleEnter?: boolean;
  /**
   * The queue-prefix harness (lib.sh:10871 `no_prompt_ok="$qprefix"`): a
   * hermes pane is injectable with no visible idle prompt — the bare prefix
   * IS the handoff — so the rc-3 no-input-prompt defer never applies.
   * Positive holds (a busy band, gone, rate-limited) still hold.
   */
  noPromptOk?: boolean;
};

/**
 * The pane effects, injectable.
 *
 * This seam exists so the replacement race can be tested DETERMINISTICALLY. The
 * defect is "a pane is replaced between two tmux processes", and reproducing
 * that against a real server means hitting a sub-second window — a flake
 * generator, and the reason an earlier attempt asserted SOURCE SHAPE instead.
 * sol-sponsor-x rejected that correctly: a regex over the source passes if
 * authorize always returns null, or validates the wrong identity, or the helper
 * targets the wrong pane. It proves the code was written, not that it works.
 *
 * With the seam, a test drives the replacement between effects and asserts what
 * the replacement RECEIVED, which is the actual property.
 */
export interface PaneEffects extends SurveyEffects {
  observePane: (target: string) => PaneObservation | null | "rate_limited" | "unobservable";
  injectText: typeof injectText;
  inputHasId: typeof inputHasId;
  pressEnter: typeof pressEnter;
  /** The interrupt sequence (U4). Optional only so pre-U4 fakes keep type-checking. */
  pressKeys?: typeof pressKeys;
  clobber?: (target: string, command: string, bound: BoundRecipient | undefined, backup: ClobberBackupReq) => ClobberVerdict;
  restoreInput?: (target: string, text: string) => boolean | "rate_limited";
  /** Injected clock: the fakes advance time without spending it. */
  settle: (seconds: number) => void;
  /** Injected evidence seam for state-machine tests. Production uses observeHarnessPid. */
  harnessEvidence?: (obs: PaneObservation, expected: string) => HarnessEvidenceClass;
  /** Required typed pre-inject band: the six-state pane-state reader. */
  paneState: (target: string, harness: string, command: string) => PaneBand;
  /** Budgeted `#{pane_in_mode}` peek. Production returns typed copy_mode; send queued/polls. */
  copyMode?: (target: string) => CopyModeObservation;
  /** Typed land/clear. Absent on unit3-lock fakes; those keep boolean inputHasId. */
  submitFrame?: (target: string, command: string, expected: string, harnessAlive?: boolean, soleContent?: boolean) => SubmitFrame;
  observeInput?: (target: string, command: string, id: string) => InputObservation;
}

/** Production pane seam. Dark `deliver()` wraps this object rather than relocating submit-verify. */
export const REAL_EFFECTS: PaneEffects = {
  ...SURVEY_EFFECTS,
  observePane: (target) => {
    const result = observePaneResult(target);
    return result.status === "ok" ? result.observation : result.status === "pane_gone" ? null : result.status;
  },
  injectText, inputHasId, pressEnter, pressKeys, settle,
  paneState,
  copyMode: observeCopyMode,
  observeInput: observeInputId,
  submitFrame: observeSubmitFrame,
};

function familyOf(command: string, families: ReadonlySet<string>): string {
  const name = (command.split("/").pop() ?? command).toLowerCase();
  for (const fam of families) {
    if (name === fam || name.startsWith(`${fam}-`)) return fam;
  }
  return name;
}

/**
 * Is the harness rooted at `panePid` observable, and as which family.
 *
 * This used to spawn `python3 -B <scriptsDir>/tap_observe_seats.py --harness-pid`
 * and parse a US-separated line back. The observation is now this process's:
 * one `ps` table, `observeProcessHarness` from the shared module. Two things
 * went with the child, and both are deliberate:
 *
 * - The wire is gone, so `parseHarnessPidStdout` is gone with it. A malformed
 *   record is no longer a reachable state — the engine returns a typed answer
 *   or nothing. Its framing arm in `unit3-lock.test.ts` went too; what a
 *   malformed process TABLE does is still pinned, at the engine, in
 *   `observe.test.ts`.
 * - `TAP_OBS_HARNESS_FAMILIES` is gone. The configured set reached the old
 *   observation only because it crossed a process boundary as an environment
 *   variable; in-process it is an argument. That is the point of the seam and
 *   not an incidental tidy: slice 1 shipped a defect where an in-process
 *   caller silently lost a configured knob that had only ever arrived by
 *   inheritance, so the caller's set is threaded explicitly and an arm makes
 *   dropping it red.
 *
 * `scriptsDir` no longer resolves a script and is retained on purpose: it is
 * this bridge's declared dependency on the installed scripts tree, threaded
 * from submit-verify's configuration, and removing it would churn every caller
 * for a parameter the Bash door still needs to agree on.
 */
export function observeHarnessPid(
  scriptsDir: string,
  agentFamilies: ReadonlySet<string>,
  panePid: string,
  env: NodeJS.ProcessEnv = process.env,
): { state: "observed" | "unobservable"; family: string } {
  const { table, ok } = readProcessTable(env);
  return observeProcessHarness(panePid, table, ok, [...agentFamilies]);
}

export function evaluateHarnessEvidence(
  expected: string,
  command: string,
  panePid: string,
  agentFamilies: ReadonlySet<string>,
  processObs: { state: "observed" | "unobservable"; family: string } | null,
): HarnessEvidenceClass {
  const want = familyOf(expected, agentFamilies);
  if (!want) return "unattested";
  const observed = familyOf(command, agentFamilies);
  if (agentFamilies.has(observed)) return observed === want ? "alive" : "mismatch";
  if (DENYLIST.has(observed)) return "exited";
  if (!panePid) return "unobservable";
  if (!processObs || processObs.state !== "observed") return "unobservable";
  if (processObs.family) return processObs.family === want ? "alive" : "mismatch";
  return "exited";
}

function collectEvidence(
  obs: PaneObservation,
  expected: string,
  fx: PaneEffects,
  authority?: SubmitAuthority,
): HarnessEvidenceClass {
  if (fx.harnessEvidence) return fx.harnessEvidence(obs, expected);
  if (!authority) return "unobservable";
  const observed = familyOf(obs.currentCommand, authority.agentFamilies);
  let processObs: { state: "observed" | "unobservable"; family: string } | null = null;
  if (!authority.agentFamilies.has(observed) && !DENYLIST.has(observed)) {
    processObs = observeHarnessPid(authority.scriptsDir, authority.agentFamilies, obs.panePid);
  }
  return evaluateHarnessEvidence(expected, obs.currentCommand, obs.panePid, authority.agentFamilies, processObs);
}

/** Pre-placement twin of the post-lock authorize harness check. */
export function evaluateBoundHarness(
  obs: PaneObservation,
  expected: string,
  authority: SubmitAuthority,
): HarnessEvidenceClass {
  return collectEvidence(obs, expected, REAL_EFFECTS, authority);
}

export function submitVerify(
  pane: string,
  id: string,
  sentinel: string,
  bound?: BoundRecipient,
  authority?: SubmitAuthority,
  fx: PaneEffects = REAL_EFFECTS,
): SubmitResult {
  // SERIALIZE THE WHOLE SUBMIT CYCLE ON THE PANE. Nothing between the text write
  // and the Enter is atomic, so any concurrent writer lands inside that window
  // and both sentinels are submitted as one line — with both senders exiting 0.
  const lock = acquirePaneLock(bound?.paneId || pane);
  if (!lock) {
    return {
      status: "lock_busy",
      detail: `another submit holds pane '${pane}'; parking rather than risking a fused line`,
    };
  }
  try {
    if (recoveryHold(bound?.paneId || pane)) return { status: "recovery_held", detail: `recovery owns pane '${pane}'; delivery parked` };
    const submit = () => submitVerifyLocked(pane, id, sentinel, bound, fx, authority);
    return authority?.busHome ? captureCourierFailure({ id, pane, sentinel, harness: bound?.harness ?? "",
      busHome: authority.busHome, scriptsDir: authority.scriptsDir }, submit, true) : submit();
  } finally {
    lock.release();
  }
}

type AuthorizeResult =
  | { status: "ok"; observation: PaneObservation }
  | Extract<SubmitResult, { status: "identity_mismatch" | "rate_limited" | "band_busy" }>;

/**
 * The one pre-effect authorization, narrowed for callers that hold the pane
 * submit lock themselves and must re-prove identity before their OWN named key
 * (self-compact's single Escape). It is the same `authorize` every locked
 * submission runs — no second predicate, no weaker check.
 */
export function authorizePaneEffect(
  pane: string,
  bound: BoundRecipient | undefined,
  fx: PaneEffects = REAL_EFFECTS,
  authority?: SubmitAuthority,
): AuthorizeResult {
  return authorize(pane, bound, fx, authority);
}

/**
 * Reread the acting registry at point-of-effect. The captured handle must still
 * name an active pane-delivery row bound to the same pane id and instance.
 * Unreadable, absent, inactive, launching, malformed, poll-only, or rebound
 * rows refuse before any pane effect.
 */
function boundRecipientRowRefusal(
  bound: BoundRecipient,
  authority?: SubmitAuthority,
): Extract<SubmitResult, { status: "identity_mismatch" }> | null {
  if (!bound.handle || !authority?.registryPath) return null;
  const handle = bound.handle;
  const path = authority.registryPath;
  let seats: Record<string, unknown>;
  try {
    seats = seatMap(loadRegistry(path));
  } catch {
    return {
      status: "identity_mismatch",
      detail: `acting registry '${path}' is unreadable; refusing to deliver to '${handle}'`,
    };
  }
  if (!Object.hasOwn(seats, handle)) {
    return {
      status: "identity_mismatch",
      detail: `'${handle}' is not an active seat; refusing to deliver to a pane that is not the addressed seat`,
    };
  }
  const row = seats[handle];
  if (typeof row !== "object" || row === null || Array.isArray(row)) {
    return {
      status: "identity_mismatch",
      detail: `'${handle}' is not an active seat; refusing to deliver to a pane that is not the addressed seat`,
    };
  }
  const rec = row as Record<string, unknown>;
  if (authority?.expectedNativeSession !== undefined && rec.harness_session_id !== authority.expectedNativeSession) {
    return { status: "identity_mismatch", detail: `'${handle}' native session changed before reset effect` };
  }
  if (String(rec.status ?? "active") !== "active") {
    return {
      status: "identity_mismatch",
      detail: `'${handle}' is not an active seat; refusing to deliver to a pane that is not the addressed seat`,
    };
  }
  if (String(rec.status_reason ?? "") === "launching") {
    return {
      status: "identity_mismatch",
      detail: `'${handle}' is still launching; refusing to deliver to a pane that is not the addressed seat`,
    };
  }
  if (String(rec.delivery ?? "pane") === "poll") {
    return {
      status: "identity_mismatch",
      detail: `'${handle}' is no longer a pane-delivery seat; refusing to deliver to a pane that is not the addressed seat`,
    };
  }
  const rowPaneId = String(rec.pane_id ?? "");
  if (bound.paneId && rowPaneId !== bound.paneId) {
    return {
      status: "identity_mismatch",
      detail: `'${handle}' is bound to pane id ${rowPaneId || "(none)"}, not the captured ${bound.paneId} — refusing to deliver to a pane that is not the addressed seat`,
    };
  }
  const rowInstance = typeof rec.instance === "string" ? rec.instance : "";
  const captured = bound.instance ?? "";
  if (captured !== rowInstance) {
    return {
      status: "identity_mismatch",
      detail: `'${handle}' is instance '${rowInstance || "(none)"}', not the captured '${captured || "(none)"}' — refusing to deliver to a pane that is not the addressed seat`,
    };
  }
  return null;
}

/**
 * Re-authorize the live pane against the bound row. Returns the accepted
 * same-tuple observation, or a refusal. Success is never null.
 *
 * FAILS CLOSED ON AN UNOBSERVABLE GENERATION. An earlier version required BOTH
 * the bound and the live generation to be present before comparing, which
 * treated "cannot observe" as permission — precisely backwards for a check whose
 * job is to refuse when identity is in doubt.
 */
function authorize(
  pane: string,
  bound: BoundRecipient | undefined,
  fx: PaneEffects = REAL_EFFECTS,
  authority?: SubmitAuthority,
): AuthorizeResult {
  if (bound) {
    const rowRefuse = boundRecipientRowRefusal(bound, authority);
    if (rowRefuse) return rowRefuse;
  }
  const obs = fx.observePane(pane);
  if (obs === "unobservable") {
    return { status: "band_busy", bandState: "unobservable", detail: `pane '${pane}' identity is unobservable` };
  }
  if (obs === "rate_limited") {
    return { status: "rate_limited", detail: "tmux client budget exhausted before pane identity could be authorized" };
  }
  if (!obs) return { status: "identity_mismatch", detail: `pane '${pane}' does not exist` };
  if (!bound) return { status: "ok", observation: obs };
  if (bound.paneId && bound.paneId !== obs.paneId) {
    return { status: "identity_mismatch", detail: `'${pane}' is now pane ${obs.paneId}, not the bound ${bound.paneId} — refusing to deliver to a pane that is not the addressed seat` };
  }
  const bootRefuse = boundBootRefusal(bound.bootId ?? "", "submit");
  if (bootRefuse) {
    return { status: "identity_mismatch", detail: bootRefuse.detail };
  }
  if (bound.serverEpoch && bound.serverEpoch !== obs.serverEpoch) {
    return { status: "identity_mismatch", detail: obs.serverEpoch
      ? `the pane reports server generation ${obs.serverEpoch}, not the bound ${bound.serverEpoch}`
      : `the pane's server generation is not observable, so the bound generation ${bound.serverEpoch} cannot be verified` };
  }
  const evidence = collectEvidence(obs, bound.harness ?? "", fx, authority);
  if (evidence === "alive") return { status: "ok", observation: obs };
  return {
    status: "identity_mismatch",
    detail: `harness evidence ${evidence} for bound family '${bound.harness ?? ""}' (live command '${obs.currentCommand}')`,
  };
}

function sampleInput(fx: PaneEffects, target: string, command: string, id: string): InputObservation {
  if (fx.observeInput) return fx.observeInput(target, command, id);
  return fx.inputHasId(target, command, id) ? { state: "present", text: id } : { state: "absent" };
}

function copyModeSubmit(pane: string): Extract<SubmitResult, { status: "copy_mode" }> {
  return { status: "copy_mode", cause: "copy-mode", detail: `pane '${pane}' is in copy-mode` };
}

/** Copy-mode, gone, and rate-limited. Unobservable is not a resample override. */
function copyModeResample(obs: CopyModeObservation | undefined, pane: string): SubmitResult | null {
  if (!obs) return null;
  if (obs.status === "copy-mode") return copyModeSubmit(pane);
  if (obs.status === "rate-limited") return { status: "rate_limited", detail: obs.reason };
  if (obs.status === "gone") return { status: "pane_gone", detail: `pane '${pane}' does not exist` };
  return null;
}

function copyModePreEffect(obs: CopyModeObservation | undefined, pane: string): SubmitResult | null {
  const resampled = copyModeResample(obs, pane);
  if (resampled) return resampled;
  if (obs?.status === "unobservable") return { status: "band_busy", bandState: "unobservable", detail: obs.reason };
  return null;
}

function bandBlocksSubmit(band: PaneBand, pane: string): SubmitResult | null {
  if (band.state === "ready") return null;
  if (band.state === "busy") {
    return {
      status: "band_busy",
      bandState: "queued" in band && band.queued ? "queued" : "busy",
      bandText: band.text,
      detail: `pane '${pane}' holds unsubmitted input; refusing to inject rather than concatenating onto it`,
    };
  }
  if (band.state === "unobservable") {
    return { status: "band_busy", bandState: "unobservable", detail: band.reason ?? "input band is unobservable" };
  }
  if (band.state === "rate_limited") {
    return { status: "rate_limited", detail: band.reason ?? "tmux client budget exhausted before pane input could be inspected" };
  }
  if (band.state === "gone") {
    return { status: "pane_gone", detail: `pane '${pane}' is gone` };
  }
  return null;
}

/** Called only while the normal submit lock is held, including the Bash bridge. */
export function recoverSurveyLocked(pane: string, bound: BoundRecipient | undefined,
  authority: SubmitAuthority | undefined, fx: PaneEffects = REAL_EFFECTS, id = "") {
  const target = bound?.paneId || pane;
  let admittedHere = authority?.attemptAdmitted === true || process.env.TAP_DELIVERY_NEW_ATTEMPT === id;
  const surveyFx: PaneEffects = id && authority?.busHome ? {
    ...fx,
    admitAttempt: () => {
      if (admittedHere) return true;
      try {
        if (beginDeliveryAttempt(authority.busHome!, id) !== "created") return false;
        admittedHere = true;
        return true;
      } catch (error) {
        console.error(`tap: cannot record delivery attempt: ${error}`);
        return false;
      }
    },
  } : fx;
  const result = recoverAgySurvey(target, bound?.harness ?? "", surveyFx, () => {
    if (!bound?.handle || !bound.instance || !bound.serverEpoch || !authority?.registryPath) return "complete registered target identity required; no keys sent";
    if (id && authority.busHome && !admittedHere) {
      try {
        lstatSync(join(authority.busHome, "receipts", `${id}.attempted`));
        return "prior possible attempt; no recovery or sentinel replay";
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "ENOENT") return "attempt evidence unreadable; no recovery or sentinel replay";
      }
    }
    const check = authorize(pane, bound, fx, authority);
    if (check.status !== "ok") return check.detail;
    const fence = paneEffectFence(authority);
    if (fence) return fence.detail;
    const copy = copyModePreEffect(fx.copyMode?.(target), pane);
    if (copy && "detail" in copy) return copy.detail;
    return recoveryHold(target) ? "another recovery owns this pane" : null;
  });
  return { ...result, attemptAdmitted: admittedHere };
}

/** The `unobservable` reasons that mean "no composer geometry was readable" (classifyPane's no-band arms for an unrecognized Claude/Codex/Antigravity frame), as opposed to a human decision on screen. See the `--no-spool` arm in submitVerifyLocked. */
const NO_SPOOL_ATTEMPTS_ON: ReadonlySet<string> = new Set([
  "no recognized Claude input box",
  "no recognized Codex composer",
  "no recognized Antigravity composer",
]);

export function submitVerifyLocked(
  pane: string,
  id: string,
  sentinel: string,
  bound?: BoundRecipient,
  fx: PaneEffects = REAL_EFFECTS,
  authority?: SubmitAuthority,
): SubmitResult {
  const attempt = randomUUID();
  let enterCount = 0, ordinal = 0;
  let phasesRecorded = !!authority?.busHome;
  const phase = (name: SubmitPhase, result?: string) => {
    if (!authority?.busHome) return;
    try { recordPhase(authority.busHome, { id, attempt, phase: name, recipient: authority.recipient ?? "",
      enter_count: enterCount, ordinal, result }); }
    catch (error) {
      phasesRecorded = false;
      console.error(`tap: submission phase evidence unavailable; submit behavior unchanged: ${error}`);
    }
  };
  const result = submitVerifyLockedBody(pane, id, sentinel, bound, fx, authority, phase,
    () => { ordinal++; }, () => { enterCount++; });
  phase("verify-result", result.status === "injected" ? "verified" : result.status === "harness_queued" ? "queued" : "unverified");
  if (result.status === "unverified" && result.reprobePending && !phasesRecorded) {
    return { status: "unverified", detail: result.detail };
  }
  return result;
}

function submitVerifyLockedBody(
  pane: string,
  id: string,
  sentinel: string,
  bound: BoundRecipient | undefined,
  fx: PaneEffects,
  authority: SubmitAuthority | undefined,
  phase: (name: SubmitPhase, result?: string) => void,
  nextOrdinal: () => void,
  entered: () => void,
): SubmitResult {
  // RE-AUTHORIZED AFTER THE LOCK AND BEFORE ANY PANE EFFECT — not merely before
  // placement, which is a different moment entirely.
  const authorized = authorize(pane, bound, fx, authority);
  if (authorized.status !== "ok") return authorized;

  // TARGET THE PANE ID, NOT THE ADDRESS. Authorizing and then acting on the
  // positional address leaves a real gap: those are two tmux processes, and a
  // session replaced between them means the keystroke lands on whatever now
  // occupies that address. sol-sponsor-x's correction — bound.paneId IS the
  // immutable-within-generation identity, and combined with bound.serverEpoch
  // (which authorize compares) it is the composite identity I said was
  // unavailable. It was available; I had it in hand and was not using it.
  //
  // Authorization still runs before every effect, because the epoch check is
  // what catches a server REBIRTH — a %N is unique only within one generation,
  // so the id alone is not enough. Targeting the id closes the address race;
  // authorizing closes the generation race. Both are needed.
  const target = bound?.paneId || pane;
  const mode = recordedPermissions(authority?.registryPath, bound?.handle ?? authority?.recipient);
  if (mode === "unknown") {
    // A row can disappear during the pane observation above. Identity refusal
    // keeps precedence over the later permission-policy hold.
    const rowRefusal = bound && boundRecipientRowRefusal(bound, authority);
    if (rowRefusal) return rowRefusal;
    return { status: "band_busy", detail: "recipient permission policy is unreadable" };
  }
  const auto = mode === "auto";

  // U4 (the interrupt class). The effective urgency rides the delivery facts,
  // but an auto-permission seat has no human to interrupt — the incumbent
  // downgrades to ordinary delivery BEFORE any pane effect, warning once
  // (tap-send.sh:1582-1591). Everything urgent-scoped below keys off this
  // local, so a downgraded auto seat takes the ordinary path throughout.
  let urgent = authority?.deliveryFacts?.urgent === true;
  if (urgent && auto) {
    process.stderr.write("tap send: warning: auto_mode_no_interrupt: auto seat cannot be interrupted; queued as ordinary delivery\n");
    urgent = false;
  }

  const readerCommand = (obs: PaneObservation) => bound?.harness || obs.currentCommand;
  let command = readerCommand(authorized.observation);

  // INPUT SAFETY, CHECKED BEFORE ANY PANE EFFECT.
  //
  // send-keys appends to whatever is already in the band, so injecting into a
  // pane whose owner has typed something concatenates the sentinel onto their
  // half-written message and Enter submits BOTH as one line. Reproduced: a
  // pane holding `HUMAN-DRAFT` received
  // `HUMAN-DRAFT[[TAP v=0.20 …]]` as a single submitted line, and the send
  // still returned 0. That is user-input corruption reported as success.
  //
  // This PoC takes the conservative outcome — skip the pane effect, leave the
  // canonical on the bus — rather than the reference's backup-and-clobber
  // pipeline, which is out of the declared slice. The recipient can poll it:
  // blocked-band maps to exit-0 queued/poll, not exit-5.
  //
  // AN UNOBSERVABLE BAND IS ALSO A REFUSAL. A harness mid-turn renders no prompt
  // glyph at all, and an earlier version read "no prompt found" as "band is
  // empty" — then injected into a pane it could not see, leaving the sentinel
  // sitting unsubmitted while the payload looked delivered from outside.
  // "I cannot see the band" and "the band is empty" are opposite facts.
  const initialCopy = copyModePreEffect(fx.copyMode?.(target), pane);
  if (initialCopy) return initialCopy;
  const survey = recoverSurveyLocked(pane, bound, authority, fx, id);
  if (survey.status === "attempt_evidence_unwritable") return survey;
  if (survey.status === "blocked") return { status: "band_busy", bandState: "unobservable", detail: survey.detail };
  let attemptAdmitted = survey.attemptAdmitted;
  const admitEffect = (): Extract<SubmitResult, { status: "attempt_evidence_unwritable" }> | null => {
    if (!authority?.deliveryFacts || attemptAdmitted) return null;
    try {
      if (beginDeliveryAttempt(authority.busHome ?? "", id) !== "created") {
        return { status: "attempt_evidence_unwritable", detail: `delivery attempt for '${id}' already recorded` };
      }
      attemptAdmitted = true;
      return null;
    } catch (error) {
      return { status: "attempt_evidence_unwritable", detail: `cannot record delivery attempt: ${error}` };
    }
  };
  const band = fx.paneState(target, bound?.harness ?? "", command);
  if (auto && (band.state !== "ready" || !fx.submitFrame)) {
    return { status: "band_busy", detail: "auto seat has no positively ready empty band" };
  }
  // This is the courier-local band, REASSIGNED after an urgent interrupt: the
  // incumbent re-reads pending input once the Escape has landed
  // (tap-send.sh:1666), because the interrupt may have cleared a half-open
  // draft into a ready band.
  let effectiveBand = band;
  let draftBackup: Extract<ClobberVerdict, { kind: "cleared" | "residue" }> | undefined;
  let decision: DeliveryDisposition | undefined;
  if (authority?.deliveryFacts && band.state !== "gone" && band.state !== "rate_limited") {
    const facts = { ...authority.deliveryFacts, urgent };
    const observed = band.state === "ready" ? "bare"
      : band.state === "busy" ? ("queued" in band && band.queued ? "queued"
        : deliveryBand(band.text, facts.harness ?? "", "")) : "unobservable";
    decision = deliveryDisposition({ ...facts, band: observed });
  }
  // THE URGENT INTERRUPT (U4). Ordered by the incumbent's first-effect rule
  // (tap-send.sh:1582-1760): a human decision on screen is never interrupted —
  // agy's permission overlay reads a plain capture, claude/codex read theirs
  // escape-sequenced (lib.sh:10924-10977); the red cue flashes on the direct
  // path's draft band (:1750); identity is re-authorized and the
  // possible-effect evidence minted (the FIRST interrupt key is a delivery
  // effect — never retried, held by receipts/<id>.attempted); then, and only
  // then, the interrupt keys fall (tap_interrupt_seq, lib.sh:9104).
  if (urgent) {
    const fam = familyOf(command, authority?.agentFamilies ?? new Set<string>());
    const modalCapture = (escaped: boolean) => capturePane(pane, escaped, true);
    if (fam === "agy") {
      const r = modalCapture(false);
      if (r.rateLimited) return { status: "rate_limited", detail: "tmux client budget exhausted before urgent interrupt" };
      if (r.code !== 0) return { status: "band_busy", bandState: "unobservable", detail: "no visible input prompt" };
      if (agyPermissionOverlay(r.stdout)) {
        return { status: "band_busy", bandState: "unobservable", detail: `pane '${pane}' is showing a permission prompt -> defer (urgent will not interrupt a pending decision)` };
      }
    } else if (fam === "claude" || fam === "codex") {
      const r = modalCapture(true);
      if (r.rateLimited) return { status: "rate_limited", detail: "tmux client budget exhausted before urgent interrupt" };
      if (r.code !== 0) return { status: "band_busy", bandState: "unobservable", detail: "no visible input prompt" };
      if (approvalPrompt(command, r.stdout)) {
        return { status: "band_busy", bandState: "unobservable", detail: "approval prompt blocks urgent delivery; nothing submitted or cleared" };
      }
      if (fam === "claude" && claudeFeedbackOverlay(r.stdout)) {
        return { status: "band_busy", bandState: "unobservable", detail: "Claude feedback dialog blocks urgent delivery; nothing submitted or cleared" };
      }
    }
    if (decision?.cue.initialStyle) {
      flashPaneLocked({ home: authority?.busHome ?? "", pane, paneId: target, ownerId: id, style: `bg=${decision.cue.initialStyle}` });
    }
    const beforeInterrupt = authorize(pane, bound, fx, authority);
    if (beforeInterrupt.status !== "ok") return beforeInterrupt;
    const interruptFence = paneEffectFence(authority);
    if (interruptFence) return interruptFence;
    // opencode double-Escapes; cursor interrupts with C-c; claude/codex/agy
    // Escape once; hermes is skipped — its bare un-prefixed inject IS the
    // interrupt.
    const seq = fam === "opencode" ? ["Escape", "Escape"]
      : fam === "cursor" ? ["C-c"]
      : fam === "hermes" ? []
      : ["Escape"];
    if (seq.length > 0) {
      const refused = admitEffect();
      if (refused) return refused;
      const pressed = fx.pressKeys ? fx.pressKeys(target, seq) : pressKeys(target, seq);
      if (pressed === "rate_limited") return { status: "rate_limited", detail: "tmux client budget exhausted before urgent interrupt" };
      if (!pressed) return { status: "pane_gone", detail: `pane '${pane}' gone before urgent interrupt` };
    }
    fx.settle(0.15);
    effectiveBand = fx.paneState(target, bound?.harness ?? "", command);
    if (effectiveBand.state === "busy" && !effectiveBand.text.trimStart().startsWith("[[TAP") && !("queued" in effectiveBand && effectiveBand.queued)) {
      const beforeClear = authorize(pane, bound, fx, authority);
      if (beforeClear.status !== "ok") return { status: "unverified", detail: beforeClear.detail };
      const clearFence = paneEffectFence(authority);
      if (clearFence) return { status: "unverified", detail: clearFence.detail };
      if (!fx.clobber) return { status: "unverified", detail: "draft clear effects are unavailable; input preserved" };
      const refused = admitEffect();
      if (refused) return refused;
      const cleared = fx.clobber(target, command, bound, {
        directory: join(authority!.busHome!, "input-backups"), handle: authority?.recipient ?? id,
        payloadId: id, pane, paneId: target,
      });
      if (cleared.kind !== "cleared" && cleared.kind !== "residue") {
        return { status: "unverified", detail: "detail" in cleared ? cleared.detail
          : cleared.kind === "possible-failure" ? cleared.result.detail : "paste-collapse draft persists after clear attempts" };
      }
      draftBackup = cleared;
      // The shared door retains the draft backup and explicitly permits residue.
      effectiveBand = cleared.kind === "residue" ? { state: "ready" } : fx.paneState(target, bound?.harness ?? "", command);
    }
  }
  let blocked = bandBlocksSubmit(effectiveBand, pane);
  // `--no-spool` (CONTRACT §tap send --no-spool; lib.sh:11774's rc-3 arm): an
  // AMBIGUOUS observation — the composer geometry could not be read — permits
  // the one direct attempt; every positive hold keeps refusing. The precondition
  // is POSITIVE: `toPaneBand` collapses eight classifications into
  // `unobservable` (pane-state.ts:171-180), and three of them are a human's
  // pending decision (a Claude/Codex approval prompt, the Claude feedback
  // dialog, the Antigravity permission overlay — lib.sh's rc 4, never typed
  // over), so "unobservable" alone would inject into an approval prompt. Only
  // the geometry-unreadable reasons qualify; an unlisted reason holds. The
  // coupling to pane-state.ts's reason strings is deliberate and FAILS CLOSED:
  // an edited reason string stops this arm rather than widening it. The
  // list is a workaround for the collapse, not the contract — it retires when
  // `PaneBand` carries the rc 3 / rc 4 distinction (lane B, B2b convergence,
  // tap-b8qp5). OpenCode's composer-absent reason is deliberately absent (its
  // `booting` hold). Named hunk from lane D (D3a) in lane B's engine, under
  // B's per-unit read.
  if (blocked?.status === "band_busy" && blocked.bandState === "unobservable" && authority?.deliveryFacts?.noSpool
    && NO_SPOOL_ATTEMPTS_ON.has(blocked.detail)) {
    process.stderr.write("tap: explicit --no-spool attempt with no readable input band -> injecting\n");
    blocked = null;
  }
  // The queue-prefix harness (lib.sh:10871 `no_prompt_ok="$qprefix"`): the
  // `/queue ` prefix QUEUES over pending input instead of clobbering it, so
  // the incumbent skips the pending-input hold entirely whenever the prefix
  // rides — only a positive gone / rate-limited / copy-mode keeps refusing.
  // U4 drops the prefix for urgent, but the hermes bypass STAYS: the caller
  // still reports no_prompt_ok for hermes because its bare un-prefixed inject
  // is itself the interrupt (lib.sh:10871 captures no_prompt_ok from the
  // prefix before the urgent path zeroes it).
  if (authority?.noPromptOk && blocked?.status === "band_busy") {
    blocked = null;
  }
  if (blocked) {
    const mid = copyModeResample(fx.copyMode?.(target), pane);
    // Copy-mode / gone / rate-limited replace a blocked band. Mid
    // unobservable must not relabel pane_gone or rate_limited as band_busy.
    if (mid) return mid;
    return blocked.status === "band_busy" && decision?.action === "park" ? { ...blocked, disposition: decision } : blocked;
  }
  // The queue prefix rides over the disposition hold too: the incumbent's
  // band read of a queue-prefix pane answers unobservable and its slice then
  // injects (delivery-disposition pins "hermes unobservable injects"), so the
  // measured bash outcome for prefix + occupied composer is DELIVER, not park.
  if (decision?.action === "park" && !authority?.noPromptOk) return { status: "band_busy", disposition: decision, detail: "delivery deferred by recipient disposition" };

  const beforeInject = authorize(pane, bound, fx, authority);
  if (beforeInject.status !== "ok") return beforeInject;
  command = readerCommand(beforeInject.observation);
  const fenced = paneEffectFence(authority);
  if (fenced) return fenced;
  const finalCopy = copyModePreEffect(fx.copyMode?.(target), pane);
  if (finalCopy) return finalCopy;
  const finalBand = fx.paneState(target, bound?.harness ?? "", command);
  if (auto && finalBand.state !== "ready") {
    return { status: "band_busy", detail: "auto seat band changed before paste" };
  }
  if (!urgent && !authority?.noPromptOk) {
    const late = bandBlocksSubmit(finalBand, pane);
    const geometryAttempt = late?.status === "band_busy" && late.bandState === "unobservable"
      && authority?.deliveryFacts?.noSpool && NO_SPOOL_ATTEMPTS_ON.has(late.detail);
    if (late && !geometryAttempt) return late;
  }
  // Admit at the first real effect, including Hermes's interrupt-by-injection.
  const refused = admitEffect();
  if (refused) return refused;
  const injected = fx.injectText(target, sentinel);
  if (injected === "rate_limited") {
    return { status: "rate_limited", detail: "tmux client budget exhausted before sentinel injection" };
  }
  if (!injected) return { status: "unverified", detail: `pane '${target}' gone during inject` };

  // A full visible wire is landing evidence even if the older id-only input
  // adapter cannot read this harness's band (notably OpenCode's left border).
  let fullTextLanded = false;
  const sampleLanding = (): InputObservation => {
    if (fx.submitFrame?.(target, command, sentinel, !!bound?.harness, auto).state === "staged") {
      fullTextLanded = true;
      return { state: "present", text: sentinel };
    }
    // tap-dl3 / lib.sh:11507-11521: a queue-prefix harness renders its band
    // WITHOUT a prompt glyph, so the glyph-anchored reader false-negatives the
    // landed '/queue <sentinel>' line; no_prompt_ok re-checks glyph-less and a
    // positive observation proves the inject landed and submits.
    if (authority?.noPromptOk) {
      const band = fx.paneState(target, bound?.harness ?? "", command);
      if (band.state === "busy" && band.text.includes(sentinel)) return { state: "present", text: sentinel };
      if (band.state === "gone") return { state: "gone" };
    }
    return sampleInput(fx, target, command, id);
  };
  let landed = false;
  for (let i = 0; i < 10; i++) {
    const sample = sampleLanding();
    if (sample.state === "present") { landed = true; break; }
    if (sample.state === "gone") {
      return { status: "unverified", detail: `pane '${target}' gone during land` };
    }
    if (sample.state === "rate_limited") {
      return { status: "unverified", detail: sample.reason };
    }
    fx.settle(0.1);
  }
  if (!landed) {
    const extra = sampleLanding();
    if (extra.state === "present") landed = true;
    else if (extra.state === "gone") {
      return { status: "unverified", detail: `pane '${target}' gone during land` };
    } else if (extra.state === "rate_limited") {
      return { status: "unverified", detail: extra.reason };
    }
  }
  if (!landed) return { status: "unverified", detail: `input did not land on '${pane}'` };

  // Four attempts, a pair per attempt on Cursor. Inspect after each attempt;
  // another id-free draft or a missing prompt is not positive acceptance.
  let cleared = false, queued = false, textConfirmed = false;
  let initialMode: SubmitFrame["mode"] | undefined;
  const enterAttempts = authority?.singleEnter ? 1 : 4;
  for (let attempt = 0; attempt < enterAttempts; attempt++) {
    const beforeEnter = authorize(pane, bound, fx, authority);
    if (beforeEnter.status !== "ok") return { status: "unverified", detail: beforeEnter.detail };
    command = readerCommand(beforeEnter.observation);
    const fenced = paneEffectFence(authority);
    if (fenced) return { status: "unverified", detail: fenced.detail };
    if (fx.submitFrame) {
      const frame = fx.submitFrame(target, command, sentinel, !!bound?.harness, auto);
      initialMode ??= frame.mode;
      if (frame.state === "queued") { queued = true; cleared = true; break; }
      // The queue-prefix landing was the gate (lib.sh:11507); its glyph-less
      // band never classifies staged, so no_prompt_ok proceeds to Enter.
      if (frame.state !== "staged" && !authority?.noPromptOk) {
        // AGY may repaint after the full wire landed but before the first
        // Enter. The existing owner can re-observe and submit that exact wire
        // in place; it must never repeat the injection or an earlier Enter.
        if (command === "agy" && frame.state === "changed" && attempt === 0 && fullTextLanded) {
          phase("injected-text-confirmed");
          return { status: "unverified", reprobePending: true, detail: "AGY input changed before Enter; sentinel remains pending" };
        }
        return { status: "unverified", detail: `${frame.state}, ${frame.mode}, width ${frame.width}` };
      }
    }
    if (fx.submitFrame && !textConfirmed) {
      phase("injected-text-confirmed");
      textConfirmed = true;
    }
    nextOrdinal();
    phase("Enter-intent");
    const copy = copyModePreEffect(fx.copyMode?.(target), pane);
    if (copy) return { status: "unverified", detail: "detail" in copy ? copy.detail : "pane observation changed before submit" };
    const finalIdentity = authorize(pane, bound, fx, authority);
    if (finalIdentity.status !== "ok") return { status: "unverified", detail: finalIdentity.detail };
    const finalFence = paneEffectFence(authority);
    if (finalFence) return { status: "unverified", detail: finalFence.detail };
    entered();
    const pressed = fx.pressEnter(target);
    if (pressed === "rate_limited") return { status: "unverified", detail: "tmux client budget exhausted after sentinel injection" };
    if (!pressed) return { status: "unverified", detail: `pane '${target}' vanished after sentinel injection` };
    phase("Enter-sent");
    // Cursor's plain sequence steers then interrupts at its safe boundary.
    // It is unconditional: a queued frame after the first Enter does not omit
    // it. An URGENT cursor send already interrupted with C-c before the
    // payload, so its steering tail stays a single Enter (the downgrade-local
    // `urgent`, not the caller's fact — a downgraded auto seat keeps its tail).
    if (command.startsWith("cursor") && !urgent && !authority?.singleEnter) {
      fx.settle(0.25);
      const secondCopy = copyModePreEffect(fx.copyMode?.(target), pane);
      if (secondCopy) return { status: "unverified", detail: "pane entered copy mode during Cursor submit" };
      nextOrdinal();
      phase("Enter-intent");
      const secondIdentity = authorize(pane, bound, fx, authority);
      if (secondIdentity.status !== "ok") return { status: "unverified", detail: secondIdentity.detail };
      const secondFence = paneEffectFence(authority);
      if (secondFence) return { status: "unverified", detail: secondFence.detail };
      entered();
      const second = fx.pressEnter(target);
      if (second === "rate_limited") return { status: "unverified", detail: "tmux client budget exhausted during Cursor submit" };
      if (!second) return { status: "unverified", detail: `pane '${target}' vanished during Cursor submit` };
      phase("Enter-sent");
    }
    fx.settle(attempt === 3 ? 1.5 : 0.5);
    if (fx.submitFrame) {
      const frame = fx.submitFrame(target, command, sentinel, !!bound?.harness, auto);
      if (frame.state === "queued") { queued = true; cleared = true; break; }
      if (authority?.noPromptOk) {
        // lib.sh:11043: no_prompt_ok (the /queue prefix) relaxes the
        // post-submit pending-input recheck too — a queue line still rendered
        // is the harness's own business, never an unverified submit.
        queued = true; cleared = true; break;
      }
      if (frame.state === "empty" || (frame.state === "unobservable" && frame.mode === "working" && initialMode !== "working")) { cleared = true; break; }
      if (frame.state !== "staged" || attempt === enterAttempts - 1) {
        return { status: "unverified", detail: `${frame.state}, ${frame.mode}, width ${frame.width}` };
      }
    } else {
      // Older injected effects expose typed input observations instead of frames.
      const sample = sampleInput(fx, target, command, id);
      if (sample.state === "absent") { cleared = true; break; }
      if (sample.state === "chip") return { status: "unverified", detail: `paste-collapse chip remains in the input of '${pane}'` };
      if (sample.state === "unobservable" || sample.state === "rate_limited") return { status: "unverified", detail: sample.reason };
      if (sample.state === "gone") return { status: "unverified", detail: `pane '${pane}' gone after sentinel injection` };
    }
  }
  if (!cleared) return { status: "unverified", detail: `staged, width unknown: id '${id}' did not leave the input line of '${pane}'` };
  // Enter may already have taken effect. A late identity failure cannot be a
  // pre-effect refusal class — the receipt would claim a different pane/epoch
  // than the one that was submitted to.
  // A successful reset may already have rebound the native conversation.
  // Keep pane/instance/epoch/harness checks, but do not reject that expected change.
  const afterClear = authorize(pane, bound, fx, authority ? { ...authority, expectedNativeSession: undefined } : undefined);
  if (afterClear.status !== "ok") {
    return { status: "unverified", detail: afterClear.detail };
  }
  if (draftBackup?.backupPath) {
    let restored = false;
    if (draftBackup.lines <= 2 && !draftBackup.chip && !command.startsWith("opencode") && fx.restoreInput &&
        fx.paneState(target, bound?.harness ?? "", command).state === "ready" && !paneEffectFence(authority)) {
      try {
        const text = inputBackupBody(readFileSync(draftBackup.backupPath, "utf8"));
        if (fx.restoreInput(target, text) === true) {
          const observed = fx.paneState(target, bound?.harness ?? "", command);
          restored = observed.state === "busy" && observed.text.split("\n", 1)[0] === text.split("\n", 1)[0];
        }
      } catch { /* The retained backup remains the recovery authority. */ }
    }
    process.stderr.write(restored ? `tap: input backup restored from retained file: ${draftBackup.backupPath}\n`
      : "tap: draft backed up — view + copy with: tap draft\n");
  }
  return { status: queued ? "harness_queued" : "injected" };
}

/**
 * Bash polarity for a recipient clear marker: content is the signal, not
 * lock-held. Unreadable or malformed records are absent.
 *
 * A thin wrapper over the ONE reader. This used to hold a second copy of the
 * predicate, and the two had drifted: `Number()` is not `float()`, so a ceiling
 * of "1_000" or "infinity" read absent here and live at the Bash door, while
 * "0x10" read live here and absent there. The state is all this caller needs;
 * `readClearFence` also returns the record, which is what lets the Bash door
 * name the wedged clearer.
 *
 * Fail-open is applied HERE rather than inside the reader. A marker that cannot
 * be DECODED is a refusal at the reset door and a delivery here, so the reader
 * raises and each door chooses — folding it into "absent" would take that
 * choice away from both.
 */
export function inspectClearFenceRecord(busHome: string, handle: string): ClearFenceRead {
  try {
    return readClearFence(busHome, handle);
  } catch {
    return { state: "absent", rec: null };
  }
}

export function inspectClearFence(busHome: string, handle: string): ClearFenceState {
  return inspectClearFenceRecord(busHome, handle).state;
}

function paneEffectFence(
  authority?: SubmitAuthority,
): Extract<SubmitResult, { status: "team_reset_fenced" | "clearing" }> | null {
  if (!authority?.busHome) return null;
  const reset = resetFenceRefusal(authority.busHome, "tap send");
  if (reset) return { status: "team_reset_fenced", ...reset };
  const recipientBus = authority.recipientBusHome || authority.busHome;
  if (recipientBus !== authority.busHome) {
    const remoteReset = resetFenceRefusal(recipientBus, "tap send (recipient bus)");
    if (remoteReset) return { status: "team_reset_fenced", ...remoteReset };
  }
  if (!authority.recipient) return null;
  const clear = inspectClearFenceRecord(recipientBus, authority.recipient);
  if (clear.state === "live") {
    return { status: "clearing", detail: `seat '${authority.recipient}' is mid-clear` };
  }
  if (clear.state === "expired" && noticeExpiredAtSendDoor(recipientBus, authority.recipient, clear.rec)) {
    process.stderr.write(
      `tap send: WARNING: clear fence for ${authority.recipient} expired; delivering anyway (fail-open past the family await ceiling)\n`,
    );
  }
  return null;
}

export { renderSentinel };
