// `tap session list` — the native session snapshot behind `tap session [list]`.
// Port of session/launcher.py cmd_list and its list-only helpers (render_table,
// completion_names, recency_key, machine_registry_session_state), deleted in the
// same PR; the shared read path reuses the live twins (registry resolution via
// index-home, the relaunch predicate via complete.ts, revive tiers via
// resume-identity, root resolution via bushome, the tmux seam via tmux.ts, and
// team.ts's table renderer). The rubric is BYTE fidelity: JSON compact +
// ensure_ascii in the incumbent's insertion order, the fixed 9-column table with
// width pressure on cwd only, refusals as `tap session: <msg>` (rc 2) or, under
// TAP_JSON=1, the session_error envelope on stdout. One deliberate drift: the
// header row carries no tty styled() wrapper — plain bytes on every door.
//
// Further ruled deviations (ceiling-400 brief, BIN B): a BOM-prefixed acting
// registry is ACCEPTED (the decoder strips U+FEFF); parse faults keep the JS
// SyntaxError message instead of CPython prose; NaN/Infinity literals refuse;
// and ordering is native UTF-16, which differs from Python only for astral-vs-
// private-use names — no consumer branches on any of the three.
import { readFileSync } from "node:fs";
import { ensureAscii } from "../fsatomic";
import { isRegularFile, loadGlobalRegistry } from "../index-home";
import { errorJson } from "../native-error";
import { ServerUnresponsive, tmuxReadOnly } from "../tmux";
import { HARNESSES } from "./catalog";
import { actingRegistryPath, isDict, nonEmpty, pathIsUnder, payloadRecords, realOrSelf, rootForCwd, sessionHandle, SessionStateError as ListRefusal, type Row, type SessionRecord as ListRecord } from "./records";
import { reviveTier } from "./resume-identity";
import { table } from "../verbs/team";

const TMUX_REFUSAL = "tmux session-name snapshot is unobservable; refusing to treat the session namespace as empty";
const TMUX_NO_SERVER = [/^no server running on .+$/, /^error connecting to .+ \(No such file or directory\)$/];

function tmuxNames(): Set<string> {
  let run;
  try {
    run = tmuxReadOnly(["list-sessions", "-F", "#S"]);
  } catch (error) {
    // The shared seam's one known transport failure (client deadline / fork
    // failure) is the same unobservable namespace as a crashed tmux; anything
    // else is a programming error and propagates.
    if (error instanceof ServerUnresponsive) throw new ListRefusal(TMUX_REFUSAL);
    throw error;
  }
  if (run.code === 0) return new Set(run.stdout.split("\n").filter((line) => line.length > 0));
  const stderr = run.stderr.trim();
  if (TMUX_NO_SERVER.some((pattern) => pattern.test(stderr))) return new Set();
  // A missing tmux binary lands here too: empty stderr is not a no-server
  // answer, and an unobservable namespace must not read as empty.
  throw new ListRefusal(TMUX_REFUSAL);
}

function readRegistryDoc(path: string): Row {
  let doc: unknown;
  try {
    doc = JSON.parse(readRegistryText(path));
  } catch (error) {
    throw new ListRefusal(`acting registry unreadable: ${(error as Error).message}; next: tap doctor`);
  }
  if (!isDict(doc)) throw new ListRefusal("acting registry root is not an object; next: tap doctor");
  return doc;
}

/** Strict-UTF-8 read whose decoder strips a leading BOM (TextDecoder's default
 *  polarity): a BOM-prefixed acting registry is accepted, the ruled deviation
 *  from the incumbent's plain-utf8 decoder (BIN B, ceiling-400 brief). Parse
 *  faults keep the JS SyntaxError message — no parser-prose compatibility. */
function readRegistryText(path: string): string {
  return new TextDecoder("utf-8", { fatal: true }).decode(readFileSync(path));
}

/** load_state_doc twin: a MISSING team registry is an empty walk, not an error;
 *  a present-but-broken one throws raw for the walk's caller to label with the
 *  team name. */
function loadTeamDoc(path: string): Row | null {
  if (!isRegularFile(path)) return null;
  const doc = JSON.parse(readRegistryText(path));
  if (!isDict(doc)) throw new Error(`registry state doc is not an object: ${path}`);
  return doc;
}

function cwdStateRecords(cwd: string): ListRecord[] {
  const root = rootForCwd(cwd);
  const path = actingRegistryPath(root);
  return path ? payloadRecords(readRegistryDoc(path), root) : [];
}

function machineStateRecords(cwd: string): ListRecord[] {
  const snapshot = loadGlobalRegistry();
  if (snapshot.marker === "invalid") throw new ListRefusal("global registry is invalid; next: tap doctor");
  if (snapshot.marker === "absent") return cwdStateRecords(cwd);
  const teams = snapshot.doc!.teams;
  if (!isDict(teams)) return [];
  const records: ListRecord[] = [];
  for (const [teamName, enrollment] of Object.entries(teams)) {
    if (!isDict(enrollment) || String(enrollment.state ?? "registered") === "historical") continue;
    const root = enrollment.root;
    const location = enrollment.registry_location;
    if (!nonEmpty(root) || !nonEmpty(location)) continue;
    let payload: Row | null;
    try {
      payload = loadTeamDoc(location);
    } catch (error) {
      throw new ListRefusal(`acting registry for team '${teamName}' is unreadable: ${(error as Error).message}; next: tap doctor`);
    }
    if (payload) records.push(...payloadRecords(payload, root));
  }
  return records;
}

function sessionListJson(records: ListRecord[], liveNames: Set<string>, machine: boolean): string {
  const sessions = records.map((record) => {
    const row: Row = {
      name: record.name, harness: record.harness, cwd: record.cwd,
      live: liveNames.has(record.name), seated: true, restorable: true,
      revive: reviveTier(record.harness, record.harnessSessionId),
      model: record.model, tag: record.tag, handle: sessionHandle(record),
      last_seen: record.lastSeen, last_launched: record.lastLaunched,
    };
    if (record.preset) row.preset = record.preset;
    return row;
  });
  return ensureAscii(JSON.stringify({ ok: true, sessions, count: sessions.length, scope: machine ? "machine" : "cwd" }));
}

const HEADERS = ["name", "harness", "live", "seated", "revive", "model", "preset", "last seen", "cwd"];

/** completion_names: cwd-matching rows first, then name, then unseen tmux. */
function completionNames(records: ListRecord[], harness: string | null, cwd: string, tmux: Set<string>): string[] {
  const cwdReal = realOrSelf(cwd);
  const under = (record: ListRecord) => (realOrSelf(record.cwd) === cwdReal ? 0 : 1);
  const names = records
    .filter((record) => !harness || record.harness === harness)
    .sort((a, b) => under(a) - under(b) || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
    .map((record) => record.name);
  const seen = new Set(names);
  for (const name of [...tmux].sort()) {
    if (!seen.has(name)) {
      names.push(name);
      seen.add(name);
    }
  }
  return names;
}

interface ListArgs {
  harness: string | null; cwd: string; all: boolean; live: boolean;
  machine: boolean; json: boolean; namesOnly: boolean; includeTmux: boolean;
}

const FLAGS = { "--all": "all", "--live": "live", "--machine": "machine", "--json": "json", "--names-only": "namesOnly", "--include-tmux": "includeTmux" } as const;
const USAGE = "usage: tap session list [--harness HARNESS] [--cwd CWD] [--all] [--live] [--machine] [--json] [--names-only] [--include-tmux]\n";

function parseListArgs(argv: string[]): ListArgs {
  const args: ListArgs = { harness: null, cwd: process.cwd(), all: false, live: false, machine: false, json: false, namesOnly: false, includeTmux: false };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!;
    const valued = arg.match(/^--(harness|cwd)(?:=(.*))?$/);
    if (valued) {
      const value = valued[2] ?? argv[++i];
      if (value === undefined) throw new Error("usage");
      if (valued[1] === "cwd") args.cwd = value;
      else {
        if (!HARNESSES.includes(value)) throw new Error("usage");
        args.harness = value;
      }
      continue;
    }
    const flag = FLAGS[arg as keyof typeof FLAGS];
    if (!flag) throw new Error("usage");
    args[flag] = true;
  }
  return args;
}

function recencyLess(a: ListRecord, b: ListRecord): number {
  const key = (record: ListRecord) => record.lastSeen ?? record.lastLaunched ?? "";
  const first = key(a), second = key(b);
  // One order for every view: (recency, name) descending, stable for ties.
  return first < second ? 1 : first > second ? -1 : a.name < b.name ? 1 : a.name > b.name ? -1 : 0;
}

function renderList(args: ListArgs): number {
  const records = args.machine ? machineStateRecords(args.cwd) : cwdStateRecords(args.cwd);
  const liveNames = tmuxNames();
  if (args.namesOnly && args.includeTmux) {
    const names = completionNames(records, args.harness, args.cwd, liveNames);
    if (names.length) process.stdout.write(`${names.join("\n")}\n`);
    return 0;
  }
  // The incumbent re-probes git per record for in_scope; the cwd is constant,
  // so the root is computed once — same answer, fewer children.
  const scopeRoot = args.machine ? null : rootForCwd(args.cwd);
  const filtered = records.filter((record) =>
    (!args.harness || record.harness === args.harness)
    && (!scopeRoot || pathIsUnder(record.cwd, scopeRoot))
    && (!args.live || liveNames.has(record.name)));
  filtered.sort(recencyLess);
  if (args.json) {
    process.stdout.write(`${sessionListJson(filtered, liveNames, args.machine)}\n`);
    return 0;
  }
  if (filtered.length === 0) {
    if (!args.namesOnly) process.stdout.write("tap session: no sessions\n");
    return 0;
  }
  if (args.namesOnly) {
    process.stdout.write(`${filtered.map((record) => record.name).join("\n")}\n`);
    return 0;
  }
  process.stdout.write(table(HEADERS, filtered.map((record) => [
    record.name,
    record.harness,
    liveNames.has(record.name) ? "yes" : "no",
    "yes",
    reviveTier(record.harness, record.harnessSessionId),
    record.model ?? "-",
    record.preset?.name ?? "-",
    record.lastSeen ?? "-",
    record.cwd,
  ])));
  return 0;
}

export function cmdSessionList(argv: string[]): number {
  let args: ListArgs;
  try {
    args = parseListArgs(argv);
  } catch {
    process.stderr.write(USAGE);
    return 2;
  }
  try {
    return renderList(args);
  } catch (error) {
    if (!(error instanceof ListRefusal)) throw error;
    if (process.env.TAP_JSON === "1") process.stdout.write(errorJson("session_error", "tap help session", error.message));
    else process.stderr.write(`tap session: ${error.message}\n`);
    return 2;
  }
}

if (import.meta.main) process.exitCode = cmdSessionList(process.argv.slice(2));
