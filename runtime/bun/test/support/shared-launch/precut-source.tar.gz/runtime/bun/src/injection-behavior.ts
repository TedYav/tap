import { readFileSync } from "node:fs";
import { join } from "node:path";
import { configDirectory, table } from "./launcher/catalog";

export type InjectionBehavior = "clobber" | "warn";
export function injectionBehavior(env: NodeJS.ProcessEnv = process.env): InjectionBehavior {
  let doc: Record<string, any>;
  try { doc = Bun.TOML.parse(readFileSync(join(configDirectory(env), "config.toml"), "utf8")); }
  catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return "clobber"; throw error; }
  if (doc.injection !== undefined && !table(doc.injection)) throw new Error("injection must be a TOML table");
  const value = doc.injection?.behavior ?? "clobber";
  if (value !== "clobber" && value !== "warn") throw new Error("injection.behavior must be clobber or warn");
  return value;
}

/** Existing standard grace records remain readable across the upgrade. */
export function draftClobberDue(meta: Record<string, unknown>, now: number, behavior: InjectionBehavior): boolean {
  const raw = meta.draft_deadline_epoch ?? (meta.waiter_lifetime === "grace-window" ? meta.deadline_epoch : undefined);
  const deadline = typeof raw === "number" ? raw : typeof raw === "string" && /^\d+$/.test(raw) ? Number(raw) : NaN;
  return behavior === "clobber" && Number.isFinite(deadline) && deadline > 0 && now >= deadline;
}

export function queuedDraftClobberDue(spool: string, id: string, now = Date.now() / 1000): boolean {
  const meta = JSON.parse(readFileSync(join(spool, `${id}.meta.json`), "utf8"));
  return draftClobberDue(meta, now, injectionBehavior());
}

/** One pass over candidate rows; fresh drafts do not join older due notes. */
export function digestDraftPlan(rows: string, spool: string, now: number, cap = 32, mode = injectionBehavior()): string {
  if (!Number.isSafeInteger(cap)) throw new Error("TAP_DIGEST_MAX_ITEMS must be an integer");
  cap = Math.max(2, cap);
  const groups = new Map<string, {id: string; auto: boolean}[]>();
  for (const line of rows.split("\n")) {
    const f = line.split("\x1f"); if (f.length !== 9) continue;
    const id = f[6]!, ready = f[8]!;
    if (ready !== "ready") {
      if (ready !== "busy:pending") continue;
      let meta: Record<string, unknown>;
      try { meta = JSON.parse(readFileSync(join(spool, `${id}.meta.json`), "utf8")); } catch { continue; }
      if (!draftClobberDue(meta, now, mode)) continue;
    }
    const key = f.slice(0, 5).join("\x1f");
    const group = groups.get(key) ?? []; group.push({id, auto: f[7] !== "plain"}); groups.set(key, group);
  }
  const output: string[] = [];
  for (const [key, group] of groups) {
    for (let i = 0; i < group.length; i += cap) {
      const chunk = group.slice(i, i + cap);
      if (chunk.length > 1 || chunk.some(row => row.auto)) output.push(`${key}\x1f${chunk.map(row => row.id).join(" ")}`);
    }
  }
  return output.length ? output.join("\n") + "\n" : "";
}

if (import.meta.main) {
  try {
    const [op, spool, id] = process.argv.slice(2);
    if (op === "mode") console.log(injectionBehavior());
    else if (op === "plan" && spool && id) process.stdout.write(digestDraftPlan(await Bun.stdin.text(), spool, Number(id), Number(process.env.TAP_DIGEST_MAX_ITEMS || 32)));
    else if (op === "cue" && spool && id) {
      const meta = JSON.parse(readFileSync(join(spool, `${id}.meta.json`), "utf8"));
      console.log(`${meta.cue_red_at ?? ""}\x1f${meta.draft_deadline_epoch ?? meta.deadline_epoch ?? ""}`);
    }
    else throw new Error("invalid injection behavior operation");
  } catch (error) { console.error(`tap injection: ${String(error)}`); process.exitCode = 1; }
}
