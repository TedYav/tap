import { approvalPrompt } from "./agent-state";
import { opencodeTerminalOverprint } from "./opencode-composer";
import { agyComposer, agyPermissionOverlay, agySurveyOverlay, composerInput, readComposerFrame } from "./submit-frame";
import { codexQueuedRows } from "./slices/delivery-disposition";
import { dimPlaceholder } from "./terminal-text";
// Typed band + active-input observation. Family authority is bound.harness,
// never chrome and never a raw pane_current_command guess.
import {
  capturePane,
  normalizeInputMatch,
  observeInputRegion,
  observePaneResult,
  tmux,
} from "./tmux";
import { pendingInputText, type PaneIo } from "./pane/reader";

export type InputObservation =
  | { state: "present"; text: string }
  | { state: "chip"; text: string }
  | { state: "absent" }
  | { state: "unobservable"; reason: string }
  | { state: "rate_limited"; reason: string }
  | { state: "gone" };

export type PaneBand =
  | { state: "ready" }
  | { state: "busy"; text: string; queued?: boolean }
  | { state: "unobservable"; reason: string }
  | { state: "rate_limited"; reason: string }
  | { state: "gone" };

/** R5 six-state vocabulary. Frozen; a semantic change is a HOLD for sol. */
export type PaneKind = "ready" | "draft" | "no-band" | "copy-mode" | "gone" | "rate-limited";

export type ClassifiedPane =
  | { kind: "queued"; text: string }
  | { kind: "ready" }
  | { kind: "draft"; text: string }
  | { kind: "no-band"; reason: string }
  | { kind: "copy-mode" }
  | { kind: "gone" }
  | { kind: "rate-limited"; reason: string };

/** U+2500 run floor. Footer after the border is chrome, not draft. */
export const CLAUDE_BORDER_CELLS = 10;

const CLAUDE_PROMPT = /^[ \t]*[›❯]\s*(.*)$/;

/**
 * Proof that the classifier consumes only the frame its caller supplies:
 * the pane reader may never sample the pane again behind classifyPane's back.
 */
const NO_RECAPTURE: PaneIo = {
  capture() {
    throw new Error("classifyPane must classify the supplied frame, not recapture the pane");
  },
  paneWidth() {
    return "";
  },
};

/** After a live first peek, an unobservable later read may mean the pane vanished. */
function afterLiveNoBand(target: string, reason: string): ClassifiedPane {
  const again = panePresence(target);
  if (again?.state === "gone") return { kind: "gone" };
  if (again?.state === "rate_limited") return { kind: "rate-limited", reason: again.reason };
  return { kind: "no-band", reason };
}

function plain(s: string): string {
  return s
    .replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)/g, "")
    .replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "");
}

function isClaudeBottomBorder(line: string): boolean {
  const vis = plain(line).replace(/^[ \t]+/, "").replace(/[ \t]+$/, "");
  return /^─+$/.test(vis) && vis.length >= CLAUDE_BORDER_CELLS;
}

function isClaudeBoxFence(line: string): boolean {
  return /^[ \t]*─{10,}/.test(plain(line));
}

/** Feedback panel immediately above the live composer, never transcript prose. */
export function claudeFeedbackOverlay(capture: string): boolean {
  const lines = plain(capture).split("\n").map(line => line.trim());
  let prompt = lines.length;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (/^[›❯](?:\s|$)/.test(lines[i]!)) { prompt = i; break; }
  }
  let bottom = -1;
  for (let i = prompt - 1; i >= 0; i--) {
    if (/^╰─{10,}╯$/.test(lines[i]!)) { bottom = i; break; }
    if (lines[i] && !/^─{10,}.*$/.test(lines[i]!)) return false;
  }
  if (bottom < 0) return false;
  let top = bottom - 1;
  while (top >= 0 && /^│.*│$/.test(lines[top]!)) top--;
  if (top < 0 || !/^╭─{10,}╮$/.test(lines[top]!)) return false;
  const body = lines.slice(top + 1, bottom);
  return /^│\s*✻ Bug report drafted:/.test(body[0] ?? "")
    && /^│\s*1 to review · 2 to send · 0 to dismiss\s*│$/.test(body.at(-1) ?? "");
}

/** Active Claude box: last qualifying bottom border, then the prompt above it. */
export function claudeBox(capture: string): { typed: string; raw: string; columns: number } | null {
  const range = claudeActiveBoxRange(capture);
  if (!range) return null;
  const { top, start, bot } = range;
  const lines = capture.split("\n");
  const first = plain(lines[start]!).match(CLAUDE_PROMPT)![1]!;
  const raw = [first, ...lines.slice(start + 1, bot).map(plain)].join("\n");
  const typed = raw.replace(/[ \t]+$/gm, "").trim();
  return { typed, raw, columns: plain(lines[bot]!).trim().length };
}

/**
 * Shared active-box geometry: the [top, bot) row span `claudeBox` reads, with
 * `start` the composer prompt row. Same refusals: feedback overlay, approval
 * dialog, prompt rows below the bottom border, or no prompt inside the box.
 */
function claudeActiveBoxRange(capture: string): { top: number; start: number; bot: number } | null {
  if (claudeFeedbackOverlay(capture) || approvalPrompt("claude", capture)) return null;
  const lines = capture.split("\n");
  let bot = -1;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (isClaudeBottomBorder(lines[i]!)) { bot = i; break; }
  }
  if (bot < 0 || lines.slice(bot + 1).some(line => CLAUDE_PROMPT.test(plain(line)))) return null;
  let top = 0;
  for (let i = bot - 1; i >= 0; i--) {
    if (isClaudeBoxFence(lines[i]!)) { top = i + 1; break; }
  }
  let start = -1;
  for (let i = top; i < bot; i++) {
    if (CLAUDE_PROMPT.test(plain(lines[i]!))) { start = i; break; }
  }
  if (start < 0) return null;
  return { top, start, bot };
}

/**
 * Queued-but-unaccepted messages parked above the active box's top fence.
 *
 * Claude renders a delivered message the harness has not yet consumed as an
 * INDENTED prompt row directly above the fence, wrapped continuations indented
 * beneath it. Transcript prompt rows sit at column 0, so the indent is what
 * separates a queued message from transcript prose. Parsing reuses the exact
 * bounded box `claudeBox` recognizes — no active box, no rows.
 */
export function claudeQueuedRows(capture: string): string[] {
  const range = claudeActiveBoxRange(capture);
  if (!range) return [];
  const lines = capture.split("\n");
  const fence = range.top - 1;
  if (fence < 0 || !isClaudeBoxFence(lines[fence]!)) return [];
  const rows: string[] = [];
  let continuations: string[] = [];
  for (let i = fence - 1; i >= 0; i--) {
    const text = plain(lines[i]!);
    if (!text.trim()) continue;
    const queued = text.match(/^[ \t]+[›❯]\s*(.*)$/);
    if (queued) {
      rows.unshift([queued[1]!.replace(/[ \t]+$/, ""), ...continuations].join("\n"));
      continuations = [];
      continue;
    }
    if (/^[ \t]+\S/.test(text)) {
      continuations.unshift(text.trim());
      continue;
    }
    break;
  }
  return rows;
}

/**
 * Claude's dim `Press up to edit queued messages` idle hint is chrome, not a
 * draft: only that exact sentence reads as ready, and only when the
 * dimPlaceholder paint on the prompt row AND bounded queued rows above the
 * fence BOTH hold. Any other dim sentence, a human-typed sentence, or a
 * missing queue stays a draft.
 */
function claudeQueuedChrome(capture: string, typed: string): boolean {
  if (typed !== "Press up to edit queued messages") return false;
  if (!claudeQueuedRows(capture).length) return false;
  const range = claudeActiveBoxRange(capture);
  if (!range) return false;
  return dimPlaceholder(capture.split("\n")[range.start] ?? "", typed, "claude");
}

function familyOf(harness: string): string {
  const name = (harness.split("/").pop() ?? harness).toLowerCase();
  if (name.startsWith("claude")) return "claude";
  return name;
}

/** Incumbent paste-collapse chip shapes, keyed by live pane command. */
export function isPasteCollapse(paneCommand: string, text: string): boolean {
  if (/^(claude|cursor)/.test(paneCommand)) return /\[Pasted text( #[0-9]+)?( \+[0-9]+ lines)?\]/.test(text);
  if (/^codex/.test(paneCommand)) return /\[Pasted Content [0-9]+ chars\]/.test(text);
  if (/^opencode/.test(paneCommand)) return /\[Pasted ~[0-9]+ lines\]/.test(text);
  return false;
}

function panePresence(target: string): { state: "gone" } | { state: "rate_limited" | "unobservable"; reason: string } | null {
  const live = observePaneResult(target);
  if (live.status === "rate_limited") {
    return { state: "rate_limited", reason: "tmux client budget exhausted before pane input could be inspected" };
  }
  if (live.status === "pane_gone") return { state: "gone" };
  if (live.status === "unobservable") return { state: "unobservable", reason: live.reason };
  return null;
}

/** Budgeted `#{pane_in_mode}` peek. Never cancels copy-mode. */
export type CopyModeObservation =
  | { status: "copy-mode" }
  | { status: "normal" }
  | { status: "unobservable"; reason: string }
  | { status: "rate-limited"; reason: string }
  | { status: "gone" };

export function observeCopyMode(target: string): CopyModeObservation {
  const mode = tmux(["display-message", "-p", "-t", target, "#{pane_in_mode}"]);
  if (mode.rateLimited) {
    return { status: "rate-limited", reason: "tmux client budget exhausted before copy-mode could be inspected" };
  }
  if (mode.code !== 0) {
    const again = panePresence(target);
    if (again?.state === "gone") return { status: "gone" };
    if (again?.state === "rate_limited") return { status: "rate-limited", reason: again.reason };
    return { status: "unobservable", reason: `could not read copy-mode flag for '${target}'` };
  }
  const flag = mode.stdout.trim();
  if (flag === "1") return { status: "copy-mode" };
  if (flag === "0") return { status: "normal" };
  return { status: "unobservable", reason: `unrecognized pane_in_mode ${JSON.stringify(flag)}` };
}

export function toPaneBand(classified: ClassifiedPane): PaneBand {
  switch (classified.kind) {
    case "ready": return { state: "ready" };
    case "draft": return { state: "busy", text: classified.text };
    case "queued": return { state: "busy", text: classified.text, queued: true };
    case "gone": return { state: "gone" };
    case "rate-limited": return { state: "rate_limited", reason: classified.reason };
    case "copy-mode": return { state: "unobservable", reason: "pane is in copy-mode" };
    case "no-band": return { state: "unobservable", reason: classified.reason };
  }
}

/** Owner/delivery seam: six-state kind, including copy-mode. Do not substitute paneState(). */
export function toPaneProbe(classified: ClassifiedPane): { kind: PaneKind } {
  return { kind: classified.kind === "queued" ? "no-band" : classified.kind };
}

/**
 * Typed copy-mode surface for Courier owner delivery (tap-nwgh8 U1).
 * Callers consume this instead of the Courier-local `#{pane_in_mode}` peek.
 * `paneState()` stays the frozen PaneBand path and still collapses copy-mode.
 */
export function observePaneProbe(target: string, harness: string, command: string): { kind: PaneKind } {
  return toPaneProbe(observePaneKind(target, harness, command));
}

/**
 * Shared classifier over captured bytes. Cursor and Hermes read the pane
 * reader's verdict on the supplied frame; every other unsupported family
 * classifies no-band.
 */
export function classifyPane(capture: string, harness: string, copyMode: boolean): ClassifiedPane {
  if (copyMode) return { kind: "copy-mode" as const };
  if (approvalPrompt(harness, capture)) return { kind: "no-band", reason: "human approval prompt is visible" };
  if (familyOf(harness) === "claude") {
    if (claudeFeedbackOverlay(capture)) return { kind: "no-band", reason: "Claude feedback dialog is visible" };
    const box = claudeBox(capture);
    if (!box) return { kind: "no-band", reason: "no recognized Claude input box" };
    if (box.typed && !claudeQueuedChrome(capture, box.typed)) return { kind: "draft", text: box.typed };
    return { kind: "ready" };
  }
  if (familyOf(harness).startsWith("codex")) {
    const composer = readComposerFrame(capture, "codex");
    if (composer === null) return { kind: "no-band", reason: "no recognized Codex composer" };
    if (composer) return { kind: "draft", text: composer };
    const queued = codexQueuedRows(capture);
    if (queued.length) return { kind: "queued", text: queued.join("\n") };
    return { kind: "ready" };
  }
  if (familyOf(harness) === "opencode") {
    if (opencodeTerminalOverprint(capture)) {
      return { kind: "no-band", reason: "OpenCode terminal overprint obscures the composer" };
    }
    const composer = readComposerFrame(capture, "opencode");
    if (composer === null) return { kind: "no-band", reason: "no recognized OpenCode composer" };
    return composer ? { kind: "draft", text: composer } : { kind: "ready" };
  }
  if (familyOf(harness) === "agy") {
    if (agySurveyOverlay(capture)) return { kind: "no-band", reason: "Antigravity survey blocks the composer" };
    if (agyPermissionOverlay(capture)) return { kind: "no-band", reason: "Antigravity permission overlay is visible" };
    const composer = agyComposer(capture);
    if (composer === null) return { kind: "no-band", reason: "no recognized Antigravity composer" };
    return composer ? { kind: "draft", text: composer } : { kind: "ready" };
  }
  const family = familyOf(harness);
  if (family.startsWith("cursor") || family.startsWith("hermes")) {
    const pending = pendingInputText(NO_RECAPTURE, "", family, capture);
    if (pending.status === "text") {
      // The prompt row is only the LAST row of a typed draft, and an empty
      // prompt row can still sit above typed continuation rows. The full
      // active composer on the SAME supplied frame decides readiness, not
      // the row alone; when bounded geometry is unavailable the row stays
      // the conservative fallback.
      const composer = composerInput(capture, family);
      // composerInput models awk's emitted trailing newline; this is an
      // in-process caller, so strip exactly that synthetic terminator and
      // keep real hard newlines.
      let text = composer.state === "text" ? composer.text.replace(/\n$/, "") : "";
      // The reader collapses the idle placeholder on the prompt row, but the
      // composer's generic branch has no dim model — so for hermes its text
      // is chrome unless the region extends past the prompt row.
      if (family.startsWith("hermes") && pending.text === "" && !text.startsWith("\n")) text = "";
      if (text === "") text = pending.text;
      return text === "" ? { kind: "ready" } : { kind: "draft", text };
    }
    return { kind: "no-band", reason: `no readable ${family} prompt row in the supplied frame` };
  }
  return { kind: "no-band", reason: "no shared classifier for this harness" };
}

/**
 * Six-state live observation for Courier owner delivery. Copy-mode is
 * `copy-mode`, never collapsed to no-band. Reads `#{pane_in_mode}` only.
 */
export function observePaneKind(target: string, harness: string, command: string): ClassifiedPane {
  const presence = panePresence(target);
  if (presence?.state === "gone") return { kind: "gone" };
  if (presence?.state === "rate_limited") return { kind: "rate-limited", reason: presence.reason };
  if (presence?.state === "unobservable") return { kind: "no-band", reason: presence.reason };
  const mode = observeCopyMode(target);
  if (mode.status === "gone") return { kind: "gone" };
  if (mode.status === "rate-limited") return { kind: "rate-limited", reason: mode.reason };
  if (mode.status === "unobservable") return afterLiveNoBand(target, mode.reason);
  if (mode.status === "copy-mode") return { kind: "copy-mode" };
  // Family authority is the bound harness; the pane command is only the
  // empty-harness fallback.
  const family = familyOf(harness || command);
  const native = family === "claude" || family.startsWith("codex") ||
    family === "opencode" || family === "agy" ||
    family.startsWith("cursor") || family.startsWith("hermes");
  if (native) {
    const escaped = family.startsWith("codex") || family.startsWith("cursor") || family.startsWith("hermes");
    const captured = capturePane(target, escaped, family !== "opencode");
    if (captured.rateLimited) {
      return { kind: "rate-limited", reason: "tmux client budget exhausted before pane input could be inspected" };
    }
    if (captured.code !== 0) {
      return afterLiveNoBand(target, `capture-pane failed for '${target}'`);
    }
    return classifyPane(captured.stdout, harness || command, false);
  }
  return afterLiveNoBand(target, "no shared classifier for this harness");
}

/**
 * Pre-inject band. `harness` is BoundRecipient.harness; `command` is the
 * authorized observation's currentCommand for prompt-glyph matching only.
 * Copy-mode maps to unobservable here so submitVerify refuses without a
 * PaneBand expansion; owner delivery must call observePaneKind instead.
 */
export function paneState(target: string, harness: string, command: string): PaneBand {
  return toPaneBand(observePaneKind(target, harness, command));
}

/** Land/clear observation of one id in the active band. */
export function observeInputId(target: string, command: string, id: string): InputObservation {
  const presence = panePresence(target);
  if (presence) return presence;
  const captured = observeInputRegion(target, command);
  if (captured.status === "rate_limited") {
    return { state: "rate_limited", reason: captured.reason };
  }
  if (captured.status === "unobservable") {
    return { state: "unobservable", reason: captured.reason };
  }
  if (captured.status === "no_prompt") {
    return { state: "unobservable", reason: `no input prompt is visible in '${target}' (the harness may be mid-turn)` };
  }
  const region = captured.region;
  if (normalizeInputMatch(region).includes(normalizeInputMatch(id))) {
    return { state: "present", text: region };
  }
  if (isPasteCollapse(command, region)) {
    return { state: "chip", text: region };
  }
  return { state: "absent" };
}
