import { launch, LaunchInterrupted } from "./launch";

export async function launchCli(args: string[]): Promise<number> {
  try { return await launch(args); }
  catch (error) {
    const message = (error as Error).message;
    if (process.env.TAP_JSON === "1" || args.includes("--json")) {
      const tagged = error as Error & { tapErrorClass?: string; tapAction?: string };
      const match = /^([a-z_]+): (.*)$/s.exec(message);
      process.stdout.write(JSON.stringify({ ok: false, error_class: tagged.tapErrorClass ?? match?.[1] ?? "session_error",
        action: tagged.tapAction ?? "tap help session", detail: match?.[2] ?? message }) + "\n");
    } else process.stderr.write(`tap session: ${message}\n`);
    return error instanceof LaunchInterrupted ? error.exitCode : 2;
  }
}

if (import.meta.main) process.exitCode = await launchCli(process.argv.slice(2));
