// The watch sidecar's lifecycle: ensure exactly one loop window for a team, and
// the guarded disarm that reaps it. Migration slice W1 moves `_watch_ensure_sidecar`,
// `_watch_off_guarded` and `tap_watch_reminders` out of tap-watch.sh. The verb
// layer (verbs/watch.ts) calls these with the context already resolved; remind.ts
// calls `offGuarded` IN-PROCESS inside its queue-lock body, which is what closes
// the `bash -c '. tap-watch.sh; _watch_off_guarded'` backcall it used to spawn.
//
// Stamped in the sidecar fingerprint through remind.ts, so this module imports
// only loop-safe leaves and takes bus, scripts dir, registry path and clock as
// arguments -- never a resolved context.
//
// What is carried from the incumbent, each pinned by a control:
//   - One loop per team under race: concurrent `on`s serialize on the atomic
//     `watch/.spawn.lock` mkdir mutex (macOS ships no flock(1)); a caller that
//     cannot acquire it within ~5 s skips ITS spawn and keeps the lease, and never
//     removes a mutex it does not hold. The same path a pre-upgrade Bash `on`
//     takes, so the two serialize with each other during the mixed window.
//   - Self-heal is OWNERSHIP-GATED: a window named `watch` is reaped only when its
//     pane pid equals the recorded `watcher_pid`; a foreign window sharing the name
//     is left alone and the caller is told to run `tap health`. A confirmed-ours
//     window whose process is alive and whose heartbeat is fresh (or absent: just
//     spawned, not yet ticked) is an idempotent skip; dead or stale is respawned.
//   - The spawned command is `TAP_HOME='<bus>' exec bun '<src>/watch-run.ts' run` (slice
//     W3: the loop is Bun) and the recorded `watcher_command` is `watch-run.ts run`:
//     `tap remind`'s reuse rule and `tap health` compare that string. A sidecar
//     started before W3 carries `tap-watch.sh run` until its first heartbeat after the
//     re-exec through the forward; both signatures are known, and a recorded one is
//     alive when the process at the recorded pid shows EITHER -- never any other
//     command (astra-pinnacle-migration-partner, W3 F1). The old signature retires
//     with the forward (W4).
//   - `offGuarded` is armer-owned unless `--force`; the forced path notices the
//     armer. Tints are cleared BEFORE the record (the only tint-ownership record)
//     is deleted; the locked disarm is fail-loud (lease KEPT, error surfaced,
//     nonzero); a sticky NOTIFY is cleared ONLY by an armer self-disarm; the
//     sidecar window is killed only when its pane pid still matches.

import { spawnSync } from "node:child_process";
import { mkdirSync, rmdirSync, rmSync } from "node:fs";
import { join } from "node:path";

import { markResetGenerationReused } from "./reset";
import { tmux, tmuxReadOnly } from "./tmux";
import { disarm, fieldValue, isFile, itemLines, readLoose, set as leaseSet } from "./watch-lease";
import { armPath, noticeOrNotify, notifyPath } from "./watch-notice";
import { repoRoot, teamSession } from "./watch-registry";
import { atLeast, BUN_FLOOR } from "./watch-run";

export const WATCHER_COMMAND = "watch-run.ts run";
/** The pre-W3 loop's signature: recorded by a sidecar that has not re-exec'd yet. */
export const LEGACY_WATCHER_COMMAND = "tap-watch.sh run";
export const WATCHER_SIGNATURES: ReadonlySet<string> = new Set([WATCHER_COMMAND, LEGACY_WATCHER_COMMAND]);

/**
 * `tap_supervision_pid_alive`: a live process whose command still contains <command>.
 * A recorded watcher signature is matched by either known one: between the forward's
 * re-exec and the Bun loop's first heartbeat the record says `tap-watch.sh run` while
 * `ps` shows `watch-run.ts run`, and that live loop must not be reaped as dead.
 */
export function pidAlive(pid: string, command: string): boolean {
  if (!/^[0-9]+$/.test(pid) || pid === "0") return false;
  const r = spawnSync("ps", ["-p", pid, "-o", "command="], { encoding: "utf8" });
  const out = (r.stdout ?? "").trim();
  if (!out) return false;
  if (!command) return true;
  const accepted = WATCHER_SIGNATURES.has(command) ? [...WATCHER_SIGNATURES] : [command];
  return accepted.some(sig => out.includes(sig));
}

/** `tap_watch_clear_tints`: untint every pane the record owns; best-effort throughout. */
export function clearTints(bus: string, env: NodeJS.ProcessEnv = process.env): void {
  for (const pane of itemLines(readLoose(armPath(bus)), "tinted_panes")) {
    if (!pane) continue;
    try { tmux(["select-pane", "-t", pane, "-P", "bg=default"], env); } catch { /* best-effort */ }
  }
}

function watchWindowPanePid(sess: string, env: NodeJS.ProcessEnv): string | null {
  const r = tmuxReadOnly(["list-windows", "-t", sess, "-F", "#{window_name} #{pane_pid}"], env);
  if (r.code !== 0) return null;
  for (const line of r.stdout.split("\n")) {
    const [name, pid] = line.split(" ", 2);
    if (name === "watch") return pid ?? "";
  }
  return null;
}

function staleThreshold(interval: string): number {
  const iv = /^[0-9]+$/.test(interval) ? Number(interval) * 3 : 0;
  return iv >= 180 ? iv : 180;
}

export interface SidecarArgs {
  bus: string;
  scripts: string;
  registry: string;
  armer: string;
  noSpawn: boolean;
  now: string;
  env?: NodeJS.ProcessEnv;
  /** The runtime the window runs the loop under: this process's Bun (version and executable) by default; a control's seams. */
  runtimeVersion?: string;
  runtimeExecutable?: string;
}

/** One shell word for the window's command line: single-quoted, an embedded quote closed and reopened. */
export function sq(word: string): string { return `'${word.replace(/'/g, "'\\''")}'`; }

/**
 * `_watch_ensure_sidecar`. Returns 0 when a loop is confirmed (spawned, or
 * already running and fresh) and 1 when the lease stands without a confirmed
 * runner -- every 1 path has already said why on stderr.
 */
export function ensureSidecar(a: SidecarArgs): number {
  const env = a.env ?? process.env;
  if (a.noSpawn) {
    process.stdout.write("tap watch: sidecar spawn skipped because TAP_WATCH_NO_SPAWN is set\n");
    return 0;
  }
  // The loop's entry refuses a Bun below its floor (`process.execve`) -- but only AFTER
  // the window is open and its pane pid recorded, which would read as "sidecar started"
  // over a loop that ended at once. Refuse here first, before any spawn or record write,
  // with the same line (chatgpt-codex-connector on #xxxx).
  const runtime = a.runtimeVersion ?? Bun.version;
  if (!atLeast(runtime, BUN_FLOOR)) {
    process.stderr.write(`tap watch: the sidecar loop needs bun ${BUN_FLOOR} or newer (process.execve); this is ${runtime}; sidecar not spawned, watch remains armed\n`);
    return 1;
  }
  const sess = teamSession(a.registry, a.armer, env);
  if (!sess) {
    process.stderr.write("tap watch: no team tmux session is available; sidecar not spawned, watch remains armed\n");
    return 1;
  }
  const mutex = join(a.bus, "watch", ".spawn.lock");
  mkdirSync(join(a.bus, "watch"), { recursive: true });
  let acquired = false;
  for (let waited = 0; waited <= 100; waited++) {
    try { mkdirSync(mutex); acquired = true; break; } catch { /* held */ }
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 50);
  }
  // Never acquired: another `watch on` owns the spawn -- skip ours rather than
  // proceed unsynchronized, and never rmdir a lock we do not hold. The lease stands.
  if (!acquired) {
    process.stderr.write("tap watch: another watch-on call holds the spawn lock; skipping sidecar spawn and keeping the watch armed\n");
    return 1;
  }
  try {
    const arm = armPath(a.bus);
    const winPid = watchWindowPanePid(sess, env);
    if (winPid !== null) {
      // T1 self-heal, ownership-gated: the name `watch` is NOT unique (a user window,
      // or another bus's sidecar in the same session, can share it). Confirm by the
      // recorded watcher_pid before touching anything.
      const rec = readLoose(arm);
      const wpid = fieldValue(rec, "watcher_pid");
      const wcmd = fieldValue(rec, "watcher_command");
      const hb = fieldValue(rec, "heartbeat_at");
      const thresh = staleThreshold(fieldValue(rec, "tick_interval_seconds") || "60");
      if (!wpid || wpid === "0" || winPid !== wpid) {
        process.stderr.write(`tap watch: a watch window in '${sess}' belongs to another process; leaving it untouched and keeping this watch armed; next: tap health\n`);
        return 1;
      }
      // Confirmed ours. Alive AND heartbeat-fresh -> idempotent skip (an empty/zero
      // heartbeat is a just-spawned loop that has not ticked -- don't race-kill it).
      const fresh = !hb || hb === "0" || (/^[0-9]+$/.test(hb) && Number(a.now) - Number(hb) <= thresh);
      if (pidAlive(wpid, wcmd) && fresh) {
        process.stdout.write(`tap watch: sidecar already running in session '${sess}'\n`);
        return 0;
      }
      process.stderr.write(`tap watch: sidecar in '${sess}' stopped responding; respawning it\n`);
      tmux(["kill-window", "-t", `${sess}:watch`], env);
    }
    const worktree = repoRoot(a.registry);
    // The window runs the loop under THE executable the floor check above described --
    // this process's Bun by absolute path, never a bare `bun` for the window's PATH to
    // resolve to some other install (sol-pinnacle-5, #xxxx round 2).
    const spawned = tmux(["new-window", "-d", "-P", "-F", "#{pane_pid}", "-t", sess, "-n", "watch", "-c", worktree,
      `TAP_HOME=${sq(a.bus)} exec ${sq(a.runtimeExecutable ?? process.execPath)} ${sq(join(import.meta.dir, "watch-run.ts"))} run`], env);
    if (spawned.code !== 0) {
      process.stderr.write(`tap watch: sidecar spawn failed in session '${sess}'\n`);
      return 1;
    }
    const panePid = spawned.stdout.trim();
    if (!/^[0-9]+$/.test(panePid) || panePid === "0") {
      process.stderr.write(`tap watch: sidecar spawn returned no valid process in session '${sess}'\n`);
      return 1;
    }
    try {
      if (leaseSet(arm, ["watcher_pid", panePid, "watcher_command", WATCHER_COMMAND], env) !== 0) return 1;
    } catch {
      return 1;
    }
    process.stdout.write(`tap watch: sidecar started in session '${sess}'\n`);
    return 0;
  } finally {
    try { rmdirSync(mutex); } catch { /* already gone */ }
  }
}

export interface OffArgs {
  bus: string;
  scripts: string;
  registry: string;
  actor: string;
  force: boolean;
  now: string;
  env?: NodeJS.ProcessEnv;
}

/**
 * `_watch_off_guarded`: called only through the reminder queue owner, which
 * holds its lock through reap. Every refusal and failure is reported on stderr
 * in `tap watch:` shape here and returned as 1; 0 means the lease is gone.
 */
export function offGuarded(a: OffArgs): number {
  const env = a.env ?? process.env;
  const arm = armPath(a.bus);
  const rec = readLoose(arm);
  const armedBy = fieldValue(rec, "armed_by");
  const sess = teamSession(a.registry, armedBy, env);
  const wpid = fieldValue(rec, "watcher_pid"); // captured BEFORE disarm deletes the record
  const actorShown = a.actor || "<unknown>";

  // tap-a4i/W-D3: disarm belongs to the armer. A non-armer (including an unknown
  // actor) must opt into the dead-armer escape with --force; the forced path keeps
  // the old loud notice behavior.
  if (armedBy && a.actor !== armedBy) {
    if (!a.force) {
      process.stderr.write(`tap watch: watch is armed by '${armedBy}'; '${actorShown}' cannot disarm it; next: ask '${armedBy}' to run tap watch off, or pass --force\n`);
      return 1;
    }
    // `set -e` in the incumbent's helper: a fallback that could not publish ended it here, lease kept
    if (noticeOrNotify({ bus: a.bus, scripts: a.scripts, to: armedBy, now: a.now, env,
      reason: `tap watch off was run by '${actorShown}' for a watch armed by '${armedBy}'.`,
      evidence: `actor=${a.actor || "unknown"}` }) !== 0) return 1;
  }

  clearTints(a.bus, env); // untint owned panes BEFORE the arm record (the only tint ownership record) is deleted
  // T9 fail-loud: no unlocked fallback. If the locked delete fails, keep the lease,
  // surface the error, return nonzero -- an armed-but-undismissed watch is visible in
  // `tap health` and recoverable by re-running `tap watch off`; a silent racy delete is neither.
  try {
    disarm(arm);
  } catch (error) {
    process.stderr.write(`tap watch: ${error instanceof Error ? error.message : String(error)}\n`);
    process.stderr.write("tap watch: warning: locked disarm failed; lease KEPT to avoid an unlocked racy delete. See 'tap health'; retry 'tap watch off'.\n");
    return 1;
  }
  markResetGenerationReused(a.bus, "watch");
  // Sticky-NOTIFY rule (#3): a pending human escalation is cleared ONLY by `tap watch ack`
  // or an ARMER self-disarm. A non-armer / unknown-actor disarm must NOT erase it.
  if (a.actor && a.actor === armedBy) {
    try { rmSync(notifyPath(a.bus), { force: true }); } catch { /* best-effort */ }
  }
  // Best-effort reap OUR sidecar window now -- the lease deletion already guarantees
  // the loop exits on its next tick. Ownership-gated exactly like the spawn path.
  if (sess && wpid && wpid !== "0") {
    const winPid = watchWindowPanePid(sess, env);
    if (winPid === wpid) tmux(["kill-window", "-t", `${sess}:watch`], env);
  }
  process.stdout.write(`tap watch: disarmed by '${a.actor || "?"}'\n`);
  return 0;
}

export interface RemindersArgs {
  bus: string;
  scripts: string;
  registry: string;
  owner: string;
  noSpawn: boolean;
  now: string;
  env?: NodeJS.ProcessEnv;
}

/**
 * `tap_watch_reminders --by <owner>`: the reminder queue has installed its minimal
 * lease; confirm a runner. An armed supervision loop with a live recorded command
 * and a fresh tick is reused without touching any window (its loop can be a child
 * of the pane shell, so pane-pid equality is not needed when no window will be
 * touched); otherwise ensure the sidecar. 1 when no runner is confirmed.
 */
export function remindersEntry(a: RemindersArgs): number {
  const env = a.env ?? process.env;
  const arm = armPath(a.bus);
  if (!a.owner || !isFile(arm)) return 1; // tap_watch_is_armed: `[ -f ]`
  const rec = readLoose(arm);
  const armedAt = fieldValue(rec, "armed_at");
  const pid = fieldValue(rec, "watcher_pid");
  const command = fieldValue(rec, "watcher_command");
  const heartbeat = fieldValue(rec, "heartbeat_at");
  const interval = fieldValue(rec, "tick_interval_seconds");
  const now = Number(a.now);
  if (fieldValue(rec, "mode") === "supervision" && WATCHER_SIGNATURES.has(command)
    && /^[0-9]+$/.test(heartbeat) && /^[0-9]+$/.test(interval) && Number(heartbeat) > 0 && Number(interval) > 0) {
    const age = now - Number(heartbeat);
    const limit = Math.max(Number(interval) * 3, 180);
    // The arm identity is rechecked before reporting success: `_watch_lease_current`.
    if (age >= 0 && age <= limit && pidAlive(pid, command)
      && isFile(arm) && fieldValue(readLoose(arm), "armed_at") === armedAt) {
      process.stdout.write(`tap remind: rides armed supervision watcher pid ${pid} (armed by ${fieldValue(rec, "armed_by")})\n`);
      return 0;
    }
  }
  return ensureSidecar({ bus: a.bus, scripts: a.scripts, registry: a.registry, armer: fieldValue(rec, "armed_by"), noSpawn: a.noSpawn, now: a.now, env });
}
