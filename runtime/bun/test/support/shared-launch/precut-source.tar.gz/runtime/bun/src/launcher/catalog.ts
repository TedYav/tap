import { closeSync, constants, fstatSync, openSync, readFileSync, realpathSync, statSync } from "node:fs";
import { createHash } from "node:crypto";
import { isAbsolute, join } from "node:path";
import { permissionMode, type PermissionMode } from "./permissions";
import { LauncherError } from "./types";
import { pyBlank } from "./catalog-metadata";
import type { Notices } from "./catalog-notices";
import { configDefaults, configOnly } from "./config-args";
import {
  isDocumentedRetiredCatalog, loadHarnessPolicy, loadPresetCatalog,
  policyDegradedNotice, readHarnessPolicyFromDisk, requirePreset,
} from "./catalog-listing";

export type Table = Record<string, unknown>;
export type Params = Record<string, string | boolean | string[]>;
export type CatalogSource = { path: string; digest: string; data: Table };
export type Preset = {
  harness: string;
  params: Params;
  env: Record<string, string>;
  provenance: { name: string; source_path: string; config_digest: string };
};
export const HARNESSES = ["claude", "codex", "opencode", "cursor", "agy", "hermes"];
/**
 * Is this parsed TOML value a TABLE?
 *
 * A Date is not, and saying otherwise is not pedantry: TOML has first-class
 * date scalars, `typeof aDate === "object"` is true, and `Object.keys(aDate)`
 * is empty -- so `presets = 1979-05-27` read as an EMPTY TABLE. The precedence
 * path then classified it as a vacant `[presets]` and fell back to the legacy
 * catalog, which is the one thing that branch must never do for a wrong-shape
 * value: it answers a botched migration by telling the operator to perform the
 * migration they just attempted.
 *
 * Every consumer of this predicate wants table semantics over parsed TOML --
 * preset entries, roles, intelligences, notes, precedence, params, env, harness
 * policy, discovery display, recovery shape. None of them wants a date.
 *
 * This does NOT mean dates are dropped: `jsonSafe` still serializes one carried
 * as an inert metadata annotation value. Being unable to act as a table and
 * being unable to travel as data are different questions.
 */
export const table = (value: unknown): value is Table => {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  // A TOML table parses to a PLAIN object. Anything carrying a class prototype
  // is a scalar wearing an object's typeof -- and enumerating those classes is
  // the trap: the first attempt at this excluded `Date`, and `Bun.TOML` returns
  // a Temporal `PlainDate`, so the guard looked right and caught nothing. Asking
  // what the value IS beats listing what it must not be, and it covers
  // PlainDateTime, PlainTime and Instant without naming any of them.
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
};

export function refuse(kind: string, detail: string, action?: string, code?: string): never {
  throw new LauncherError(`${kind}: ${detail}`, kind, action ?? null, detail, code);
}

/**
 * Locate the config directory. `XDG_CONFIG_HOME` wins when SET, not when valid.
 *
 * A relative `XDG_CONFIG_HOME` REFUSES rather than falling through to `$HOME`.
 * This reader used to fall through, and that is a silent wrong answer: the
 * operator set a variable, the launcher read a different file, and nothing said
 * so -- the same shape as "I changed it and nothing happened". A differential
 * against the incumbent measured the disagreement; the incumbent refuses, and it
 * is right. Ratified as a deliberate behavior change rather than folded in.
 *
 * An EMPTY `XDG_CONFIG_HOME` is falsy and still falls through to `$HOME`, which
 * matches the incumbent's truthiness test.
 */
export function configDirectory(env: NodeJS.ProcessEnv): string {
  const xdg = env.XDG_CONFIG_HOME;
  if (xdg) {
    if (!isAbsolute(xdg)) {
      refuse("preset_config_invalid",
             `invalid preset config ${join(xdg, "tap", "config.toml")}: XDG_CONFIG_HOME must be absolute`,
             `fix ${join(xdg, "tap", "config.toml")}`);
    }
    return join(xdg, "tap");
  }
  if (env.HOME) {
    if (!isAbsolute(env.HOME)) {
      refuse("preset_config_invalid",
             `invalid preset config ${join(env.HOME, ".config", "tap", "config.toml")}: HOME must be absolute when XDG_CONFIG_HOME is unset`,
             `fix ${join(env.HOME, ".config", "tap", "config.toml")}`);
    }
    return join(env.HOME, ".config", "tap");
  }
  return refuse("preset_config_invalid",
                "invalid preset config ${HOME}/.config/tap/config.toml: HOME is unset and XDG_CONFIG_HOME was not provided",
                "fix ${HOME}/.config/tap/config.toml");
}

/**
 * Validate the opened object and its path, then return its bytes VERBATIM.
 *
 * This is the security boundary, not a convenience: the descriptor is opened
 * once and every check below interrogates THAT descriptor, so a path swapped
 * between resolve and read refuses instead of being read. `realpath` +
 * dev/ino comparison is the TOCTOU re-check; deleting it is what a control
 * has to be able to catch.
 *
 * Bytes come back RAW — undecoded, BOM intact, unparsed. A caller that keeps
 * its own decoding (the digest-window writer reads the same file and must see
 * a leading BOM that `TextDecoder` would consume) consumes this directly
 * rather than re-reading the name, which would be a second, unchecked read.
 */
/**
 * The phases a secure read can fault in AFTER the open has succeeded. Native
 * callers get the native refusal for each; the Python facade's door supplies a
 * mapper that re-classes the same faults with the incumbent's texts (its
 * `read_secure_preset_bytes` wraps them in `_invalid`). Mapping lives with the
 * caller that requires it -- the shared reader stays native.
 */
export type SecureFaultPhase = "race" | "resolve" | "read";

export function readSecureBytes(
  path: string,
  mapFaults?: (phase: SecureFaultPhase, error: unknown) => never,
): { bytes: Buffer; resolvedPath: string; digest: string } {
  let fd: number;
  try {
    fd = openSync(path, constants.O_RDONLY | constants.O_NONBLOCK);
  } catch (error) {
    const err = error as NodeJS.ErrnoException;
    // An absent config is its own answer, and the incumbent names it:
    // `preset_config_missing`, remedied by creating the file. `code` is kept so
    // callers already branching on ENOENT keep working -- this adds a class, it
    // does not take one away.
    if (err.code === "ENOENT") {
      throw new LauncherError(
        `preset_config_missing: requested preset config does not exist: ${path}`,
        "preset_config_missing", `create ${path}`,
        `requested preset config does not exist: ${path}`, "ENOENT");
    }
    throw new LauncherError(
      `preset_config_invalid: invalid preset config ${path}: could not open file: ${err.message}`,
      "preset_config_invalid", `fix ${path}`,
      `invalid preset config ${path}: could not open file: ${err.message}`, err.code);
  }
  try {
    let info: ReturnType<typeof fstatSync>;
    try {
      info = fstatSync(fd);
    } catch (error) {
      // The incumbent's post-open catch-all: an fstat OSError degrades through
      // `could not read file` (facade) or surfaces raw (native default).
      if (mapFaults) mapFaults("read", error);
      throw error;
    }
    // TWO refusals, not one. The incumbent raises them separately
    // (presets.py:487-497) and the degradation notice interpolates `exc.detail`
    // verbatim, so a merged message reaches the operator as a merged message:
    // "must be a regular file without group/world write permission" tells
    // someone whose config is a DIRECTORY to check its permissions, and someone
    // whose config is mode 666 to check that it is a file. The incumbent names
    // the one fault that is actually true.
    if (!info.isFile()) {
      refuse("preset_config_insecure", `preset config is not a regular file: ${path}`,
             `replace ${path} with an operator-owned regular file`);
    }
    if (info.mode & 0o022) {
      refuse("preset_config_insecure", `preset config is group/world writable: ${path}`,
             `chmod 600 ${path}`);
    }
    let resolved: string;
    try {
      resolved = realpathSync(path);
    } catch (error) {
      // A name removed inside the window: the incumbent's resolve-phase arm
      // (`could not resolve opened file`), native-raw without the mapper.
      if (mapFaults) mapFaults("resolve", error);
      throw error;
    }
    let named: { dev: number; ino: number };
    try {
      named = statSync(resolved) as { dev: number; ino: number };
    } catch (error) {
      if (mapFaults) mapFaults("resolve", error);
      throw error;
    }
    if (named.dev !== info.dev || named.ino !== info.ino) {
      if (mapFaults) mapFaults("race", null);
      refuse("preset_config_insecure", `${path} changed while opening`, `fix ${path}`);
    }
    let bytes: Buffer;
    try {
      bytes = readFileSync(fd);
    } catch (error) {
      if (mapFaults) mapFaults("read", error);
      throw error;
    }
    return { bytes, resolvedPath: resolved, digest: `sha256:${createHash("sha256").update(bytes).digest("hex")}` };
  } finally {
    closeSync(fd);
  }
}

/**
 * Does this file open with a UTF-8 BOM? Rule 40 / tap-uddlm, family T3.
 *
 * `tomllib` REFUSES a leading U+FEFF -- `Invalid statement (at line 1, column 1)`
 * -- so the incumbent degrades a BOM-prefixed config to no policy and says so.
 * The port reached the opposite answer twice over: `new TextDecoder("utf-8")`
 * defaults to `ignoreBOM: false`, which CONSUMES the BOM before the parser sees
 * anything, and `Bun.TOML.parse` accepts a leading U+FEFF even when handed one
 * directly. Both measured.
 *
 * The consequence ran the wrong way for a fence: a config an editor saved with a
 * BOM had its `[harness.*.env]` policy APPLIED by the port and REFUSED by the
 * incumbent. The more permissive side was ours, on the tier that decides which
 * environment variables reach a child process.
 *
 * So the question is asked of the BYTES, before any decoder gets a chance to be
 * helpful -- which is why `readSecureBytes` hands back raw bytes with the BOM
 * intact, and why an `ignoreBOM: true` flip would be the wrong fix: that makes
 * the BOM survive into the string, where `Bun.TOML.parse` would accept it anyway.
 */
export function hasUtf8Bom(bytes: Buffer): boolean {
  return bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf;
}

/** The parsed projection of a secure read. Decoding is strict, and a leading BOM is refused rather than consumed (tomllib parity). */
export function readCatalog(path: string): CatalogSource {
  const { bytes, resolvedPath, digest } = readSecureBytes(path);
  if (hasUtf8Bom(bytes)) {
    refuse("preset_config_invalid",
      `invalid preset config ${path}: TOML parse failed: a leading UTF-8 BOM is not valid TOML`,
      // The incumbent's action for every parse failure is the bare `fix <path>`
      // (presets.py), and this is one. The BOM-specific guidance lives in the
      // DETAIL, where the incumbent also puts its parser's explanation -- so the
      // operator still learns what is wrong, and the two actions agree byte for
      // byte instead of diverging on a string that was mine to choose.
      `fix ${path}`);
  }
  const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  const data = Bun.TOML.parse(text);
  if (!table(data)) refuse("preset_config_invalid", `${path} is not a TOML table`);
  return { path: resolvedPath, digest, data };
}

const FORBIDDEN = new Set(("TAP HOME USER LOGNAME SHELL PATH PWD OLDPWD CDPATH TMUX TMUX_PANE " +
  "TERM_SESSION_ID SESSION SESSION_ID AGENT_ID AGENT_NAME TEAM TEAM_NAME CWD BUS BUS_PATH " +
  "BASH_ENV ENV NODE_OPTIONS PYTHONHOME PYTHONPATH PYTHONSTARTUP LD_PRELOAD LD_LIBRARY_PATH " +
  "DYLD_INSERT_LIBRARIES DYLD_LIBRARY_PATH RUBYOPT PERL5OPT").split(" "));
const CONTROL = /[\x00-\x1f\x7f]/;

/**
 * `where` and `source` turn a refusal into a repair (tap-dv0b6).
 *
 * The incumbent tells the operator four things -- which table, which key, which
 * file, and what to do:
 *
 *   detail  [harness.claude.env] key 'HF_TOKEN' in <path> crosses the identity,
 *           transport, process, credential, or policy fence
 *   action  remove key 'HF_TOKEN' from [harness.claude.env] in <path>
 *
 * The port said `forbidden environment key HF_TOKEN` with `action: null`, which
 * is the exact shape `LauncherError.action`'s own docstring warns about: a
 * refusal that says what is wrong but not what to do is a worse product, and it
 * is invisible in any test that only asserts the class. Both engines refused, so
 * only a differential comparing the CONTENT could see it.
 *
 * OPTIONAL, and deliberately supplied at ONE call site so far. The harness-policy
 * fence is the one this lane measured against the incumbent; the preset-env and
 * launch-env fences have their own incumbent texts that I have not measured, and
 * guessing them would trade a known-narrow message for an invented one.
 */
/**
 * ONE CONSTRUCTOR PER FAILURE, spelling the incumbent's text exactly.
 *
 * `TuningContext` (presets.py:523) is a set of constructors, and every
 * invalid-config one routes through `_invalid(path, detail)` (presets.py:430):
 *
 *     class   preset_config_invalid
 *     action  fix <resolved path>              <- the PATH, nothing else
 *     detail  invalid preset config <path>: <detail>
 *
 * An earlier attempt passed one `invalidKind` plus hand-built prose and drifted
 * immediately: it invented `fix [harness.claude.env] in <path>`,
 * `fix the key name in ...` and `fix env.GOOD in ...`, none of which the
 * incumbent says, and collapsed two distinct value diagnostics into one. Hence
 * constructors — prose assembled at three call sites drifts from prose assembled
 * in one (sol-pinnacle-6, S2 exact-head read).
 */
/**
 * `-f`: a REGULAR file, symlinks followed. The incumbent's operator, exactly.
 *
 * Rule 38: file-kind predicates port by OPERATOR, and this one guards whether a
 * surviving `presets.toml` SHADOWS the authority catalog. The incumbent asks
 * `legacy.is_file()` inside `except (OSError, PresetError)` (presets.py:1657-1661),
 * so a stat that throws is the operator's FALSE rather than an error -- which is
 * what the `catch` here reproduces, and why it must not be narrowed to a
 * particular errno.
 *
 * `existsSync` was the port's predicate and it is WIDER: "any entry". A
 * directory, socket or fifo named `presets.toml` beside a populated config.toml
 * took the shadow branch in the port and not in the incumbent, so the operator
 * read a legacy-shadowed notice about a file that is not a file. A broken
 * symlink agreed by accident, both being false, which is how the row survived a
 * reading. Disclosed on #xxxx; fixed here as rule 38's P2 class, riding the
 * owning lane's next PR for this file.
 */
export function isRegularFile(path: string): boolean {
  try { return statSync(path).isFile(); } catch { return false; }
}

export type EnvRefusals = {
  notTable(): never;
  keyInvalid(key: string): never;
  forbidden(key: string): never;
  fieldError(field: string, problem: string): never;
};

/** The `[harness.<name>.env]` spelling of every refusal (presets.py:1725). */
export function harnessEnvRefusals(harness: string, path: string): EnvRefusals {
  const table = `[harness.${harness}.env]`;
  const invalid = (detail: string): never =>
    refuse("preset_config_invalid", `invalid preset config ${path}: ${detail}`, `fix ${path}`);
  return {
    notTable: () => invalid(`${table} must be a table`),
    keyInvalid: (key) => invalid(`${table} has invalid environment key '${key}'`),
    fieldError: (field, problem) => invalid(`${table} field '${field}' ${problem}`),
    forbidden: (key) => refuse("harness_env_forbidden",
      `${table} key '${key}' in ${path} crosses the identity, transport, process, credential, or policy fence`,
      `remove key '${key}' from ${table} in ${path}`),
  };
}

/**
 * The `preset '<name>'` spelling of every env refusal (presets.py:523-583).
 * The fence arm is NOT `_invalid`-wrapped — the incumbent raises it as a direct
 * `PresetError("preset_env_forbidden", ...)`, so its detail carries no
 * `invalid preset config` prefix and its action names the key, not the file.
 */
export function presetEnvRefusals(name: string, path: string): EnvRefusals {
  const invalid = (detail: string): never =>
    refuse("preset_config_invalid", `invalid preset config ${path}: ${detail}`, `fix ${path}`);
  return {
    notTable: () => invalid(`preset '${name}' field 'env' must be a table`),
    keyInvalid: (key) => invalid(`preset '${name}' has invalid environment key '${key}'`),
    fieldError: (field, problem) => invalid(`preset '${name}' field '${field}' ${problem}`),
    forbidden: (key) => refuse("preset_env_forbidden",
      `preset '${name}' environment key '${key}' crosses the identity, transport, process, credential, or policy fence`,
      `remove environment key '${key}' from preset '${name}' in ${path}`),
  };
}

export function environment(value: unknown, kind: string, refusals?: EnvRefusals): Record<string, string> {
  if (value === undefined) return {};
  if (!table(value)) {
    if (refusals) refusals.notTable();
    return refuse(kind, "env must be a table");
  }
  const result: Record<string, string> = Object.create(null);
  for (const [key, item] of Object.entries(value)) {
    const upper = key.toUpperCase();
    // Spelling before fence, as presets.py:610-613 orders it: a key that is not a
    // legal environment name is MALFORMED, not an attempt to cross the fence.
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) {
      if (refusals) refusals.keyInvalid(key);
      refuse(kind, `forbidden environment key ${key}`);
    }
    if (FORBIDDEN.has(upper) || upper.startsWith("TAP_") ||
        /(^|_)(IDENTITY|HANDLE|TEAM|CWD|BUS|SANDBOX|APPROVALS?|PERMISSIONS?|BYPASS|PASSWORD|PASSWD|SECRET)(_|$)/.test(upper) ||
        /(^|_)TOKEN$|(^|_)(API_KEY|ACCESS_KEY|PRIVATE_KEY)(_|$)/.test(upper)) {
      if (refusals) refusals.forbidden(key);
      refuse(kind, `forbidden environment key ${key}`);
    }
    // `pyBlank`, not `trim()`. `_behavioral_string` (presets.py:569) tests
    // `not value.strip()`, and the two whitespace sets disagree on U+FEFF and
    // U+001C-U+001F — so a policy value of U+FEFF is a usable string to the
    // incumbent and blank to JS. That exact disagreement has already produced two
    // catalog defects in this lane; this is the third site and the same fix.
    if (typeof item !== "string" || pyBlank(item)) {
      if (refusals) refusals.fieldError(`env.${key}`, "must be a non-empty string");
      refuse(kind, `invalid value for environment key ${key}`);
    }
    if (CONTROL.test(item)) {
      if (refusals) refusals.fieldError(`env.${key}`, "contains a control character");
      refuse(kind, `invalid value for environment key ${key}`);
    }
    result[key] = item;
  }
  return result;
}

export function parameters(value: unknown): Params {
  if (value === undefined) return {};
  if (!table(value)) return refuse("preset_config_invalid", "params must be a table");
  const result: Params = Object.create(null);
  const validString = (item: unknown): item is string =>
    typeof item === "string" && item.trim().length > 0 && !CONTROL.test(item);
  for (const [key, item] of Object.entries(value)) {
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(key) ||
        !(typeof item === "boolean" || validString(item) || (Array.isArray(item) && item.every(validString)))) {
      refuse("preset_config_invalid", `invalid param ${key}`);
    }
    result[key] = item as string | boolean | string[];
  }
  return result;
}

export function addParams(argv: string[], params: Params, configKeys = false): string[] {
  const extra: string[] = [];
  for (const [key, value] of Object.entries(params)) {
    const flag = `--${key}`;
    if (configKeys && key === "config" && typeof value !== "boolean") {
      const tokens: string[] = [];
      for (const item of Array.isArray(value) ? value : [value]) {
        const pair = item.startsWith("-") ? [`${flag}=${item}`] : [flag, item];
        // Other operand shapes keep the existing option floor.
        if (configOnly(pair).length || !argv.some(token => token === flag || token.startsWith(`${flag}=`))) tokens.push(...pair);
      }
      extra.push(...configDefaults(tokens, argv));
      continue;
    }
    if (value === false || argv.some(token => token === flag || token.startsWith(`${flag}=`))) continue;
    if (value === true) extra.push(flag);
    else for (const item of Array.isArray(value) ? value : [value]) {
      if (item.startsWith("-")) extra.push(`${flag}=${item}`);
      else extra.push(flag, item);
    }
  }
  return argv.length ? [argv[0]!, ...extra, ...argv.slice(1)] : extra;
}

/**
 * The LAUNCH-path projection of the one catalog reader.
 *
 * Everything this used to do for itself -- open config.toml, run the version
 * arms, check for a legacy presets.toml, select a preset and word its two
 * refusals -- is `loadPresetCatalog` and `requirePreset`. Keeping a private copy
 * here made the launcher a second reader of the same file with its own notice
 * policy, which is the thing the migration is removing, not a shortcut around it.
 *
 * Collapsing it also CORRECTED a divergence rather than merely deduplicating:
 * the private copy refused the whole file when a requested preset sat in a
 * catalog it disliked, where the incumbent degrades the unusable preset and then
 * reports `preset_not_usable` naming that preset. Asking for a good preset in a
 * file with one bad neighbour now launches, as it always did in Python.
 */
export function resolveCatalog(
  requested: string | undefined,
  harness: string | undefined,
  env: NodeJS.ProcessEnv,
  notice: (message: string) => void,
): { preset?: Preset; policyEnv: Record<string, string>; policyParams: Params; permissions: PermissionMode } {
  const dir = configDirectory(env);
  // Policy is read as its own authority and never blocks: CONTRACT says an
  // absent config resolves the harness tier empty and silently, and an
  // unreadable one allows the launch to proceed with one notice. The catalog is
  // only read when a preset was actually REQUESTED, so a direct harness launch
  // on a machine with no catalog starts instead of refusing.
  let policies: Table = {};
  let policySource = join(dir, "config.toml");
  let preset: Preset | undefined;
  if (!requested) {
    // No preset was asked for, so the catalog is not consulted at all -- only
    // the policy, tolerantly. This is the arm that must survive a machine with
    // no config file.
    ({ policy: policies, source: policySource } = loadHarnessPolicy(notice, readSecureBytes, dir));
  } else {
    // A preset WAS asked for, so the catalog is read -- once. Its policy comes
    // from config.toml even when its presets came from the legacy file, so
    // reading it again here would only duplicate every notice the parse emits.
    const catalog = loadPresetCatalog(env, notice, readSecureBytes, dir, isRegularFile);
    policies = catalog.harnessPolicy;
    // The POLICY's source, not the presets'. In the legacy fallback these differ,
    // and using the preset path here named the wrong file in a policy refusal.
    policySource = catalog.harnessPolicySource;
    // CONTRACT.md:1794 and the :2323 error table: the Bun launcher reports
    // `preset_config_retired` with migration guidance when a REQUESTED preset
    // belongs to a version-1 catalog, while direct-harness launches keep
    // notice-only behavior. That is a documented, deliberate divergence from
    // presets.py, which notices the retirement and then answers
    // `preset_not_found` -- and CONTRACT outranks the deleted program in the
    // oracle order, so it is retained rather than ported away.
    //
    // It sits HERE, in the launch projection, because it is the launch path's
    // policy: the reader stays tolerant and is still read exactly once. Putting
    // it back in a private reader is what this file just stopped doing.
    if (isDocumentedRetiredCatalog(catalog.version)) {
      refuse("preset_config_retired",
        `${catalog.source_path}: version 1 is retired; migrate the catalog to version 2 or 3`,
        `migrate ${catalog.source_path} to version 2 or 3`);
    }
    const resolved = requirePreset(catalog, requested);
    if (harness && harness !== resolved.harness) {
      refuse("preset_harness_mismatch", `${requested} uses ${resolved.harness}, not ${harness}`);
    }
    harness = resolved.harness;
    preset = { harness, params: resolved.params, env: resolved.env, provenance: resolved.provenance };
    if (resolved.note) notice(resolved.note);
  }
  // PRESENT but not a table is an authoring error the operator must hear about;
  // ABSENT is the ordinary case and says nothing (presets.py:1822-1829). The
  // previous line collapsed both into `{}`, so `[harness]\nclaude = "x"` launched
  // claude with no policy and no explanation. A comment here claimed "the
  // requested harness's own arm reports it" -- it did not; nothing did.
  // astra-pinnacle-reviewer-2's lead on #xxxx, confirmed by the differential:
  // the claude row diverged while the codex sibling control matched.
  const requestedTable = harness ? policies[harness] : undefined;
  if (harness && requestedTable !== undefined && !table(requestedTable)) {
    notice(`tap session: [harness.${harness}] in ${policySource} must be a table — ` +
      `no harness environment policy is being applied for ${harness}`);
  }
  const policy = table(requestedTable) ? requestedTable as Table : {};
  return { preset, permissions: permissionMode(policy.permissions),
           policyEnv: environment(policy.env, "harness_env_forbidden",
             // Only a NAMED harness has a `[harness.<name>.env]` table to quote in a
             // refusal. With no harness the policy is `{}`, so `environment` returns
             // on the undefined value before any refusal could be constructed.
             harness ? harnessEnvRefusals(harness, policySource) : undefined),
           policyParams: parameters(policy.params) };
}

/**
 * Params validation carrying the PYTHON diagnostics, for the policy tier.
 *
 * The Python facade's harness-policy refusals are quoted to operators verbatim
 * (`[harness.X] params.k must be a boolean, a string, or an array of strings`,
 * classed `preset_config_invalid`, actioned `fix <path>`), and a policy read
 * that reaches the Python facade must refuse with exactly those words. The
 * shared `parameters` validator above spells a shorter native text for the
 * catalog reader's drop reasons, which are a different surface with a
 * different history — so this is the facade's spelling, not a second opinion
 * about what is invalid. Order and predicate match `_parse_params` exactly:
 * key spelling, then per element string/blank/control, storing the ORIGINAL
 * value (a scalar string is not listified on the way out).
 */
export function pyParams(value: unknown, where: string, path: string): Params {
  if (value === undefined) return {};
  if (!table(value)) {
    refuse("preset_config_invalid",
           `invalid preset config ${path}: ${where} field 'params' must be a table`,
           `fix ${path}`);
  }
  const result: Params = Object.create(null);
  for (const [key, item] of Object.entries(value)) {
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(key)) {
      refuse("preset_config_invalid",
             `invalid preset config ${path}: ${where} has invalid params key '${key}'`,
             `fix ${path}`);
    }
    if (typeof item === "boolean") { result[key] = item; continue; }
    for (const element of Array.isArray(item) ? item : [item]) {
      if (typeof element !== "string") {
        refuse("preset_config_invalid",
               `invalid preset config ${path}: ${where} params.${key} must be a boolean, ` +
               "a string, or an array of strings",
               `fix ${path}`);
      }
      // `pyBlank`, not `trim()` — the incumbent tests `not value.strip()`, and
      // the two whitespace sets disagree on U+FEFF.
      if (pyBlank(element)) {
        refuse("preset_config_invalid",
               `invalid preset config ${path}: ${where} params.${key} must be a non-empty string`,
               `fix ${path}`);
      }
      if (CONTROL.test(element)) {
        refuse("preset_config_invalid",
               `invalid preset config ${path}: ${where} params.${key} contains a control character`,
               `fix ${path}`);
      }
    }
    result[key] = item as string | string[];
  }
  return result;
}

export type HarnessPolicyResolution = {
  env: Record<string, string>;
  /** RETURNED data. The caller's notify gate decides whether these print. */
  notices: string[];
  params: Params;
  permissions: PermissionMode;
};

/**
 * The standalone harness-policy read, as the Python facade's
 * `resolve_harness_env` spelled it.
 *
 * The open/parse/degrade body is `readHarnessPolicyFromDisk` -- the SAME
 * implementation the launch path uses through `loadHarnessPolicy`; this seam
 * only chooses the sinks (parser findings emit through the command's notice
 * lifetime, `[harness]`-tier findings and the degrade are RETURNED as data)
 * and does the facade-specific selection below. This is the POLICY tier alone
 * — always config.toml, read fresh, never the catalog — because that is the
 * contract the facade promises: machine policy located by `environ`, degraded
 * by failure class, and handed back with its notices as DATA:
 *
 *   - Degrade vs refuse. Absent is silent; unreadable/malformed/insecure
 *     resolves empty with one recoverable notice; but a fence-crossing env
 *     key, a bad params value, or a bad `permissions` in the REQUESTED
 *     harness's own table refuses, and only that table is fence-checked.
 *
 * Relative XDG / bad HOME follows the facade too: configDirectory refuses, and
 * this seam converts that refusal into the degraded notice naming
 * `config.toml`, instead of stranding a caller that asked a question.
 *
 * `read` is injectable because the facade's door supplies a secure reader that
 * maps race/OSError faults onto the incumbent's classes; the launch path keeps
 * the native default.
 */
export function resolveHarnessPolicy(
  harness: string, env: NodeJS.ProcessEnv, notices: Notices,
  read: (path: string) => { bytes: Buffer; resolvedPath: string; digest: string } = readSecureBytes,
): HarnessPolicyResolution {
  const empty: HarnessPolicyResolution =
    { env: {}, notices: [], params: Object.create(null), permissions: "bypass" };
  let dir: string;
  try {
    dir = configDirectory(env);
  } catch (error) {
    const failure = error as Partial<LauncherError>;
    return { ...empty, notices: [policyDegradedNotice(
      "config.toml",
      failure.detail ?? failure.message ?? String(error),
      failure.action ?? "fix config.toml")] };
  }
  const returned: string[] = [];
  const { policy: tables, source } = readHarnessPolicyFromDisk(
    {
      parser: notices.sink,
      tables: (message) => { returned.push(message); },
      degraded: (degSource, detail, action) => {
        returned.push(policyDegradedNotice(degSource, detail, action));
      },
    },
    read, dir);
  // Only THIS harness's table is fence-checked, and the refusal order is the
  // incumbent's: env, then params, then permissions.
  const rawTable = Object.prototype.hasOwnProperty.call(tables, harness)
    ? (tables as Table)[harness]
    : undefined;
  if (rawTable === undefined) return { ...empty, notices: returned };
  if (!table(rawTable)) {
    return { ...empty, notices: [...returned,
      `tap session: [harness.${harness}] in ${source} must be a table — ` +
      `no harness environment policy is being applied for ${harness}`] };
  }
  const envOut = environment(rawTable.env, "harness_env_forbidden",
                             harnessEnvRefusals(harness, source));
  const params = pyParams(rawTable.params, `[harness.${harness}]`, source);
  const permissions = rawTable.permissions === undefined ? "bypass" : rawTable.permissions;
  if (typeof permissions !== "string" || (permissions !== "bypass" && permissions !== "auto")) {
    refuse("preset_config_invalid",
           `invalid preset config ${source}: [harness.${harness}] permissions must be ` +
           '"bypass" or "auto"',
           `fix ${source}`);
  }
  return { env: envOut, notices: returned, params, permissions };
}
