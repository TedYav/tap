import { readFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { startupDiagnostic } from "./startup-trace";

/** Explicit lifecycle call sites only: no console output, no tmux tracing. */
export function lifecycleDiagnostic(event: string, fields: Record<string, unknown>, env: NodeJS.ProcessEnv = process.env): void {
  try {
    const config = join(env.XDG_CONFIG_HOME || join(env.HOME || homedir(), ".config"), "tap/config.toml");
    const doc = Bun.TOML.parse(readFileSync(config, "utf8")) as { diagnostics?: { level?: unknown } };
    if (doc.diagnostics?.level !== "verbose") return;
    const safe = event === "pane_failure" || event === "pane_output"
      ? Object.fromEntries(Object.entries(fields).filter(([key]) => ["target", "status", "command"].includes(key))) : fields;
    startupDiagnostic(event, safe, env);
  } catch { /* Developer diagnostics must not change the operation result. */ }
}
