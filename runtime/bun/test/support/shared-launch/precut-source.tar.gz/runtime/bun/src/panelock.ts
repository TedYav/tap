// Per-pane submit serialization.
//
// THE DEFECT THIS EXISTS FOR, measured on real tmux panes: two senders
// submitting to ONE pane concurrently produce a FUSED LINE — both sentinels in
// a single submitted turn — and BOTH senders exit 0. The band read-back cannot
// see it: it asks "did my id leave the band", and the id did leave, glued to
// someone else's.
//
// THIS FILE USED TO BE FOUR TIMES LONGER, AND THAT WAS THE BUG.
//
// Three custom representations came and went here — an O_EXCL file, an atomic
// mkdir, then a link(2)-published owner record — each with hand-written rules
// for a question the kernel already answers: is the holder still alive? Every
// version leaked a different ownership-theft path, because "did this lock's
// owner die" is not decidable from the filesystem, and each fix moved the
// window rather than closing it:
//
//   - malformed owner JSON parsed to `{}`, reached processAlive(undefined),
//     and was classified DEAD, so an unknown lock was stolen;
//   - release removed an unreadable REPLACEMENT, because the predicate was
//     "no valid owner disagrees with me" rather than "a valid owner IS me";
//   - dead-owner reaping was check-then-unlink BY PATH, so a reaper could
//     delete A, another could publish B, and the first could then unlink B.
//
// A previous comment in this file claimed macOS ships no flock, and inferred
// that custom stale-owner rules were therefore necessary. THAT PREMISE WAS
// FALSE, and sol-sponsor-x caught it: this host ships /usr/bin/lockf, whose own
// manual page says it uses BSD flock(2) and that "the mere existence of the
// file is not considered to constitute a lock." Verified here before adopting:
// a second acquirer is refused while the first holds (rc 75), succeeds after
// release, and — the property that deletes all of the above — succeeds after
// the holder is SIGKILLed, because the KERNEL drops the lock when the process
// dies. No liveness inference, no owner record, no reaping, no staleness
// horizon. Those were an entire category of code written to work around a
// primitive that was already installed.
//
// It remains true that bun exposes no flock BINDING; the fix was to stop
// treating "no binding in this runtime" as "no primitive on this machine."

import { spawn, spawnSync } from "node:child_process";
import { closeSync, existsSync, mkdirSync, openSync, rmSync } from "node:fs";
import { homedir, tmpdir } from "node:os";
import { createHash } from "node:crypto";
import { dirname, join } from "node:path";

export interface PaneLock {
  release(fenceTimeoutMs?: number): void;
}

declare const registryLockBrand: unique symbol;
const REGISTRY_LOCK_BRAND: typeof registryLockBrand = Symbol("tap.RegistryLock") as typeof registryLockBrand;

/**
 * Path-bound acting-registry lock. Minted only by `acquireRegistryLock`.
 * A plain `{ registryLocation, release() }` is not this type.
 *
 * `registryLocation` is the path as acquired — the index-recorded literal —
 * and the sidecar is `${literal}.lock`. Mixed Bash/Bun writers share that
 * sidecar. Do not realpath this field; canonical equality lives on Selection.
 */
export type RegistryLock = {
  readonly [registryLockBrand]: typeof registryLockBrand;
  /** Index-recorded acting registry path — never the `.lock` sidecar. */
  readonly registryLocation: string;
  release(): void;
};

export function isRegistryLock(value: object): value is RegistryLock {
  return (value as { [registryLockBrand]?: unknown })[REGISTRY_LOCK_BRAND] === REGISTRY_LOCK_BRAND;
}

/**
 * The lock root, resolved through the ISOLATION AUTHORITY rather than always
 * landing in production. A sandboxed send must not create files under the
 * operator's real ~/.tap/locks, and parallel private tmux servers must not
 * contend on identical pane-address keys. A run pinned only by TAP_HOME keeps
 * its locks WITH ITS BUS: without this tier, a bare fixture run escaped the
 * sandbox and wrote the operator's real ~/.tap/locks (tap-7r3fn.66).
 */
export function lockRoot(env: NodeJS.ProcessEnv = process.env): string {
  if (env.TAP_LOCK_DIR) return env.TAP_LOCK_DIR;
  if (env.TAP_INDEX_HOME) return join(env.TAP_INDEX_HOME, "locks");
  // A caller-pinned bus keeps its locks WITH ITS BUS. The --team override
  // also sets TAP_HOME, but its marker excludes it: derived buses keep the
  // incumbent default so Bash (TAP_BUS_RULE) and Bun stay in lockstep.
  if (env.TAP_HOME && env.TAP_HOME !== env.TAP_TEAM_OVERRIDE_BUS) return join(env.TAP_HOME, "locks");
  return join(homedir(), ".tap", "locks");
}

function lockPath(scope: string, key: string, env: NodeJS.ProcessEnv): string {
  const dir = lockRoot(env);
  mkdirSync(dir, { recursive: true });
  const safe = key.replace(/[^A-Za-z0-9_.-]/g, "_");
  // Keep every representable legacy obligation path (16-byte prefix/suffix).
  // A separate directory prevents aliasing a literal short id with its digest.
  if (scope === "obligation" && safe.length > 239) {
    return join(dir, "obligation-long", `${createHash("sha256").update(safe).digest("hex")}.lock`);
  }
  return join(dir, `${scope}-${safe}.lock`);
}

/** Present iff this platform has the kernel-backed helper. */
export const KERNEL_LOCK = process.platform === "linux" ? "/usr/bin/flock" : "/usr/bin/lockf";

/** Both helpers use flock(2), matching Bash's Python fcntl.flock sidecars. */
export function kernelLockArgs(path: string, timeoutMs: number, command: string[]): string[] {
  if (timeoutMs === Infinity) { // wait indefinitely: the helpers' own default with no --timeout/-t
    return process.platform === "linux"
      ? ["--exclusive", "--no-fork", path, ...command]
      : ["-k", path, ...command];
  }
  const seconds = String(Math.ceil(timeoutMs / 1000));
  // No supervisory fork: the child we terminate must be the lock holder.
  // Neither platform unlinks the sidecar after release.
  return process.platform === "linux"
    ? ["--exclusive", "--no-fork", "--timeout", seconds, path, ...command]
    : ["-k", "-t", seconds, path, ...command];
}

export function kernelLockAvailable(): boolean {
  return existsSync(KERNEL_LOCK);
}

/**
 * Acquire the pane's submit lock, or null when another submit holds it.
 *
 * NULL IS A PARK, NEVER A PROCEED. Waiting a bounded time and then continuing
 * unlocked re-creates the exact fused line this prevents, and does it silently.
 *
 * HOW THE HOLD IS EXPRESSED. The helper holds the lock for the lifetime of a
 * command it runs, so the held state is a live child process parked on `cat`
 * with an open stdin; releasing closes that stdin and the child exits, which is
 * what drops the flock. The lock therefore belongs to a PROCESS rather than to
 * a file's contents — which is the whole point, since a process's death is a
 * fact the kernel knows and a file's contents are a guess.
 */
export function acquirePaneLock(
  pane: string,
  timeoutMs = 5000,
  env: NodeJS.ProcessEnv = process.env,
): PaneLock | null {
  return acquireKernelLock("pane-submit", pane, timeoutMs, env);
}

/** Serialize resize/restore across every pane sharing one tmux window. */
export function acquireWindowRepaintLock(
  server: string,
  windowId: string,
  timeoutMs = 5000,
  env: NodeJS.ProcessEnv = process.env,
): PaneLock | null {
  const key = createHash("sha256").update(`${server}\0${windowId}`).digest("hex");
  return acquireKernelLock("window-repaint", key, timeoutMs, env);
}

/** Serialize the full eligibility/effect/receipt cycle for one obligation. */
export function acquireObligationLock(
  id: string,
  timeoutMs = 5000,
  env: NodeJS.ProcessEnv = process.env,
): PaneLock | null {
  return acquireKernelLock("obligation", id, timeoutMs, env);
}

/** Serialize readers that must observe one coherent acting-registry snapshot. */
export function acquireRegistryLock(
  registryPath: string,
  timeoutMs = 5000,
  env: NodeJS.ProcessEnv = process.env,
): RegistryLock | null {
  const literal = literalActingRegistry(registryPath);
  const held = acquireKernelLockAt(`${literal}.lock`, timeoutMs, env);
  if (!held) return null;
  const token = {
    [REGISTRY_LOCK_BRAND]: REGISTRY_LOCK_BRAND,
    registryLocation: literal,
    release() {
      held.release();
      Reflect.deleteProperty(token, REGISTRY_LOCK_BRAND);
    },
  };
  return token as RegistryLock;
}

function literalActingRegistry(registryPath: string): string {
  if (registryPath.endsWith(".lock")) {
    const stem = registryPath.slice(0, -".lock".length);
    if (existsSync(stem)) {
      throw new Error(
        `acquireRegistryLock takes the acting registry file, not the sidecar '${registryPath}'`,
      );
    }
  }
  return registryPath;
}

/** Acquire an already-resolved exact sidecar path. */
export function acquirePathLock(
  path: string,
  timeoutMs = 5000,
  env: NodeJS.ProcessEnv = process.env,
): PaneLock | null {
  // Runtime-cache sidecars sit on a declared 1s refusal boundary. Their
  // synchronous child handshake therefore gets a small fixed allowance rather
  // than the pane/registry path's broad startup cushion.
  return acquireKernelLockAt(path, timeoutMs, env, 100);
}

function acquireKernelLock(
  scope: string,
  key: string,
  timeoutMs: number,
  env: NodeJS.ProcessEnv,
): PaneLock | null {
  const path = lockPath(scope, key, env);
  return acquireKernelLockAt(path, timeoutMs, env);
}

function acquireKernelLockAt(
  path: string,
  timeoutMs: number,
  env: NodeJS.ProcessEnv,
  handshakeSlackMs = 1500,
): PaneLock | null {
  mkdirSync(dirname(path), { recursive: true });

  if (!kernelLockAvailable()) {
    // FAIL CLOSED, LOUDLY. A missing primitive must not silently downgrade to
    // "no serialization" — that is the fused-line defect returning as a
    // portability convenience.
    throw new Error(
      `pane serialization requires ${KERNEL_LOCK}, which is not present on this host. ` +
      "Refusing to submit unserialized: concurrent senders would fuse into one line " +
      "with both reporting success.",
    );
  }

  // THE HANDSHAKE IS THE ACQUISITION SIGNAL, and it has to be, because
  // acquisition is not synchronously observable any other way.
  //
  // The helper either RUNS its command (we hold the lock) or exits nonzero WITHOUT
  // running it (someone else does). A first attempt inferred which had happened
  // from "is the child still alive?" — unobservable in the window that matters,
  // so a second acquirer sailed straight past a held lock. The command
  // therefore ANNOUNCES itself by writing a marker file and then blocking on
  // stdin, and the marker's existence is proof the helper granted the lock rather
  // than an inference about it.
  //
  // A marker FILE rather than a pipe byte: bun does not expose a numeric `fd`
  // on a child's stdout (checked — it is undefined), so there is no synchronous
  // read available, and an async 'data' handler cannot be awaited from a
  // synchronous acquire. The filesystem is the one channel both sides can use
  // without an event loop turn.
  //
  // The helper retains the sidecar and bounds its wait; a wedged holder
  // cannot park us forever. Linux --no-fork keeps termination aimed at the
  // process holding the descriptor, rather than a parent that leaves it alive.
  const markerSuffix = `.held.${process.pid}.${Math.random().toString(36).slice(2, 10)}`;
  const marker = Buffer.byteLength(path.slice(path.lastIndexOf("/") + 1) + markerSuffix) <= 255
    ? path + markerSuffix : join(dirname(path), markerSuffix);
  // No deadline = no loop exit when the helper dies before granting, so the
  // Infinity arm keeps the incumbent's open("w") boundary: an unusable
  // sidecar (EISDIR/ENOTDIR/EACCES) fails HERE, promptly, before the spawn.
  if (timeoutMs === Infinity) closeSync(openSync(path, "w"));
  // A no-deadline wait has no loop exit when the helper dies before granting
  // (unwritable/full marker dir), so the helper's grant failure writes a
  // terminal file in the always-writable temp dir; both exits below clean up.
  const goneFile = join(tmpdir(), `.tap-lock-gone.${process.pid}.${Math.random().toString(36).slice(2, 10)}`);
  const child = spawn(KERNEL_LOCK, kernelLockArgs(path, timeoutMs, [
    "sh", "-c", `if : > "$0"; then exec cat; else : > "$1"; fi`, marker, goneFile]), {
    // Terminal group signals must not drop the lock while its owner still unwinds.
    detached: true,
    stdio: ["pipe", "ignore", "ignore"],
    env: env as NodeJS.ProcessEnv,
  });

  const deadline = timeoutMs === Infinity ? Infinity : Date.now() + timeoutMs + handshakeSlackMs;
  let granted = false;
  while (Date.now() < deadline) {
    if (existsSync(marker)) { granted = true; break; }
    if (existsSync(goneFile)) break; // the helper could not announce its grant: a refusal, promptly
    // NO `child.exitCode` BRANCH. It reads null for the entire synchronous
    // window (measured: still null 29ms after the child had already dropped its
    // kernel lock), because bun updates it on an event-loop turn this loop
    // never yields to. Consulting it here does not detect a refusal early; it
    // only makes the deadline look conditional when it is not.
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10);
  }
  if (!granted) {
    child.kill("SIGKILL");
    rmSync(marker, { force: true });
    rmSync(goneFile, { force: true });
    return null;
  }

  let released = false;
  return {
    release(fenceTimeoutMs = 2000) {
      if (released) return;
      released = true;
      // Closing stdin ends `cat`, which ends the helper child, which drops the
      // flock. No path comparison, no ownership predicate: this process can
      // only ever release the lock IT holds, because the release is the death
      // of its own child.
      try {
        child.stdin?.end();
      } catch {
        /* already gone */
      }
      // WAIT FOR THE HOLD TO ACTUALLY END — WITH THE KERNEL, NOT WITH A PID.
      //
      // Closing stdin starts the child's exit; the flock is not dropped until
      // the process is GONE. Returning before that makes release() a promise
      // rather than a fact, and the next acquirer — often this same process,
      // one line later — is refused a lock nobody holds.
      //
      // The first version polled `process.kill(child.pid, 0)` for up to 2s.
      // That was the suite hang, and sol-sponsor-x diagnosed it exactly: the
      // child is a zombie whose reaping is bun bookkeeping that cannot happen
      // while this synchronous turn holds the loop, so EVERY release burned the
      // full 2 seconds and enough of them timed the test file out. The pid
      // never stops answering, so the poll could not succeed by construction.
      //
      // Ask the KERNEL instead. `lockf -t <n> <same path> true` cannot return 0
      // while any process still owns that flock, so status 0 IS the proof the
      // hold ended. Measured on this host: 0 in 29ms, while child.exitCode was
      // still null — the same instant the pid poll would have kept spinning.
      try {
        child.kill("SIGTERM");
      } catch {
        /* already gone */
      }
      // Queued runtime-cache callers use zero: their next acquisition waits
      // for the kernel release, so this fence must not queue behind them.
      const fence = spawnSync(KERNEL_LOCK, kernelLockArgs(path, fenceTimeoutMs, ["true"]), { stdio: "ignore" });
      if (fence.status !== 0) {
        // NOT PROOF OF FAILURE, and deliberately not thrown. A nonzero fence
        // means "could not prove the drop within the bound" — which is also
        // what a CONTENDER that acquired in the gap looks like, and that case
        // is a success we cannot distinguish from the outside. The hold has
        // been terminated and the wait was bounded; the honest thing is to say
        // the proof is unavailable rather than to invent a verdict from it.
      }
      rmSync(marker, { force: true });
      rmSync(goneFile, { force: true });
      child.unref();
    },
  };
}
