import { existsSync, lstatSync, mkdirSync, readFileSync, realpathSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { createHash } from "node:crypto";
import { createInterface } from "node:readline/promises";
import { collectDifferences } from "./config";
import { removeOwnedLink } from "../install-skill-links";
import { DelegateToBash } from "../context";
import { readIndexJson } from "../index-home";

const REPO = resolve(import.meta.dir, "../../../..");
const BEGIN = "# >>> tap aliases >>>", END = "# <<< tap aliases <<<";
type Entry = { kind: string; path: string; [key: string]: any };
type Manifest = { version: number; repo: string; targets?: Record<string,string>; entries: Entry[]; historyPending?: boolean };
export type Prompt = (question: string) => Promise<string>;
const home = () => process.env.HOME!;
const index = () => process.env.TAP_INDEX_HOME || join(home(), ".tap");
const configDir = () => {
  const root = process.env.XDG_CONFIG_HOME || join(home(), ".config");
  if (!isAbsolute(root)) throw new Error("XDG_CONFIG_HOME must be absolute; use an absolute path or unset it");
  return join(root, "tap");
};
const manifestPath = () => join(index(), "install-manifest.json");
const hash = (data: string | Buffer) => createHash("sha256").update(data).digest("hex");
const quote = (value: string) => "'" + value.replaceAll("'", "'\\''") + "'";
const equal = (a: unknown, b: unknown): boolean => JSON.stringify(a) === JSON.stringify(b);
function readManifest(): Manifest {
  const path = manifestPath();
  if (!existsSync(path)) return {version: 1, repo: REPO, entries: []};
  if (lstatSync(path).isSymbolicLink()) throw new Error(`preserve and inspect symlink manifest ${path}`);
  const value = JSON.parse(readFileSync(path, "utf8"));
  if (value.version !== 1 || !Array.isArray(value.entries) || typeof value.repo !== "string") throw new Error(`invalid manifest ${path}; preserve it and inspect before rerunning install`);
  return value;
}
function atomic(path: string, content: string) {
  if (existsSync(path) && lstatSync(path).isSymbolicLink()) throw new Error(`preserving symlink ${path}`);
  mkdirSync(dirname(path), {recursive:true});
  const temp = `${path}.tap-${process.pid}`;
  writeFileSync(temp,content,{mode:0o600});
  renameSync(temp,path);
}
function saveManifest(manifest: Manifest) { atomic(manifestPath(), JSON.stringify(manifest,null,2)+"\n"); }
function record(entry: Entry) {
  const manifest = readManifest();
  manifest.entries = manifest.entries.filter(e => !(e.kind === entry.kind && e.path === entry.path));
  manifest.entries.push(entry);
  saveManifest(manifest);
}
async function confirm(ask: Prompt, question: string, fallback: "y" | "n"): Promise<boolean> {
  const answer = (await ask(`${question} [${fallback === "y" ? "Y/n" : "y/N"}] `)).trim();
  return answer === "" ? fallback === "y" : /^(y|yes)$/i.test(answer);
}
async function interact(operation: (ask: Prompt) => Promise<number>, output: NodeJS.WriteStream = process.stdout): Promise<number> {
  if (!process.stdin.isTTY || !output.isTTY) {
    console.error("tap: an interactive terminal is required; next: run this command in a terminal (tap setup --machine or tap uninstall)");
    return 2;
  }
  const rl = createInterface({input:process.stdin,output});
  const abort = new AbortController();
  const interrupt = () => abort.abort();
  rl.on("SIGINT", interrupt);
  process.on("SIGINT", interrupt);
  try { return await operation(question => rl.question(question, {signal: abort.signal})); }
  finally { process.off("SIGINT", interrupt); rl.close(); }
}
export function serializeToml(document: Record<string,any>, bareKeys = false): string {
  const lines: string[] = [];
  const scalar = (v: any): string => typeof v === "object" && !Array.isArray(v) ? "{ " + Object.entries(v).map(([k,x])=>`${JSON.stringify(k)} = ${scalar(x)}`).join(", ")+" }" : Array.isArray(v) ? `[${v.map(scalar).join(", ")}]` : JSON.stringify(v);
  const key = (name: string) => bareKeys && /^[A-Za-z0-9_-]+$/.test(name) ? name : JSON.stringify(name);
  const emit = (obj: Record<string,any>, path: string[]) => {
    if (path.length) lines.push("",`[${path.map(key).join(".")}]`);
    for (const [k,v] of Object.entries(obj)) if (typeof v !== "object" || v === null || Array.isArray(v)) lines.push(`${key(k)} = ${scalar(v)}`);
    for (const [k,v] of Object.entries(obj)) if (typeof v === "object" && v !== null && !Array.isArray(v)) emit(v,[...path,k]);
  };
  emit(document,[]);
  return lines.join("\n")+"\n";
}
export function applyEffort(preset: any, effort: string): any {
  const result = structuredClone(preset);
  if (result.harness === "claude") result.params.effort = effort;
  if (result.harness === "codex") {
    const values = Array.isArray(result.params.config) ? result.params.config : [result.params.config].filter(Boolean);
    result.params.config = [...values.filter((v: string) => !/^\s*model_reasoning_effort\s*=/.test(v)), `model_reasoning_effort=${effort}`];
  }
  if (["claude","codex"].includes(result.harness)) result.description = `${result.params.model} at ${effort}`;
  return result;
}
export async function setupMachine(ask: Prompt, detected?: string[], json = false): Promise<number> {
  const notes: string[] = [];
  const status = await runSetupMachine(ask, detected, notes, json);
  if (json) console.log(JSON.stringify({exit_code: status, notes}));
  return status;
}

async function runSetupMachine(ask: Prompt, detected: string[] | undefined, notes: string[], json: boolean): Promise<number> {
  const log = json ? console.error : console.log;
  configDir(); // Refuse unusable roots before questions or any write.
  const binaries: Record<string,string> = {claude:"claude",codex:"codex",cursor:"cursor-agent",opencode:"opencode",agy:"agy"};
  const searchPath = [process.env.PATH || "",join(home(),".local/bin"),"/opt/homebrew/bin","/usr/local/bin"].join(":");
  const found = detected ?? Object.keys(binaries).filter(h => Bun.which(binaries[h]!,{PATH:searchPath}));
  log(`Detected executables: ${found.join(", ") || "none"}. This does not verify login or model access.`);
  log("Recommended: Claude and Codex. Also supported: OpenCode, Antigravity, and Cursor Agent. More harnesses coming soon.");
  if (!found.length) { log("next: install and sign into a supported CLI (claude, codex, cursor-agent, opencode, agy), then run tap setup --machine"); return 0; }
  const catalog = Bun.TOML.parse(readFileSync(join(REPO,"skills/tap/config/config.v3.toml"),"utf8")) as any;
  const chosen: Record<string,any> = {};
  let effort = found.some(h=>["claude","codex"].includes(h)) ? (await ask("Default effort for Claude/Codex starter models [high] (low/medium/high/xhigh): ")).trim() || "high" : "high";
  while (!["low","medium","high","xhigh"].includes(effort)) effort = (await ask("Choose low, medium, high, or xhigh: ")).trim();
  for (const harness of found) {
    const entries = Object.entries(catalog.presets).filter(([,p]: any) => p.harness === harness);
    const mode = (await ask(`${harness}: keep it simple, choose myself, or skip? [simple] `)).trim().toLowerCase();
    if (mode === "skip") continue;
    if (mode === "choose" || mode === "myself" || mode === "choose myself") {
      entries.forEach(([name,p]: any,i) => log(`${i+1}. ${name}: ${p.description}`));
      let selections = (await ask("Select preset numbers separated by commas (empty skips): ")).trim();
      while (selections && selections.split(/[ ,]+/).some(v=>!/^\d+$/.test(v)||Number(v)<1||Number(v)>entries.length)) selections=(await ask("Use only numbers from the list, separated by commas: ")).trim();
      for (const n of selections ? selections.split(/[ ,]+/) : []) {
        const [name,preset] = entries[Number(n)-1]!;
        chosen[name] = structuredClone(preset);
      }
    } else if (!mode || mode === "simple" || mode === "keep it simple") {
      for (const [name,preset] of entries as [string,any][]) if (preset.metadata?.starter === true) chosen[name] = applyEffort(preset,effort);
    } else { console.error(`Unrecognized choice '${mode}'; no config written. next: tap setup --machine`); return 2; }
  }
  if (!Object.keys(chosen).length) { log("No presets selected; config unchanged. next: tap setup --machine to choose presets, or tap session launch <harness> <name>"); return 0; }
  // tap-7r3fn.122 owns the enforced mappings; other harnesses have no auto mode.
  const permissionHarnesses = ["claude", "codex"];
  const config = join(configDir(),"config.toml");
  let previous: any = {};
  if (existsSync(config)) {
    try { previous = Bun.TOML.parse(readFileSync(config,"utf8")); }
    catch { log(`Cannot read existing selections in ${config}; it stays preserved unless you explicitly replace it.`); }
  }
  let permissions = "";
  if (found.some(h=>permissionHarnesses.includes(h))) {
    log("Claude/Codex permission mode: bypass is recommended for a dedicated machine; auto asks before risky actions, so attach to answer.");
    permissions = (await ask("Permission mode [keep existing, otherwise bypass] (bypass/auto): ")).trim();
    while (permissions && !["bypass","auto"].includes(permissions)) permissions = (await ask("Choose bypass or auto, or leave empty to keep existing: ")).trim();
  }
  if (permissions === "auto") {
    const note = "Note: in auto mode you may have to approve the first TAP message, unless you run `tap init` in the project first.";
    notes.push(note);
    log(note);
  }
  const harness = Object.fromEntries(found.map(h=>{
    const policy = {...(catalog.harness[h] || {})};
    delete policy.permissions;
    if (permissionHarnesses.includes(h)) policy.permissions = permissions || previous.harness?.[h]?.permissions || "bypass";
    return [h,policy];
  }));
  const document = {...catalog, presets:chosen, harness};
  const replace = !existsSync(config) || await confirm(ask, `Replace existing ${config}?`, "n");
  const target = replace ? config : join(configDir(),"config.candidate.toml");
  if (!replace && existsSync(target) && !(await confirm(ask, `Replace existing candidate ${target}?`, "n"))) { log("Existing config and candidate preserved. next: review them, then rerun tap setup --machine"); return 0; }
  atomic(target,serializeToml(document,true));
  log(`Wrote ${target}`);
  const shell = process.env.SHELL || "/bin/zsh";
  const supportsAliases = /(?:^|\/)(?:bash|zsh)$/.test(shell);
  if (replace && !supportsAliases) log(`Shell aliases support Bash/Zsh, not ${shell}; next: use tap session launch directly or configure your shell manually.`);
  if (replace && supportsAliases && await confirm(ask, "Add shell aliases?", "y")) {
    const path = join(home(),shell.endsWith("bash") ? ".bashrc" : ".zshrc");
    const original = existsSync(path) ? readFileSync(path,"utf8") : "";
    if (original.includes(BEGIN) || original.includes(END)) {
      log(`Existing TAP alias block preserved in ${path}; edit it to add new choices.`);
      if(original.includes("Scripts"))log(`Check the existing PATH in ${path}: TAP now installs to ${join(home(),".local/bin")}.`);
    } else {
      const binDir = process.env.TAP_INSTALL_BIN || join(home(), ".local", "bin");
      const pathLine = (process.env.PATH || "").split(":").includes(binDir) ? [] : [`export PATH=${quote(binDir)}:"$PATH"`];
      let python = process.env.TAP_VALIDATED_PYTHON3 || process.env.TAP_PYTHON3;
      try {
        python ||= readFileSync(join(index(), "python3"), "utf8").trim();
        const brew = realpathSync(python).match(/^(.*)\/Cellar\//)?.[1];
        if (brew) pathLine.unshift(`export PATH=${quote(`${brew}/bin:${brew}/opt/python@3.11/libexec/bin`)}:"$PATH"`);
      } catch { /* No recorded Homebrew interpreter: no brew PATH edit. */ }
      const block = [BEGIN,...pathLine,'tap_launch() { local preset="$1" name="$1"; shift; if [ "$#" -gt 0 ] && [[ "$1" != -* ]]; then name="$name-$1"; shift; fi; tap session launch "$preset" "$name" "$@"; }',...Object.keys(chosen).map(n=>`alias ${n}=${quote(`tap_launch ${n}`)}`),END].join("\n");
      record({kind:"block",path,begin:BEGIN,end:END,content:block});
      atomic(path,original+(original.endsWith("\n") || !original ? "" : "\n")+block+"\n");
      log(`Added shell aliases to ${path}`);
    }
  }
  log("Optional plugins are installed separately and will remain after tap uninstall.");
  for (const cli of ["claude","codex"].filter(h=>found.includes(h))) for (const [name,market,source] of [
    ["ponytail","ponytail","DietrichGebert/ponytail"],
    ["compound-engineering","compound-engineering-plugin","EveryInc/compound-engineering-plugin"],
    ["superpowers","superpowers-marketplace","obra/superpowers-marketplace"],
  ]) {
    const commands = [[cli,"plugin","marketplace","add",source!],[cli,"plugin",cli === "codex" ? "add" : "install",`${name}@${market}`]];
    log(commands.map(c=>c.join(" ")).join("\n"));
    if (await confirm(ask, `Install ${name} for ${cli}?`, "y")) for (const command of commands) {
      const child = Bun.spawn(command,{env:{...process.env,PATH:searchPath},stdin:"inherit",stdout:json ? 2 : "inherit",stderr:"inherit"});
      if (await child.exited !== 0) { log(`Plugin command failed; next: rerun ${command.join(" ")}`); break; }
    }
  }

  const python=Bun.spawnSync(["python3","-c","import sys,platform; print(sys.executable+' '+platform.python_version())"],{stdout:"pipe",stderr:"pipe"});
  log(`Python runtime: ${python.exitCode===0 ? python.stdout.toString().trim() : "unavailable"}`);
  const installed=Bun.which(join(process.env.TAP_INSTALL_BIN || join(home(),".local/bin"),"tap")) || Bun.which("tap");
  if(installed) {
    const executable=realpathSync(installed);
    const revision=Bun.spawnSync(["git","-C",dirname(executable),"rev-parse","HEAD"],{stdout:"pipe",stderr:"pipe"});
    log(`Installed TAP: ${installed} -> ${executable}; HEAD ${revision.exitCode===0 ? revision.stdout.toString().trim() : "unavailable"}`);
  } else log("Installed TAP: unavailable on PATH");

  const sheet = join(REPO,"docs/cheatsheet.html");
  if (process.env.TAP_SETUP_OPEN_GUIDE !== "0" && existsSync(sheet) && process.platform === "darwin") {
    const result = Bun.spawnSync(["open",sheet],{stdout:"ignore",stderr:"pipe"});
    if (result.exitCode) log(`Open the guide: ${sheet}`);
  } else log(`Guide: ${sheet}`);
  const name = chosen.fable ? "fable" : Object.keys(chosen)[0]!;
  log(replace ? `next: from your work directory, run tap session launch ${name}` : `next: review ${target}, replace ${config} when ready, then run tap session launch ${name} from your work directory`);
  return 0;
}

export async function cmdSetupMachine(argv: string[]): Promise<number> {
  if (!argv.includes("--machine")) throw new DelegateToBash();
  if (argv.some(a=>a!=="--machine" && a!=="--json")) { console.error("Usage: tap setup --machine [--json]"); return 2; }
  const json = argv.includes("--json");
  try { return await interact(ask=>setupMachine(ask, undefined, json), json ? process.stderr : process.stdout); } catch (error) { console.error(`tap setup: ${error}; completed writes are preserved. next: tap setup --machine`); return 2; }
}

export function removeEntry(entry: Entry): string {
  if (entry.kind === "migration") return "already migrated; old path untouched";
  if (entry.kind === "git-config") {
    const current = Bun.spawnSync(["git","-C",entry.path,"config","--local","--get","core.hooksPath"]);
    if (current.stdout.toString().trim() !== entry.value) return "preserved changed core.hooksPath";
    const result = Bun.spawnSync(["git","-C",entry.path,"config","--local","--unset","core.hooksPath"]);
    if (result.exitCode !== 0) throw new Error(`could not unset core.hooksPath at ${entry.path}`);
    return "unset core.hooksPath in";
  }
  let stat;
  try { stat = lstatSync(entry.path); } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return "already missing";
    throw error;
  }
  if (entry.kind === "symlink") {
    return removeOwnedLink(entry.path, entry.target);
  }
  if (!stat.isFile() || stat.isSymbolicLink()) return "preserved changed file type";
  const raw = readFileSync(entry.path,"utf8");
  if (entry.kind === "file") {
    if (hash(readFileSync(entry.path)) !== entry.sha256) return "preserved edited file";
    rmSync(entry.path); return "removed";
  }
  if (entry.kind === "block") {
    if (!raw.includes(entry.content)) return "preserved edited or missing TAP block";
    if (raw.indexOf(entry.content) !== raw.lastIndexOf(entry.content)) return "preserved ambiguous TAP blocks";
    let next=raw.replace(entry.content,"");
    const created=entry.created_containers;
    if(created && entry.path.endsWith(".toml")) {
      try {
        const parsed=Bun.TOML.parse(next) as any;
        const expected=structuredClone(parsed);
        if(!parsed.hooks || !Object.keys(parsed.hooks).length) {
          if(created.hooks) {
            next=next.replace(/^\[hooks\][ \t]*\r?\n(?=\s*(?:\[|$))/m,"");
            delete expected.hooks;
          }
          if(created.features_hooks && parsed.features?.hooks===true) {
            next=next.replace(/(^\[features\][^\[]*?)^hooks[ \t]*=[ \t]*true[ \t]*\r?\n/m,"$1");
            delete expected.features.hooks;
            if(created.features) {
              next=next.replace(/^\[features\][ \t]*\r?\n(?=\s*(?:\[|$))/m,"");
              if(!Object.keys(expected.features).length)delete expected.features;
            }
          }
        }
        // As in config set: text matching locates; parsed values authorize the write.
        // Only recorded owned keys/empty containers may differ after block removal.
        const differences: string[]=[];
        collectDifferences(expected,Bun.TOML.parse(next),[],differences);
        if(differences.length)return "preserved ambiguous TOML containers";
      } catch { return "preserved ambiguous TOML containers"; }
    }
    atomic(entry.path,next); return entry.begin === BEGIN ? "removed the TAP alias block from" : "removed the TAP block from";
  }
  const data = JSON.parse(raw);
  if (entry.kind === "json-key") {
    if (!equal(data[entry.key],entry.value)) return "preserved changed JSON entry";
    delete data[entry.key];
  } else if (entry.kind === "hook") {
    const rows = data.hooks?.[entry.event];
    if (!Array.isArray(rows)) return "already missing";
    let removed = false;
    data.hooks[entry.event] = rows.flatMap((row: any) => {
      if (!entry.nested) {
        if (equal(row,entry.value)) { removed = true; return []; }
        return [row];
      }
      if (!Array.isArray(row?.hooks)) return [row];
      const kept = row.hooks.filter((leaf: any)=> !equal(leaf,entry.value));
      if (kept.length === row.hooks.length) return [row];
      removed = true;
      if (!kept.length && Object.keys(row).every(k=>["hooks","matcher"].includes(k))) return [];
      return [{...row,hooks:kept}];
    });
    if (!removed) return "preserved changed or missing hook";
    const created=entry.created_containers;
    if(created?.events?.includes(entry.event) && !data.hooks[entry.event].length)delete data.hooks[entry.event];
    if(created?.hooks && !Object.keys(data.hooks).length)delete data.hooks;
  } else return "preserved unknown manifest kind";
  atomic(entry.path,JSON.stringify(data,null,2)+"\n");
  return "removed";
}
export function historyPaths(): string[] {
  const paths = [index(),configDir()];
  const registry = join(index(),"global-registry.json");
  if (existsSync(registry)) {
    const data = readIndexJson(registry);
    if (!data.teams || typeof data.teams !== "object" || Array.isArray(data.teams)) throw new Error(`invalid registry ${registry}; preserve history and inspect it`);
    for (const team of Object.values(data.teams) as any[]) {
      if (typeof team.root !== "string" || !isAbsolute(team.root)) throw new Error("invalid team root; history preserved");
      paths.push(join(team.root,".tap"));
    }
  }
  const unique = [...new Set(paths.map(p=>resolve(p)))];
  for (const path of unique) if (path === "/" || path === resolve(home()) || path === REPO) throw new Error(`unsafe history path ${path}`);
  return unique.filter(p=>existsSync(p)).filter(p=>!unique.some(other=>other!==p && p.startsWith(other+"/")));
}
export async function uninstallMachine(ask: Prompt): Promise<number> {
  const manifest = readManifest();
  if (!existsSync(manifestPath())) { console.log("Nothing to uninstall: no install manifest. History, dependencies, and plugins are preserved."); return 0; }
  // Detect an omitted record without deleting an artifact on inferred ownership.
  if (manifest.targets) {
    const scan = Bun.spawnSync(["python3","-B",join(REPO,"scripts/install_manifest.py"),"--scan"],{env:{...process.env,TAP_INSTALL_MANIFEST:manifestPath()}});
    if (scan.exitCode !== 0) throw new Error(`cannot inspect install manifest: ${scan.stderr.toString()}`);
    for (const found of JSON.parse(scan.stdout.toString()) as Entry[]) {
      if (!manifest.entries.some(e=>e.path===found.path && e.kind===found.kind && e.event===found.event && e.key===found.key && (e.kind!=="hook" || e.value?.command===found.value?.command))) console.log(`Unrecorded TAP artifact (preserved): ${found.path}; next: rerun ./install.sh to reconcile the manifest`);
    }
  }
  if (!manifest.entries.length && !manifest.historyPending) { console.log("Nothing to uninstall: all recorded artifacts already removed. History, dependencies, and plugins are preserved."); return 0; }
  console.log("Recorded removal list:");
  for (const entry of manifest.entries) console.log(entry.kind === "migration" ? `  migration history (no removal): ${entry.path} -> ${entry.destination}` : `  ${entry.kind}: ${entry.path}${entry.event ? ` (${entry.event})` : ""}`);
  console.log("Changed files/targets are preserved. Dependencies and plugins always stay.");
  if (!(await confirm(ask, "Remove these TAP artifacts?", "n"))) { console.log("Uninstall cancelled; next: tap uninstall when ready."); return 0; }
  const history = historyPaths(); // Capture enrolled roots before removing anything.
  const remaining: Entry[] = [];
  for (const entry of manifest.entries) {
    const outcome = removeEntry(entry);
    console.log(`${outcome}: ${entry.path}`);
    if (outcome.startsWith("preserved")) remaining.push(entry);
  }
  manifest.entries = remaining;
  manifest.historyPending = true;
  saveManifest(manifest);
  console.log("TAP history locations:\n"+history.map(p=>`  ${p}`).join("\n"));
  console.log("Unindexed project history remains in each project’s .tap/ directory.");
  let choice = (await ask("Keep, archive, or delete your TAP history? [keep] ")).trim().toLowerCase() || "keep";
  while (!["keep","archive","delete"].includes(choice)) choice = (await ask("Choose keep, archive, or delete: ")).trim().toLowerCase();
  if (choice === "keep") {
    console.log("History kept at the locations above.");
    manifest.historyPending = false; saveManifest(manifest);
  }
  else {
    if (remaining.length) { console.log("Some installed artifacts were preserved; history kept so their records survive. next: review those artifacts and rerun tap uninstall"); return 2; }
    if (choice === "archive") {
      const archive = join(home(),`tap-history-${new Date().toISOString().replaceAll(":","").replaceAll(".","")}.tar.gz`);
      const result = Bun.spawnSync(["python3",join(REPO,"scripts/install_history.py"),archive,...history],{stdout:"inherit",stderr:"inherit"});
      if (result.exitCode !== 0) { console.error("Archive verification failed; originals preserved. next: inspect archive and rerun tap uninstall"); return 2; }
    } else for (const path of history) rmSync(path,{recursive:true});
  }
  console.log("Dependencies and plugins remain installed.");
  return 0;
}
export async function cmdUninstall(argv: string[]): Promise<number> {
  if (argv.length) { console.error("Usage: tap uninstall (interactive; no --purge)"); return 2; }
  try { return await interact(ask=>uninstallMachine(ask)); } catch (error) { console.error(`tap uninstall: ${error}; next: inspect the preserved manifest and rerun tap uninstall`); return 2; }
}

if (import.meta.main) {
  const [verb,...argv] = process.argv.slice(2);
  process.exitCode = verb === "setup" ? await cmdSetupMachine(argv) : await cmdUninstall(argv);
}
