// Peek owns command orchestration; the shared identity and paired-capture owners stay intact.
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { TapError, displayCwd, observeCallingPane, requireActingRegistry, resolveContext } from "../context";
import { contextUsedPercent } from "../context-census";
import { validToken } from "../ids";
import { errorJson, humanAction, humanLine } from "../native-error";
import { parsePreservingBigint, seatMap, type RegistryDoc, type Seat } from "../registry";
import { pyTruthy } from "../spool-publication";
import { libCall } from "../watch-detectors";
import { pythonStr } from "../watch-lease";

const scripts = resolve(import.meta.dir, "../../../../skills/tap/scripts");
const subst = (value: string) => value.replace(/\n+$/, "");
type Result = { status: number; stdout: string; stderr: string };
const empty = (status = 0): Result => ({ status, stdout: "", stderr: "" });

/** A watcher supplies an environment, not permission to replace its own process globals.
 * Keep the old subprocess boundary; only the command owner on its far side changes. */
export function peekResult(handle: string, scriptsDir: string, env: NodeJS.ProcessEnv): Result {
  const r = spawnSync("bun", [resolve(scriptsDir, "../../../runtime/bun/src/verbs/peek.ts"), handle], {
    encoding: "utf8", env, stdio: ["ignore", "pipe", "pipe"],
  });
  return { status: r.status ?? 1, stdout: r.stdout ?? "", stderr: r.stderr ?? "" };
}

function readPeek(argv: string[], scriptsDir: string): Result {
  let handle = "", pane = "", json = false;
  let env: NodeJS.ProcessEnv = { ...process.env, TAP_VERB: "tap peek", TAP_PEEK_JSON: "0" };
  const call = (fn: string, args: string[] = []) => libCall(scriptsDir, fn, args, env);
  try {
    for (let i = 0; i < argv.length; i++) {
      const a = argv[i]!;
      if (a === "--pane") {
        pane = argv[++i] ?? "";
        // The old shell's required-operand error bypassed JSON, even after --json.
        if (!pane) return { status: 1, stdout: "", stderr: "tap peek: --pane needs a value\n" };
      } else if (a === "--json") {
        json = true;
        env = { ...env, TAP_JSON: "1", TAP_PEEK_JSON: "1" };
      } else if (a.startsWith("--")) throw new TapError(1, "unknown_option", "tap help peek", `unknown option '${a}'`);
      else if (!handle) handle = a;
      else throw new TapError(1, "usage_error", "tap help peek", `unexpected arg '${a}'`);
    }
    if (!handle) throw new TapError(1, "usage_error", "tap help peek", "usage: tap peek <handle> [--pane <tmux-target>] [--json]");
    if (!validToken(handle)) throw new TapError(1, "usage_error", "tap help peek", `handle '${handle}' is not a valid token (^[A-Za-z0-9][A-Za-z0-9._-]*$)`);

    let harness = "", resolvedId = "", observedEpoch: string | undefined;
    if (pane) {
      if (call("tap_pane_alive", [pane]).status !== 0) {
        throw new TapError(3, "pane_gone", "re-open the pane and retry", `pane '${pane}' for '${handle}' is gone`);
      }
    } else {
      let ctx;
      try {
        ctx = resolveContext(process.cwd(), env, { paneFallback: false });
        requireActingRegistry(ctx, 4);
      } catch {
        const caller = observeCallingPane(env);
        if (caller.state === "inside") {
          return call("tap_fail_unregistered_pane", [caller.paneId, `no registry at cwd (${displayCwd(process.cwd(), env)})`, "4"]);
        }
        const reason = caller.state === "outside" ? caller.detail : caller.refusal;
        throw new TapError(4, "unanchored_bus", "run from the enrolled team root",
          `cwd-derived bus has no acting registry and the caller pane is not observable (${reason})`);
      }
      const ensured = call("tap_ensure_dirs");
      if (ensured.status !== 0) return ensured;
      let row: Seat = {};
      try { row = seatMap(parsePreservingBigint(readFileSync(ctx.registryPath, "utf8")) as RegistryDoc)[handle] ?? {}; } catch { /* Incumbent unreadable row is absent. */ }
      const status = Object.hasOwn(row, "status") ? row.status : "active";
      if (status !== "active" && !(status === "suspended" && row.status_reason === "server_restarted")) row = {};
      const text = (key: string, fallback = "") => pythonStr(pyTruthy(row[key]) ? row[key] : fallback);
      if (!text("pane") && !text("session")) {
        throw new TapError(1, "unregistered", `tap register ${handle} --pane <tmux-target>`, `no pane for '${handle}'`);
      }
      harness = text("harness");
      observedEpoch = subst(call("tap_server_epoch_now").stdout);
      const observed = call("tap_seat_observed_record", [text("status", "active"), text("delivery", "pane"),
        text("pane"), text("pane_id"), text("session"), text("registered_at"), text("server_epoch"), observedEpoch,
        text("boot_id"), subst(call("tap_boot_id").stdout), harness, text("status_reason")]);
      if (observed.status !== 0) return observed;
      const [state = "", reason = "", resolvedPane = "", paneId = "", observedHarness = ""] = subst(observed.stdout).split("\x1f");
      if (!resolvedPane) {
        if (state === "gone") {
          const action = call("tap_is_launcher_managed", [handle]).status === 0
            ? `tap session resume ${handle}` : `re-open pane for '${handle}' and run 'tap in'`;
          throw new TapError(3, "pane_gone", action, `session for '${handle}' is gone (${reason || "session_absent"})`);
        }
        if (reason === "address_rebound") {
          throw new TapError(1, "pane_recycled", `tap team   (verify the seat's row)   ·   tap session resume ${handle}`,
            `the stored address for '${handle}' now holds a DIFFERENT pane (${reason}) — refusing to read a pane the session name does not vouch for`);
        }
        throw new TapError(1, "pane_unproven", "tap team   (verify the seat's row)   ·   tap doctor",
          `identity for '${handle}' is unproven (${state}${reason ? `: ${reason}` : ""}) — peek reads only name-proven panes`);
      }
      pane = resolvedPane;
      resolvedId = paneId;
      harness = observedHarness || harness;
    }
    if (!harness) {
      const command = spawnSync("tmux", ["display-message", "-p", "-t", pane, "#{pane_current_command}"], { encoding: "utf8", env });
      harness = subst(call("tap_pane_harness_command", [pane, subst(command.stdout ?? "")]).stdout);
    }
    if (env.TAP_PEEK_CONTEXT === "1") {
      const before = call("tap_server_epoch_now");
      const epoch = subst(before.stdout);
      if (before.status !== 0 || !epoch || epoch !== (observedEpoch ?? epoch)) return { ...empty(1), stderr: before.stderr };
      // Ambient tmux, unjoined: moving this to socket-aware capture is a separate B1 decision.
      const capture = spawnSync("tmux", ["capture-pane", "-t", resolvedId || pane, "-p"], { encoding: "utf8", env });
      if (capture.status !== 0) return { ...empty(1), stderr: capture.stderr ?? "" };
      const after = call("tap_server_epoch_now");
      if (epoch !== subst(after.stdout)) return { ...empty(1), stderr: before.stderr + after.stderr };
      const percent = contextUsedPercent(harness, subst(capture.stdout ?? ""));
      return { ...empty(), stdout: percent === null ? "" : `${percent}\n`, stderr: before.stderr + after.stderr };
    }
    return call("tap_pane_read", [pane, harness, handle]);
  } catch (error) {
    const tagged = error as Error & { tapErrorClass?: string; tapAction?: string };
    if (!(error instanceof TapError) && !tagged?.tapErrorClass) throw error;
    const code = error instanceof TapError ? error.code : 1;
    const cls = error instanceof TapError ? error.errorClass : tagged.tapErrorClass!;
    const action = error instanceof TapError ? error.action : tagged.tapAction ?? "";
    const detail = error instanceof TapError ? error.detail : tagged.message;
    return json || env.TAP_JSON === "1"
      ? { status: code, stdout: errorJson(cls, action, detail), stderr: "" }
      : { status: code, stdout: "", stderr: `tap peek: ${humanLine(detail)}; next: ${humanAction(action)}\n` };
  }
}

export function cmdPeek(argv: string[], scriptsDir = scripts): number {
  const result = readPeek(argv, scriptsDir);
  process.stdout.write(result.stdout);
  process.stderr.write(result.stderr);
  return result.status;
}

if (import.meta.main) process.exitCode = cmdPeek(Bun.argv.slice(2));
