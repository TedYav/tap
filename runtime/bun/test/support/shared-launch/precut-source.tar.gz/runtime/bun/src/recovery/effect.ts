import { appendFileSync, existsSync, writeFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import { sentinelSubmitDecision, visibleSentinelId } from "../submit-frame";
import { parseStuckSentinel } from "../stuck-sentinel";
import { repaintPane, type RepaintResult } from "../pane/repaint";
import { checkIdentityGuard, type IdentityGuardEvidence } from "./identity-guard";
import { atomicWrite } from "../fsatomic";
import { acquirePaneLock } from "../panelock";
import { isOpenCodeCommand, tmux, tmuxReadOnly, type Run } from "../tmux";
import { loadRegistry, seatMap } from "../registry";
import { MAX_EFFECTS, canAct, readRun, runDirectory, updateRun, writeRun, type RecoveryRun, type RecoveryTarget, type Liveness } from "./state";

export interface PaneSnapshot {
  dead: string; command: string; windowCount: string; paneId: string;
  instance: string | null; present?: boolean | null; pid?: string; registered?: boolean | null;
}
export type EffectOutcome = "verified" | "unverified" | "harness-exited" | "refused";
export interface RecoveryEvent {
  v: 1; recoveryId: string; seat: string; mode: string; action: string; reason: string;
  before: string | null; after: string | null; state: PaneSnapshot | null;
  effect?: "none" | "possible"; identityChecks?: IdentityGuardEvidence[];
  outcome: EffectOutcome; summary: string; at: string; incident: boolean;
}
export interface EffectIO {
  capture(target: RecoveryTarget, wholeHistory?: boolean): string;
  snapshot(target: RecoveryTarget): PaneSnapshot;
  authorize(target: RecoveryTarget, record?: (e: IdentityGuardEvidence) => void): string | null;
  repaint?(target: RecoveryTarget): RepaintResult;
  effect(args: string[]): Run;
  settle(): void;
}
const scripts = resolve(import.meta.dir, "../../../../skills/tap/scripts");
function field(target: RecoveryTarget, format: string): string {
  const r = tmuxReadOnly(["display-message", "-p", "-t", target.paneId, format]);
  return r.code === 0 ? r.stdout.trim() : "";
}
export const REAL_RECOVERY_IO: EffectIO = {
  capture(target, wholeHistory = true) {
    const r = tmuxReadOnly(["capture-pane", "-p", "-e", "-J", ...(wholeHistory ? ["-S", "-"] : []), "-t", target.paneId]);
    if (r.code !== 0 || r.rateLimited) throw new Error("full before/after frame unavailable");
    return r.stdout;
  },
  snapshot(target) {
    let instance: string | null = null, registered: boolean | null = null;
    try { const row = seatMap(loadRegistry(target.registry))[target.handle]; registered = !!row; instance = String(row?.instance ?? ""); } catch { /* unknown */ }
    // A successful server inventory can prove absence; socket/read failure cannot.
    const presence = tmuxReadOnly(["list-panes", "-a", "-F", "#{pane_id}"]);
    const ids = presence.stdout.trim().split(/\r?\n/).filter(Boolean);
    return { registered, pid: field(target, "#{pane_pid}"), present: presence.code === 0 && !presence.rateLimited && ids.every(id => /^%\d+$/.test(id)) ? ids.includes(target.paneId) : null,
      dead: field(target, "#{pane_dead}"), command: field(target, "#{pane_current_command}"),
      windowCount: field(target, "#{session_windows}"), paneId: field(target, "#{pane_id}"), instance };
  },
  authorize(target, record) {
    try {
      const row = seatMap(loadRegistry(target.registry))[target.handle];
      if (!row || (row.status ?? "active") !== "active" || row.pane_id !== target.paneId || row.pane !== target.pane ||
          String(row.instance ?? "") !== target.instance || String(row.session ?? "") !== target.session ||
          String(row.harness ?? "") !== target.harness) return "captured target binding changed";
      if (!target.processPid || field(target, "#{pane_pid}") !== target.processPid) return "captured target process changed or is unobservable";
    } catch { return "captured target registry is unreadable"; }
    return checkIdentityGuard(target, record);
  },
  repaint: target => repaintPane(target.paneId),
  effect: args => tmux(args),
  settle: () => Bun.sleepSync(100),
};
function exited(run: RecoveryRun, state: PaneSnapshot): boolean {
  return state.present === false || state.dead === "1" || (state.registered === false && !!run.target.handle) ||
    (!!state.pid && !!run.target.processPid && state.pid !== run.target.processPid) || (state.instance !== null && state.instance !== run.target.instance) ||
    /^(?:ba|z|fi|da|k|c|tc)?sh$|^(?:less|more|vim|nvim|vi|nano)$/.test(state.command);
}

function expectedNudgeId(run: RecoveryRun): string | null {
  if (!run.nudgeExpected) return null;
  const parsed = parseStuckSentinel(run.nudgeExpected, run.target.harness);
  return parsed.ok ? parsed.fields.id : null;
}

function postRepaintSentinelMatches(run: RecoveryRun, frame: string): boolean {
  const expected = expectedNudgeId(run);
  return expected !== null && visibleSentinelId(frame, run.target.harness, true) === expected;
}
export function appendRecoveryEvent(id: string, event: RecoveryEvent, env = process.env): void {
  appendFileSync(join(runDirectory(id, env), "events.jsonl"), JSON.stringify(event) + "\n", { mode: 0o600 });
}

/** One recorded, bounded effect. Model thinking and completion waits never own this mutex. */
export function recoveryEffect(
  id: string, action: string, reason: string, args: string[],
  io: EffectIO = REAL_RECOVERY_IO, env = process.env, facts?: () => Liveness,
): { code: number; event: RecoveryEvent } {
  if (!reason.trim() || !action.trim()) throw new Error("every recovery effect needs an action and policy decision reason");
  const initial = readRun(id, env);
  const event: RecoveryEvent = { v: 1, recoveryId: id, seat: `${initial.target.team}/${initial.target.handle}`,
    mode: initial.mode, action, reason, before: null, after: null, state: null,
    effect: "none", identityChecks: [], outcome: "refused", summary: "recovery effect refused", at: new Date().toISOString(), incident: false };
  const lock = acquirePaneLock(initial.target.paneId, 1000, env);
  if (!lock) {
    event.summary = "target effect mutex is busy; no keys sent";
    appendRecoveryEvent(id, event, env);
    return { code: 4, event };
  }
  const authorize = (target: RecoveryTarget) => io.authorize(target, detail => event.identityChecks!.push(detail));
  let attempted = false;
  let counted = false;
  let code = 1;
  try {
    const run = readRun(id, env);
    if (!canAct(run, env, facts?.()) || run.effects >= MAX_EFFECTS) throw new Error("recovery ownership expired, stopped, or exhausted; no keys sent");
    // Caller-supplied effects remain bounded key sequences. OpenCode's typed
    // repaint helper is internal observation hygiene and cannot route argv.
    if (args[0] !== "send-keys" || args[1] !== "-t" || args[2] !== run.target.paneId || args.length < 4) {
      throw new Error("recovery effects are keys to the exact bound pane only");
    }
    const keys = args.slice(3);
    const allowed = new Set(["Escape", "Enter", "C-u", "BSpace", "Up", "Down", "Left", "Right", "Tab", "BTab", "Home", "End", ..."0123456789"]);
    if (keys.length > 6 || (!(keys.length === 2 && keys[0] === "-X" && keys[1] === "cancel") && !keys.every(key => allowed.has(key)))) {
      throw new Error("unsupported recovery key sequence");
    }
    event.state = io.snapshot(run.target);
    if (exited(run, event.state)) {
      event.outcome = "harness-exited"; event.incident = true;
      throw new Error("bound harness was already gone or its registered instance changed before the effect");
    }
    const denied = authorize(run.target);
    if (denied) throw new Error(denied);
    const stem = `effect-${run.effects + 1}-${randomUUID()}`;
    const dir = runDirectory(id, env);
    event.before = join(dir, `${stem}.before.ansi`);
    event.after = join(dir, `${stem}.after.ansi`);
    const beforeFrame = io.capture(run.target);
    writeFileSync(event.before, beforeFrame, { mode: 0o600, flag: "wx" });
    if (exited(run, event.state)) {
      event.outcome = "harness-exited"; event.incident = true;
      throw new Error("INCIDENT: bound harness exited or its registered instance changed before recovery");
    }
    const lateDenial = authorize(run.target);
    if (lateDenial || !canAct(run, env, facts?.())) throw new Error(lateDenial || "recovery expired during before capture");
    const countEffect = () => {
      if (counted) return;
      run.effects++;
      writeRun(run, env);
      counted = true;
    };
    const nudgeEnter = action.startsWith("nudge ") && keys.includes("Enter");
    if (nudgeEnter && isOpenCodeCommand(run.target.harness)) {
      countEffect();
      let firstPostRepaint = beforeFrame;
      if (env.TAP_NUDGE_REPAINTED !== "1") {
        if (!io.repaint) throw new Error("OpenCode repaint is unavailable; no keys sent");
        const repaint = io.repaint(run.target);
        if (repaint.before !== null) writeFileSync(join(dir, `${stem}.repaint-before.ansi`), repaint.before, { mode: 0o600, flag: "wx" });
        if (repaint.after !== null) writeFileSync(join(dir, `${stem}.repaint-after.ansi`), repaint.after, { mode: 0o600, flag: "wx" });
        if (!repaint.ok || repaint.after === null) throw new Error(`${repaint.reason}; no keys sent`);
        firstPostRepaint = repaint.after;
        const repaintDenial = authorize(run.target);
        if (repaintDenial || !canAct(run, env, facts?.())) throw new Error(repaintDenial || "recovery expired after OpenCode repaint");
      } else {
        writeFileSync(join(dir, `${stem}.repaint-after.ansi`), beforeFrame, { mode: 0o600, flag: "wx" });
      }
      io.settle();
      const confirmation = io.capture(run.target);
      writeFileSync(join(dir, `${stem}.repaint-confirm.ansi`), confirmation, { mode: 0o600, flag: "wx" });
      if (!postRepaintSentinelMatches(run, firstPostRepaint) || !postRepaintSentinelMatches(run, confirmation)) {
        throw new Error("expected staged sentinel id was not stable across two post-repaint samples; no keys sent");
      }
    } else if (nudgeEnter &&
        (!run.nudgeExpected || sentinelSubmitDecision(beforeFrame, run.target.harness, run.nudgeExpected, true).action !== "submit")) {
      throw new Error("expected staged sentinel changed before Enter; no keys sent");
    }
    const finalDenial = authorize(run.target);
    if (finalDenial || !canAct(run, env, facts?.())) throw new Error(finalDenial || "recovery expired immediately before the effect");
    countEffect();
    // A crash can leave only intent after keys; it must never certify no effect.
    // Persist this immediately before the key boundary, after any input-free repaint.
    atomicWrite(join(dir, `${stem}.intent.json`), JSON.stringify({ ...event, effect: "possible", outcome: "unverified", state: event.state,
      summary: "effect intent persisted; completion not yet observed", argv: args, deadline: run.deadline }, null, 2));
    attempted = true; event.effect = "possible";
    const result = io.effect(args);
    code = result.code;
    io.settle();
    writeFileSync(event.after, io.capture(run.target), { mode: 0o600, flag: "wx" });
    event.state = io.snapshot(run.target);
    event.incident = exited(run, event.state);
    event.outcome = event.incident ? "harness-exited" : "unverified";
    event.summary = event.incident ? "INCIDENT: harness exited or registered instance changed after recovery; stopped" :
      `attempted ${action}; frames recorded, restored flow still requires submission evidence`;
    if (event.incident || result.code !== 0 || authorize(run.target)) {
      run.state = "stopped";
      if (!event.incident) event.summary = `effect or subsequent identity check unverified; stopped without replay (${result.stderr.trim()})`;
      code = 124; // Existing submit callers treat this as a possible effect, never a clean retry.
    }
    writeRun(run, env);
  } catch (error) {
    if (attempted && event.after && !existsSync(event.after)) {
      try {
        io.settle();
        writeFileSync(event.after, io.capture(initial.target), { mode: 0o600, flag: "wx" });
        event.state = io.snapshot(initial.target);
        event.incident = exited(initial, event.state);
        if (event.incident) event.outcome = "harness-exited";
      } catch {
        try { event.state = io.snapshot(initial.target); event.incident = exited(initial, event.state); }
        catch { /* intent and the unverified event retain the evidence gap */ }
        if (event.incident) event.outcome = "harness-exited";
      }
    }
    event.summary = `${event.incident ? "INCIDENT: bound harness gone; stopped" : attempted ? "post-effect evidence unavailable; no replay" : "refused before keys"}: ${error instanceof Error ? error.message : error}`;
    if (attempted && !event.incident) event.outcome = "unverified";
    code = attempted ? 124 : 1;
    try {
      const run = readRun(id, env);
      run.state = "stopped";
      writeRun(run, env);
    } catch { /* fixed deadline/owner-gone still releases the courier */ }
  } finally {
    try { appendRecoveryEvent(id, event, env); }
    finally { lock.release(); }
  }
  return { code, event };
}


export function recordObservation(run: RecoveryRun, io: EffectIO = REAL_RECOVERY_IO, env = process.env, stage: "initial" | "final" | "inspection" = "inspection"): string {
  const path = join(runDirectory(run.id, env), `${stage}.ansi`);
  const event: RecoveryEvent = { v: 1, recoveryId: run.id, seat: `${run.target.team}/${run.target.handle}`,
    mode: run.mode, action: `inspect:${stage}`, reason: `${run.mode}: observation only, no pane effects`, before: null, after: null,
    state: null, outcome: "unverified", summary: "observation unavailable", at: new Date().toISOString(), incident: false };
  let frame = "", failure: unknown;
  try {
    frame = io.capture(run.target);
    writeFileSync(path, frame, { flag: "wx", mode: 0o600 });
    event.before = path; event.after = path;
    event.state = io.snapshot(run.target);
    event.incident = exited(run, event.state);
    event.outcome = event.incident ? "harness-exited" : "verified";
    event.summary = event.incident ? "INCIDENT: registered harness absent during inspection; no effects" : "inspection captured; no pane effects";
  } catch (error) {
    failure = error;
    try { event.state = io.snapshot(run.target); event.incident = exited(run, event.state); } catch { /* explicit observation gap */ }
    event.outcome = event.incident ? "harness-exited" : "unverified";
    event.summary = `${event.incident ? "INCIDENT: registered harness absent" : "observation unavailable"}: ${error}`;
  }
  appendRecoveryEvent(run.id, event, env);
  if (event.incident) updateRun(run.id, current => { current.state = "stopped"; current.summary = event.summary; }, env);
  if (failure) throw failure;
  if (event.incident && run.mode !== "report-only") throw new Error(event.summary);
  return frame;
}

/** One terminal notification attempt, shared by incident handling and worker completion. */
export function escalateRecovery(id: string, summary: string, env = process.env): number {
  const initial = readRun(id, env);
  const lock = acquirePaneLock(initial.target.paneId, 1000, env);
  if (!lock) throw new Error("cannot record recovery escalation ownership");
  let run: RecoveryRun;
  try {
    run = readRun(id, env);
    if (run.escalationAttemptedAt) return run.escalationCode ?? 1;
    run.escalationAttemptedAt = new Date().toISOString(); run.escalationStatus = "attempted"; run.summary = summary;
    writeRun(run, env);
  } finally { lock.release(); }
  const body = join(runDirectory(id, env), "escalation.md");
  const targetName = `${run.target.team}/${run.target.handle}`;
  const question = summary.startsWith(targetName + ":") ? summary : `${targetName}: ${summary}`;
  writeFileSync(body, `${question}\nRecovery: ${id}\nEvidence: ${runDirectory(id, env)}\n`, { mode: 0o600 });
  const result = spawnSync(process.execPath, [join(scripts, "../../../runtime/bun/src/verbs/escalate.ts"), "--team", run.caller?.team || run.target.team,
    "--from", run.caller?.actor || run.target.handle, "-f", body], { env: { ...env, BUN_BE_BUN: "1" }, encoding: "utf8", timeout: 10_000 });
  atomicWrite(join(runDirectory(id, env), "escalation-result.json"), JSON.stringify({ at: new Date().toISOString(),
    code: result.status, error: result.error?.message, stdout: result.stdout, stderr: result.stderr }));
  const code = result.status ?? 1;
  updateRun(id, current => { current.escalationCode = code; current.escalationStatus = code === 0 ? "delivered" : "unconfirmed"; }, env);
  if (code !== 0) console.error(`tap recovery: user notification unconfirmed; retained ${join(runDirectory(id, env), "escalation-result.json")}`);
  return code;
}
