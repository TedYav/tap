import { CString, dlopen } from "bun:ffi";
import { fstatSync, writeSync } from "node:fs";
import { isatty } from "node:tty";
import { physicalSocketPath, tmux, tmuxReadOnly } from "../tmux";
import { execReachedHarness, LAUNCH_PANE_FORMAT, launchPanePredicate, observeLaunchPane,
  parseLaunchPane, sameLaunchPane, shellQuote, type LaunchPane } from "./effects";

type Terminal = { tty: string; group: number };
type Client = { name: string; pid: string; session: string };
export type AttachIntent = { kind: "refused"; reason: string }
  | { kind: "outside"; terminal: Terminal; socket: string }
  | { kind: "inside"; terminal: Terminal; socket: string; caller: LaunchPane; client: Client };

/** Read the actual std-fd terminal ownership, never a tty inferred from $TMUX. */
export function foregroundTerminal(): Terminal | null {
  if (!isatty(0) || !isatty(1)) return null;
  try {
    if (fstatSync(0).rdev !== fstatSync(1).rdev) return null;
    const libc = dlopen(process.platform === "darwin" ? "/usr/lib/libSystem.B.dylib" : "libc.so.6", {
      getpgrp: { args: [], returns: "i32" },
      tcgetpgrp: { args: ["i32"], returns: "i32" },
      ttyname: { args: ["i32"], returns: "ptr" },
    });
    try {
      const group = libc.symbols.getpgrp();
      if (group <= 0 || libc.symbols.tcgetpgrp(0) !== group || libc.symbols.tcgetpgrp(1) !== group) return null;
      const name = libc.symbols.ttyname(0);
      return name ? { tty: new CString(name).toString(), group } : null;
    } finally { libc.close(); }
  } catch { return null; }
}

function uniqueClient(caller: LaunchPane, env: NodeJS.ProcessEnv): Client | null {
  const result = tmuxReadOnly(["list-clients", "-t", caller.sessionId, "-F", "#{client_name}\t#{client_pid}\t#{client_session}"], env);
  const rows = result.stdout.trim().split("\n").filter(Boolean);
  if (result.code !== 0 || rows.length !== 1) return null;
  const fields = rows[0]!.split("\t");
  const [name, pid, session] = fields;
  if (fields.length !== 3 || !name || !pid || !/^\d+$/.test(pid) || session !== caller.session || /[{},#\r\n]/.test(name + session)) return null;
  return { name, pid, session };
}

function clientPredicate(client: Client): string {
  // if-shell's incidental client context may be a different, more recent client.
  // L: evaluates these fields on each actual client (tmux 3.4+); older servers
  // cannot attest the selected client and remain detached.
  const match = `#{&&:#{==:#{client_name},${client.name}},#{&&:#{==:#{client_pid},${client.pid}},#{==:#{client_session},${client.session}}}}`;
  return `#{==:#{L:#{?${match},1,}},1}`;
}

export function captureAttachIntent(env: NodeJS.ProcessEnv = process.env): AttachIntent {
  const terminal = foregroundTerminal();
  if (!terminal) return { kind: "refused", reason: "caller does not own foreground tty" };
  const socket = physicalSocketPath(env);
  // An explicit launch socket may differ from the inherited caller's server.
  // Observe the caller's real tty there before deciding this is an outside tty.
  const inherited = env.TMUX?.split(",", 1)[0];
  if (inherited && !inherited.startsWith("/")) return { kind: "refused", reason: "tmux caller state unverified" };
  const callerEnv = inherited ? { ...env, TAP_TMUX_SOCKET_PATH: inherited, TAP_TMUX_SOCKET: undefined } : env;
  const inventory = tmuxReadOnly(["list-panes", "-a", "-F", `#{pane_tty}\t${LAUNCH_PANE_FORMAT}`], callerEnv);
  if (inventory.code !== 0) {
    if (/no server running|no sessions|error connecting.*No such file/.test(inventory.stderr)) return { kind: "outside", terminal, socket };
    return { kind: "refused", reason: "tmux caller state unverified" };
  }
  const matches = inventory.stdout.split("\n").filter(line => line.split("\t", 1)[0] === terminal.tty);
  if (!matches.length) return { kind: "outside", terminal, socket };
  if (matches.length !== 1) return { kind: "refused", reason: "caller pane is ambiguous" };
  const caller = parseLaunchPane(matches[0]!.slice(terminal.tty.length + 1), callerEnv);
  if (!caller || caller.dead) return { kind: "refused", reason: "caller pane is unverified" };
  if (physicalSocketPath(callerEnv) !== socket) return { kind: "refused", reason: "caller and launched seat use different tmux servers" };
  const client = uniqueClient(caller, env);
  if (!client) return { kind: "refused", reason: "caller client is ambiguous or unobservable" };
  const attested = tmuxReadOnly(["display-message", "-p", "-t", caller.paneId, clientPredicate(client)], env);
  if (attested.code !== 0 || attested.stdout.trim() !== "1") return { kind: "refused", reason: "tmux cannot attest the selected caller client" };
  return { kind: "inside", terminal, socket, caller, client };
}

const REFUSED = "TAP_LAUNCH_ATTACH_REFUSED";

/** Called only after ready commit and fence release. Refusal never rolls back a ready seat. */
export function attachReady(intent: AttachIntent, pane: LaunchPane, harness: string, env: NodeJS.ProcessEnv = process.env): string | null {
  if (intent.kind === "refused") return intent.reason;
  const terminal = foregroundTerminal();
  if (!terminal || terminal.tty !== intent.terminal.tty || terminal.group !== intent.terminal.group) return "caller terminal custody changed";
  const ready = observeLaunchPane(pane.paneId, env);
  if (!sameLaunchPane(pane, ready) || !execReachedHarness(ready, harness)) return "ready pane is no longer observable";
  const readyPredicate = `#{&&:${launchPanePredicate(ready)},#{&&:#{==:#{pane_dead},0},#{==:#{pane_pid},${ready.pid}}}}`;
  if (intent.kind === "inside") {
    if (!sameLaunchPane(intent.caller, observeLaunchPane(intent.caller.paneId, env))) return "caller pane changed";
    const client = uniqueClient(intent.caller, env);
    if (!client || client.name !== intent.client.name || client.pid !== intent.client.pid) return "caller client changed";
    const switchCommand = `switch-client -c ${shellQuote(client.name)} -t ${shellQuote(ready.address)}`;
    const targetGuard = ["if-shell", "-F", "-t", ready.paneId, readyPredicate, switchCommand, `display-message -p ${REFUSED}`].map(shellQuote).join(" ");
    const result = tmux(["if-shell", "-F", "-t", intent.caller.paneId,
      `#{&&:${launchPanePredicate(intent.caller)},#{&&:#{==:#{session_attached},1},${clientPredicate(client)}}}`, targetGuard, `display-message -p ${REFUSED}`], env);
    return result.code === 0 && !result.stdout.includes(REFUSED) ? null : "caller or target custody could not be verified at switch";
  }
  if (typeof process.execve !== "function") return "this Bun runtime cannot replace itself for attach";
  const binary = Bun.which("tmux", { PATH: env.PATH });
  if (!binary) return "tmux is unavailable";
  const childEnv = Object.fromEntries(Object.entries(env).filter(([key, value]) => value !== undefined && key !== "TMUX" && key !== "TMUX_PANE")) as Record<string, string>;
  const recovery = `tap session: ${pane.session} is running detached (target changed before attach); next: tmux attach -t ${pane.session}`;
  // execve leaves no Bun process alive across tmux's raw-mode transition.
  writeSync(1, `tap session: ${pane.session} is ready; attaching (recovery: tmux attach -t ${pane.session})\n`);
  process.execve(binary, [binary, "-S", intent.socket, "if-shell", "-F", "-t", ready.paneId, readyPredicate,
    `attach-session -t ${shellQuote(ready.address)}`, `display-message -p ${shellQuote(recovery)}`], childEnv);
  return "tmux process replacement failed";
}
