import { lifecycleDiagnostic } from "../lifecycle-diagnostics";
import { startupTrace } from "../startup-trace";
import { spawnSync } from "node:child_process";
import { basename, isAbsolute, resolve } from "node:path";
import { accessSync, constants, existsSync, readFileSync, readlinkSync, statSync } from "node:fs";
import { tmux, tmuxReadOnly, serverEpochFromRaw } from "../tmux";
import { refuse } from "./catalog";
import type { LaunchRequest } from "./request";

export const shellQuote = (value: string): string => `'${value.replace(/'/g, `'"'"'`)}'`;
export const LAUNCH_PANE_FORMAT = "#{pid}:#{start_time}\t#{session_id}\t#{window_id}\t#{pane_id}\t#{session_name}\t#{window_index}\t#{pane_index}\t#{pane_pid}\t#{pane_dead}\t#{pane_current_command}";
export type LaunchPane = {
  rawEpoch: string; epoch: string; sessionId: string; windowId: string; paneId: string;
  session: string; address: string; pid: string; dead: boolean; command: string;
};

export function parseLaunchPane(output: string, env: NodeJS.ProcessEnv): LaunchPane | null {
  const fields = output.replace(/\n$/, "").split("\t");
  if (fields.length !== 10 || fields.some(f => f.includes("\n"))) return null;
  const [rawEpoch, sessionId, windowId, paneId, session, window, pane, pid, dead, command] = fields as [string,string,string,string,string,string,string,string,string,string];
  if (!/^\d+:\d+$/.test(rawEpoch) || !/^\$\d+$/.test(sessionId) || !/^@\d+$/.test(windowId) ||
      !/^%\d+$/.test(paneId) || !/^\d+$/.test(window) || !/^\d+$/.test(pane) || !/^\d+$/.test(pid) || !/^[01]$/.test(dead)) return null;
  return { rawEpoch, epoch: serverEpochFromRaw(rawEpoch, env), sessionId, windowId, paneId,
    session, address: `${session}:${window}.${pane}`, pid, dead: dead === "1", command };
}

export function observeLaunchPane(target: string, env: NodeJS.ProcessEnv): LaunchPane | null {
  const result = tmuxReadOnly(["display-message", "-p", "-t", target, LAUNCH_PANE_FORMAT], env);
  return result.code === 0 ? parseLaunchPane(result.stdout, env) : null;
}

export function sameLaunchPane(expected: LaunchPane, actual: LaunchPane | null): actual is LaunchPane {
  return !!actual && expected.rawEpoch === actual.rawEpoch && expected.sessionId === actual.sessionId &&
    expected.windowId === actual.windowId && expected.paneId === actual.paneId && expected.session === actual.session;
}

function launchTmux(args: string[], env: NodeJS.ProcessEnv) {
  try {
    const result = tmux(args, env);
    lifecycleDiagnostic("tmux_result", { command: args[0], exit_code: result.code, stderr: result.stderr }, env);
    return result;
  }
  catch (error) {
    const result = (error as { tmuxResult?: { code: number; stderr: string } }).tmuxResult;
    startupTrace("tmux_result", { command: args[0], exit_code: result?.code ?? null,
      stderr: result?.stderr ?? "", error: (error as Error).name });
    throw error;
  }
}

export function tmuxEffect(args: string[], env: NodeJS.ProcessEnv): string {
  const result = launchTmux(args, env);
  if (result.code !== 0) {
    startupTrace("tmux_result", { command: args[0], exit_code: result.code, stderr: result.stderr });
    refuse("launcher_tmux_failed", `${args[0]}: ${result.stderr.trim() || "tmux failed"}`);
  }
  return result.stdout;
}

export function launchPanePredicate(pane: LaunchPane): string {
  const terms = [
    `#{==:#{pid}:#{start_time},${pane.rawEpoch}}`, `#{==:#{session_id},${pane.sessionId}}`,
    `#{==:#{window_id},${pane.windowId}}`, `#{==:#{pane_id},${pane.paneId}}`,
  ];
  return terms.reduce((a, b) => `#{&&:${a},${b}}`);
}

/** The server checks identity and acts in one command; a recycled pane is never cleanup's target. */
export function onOwnedPane(pane: LaunchPane, command: string, env: NodeJS.ProcessEnv, allowGone = false): boolean {
  const predicate = launchPanePredicate(pane);
  const result = launchTmux(["if-shell", "-F", "-t", pane.paneId, predicate, command, "display-message -p TAP_LAUNCH_IDENTITY_MOVED"], env);
  if (allowGone && /no server running|no sessions|can't find pane|error connecting.*No such file/.test(result.stderr)) return true;
  if (result.code !== 0) {
    startupTrace("tmux_result", { command: "owned-pane effect", exit_code: result.code, stderr: result.stderr });
    refuse("launcher_tmux_failed", result.stderr.trim() || "owned-pane effect failed");
  }
  if (result.stdout.trim() === "TAP_LAUNCH_IDENTITY_MOVED") {
    if (!allowGone) refuse("launcher_identity_changed", "pane identity changed before the tmux effect");
    return false;
  }
  return true;
}

/** Only verifies the root process this launcher exec'd; not a fleet classifier. */
export function execReachedHarness(pane: LaunchPane, harness: string): boolean {
  if (pane.dead) return false;
  // Linux comm can be the script filename while its interpreter is still running.
  if (process.platform === "linux") {
    try {
      const root = `/proc/${pane.pid}`;
      const path = readFileSync(`${root}/environ`, "utf8").split("\0").find(v => v.startsWith("PATH="))?.slice(5);
      if (path === undefined) return false;
      const cwd = readlinkSync(`${root}/cwd`);
      const running = statSync(`${root}/exe`);
      for (const dir of path.split(":")) {
        const candidate = resolve(cwd, dir, harness);
        try {
          accessSync(candidate, constants.X_OK);
          const selected = statSync(candidate);
          if (!selected.isFile()) continue;
          return selected.dev === running.dev && selected.ino === running.ino;
        } catch { /* PATH lookup continues past absent or inaccessible entries. */ }
      }
      return false;
    } catch { return false; }
  }
  const result = spawnSync("ps", ["-p", pane.pid, "-o", "comm="], {
    encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: 1000, killSignal: "SIGKILL", maxBuffer: 4096,
  });
  return result.status === 0 && basename(result.stdout.trim()) === harness;
}

export function harnessCommand(request: LaunchRequest, env: NodeJS.ProcessEnv): string {
  const shell = [env.TAP_LAUNCH_SHELL, env.SHELL, "/bin/zsh", "/bin/bash", "/bin/sh"]
    .find(path => path && isAbsolute(path) && ["bash", "zsh", "sh", "dash", "ksh"].includes(basename(path)) && existsSync(path));
  if (!shell) refuse("launcher_shell_missing", "no login shell is available");
  // Env changes happen AFTER login startup. All values remain argv data, including prompts.
  const staleIdentity = ["CLAUDECODE", "CLAUDE_CODE_SESSION_ID", "CODEX_THREAD_ID", "TAP_SELF", "TAP_HARNESS_SESSION_ID",
    "TAP_TRANSCRIPT_PATH", "TAP_CLEAR_ID", "TAP_REGISTER_EXPECTED_HARNESS", "TAP_REGISTER_SUPPRESS_IDENTITY_CAPTURE",
    "TAP_HOME", "TAP_INDEX_HOME", "TAP_TMUX_SOCKET", "TAP_TMUX_SOCKET_PATH"];
  const command = ["/usr/bin/env", ...staleIdentity.flatMap(key => ["-u", key]),
    ...(request.unsetEnv ?? []).flatMap(key => ["-u", key]),
    ...(env.TAP_INDEX_HOME ? [`TAP_INDEX_HOME=${env.TAP_INDEX_HOME}`] : []),
    ...Object.entries(request.env).map(([k,v]) => `${k}=${v}`), ...request.argv];
  return [shell, "-lic", 'exec "$0" "$@"', ...command].map(shellQuote).join(" ");
}
