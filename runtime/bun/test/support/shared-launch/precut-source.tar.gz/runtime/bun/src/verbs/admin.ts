// `tap admin` (admin-r7): checkpoints A/B brought the grammar, the dashboard,
// refresh, retire and rebuild-registry native; checkpoint C routed every
// public form to this engine and deleted the tap-admin.sh body in the same
// commit. The behavior map WAS that deleted Bash body; every refusal string,
// default and exit code here is carried
// from it, with the ruled repairs: the H1 authority check (an indexed acting
// registry that is specifically ENOENT is registry_missing, even over a bus
// decoy; an unprovable location is cannot-check) and the P2 join fix (a
// non-string seat field corrupts the team instead of normalizing to healthy).
import { spawnSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import { closeSync, existsSync, mkdirSync, mkdtempSync, openSync, readFileSync, readdirSync, renameSync, rmSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

import { ensureAscii } from "../fsatomic";
import { markerSelectedIndex } from "../index-home";
import { pyReadUtf8 } from "../spool-publication";
import { cmdSubst, dumps, isMap, loads, pyTruthy, pyTypeName, type JsonMap, type JsonValue } from "../watch-detect";
import { libCall } from "../watch-detectors";
import { frontmatterFields, PY_STRIP } from "../payload-fields";
import { appendRegistryEventOrWarn, registryEventsPath } from "../events";
import { acquirePathLock } from "../panelock";
import { spoolTeamName } from "../context";
import type { ObserveEngine } from "../observe";
import { observe, type RegistryRow } from "./team";
import { cmdAdminRebuild } from "./admin-rebuild";
import { TapError } from "../context";

export const ADMIN_SUBCOMMANDS = ["dashboard", "refresh", "retire", "rebuild-registry", "migrate-registry", "prune"];
const USAGE = "tap admin [dashboard]|refresh|retire|rebuild-registry|migrate-registry";
const DASHBOARD_LABEL = "tap admin dashboard";
const MISSING_REASON = "no .tap/bus or tmp/tap registry.json found under an enrolled root";

interface AdminOptions { json: boolean; full: boolean; verbose: boolean; staleAfter: number; staleAfterRaw: string }
interface Obligation { id: string; age: number | null }
interface SeatScan {
  team: string; handle: string; status: string; pane: string; paneId: string; harness: string; delivery: string;
  statusReason: string; registeredAt: string; session: string; serverEpoch: string; bootId: string;
  fingerprint: string; paneAlive: boolean | null; paneReason: string; seatState: string;
  inbound: Obligation[]; outstanding: Obligation[]; staleIds: string[];
}
interface TeamScan {
  index: { name: string; root: string; exists: boolean; registryLocation: string };
  bus: string; registry: string;
  unreadableKind: "" | "registry_missing" | "registry_corrupt";
  unreadableReason: string;
  seats: SeatScan[];
}
interface AttentionRow {
  team: string; handle: string; state: string; why: string;
  obligations: { inbound_unsettled: number; outstanding_unsettled: number; sample_ids: string[] };
}

const isFile = (path: string): boolean => { try { return statSync(path).isFile(); } catch { return false; } };
const isDir = (path: string): boolean => { try { return statSync(path).isDirectory(); } catch { return false; } };

/**
 * H1 local semantics (checkpoint B ruling): an indexed acting registry whose
 * stat fails SPECIFICALLY ENOENT is data-gone — registry_missing, purgeable.
 * Every other unprobeable shape (an empty or non-string location, EACCES,
 * ENOTDIR through a file parent) is cannot-check: present-or-unproven data is
 * never auto-purged.
 */
function classifyLocation(path: string): "present" | "enoent" | "unprobeable" {
  if (!path) return "unprobeable";
  try { return statSync(path).isFile() ? "present" : "unprobeable"; }
  catch (error) { return (error as NodeJS.ErrnoException | null)?.code === "ENOENT" ? "enoent" : "unprobeable"; }
}
// python's sorted() compares strings by CODE POINT (registry.ts's byCodePoint
// shape): the UTF-16 code-unit `<`/`>` sort puts an astral surrogate pair
// (0xD800…) BELOW U+E000, python puts it ABOVE — a fingerprint would differ.
const codePointOrder = (a: string, b: string): number => {
  const ca = Array.from(a, c => c.codePointAt(0)!);
  const cb = Array.from(b, c => c.codePointAt(0)!);
  for (let i = 0; i < Math.min(ca.length, cb.length); i++) {
    if (ca[i] !== cb[i]) return ca[i]! - cb[i]!;
  }
  return ca.length - cb.length;
};

export function cmdAdmin(argv: string[], scriptsDir: string, engine?: ObserveEngine): number {
  const args = [...argv];
  let sub = "dashboard";
  // A leading --* selects the dashboard without a shift, exactly as the
  // incumbent's `case $1 in --*)` arm does.
  if (args.length && !args[0]!.startsWith("--")) sub = args.shift()!;
  if (!ADMIN_SUBCOMMANDS.includes(sub)) {
    throw new TapError(1, "unknown_subcommand", "tap help admin", `unknown subcommand '${sub}' (usage: ${USAGE})`, "tap");
  }
  if (sub === "prune") {
    // The prune pre-scan ORs --json starting from the AMBIENT value, before the
    // dispatcher's TAP_JSON clobber would ever run on this subcommand.
    if (args.includes("--json")) process.env.TAP_JSON = "1";
    throw new TapError(1, "renamed_verb", "tap admin refresh   # or: tap admin retire <team>",
      "tap admin prune is now: tap admin refresh plus tap admin retire <team>", "tap admin prune");
  }
  if (sub === "refresh") return cmdAdminRefresh(args, scriptsDir, engine);
  if (sub === "retire") return cmdAdminRetire(args, scriptsDir);
  if (sub === "rebuild-registry") return cmdAdminRebuild(args, scriptsDir);
  if (sub === "migrate-registry") return migrateRegistry(args, scriptsDir);
  return cmdAdminDashboard(args, scriptsDir, engine);
}

function migrateRegistry(args: string[], scriptsDir: string): number {
  let yes = false; let json = false;
  for (const arg of args) {
    if (arg === "--yes") yes = true;
    else if (arg === "--json") json = true;
    else if (arg.startsWith("--")) {
      // Parse refusals honor the ambient TAP_JSON: the export happens after the loop.
      throw new TapError(1, "unknown_option", "tap help admin migrate-registry", `unknown option '${arg}'`, "tap admin migrate-registry");
    } else {
      throw new TapError(1, "usage_error", "tap help admin", `unexpected arg '${arg}'`, "tap admin migrate-registry");
    }
  }
  if (json) process.env.TAP_JSON = "1";
  const child = spawnSync("python3", ["-B", join(scriptsDir, "registry_migrate.py"), ...(yes ? ["--yes"] : []), ...(json ? ["--json"] : [])], { stdio: "inherit", env: process.env });
  return child.status ?? (child.error ? 127 : 1);
}

function parseDashboardOptions(args: string[]): AdminOptions {
  const options: AdminOptions = { json: false, full: false, verbose: false, staleAfter: 900, staleAfterRaw: "900" };
  const refuse = (errorClass: "unknown_option" | "usage_error", detail: string): never => {
    throw new TapError(1, errorClass, "tap help admin dashboard", detail, DASHBOARD_LABEL);
  };
  for (let i = 0; i < args.length; i++) {
    const arg = args[i]!;
    if (arg === "--json") { options.json = true; process.env.TAP_JSON = "1"; }
    else if (arg === "--full") options.full = true;
    else if (arg === "--verbose") options.verbose = true;
    else if (arg === "--stale-after") {
      // The incumbent's `${2:?--stale-after needs a value}`: unset or empty
      // value refuses here, exit 1, before any later flag is examined.
      const value = args[i + 1];
      if (value === undefined || value === "") refuse("usage_error", "--stale-after needs a value");
      options.staleAfterRaw = value!;
      options.staleAfter = Number(value);
      i++;
    }
    else if (arg.startsWith("--")) refuse("unknown_option", `unknown option '${arg}'`);
    else refuse("usage_error", `unexpected arg '${arg}'`);
  }
  if (!/^\d+$/.test(options.staleAfterRaw)) refuse("usage_error", `--stale-after needs a non-negative integer, got '${options.staleAfterRaw}'`);
  return options;
}

export function readMachineIndex(path: string): Array<{ name: string; root: string; exists: boolean; registryLocation: string }> {
  const refusal = (): TapError => new TapError(1, "registry_invalid", "tap admin dashboard",
    `machine index '${path}' could not be read — cannot check`, DASHBOARD_LABEL);
  if (!existsSync(path)) return [];
  let raw: string;
  try { raw = pyReadUtf8(path); } catch (error) {
    // Open/read failures (EACCES, a directory, an ENOENT race) get python's
    // own text through the path-keyed probe — a second readFileSync here
    // would throw again while formatting the refusal.
    process.stderr.write(`tap admin: machine index '${path}' is invalid JSON (${pythonProbeLoadError(path)})\n`);
    throw refusal();
  }
  let doc: JsonValue;
  try { doc = loads(raw); } catch (error) {
    process.stderr.write(`tap admin: machine index '${path}' is invalid JSON (${pythonLoadErrorText(Buffer.from(raw, "utf8"))})\n`);
    throw refusal();
  }
  if (!isMap(doc)) throw refusal();
  const teamsRaw = doc.get("teams");
  const entries: Array<[string, JsonValue]> = !pyTruthy(teamsRaw) ? [] : isMap(teamsRaw) ? [...teamsRaw] : (() => { throw refusal(); })();
  const rows: Array<{ name: string; root: string; exists: boolean; registryLocation: string }> = [];
  for (const [name, ent] of entries.sort(([a], [b]) => codePointOrder(a, b))) {
    if (!isMap(ent)) {
      process.stderr.write(`tap admin: machine index '${path}' entry '${name}' is invalid (expected object)\n`);
      throw refusal();
    }
    if ((typeof ent.get("state") === "string" && ent.get("state") ? ent.get("state") : "registered") === "historical") continue;
    const rootRaw = ent.get("root");
    // The incumbent applies ONLY the absent-key default (`ent.get("root", "")`):
    // an absent or empty-string root is the dangling shape, while any other
    // falsy value fails the row join and a truthy non-string fails isdir —
    // registry_invalid either way, with python's deterministic final line.
    if (rootRaw === undefined || rootRaw === "") {
      rows.push({ name, root: "", exists: false, registryLocation: "" });
      continue;
    }
    if (typeof rootRaw !== "string") {
      // The incumbent's reader dies on a present non-string root either in
      // os.path.isdir (which accepts ints as descriptors — ints and bools
      // reach the row join) or in that join. Python's real final line comes
      // from replaying exactly those two operations on the parsed entry, never
      // from a synthesized guess; the traceback frames are the ruled drop.
      process.stderr.write(`${pythonEntryRowError(ent)}\n`);
      throw refusal();
    }
    rows.push({
      name, root: rootRaw, exists: isDir(rootRaw),
      registryLocation: typeof ent.get("registry_location") === "string" ? ent.get("registry_location") as string : "",
    });
  }
  return rows;
}

/**
 * The incumbent's corrupt-path stderr detail IS python's own str(exception).
 * On the already-decided corrupt path one pure, read-only python probe returns
 * the real final text — JSONDecodeError positions, UnicodeDecodeError byte and
 * position, the BOM note — verbatim, instead of a hand-maintained emulation.
 * The probe reads TEXT like the incumbent's `open(path)`: a strict UTF-8
 * decode that PRESERVES a leading BOM as U+FEFF for json.loads to reject.
 * Python's binary stream door silently consumes the BOM and would mis-answer.
 */
export function pythonLoadErrorText(bytes: Buffer): string {
  const probe = spawnSync("python3", ["-B", "-c", "import json,sys\ntry:\n json.loads(sys.stdin.buffer.read().decode('utf-8'))\nexcept Exception as e:\n sys.stdout.write(str(e))"], { input: bytes, encoding: "utf8" });
  // The probe exits 0 either way — empty stdout is the only "python parsed
  // what our reader refused" answer, which is a reader bug, not a document to
  // diagnose; say so rather than invent a python text.
  return probe.stdout || "untranslated: our reader refused a document python accepts";
}

/** The same probe keyed by PATH, for failures to open/read at all (EACCES, a
 * directory, an ENOENT race): json.load(open(path)), str(exception). Callers
 * must have already classified the location — this only recovers python's
 * refusal text without a second throw of our own. */
export function pythonProbeLoadError(path: string): string {
  const probe = spawnSync("python3", ["-B", "-c", "import json,sys\ntry:\n json.load(open(sys.argv[1]))\nexcept Exception as e:\n sys.stdout.write(str(e))", path], { encoding: "utf8" });
  return probe.stdout || "untranslated: our reader refused a document python accepts";
}

const ENTRY_ROW_REPLAY = "import json,sys,os\nent=json.load(sys.stdin.buffer)\nroot=ent.get('root','')\ntry:\n sys.stdout.write('\\x1f'.join(['row',root,'1' if root and os.path.isdir(root) else '0']))\nexcept Exception as e:\n sys.stdout.write(str(e))";

/**
 * A present non-string index root kills the incumbent's reader either in
 * `os.path.isdir` (which accepts ints as descriptors — ints and bools reach
 * the row join) or in that join; python's real final line comes from replaying
 * exactly those two operations on the losslessly parsed entry, never from a
 * synthesized guess.
 */
function pythonEntryRowError(entry: JsonMap): string {
  const probe = spawnSync("python3", ["-B", "-c", ENTRY_ROW_REPLAY], { input: Buffer.from(dumps(entry, true), "utf8"), encoding: "utf8" });
  return probe.stdout || "untranslated: our reader refused an entry python accepts";
}

export function busForRoot(root: string): string {
  const current = join(root, ".tap", "bus");
  if (isDir(current)) return current;
  const legacy = join(root, "tmp", "tap");
  return isDir(legacy) ? legacy : "";
}

const REGISTRY_SERIALIZE = "import json,sys\njson.dump(json.load(sys.stdin), sys.stdout, indent=2, sort_keys=True)\nsys.stdout.write(\"\\n\")";

/**
 * The incumbent publishes every registry rewrite through python's
 * `json.dump(reg, fh, indent=2, sort_keys=True)` + trailing newline. The
 * document (already decided, already mutated) is serialized by the same pure
 * python probe pattern the corrupt-path rulings pinned — float reprs, wide
 * ints and escaping stay python's own — while the write itself (temp file in
 * the registry's directory, rename over the target) stays local.
 */
export function serializeRegistryDocument(doc: JsonValue): string {
  const probe = spawnSync("python3", ["-B", "-c", REGISTRY_SERIALIZE], { input: Buffer.from(dumps(doc, true), "utf8"), encoding: "utf8" });
  if (probe.status !== 0 || !probe.stdout) throw new Error(`registry serialization probe failed: ${probe.stderr}`);
  return probe.stdout;
}

/** mkstemp-in-dir + rename, the incumbent's atomic publish shape. */
function publishRegistryDocument(doc: JsonValue, path: string): void {
  const body = serializeRegistryDocument(doc);
  const dir = join(path, "..");
  // Node has no mkstemp; a private temp directory yields the same unique-name
  // guarantee, and the rename moves the file out before the directory goes.
  const scratch = mkdtempSync(join(dir, ".tap."));
  const tmp = join(scratch, "registry");
  try {
    // Explicit 0600: the temp is always freshly created, so the mode applies
    // regardless of the operator's umask, and the registry never widens.
    writeFileSync(tmp, body, { encoding: "utf8", mode: 0o600 });
    renameSync(tmp, path);
  } finally {
    rmSync(scratch, { recursive: true, force: true });
  }
}

function scanUnsettled(bus: string, localTeam: string, now: number): { inbound: Map<string, Obligation[]>; outstanding: Map<string, Obligation[]> } {
  const inbound = new Map<string, Obligation[]>();
  const outstanding = new Map<string, Obligation[]>();
  const push = (map: Map<string, Obligation[]>, key: string, obligation: Obligation) => {
    const list = map.get(key);
    if (list) list.push(obligation); else map.set(key, [obligation]);
  };
  const payloads = join(bus, "payloads");
  if (!isDir(payloads)) return { inbound, outstanding };
  const receipts = join(bus, "receipts");
  const local = localTeam.replace(PY_STRIP, "");
  for (const name of readdirSync(payloads).sort()) {
    // tap_frontmatter.list_payload_paths's glob never matches dotfiles and the
    // scanner skips _-drafts: a hidden .ghost.md is not an obligation.
    if (!name.endsWith(".md") || name.startsWith("_") || name.startsWith(".")) continue;
    const id = name.slice(0, -".md".length);
    if (existsSync(join(receipts, `${id}.done`))) continue;
    // The incumbent's scanner decodes with errors='replace' and treats any
    // read failure as an empty field map; only the mtime failure nulls the age.
    let fields: Record<string, string>;
    try { fields = frontmatterFields(readFileSync(join(payloads, name), "utf8")); } catch { fields = {}; }
    let age: number | null;
    try { age = Math.max(0, now - Math.floor(statSync(join(payloads, name)).mtimeMs / 1000)); } catch { age = null; }
    const from = fields.from ?? "";
    const to = fields.to ?? "";
    const toTeam = (fields.to_team ?? "").replace(PY_STRIP, "");
    if (to && (toTeam === "" || toTeam === local)) push(inbound, to, { id, age });
    if (from) push(outstanding, from, { id, age });
  }
  return { inbound, outstanding };
}

function sortJson(value: JsonValue): JsonValue {
  if (Array.isArray(value)) return value.map(sortJson);
  if (value instanceof Map) return new Map([...value].sort(([a], [b]) => codePointOrder(a, b)).map(([k, x]) => [k, sortJson(x)] as [string, JsonValue]));
  return value;
}

/** python base64.urlsafe_b64encode(json.dumps(seat, sort_keys, compact)) — padded. */
export function fingerprintOf(seat: JsonMap): string {
  const encoded = Buffer.from(dumps(sortJson(seat), true), "utf8").toString("base64url");
  return encoded + "=".repeat((4 - (encoded.length % 4)) % 4);
}

function scanTeam(row: { name: string; root: string; exists: boolean; registryLocation: string }, marker: "live" | "absent", now: number, staleAfter: number, withObligations: boolean): TeamScan {
  const team: TeamScan = { index: row, bus: "", registry: "", unreadableKind: "", unreadableReason: "", seats: [] };
  const unreadable = (kind: "registry_missing" | "registry_corrupt", reason: string) => {
    team.unreadableKind = kind;
    team.unreadableReason = reason;
    return team;
  };
  // A dangling root is never probed: the enrollment itself is what is gone.
  if (!row.exists) return team;
  const bus = busForRoot(row.root);
  let registry: string;
  if (marker === "live") {
    // H1 repair: the indexed acting registry is the authority, so its exact
    // location is classified BEFORE any bus requirement. A location that is
    // SPECIFICALLY gone (ENOENT) makes the team registry_missing — data is
    // gone, purgeable — even though the legacy bus below still carries a decoy
    // the incumbent's soft rebind misread as the roster. An unprovable
    // location (empty/non-string, EACCES, ENOTDIR) is cannot-check instead:
    // present-or-unproven data is never auto-purged. A PRESENT registry parses
    // even when the bus is gone: the roster survives, but with no bus the
    // unsettled scan stays empty, seat state stays unknown (payloads are never
    // probed through a relative path), and no registry event is attempted.
    registry = row.registryLocation;
    const verdict = classifyLocation(registry);
    if (verdict === "enoent") return unreadable("registry_missing", MISSING_REASON);
    if (verdict === "unprobeable") {
      return unreadable("registry_corrupt", registry
        ? `registry.json at ${registry} could not be parsed as JSON`
        : "no acting registry location is indexed for this team");
    }
  } else {
    if (!bus) return unreadable("registry_missing", MISSING_REASON);
    registry = join(bus, "registry.json");
    if (!isFile(registry)) return unreadable("registry_missing", MISSING_REASON);
  }
  team.bus = bus;
  team.registry = registry;
  let raw: string;
  try { raw = pyReadUtf8(registry); } catch {
    // The incumbent's reader wraps decode failures in the same line as parse
    // failures; the detail is python's str(UnicodeDecodeError) of the bytes.
    process.stderr.write(`registry.json is invalid JSON (${pythonProbeLoadError(registry)})\n`);
    return unreadable("registry_corrupt", `registry.json at ${registry} could not be parsed as JSON`);
  }
  let doc: JsonValue;
  try { doc = loads(raw); } catch (error) {
    process.stderr.write(`registry.json is invalid JSON (${pythonLoadErrorText(Buffer.from(raw, "utf8"))})\n`);
    return unreadable("registry_corrupt", `registry.json at ${registry} could not be parsed as JSON`);
  }
  if (!isMap(doc)) {
    // A readable non-dict registry dies in python inside `_seat_map`
    // (`data.get`); the exception line is deterministic, the <stdin> traceback
    // around it is not reproduced.
    process.stderr.write(`AttributeError: '${pyTypeName(doc)}' object has no attribute 'get'\n`);
    return unreadable("registry_corrupt", `registry.json at ${registry} could not be parsed as JSON`);
  }
  const seatsRaw = doc.get("seats");
  const seats = isMap(seatsRaw) ? seatsRaw : isMap(doc.get("agents")) ? doc.get("agents") as JsonMap : new Map();
  const partial: SeatScan[] = [];
  for (const handle of [...seats.keys()].sort(codePointOrder)) {
    const seat = seats.get(handle);
    if (!isMap(seat)) continue;
    const pick = (key: string, fallback: string): JsonValue => (seat.has(key) ? seat.get(key)! : fallback);
    // Incumbent defaults first (python .get semantics: the fallback applies
    // only when the key is ABSENT — a null value stays null), then the join
    // requires strings. Any non-string crashed the incumbent's reader with a
    // TypeError and left the whole team corrupt (P2: never normalize to healthy).
    const deliveryValue = pyTruthy(seat.get("delivery")) ? seat.get("delivery")! : "pane";
    const joined = [
      pick("status", "active"), pick("pane", ""), pick("pane_id", ""), pick("harness", ""),
      deliveryValue, pick("status_reason", ""), pick("registered_at", ""), pick("session", ""),
      pick("server_epoch", ""), pick("boot_id", ""),
    ];
    if (joined.some(value => typeof value !== "string")) {
      // The incumbent's reader dies here on python's str-join TypeError; the
      // deterministic exception line is kept, the <stdin> traceback is not.
      const bad = joined.findIndex(value => typeof value !== "string");
      process.stderr.write(`TypeError: sequence item ${bad}: expected str instance, ${pyTypeName(joined[bad]!)} found\n`);
      return unreadable("registry_corrupt", `registry.json at ${registry} could not be parsed as JSON`);
    }
    const [status = "", pane = "", paneId = "", harness = "", delivery = "", statusReason = "", registeredAt = "", session = "", serverEpoch = "", bootId = ""] = joined as string[];
    partial.push({
      team: row.name, handle, status, pane, paneId, harness, delivery, statusReason, registeredAt,
      session, serverEpoch, bootId, fingerprint: fingerprintOf(seat),
      paneAlive: null, paneReason: "", seatState: "", inbound: [], outstanding: [], staleIds: [],
    });
  }
  team.seats = partial;
  // Only the dashboard reads obligation history; refresh's registry work
  // never opens payloads or receipts.
  const unsettled = withObligations && bus
    ? scanUnsettled(bus, row.name, now)
    : { inbound: new Map<string, Obligation[]>(), outstanding: new Map<string, Obligation[]>() };
  for (const seat of team.seats) {
    seat.inbound = unsettled.inbound.get(seat.handle) ?? [];
    seat.outstanding = unsettled.outstanding.get(seat.handle) ?? [];
    // Strictly greater than the threshold; an unmeasurable age is never stale.
    seat.staleIds = seat.outstanding.filter(o => o.age !== null && o.age > staleAfter).map(o => o.id);
  }
  return team;
}

/**
 * ONE shared observation across every team, like the incumbent's single
 * classifier batch. The dashboard observes active pane seats; refresh observes
 * EVERY pane seat — a suspended row whose pane is gone is exactly what it
 * trims. Returns the classifier's failure code, never a half-roster.
 */
function observeTeams(teams: TeamScan[], scriptsDir: string, engine: ObserveEngine | undefined, refreshAll: boolean): number {
  const rows: RegistryRow[] = [];
  const byKey = new Map<string, SeatScan>();
  for (const team of teams) {
    for (const seat of team.seats) {
      if (seat.delivery === "poll") continue;
      if (!refreshAll && seat.status !== "active") continue;
      const key = JSON.stringify([seat.team, seat.handle]);
      rows.push({
        team: seat.team, handle: key, harness: seat.harness, pane: seat.pane, status: seat.status,
        status_reason: seat.statusReason, delivery: seat.delivery, pane_id: seat.paneId,
        unattended: "", session: seat.session, registered_at: seat.registeredAt, crew: "",
        server_epoch: seat.serverEpoch, boot_id: seat.bootId, preset: "",
      });
      byKey.set(key, seat);
    }
  }
  if (!rows.length) return 0;
  const observations = observe(rows, scriptsDir, false, undefined, engine);
  // A classifier that could not run is not a roster of unknowns: propagate
  // the failure instead of rendering "active" teams it never observed.
  if (observations.code !== 0) return observations.code;
  for (const [key, seat] of byKey) {
    const fields = observations.rows.get(key);
    seat.paneReason = fields?.[1] ?? "";
    const state = fields?.[0] ?? "";
    if (state === "active") seat.paneAlive = true;
    else if (state === "gone") seat.paneAlive = false;
  }
  return 0;
}

function classifyTeam(team: TeamScan): "active" | "dormant" | "dangling" | "unreadable" {
  if (!team.index.exists) return "dangling";
  if (team.unreadableKind) return "unreadable";
  const panes = team.seats.filter(seat => seat.delivery !== "poll");
  if (!panes.length) return "active";
  for (const seat of panes) {
    if (seat.status === "suspended") continue;
    if (seat.paneAlive !== false) return "active";
  }
  return "dormant";
}

const PURGE_REASON_TEXT: Record<string, string> = { root_gone: "worktree root gone", registry_missing: "registry file missing" };

/**
 * `tap admin refresh` (admin-r7 U3): report and trim dead panes whose captured
 * roster row is unchanged under the registry lock, purge data-gone teams
 * through retire's index writer, and surface dormant retire candidates. A
 * --dry-run renders byte-identical output and writes nothing at all.
 */
function cmdAdminRefresh(args: string[], scriptsDir: string, engine?: ObserveEngine): number {
  // The incumbent clobbers TAP_JSON=0 after sub dispatch, before the flag table.
  process.env.TAP_JSON = "0";
  let dryRun = false;
  for (const arg of args) {
    if (arg === "--json") process.env.TAP_JSON = "1";
    else if (arg === "--dry-run") dryRun = true;
    else if (arg.startsWith("--")) throw new TapError(1, "unknown_option", "tap help admin refresh", `unknown option '${arg}'`, "tap admin refresh");
    else throw new TapError(1, "usage_error", "tap help admin refresh", `unexpected arg '${arg}'`, "tap admin refresh");
  }
  const json = process.env.TAP_JSON === "1";
  const selected = markerSelectedIndex();
  if (selected.marker === "invalid") {
    throw new TapError(1, "invalid_flip", "tap doctor",
      "global-registry.json is present but unreadable or wrong schema — refusing admin index ops", "tap admin refresh");
  }
  const rawNow = process.env.TAP_WATCH_NOW;
  const now = rawNow ? Number(rawNow) : Math.floor(Date.now() / 1000);
  const teams = readMachineIndex(selected.path).map(row => scanTeam(row, selected.marker, now, 900, false));
  if (observeTeams(teams, scriptsDir, engine, true) !== 0) return 1;

  const classes = new Map(teams.map(team => [team.index.name, classifyTeam(team)]));
  const corruptReason = new Map<string, string>();
  for (const team of teams) {
    if (team.unreadableKind === "registry_corrupt") corruptReason.set(team.index.name, team.unreadableReason);
  }
  const missing: Array<{ team: string; reason: string }> = [];
  for (const team of teams) {
    if (!team.index.exists) missing.push({ team: team.index.name, reason: "root_gone" });
    else if (team.unreadableKind === "registry_missing") missing.push({ team: team.index.name, reason: "registry_missing" });
  }
  // Data-gone teams are REPORTED in a dry run too (byte-consistent with a real
  // run); only the de-enrollment itself is a real-run side effect.
  const purged = missing.map(entry => ({ team: entry.team, reason: entry.reason }));
  const retireCandidates = teams
    .filter(team => classes.get(team.index.name) === "dormant")
    .map(team => {
      const pollMembers = team.seats.filter(seat => seat.delivery === "poll").map(seat => seat.handle).sort(codePointOrder);
      const blockedBy = pollMembers.length ? [`poll-mode members: ${pollMembers.join(",")}`] : [];
      return { team: team.index.name, classification: "dormant", blocked_by: blockedBy, recommended: blockedBy.length === 0 };
    });

  // TRIM: a registry that turned corrupt between the scan and the locked
  // reload joins cannot-check instead of mutating (present-but-broken data is
  // never trimmed or purged).
  const trimmed: Array<{ team: string; handle: string; pane: string; reason: string }> = [];
  for (const team of teams) {
    if (!team.index.exists || team.unreadableKind || !team.registry) continue;
    const candidates = team.seats
      .filter(seat => seat.delivery !== "poll" && seat.paneAlive === false)
      .sort((a, b) => codePointOrder(a.handle, b.handle));
    if (!candidates.length) continue;
    let trimmedHandles: string[] = [];
    if (!dryRun) {
      const lock = acquirePathLock(`${team.registry}.lock`);
      if (!lock) {
        corruptReason.set(team.index.name, `registry.json at ${team.registry} stayed locked during refresh`);
        continue;
      }
      try {
        let raw: string;
        try { raw = pyReadUtf8(team.registry); } catch {
          corruptReason.set(team.index.name, `registry.json at ${team.registry} could not be parsed during refresh (${pythonProbeLoadError(team.registry)})`);
          continue;
        }
        let doc: JsonValue;
        try { doc = loads(raw); } catch {
          corruptReason.set(team.index.name, `registry.json at ${team.registry} could not be parsed during refresh (${pythonLoadErrorText(Buffer.from(raw, "utf8"))})`);
          continue;
        }
        if (!isMap(doc)) {
          corruptReason.set(team.index.name, `registry.json at ${team.registry} could not be parsed during refresh (AttributeError: '${pyTypeName(doc)}' object has no attribute 'get')`);
          continue;
        }
        // seat_store twin: seats dict, else agents dict, else create agents.
        let key: string;
        let agents: JsonMap;
        const seatsRaw = doc.get("seats");
        if (isMap(seatsRaw)) { key = "seats"; agents = seatsRaw; }
        else {
          const agentsRaw = doc.get("agents");
          if (isMap(agentsRaw)) { key = "agents"; agents = agentsRaw; }
          else { key = "agents"; agents = new Map(); doc.set("agents", agents); }
        }
        // Effect-time authority: the scan's capture was only a plan. Before
        // the first mutation, re-resolve the team through a fresh marker-aware
        // snapshot and require the same live/absent marker, active team, root
        // and acting registry the scan saw — anything else joins cannot-check
        // instead of locking in a rewrite of a store that is no longer ours.
        const fresh = markerSelectedIndex();
        const freshRow = fresh.marker === selected.marker
          ? readMachineIndex(fresh.path).find(entry => entry.name === team.index.name)
          : undefined;
        if (!freshRow || !freshRow.exists || freshRow.root !== team.index.root || freshRow.registryLocation !== team.index.registryLocation) {
          corruptReason.set(team.index.name, `the machine-index authority for team '${team.index.name}' moved during refresh; nothing was trimmed`);
          continue;
        }
        // Pre-flip both indexed locations are empty, so the field compare
        // above is vacuous there; the ACTING store is derived from the root
        // through busForRoot's .tap/bus > tmp/tap chain — exactly the
        // selection scanTeam used. A root promoted (or demoted) between the
        // layouts mid-race changes that derivation, so require the fresh
        // actual path to still name the captured store before any mutation.
        const freshRegistry = fresh.marker === "live"
          ? freshRow.registryLocation
          : (() => { const bus = busForRoot(freshRow.root); return bus ? join(bus, "registry.json") : ""; })();
        if (freshRegistry !== team.registry) {
          corruptReason.set(team.index.name, `the acting registry for team '${team.index.name}' moved during refresh; nothing was trimmed`);
          continue;
        }
        for (const seat of candidates) {
          const current = agents.get(seat.handle);
          // CAS on the COMPLETE captured row: any concurrent writer that
          // changed anything — an unknown field, a value between adjacent
          // wide ints — produces a different fingerprint and defeats the trim.
          const currentFingerprint = isMap(current) ? fingerprintOf(current) : "";
          if (currentFingerprint === seat.fingerprint) {
            agents.delete(seat.handle);
            trimmedHandles.push(seat.handle);
          }
        }
        if (trimmedHandles.length) publishRegistryDocument(doc, team.registry);
      } finally {
        lock.release();
      }
    } else {
      trimmedHandles = candidates.map(seat => seat.handle);
    }
    for (const seat of candidates) {
      if (!trimmedHandles.includes(seat.handle)) continue;
      trimmed.push({ team: team.index.name, handle: seat.handle, pane: seat.pane, reason: seat.paneReason || "pane_gone" });
    }
  }
  const cannotCheck = [...corruptReason.keys()].sort(codePointOrder);

  // Render first: the incumbent's python stage prints before its bash stage
  // appends events and de-enrolls.
  if (json) {
    process.stdout.write(`${ensureAscii(JSON.stringify({ ok: true, dry_run: dryRun, trimmed, purged, retire_candidates: retireCandidates, cannot_check: cannotCheck }))}\n`);
  } else {
    for (const item of trimmed) process.stdout.write(`tap admin refresh: trimmed '${item.team}/${item.handle}' (${item.reason})\n`);
    for (const item of purged) process.stdout.write(`tap admin refresh: PURGED '${item.team}' from index (${PURGE_REASON_TEXT[item.reason] ?? item.reason})\n`);
    for (const item of retireCandidates) {
      if (item.recommended) process.stdout.write(`tap admin refresh: retire candidate '${item.team}' (${item.classification})\n`);
      else process.stdout.write(`tap admin refresh: retire blocked '${item.team}' (${item.classification}: ${item.blocked_by.join("; ")})\n`);
    }
    for (const name of cannotCheck) process.stdout.write(`tap admin refresh: warning: could not read team '${name}' (${corruptReason.get(name)}) - skipped, no mutation attempted\n`);
    if (!trimmed.length && !purged.length && !retireCandidates.length && !cannotCheck.length) {
      process.stdout.write("tap admin refresh: nothing to do\n");
    }
  }
  if (!dryRun) {
    // One registry event per successful trim, on a real bus only.
    for (const item of trimmed) {
      const team = teams.find(entry => entry.index.name === item.team);
      if (!team?.bus || !team.registry) continue;
      appendRegistryEventOrWarn("tap admin refresh", {
        log: registryEventsPath(team.bus),
        actor: "admin-refresh",
        action: "trimmed",
        handle: item.handle,
        pane: item.pane,
        team: spoolTeamName(team.bus, team.registry),
        detail: "",
      });
    }
    // De-enroll through retire's index writer; a failure warns (the incumbent
    // call passes the verb as two words, so the rendered line really is
    // `tap admin: warning: refresh; next: …`) and never changes the exit code.
    // Guarded capture is a LIVE-marker contract: the helper re-checks the exact
    // observed root/location and the positive absence of the acting registry
    // under the index lock, writing a rollback witness first. The pre-flip
    // compatibility branch can report registry_missing with an empty indexed
    // location — there is nothing for the helper to fence, so that shape (and
    // root-gone, whose absence is itself the observable fact) keeps the
    // ordinary call until C5 retires the compatibility branch.
    for (const item of purged) {
      const team = teams.find(entry => entry.index.name === item.team);
      if (item.reason === "registry_missing" && selected.marker === "live" && team?.index.root && team.index.registryLocation) {
        const recovery = join(dirname(selected.path), "recovery");
        let artifact = "";
        try {
          mkdirSync(recovery, { recursive: true });
          artifact = join(recovery, `team-admin-refresh.${randomBytes(6).toString("hex")}`);
          closeSync(openSync(artifact, "wx", 0o600));
        } catch {
          process.stderr.write(`tap admin: warning: refresh; next: could not allocate a purge capture artifact; team '${item.team}' was left enrolled — retry 'tap admin refresh'\n`);
          continue;
        }
        const result = libCall(scriptsDir, "tap_index_deenroll_team", [item.team, "--capture", artifact, "--expect-root", team.index.root, "--expect-registry", team.index.registryLocation]);
        if (result.status === 0) {
          try { unlinkSync(artifact); } catch {
            process.stderr.write(`tap admin: warning: refresh; next: could not remove the consumed purge artifact '${artifact}'\n`);
          }
        } else {
          process.stderr.write(`tap admin: warning: refresh; next: purge of team '${item.team}' was refused (rc=${result.status}) and the index was left intact; the capture artifact is retained at '${artifact}' for inspection\n`);
        }
        continue;
      }
      const result = libCall(scriptsDir, "tap_index_deenroll_team", [item.team]);
      if (result.status !== 0) {
        process.stderr.write(`tap admin: warning: refresh; next: could not purge team '${item.team}' from index\n`);
      }
    }
  }
  // Exit 1 only on a genuine cannot-check; purging data-gone teams is normal,
  // successful work.
  return cannotCheck.length ? 1 : 0;
}

function cmdAdminRetire(args: string[], scriptsDir: string): number {
  process.env.TAP_JSON = "0";
  const label = "tap admin retire";
  let force = false;
  let team = "";
  for (let i = 0; i < args.length; i++) {
    const arg = args[i]!;
    if (arg === "--json") process.env.TAP_JSON = "1";
    else if (arg === "--force") force = true;
    else if (arg.startsWith("--")) throw new TapError(1, "unknown_option", "tap help admin retire", `unknown option '${arg}'`, label);
    else if (!team) team = arg;
    else throw new TapError(1, "usage_error", "tap help admin retire", `unexpected arg '${arg}'`, label);
  }
  if (!team) throw new TapError(1, "usage_error", "tap help admin retire", "usage: tap admin retire <team> [--force]", label);

  const selected = markerSelectedIndex();
  if (selected.marker === "invalid") {
    throw new TapError(1, "invalid_flip", "tap doctor",
      "global-registry.json is present but unreadable or wrong schema — refusing admin index ops", label);
  }
  const notEnrolled = (): TapError =>
    new TapError(1, "unknown_team", "tap admin dashboard", `team '${team}' is not enrolled in machine index '${selected.path}'`, label);
  const row = readMachineIndex(selected.path).find(entry => entry.name === team);
  if (!row) throw notEnrolled();

  // Poll-mode seats survive a retire: they are the blockers that force --force.
  // The resolution is H1-corrected like the dashboard's: the indexed acting
  // location is the authority, so a decoy under the bus can never manufacture
  // a blocker (or hide one). Retire extracts poll members ONLY — it does not
  // run the dashboard's string-join validation.
  if (row.exists) {
    const bus = busForRoot(row.root);
    let registry: string;
    if (selected.marker === "live") {
      const verdict = classifyLocation(row.registryLocation);
      if (verdict === "present") registry = row.registryLocation;
      else if (verdict === "enoent") registry = "";
      else {
        // An unprobeable authority means the poll roster cannot be proven
        // either way — retiring would bypass the blocker check on a guess.
        throw new TapError(1, "registry_invalid", "repair_registry",
          `the acting registry for team '${team}' at '${row.registryLocation}' could not be read`, label);
      }
    } else {
      registry = join(bus, "registry.json");
    }
    if (registry && isFile(registry)) {
      const pollMembers = pollHandlesOrRefuse(registry, label);
      if (pollMembers.length > 0 && !force) {
        throw new TapError(1, "retire_refused", `tap admin retire ${team} --force`,
          `refusing to retire team '${team}': poll-mode members: ${pollMembers.join(",")}`, label);
      }
    }
  }

  const result = libCall(scriptsDir, "tap_index_deenroll_team", [team]);
  const errText = cmdSubst(result.stderr);
  switch (result.status) {
    case 0: break;
    case 2: throw notEnrolled();
    case 3: throw new TapError(1, "registry_invalid", "tap admin dashboard", errText || `machine index '${selected.path}' could not be read`, label);
    case 4: throw new TapError(1, "invalid_flip", "tap doctor", errText || "global-registry.json is present but unreadable or wrong schema", label);
    default: throw new TapError(1, "error", "tap admin dashboard", `could not retire team '${team}'`, label);
  }
  const removedRoot = cmdSubst(result.stdout);

  // The retired event is written only where a bus exists to hold it.
  if (row.root && row.exists) {
    const bus = busForRoot(row.root);
    if (bus) {
      appendRegistryEventOrWarn("tap admin retire", {
        log: registryEventsPath(bus),
        actor: "admin-retire",
        action: "retired",
        handle: team,
        pane: "",
        team: spoolTeamName(bus, join(bus, "registry.json")),
        detail: "",
      });
    }
  }

  if (process.env.TAP_JSON === "1") {
    process.stdout.write(`${ensureAscii(JSON.stringify({ ok: true, team, root: removedRoot || row.root, forced: force }))}\n`);
  } else {
    process.stdout.write(`tap admin retire: de-enrolled team '${team}'\n`);
  }
  return 0;
}

/** Retire's poll-only extraction: no join validation, corrupt is a repair refusal. */
function pollHandlesOrRefuse(registry: string, label: string): string[] {
  let raw: string;
  try { raw = pyReadUtf8(registry); } catch {
    throw new TapError(1, "registry_invalid", "repair_registry",
      `registry.json at ${registry} could not be parsed as JSON (${pythonProbeLoadError(registry)})`, label);
  }
  let doc: JsonValue;
  try { doc = loads(raw); } catch {
    throw new TapError(1, "registry_invalid", "repair_registry",
      `registry.json at ${registry} could not be parsed as JSON (${pythonLoadErrorText(Buffer.from(raw, "utf8"))})`, label);
  }
  if (!isMap(doc)) {
    throw new TapError(1, "registry_invalid", "repair_registry",
      `registry.json at ${registry} could not be parsed as JSON (AttributeError: '${pyTypeName(doc)}' object has no attribute 'get')`, label);
  }
  const seatsRaw = doc.get("seats");
  const seats = isMap(seatsRaw) ? seatsRaw : isMap(doc.get("agents")) ? doc.get("agents") as JsonMap : new Map();
  const poll: string[] = [];
  for (const handle of [...seats.keys()].sort(codePointOrder)) {
    const seat = seats.get(handle);
    if (!isMap(seat)) continue;
    const delivery = pyTruthy(seat.get("delivery")) ? seat.get("delivery")! : "pane";
    if (delivery === "poll") poll.push(handle);
  }
  return poll;
}

function cmdAdminDashboard(args: string[], scriptsDir: string, engine?: ObserveEngine): number {
  // The incumbent clobbers TAP_JSON=0 after sub dispatch and BEFORE the flag
  // table, so an ambient TAP_JSON=1 cannot turn a flag refusal into JSON; the
  // sequential parse flips it back exactly when it reaches --json.
  process.env.TAP_JSON = "0";
  const options = parseDashboardOptions(args);
  const selected = markerSelectedIndex();
  if (selected.marker === "invalid") {
    throw new TapError(1, "invalid_flip", "tap doctor",
      "global-registry.json is present but unreadable or wrong schema — refusing admin index ops", DASHBOARD_LABEL);
  }
  const rawNow = process.env.TAP_WATCH_NOW;
  const now = rawNow ? Number(rawNow) : Math.floor(Date.now() / 1000);
  const teams = readMachineIndex(selected.path).map(row => scanTeam(row, selected.marker, now, options.staleAfter, true));

  if (observeTeams(teams, scriptsDir, engine, false) !== 0) return 1;
  // Seat state is read only where it can mean something: active registry rows
  // whose pane was just observed alive. Read-only, stderr dropped, and a
  // failed read is the incumbent's "unknown".
  for (const team of teams) {
    if (!team.bus) continue;
    for (const seat of team.seats) {
      if (seat.status !== "active" || seat.delivery === "poll" || seat.paneAlive !== true) continue;
      const result = libCall(scriptsDir, "tap_seat_state", [seat.handle], {
        ...process.env,
        TAP_HOME: team.bus,
        TAP_REGISTRY: team.registry,
        TAP_PAYLOADS: join(team.bus, "payloads"),
        TAP_RECEIPTS: join(team.bus, "receipts"),
        TAP_REGISTRY_EVENTS: join(team.bus, "registry-events.log"),
        TAP_SEAT_STATE_READONLY: "1",
      });
      seat.seatState = result.status === 0 ? cmdSubst(result.stdout) : "unknown";
    }
  }

  const displayState = (seat: SeatScan): string => seat.seatState || (seat.delivery === "poll" ? "poll-mode (liveness unknown)" : "unknown");
  const classes = new Map(teams.map(team => [team.index.name, classifyTeam(team)]));
  const cannotCheck = teams.filter(team => team.unreadableKind === "registry_corrupt").map(team => team.index.name).sort();
  const missing: Array<{ team: string; reason: string }> = [];
  for (const team of teams) {
    if (!team.index.exists) missing.push({ team: team.index.name, reason: "root_gone" });
    else if (team.unreadableKind === "registry_missing") missing.push({ team: team.index.name, reason: "registry_missing" });
  }
  const attention: AttentionRow[] = [];
  for (const team of teams) {
    for (const seat of team.seats) {
      if (seat.status !== "active") continue;
      const reasons: string[] = [];
      if (seat.delivery !== "poll") {
        if (seat.paneAlive === false) {
          reasons.push(`pane dead while registry status is still active${registeredAge(seat.registeredAt, now)}`);
        } else if (seat.seatState === "wedged" || seat.seatState === "rate-limited-error") {
          reasons.push(`seat ${seat.seatState}`);
        } else if (seat.seatState === "idle-at-prompt" && seat.inbound.length > 0) {
          reasons.push(`idle-at-prompt with ${seat.inbound.length} unsettled inbound payload(s)`);
        }
      }
      if (seat.staleIds.length > 0) {
        reasons.push(`${seat.staleIds.length} stale outstanding send(s) with no .done after ${options.staleAfter}s`);
      }
      if (reasons.length === 0) continue;
      attention.push({
        team: team.index.name, handle: seat.handle, state: displayState(seat), why: reasons.join("; "),
        obligations: {
          inbound_unsettled: seat.inbound.length,
          outstanding_unsettled: seat.outstanding.length,
          sample_ids: [...seat.inbound, ...seat.outstanding].slice(0, 3).map(o => o.id),
        },
      });
    }
  }

  if (options.json) {
    const teamsJson = teams.map(team => {
      const out: Record<string, unknown> = { name: team.index.name, classification: classes.get(team.index.name)!, root: team.index.root };
      if (options.full) {
        out.seats = team.seats.map(seat => ({
          handle: seat.handle, status: seat.status, pane: seat.pane, harness: seat.harness,
          delivery: seat.delivery, state: displayState(seat),
        }));
      }
      return out;
    });
    process.stdout.write(`${ensureAscii(JSON.stringify({ teams: teamsJson, attention, cannot_check: cannotCheck, missing }))}\n`);
  } else {
    const missingNames = new Set(missing.map(entry => entry.team));
    process.stdout.write(`tap admin dashboard: ${teams.length} team(s) indexed\n`);
    for (const team of teams) {
      if (!options.verbose && missingNames.has(team.index.name)) continue;
      process.stdout.write(`  ${team.index.name}  ${classes.get(team.index.name)}  root: ${team.index.root}\n`);
      if (options.full) {
        for (const seat of team.seats) {
          process.stdout.write(`    ${seat.handle}  status: ${seat.status}  delivery: ${seat.delivery}  pane: ${seat.pane || "-"}  harness: ${seat.harness || "-"}  state: ${displayState(seat)}\n`);
        }
      }
    }
    process.stdout.write(`${secondary("attention")}\n`);
    if (attention.length === 0) {
      process.stdout.write("  none\n");
    } else {
      for (const row of attention) {
        process.stdout.write(`  ${row.team}/${row.handle}  state: ${row.state}  inbound: ${row.obligations.inbound_unsettled}  outstanding: ${row.obligations.outstanding_unsettled}  sample: ${row.obligations.sample_ids.join(",") || "-"}  why: ${row.why}\n`);
      }
    }
    const reasonOf = new Map(teams.map(team => [team.index.name, team.unreadableReason]));
    const details = options.verbose
      ? teams.filter(team => team.unreadableKind).map(team => ({ name: team.index.name, reason: team.unreadableReason })).sort((a, b) => codePointOrder(a.name, b.name))
      : cannotCheck.map(name => ({ name, reason: reasonOf.get(name) ?? "" }));
    if (details.length) {
      process.stdout.write(`${secondary("cannot-check")}\n`);
      for (const detail of details) process.stdout.write(`  ${detail.name}: ${detail.reason}\n`);
    }
    if (missing.length) {
      process.stdout.write(`tap admin dashboard: ${missing.length} missing team(s) detected - run tap admin refresh to purge them\n`);
    }
  }
  return cannotCheck.length ? 1 : attention.length ? 2 : 0;
}

function registeredAge(registeredAt: string, now: number): string {
  // python strptime("%Y-%m-%dT%H:%M:%SZ") parity: the exact shape, a real
  // calendar date, and no sub-second remainder.
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/.test(registeredAt)) return "";
  const stamp = Date.parse(registeredAt);
  if (!Number.isFinite(stamp) || new Date(stamp).toISOString() !== `${registeredAt.slice(0, -1)}.000Z`) return "";
  const delta = Math.max(0, now - Math.floor(stamp / 1000));
  const age = delta < 60 ? `${delta}s`
    : delta < 3600 ? `${Math.floor(delta / 60)}m`
    : delta < 86400 ? `${Math.floor(delta / 3600)}h`
    : `${Math.floor(delta / 86400)}d`;
  return `; registered ${age} ago`;
}

function secondary(text: string): string {
  if (process.env.NO_COLOR !== undefined || !process.env.TERM || process.env.TERM === "dumb") return text;
  // style.sh polarity: CLICOLOR_FORCE forces unless it is "0"; an EMPTY value
  // is not a force. Without a force, a non-tty stdout stays plain.
  const forced = Boolean(process.env.CLICOLOR_FORCE && process.env.CLICOLOR_FORCE !== "0");
  if (!forced && !process.stdout.isTTY) return text;
  const tokens = [["setaf", "1"], ["setaf", "3"], ["bold"], ["dim"], ["sgr0"]].map(probe =>
    spawnSync("tput", probe as string[], { env: process.env, encoding: "utf8" }));
  if (tokens.some(result => result.status !== 0 || !result.stdout)) return text;
  return `${tokens[3]!.stdout}${text}${tokens[4]!.stdout}`;
}

if (import.meta.main) process.exitCode = cmdAdmin(process.argv.slice(2), join(import.meta.dir, "../../../../skills/tap/scripts"));
