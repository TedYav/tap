import { spawnSync } from "node:child_process";
import { writeSync } from "node:fs";
import { join } from "node:path";
import { TapError } from "./context";
import { lockRoot, acquireRegistryLock } from "./panelock";
import { acquireResetMutationLock, markResetGenerationReused } from "./reset";
import { loadRegistry, saveRegistry, seatMap, type Seat } from "./registry";
import { assertSelectionCurrent, parseTarget, selectCaller, SelectorError, type Selection } from "./selector";
import { canonicalSessionName, destructiveSessionTarget, isPaneId, lifecycleDisposition } from "./lifecycle-target";
import { bootId, bootIdsMatch, serverEpochFromRaw, tmuxReadOnly, physicalSocketPath, type Run } from "./tmux";

export interface SeatOptions { target: string; team?: string; json: boolean; dryRun: boolean; selfReported?: boolean }
export function parseSeatOptions(argv: string[]): SeatOptions {
  const options: SeatOptions = { target: "", json: false, dryRun: false };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!;
    if (arg === "--json") options.json = true;
    else if (arg === "--dry-run") options.dryRun = true;
    else if (arg === "--team") {
      if (options.team !== undefined || !argv[i + 1] || argv[i + 1]!.startsWith("-")) fail("usage_error", "--team needs one team name");
      options.team = argv[++i];
    } else if (arg.startsWith("-") || options.target) fail("usage_error", `unexpected argument '${arg}'`);
    else options.target = arg;
  }
  if (!options.target) fail("usage_error", "name one durable seat");
  return options;
}
function fail(errorClass: string, detail: string): never {
  throw new TapError(1, errorClass, "tap help up / tap help down", detail);
}

interface Pane { id: string; session: string; sessionId: string; window: string; rawEpoch: string }
export interface SeatSnapshot { panes: Pane[]; epoch: string }
export type TmuxCall = (args: string[]) => Run;
const paneFormat = "#{pane_id}\t#{session_name}\t#{session_id}\t#{window_id}\t#{pid}:#{start_time}";
/** One complete namespace observation. An unreadable server never means stopped. */
export function seatSnapshot(call: TmuxCall = tmuxReadOnly): SeatSnapshot {
  const result = call(["list-panes", "-a", "-F", paneFormat]);
  if (result.code !== 0) {
    if (/^(no server running on|error connecting to .*No such file or directory|failed to connect to server: No such file or directory)/.test(result.stderr.trim())) return { panes: [], epoch: "" };
    fail("tmux_unobservable", `cannot observe sessions: ${result.stderr.trim()}`);
  }
  const panes: Pane[] = [];
  for (const line of result.stdout.trimEnd().split("\n")) {
    const parts = line.split("\t");
    const [id, session, sessionId, window, rawEpoch] = parts;
    if (parts.length !== 5 || !isPaneId(id) || !session || !/^\$\d+$/.test(sessionId!) || !/^@\d+$/.test(window!) || !/^\d+:\d+$/.test(rawEpoch!)) fail("tmux_unobservable", "malformed session snapshot");
    panes.push({ id, session, sessionId: sessionId!, window: window!, rawEpoch: rawEpoch! });
  }
  if (!panes.length || panes.some(p => p.rawEpoch !== panes[0]!.rawEpoch)) fail("tmux_unobservable", "inconsistent server generation");
  return { panes, epoch: serverEpochFromRaw(panes[0]!.rawEpoch) };
}

export function validateDurable(row: Seat | undefined, handle: string, team: string, verb: "up" | "down"): Seat {
  if (!row || typeof row !== "object" || Array.isArray(row)) fail("not_found", `unknown seat '${team}/${handle}'; create it with tap session launch`);
  const disposition = lifecycleDisposition(row.crew === true ? "crew" : "seat", verb);
  if (!disposition.ok) fail("ephemeral_crew", disposition.detail);
  if (row.delivery === "poll") fail("poll_seat", "poll seats have no durable tmux session");
  if (row.session !== canonicalSessionName(team, handle)) fail("session_identity_mismatch", "stored session is not this durable seat's exact session");
  if (row.status === "pending" || row.launch_token) fail("launch_in_progress", "seat launch is in progress");
  return row;
}

/** Strict pane membership additionally rules out a name reused after its stored pane died. */
export function liveSeat(row: Seat, expected: string, snapshot: SeatSnapshot): Pane | undefined {
  const members = snapshot.panes.filter(p => p.session === expected);
  if (!members.length) return undefined;
  const decision = destructiveSessionTarget(row, expected, {
    hasSession: name => snapshot.panes.some(p => p.session === name),
    paneSession: id => snapshot.panes.find(p => p.id === id)?.session ?? null,
    sessionPaneIds: name => snapshot.panes.filter(p => p.session === name).map(p => p.id),
  });
  if (!decision.ok) fail("session_identity_mismatch", decision.reason);
  const pane = members.find(p => p.id === row.pane_id);
  if (!pane) fail("session_identity_mismatch", "live session does not contain the stored pane; refusing a reused name");
  if (row.server_epoch && row.server_epoch !== snapshot.epoch) fail("session_identity_mismatch", "stored server generation differs");
  if (row.boot_id && bootIdsMatch(String(row.boot_id), bootId()) !== "match") fail("session_identity_mismatch", "stored boot identity is not current");
  return pane;
}

/** Shared-session ownership is the installed crew contract. No foreign pane is followed. */
export function ownedCrewRows(seats: Record<string, Seat>, session: string, snapshot: SeatSnapshot): string[] {
  const handles: string[] = [];
  for (const [handle, row] of Object.entries(seats)) {
    if (row.crew !== true || row.session !== session) continue;
    const live = snapshot.panes.find(p => p.id === row.pane_id);
    if (live && live.session !== session) fail("crew_identity_mismatch", `crew '${handle}' is live in another session`);
    handles.push(handle);
  }
  return handles;
}

/** The final predicate and kill run on the same tmux server, using immutable ids. */
export function stopExactPane(pane: Pane, call: TmuxCall = tmuxReadOnly): Run {
  const condition = `#{&&:#{==:#{session_name},${pane.session}},#{&&:#{==:#{session_id},${pane.sessionId}},#{&&:#{==:#{pane_id},${pane.id}},#{==:#{pid}:#{start_time},${pane.rawEpoch}}}}}`;
  return call(["if-shell", "-F", "-t", pane.id, condition,
    `kill-session -t '${pane.sessionId}'`, "display-message -p 'tap down: stop identity changed'"]);
}

function render(verb: "up" | "down", options: SeatOptions, fields: Record<string, unknown>): void {
  const receipt = { ok: true, verb, ...fields };
  // Synchronous fd write matters when this command is stopping its own session.
  const crews = Array.isArray(fields.crews) && fields.crews.length ? ` (owned crew: ${fields.crews.join(", ")})` : "";
  writeSync(1, options.json ? `${JSON.stringify(receipt)}\n` : `tap ${verb}: ${fields.team}/${fields.handle} ${fields.outcome}${crews}\n`);
}

function selectionFor(options: SeatOptions): { selection: Selection; handle: string } {
  const parsed = parseTarget(options.target);
  if (parsed.qualified && options.team) fail("selector_conflict", "pass --team OR a qualified seat, not both");
  const selection = selectCaller({ cwd: process.cwd(), explicitTeam: parsed.qualified ? parsed.team : options.team, verbClass: "lifecycle" });
  return { selection, handle: parsed.handle };
}

export function cmdSeatUpDown(verb: "up" | "down", argv: string[], scriptDir: string): number {
  let options: SeatOptions | undefined;
  try {
    options = parseSeatOptions(argv);
    return executeSeatUpDown(verb, options, scriptDir);
  } catch (error) {
    const known = error instanceof TapError || error instanceof SelectorError;
    const detail = error instanceof Error ? error.message : String(error);
    if (argv.includes("--json")) {
      writeSync(options?.selfReported ? 2 : 1, JSON.stringify({ ok: false, verb, error_class: known ? error.errorClass : "operation_failed", detail }) + "\n");
      return 1;
    }
    if (error instanceof SelectorError) throw new TapError(error.code, error.errorClass, error.action, error.detail);
    throw error;
  }
}

function executeSeatUpDown(verb: "up" | "down", options: SeatOptions, scriptDir: string): number {
  const { selection, handle } = selectionFor(options);
  const resetLock = acquireResetMutationLock(selection.busHome, `tap ${verb}`);
  let row: Seat;
  try {
    const lock = acquireRegistryLock(selection.registryLocation);
    if (!lock) fail("registry_busy", "could not obtain the selected registry lock");
    try {
      assertSelectionCurrent(selection, lock);
      const doc = loadRegistry(selection.registryLocation);
      const seats = seatMap(doc);
      row = validateDurable(seats[handle], handle, selection.team, verb);
      const snapshot = seatSnapshot();
      const pane = liveSeat(row, String(row.session), snapshot);
      const fields = { team: selection.team, handle, session: row.session, instance: row.instance };
      if (verb === "up") {
        if (pane) {
          if (row.status !== "active" || row.status_reason) fail("seat_not_ready", "session exists but its row is not ready; inspect it before resuming");
          render(verb, options, { ...fields, outcome: "already_live" });
          return 0;
        }
        if (options.dryRun) {
          if (!row.harness_session_id) fail("resume_identity_missing", "seat has no stored native conversation identity");
          render(verb, options, { ...fields, outcome: "would_resume" });
          return 0;
        }
        // The adapter reacquires the reset/registry transaction and compares this
        // complete row before claiming. Never hold the registry lock over launch.
      } else {
        if (!pane) {
          render(verb, options, { ...fields, outcome: "already_stopped", crews: [] });
          return 0;
        }
        for (const [name, other] of Object.entries(seats)) {
          if (name === handle || other.delivery === "poll") continue;
          const sharesSession = other.session === row.session || snapshot.panes.some(p => p.id === other.pane_id && p.session === row.session);
          if (sharesSession && !(other.crew === true && other.session === row.session)) {
            fail("shared_durable_session", `seat '${name}' shares this session; use the team lifecycle command`);
          }
        }
        const crews = ownedCrewRows(seats, String(row.session), snapshot);
        if (options.dryRun) {
          render(verb, options, { ...fields, outcome: "would_stop", crews });
          return 0;
        }
        if (crews.length) {
          writeSync(2, `tap down: removing owned crew ${crews.join(", ")}; any unsettled crew mail remains on the bus without a recipient. Hand off work before down; this command does not transfer or settle it.\n`);
        }
        const original = structuredClone(row);
        const originals = new Map(crews.map(h => [h, seats[h]!]));
        const callerSocket = process.env.TMUX ? physicalSocketPath({ ...process.env, TAP_TMUX_SOCKET: undefined, TAP_TMUX_SOCKET_PATH: undefined }) : "";
        const self = !!pane && callerSocket === physicalSocketPath() && snapshot.panes.some(p => p.id === process.env.TMUX_PANE && p.sessionId === pane.sessionId);
        row.status = "suspended";
        row.status_reason = "session_stopped";
        for (const crew of crews) delete seats[crew];
        markResetGenerationReused(selection.busHome, "tap down");
        saveRegistry(selection.registryLocation, doc);
        if (self) {
          render(verb, options, { ...fields, outcome: "stop_requested", crews });
          options.selfReported = true;
        }
        // A timeout can have acted: leave the row suspended and never retry.
        const result = stopExactPane(pane);
        const after = seatSnapshot();
        if (after.panes.some(p => p.sessionId === pane.sessionId && p.rawEpoch === pane.rawEpoch)) {
          seats[handle] = original;
          for (const [crew, old] of originals) seats[crew] = old;
          saveRegistry(selection.registryLocation, doc);
          fail("stop_failed", result.stderr.trim() || result.stdout.trim() || "session survived; registry restored");
        }
        if (!self) render(verb, options, { ...fields, outcome: "stopped", crews });
        return 0;
      }
    } finally { lock.release(); }
  } finally { resetLock.release(); }
  const result = spawnSync("python3", ["-B", join(scriptDir, "session", "launcher.py"), "_seat-up",
    selection.rootReal, selection.team, handle, JSON.stringify(row!), selection.registryLocationReal], {
    // Python's tmux subprocesses use TMUX, not TAP_TMUX_SOCKET. Pin the same
    // physical socket Bun selected, including when no server exists yet.
    cwd: selection.rootReal, env: { ...process.env, TAP_LOCK_DIR: lockRoot(), TAP_HOME: selection.busHome,
      TMUX: `${physicalSocketPath()},0,0`, TMUX_PANE: undefined }, encoding: "utf8", timeout: 120_000,
  });
  if (result.stderr) writeSync(2, result.stderr);
  if (result.error || result.status !== 0) {
    if (result.stdout) writeSync(2, result.stdout);
    fail("resume_failed", result.error?.message || "detached resume failed; inspect the seat before retrying");
  }
  render(verb, options, { team: selection.team, handle, session: row!.session, outcome: "resumed" });
  return 0;
}

if (import.meta.main) {
  const [verb, ...args] = process.argv.slice(2);
  if (verb !== "up" && verb !== "down") throw new Error("expected up or down");
  try { process.exitCode = cmdSeatUpDown(verb, args, join(import.meta.dir, "../../../skills/tap/scripts")); }
  catch (error) {
    process.stderr.write(`tap ${verb}: ${(error as Error).message}\n`);
    process.exitCode = 1;
  }
}
