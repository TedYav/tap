// Thin G1 slice: model flag tokens from presets.TUNING_CAPABILITIES.
// Secure-read, 95-case dispositions, and two-snapshot digest live in later units.

type TuningAxis = {
  argv: readonly string[];
  valueTemplate?: string;
};

type HarnessTuning = {
  model?: TuningAxis;
};

const TUNING_CAPABILITIES: Record<string, HarnessTuning> = {
  claude: { model: { argv: ["--model"] } },
  codex: { model: { argv: ["--model"] } },
  opencode: { model: { argv: ["--model"] } },
  cursor: { model: { argv: ["--model"] } },
  agy: { model: { argv: ["--model"] } },
  hermes: { model: { argv: ["--model"] } },
};

function tokens(axis: TuningAxis, value: string): string[] {
  const rendered = axis.valueTemplate
    ? axis.valueTemplate.replace("{value}", value)
    : value;
  return [...axis.argv, rendered];
}

/** Flag tokens for a resolved model, or empty when none was supplied. */
export function modelArgv(harness: string, model: string | null | undefined): string[] {
  if (!model) return [];
  const axis = TUNING_CAPABILITIES[harness]?.model;
  if (!axis) return [];
  return tokens(axis, model);
}
