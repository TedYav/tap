import { closeSync, fsyncSync, linkSync, mkdirSync, openSync, unlinkSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { receiptBytes } from "./fsatomic";
import { validId } from "./ids";

/** Create the conservative possible-effect marker without exposing partial bytes. */
export function beginDeliveryAttempt(home: string, id: string): "created" | "existing" {
  if (!home || !validId(id)) throw new Error("delivery attempt needs a bus home and valid id");
  const receipts = join(home, "receipts");
  mkdirSync(receipts, { recursive: true });
  const destination = join(receipts, `${id}.attempted`);
  const temporary = join(receipts, `.attempted.${process.pid.toString(36)}.${Math.random().toString(36).slice(2, 10)}`);
  const fd = openSync(temporary, "wx", 0o600);
  try {
    try {
      writeFileSync(fd, receiptBytes({ id, effect: "possible" }));
      fsyncSync(fd);
    } finally {
      closeSync(fd);
    }
    try {
      linkSync(temporary, destination);
      return "created";
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "EEXIST") return "existing";
      throw error;
    }
  } finally {
    try { unlinkSync(temporary); } catch { /* already absent */ }
  }
}

if (import.meta.main) {
  const [operation, home, id] = process.argv.slice(2);
  if (operation !== "begin" || !home || !id) {
    console.error("usage: delivery-attempt.ts begin <tap-home> <id>");
    process.exit(2);
  }
  try {
    console.log(beginDeliveryAttempt(home, id));
  } catch (error) {
    console.error(`tap: cannot record delivery attempt: ${error}`);
    process.exit(1);
  }
}
