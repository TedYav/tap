// Pure resume-identity resolution over a filesystem snapshot.
// Claude chain: acting hsid → transcript_path id → quarantined → picker.
// Each exact step requires an on-disk transcript (tap-gc1n).
//
// revive_tier reads the RAW stored id, not the resolved target — that is
// why a ghost (stored id, absent transcript) prints revive_tier "exact"
// while resolving to picker / target null.

import { readdirSync, statSync } from "node:fs";
import { homedir } from "node:os";
import { basename, join } from "node:path";

import { AGENT_FAMILIES } from "../verbs/team";
import type { SessionRecord } from "./types";

export type ResumeSource =
  | "acting_hsid"
  | "transcript_path"
  | "quarantined"
  | "picker";

export type ResumeTarget = {
  session_id: string | null;
  source: ResumeSource;
  split_brain: boolean;
  disclosure: string | null;
};

export function claudeHome(env: NodeJS.ProcessEnv = process.env): string {
  // Python: os.environ.get("TAP_CLAUDE_HOME") or os.environ.get("CLAUDE_HOME", "~/.claude")
  // TAP uses truthiness (empty falls through); CLAUDE_HOME keeps a supplied empty
  // string. Path("").expanduser() is "." — not "~/.claude" via HOME.
  const raw =
    env.TAP_CLAUDE_HOME ||
    (env.CLAUDE_HOME !== undefined ? env.CLAUDE_HOME : "~/.claude");
  // tap-jevu6.1: under Bun, homedir() (like userInfo().homedir) reads the launcher's
  // startup $HOME else passwd, so this fallback consults ambient state and can diverge
  // from Python's passwd expansion when the frozen env omits HOME — dark today (no
  // production caller of planResume/planJson); the real fix is beaded.
  const home = env.HOME !== undefined ? env.HOME : homedir();
  if (raw === "~" || raw.startsWith("~/")) {
    return (home.replace(/\/+$/, "") + raw.slice(1)) || "/";
  }
  return raw === "" ? "." : raw;
}

export function claudeSessionTranscriptExists(
  sessionId: string | null | undefined,
  env: NodeJS.ProcessEnv = process.env,
): boolean {
  if (!sessionId) return false;
  const projects = join(claudeHome(env), "projects");
  try {
    for (const name of readdirSync(projects)) {
      try {
        if (statSync(join(projects, name, `${sessionId}.jsonl`)).isFile()) {
          return true;
        }
      } catch {
        // missing path under this project
      }
    }
    return false;
  } catch {
    return false;
  }
}

export function transcriptPathSessionId(
  transcriptPath: string | null | undefined,
): string | null {
  if (!transcriptPath) return null;
  const name = basename(transcriptPath);
  if (name.endsWith(".jsonl") && name.length > 6) {
    return name.slice(0, -".jsonl".length);
  }
  return null;
}

export function resolveResumeTarget(
  record: SessionRecord,
  env: NodeJS.ProcessEnv = process.env,
): ResumeTarget {
  if (record.harness !== "claude") {
    return {
      session_id: record.harness_session_id ?? null,
      source: "acting_hsid",
      split_brain: false,
      disclosure: null,
    };
  }

  const hsid =
    typeof record.harness_session_id === "string"
      ? record.harness_session_id
      : null;
  const tpathId = transcriptPathSessionId(record.transcript_path ?? null);
  const split = Boolean(hsid && tpathId && hsid !== tpathId);

  if (hsid && claudeSessionTranscriptExists(hsid, env)) {
    return {
      session_id: hsid,
      source: "acting_hsid",
      split_brain: split,
      disclosure: null,
    };
  }
  if (tpathId && claudeSessionTranscriptExists(tpathId, env)) {
    return {
      session_id: tpathId,
      source: "transcript_path",
      split_brain: hsid ? true : split,
      disclosure: null,
    };
  }
  const qid =
    typeof record.quarantined_harness_session_id === "string"
      ? record.quarantined_harness_session_id
      : null;
  if (qid && claudeSessionTranscriptExists(qid, env)) {
    return {
      session_id: qid,
      source: "quarantined",
      split_brain: split || Boolean(hsid || tpathId),
      disclosure: "resuming quarantined session; attestation previously failed",
    };
  }
  return {
    session_id: null,
    source: "picker",
    split_brain: split,
    disclosure: null,
  };
}

/** Short tier word. Reads the RAW stored id, not the resolved target. */
export function reviveTier(
  harness: string | null | undefined,
  nativeId: string | null | undefined,
): string {
  if (!harness || !AGENT_FAMILIES.has(harness)) return "-";
  if (nativeId) return "exact";
  if (harness === "claude" || harness === "codex") return "picker";
  if (harness === "agy") return "latest";
  return "fresh";
}

/**
 * Python's `!r` for the two values the split-brain receipt interpolates.
 *
 * The first version was `` `'${value}'` `` -- quotes around the raw string, no
 * escaping -- which is right for the paths anyone pictures and wrong for three
 * shapes a real `transcript_path` can carry. Found by astra-pinnacle-reviewer-2
 * as an unverified lead on #xxxx and measured against CPython before fixing:
 *
 *     value                     CPython repr              the old version
 *     /t/o'brien.jsonl          "/t/o'brien.jsonl"        '/t/o'brien.jsonl'
 *     /t/back\slash.jsonl       '/t/back\\slash.jsonl'    '/t/back\slash.jsonl'
 *     /t/new\nline.jsonl        '/t/new\\nline.jsonl'     '/t/new<LF>line.jsonl'
 *
 * The third is the one that matters beyond cosmetics: an unescaped newline puts
 * a LITERAL line break inside a one-line receipt, so a reader splitting stderr
 * on newlines sees a truncated record followed by a fragment. A path can contain
 * a newline on every filesystem TAP runs on.
 *
 * Python's rule, which this reproduces: prefer single quotes; switch to double
 * quotes only when the string contains a `'` and no `"`; escape the backslash,
 * the quote actually used, and the C0 controls; leave printable non-ASCII alone,
 * because Python 3 `repr` does not escape it.
 */
export function pyRepr(value: string | null | undefined): string {
  if (value === null || value === undefined) return "None";
  const quote = value.includes("'") && !value.includes('"') ? '"' : "'";
  let out = "";
  for (const ch of value) {
    if (ch === "\\") out += "\\\\";
    else if (ch === quote) out += `\\${ch}`;
    else if (ch === "\n") out += "\\n";
    else if (ch === "\r") out += "\\r";
    else if (ch === "\t") out += "\\t";
    else {
      const code = ch.codePointAt(0)!;
      // C0 and DEL plus the C1 block, which CPython also escapes as \xNN.
      if (code < 0x20 || code === 0x7f || (code >= 0x80 && code <= 0x9f)) {
        out += `\\x${code.toString(16).padStart(2, "0")}`;
      } else out += ch;
    }
  }
  return `${quote}${out}${quote}`;
}

/**
 * The resume-target receipts, byte-for-byte with `_emit_resume_target_receipts`
 * (launcher.py:1996).
 *
 * THIS IS NOT A NOTICE CHANNEL, and the distinction is load-bearing. The
 * incumbent writes these with four bare `print(..., file=sys.stderr)` calls: no
 * suppression, no dedup. Routing them through the catalog's `Notices` sink would
 * give them command-scoped de-duplication and thereby close **tap-2qrt** — the
 * open bug where a discarded pre-flight build prints the receipts twice — as an
 * undeclared side effect of a parity port. `notify_env_policy=False` suppresses
 * exactly the config/env notices and NOT these; `launch_invocation`'s docstring
 * (launcher.py:2723) says so and names the duplication.
 *
 * So: a plain writer, deliberately. Changing receipt suppression or dedup is a
 * separate measured deviation, not this port's business.
 */
export function emitResumeTargetReceipts(
  record: SessionRecord,
  target: ResumeTarget,
  write: (line: string) => void,
): void {
  if (target.split_brain) {
    write("tap session: resume_identity_split — " +
      `harness_session_id=${pyRepr(record.harness_session_id)} ` +
      `transcript_path=${pyRepr(record.transcript_path)}; ` +
      `using ${target.source}` +
      (target.session_id ? ` id=${target.session_id}` : "") +
      "; next: realign harness_session_id to the durable transcript");
  }
  if (target.disclosure) write(`tap session: ${target.disclosure}`);
  if (target.source === "picker") {
    write("tap session: no verified resume transcript; " +
      "falling through to id-less harness picker");
  } else if (target.source === "transcript_path" && !target.split_brain) {
    write(`tap session: resume target from transcript_path id=${target.session_id}`);
  }
}

export function resolvedResumeIdentity(
  record: SessionRecord,
  env: NodeJS.ProcessEnv = process.env,
  // Silent by default: a caller that only wants the id (the dark planner, a
  // pre-flight) passes nothing. The receipts ride the SAME resolution that
  // produced the id — resolving twice to explain a fallback is how the argv and
  // the explanation come to disagree about which transcript was found.
  receipts?: (line: string) => void,
): string | null {
  if (record.harness === "claude") {
    const target = resolveResumeTarget(record, env);
    if (receipts) emitResumeTargetReceipts(record, target, receipts);
    return target.session_id;
  }
  return record.harness_session_id ?? null;
}

/** Dark plan fields for one resume row. revive_tier uses the stored id. */
export function planResume(
  record: SessionRecord,
  env: NodeJS.ProcessEnv = process.env,
): {
  target: string | null;
  source: ResumeSource;
  split_brain: boolean;
  revive_tier: string;
  disclosure: string | null;
} {
  const target = resolveResumeTarget(record, env);
  return {
    target: target.session_id,
    source: target.source,
    split_brain: target.split_brain,
    revive_tier: reviveTier(record.harness, record.harness_session_id ?? null),
    disclosure: target.disclosure,
  };
}
