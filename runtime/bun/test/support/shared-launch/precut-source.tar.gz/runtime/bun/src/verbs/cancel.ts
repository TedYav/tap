// Sender-side cancellation of dead obligations (tap-pe56).
//
// `tap cancel <id> [--by <me>] [--team <name>] [--spooled] [--json]`
//
// When the target seat cannot settle the mail — the seat is GONE from its
// registry, suspended, or the send is still parked in the spool and the sender
// withdraws it with --spooled — the sender archives the payload and writes a
// `.cancelled` receipt DISTINCT from `.done` (provenance never claims the
// recipient settled: via is always "cancelled"). Refuses while the addressee
// is active/launching with the delivered payload in hand.
//
// Custody order is load-bearing: obligation lock, then the no-steal spool
// claim, both held across the residency observation, the archive rename, the
// spool-entry removal, and the receipt. The archive rename happens BEFORE
// `removeEntry` — for a spooled entry the payload IS the spool body, so the
// order is what keeps the only copy alive (tap-92v3r U2d).
import { existsSync, mkdirSync, readFileSync, renameSync, statSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { callingPane, repoRoot, resolveSelf, TapError } from "../context";
import { applyTeamOverride } from "../team-override";
import { resolveSelection, worktreeTeamRoot } from "../team-selection";
import { resolveTeamMarkerAware } from "../index-home";
import { envelopeField } from "../envelope";
import { jsonObj, atomicWrite } from "../fsatomic";
import { utcStamp, validId, validToken } from "../ids";
import { acquireObligationLock } from "../panelock";
import { claimAcquire, claimRelease, metaPath, payloadPath, removeEntry } from "../spool-sidecar";
import { isFile } from "../watch-lease";
import { libCall } from "../watch-detectors";
import { assertResetUnfenced, markResetGenerationReused } from "../reset";
import { instanceClearingRemedy, NO_CLEARING_PATH, historyDirForBus } from "../addressee-grant";
import { currentInstance, loadRegistry, seatMap } from "../registry";

// Security boundary (tap-fcd3): an ABSENT registry at a RESOLVED location is
// evidence the team is gone and the obligation can never settle, so it cancels.
// An unreadable or unresolved one is unknown, never an answer, and refuses.
function classifySeat(registryPath: string, handle: string): string {
  let seats: Record<string, unknown>;
  try { seats = seatMap(loadRegistry(registryPath)); }
  catch { return "unreadable"; }
  // OWN-property check: a bracket read on seatMap's plain object inherits constructor/toString and mistakes a prototype member for a seat row.
  if (!Object.hasOwn(seats, handle) || seats[handle] == null) return "gone"; // absent from the consulted registry — gone, not active
  const row = seats[handle] as Record<string, unknown>;
  const status = typeof row.status === "string" && row.status ? row.status : "active";
  return status === "active" && row.status_reason === "launching" ? "launching" : status;
}

// attach.ts carries the same file-local twins; neither unit owns the other's
// bytes, so each keeps its own rather than widening a shared export.
function legacyRegistry(root: string): string {
  // EXISTS not isFile: non-regular canonical paths must reach the statSync
  // guard, not fall through to an ABSENCE-manufactured gone verdict.
  const dotdir = join(root, ".tap", "bus", "registry.json");
  return existsSync(dotdir) ? dotdir : join(root, "tmp", "tap", "registry.json");
}

export function cmdCancel(argv: string[], scriptsDir: string): number {
  // Restart catch-up via the shared helper: best-effort/silent, run on BOTH doors (the direct Bun entry has no tap.sh pre-dispatch).
  libCall(scriptsDir, "tap_registry_invalidate_server_restart", []);
  let id = "", actor = process.env.TAP_SELF ?? "", team = "", spooled = false, json = false;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!;
    if (arg === "--by" || arg === "--team") {
      const value = argv[++i];
      if (value === undefined || value === "") throw new TapError(1, "usage_error", "tap help cancel", `${arg} needs a value`);
      if (arg === "--by") actor = value; else team = value;
    } else if (arg === "--json") { json = true; process.env.TAP_JSON = "1"; }
    else if (arg === "--spooled") spooled = true;
    else if (arg.startsWith("--")) throw new TapError(1, "unknown_option", "tap help cancel", `unknown option '${arg}'`);
    else if (!id) id = arg;
    else throw new TapError(1, "usage_error", "tap help cancel", `unexpected arg '${arg}'`);
  }
  if (!id) throw new TapError(1, "usage_error", "tap help cancel", "usage: tap cancel <id> [--by <me>] [--team <name>] [--spooled] [--json]");
  if (!validId(id)) throw new TapError(1, "usage_error", "tap help cancel", `invalid id '${id}'`);

  const callerPin = process.env.TAP_HOME ?? "";
  applyTeamOverride(team);
  const ctx = resolveSelection(callerPin, team);
  // Actor: --by > TAP_SELF > pane-derived handle. The pane fallback fails SOFT
  // (the incumbent swallowed resolve errors into empty), so an unobservable
  // pane is the plain no_actor refusal, not a generation verdict.
  if (!actor) {
    const pane = callingPane();
    if (pane?.status === "ok") actor = resolveSelf(ctx, pane, 1).handle;
  }
  if (!actor) throw new TapError(1, "no_actor", "pass --by <handle> (or run 'tap register' to join this team)", "cancel requires an actor");
  if (!validToken(actor)) throw new TapError(1, "usage_error", "tap help cancel", `actor '${actor}' is not a valid token`);

  assertResetUnfenced(ctx.bus.home, "tap cancel");
  ctx.bus.ensureDirs();
  const spoolDir = join(ctx.bus.home, "spool");
  const lock = acquireObligationLock(id, 5000);
  if (!lock) throw new TapError(1, "obligation_busy", `retry tap cancel ${id}`, `another process is acting on '${id}'; refusing to cancel without exclusive eligibility`);
  let claimHeld = false;
  try {
    mkdirSync(spoolDir, { recursive: true });
    if (claimAcquire(spoolDir, id, true) === "held") {
      throw new TapError(1, "spool_busy", `retry tap cancel ${id}`, `spool entry '${id}' is claimed; leaving its payload and receipts unchanged`);
    }
    claimHeld = true;
    // Already-settled/already-cancelled FIRST: a cancelled id's payload was
    // archived, so the residency not_found would otherwise fire instead.
    // Every EXISTING path is terminal (a squatter on the receipt name included).
    if (existsSync(ctx.bus.donePath(id))) throw new TapError(1, "already_settled", "tap outstanding", `'${id}' is already settled (.done exists)`);
    if (existsSync(ctx.bus.cancelPath(id))) throw new TapError(1, "already_cancelled", "tap outstanding", `'${id}' is already cancelled (.cancelled exists)`);

    // Payload-first, spool-second: a spooled dead obligation is the exact
    // motivating case — the send parked and the target later vanished.
    let payload = ctx.bus.payloadPath(id), source = "payloads";
    const spoolBody = payloadPath(spoolDir, id);
    if (!isFile(payload)) {
      if (!isFile(spoolBody)) throw new TapError(1, "not_found", `tap send <id>`, `no local payload '${id}' to cancel (not in payloads/ or spool/)`);
      payload = spoolBody;
      source = "spool";
    }
    // An unconfirmed transport disposition retains both copies for recovery.
    // Its canonical copy is not proof of delivery; explicit withdrawal is valid.
    let unconfirmedCustody = false;
    if (spooled && isFile(join(ctx.bus.receiptsDir, `${id}.unconfirmed`)) && isFile(spoolBody) && isFile(metaPath(spoolDir, id))) {
      unconfirmedCustody = true;
      source = "spool";
    }

    // Content uncertainty is not an answer: one structured refusal, payload
    // unmoved (never a raw throw — the --json caller gets its envelope).
    let raw: string;
    try { raw = readFileSync(payload, "utf8"); }
    catch { throw new TapError(1, "payload_unreadable", "tap doctor", `payload '${id}' exists at '${payload}' but could not be read; refusing cancel — an unreadable payload is unknown, not settled, and stays in place`); }
    const field = (key: string) => envelopeField(raw, key) ?? "";
    const envFrom = field("from");
    if (!envFrom) throw new TapError(1, "usage_error", "tap help cancel", `payload '${id}' has no 'from' field`);
    const remedyInput = { adoptionRegistryPath: ctx.registryPath, marker: ctx.marker, historyDir: historyDirForBus(ctx.bus.home) };
    if (envFrom !== actor) {
      // Ask the question the NEXT gate will ask, before recommending a command
      // that has to pass it (tap-ye2n). A third party gets the diagnosis, never
      // the sender's remedy as a command.
      const probe = instanceClearingRemedy(remedyInput, envFrom, field("sender_instance"));
      if (probe.kind !== "unknown") {
        throw new TapError(1, "not_sender", "tap team",
          `'${id}' was sent by '${envFrom}', not '${actor}' — only the sender may cancel, and '${envFrom}' cannot cancel it as it stands either: ${probe.detail}`);
      }
      throw new TapError(1, "not_sender", `tap cancel ${id} --by ${envFrom}`, `'${id}' was sent by '${envFrom}', not '${actor}' — only the sender may cancel`);
    }
    if (ctx.marker === "live") {
      const sinst = field("sender_instance");
      if (sinst) {
        if (!ctx.registryPath) throw new TapError(1, "registry_unreachable", "tap doctor", `acting registry unreachable — cannot verify sender instance for '${id}'`);
        const mySinst = currentInstance(ctx.registryPath, actor);
        // Never re-suggest `tap cancel <id> --by <sender>` here: the caller just
        // ran exactly that and landed on this refusal (#xxx).
        if (mySinst !== sinst) {
          const remedy = instanceClearingRemedy(remedyInput, actor, sinst);
          const why = `'${id}' is bound to sender instance '${sinst}', not the current '${actor}' instance '${mySinst || "<none>"}'`;
          if (remedy.kind === "command") {
            throw new TapError(1, "not_sender", remedy.next, `${why} — retrying 'tap cancel ${id} --by ${envFrom}' fails identically; ${remedy.detail}`);
          }
          throw new TapError(1, "not_sender", remedy.next || NO_CLEARING_PATH, `${why}${remedy.detail ? ` — ${remedy.detail}` : ""}`);
        }
      }
    }

    const envTo = field("to");
    if (!envTo) throw new TapError(1, "usage_error", "tap help cancel", `payload '${id}' has no 'to' field`);
    const envToTeam = field("to_team");
    // --spooled asserts UNDELIVERED residency of the residency this run
    // resolved, before any registry lookup: it must never apply to a CANONICAL
    // payload, where it would blanket-bypass the seat_active refusal for
    // delivered mail (tap-cm00).
    if (spooled && source !== "spool") {
      const recover = field("reply") === "settle-only"
        ? `tap read ${id} --by ${envTo || "<addressee>"}`
        : `tap reply ${id} -f <file>  (the addressee answers it)`;
      throw new TapError(1, "not_spooled", recover,
        `--spooled withdraws an UNDELIVERED send, but '${id}' is a delivered payload in payloads/ — the addressee has it and can settle it normally`);
    }

    // Seats-first status: gone only after a successfully loaded registry proves
    // absence; invalid/unreadable/unresolved refuse — never authorize cancel.
    let targetStatus = "", registryChecked = "", statusRegistry = "";
    if (envToTeam && envToTeam !== ctx.team) {
      const resolved = resolveTeamMarkerAware(envToTeam, process.env.TAP_INDEX_HOME);
      if (resolved.marker === "invalid") {
        throw new TapError(1, "invalid_flip", "tap doctor", "registry flip marker is present but invalid — refusing cancel that would treat the recipient as gone");
      }
      let location = resolved.registryLocation;
      if (!location && resolved.marker === "absent") {
        // Incumbent authority ladder under an absent marker: the legacy
        // registry root when the index knows the team, then the pre-flip
        // worktree scan. The scan anchors to the SELECTED context root only —
        // no cwd fallback (a standalone bus outside Git refuses) and an untrusted scan refuses.
        if (resolved.status === "ok" && resolved.root) location = legacyRegistry(resolved.root);
        else {
          const scan = worktreeTeamRoot(envToTeam, repoRoot(ctx.root));
          if (scan.state === "found") location = legacyRegistry(scan.root);
          else if (scan.state === "error" || scan.state === "ambiguous") {
            throw new TapError(1, "unreachable_team", `re-enroll team '${envToTeam}', or repair its registry`, `cannot scan for team '${envToTeam}' worktrees (${scan.detail || scan.state}); refusing cancel — an ABSENT registry is treated as gone and cancels, but an unreadable one is unknown, not an answer`);
          }
        }
      }
      if (location && !existsSync(location)) {
        // Provable absence only: we resolved WHERE the registry should be and
        // nothing is there. Bind no registry, so absence can never become a
        // back door to the forbidden sibling rescue.
        targetStatus = "gone";
        registryChecked = `foreign_team_registry (${envToTeam}): absent at ${location}`;
      } else if (location) {
        registryChecked = `acting_registry (team '${envToTeam}')`;
        statusRegistry = location;
        // Before any soft load: a DIRECTORY or FIFO at the authority path is
        // uncertainty, not absence — and readFileSync on a FIFO blocks forever.
        // Local to cancel's authority read; refuses from metadata, never opens.
        let regular = false;
        try { regular = statSync(location).isFile(); } catch { regular = false; }
        if (!regular) {
          throw new TapError(1, "registry_error", `repair or remove '${location}'`, `recipient registry '${location}' is not a regular file; refusing cancel — an ABSENT registry is treated as gone and cancels, but an unreadable one is unknown, not an answer`);
        }
        targetStatus = classifySeat(location, envTo);
        if (targetStatus === "unreadable") {
          throw new TapError(1, "registry_error", `repair or remove '${location}'`,
            `recipient registry '${location}' is unreadable; refusing cancel — an ABSENT registry is treated as gone and cancels, but an unreadable one is unknown, not an answer`);
        }
      } else {
        throw new TapError(1, "unreachable_team", `re-enroll team '${envToTeam}', or repair its registry`, `cannot observe team '${envToTeam}' registry (${resolved.status}); refusing cancel — an ABSENT registry is treated as gone and cancels, but an unreadable one is unknown, not an answer`);
      }
    } else {
      registryChecked = "bound_team_registry";
      statusRegistry = ctx.registryPath;
      targetStatus = classifySeat(ctx.registryPath, envTo);
      if (targetStatus === "unreadable") {
        throw new TapError(1, "registry_error", "tap doctor", `local registry '${statusRegistry}' is unreadable; refusing cancel`);
      }
    }

    // A stamped payload stays bound even without a flip marker. Active refusals
    // apply only when the CURRENT recipient instance matches the envelope
    // stamp: a fresh same-handle seat cannot settle predecessor-bound mail, so
    // refusing cancel would strand the matching sender instance with no
    // clearing path.
    let recipientMatches = true;
    if (source !== "spool" && statusRegistry) {
      const rinst = field("recipient_instance");
      if (rinst) {
        const cur = currentInstance(statusRegistry, envTo);
        if (cur && cur !== rinst) recipientMatches = false;
      }
    }

    // A live addressee can settle only mail it HAS. Undelivered (spooled) mail
    // is withdrawable by its sender via --spooled; delivered mail is not.
    let withdrawn = false;
    if ((targetStatus === "active" || targetStatus === "launching") && recipientMatches) {
      if (source === "spool") {
        if (spooled) withdrawn = true;
        else throw new TapError(1, "spooled_needs_flag", `tap cancel ${id} --by ${actor} --spooled`,
          `'${id}' is PARKED in the spool and has never reached '${envTo}', so '${envTo}' cannot settle it (settlement resolves ids against payloads/). Withdraw it with --spooled, or leave it parked to deliver when that pane frees up`);
      } else if (targetStatus === "active") {
        const activeNext = field("reply") === "settle-only"
          ? `tap read ${id} --by ${envTo}`
          : `tap reply ${id} -f <file>  (${envTo} answers it)`;
        throw new TapError(1, "seat_active",
          `tap withdraw ${id} -m '<why it is superseded>'   (or let them settle it: ${activeNext})`,
          `'${envTo}' is still an active registered seat — cancel is for sends whose addressee is GONE. If the send still stands, they settle it normally (tap read for a note, tap reply for an ask); if you have SUPERSEDED it, withdraw it: that stops it aging on your outstanding list and leaves them a tombstone instead of a dead head`);
      } else {
        throw new TapError(1, "seat_launching", "wait for the launch to finish", `'${envTo}' is still launching — cancel is for sends whose addressee is GONE`);
      }
    }
    cancelScratchBarrier("cancel-after-eligibility", id);

    // ARCHIVE, then remove: the archive renames the spool body's inode first,
    // so the removal finds nothing and the withdrawn body survives. Above the
    // rename it would destroy the only copy; a bare meta unlink would also sit
    // outside the entry's meta lock — `removeEntry` holds that lock across all
    // three sidecars (courier-busy-hold 13d pins the archived bytes).
    const archiveDir = join(ctx.bus.home, "archive");
    mkdirSync(archiveDir, { recursive: true });
    const archivePath = join(archiveDir, `${id}.cancelled.md`);
    if (isFile(payload)) renameSync(payload, archivePath);
    cancelScratchBarrier("cancel-after-archive", id);
    if (source === "spool") removeEntry(spoolDir, id);

    // Two facts share this receipt and the ledger must tell them apart.
    const reason = unconfirmedCustody ? "unconfirmed_withdrawn" : withdrawn ? "spooled_withdrawn" : !recipientMatches ? "instance_retired" : "seat_unresolvable";
    atomicWrite(ctx.bus.cancelPath(id), jsonObj({
      id, status: "cancelled", at: utcStamp(), by: actor, via: "cancelled",
      reason, target: envTo, target_status: targetStatus, registry_checked: registryChecked, source,
    }) + "\n");
    markResetGenerationReused(ctx.bus.home, "cancel");

    if (json) {
      process.stdout.write(jsonObj({ status: "cancelled", id, via: "cancelled", reason, target: envTo, target_status: targetStatus, by: actor, source }) + "\n");
    } else if (unconfirmedCustody) {
      process.stdout.write(`tap cancel: cancelled ${id} (sender withdrew an unconfirmed delivery; prior recipient effect remains unknown)\n`);
    } else if (withdrawn) {
      process.stdout.write(`tap cancel: cancelled ${id} (withdrew an undelivered send to '${envTo}', which is ${targetStatus}; source: ${source})\n`);
    } else {
      process.stdout.write(`tap cancel: cancelled ${id} (target '${envTo}' is ${targetStatus}; source: ${source})\n`);
    }
    return 0;
  } finally {
    lock.release();
    if (claimHeld) { try { claimRelease(spoolDir, id); } catch { /* the claim is best-effort custody, never a verdict */ } }
  }
}

/** Scratch-only mutation barrier; production callers never enter it. */
function cancelScratchBarrier(stage: string, id: string): void {
  const base = process.env.TAP_OBLIGATION_TEST_BARRIER;
  if (!base || !process.env.TAP_SCRATCH_ONLY || process.env.TAP_OBLIGATION_TEST_ID !== id) return;
  if ((process.env.TAP_OBLIGATION_TEST_STAGE ?? "") !== stage) return;
  writeFileSync(`${base}.${stage}.${process.pid}.reached`, "1\n");
  const release = `${base}.${stage}.release`;
  const deadline = Date.now() + 60_000;
  while (!existsSync(release)) {
    if (Date.now() >= deadline) throw new Error(`cancel ${stage} test barrier timed out`);
    Bun.sleepSync(5);
  }
}
