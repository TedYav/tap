// The digest transaction (Phase C of the drain), ported from lib.sh
// `tap_spool_digest_inject` and `tap_spool_notify_digest_senders`.
//
// THE WALK DECIDES; THE ADAPTER FETCHES AND EFFECTS — the shape A3a ratified for
// `tap_spool_pane_ready` (`spool-readiness.ts`), reused here because this function is
// an ORCHESTRATOR over slices that are already native: claim CAS (`spool-sidecar.ts`),
// the index write and stamp (`digest-index.ts`), the outcome table
// (`slices/digest-outcome.ts`), the sender grouping (`notice.ts`), the id mint
// (`ids.ts`) and the sentinel (`sentinel.ts`). What was Bash is the sequencing, the
// survivor bookkeeping, and six things this runtime may not do for itself:
//
//   readiness      the pane predicate, whose CAPTURE belongs to the caller's language
//                  (B1's ruling; a native capture would ask a different tmux server than
//                  the bare `tap_capture_pane` the smokes stub as a shell function)
//   matches-team   `tap_registry_matches_team`, five other production callers
//   identity       `tap_bound_pane_identity_state`, likewise shared
//   harness        `tmux display-message -p '#{pane_current_command}'`
//   submit         `tap_debug_spool_submit` (which marks every member at its
//                  shared first-pane-effect boundary)
//   notify-sender  `tap_spool_notify_sender_on_escalate`, three other production callers
//
// PER-ID OBSERVATIONS STAY PER-ID. `matches-team` and `identity` take arguments that do
// not vary across the batch, so asking once would be the obvious optimization and is
// wrong: the incumbent asked once PER SURVIVOR inside its revalidation loop, and
// `courier-digest.test.sh`'s first arm drives exactly that — `FAKE_LIST_PANES_FLIP_AFTER=3`
// flips the identity answer on the FOURTH list-panes call (the stub flips when the count
// exceeds 3), so a batch that probed once would never reach the drift the arm exists to
// test. It would not go red, either: the refusal would simply move to the effect boundary,
// and the arm would pass while its revalidation-drift coverage was gone. The round count is
// therefore a function of the batch size, not a constant.
//
// THE REFUSAL THIS FILE DOES NOT ABSORB (charter rule 3). The bus-authority marker
// (`tap_spool_home_authorized_or_warn`) stays in the adapter, ahead of the door, exactly
// as A3a left the clear-fence pre-check ahead of the readiness door: it is a shared guard
// with production callers on the drain entry and on redeliver, and reimplementing its file
// test here would be a second engine for a refusal rule 3 protects.

import { appendFileSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";

import { digestIndexPath, stampInjected, writeDigestIndex } from "./digest-index";
import { mintId } from "./ids";
import { recordHarnessQueued } from "./harness-queue";
import { renderSentinel } from "./sentinel";
import { digestOutcome } from "./slices/digest-outcome";
import { claimAcquire, claimRelease, metaField, metaPath, payloadPath as spoolPayloadPath } from "./spool-sidecar";
import { queuedDraftClobberDue } from "./injection-behavior";
import { graceAttempted, type DeadlineContext } from "./spool-deadline";

/**
 * `$TAP_AUTOSETTLE_POLICY` — `tap_spool_entry_is_presettled`'s one comparison, and the
 * literal is `autosettle` with no separator (lib.sh:1930). The plausible spelling is wrong
 * and fails QUIETLY in the direction of doing less: no entry matches, `autos` is empty, and
 * a batch that should have notified its senders simply notifies nobody.
 */
export const AUTOSETTLE_POLICY = "autosettle";

/** Facts the caller already holds when it enters the transaction. */
export interface InjectPrefix {
  /** `$TAP_HOME`. */
  home: string;
  /** `$TAP_SPOOL`. */
  spoolDir: string;
  /** `$TAP_PAYLOADS`. */
  payloadsDir: string;
  /** `$TAP_RECEIPTS`. */
  receiptsDir: string;
  /** `tap_spool_team_name` — the empty-`toTeam` fallback, in both carriers. */
  team: string;
  /** `$TAP_COURIER_IDENTITY`. */
  courierIdentity: string;
  targetRegistry: string;
  toTeam: string;
  handle: string;
  pane: string;
  paneId: string;
  /** The candidate ids, in the caller's order. */
  ids: string[];
}

/**
 * One observation or effect the walk wants next. `id` rides the per-entry kinds so the
 * adapter answers about the entry the walk is currently revalidating.
 */
export type InjectNeed =
  | { kind: "readiness" }
  | { kind: "matches-team"; id: string }
  | { kind: "identity"; id: string }
  | { kind: "harness" }
  | { kind: "submit"; submit: SubmitRequest }
  | { kind: "notify-senders"; digestId: string; target: string; registry: string; ids: string[] };

/** Everything `tap_debug_spool_submit` needs, composed here and decided nowhere else. */
export interface SubmitRequest {
  /** Ids handed to submit for `.attempted` marking at its first pane effect. */
  attemptIds: string[];
  preserveDraft: boolean;
  payloadPath: string;
  digestId: string;
  /**
   * The incumbent's `$survivors`, INCLUDING ITS LEADING SPACE. Bash accumulated the list as
   * `survivors="$survivors $id"` from an empty string, and this argument is passed QUOTED, so
   * `tap_debug_spool_submit` records it as `members=[ m1 m2]` in the debug attempt row. The
   * differential caught the difference on the effects log. Reproduced rather than tidied: a
   * port is not the place to change a byte a recorded artifact carries, and the fix, if
   * anyone wants one, is its own change with its own reason.
   *
   * THE SENDER NOTICE IS NOT A CARRIER OF IT, and an earlier version of this comment said it
   * was (sol-pinnacle-1's unit-3 correction). The incumbent passes `$autos` UNQUOTED to
   * `tap_spool_notify_digest_senders` (lib.sh:3067), so word splitting drops the padding
   * before the callee sees it, and `notice.ts` rebuilds each group with `ids.join(" ")`. One
   * carrier, not two — scoping the claim matters because the next reader deciding whether to
   * tidy this byte needs to know exactly which artifact would change.
   */
  members: string;
  pane: string;
  sentinel: string;
  handle: string;
  targetRegistry: string;
  paneId: string;
  /**
   * THE COMPLETE DECISION TABLE, RESOLVED BEFORE THE EFFECT — five fixed-order rows, one per
   * submit status (0, 5, 124, 7, then the generic failure). The incumbent computed exactly this
   * before `tap_debug_spool_submit` and said why: *"no subprocess is needed between an observed
   * submit and its custody disposition."* This port moved that computation to the far side of
   * the effect and reintroduced a fallible boundary the incumbent did not have
   * (sol-pinnacle-1 on #xxxx; rule 54). Handing the table over WITH the submit request is what
   * lets the caller apply custody in the shell that observed the effect.
   */
  outcomeTable: OutcomeRow[];
}

/** One row of the pre-resolved table. The caller selects by rc and applies; it never decides. */
export interface OutcomeRow {
  /** The submit status this row answers, or `*` for the generic failure row. */
  key: string;
  canonicalize: boolean;
  stampClock: boolean;
  notifySenders: boolean;
  returnCode: number;
  event: string;
  diagnostic: string;
}

/** A registry-event append the adapter never composes and never interprets. */
export interface InjectEvent {
  identity: string;
  event: string;
  handle: string;
  pane: string;
  detail: string;
  /** `tap_registry_event_append_or_warn` (true) vs the silent `..._append` (false). */
  warn: boolean;
}

/** A stderr line the incumbent printed. The adapter writes it and reads nothing into it. */
export type InjectWarning = string;

export type InjectStep =
  | { done: true; rc: number; events: InjectEvent[]; warnings: InjectWarning[]; stampClock: boolean }
  | { done: false; need: InjectNeed };

/** The answers the adapter hands back, one field per need kind. */
export interface InjectAnswer {
  readiness?: string;
  /** Legacy adapter answer: attempt evidence failed before any pane effect. */
  attemptFailed?: boolean;
  matchesTeam?: boolean;
  identity?: string;
  harness?: string;
  submitRc?: number;
  notified?: boolean;
}

/**
 * The walk's carried record. It round-trips the adapter boundary as a FILE, not as a
 * shared object: a control that hands this between rounds in-process proves the decisions
 * and proves nothing about the boundary, which is the defect gemini found in A3a's
 * `converse()`.
 */
export interface InjectState {
  prefix: InjectPrefix;
  /** Claims held, in acquisition order. Released on every exit path. */
  claimed: string[];
  /** Ids that survived revalidation, in the incumbent's order. */
  survivors: string[];
  /** Survivors whose policy is auto-settle. */
  autos: string[];
  /** The index of the claimed id currently being revalidated. */
  cursor: number;
  /** Per-entry observations already answered for `claimed[cursor]`. */
  matchesTeam?: boolean;
  identity?: string;
  digestId?: string;
  clobberDraft?: boolean;
  indexPath?: string;
  harness?: string;
  /** Where the claim ledger lives. Absent only for an in-process caller. */
  ledger?: string;
  /** The finished verdict, held across the notify round. */
  pending?: { rc: number; events: InjectEvent[]; warnings: InjectWarning[]; stampClock: boolean };
  phase: "claim" | "readiness" | "revalidate" | "harness" | "submit" | "notify" | "done";
}

export function initialState(prefix: InjectPrefix, ledger?: string): InjectState {
  return { prefix, claimed: [], survivors: [], autos: [], cursor: 0, phase: "claim", ledger };
}

/** One id per line, appended. A torn append loses at most its own last line. */
function recordClaim(ledger: string, id: string): void {
  try { appendFileSync(ledger, `${id}\n`); } catch { /* the ledger is a safety net, not a gate */ }
}

/**
 * The ids this transaction actually acquired, read line-wise so a truncated file still
 * yields every complete line before the tear. A partial last line is dropped rather than
 * guessed at: releasing a claim on a misread id would be releasing a sibling's.
 */
function ledgerClaims(ledger: string): string[] {
  let text = "";
  try { text = readFileSync(ledger, "utf8"); } catch { return []; }
  const lines = text.split("\n");
  if (!text.endsWith("\n")) lines.pop();
  return lines.filter(line => line.length > 0);
}

function deadlineContext(prefix: InjectPrefix): DeadlineContext {
  // `graceAttempted` reads `home` and `spoolDir` only; the remaining fields carry the
  // caller's real values where it has them, so a later reader cannot mistake this for a
  // stub context that happens to work.
  const ctx: DeadlineContext = {
    home: prefix.home, spoolDir: prefix.spoolDir, eventLog: "", team: prefix.team,
    verbLabel: "tap", actingRegistry: "", scriptsDir: "", alert: { mode: "none" }, now: 0, unroutedGrace: 0,
  };
  return ctx;
}

/**
 * `[ -f "$path" ]` — regular file, following symlinks (charter rule 38). `existsSync`
 * would take the present branch for a DIRECTORY at the same path; a stat that throws is
 * the operator's FALSE, never an error.
 */
function isRegularFile(path: string): boolean {
  try { return statSync(path).isFile(); } catch { return false; }
}

const canonicalPath = (p: InjectPrefix, id: string) => join(p.payloadsDir, `${id}.md`);
const donePath = (p: InjectPrefix, id: string) => join(p.receiptsDir, `${id}.done`);
const cancelPath = (p: InjectPrefix, id: string) => join(p.receiptsDir, `${id}.cancelled`);

/**
 * Release every claim this transaction holds — and RETIRE THE LEDGER IN THE SAME BREATH.
 *
 * The ledger is a list of claims we hold. The moment we hold none it is a list of claims
 * SOMEBODY ELSE may hold, and replaying it is no longer cleanup but a reach into another
 * transaction's custody. sol-pinnacle-1 found the window on #xxxx: `postSubmit` releases every
 * member claim and then returns `need notify-senders`, and during that Bash round a canonical
 * `tap cancel <member>` may acquire the same claim (tap-cancel.sh:55-68). A later round
 * failing would then have the abort — native or pure-Bash — delete the successor's live claim.
 *
 * So this is the one place claims go away and the one place the ledger is retired, which is
 * what keeps the two from drifting apart. Every release path reaches here, including the
 * canonicalize loop's per-survivor releases, which end at this call.
 */
function releaseAll(state: InjectState): void {
  for (const id of state.claimed) claimRelease(state.prefix.spoolDir, id);
  state.claimed = [];
  if (state.ledger) rmSync(state.ledger, { force: true });
}

function finish(state: InjectState, rc: number, events: InjectEvent[] = [],
                warnings: InjectWarning[] = [], stampClock = false): InjectStep {
  state.phase = "done";
  return { done: true, rc, events, warnings, stampClock };
}

/**
 * One step of the transaction. Call it with the state the previous step returned and the
 * answer to the need it asked for; it either answers a final rc or asks for the next thing.
 *
 * Statuses are the incumbent's, unchanged: 0 on a verified digest, 5 or 124 when the
 * submission is unverified or timed out AFTER canonicalization, 2 when fewer than two
 * entries survive revalidation and none auto-settles (the caller hands the survivors to
 * the per-id path — the one status `tap_spool_drain_once` branches on), 1 otherwise.
 */
export function digestInjectStep(state: InjectState, answer: InjectAnswer = {}): InjectStep {
  switch (state.phase) {
    case "claim": return claimPhase(state);
    case "readiness": return readinessPhase(state, answer);
    case "revalidate": return revalidate(state, answer);
    case "harness": {
      state.harness = answer.harness ?? "";
      return mintAndSubmit(state);
    }
    case "submit": return postSubmit(state, answer);
    case "notify": {
      const pending = state.pending!;
      return finish(state, pending.rc, pending.events, pending.warnings, pending.stampClock);
    }
    default:
      releaseAll(state);
      return finish(state, 1);
  }
}

// 1. Claim every candidate (exclusive-create CAS). A contended claim means another
//    drainer owns that entry — abort the whole group rather than split it.
function claimPhase(state: InjectState): InjectStep {
  const p = state.prefix;
  for (const id of p.ids) {
    if (claimAcquire(p.spoolDir, id) === "acquired") {
      // THE LEDGER IS APPENDED AFTER THE ACQUIRE, NEVER BEFORE. It exists so `--abort` can
      // release this transaction's claims when the carried record is unreadable, and the
      // ordering is what keeps it from releasing a SIBLING's: a line written before the CAS
      // would name a claim we might never own. Written after, the worst case is a crash in
      // the gap that leaks exactly one claim, which the sidecar's own staleness steal bounds
      // — the same exposure a hard kill always had.
      if (state.ledger) recordClaim(state.ledger, id);
      state.claimed.push(id);
    } else {
      releaseAll(state);
      return finish(state, 1);
    }
  }
  state.phase = "readiness";
  return { done: false, need: { kind: "readiness" } };
}

// 2. Re-check readiness once under the held claims (claim-then-verify, as redeliver).
// NO policy arg, deliberately (tap-toi9): phase A probes each candidate WITH its own
// policy, so a polite entry whose seat is mid-turn never reaches this batch. Every id that
// got here is non-polite, and passing one entry's policy would apply it to all of them.
function readinessPhase(state: InjectState, answer: InjectAnswer): InjectStep {
  state.clobberDraft = answer.readiness === "busy:pending" && state.claimed.length > 0
    && state.claimed.every(id => queuedDraftClobberDue(state.prefix.spoolDir, id));
  if (answer.readiness !== "ready" && !state.clobberDraft) {
    releaseAll(state);
    return finish(state, 1);
  }
  state.phase = "revalidate";
  state.cursor = 0;
  return revalidate(state, {});
}

// 3. Revalidate each claimed id (present, unsettled, binding still matches). A late
//    settle/cancel or identity drift drops that id from the batch, never the digest.
function revalidate(state: InjectState, answer: InjectAnswer): InjectStep {
  const p = state.prefix;
  const ctx = deadlineContext(p);
  let pending = answer;

  while (state.cursor < state.claimed.length) {
    const id = state.claimed[state.cursor]!;

    // The pure reads come first, in the incumbent's order: a payload that left the spool
    // is skipped before any observation is spent on it.
    if (!isRegularFile(spoolPayloadPath(p.spoolDir, id)) || !isRegularFile(metaPath(p.spoolDir, id))) {
      state.cursor++; continue;
    }
    if (graceAttempted(ctx, id)) { state.cursor++; continue; }
    if (metaField(p.spoolDir, id, "escalated_at") !== "") { state.cursor++; continue; }
    // `tap_is_done`: a `.done` OR a `.cancelled` receipt.
    if (isRegularFile(donePath(p, id)) || isRegularFile(cancelPath(p, id))) { state.cursor++; continue; }

    if (state.matchesTeam === undefined) {
      if (pending.matchesTeam === undefined) return { done: false, need: { kind: "matches-team", id } };
      state.matchesTeam = pending.matchesTeam;
      pending = {};
    }
    if (state.matchesTeam === false) { clearEntry(state); continue; }

    if (state.identity === undefined) {
      if (pending.identity === undefined) return { done: false, need: { kind: "identity", id } };
      state.identity = pending.identity;
      pending = {};
    }
    const identity = state.identity;
    clearEntry(state);
    if (identity !== "match") continue;

    state.survivors.push(id);
  }

  return afterRevalidation(state);
}

/** Advance past the entry under revalidation and forget its per-entry observations. */
function clearEntry(state: InjectState): void {
  state.matchesTeam = undefined;
  state.identity = undefined;
  state.cursor++;
}

function afterRevalidation(state: InjectState): InjectStep {
  const p = state.prefix;

  // tap-31it: an auto-settle survivor makes N>=1 legal for THIS batch — the doorbell is
  // that item's only delivery, so there is no per-id path to hand it back to. Ordinary
  // spool keeps N>=2 exactly as before: a lone busy-pane park still takes its own solo
  // redelivery rather than a digest envelope.
  state.autos = state.survivors.filter(id => metaField(p.spoolDir, id, "policy") === AUTOSETTLE_POLICY);
  const nsurv = state.survivors.length;
  // Not a digest after revalidation — hand the survivors back to the per-id path.
  if (nsurv < 2 && state.autos.length === 0) { releaseAll(state); return finish(state, 2); }
  if (nsurv < 1) { releaseAll(state); return finish(state, 2); }

  state.phase = "harness";
  return { done: false, need: { kind: "harness" } };
}

// 4. Mint the digest id and write the index (canonical paths) BEFORE submit.
//
// OUTCOME-NEUTRAL BEFORE SUBMIT (sol-prepull, round 2). The index published here is the
// file the recipient is about to be pointed at, and at this moment the courier has
// observed nothing: rows therefore carry each payload's own obligation. Pre-settling them
// here would publish `settled: true` while no receipt exists, and verify-5 explicitly
// allows that doorbell to have landed — so a seat could act on the false instruction
// before any repair could reach it. A rewrite AFTER the fact repairs an artifact the
// reader may already have used; the only sound version is to claim nothing until the
// injection is verified, which is the same rule the receipt writer already follows.
function mintAndSubmit(state: InjectState): InjectStep {
  const p = state.prefix;
  const toTeam = p.toTeam || p.team;
  const digestId = mintId(p.courierIdentity);
  const indexPath = digestIndexPath(p.spoolDir, digestId);
  state.digestId = digestId;
  state.indexPath = indexPath;

  try {
    writeDigestIndex({
      indexPath, digestId, toTeam, handle: p.handle, courier: p.courierIdentity,
      spoolDir: p.spoolDir, payloadsDir: p.payloadsDir,
      members: state.survivors.map(id => ({ id, presettled: false })),
    });
  } catch {
    rmSync(indexPath, { force: true });
    releaseAll(state);
    return finish(state, 1);
  }

  // 5. Submit the single digest sentinel with the spool copies STILL in place.
  //
  // A SAME-TEAM park stores `to_team=""` and this envelope interpolates the team into
  // both halves, so an empty value used to render `from=/courier to=/peer` — a sentinel
  // whose route tokens fail the qualified-form grammar every other constructor is held to.
  // The bus being drained IS the team whose seats these are, which is what an empty
  // `to_team` means here; the fallback above is the same one the index write takes.
  const sentinel = renderSentinel({
    from: `${toTeam}/${p.courierIdentity}`, to: `${toTeam}/${p.handle}`,
    id: digestId, kind: "digest", reply: "settle-only", urgency: "", path: indexPath,
  });

  state.phase = "submit";
  return {
    done: false,
    need: {
      kind: "submit",
      submit: {
        attemptIds: [...state.survivors],
        preserveDraft: !state.clobberDraft,
        payloadPath: canonicalPath(p, digestId),
        digestId,
        members: state.survivors.map(id => ` ${id}`).join(""),
        pane: p.pane,
        sentinel,
        handle: p.handle,
        targetRegistry: p.targetRegistry,
        paneId: p.paneId,
        outcomeTable: outcomeTable(state.survivors.length),
      },
    },
  };
}

/**
 * The five fixed-order rows, from the same `digestOutcome` the verdict round uses — one
 * function, consulted twice, never two tables that could disagree.
 */
export function outcomeTable(members: number): OutcomeRow[] {
  return [0, 5, 124, 7, 1].map(rc => {
    const o = digestOutcome({ rc, members });
    return {
      key: rc === 1 ? "*" : String(rc),
      canonicalize: o.canonicalize, stampClock: o.stampClock, notifySenders: o.notifySenders,
      returnCode: o.returnCode, event: o.event, diagnostic: o.diagnostic,
    };
  });
}

function postSubmit(state: InjectState, answer: InjectAnswer): InjectStep {
  const p = state.prefix;
  const digestId = state.digestId!;
  const indexPath = state.indexPath!;
  const events: InjectEvent[] = [];
  const warnings: InjectWarning[] = [];

  // A write failure at the shared submit boundary stops the attempt before a pane effect.
  // The legacy adapter answer remains accepted during the boundary migration. An absent rc with
  // no such report is the adapter failing to run the submit at all, which decides nothing
  // about delivery either (rule 19) and takes the same refusal.
  if (answer.attemptFailed || answer.submitRc === undefined) {
    releaseAll(state);
    return finish(state, 1);
  }

  const outcome = digestOutcome({ rc: answer.submitRc, members: state.survivors.length });

  if (!outcome.canonicalize) {
    // Inject failed: discard the index (no zombie), release claims, spool intact.
    rmSync(indexPath, { force: true });
    releaseAll(state);
    events.push({ identity: "courier", event: outcome.event, handle: p.handle, pane: p.pane,
                  detail: `id=${digestId}`, warn: true });
    return finish(state, outcome.returnCode, events, warnings);
  }

  // 6. CUSTODY HAS ALREADY MOVED, in the shell that observed the submit. This round verifies
  //    it and does everything the incumbent did AFTER custody — notify, stamp, queue record,
  //    events, verdict. A runtime death here loses what a shell death lost the incumbent at
  //    the same point: telemetry and a sender notice. Never custody.
  //
  //    Exit 5 is canonicalized too, because automatic retry could duplicate a staged digest.
  //    The index is RETAINED until all N are terminal (tap-qamw: forensics/partial-settle).
  releaseAll(state);

  if (outcome.notifySenders) {
    // Exit 5/124 is ATTEMPTED, not confirmed. The index already says the truthful thing
    // (nothing was pre-settled), so nothing is rewritten here — what is owed is the
    // sender, because rc 5 also drops the spool meta and stops automatic retry, taking the
    // delivery deadline with it. The notice says UNCONFIRMED, never failed: the courier
    // cannot observe which happened.
    state.pending = { rc: outcome.returnCode, events: tailEvents(state, outcome, digestId),
                      warnings: diagnosticWarnings(outcome, digestId), stampClock: outcome.stampClock };
    state.phase = "notify";
    return { done: false, need: { kind: "notify-senders", digestId, target: p.handle,
                                  registry: p.targetRegistry, ids: [...state.autos] } };
  }

  if (answer.submitRc === 7) {
    // Accepted into the harness queue: the entries are canonical, and each one's record is
    // the queue's, not the spool's. `harness-queue.ts record` is the same door the
    // incumbent shelled to, called here because it is already native.
    for (const id of state.survivors) recordHarnessQueue(p.home, id, warnings);
  } else {
    // Verified. NOW the courier may claim what it has observed.
    //
    // SETTLED IS NOT TERMINAL, and `tap_is_done` answers the second question: it is true
    // for a `.cancelled` receipt too. A `tap cancel --spooled` landing after revalidation
    // and before this line archives the payload and writes `.cancelled` — terminal, and
    // explicitly NOT delivered — so asking "is it done" published a WITHDRAWN send as
    // settled, pointing the seat at a canonical file cancel had just removed while telling
    // its sender the send was retracted. The predicate here is "does MY kind of settlement
    // exist", which is a `.done` receipt; `.cancelled` is a different fact.
    //
    // No reader may hold a pointer whose lifetime someone else's cleanup controls: a row
    // is published only while its canonical is actually there. Cancel archives the payload,
    // so a withdrawn id leaves the index rather than becoming a dangling path in a doorbell
    // already delivered.
    const live = state.survivors.filter(id => isRegularFile(canonicalPath(p, id)));
    const settled = state.autos.filter(id => live.includes(id) && isRegularFile(donePath(p, id)));

    // STAMP BEFORE REWRITING, deliberately. Retention protects an index that recorded a
    // verified injection, so stamping first means a rewrite that fails still leaves the
    // delivered doorbell's pointer alive for its window. The other order loses the file:
    // with no stamp and no `settled` rows, an index whose receipts are all terminal is
    // immediately reapable, and the seat we just woke is pointed at nothing.
    if (state.autos.length) { try { stampInjected(indexPath); } catch { /* both words exit 0 */ } }

    // Rewritten whenever this batch carried the class: the rewrite publishes the settled
    // rows AND drops any row whose payload is gone, and it is idempotent.
    //
    // ORDINARY DIGESTS ARE EXEMPT, AND THE EXEMPTION IS A DEFERRAL, NOT A JUDGEMENT
    // (tap-nz4c). An ordinary N>=2 batch writes its index once, before submit, and is never
    // rewritten — so an id cancelled AFTER its doorbell landed leaves a row pointing at a
    // path `tap cancel` has moved to archive. That dangling-row class is pre-existing and
    // predates this change; lifting the filter out of this gate is a behavior change to
    // code this port does not otherwise touch, so it stays beaded rather than folded in.
    // Stated here because an exemption implied by an `if` is the weakest form of a
    // deliberate decision — the next reader cannot tell it from an oversight.
    if (state.autos.length) {
      try {
        writeDigestIndex({
          indexPath, digestId, toTeam: p.toTeam || p.team, handle: p.handle,
          courier: p.courierIdentity, spoolDir: p.spoolDir, payloadsDir: p.payloadsDir,
          members: live.map(id => ({ id, presettled: settled.includes(id) })),
        });
      } catch {
        // Do not discard this. The doorbell has landed and the seat is holding the OLD
        // instructions — every row still says `tap done <id>`, which now hard-errors as
        // already_settled. That is recoverable (the error names the receipt) and silence is
        // not: nothing else in the system will notice, and the drain would otherwise report
        // a clean success.
        events.push({ identity: p.courierIdentity, event: "digest_index_rewrite_failed",
                      handle: p.handle, pane: p.pane, detail: `id=${digestId}`, warn: true });
        warnings.push(`tap: digest '${digestId}' delivered, but its index could not be rewritten ` +
                      `(${indexPath}); the recipient holds pre-delivery instructions; inspect each item before acting`);
      }
    }
  }

  return finish(state, outcome.returnCode, [...events, ...tailEvents(state, outcome, digestId)],
                [...warnings, ...diagnosticWarnings(outcome, digestId)], outcome.stampClock);
}

/** The two appends every canonicalizing outcome makes, in the incumbent's order. */
function tailEvents(state: InjectState, outcome: ReturnType<typeof digestOutcome>, digestId: string): InjectEvent[] {
  const p = state.prefix;
  const events: InjectEvent[] = [{
    // The silent append: the incumbent discarded its status with `2>/dev/null || true`.
    identity: p.courierIdentity, event: `digest(n=${state.survivors.length})`,
    handle: `${p.toTeam}/${p.handle}`, pane: p.pane, detail: "", warn: false,
  }];
  if (outcome.event !== "digest") {
    events.push({ identity: "courier", event: outcome.event, handle: p.handle, pane: p.pane,
                  detail: `id=${digestId}`, warn: true });
  }
  return events;
}

function diagnosticWarnings(outcome: ReturnType<typeof digestOutcome>, digestId: string): InjectWarning[] {
  return outcome.diagnostic ? [`tap: digest id '${digestId}' ${outcome.diagnostic}`] : [];
}

function recordHarnessQueue(home: string, id: string, warnings: InjectWarning[]): void {
  // The incumbent shelled to `harness-queue.ts record` through `tap_bun_call`; inside this
  // runtime that door is one import away, and a subprocess here would be the adapter's
  // own indirection re-created for no reason.
  try { recordHarnessQueued(home, id); }
  catch (error) { warnings.push(error instanceof Error ? error.message : String(error)); }
}

export { canonicalPath, donePath, cancelPath, isRegularFile };

// --- the door -------------------------------------------------------------------
//
// One round per invocation. The carried record lives in `--state <file>`, which the
// adapter passes back untouched: it never opens it, so the record's survival across the
// boundary is a property of THIS code and is what the boundary controls drive.
//
// Answers are fixed-order fields, never free-form JSON on the Bash side: the adapter
// reads positional lines the way `tap_spool_pane_ready`'s loop reads its three, and the
// submit request is one `\x1f`-joined row the way `tap_slice_digest_outcome`'s table is.
// A group detail may contain newlines, so the notify rows keep the incumbent's own wire —
// a header line plus a NUL-terminated body, exactly as `notice.ts digest-groups` emits.

const NEED_FIELD_SEP = "\x1f";

function renderStep(step: InjectStep): string {
  if (step.done) {
    // Warnings go to stderr from HERE, not down the wire as rows. They are the incumbent's
    // own `printf ... >&2` bytes and one of them is prose that may wrap; shipping them as
    // \x1f rows would make a newline inside one split it into two rows the adapter cannot
    // rejoin. `tap_bun_call` passes stderr through untouched, so the bytes land where the
    // incumbent put them.
    for (const w of step.warnings) process.stderr.write(`${w}\n`);
    const rows = [`done ${step.rc}`, String(+step.stampClock)];
    for (const e of step.events) {
      rows.push(["event", e.identity, e.event, e.handle, e.pane, e.detail, String(+e.warn)].join(NEED_FIELD_SEP));
    }
    return rows.join("\n") + "\n";
  }
  const need = step.need;
  switch (need.kind) {
    case "readiness":
    case "harness":
      return `need ${need.kind}\n`;
    case "matches-team":
    case "identity":
      return `need ${need.kind}\n${need.id}\n`;
    case "submit": {
      const s = need.submit;
      // Line 1 is the request; the five table rows follow, fixed order, one per line. The
      // caller validates the shape before submit can reach its `.attempted` boundary —
      // a malformed table must refuse while refusing is still free.
      return "need submit\n" + [s.payloadPath, s.digestId, s.members, s.pane, s.sentinel, s.handle,
        s.targetRegistry, s.paneId, s.attemptIds.join(" "), s.preserveDraft ? "1" : "0"].join(NEED_FIELD_SEP) + "\n" +
        s.outcomeTable.map(r => [r.key, +r.canonicalize, +r.stampClock, +r.notifySenders,
          r.returnCode, r.event, r.diagnostic].join(NEED_FIELD_SEP)).join("\n") + "\n";
    }
    case "notify-senders":
      // The adapter runs `tap_spool_notify_digest_senders`, which keeps its own grouping and
      // its NUL-separated wire. Those details may contain newlines and bash command
      // substitution drops NUL bytes, so a group list carried down THIS wire would splice
      // two notices into one; the retained loop never puts them through a substitution.
      return "need notify-senders\n" +
        [need.digestId, need.target, need.registry, need.ids.join(" ")].join(NEED_FIELD_SEP) + "\n";
  }
}

function parseArgs(argv: string[]): { state: string; answer: InjectAnswer; prefix?: InjectPrefix; abort: boolean; spoolDir: string } {
  const answer: InjectAnswer = {};
  let state = "";
  let abort = false;
  let spoolDir = "";
  let prefix: InjectPrefix | undefined;
  for (let i = 0; i < argv.length; i++) {
    const flag = argv[i];
    const value = argv[i + 1];
    switch (flag) {
      case "--state": state = value ?? ""; i++; break;
      case "--readiness": answer.readiness = value ?? ""; i++; break;
      case "--matches-team": answer.matchesTeam = value === "1"; i++; break;
      case "--identity": answer.identity = value ?? ""; i++; break;
      case "--harness": answer.harness = value ?? ""; i++; break;
      case "--submit-rc": answer.submitRc = Number(value); i++; break;
      case "--notified": answer.notified = true; break;
      case "--attempt-failed": answer.attemptFailed = true; break;
      case "--abort": abort = true; break;
      // The abort needs a spool dir of its own: when the carried record is unreadable it has
      // no other way to know where the claims it must release live.
      case "--spool": spoolDir = value ?? ""; i++; break;
      case "--begin": {
        // home spool payloads receipts team courier registry to_team handle pane pane_id id...
        const [home, spoolDir, payloadsDir, receiptsDir, team, courierIdentity, targetRegistry,
               toTeam, handle, pane, paneId, ...ids] = argv.slice(i + 1);
        if (!home || !spoolDir || !payloadsDir || !receiptsDir || !handle || !pane || !ids.length) {
          throw new Error("digest inject needs its bus paths, binding and at least one id");
        }
        prefix = { home, spoolDir, payloadsDir, receiptsDir, team: team ?? "", courierIdentity: courierIdentity ?? "courier",
                   targetRegistry: targetRegistry ?? "", toTeam: toTeam ?? "", handle, pane, paneId: paneId ?? "", ids };
        i = argv.length;
        break;
      }
      default: throw new Error(`unknown digest inject argument '${flag}'`);
    }
  }
  if (!state) throw new Error("digest inject needs --state <file>");
  return { state, answer, prefix, abort, spoolDir };
}

if (import.meta.main) {
  try {
    const { state: statePath, answer, prefix, abort, spoolDir } = parseArgs(Bun.argv.slice(2));
    if (abort) { abortState(statePath, spoolDir); process.exit(0); }
    const state: InjectState = prefix
      ? initialState(prefix, `${statePath}.claims`)
      : JSON.parse(readFileSync(statePath, "utf8")) as InjectState;
    const step = digestInjectStep(state, answer);
    persist(statePath, state);
    if (step.done) rmSync(`${statePath}.claims`, { force: true });
    process.stdout.write(renderStep(step));
  } catch (error) {
    // A slice that cannot run has decided nothing (charter rule 19). The adapter's own
    // abort path releases the claims this record still names.
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(2);
  }
}

/**
 * Release every claim the carried record still holds. The adapter calls this when a round
 * fails, so a transaction that dies between rounds does not leave the batch claimed — the
 * incumbent could not lose its claims because it never left one shell.
 */
export function abortState(statePath: string, spoolDir?: string): void {
  const ledger = `${statePath}.claims`;
  let state: InjectState | undefined;
  try { state = JSON.parse(readFileSync(statePath, "utf8")) as InjectState; } catch { /* below */ }

  if (state) {
    releaseAll(state);
    persist(statePath, state);
  }

  // AND THEN THE LEDGER, EVEN WHEN THE RECORD PARSED. An abort whose only source is the
  // carried record cannot release anything when that record is unreadable — which is the one
  // situation an abort exists for (grok-examiner-8, #xxxx). The ledger names claims this
  // transaction acquired and nothing else, so releasing from it can never reach a sibling's.
  const dir = state?.prefix.spoolDir ?? spoolDir;
  if (dir) for (const id of ledgerClaims(ledger)) claimRelease(dir, id);
  rmSync(ledger, { force: true });
}

/**
 * Replace the record, never truncate it. `writeFileSync` on the live path leaves a window
 * where the file exists and is empty; a reader in that window sees a record that parses as
 * nothing, which is the shape the abort hole was hiding behind.
 */
function persist(statePath: string, state: InjectState): void {
  const staging = `${statePath}.next`;
  writeFileSync(staging, JSON.stringify(state));
  renameSync(staging, statePath);
}
