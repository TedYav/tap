// `tap watch run` -- the watch sidecar's entry (migration slice W3). This file does
// three things BEFORE the loop's modules load, in this order, because the incumbent
// did them in this order: it refuses a Bun below the floor the loop needs, it
// stamps every source the sidecar executes (the loop's own closure, the tick's, and
// the reminder door's -- watch-loop.ts, watch-tick-run.ts, remind.ts and everything
// they import, including this file), and only then imports the loop. A stamp taken
// AFTER loading would let a source that changed between the load and the stamp run
// stale for as long as nothing else changed; the incumbent's
// `_tap_sidecar_source_stamp` was computed before `. lib.sh` for the same reason
// (tap-watch.sh at f4099de37, lines 15-36). Only node built-ins are imported
// statically here.
//
// The stamp is the git blob id of each file (`git hash-object --no-filters`, computed
// in-process: sha1 over `blob <length>\0<bytes>`), so the value the incumbent compared
// is the value this compares. An unreadable source refuses another iteration
// (status 1, lease kept: "source-unreadable"); a changed stamp re-execs this entry
// with its own argv through `process.execve`, which keeps the PID the lease records
// and the tmux window owns -- the re-exec with the lease carried.
//
// The stamp list is CHECKED, not asserted: runtime/bun/test/remind.test.ts reds when
// an import is added to any entry without appearing here.

import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";

/**
 * The Bun this loop needs: `process.execve` (the re-exec with the lease carried) is
 * what the floor names. Mirrored by `engines.bun` in runtime/bun/package.json; a
 * test asserts the two agree, since the loop never reads package.json at start.
 */
export const BUN_FLOOR = "1.4.0";

/** The sidecar's sources, relative to runtime/bun/src: the entries' whole import closure. */
export const SIDECAR_SOURCES: readonly string[] = [
  "verbs/escalate.ts", "team-selection.ts", "slices/result-pairs.ts", "routing.ts",
  "agent-state.ts", "bus-archive-index.ts", "bus.ts", "bushome.ts", "clear-command.ts", "clear-fence.ts", "context.ts", "debug-capture.ts",
  "digest-window.ts", "envelope.ts", "error-line.ts", "events.ts", "first-run.ts", "fsatomic.ts", "help.ts", "ids.ts", "index-home.ts", "iterm-viewer.ts", "latest-outbound.ts", "context-census.ts", "context-tokens.ts", "context-window.ts", "payload-fields.ts",
  "launcher/attach-partition.ts", "launcher/catalog-listing.ts", "launcher/catalog-metadata.ts", "launcher/catalog-notices.ts", "launcher/catalog.ts", "launcher/config-args.ts", "launcher/effects.ts",
  "launcher/naming.ts", "launcher/permissions.ts", "launcher/types.ts", "lifecycle-diagnostics.ts", "lifecycle-target.ts", "lossless-json.ts", "native-error.ts", "observe-gather.ts", "observe.ts", "opencode-turn-state.ts", "out-retire.ts", "panelock.ts",
  "pending-reservation.ts", "pyint.ts", "registry-tx.ts", "registry.ts", "remind-job.ts", "remind-lock.ts", "remind.ts", "reset.ts", "seat-adopt.ts", "selector.ts",
  "spawn.ts", "spool-publication.ts", "spool-sidecar.ts", "startup-trace.ts", "team/doctor.ts", "team/purge.ts", "session-store.ts", "session-identity-owner.ts", "team/attach.ts", "team/detach.ts", "team/reset-components.ts", "team/reset.ts", "team/restore.ts", "team/selection.ts", "team/stop.ts", "team/stop-clear.ts", "team/stop-plan.ts", "team/stop-tx.ts", "team-override.ts", "team-stop-queue.ts", "terminal-text.ts", "tmux.ts", "verbose.ts",
  "verbs/peek.ts", "verbs/refresh.ts", "verbs/team.ts", "watch-blocked.ts", "watch-detect.ts", "watch-detectors.ts",
  "watch-evaluate.ts", "watch-evaluator.ts", "watch-lease.ts", "watch-loop.ts", "watch-notice.ts",
  "watch-registry.ts", "watch-run.ts", "watch-sidecar.ts", "watch-tick-run.ts", "watch-tick.ts",
];

/** `git hash-object --no-filters -- <files>`: one blob id per line; null when any file cannot be read. */
export function stampOf(files: readonly string[]): string | null {
  const ids: string[] = [];
  for (const file of files) {
    let bytes: Buffer;
    try { bytes = readFileSync(file); } catch { return null; }
    ids.push(createHash("sha1").update(`blob ${bytes.length}\0`).update(bytes).digest("hex"));
  }
  return ids.join("\n");
}

/**
 * `tap_sidecar_source_refresh` for the Bun loop: null while the stamp holds; on a change,
 * the line and the re-exec (which does not return on success -- a fake that returns
 * makes the loop end with 1, as a failed `exec` did); on an unreadable source, the
 * refusal line and 1. The same two lines the incumbent printed, so the source-refresh
 * smoke keeps its shape.
 */
export function makeRefresh(files: readonly string[], entry: string, stderr: (line: string) => void, reexec: () => void): () => { status: number } | null {
  const initial = stampOf(files);
  if (initial === null) {
    stderr(`tap sidecar: source-unreadable; refusing another iteration: ${entry}`);
    return () => ({ status: 1 });
  }
  return () => {
    const current = stampOf(files);
    if (current === null) {
      stderr(`tap sidecar: source-unreadable; refusing another iteration: ${entry}`);
      return { status: 1 };
    }
    if (current === initial) return null;
    stderr(`tap sidecar: source-changed; re-exec: ${entry}`);
    try {
      reexec();
    } catch (error) {
      stderr(`tap sidecar: re-exec failed: ${(error as Error).message}`);
    }
    return { status: 1 };
  };
}

/** A dotted version at or above the floor (numeric components, missing ones are 0). */
export function atLeast(version: string, floor: string): boolean {
  const v = version.split(".").map(Number), f = floor.split(".").map(Number);
  for (let i = 0; i < Math.max(v.length, f.length); i++) {
    const a = v[i] ?? 0, b = f[i] ?? 0;
    if (Number.isNaN(a) || Number.isNaN(b)) return false;
    if (a !== b) return a > b;
  }
  return true;
}

if (import.meta.main) {
  const argv = process.argv.slice(2);
  if (argv[0] !== "run") {
    process.stderr.write("usage: watch-run.ts run\n");
    process.exit(2);
  }
  const execve = process.execve;
  if (!atLeast(Bun.version, BUN_FLOOR) || typeof execve !== "function") {
    process.stderr.write(`tap watch: the sidecar loop needs bun ${BUN_FLOOR} or newer (process.execve); this is ${Bun.version}\n`);
    process.exit(1);
  }
  const src = import.meta.dir;
  const files = SIDECAR_SOURCES.map(rel => join(src, rel));
  const entry = process.argv[1] ?? join(src, "watch-run.ts");
  const stderr = (line: string) => process.stderr.write(`${line}\n`);
  const refresh = makeRefresh(files, entry, stderr, () => execve(process.execPath, process.argv, process.env));
  // The stamp is consumed BEFORE any stamped module is imported: an unreadable source at
  // start is the refusal line and 1 -- never Bun's own resolution error for a module that
  // is not there (sol-pinnacle-5, #xxxx F1) -- and a source that changed between the two
  // stamps is a re-exec, as at any later boundary. The lease is untouched either way.
  const startup = refresh();
  if (startup) process.exit(startup.status);
  // Loaded only now: the stamp above is of the bytes about to run.
  const { realLoopSeams, runLoop } = await import("./watch-loop");
  const { resolveContext } = await import("./context");
  let status: number;
  try {
    // An unenrolled cwd with no TAP_HOME is `tap watch: <reason>` and 1 in the sidecar's
    // window (the tick's face), never a stack trace.
    const ctx = resolveContext(process.cwd(), process.env);
    // `trap '…; exit 0' INT TERM HUP`: a signal ends the loop with 0 and leaves the lease
    // for health to report. Bash ran the trap after the foreground command; the handler
    // runs when the event loop is free -- after a tick child returns, or mid-sleep.
    for (const signal of ["SIGINT", "SIGTERM", "SIGHUP"] as const) process.on(signal, () => process.exit(0));
    status = await runLoop(realLoopSeams({
      bus: ctx.bus.home,
      scripts: join(dirname(src), "..", "..", "skills", "tap", "scripts"),
      src,
      refresh,
    }));
  } catch (error) {
    process.stderr.write(`tap watch: ${(error as Error).message}\n`);
    status = 1;
  }
  process.exit(status);
}
