import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { resolveBus } from "./bushome";
import { readIndexJson } from "./index-home";
import { latestOutbound } from "./latest-outbound";
import { frontmatterFields } from "./payload-fields";

/** A displayed percentage, against the harness's own denominator. Never infer a token cap. */
export function contextUsedPercent(harness: string, text: string): number | null {
  if (!["codex", "claude", "opencode"].includes(harness)) return null;
  const footer = text.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").trimEnd().split("\n").slice(-6).join("\n");
  const patterns = harness === "codex"
    ? [/\bContext\s+(\d{1,3})%\s+left\b/gi]
    : [/\b\d+(?:\.\d+)?[Kk]\s*\((\d{1,3})%\)/g, /\b(\d{1,3})%\s*\(\d+(?:\.\d+)?[KkMm]?\)\s*ctx\b/gi];
  const values = patterns.flatMap(pattern => [...footer.matchAll(pattern)].map(m => Number(m[1])));
  if (!values.length || new Set(values).size !== 1 || values[0]! > 100) return null;
  return harness === "codex" ? 100 - values[0]! : values[0]!;
}

/** One cross-bus scan for all requested recipients; sidecars survive residency races. */
export function pendingInboundAsks(local: string, index: string, team: string, handles: string[]): Record<string, boolean | null> {
  const result: Record<string, boolean | null> = Object.fromEntries(handles.map(h => [h, false]));
  const unknown = () => { for (const h of handles) if (result[h] === false) result[h] = null; return result; };
  try {
    const buses = new Map([[local, team]]);
    if (existsSync(index)) {
      const doc = readIndexJson(index);
      for (const [name, row] of Object.entries(doc.teams ?? {}) as [string, any][]) {
        if (row.state === "historical") continue;
        if (typeof row.root !== "string") return unknown();
        const bus = resolveBus(row.root, {}).home;
        if (!buses.has(bus)) buses.set(bus, name);
      }
    }
    for (const [bus, sourceTeam] of buses) {
      const ids = new Set<string>();
      for (const folder of ["payloads", "spool"]) {
        const dir = join(bus, folder);
        if (!existsSync(dir)) continue;
        for (const name of readdirSync(dir)) {
          if (/^[_.]/.test(name)) continue;
          if (name.endsWith(".md")) ids.add(name.slice(0, -3));
          else if (folder === "spool" && name.endsWith(".meta.json")) ids.add(name.slice(0, -10));
        }
      }
      for (const id of ids) {
        try { if (statSync(join(bus, "receipts", `${id}.done`)).isFile()) continue; } catch {}
        let fields: Record<string, string> = {};
        for (const folder of ["spool", "payloads", "spool"]) {
          try { fields = frontmatterFields(readFileSync(join(bus, folder, `${id}.md`), "utf8")); } catch { fields = {}; }
          if (Object.keys(fields).length) break;
        }
        if (["id", "from", "to", "reply"].some(key => !fields[key])) return unknown();
        const recipient = fields.to!;
        if (Object.hasOwn(result, recipient) && (fields.to_team || sourceTeam) === team && fields.reply !== "settle-only") result[recipient] = true;
      }
    }
    return result;
  } catch { return unknown(); }
}

export function contextQueueFacts(local: string, index: string, team: string, handles: string[], now = Math.trunc(Date.now() / 1000)) {
  const pending = pendingInboundAsks(local, index, team, handles);
  const out = latestOutbound(join(local, "payloads"), join(local, "spool"), team, now);
  return Object.fromEntries(handles.map(handle => [handle, {
    pending_inbound_ask: pending[handle] ?? null,
    last_outbound_age_seconds: out[handle]?.epoch ? Math.max(0, now - out[handle]!.epoch) : null,
  }]));
}

if (import.meta.main) {
  const [op, ...args] = Bun.argv.slice(2);
  if (op === "gauge") {
    const percent = contextUsedPercent(args[0] ?? "", await Bun.stdin.text());
    if (percent !== null) console.log(percent);
  } else if ((op === "inbox" || op === "inbox-clear") && args.length === 4) {
    const [local, index, team, handle] = args as [string,string,string,string];
    const pending = pendingInboundAsks(local, index, team, [handle])[handle];
    if (op === "inbox-clear") process.exitCode = pending === false ? 0 : 1;
    else console.log(JSON.stringify(pending === null ? null : !pending));
  } else { console.error("tap context: invalid operation"); process.exitCode = 2; }
}
