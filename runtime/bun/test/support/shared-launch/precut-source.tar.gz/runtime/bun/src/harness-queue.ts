// Accepted by the harness queue is transport state, never recipient processing.
import { existsSync, linkSync, readFileSync, rmSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { dirname, join } from "node:path";
import { atomicWrite, jsonObj } from "./fsatomic";
import { envelopeField } from "./envelope";
import { utcStamp, validToken } from "./ids";

function receipt(home: string, id: string, suffix: string): Record<string, string> | null {
  try {
    const value = JSON.parse(readFileSync(join(home, "receipts", `${id}.${suffix}`), "utf8"));
    return value && typeof value === "object" && value.id === id ? value : null;
  } catch { return null; }
}

// First complete observation wins, including concurrent read/replay callers.
function publishOnce(path: string, fields: Record<string, string | undefined>): void {
  const temp = join(dirname(path), `.harness-queue.${randomUUID()}`);
  try {
    atomicWrite(temp, jsonObj(fields) + "\n");
    try { linkSync(temp, path); }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error; }
  } finally { rmSync(temp, { force: true }); }
}

function nonAuthoritativeRead(value: Record<string,string>): boolean {
  return String(value.forced) === "true" || value.reason === "instance_retired";
}
export function hasTerminalQueueReceipt(home: string, id: string): boolean {
  const done = receipt(home,id,"done");
  return !!(receipt(home,id,"sent") || receipt(home,id,"cancelled") || (done && !nonAuthoritativeRead(done)));
}

export function harnessQueued(home: string, id: string): boolean {
  const queued = receipt(home, id, "harness-queued");
  return queued?.status === "queued" && queued.delivery === "harness-queue"
    && !hasTerminalQueueReceipt(home,id);
}

export function completeHarnessQueued(home: string, id: string): void {
  const queued = receipt(home, id, "harness-queued");
  if (!queued || queued.status !== "queued" || queued.delivery !== "harness-queue") return;
  const read = receipt(home, id, "read") ?? receipt(home, id, "done");
  if (!read || !read.by || nonAuthoritativeRead(read)
      || (read.status === "done" && read.via !== "read")) return;
  try {
    publishOnce(join(home, "receipts", `${id}.sent`), {
      ...queued, status: "sent", at: utcStamp(), via: "harness-queue-read",
      read_by: read.by, read_at: read.at, turn: "unconfirmed",
    });
  } catch (error) { console.error(`tap: read observed; queued delivery telemetry unavailable for ${id}: ${error}`); }
}

export function recordHarnessQueued(home: string, id: string, route?: { from: string; to: string; kind: string }): void {
  try {
    const path = join(home, "payloads", `${id}.md`);
    if (receipt(home, id, "cancelled") || (!existsSync(path) && !route)) return;
    // Index-backed digests carry their routing through the delivery input.
    const raw = existsSync(path) ? readFileSync(path, "utf8") : "";
    publishOnce(join(home, "receipts", `${id}.harness-queued`), {
      id, status: "queued", delivery: "harness-queue", at: utcStamp(),
      from: route?.from ?? envelopeField(raw, "from") ?? "",
      to: route?.to ?? envelopeField(raw, "to") ?? "",
      kind: route?.kind ?? envelopeField(raw, "kind") ?? "", turn: "unconfirmed",
    });
    completeHarnessQueued(home, id);
  } catch (error) { console.error(`tap: harness accepted queued input; receipt unavailable for ${id}: ${error}`); }
}

export function harnessQueueMessage(home: string, id: string, json = false, verb = "tap send"): string {
  const fields = { id, status: "queued", delivery: "harness-queue", turn: "unconfirmed", path: join(home, "payloads", `${id}.md`) };
  return json ? jsonObj(fields) + "\n" : `${verb}: queued in harness ${id}; recipient processing unconfirmed\n`;
}

if (import.meta.main) {
  const [action, home, id, json, verb] = Bun.argv.slice(2);
  if (!home || !id || !validToken(id) || !["record", "complete", "print"].includes(action ?? "")) process.exit(2);
  if (action === "record") recordHarnessQueued(home, id);
  else if (action === "complete") completeHarnessQueued(home, id);
  else process.stdout.write(harnessQueueMessage(home, id, json === "1", verb));
}
