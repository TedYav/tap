// An atomic lock holder for the reminders queue and its lease.
//
// WHY THIS EXISTS RATHER THAN `acquirePathLock`. The Python this port replaces
// locked with `os.open(path, O_CREAT|O_RDWR|O_NOFOLLOW)` and then `fcntl.flock`
// on THAT descriptor, so the bytes it locked were provably the bytes it opened.
// `panelock.ts` acquires by handing a PATHNAME to `lockf`/`flock`, which open it
// again themselves and expose no `O_NOFOLLOW` -- so a symlinked lock path is
// followed, and no amount of checking the pathname afterwards can attest which
// inode the helper actually locked.
//
// sol-pinnacle-1 demonstrated that precisely, against a first fix that opened with
// O_NOFOLLOW, recorded dev/ino, let the helper re-open, and re-checked the path:
// rename the real lock aside, point the path at another file, let the helper take
// a REAL hold on that other inode, then restore the original before the re-check.
// The path check passes, the process publishes, and the lock it "holds" is on a
// file nobody else contends -- while the legitimate owner still holds the real one.
// A post-hoc pathname comparison is not a descriptor proof.
//
// So the open and the lock happen on one descriptor, in this process. `flock(2)`
// through FFI is the same primitive `lockf`, Linux `flock` and Python's
// `fcntl.flock` all use, so this stays mutually exclusive with every existing TAP
// holder of the same sidecar (measured: an independent `lockf -t 0` on the same
// path is refused 75 while this holds, and succeeds once released). The kernel
// drops the lock when the process dies, so there is still no staleness horizon,
// no owner record and no reaping -- the property `panelock.ts` was rewritten for.

import { dlopen, FFIType } from "bun:ffi";
import { closeSync, constants, mkdirSync, openSync } from "node:fs";
import { dirname } from "node:path";

const LOCK_EX = 2, LOCK_NB = 4, LOCK_UN = 8;

let flockFn: ((fd: number, op: number) => number) | null | undefined;
function flock(): ((fd: number, op: number) => number) | null {
  if (flockFn !== undefined) return flockFn;
  for (const lib of ["libSystem.B.dylib", "libc.so.6", "libc.so"]) {
    try {
      const { symbols } = dlopen(lib, { flock: { args: [FFIType.i32, FFIType.i32], returns: FFIType.i32 } });
      return (flockFn = symbols.flock as (fd: number, op: number) => number);
    } catch { /* try the next name */ }
  }
  return (flockFn = null);
}

export class SymlinkedLockPath extends Error {}

export interface HeldLock { release(): void }

/**
 * Acquire the lock, or return null if it stays contended to the deadline.
 *
 * Throws `SymlinkedLockPath` when the path is a symlink -- a refusal, never a
 * fallback, because it is a state the incumbent would not operate in. Throws when
 * `flock(2)` cannot be reached at all, for the same fail-closed reason
 * `panelock.ts` refuses without its kernel helper: silently not locking is the
 * defect, not the portability accommodation.
 */
export function acquireNoFollowLock(lockPath: string, timeoutMs: number): HeldLock | null {
  // ORDER IS LOAD-BEARING: open before resolving the primitive. Checking the
  // library first meant that on a host without it, a symlinked path fell back
  // through the reporting reads' unavailable-primitive branch instead of
  // refusing -- so "a symlink refuses everywhere" was documented but not true
  // of that combination (sol-pinnacle-5, M3). Opening first makes the claim
  // unconditional rather than narrowing it to hosts that happen to have FFI.
  mkdirSync(dirname(lockPath), { recursive: true });
  let fd: number;
  try {
    fd = openSync(lockPath, constants.O_CREAT | constants.O_RDWR | constants.O_NOFOLLOW, 0o600);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ELOOP") {
      throw new SymlinkedLockPath(`refusing a symlinked lock path: ${lockPath}`);
    }
    throw error;
  }

  const fn = flock();
  if (!fn) {
    closeSync(fd);
    throw new Error(`reminder locking requires flock(2) via FFI, which is unavailable on this host`);
  }

  const deadline = Date.now() + timeoutMs;
  for (;;) {
    if (fn(fd, LOCK_EX | LOCK_NB) === 0) {
      let released = false;
      return {
        release() {
          if (released) return;
          released = true;
          fn(fd, LOCK_UN);
          closeSync(fd);
        },
      };
    }
    if (Date.now() >= deadline) { closeSync(fd); return null; }
    // Yield without burning a core, the idiom panelock.ts settled on.
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10);
  }
}
