// Checkpoint C groundwork: the CURRENT-authority machine-index writers register
// needs, ported from lib.sh's born-live bootstrap and live enroll arm with the
// checkpoint-C omission contract applied — the pre-flip teams.json route is
// omitted, an old store refuses BEFORE any write, and every document is held in
// the lossless JsonMap representation end to end (never cast to a plain object).
import { spawnSync } from "node:child_process";
import { mkdirSync, readFileSync, realpathSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, join } from "node:path";
import { atomicWrite } from "./fsatomic";
import { validToken } from "./ids";
import { flipMarkerState, globalRegistryPath, legacyTeamsPath, SCHEMA } from "./index-home";
import { acquirePathLock } from "./panelock";
import { pyDumpIndent } from "./lossless-json";
import { isMap, loads, type JsonMap, type JsonValue } from "./watch-detect";

type Env = NodeJS.ProcessEnv;

function envHome(env: Env): string {
  return env.TAP_INDEX_HOME || join(env.HOME || realpathSync("."), ".tap");
}

function nowIso(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
}

function isRegularFile(p: string): boolean {
  try {
    return statSync(p).isFile();
  } catch {
    return false;
  }
}

function isDir(p: string): boolean {
  try {
    return statSync(p).isDirectory();
  } catch {
    return false;
  }
}

function realOrSelf(p: string): string {
  try {
    return realpathSync(p);
  } catch {
    return p;
  }
}

function canonicalRoot(root: string): string | null {
  try {
    return realpathSync(root);
  } catch {
    return null;
  }
}

/** RULE 19 twin of `tap_index_root_indexable`: a root that cannot be resolved
 *  is not-indexable, never indexable. Positive git proof AND top-level. */
export function rootIndexable(root: string, env: Env = process.env): boolean {
  // THE GIT HALF, positively proven: only a canonical top-level git worktree
  // enrolls; a nested path or an unobservable git state is not-indexable.
  const canon = canonicalRoot(root);
  if (!canon) return false;
  const git = spawnSync("git", ["-C", canon, "rev-parse", "--show-toplevel"], { encoding: "utf8" });
  if (git.status !== 0) return false;
  const top = (git.stdout ?? "").trim();
  if (!top) return false;
  if (realOrSelf(top) !== canon) return false;
  // THE TAP_HOME OWNERSHIP HALF: the caller's bus must be one of the two
  // canonical suffixes of THIS root, resolved (compare resolved roots, not
  // spellings — symlinked homes and macOS /tmp -> /private/tmp are entitled).
  // Unknown suffixes, missing homes, failed resolves, and mismatches are
  // not-indexable: a custom bus root never becomes machine-index authority.
  const home = env.TAP_HOME ?? "";
  let homeRoot = "";
  if (home.endsWith("/.tap/bus")) homeRoot = home.slice(0, -"/.tap/bus".length);
  else if (home.endsWith("/tmp/tap")) homeRoot = home.slice(0, -"/tmp/tap".length);
  else return false;
  if (!homeRoot) return false;
  const canonHome = canonicalRoot(homeRoot);
  if (!canonHome) return false;
  return canonHome === canon;
}

/** `tap_index_enroll_preflight` twin: refuse only an UNSET index home whose
 *  canonical root lives under a system temporary directory. */
export function enrollPreflight(root: string, env: Env = process.env): { ok: true } | { ok: false; detail: string } {
  if (env.TAP_INDEX_HOME) return { ok: true };
  const canon = canonicalRoot(root);
  if (!canon) return { ok: true };
  const tempRoots = [tmpdir(), env.TMPDIR, env.TMP, env.TEMP, "/tmp"].filter(
    (t): t is string => typeof t === "string" && t !== "",
  ).map((t) => realOrSelf(t));
  const prefix = tempRoots.find((t) => canon === t || canon.startsWith(t.endsWith("/") ? t : `${t}/`));
  if (prefix) {
    return {
      ok: false,
      detail: "refusing system temporary root; next: set TAP_INDEX_HOME to a sandbox index and retry",
    };
  }
  return { ok: true };
}

export interface OldStoreEvidence {
  kind: "legacy_teams_json" | "bus_registry" | "agents_axis" | "launcher_manifest";
  path: string;
}

/** These detectors classify an absent-marker machine before bootstrap.
 * Current machines may retain historical stores; they are never re-migrated. */
export function legacyAgentsAxisStore(path: string): boolean {
  try {
    const doc = loads(readFileSync(path, "utf8"));
    return isMap(doc) && isMap(doc.get("agents")) && !isMap(doc.get("seats"));
  } catch {
    // An unreadable candidate is not old-store evidence; later stages refuse
    // on their own grounds.
    return false;
  }
}

/** A bus registry already in the complete live schema+team+seats shape is
 * current, not old store evidence — distinct from `legacyAgentsAxisStore`,
 * which only rules out the agents-only axis; this also rules out
 * unclassified/garbage content and a mixed legacy `agents` axis riding
 * alongside `seats` (still refusal-worthy, just not a MIGRATION concern —
 * tap-55gjp: a markerless `{schema, seats, agents}` document must not pass
 * as a kept pre-flip world and hide legacy occupants from registration). */
function currentShapedStore(path: string): boolean {
  try {
    const doc = loads(readFileSync(path, "utf8"));
    return (
      isMap(doc) &&
      doc.get("schema") === SCHEMA &&
      isMap(doc.get("team")) &&
      isMap(doc.get("seats")) &&
      !isMap(doc.get("agents"))
    );
  } catch {
    return false;
  }
}

export function oldStoreEvidence(
  indexHome: string,
  busHome: string,
  actingRegistryPath: string,
  env: Env = process.env,
): OldStoreEvidence[] {
  const found: OldStoreEvidence[] = [];
  const teamsJson = legacyTeamsPath(indexHome);
  if (isRegularFile(teamsJson)) found.push({ kind: "legacy_teams_json", path: teamsJson });
  // An empty bus/acting input must not probe a CWD-relative path.
  if (busHome) {
    const busRegistry = join(busHome, "registry.json");
    if (isRegularFile(busRegistry) && !currentShapedStore(busRegistry)) {
      found.push({ kind: "bus_registry", path: busRegistry });
    }
  }
  if (actingRegistryPath && legacyAgentsAxisStore(actingRegistryPath)) {
    found.push({ kind: "agents_axis", path: actingRegistryPath });
  }
  const home = env.HOME || realpathSync(".");
  const rawManifest = env.TAP_SESSION_MANIFEST || join(home, ".tap", "launcher", "sessions.json");
  const manifest = rawManifest.startsWith("~/") ? join(home, rawManifest.slice(2)) : rawManifest;
  if (isRegularFile(manifest)) found.push({ kind: "launcher_manifest", path: manifest });
  return found;
}

/** Single-site provisional wording; the final vocabulary is a pre-landing gate. */
export function oldStoreRefusalText(path: string): string {
  return (
    `unsupported pre-v0.20 registry: ${path}; preserve this store and use an ` +
    "archived TAP version with tap admin migrate-registry to convert a recoverable copy"
  );
}

export type BornLiveOutcome =
  | { status: "live" }
  | { status: "not_indexable" }
  | { status: "refusal"; refusal: { kind: "invalid_marker" | "old_store" | "operational"; path?: string; detail?: string } };

function emptyGlobalRegistry(): JsonMap {
  const doc: JsonMap = new Map<string, JsonValue>();
  doc.set("schema", SCHEMA);
  doc.set("teams", new Map<string, JsonValue>());
  return doc;
}

function readLossless(path: string): JsonMap | null {
  try {
    const doc = loads(readFileSync(path, "utf8"));
    return isMap(doc) ? doc : null;
  } catch {
    return null;
  }
}

function writeGlobalRegistry(doc: JsonMap, indexHome: string): { ok: true } | { ok: false; detail: string } {
  const gpath = globalRegistryPath(indexHome);
  try {
    mkdirSync(indexHome, { recursive: true });
    atomicWrite(gpath, `${pyDumpIndent(doc, 0)}\n`);
    return { ok: true };
  } catch (e) {
    return { ok: false, detail: `born-live bootstrap could not write ${gpath}: ${(e as Error).message}` };
  }
}

function reclassifiedLive(indexHome: string): boolean {
  return globalRegistryState(indexHome) === "live";
}

function globalRegistryState(indexHome: string): "absent" | "live" | "invalid" {
  return flipMarkerState(indexHome);
}

/** Born-live bootstrap: create the current registry ONLY on a pristine machine.
 *  An old store refuses before any write (checkpoint-C omission contract). */
export function bornLiveBootstrap(root: string, env: Env = process.env): BornLiveOutcome {
  const indexHome = envHome(env);
  const state = globalRegistryState(indexHome);
  if (state === "live") return { status: "live" };
  if (state === "invalid") {
    return { status: "refusal", refusal: { kind: "invalid_marker" } };
  }
  if (!rootIndexable(root, env)) return { status: "not_indexable" };
  // Absent marker: an old store (teams.json, a bus registry) means the machine
  // predates the flip — refuse, name the store, change nothing.
  const evidence = oldStoreEvidence(indexHome, "", "", env);
  if (evidence.length > 0) {
    return { status: "refusal", refusal: { kind: "old_store", path: evidence[0]!.path } };
  }
  try {
    mkdirSync(indexHome, { recursive: true });
    const lock = acquirePathLock(join(indexHome, "teams.json.lock"), Infinity, env);
    if (!lock) return { status: "refusal", refusal: { kind: "operational", detail: "could not lock the machine index" } };
    try {
      // Another first entrant may have published and enrolled while we waited.
      const lockedState = globalRegistryState(indexHome);
      if (lockedState === "live") return { status: "live" };
      if (lockedState !== "absent") return { status: "refusal", refusal: { kind: "invalid_marker" } };
      const lockedEvidence = oldStoreEvidence(indexHome, "", "", env);
      if (lockedEvidence.length > 0) return { status: "refusal", refusal: { kind: "old_store", path: lockedEvidence[0]!.path } };
      const write = writeGlobalRegistry(emptyGlobalRegistry(), indexHome);
      if (!write.ok) return { status: "refusal", refusal: { kind: "operational", detail: write.detail } };
      if (!reclassifiedLive(indexHome)) {
        return {
          status: "refusal",
          refusal: {
            kind: "operational",
            detail: `born-live bootstrap wrote ${globalRegistryPath(indexHome)} but it does not classify live`,
          },
        };
      }
      return { status: "live" };
    } finally { lock.release(); }
  } catch (error) {
    return { status: "refusal", refusal: { kind: "operational", detail: String(error) } };
  }
}

export type EnrollRefusalKind =
  | "temporary_root"
  | "invalid_flip"
  | "enroll_retry"
  | "name_collision"
  | "ambiguous_root"
  | "enroll_failed";

export type EnrollOutcome =
  | { ok: true; skipped?: boolean }
  | { ok: false; kind: EnrollRefusalKind; detail: string };

function teamsEntry(doc: JsonMap): JsonMap | null {
  const teams = doc.get("teams");
  return isMap(teams) ? teams : null;
}

function entryRoot(ent: JsonValue): string {
  return isMap(ent) ? String(ent.get("root") ?? "") : "";
}

function entryState(ent: JsonValue): string {
  return isMap(ent) ? String(ent.get("state") ?? "registered") : "registered";
}

function entryStoredLoc(ent: JsonValue): string {
  return isMap(ent) ? String(ent.get("registry_location") ?? "") : "";
}

function entryEnrolledAt(ent: JsonValue): string {
  return isMap(ent) ? String(ent.get("enrolled_at") ?? "") : "";
}

function asEntry(ent: JsonValue): JsonMap {
  return isMap(ent) ? ent : new Map<string, JsonValue>();
}

/** Match the canonical root against the doc's teams map the way the incumbent
 *  enroll writer does: skip historical entries, match by real path, report
 *  ambiguity rather than picking a winner. */
function enrolledEntryForRoot(
  doc: JsonMap,
  rootReal: string,
): { status: "ok"; name: string; entry: JsonMap; storedLoc: string } | { status: "ambiguous" } | { status: "missing" } {
  const teams = teamsEntry(doc);
  if (!teams) return { status: "missing" };
  const hits: Array<{ name: string; entry: JsonMap; storedLoc: string }> = [];
  for (const [name, ent] of teams.entries()) {
    if (!isMap(ent)) continue;
    if (entryState(ent) === "historical") continue;
    const entRoot = entryRoot(ent);
    if (!entRoot) continue;
    if (realOrSelf(entRoot) !== rootReal) continue;
    hits.push({ name, entry: ent, storedLoc: entryStoredLoc(ent) });
  }
  if (hits.length === 0) return { status: "missing" };
  if (hits.length > 1) return { status: "ambiguous" };
  const hit = hits[0]!;
  return { status: "ok", name: hit.name, entry: hit.entry, storedLoc: hit.storedLoc };
}

/** The live enroll arm of `tap_index_enroll_team`: alias keys and stored
 *  registry_locations are preserved; every refusal is mapped, and an
 *  infrastructure failure never reads as success. */
export function enrollTeam(root: string, registryLocation: string, env: Env = process.env): EnrollOutcome {
  if (!rootIndexable(root, env)) return { ok: true, skipped: true };
  const preflight = enrollPreflight(root, env);
  if (!preflight.ok) return { ok: false, kind: "temporary_root", detail: preflight.detail };
  const name = basename(realOrSelf(root));
  // The incumbent's team-name gate: an invalid basename is silently left
  // unenrolled (skip WITHOUT any index write), never an invalid key.
  if (!validToken(name)) return { ok: true, skipped: true };
  const indexHome = envHome(env);
  mkdirSync(indexHome, { recursive: true });
  const indexLock = acquirePathLock(join(indexHome, "teams.json.lock"), Infinity, env);
  if (!indexLock) {
    return { ok: false, kind: "enroll_failed", detail: "could not acquire the machine-index lock" };
  }
  try {
    let state = globalRegistryState(indexHome);
    if (state === "invalid") {
      return { ok: false, kind: "invalid_flip", detail: "global-registry.json is present but unreadable or wrong schema" };
    }
    const teamsJson = legacyTeamsPath(indexHome);
    if (state === "absent") {
      // BORN LIVE inside enroll: a machine holding NEITHER store is new, not
      // pre-flip. An old store here is the pre-write refusal, again.
      if (isRegularFile(teamsJson)) {
        return { ok: false, kind: "invalid_flip", detail: oldStoreRefusalText(teamsJson) };
      }
      const write = writeGlobalRegistry(emptyGlobalRegistry(), indexHome);
      if (!write.ok) return { ok: false, kind: "enroll_failed", detail: write.detail };
      state = globalRegistryState(indexHome);
      if (state !== "live") {
        return {
          ok: false,
          kind: "invalid_flip",
          detail: `bootstrapped global-registry.json but the flip marker did not classify live (got ${state}) — refusing enroll`,
        };
      }
    }
    if (state !== "live") {
      return { ok: false, kind: "invalid_flip", detail: "global-registry.json is present but unreadable or wrong schema" };
    }
    const gpath = globalRegistryPath(indexHome);
    const globalLock = acquirePathLock(`${gpath}.lock`, Infinity, env);
    if (!globalLock) {
      return { ok: false, kind: "enroll_failed", detail: "could not acquire the global-registry lock" };
    }
    try {
      // Marker can still move between the two locks; recheck again.
      if (globalRegistryState(indexHome) !== "live") {
        return { ok: false, kind: "enroll_retry", detail: "flip marker moved during enroll — retry" };
      }
      const doc = readLossless(gpath) ?? emptyGlobalRegistry();
      if (doc.get("schema") !== SCHEMA) {
        return { ok: false, kind: "invalid_flip", detail: `global-registry schema is not ${SCHEMA}; refusing enroll` };
      }
      if (!doc.has("teams")) doc.set("teams", new Map<string, JsonValue>());
      const teams = doc.get("teams");
      if (!isMap(teams)) {
        return {
          ok: false,
          kind: "invalid_flip",
          detail: "global-registry.json 'teams' is not an object — refusing enroll (would erase prior enrollments)",
        };
      }
      const rootReal = realOrSelf(root);
      // The index stores the CANONICAL root (the incumbent canonicalizes
      // before its writer); symlink/relative spellings never persist.
      const canonical = rootReal;
      const match = enrolledEntryForRoot(doc, rootReal);
      if (match.status === "ambiguous") {
        return { ok: false, kind: "ambiguous_root", detail: `multiple global enrollments for root ${root} — refusing enroll` };
      }
      let enrollKey = name;
      let storedLoc = "";
      if (match.status === "ok") {
        enrollKey = match.name;
        storedLoc = match.storedLoc;
      }
      // The collision arm reads the entry under the CHOSEN key (the incumbent
      // reads teams.get(enroll_key)): a root-match supplies the alias, a
      // missing match still checks the plain-name entry for a different home.
      const ent = teams.has(enrollKey) && isMap(teams.get(enrollKey)) ? teams.get(enrollKey) as JsonMap : new Map<string, JsonValue>();
      const oldRoot = entryRoot(ent);
      if (oldRoot && realOrSelf(oldRoot) !== rootReal && isDir(oldRoot)) {
        return {
          ok: false,
          kind: "name_collision",
          detail:
            `team '${enrollKey}' is already indexed at a different path — run ` +
            `'tap admin retire ${enrollKey}' to de-enroll the stale entry, or rename one team`,
        };
      }
      const useLoc = match.status === "ok" && storedLoc ? storedLoc : registryLocation;
      const next = new Map<string, JsonValue>(ent);
      next.set("root", canonical);
      next.set("registry_location", useLoc);
      next.set("state", ent.get("state") ?? "registered");
      next.set("enrolled_at", ent.get("enrolled_at") ?? nowIso());
      teams.set(enrollKey, next);
      try {
        atomicWrite(gpath, `${pyDumpIndent(doc, 0)}\n`);
      } catch (e) {
        return { ok: false, kind: "enroll_failed", detail: `could not write ${gpath}: ${(e as Error).message}` };
      }
      return { ok: true };
    } finally {
      globalLock.release();
    }
  } finally {
    indexLock.release();
  }
}
