import { AsyncLocalStorage } from "node:async_hooks";
import { randomUUID } from "node:crypto";
import { spawnSync } from "node:child_process";
import { closeSync, constants, existsSync, mkdirSync, openSync, realpathSync, renameSync, statSync, writeSync } from "node:fs";
import { homedir } from "node:os";
import { basename, dirname, join, resolve } from "node:path";
import { ensureAscii } from "./fsatomic";
import { acquireNoFollowLock } from "./remind-lock";

const CAP = 300 * 1024, MAX_LINE = 4096;
const SECRET = /key|token|secret|password|passwd|credential|authorization/i;
const OMIT = new Set(["prompt", "initial_prompt", "argv", "shell_command", "harness_env", "passthrough"]);
const ROW_KEYS = ["status", "status_reason", "delivery", "session", "harness", "harness_session_id",
  "transcript_path", "registered_from_worktree", "instance", "pane", "pane_id", "boot_id", "server_epoch"];
type Fields = Record<string, unknown>;
type Context = { fields: Fields; active: boolean };
const operations = new AsyncLocalStorage<Fields>();
export function withStartupTrace<T>(work: () => T): T {
  return operations.run({ operation_id: randomUUID(), phase: "dispatch" }, work);
}

/** Keep filesystem work in a killable child, including when imported by a launcher. */
function writeNative(op: string, args: Fields, env: NodeJS.ProcessEnv = process.env): void {
  try {
    spawnSync(process.execPath, [resolve(import.meta.dir, "startup-trace.ts")], {
      input: JSON.stringify({ op, args }), cwd: env.HOME,
      env: { ...env, BUN_RUNTIME_TRANSPILER_CACHE_PATH: "0" },
      stdio: ["pipe", "ignore", "ignore"], timeout: 200, killSignal: "SIGKILL",
    });
  } catch { /* Evidence must never change the operation result. */ }
}

export function startupTrace(event: string, fields: Fields = {}, rotate = false): void {
  try {
    const context = operations.getStore();
    if (context) {
      if (event === "launch_start") Object.assign(context, fields);
      if (event === "create_session" || event === "respawn_pane") Object.assign(context, fields, { phase: event });
    }
    writeNative("emit", { event, rotate, fields: { ...context, ...fields } });
  } catch { /* Even caller field serialization is best effort. */ }
}

export function startupTransition(registry: string, handle: string, before: unknown, after: unknown, relaunchable: boolean): void {
  writeNative("transition", { registry, handle, before, after, relaunchable, context: operations.getStore() });
}

/** Diagnostic enablement and pane-output filtering remain with their caller. */
export function startupDiagnostic(event: string, fields: Fields, env: NodeJS.ProcessEnv): void {
  writeNative("diagnostic", { record: { event, ...fields }, rotate: true }, env);
}

function record(value: unknown): Fields {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value as Fields : {};
}

function clean(value: unknown): unknown {
  if (typeof value === "string") {
    let text = value;
    for (const [key, secret] of Object.entries(process.env)) {
      if (SECRET.test(key) && secret) text = text.split(secret).join("<redacted>");
    }
    text = text.replace(/(\b\S*(?:key|token|secret|password)\S*\s*[=:]\s*)\S+/gi, "$1<redacted>");
    return Array.from(text).slice(0, 600).join("");
  }
  if (Array.isArray(value)) return value.slice(0, 20).map(clean);
  if (value !== null && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).filter(([key]) => !OMIT.has(key))
      .map(([key, item]) => [key, SECRET.test(key) ? "<redacted>" : clean(item)]));
  }
  return value;
}

function logPath(): string {
  return join(process.env.TAP_INDEX_HOME || join(homedir(), ".tap"), "logs", "startup.jsonl");
}

function append(path: string, entry: Fields, rotate = false, cap = CAP, rotations = 1): boolean {
  try {
    const data = Buffer.from(ensureAscii(JSON.stringify(clean(entry))).replace(/\x7f/g, "\\u007f") + "\n");
    if (data.length >= MAX_LINE) return false;
    // Establish private directories BEFORE the shared lock helper can create them.
    mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
    const held = acquireNoFollowLock(path + ".lock", 0);
    if (!held) return false;
    try {
      const size = existsSync(path) ? statSync(path).size : 0;
      if (size + data.length > cap) {
        if (!rotate) return false;
        for (let index = rotations - 1; index > 0; index--) {
          if (existsSync(path + `.${index}`)) renameSync(path + `.${index}`, path + `.${index + 1}`);
        }
        renameSync(path, path + ".1");
      }
      const fd = openSync(path, constants.O_WRONLY | constants.O_APPEND | constants.O_CREAT, 0o600);
      try { return writeSync(fd, data) === data.length; }
      finally { closeSync(fd); }
    } finally { held.release(); }
  } catch { return false; }
}

function stamp(): Fields {
  return { schema: 1, timestamp: new Date().toISOString().replace("Z", "000+00:00"), pid: process.pid };
}

function emit(context: Context | null, event: string, fields: Fields = {}, rotate = false): boolean {
  return append(logPath(), { ...stamp(), ...context?.fields, event, ...fields }, rotate);
}

function snapshot(row: unknown): unknown {
  return row !== null && typeof row === "object" && !Array.isArray(row)
    ? clean(Object.fromEntries(ROW_KEYS.filter(key => key in row).map(key => [key, (row as Fields)[key]]))) : null;
}

function socketPath(): string {
  const env = process.env;
  const path = resolve(env.TAP_TMUX_SOCKET_PATH || (!env.TAP_TMUX_SOCKET && env.TMUX ? env.TMUX.split(",")[0]!
    : join(env.TMUX_TMPDIR || "/tmp", `tmux-${process.getuid!()}`, env.TAP_TMUX_SOCKET ?? "default")));
  // os.path.realpath also resolves existing parents of an absent socket.
  let prefix = path;
  const tail: string[] = [];
  for (;;) {
    try { return join(realpathSync(prefix), ...tail); } catch { /* absent tail */ }
    if (dirname(prefix) === prefix) return path;
    tail.unshift(basename(prefix));
    prefix = dirname(prefix);
  }
}

function activate(context: Context | null): void {
  if (context && !context.active) {
    context.active = true;
    emit(context, "launch_start", { socket: socketPath() }, true);
  }
}

/** Python carries this capsule unchanged; all lifecycle decisions live here. */
function dispatch(op: string, args: Fields, context: Context | null): { context: Context | null; value: unknown } {
  let value: unknown = null;
  switch (op) {
    case "begin":
      context = { fields: { operation_id: randomUUID().replaceAll("-", ""), verb: args.verb, cwd: args.cwd,
        phase: "dispatch", boot_id: args.boot_id, target: args.target }, active: false };
      if (!args.deferred) activate(context);
      break;
    case "activate": activate(context); break;
    case "phase":
      if (context) Object.assign(context.fields, { phase: args.name }, record(args.fields));
      break;
    case "finish":
      if (context?.active) emit(context, args.code === 0 ? "launch_complete" : "launch_failure", { exit_code: args.code });
      context = null;
      break;
    case "emit":
      if (typeof args.event !== "string") throw new Error("missing event");
      value = emit(context, args.event, record(args.fields), args.rotate === true);
      break;
    case "command_result": {
      const argv = args.argv;
      if (!context?.active || !Array.isArray(argv) || !argv.length || basename(String(argv[0])) !== "tmux") break;
      const result = record(args.error ?? args.result);
      const code = result.returncode ?? null;
      const command = ["new-session", "new-window", "respawn-pane", "kill-session", "kill-pane", "start-server"].find(cmd => argv.includes(cmd));
      if (code === 0 && command === undefined) break;
      emit(context, "tmux_result", { command: command ?? "observation_or_guard", exit_code: code,
        error: args.error ? result.error_class : null, stderr: result.stderr || "" });
      break;
    }
    case "transition": {
      if (typeof args.registry !== "string" || typeof args.handle !== "string" || !("before" in args) || !("after" in args) || typeof args.relaunchable !== "boolean") throw new Error("invalid transition");
      const fields = { handle: args.handle, before: snapshot(args.before), after: snapshot(args.after), relaunchable: args.relaunchable };
      const extra = record(args.context);
      const { pid, ...journalStamp } = stamp();
      append(join(dirname(String(args.registry)), "registry-events.jsonl"), {
        ...journalStamp, event: "launch_rollback", ...fields, ...context?.fields, ...extra,
      }, false, Infinity);
      emit(context, "launch_rollback", { ...fields, ...extra });
      break;
    }
    case "diagnostic":
      if (typeof record(args.record).event !== "string") throw new Error("missing diagnostic event");
      value = append(join(dirname(logPath()), "launch-debug.jsonl"), { ...stamp(), ...record(args.record) }, args.rotate === true, 5 * 1024 * 1024, 3);
      break;
    default: throw new Error("unknown trace operation");
  }
  return { context, value };
}

if (import.meta.main) {
  try {
    const packet = JSON.parse(await Bun.stdin.text());
    const context: Context | null = packet.context == null ? null : JSON.parse(packet.context);
    if (context !== null && (typeof context !== "object" || Array.isArray(context) || typeof context.active !== "boolean" || !context.fields || Array.isArray(context.fields) || typeof context.fields !== "object")) throw new Error("invalid context");
    const result = dispatch(packet.op, record(packet.args), context);
    process.stdout.write(JSON.stringify({ context: result.context === null ? null : JSON.stringify(result.context), value: result.value }));
  } catch { process.exitCode = 1; /* The caller quietly omits failed evidence. */ }
}
