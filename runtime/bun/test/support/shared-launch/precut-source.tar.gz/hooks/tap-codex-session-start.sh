#!/bin/bash
# tap-codex-session-start.sh — Codex SessionStart adapter for TAP.
#
# Codex (codex-cli >= 0.144) has [[hooks.SessionStart]] with stdout injected as
# developer context. Codex passes `cwd` in the hook JSON, which is the session's
# working directory — for a TAP-launched session that's the worktree root.
# The script resolves the session root from cwd via tap-resolve-session-root
# (NOT from this script's location, which is the TAP checkout, not the active
# worktree), delegates to the shared context script, and wraps the raw context
# once in Codex's JSON shape:
#   {"hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":"..."}}
#
# Self-silencing: outside a TAP repo it emits nothing (accepted by Codex).
#
# It used to also restore a one-shot /self compact focus capsule from this same
# hook. That rail is gone (tap-thgv): the focus now rides the resume ping chained
# behind the staged /compact, which lands on every harness rather than only on
# the one whose SessionStart hook read the file.
# Safety: always exits 0.

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESOLVER="$REPO/skills/tap/scripts/tap-resolve-session-root"

# Read stdin (Codex hook JSON) to extract cwd. The shared script also reads
# stdin for `source`, so we tee it.
INPUT=""
if [ ! -t 0 ]; then
  IFS= read -r -t 1 INPUT || :
fi

# Resolve the session root from the hook JSON's cwd (shared pre-/post-flip rule).
CWD="$(printf '%s' "$INPUT" | sed -n 's/.*"cwd"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)"
[ -n "$CWD" ] || CWD="$PWD"

ROOT="$(python3 -B "$RESOLVER" walk "$CWD" 2>/dev/null || true)"

# The event name must match the hook this invocation is serving, or the harness
# discards the block. Only SessionStart is wired now — the UserPromptSubmit
# roster arm this used to also serve was removed (tap-hx4r).
_EVENT="SessionStart"

OUTPUT=""

# Add TAP's ordinary identity/advisory only when this cwd resolves to a session.
if [ -n "$ROOT" ]; then
  TAP_OUTPUT="$(printf '%s' "$INPUT" | bash "$REPO/hooks/tap-session-context.sh" "$ROOT")"
  TAP_OUTPUT="${TAP_OUTPUT}
TAP skills: \`tap help skill <name>\`; roots ~/.agents/skills, ~/.claude/skills, ~/.codex/skills."
  if [ -n "$TAP_OUTPUT" ]; then
    if [ -n "$OUTPUT" ]; then
      OUTPUT="${OUTPUT}

${TAP_OUTPUT}"
    else
      OUTPUT="$TAP_OUTPUT"
    fi
  fi
fi

# Wrap the combined raw context in Codex's JSON shape.
# jq -Rs handles all string escaping; if jq is absent, fall back to python3
# (already a TAP dependency) so codex injection never silently no-ops.
if [ -n "$OUTPUT" ]; then
  if command -v jq >/dev/null 2>&1; then
    printf '%s' "$OUTPUT" | jq -Rs --arg ev "$_EVENT" '{hookSpecificOutput: {hookEventName: $ev, additionalContext: .}}'
  else
    printf '%s' "$OUTPUT" | TAP_EVENT="$_EVENT" python3 -c 'import json,os,sys; print(json.dumps({"hookSpecificOutput":{"hookEventName":os.environ["TAP_EVENT"],"additionalContext":sys.stdin.read()}}))'
  fi
fi
exit 0
