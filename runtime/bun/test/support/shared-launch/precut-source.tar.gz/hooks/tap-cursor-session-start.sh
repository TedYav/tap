#!/bin/bash
# tap-cursor-session-start.sh — Cursor sessionStart adapter for TAP (tap-o6e).#
# A per-turn UserPromptSubmit roster line was never live here: #xxx added a
# second registration on `beforeSubmitPrompt` and #xxx removed it again,
# because that event discards `additional_context` and so has no field a hook
# can inject through. `install.sh` de-wires any stray leftover, and
# `cursor-beforesubmit-not-wired.test.sh` fails if it is ever re-added. The
# same roster line was later removed from every harness that DID carry it
# (Claude, Codex) as tap-hx4r — see tap-session-context.sh's header.
#
# Cursor (~/.cursor/hooks.json) has sessionStart with stdout JSON:
#   {"additional_context":"...","env":{...}}
# Proven model-visible on the CLI path TAP launches (`cursor-agent --force
# --sandbox disabled --workspace <cwd>`): see
# skills/tap/scripts/smoke/cursor-sessionstart-visibility.recipe.sh.
#
# Cursor's hook JSON supplies workspace_roots (not cwd). PWD at hook time is
# often ~/.cursor — NEVER use PWD when workspace_roots is set (PR-5 class).
# Root resolution (AUTHORITATIVE):
#   1. If workspace_roots is non-empty: walk UP from each listed root via
#      tap-resolve-session-root. If none yield a session root → SILENCE (no
#      PWD fall-through — a non-TAP workspace whose shell cwd sits inside a
#      TAP checkout must not inject that repo's identity).
#   2. If workspace_roots is absent/empty: walk up from PWD (only then).
#   3. No session root → silence.
#
# Delegates body text to hooks/tap-session-context.sh (R8 identity + advisory).
# Self-silencing outside TAP repos. Safety: always exits 0; bounded stdin read.

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESOLVER="$REPO/skills/tap/scripts/tap-resolve-session-root"

INPUT=""
if [ ! -t 0 ]; then
  IFS= read -r -t 1 INPUT || :
fi

ROOT="$(
  TAP_CURSOR_PWD="${PWD:-/}" TAP_RESOLVER="$RESOLVER" python3 -c '
import json, os, subprocess, sys

resolver = os.environ["TAP_RESOLVER"]

def walk(start: str) -> str:
    try:
        out = subprocess.check_output(
            [sys.executable, "-B", resolver, "walk", start],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return ""
    return (out or "").strip()

raw = sys.stdin.read()
roots = []
try:
    data = json.loads(raw) if raw.strip() else {}
    wr = data.get("workspace_roots") or []
    if isinstance(wr, list):
        roots = [r for r in wr if isinstance(r, str) and r.strip()]
except Exception:
    roots = []

if roots:
    for r in roots:
        hit = walk(r)
        if hit:
            print(hit)
            raise SystemExit(0)
    # AUTHORITATIVE: workspace_roots present but no session root → silence.
    raise SystemExit(0)

hit = walk(os.environ.get("TAP_CURSOR_PWD", "/"))
if hit:
    print(hit)
' <<<"$INPUT"
)"

[ -n "$ROOT" ] || exit 0

OUTPUT="$(printf '%s' "$INPUT" | bash "$REPO/hooks/tap-session-context.sh" "$ROOT")"
if [ -n "$OUTPUT" ]; then
  if command -v jq >/dev/null 2>&1; then
    printf '%s' "$OUTPUT" | jq -Rs '{additional_context: .}'
  else
    printf '%s' "$OUTPUT" | python3 -c 'import json,sys; print(json.dumps({"additional_context": sys.stdin.read()}))'
  fi
fi
exit 0
