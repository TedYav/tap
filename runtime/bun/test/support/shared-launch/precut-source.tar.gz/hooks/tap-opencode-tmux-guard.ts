/** Block an unscoped tmux kill-server before OpenCode runs the Bash tool. */
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"
import { spawnSync } from "node:child_process"

function guardTmuxCommand(command: unknown): void {
  // Shell quoting can split "tmux", but every direct spelling still contains x.
  if (typeof command !== "string" || !command.includes("x")) return
  const guard = join(dirname(fileURLToPath(import.meta.url)), "tap-shell-body-guard.py")
  const result = spawnSync(guard, [], {
    input: JSON.stringify({ tool_name: "Bash", tool_input: { command } }),
    encoding: "utf8",
    timeout: 2000,
  })
  if (result.error || result.status !== 0 || !result.stdout) return
  try {
    const output = JSON.parse(result.stdout)
    const decision = output?.hookSpecificOutput
    if (decision?.permissionDecision === "deny") {
      throw new Error(decision.permissionDecisionReason || "Command denied by TAP guard")
    }
  } catch (error) {
    if (error instanceof SyntaxError) return
    throw error
  }
}

export default (async (_context: unknown) => ({
  "tool.execute.before": async (
    input: { tool?: string; sessionID?: string; callID?: string },
    output: { args?: { command?: unknown } },
  ) => {
    if (input.tool === "bash") guardTmuxCommand(output.args?.command)
  },
}))
