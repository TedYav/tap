/**
 * tap-opencode-session-start.ts — OpenCode SessionStart-equivalent ensure-bound
 * adapter (tap-9kvd, closes the tap-35m harness-coverage gap).
 *
 * OpenCode is the ONE supported harness with no SessionStart hook — Claude, Codex,
 * and Cursor share hooks/tap-session-context.sh (see
 * tmp/design/35m-reachability-routability.md §7). So a native OpenCode resume leaves
 * the seat REACHABLE (its pane is alive) but UNROUTABLE (the registry seat is unbound
 * or stale): the tap-35m orphan class, worst for the glm seat. This plugin closes that
 * gap by porting the SHIPPED Part-1 ensure-bound fallback verbatim: a bare, idempotent
 * `tap in` at the SessionStart-equivalent.
 *
 * OpenCode's SessionStart-equivalent is the first lifecycle event that carries this
 * pane's ROOT session id. OpenCode always carries a session id, so every such fire is
 * identity-bearing — the trigger matrix's (§3.1) "resume|clear|startup WITH identity ->
 * bind (identity path)" row. We therefore do not (and cannot) distinguish resume from a
 * fresh start, and do not need to. What we DO honor from the matrix LAW:
 *
 *   - No identity, no bind. `tap in` never runs at plugin init when no session id
 *     exists yet (bare splash), or on any non-session event — the "startup WITHOUT
 *     identity -> NO bind" floor. Attaching to a preminted `--session` IS identity:
 *     session.created/updated do not fire on that path (tap-cpfu), and Bun rewrites
 *     process.argv to the worker script, so init reads `--session` from the kernel
 *     argv of this pid.
 *   - Root sessions only. Sub-agent sessions carry a parentID; binding one would restamp
 *     the pane seat with a child's id, so we skip anything with a parentID.
 *   - Ladder inherited VERBATIM. `tap in` IS the shared register path; this plugin
 *     invents no hook-only reclaim and never attests identity (bind != trust; a
 *     quarantined id stays quarantined — #xxx is not laundered by a SessionStart fire).
 *   - No consent machinery / sticky markers (TED-CALL T1 undecided — bead tap-9kvd).
 *   - Bare `tap in` (registry bind only). The launcher manifest stays backfill-owned for
 *     OpenCode (CONTRACT.md); we do not call the launcher restamp verb.
 *
 * Fail-open always: outside tmux (no pane to bind), outside a TAP repo (no bus), or on
 * any error, every event is a silent no-op. It must never brick an OpenCode start.
 */
import type { Plugin } from "@opencode-ai/plugin"
import { existsSync } from "node:fs"
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"
import { spawnSync } from "node:child_process"

const BIND_TIMEOUT_MS = 5000

// tap-cpfu: preminted `--session` is startup WITH identity; session.created does
// not fire. Bun's process.argv is the worker script (`bun /$bunfs/.../worker.js`),
// not opencode's flags. The sibling helper reads `--session` from argv or from
// this pid's kernel args. Fail CLOSED: missing helper, nonzero, or empty stdout
// means no init bind — the plugin waits for session.created/updated as before.
function sessionIdFromHelper(args: string[]): string {
  try {
    const sibling = join(dirname(fileURLToPath(import.meta.url)), "tap-opencode-session-id")
    if (!existsSync(sibling)) return ""
    const out = spawnSync(sibling, args, { encoding: "utf8", timeout: 2000 })
    if (out.error || out.status !== 0) return ""
    return (out.stdout || "").trim()
  } catch {
    return ""
  }
}

function sessionIdAtInit(): string {
  return (
    sessionIdFromHelper(["from-argv", ...process.argv]) ||
    sessionIdFromHelper(["from-pid", String(process.pid)])
  )
}

function walkUpCheckoutResolver(start: string): string | undefined {
  let dir = start
  for (let i = 0; dir && i < 40; i++) {
    const cand = join(dir, "skills", "tap", "scripts", "tap-resolve-session-root")
    if (existsSync(cand)) return cand
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  return undefined
}

function resolverViaTapOnPath(): string | undefined {
  const out = spawnSync(
    "bash",
    [
      "-c",
      `src=$(command -v tap) || exit 1
while [ -h "$src" ]; do
  dir=$(cd -P "$(dirname "$src")" >/dev/null 2>&1 && pwd)
  src=$(readlink "$src")
  case "$src" in /*) ;; *) src="$dir/$src" ;; esac
done
here=$(cd -P "$(dirname "$src")" >/dev/null 2>&1 && pwd)
echo "$here/../skills/tap/scripts/tap-resolve-session-root"`,
    ],
    { encoding: "utf8", env: process.env },
  )
  if (out.status !== 0) return undefined
  const path = (out.stdout || "").trim()
  return path && existsSync(path) ? path : undefined
}

// Locate tap-resolve-session-root without requiring `tap` on PATH (install bin
// may be off PATH). Order: env override → sibling install wrapper → walk-up
// from session directory hints → optional tap-on-PATH chase. One executable
// authority shared with Claude/Codex/Cursor (fable #xxx round 5 / sol P1).
function resolveSessionRootResolver(...hints: string[]): string | undefined {
  const override = process.env.TAP_SESSION_ROOT_RESOLVER
  if (override && existsSync(override)) return override

  try {
    const sibling = join(dirname(fileURLToPath(import.meta.url)), "tap-resolve-session-root")
    if (existsSync(sibling)) return sibling
  } catch {
    // import.meta.url unavailable — fall through
  }

  for (const hint of hints) {
    if (!hint) continue
    const hit = walkUpCheckoutResolver(hint)
    if (hit) return hit
  }

  return resolverViaTapOnPath()
}

// Walk up from a starting dir via the shared SessionStart ROOT resolver
// (pre-flip bus registry file OR flip-live enrolled stored loc — never mere .tap/).
function findBusRoot(start: string, ...hints: string[]): string | undefined {
  if (!start) return undefined
  const resolver = resolveSessionRootResolver(start, ...hints)
  if (!resolver) return undefined
  // Exec the resolver as a program: install drops a bash wrapper sibling;
  // checkout / tap-on-PATH hits the python shebang script. Never `python3 -B`
  // the wrapper (that treats bash as python and silently fails).
  let out = spawnSync(resolver, ["walk", start], {
    encoding: "utf8",
    env: process.env,
    timeout: 5000,
  })
  if (out.error || (out.status !== null && out.status !== 0)) {
    out = spawnSync("python3", ["-B", resolver, "walk", start], {
      encoding: "utf8",
      env: process.env,
      timeout: 5000,
    })
  }
  if (out.error || (out.status !== null && out.status !== 0)) return undefined
  const root = (out.stdout || "").trim()
  return root || undefined
}

export default (async ({ directory, worktree, $ }) => {
  // Resolved once per process: the bus root, and whether we have a pane to bind. If
  // either is absent, every event is a cheap no-op (self-silence outside TAP / tmux).
  const root =
    findBusRoot(directory, directory, worktree || "") ??
    (worktree ? findBusRoot(worktree, directory, worktree) : undefined)
  const inTmux = !!process.env.TMUX

  const bound = new Set<string>() // root session ids proven bound (exit 0) — steady state
  const inflight = new Set<string>() // binds in progress — guards concurrent duplicates

  async function ensureBound(sessionID: string): Promise<void> {
    if (!sessionID || bound.has(sessionID) || inflight.has(sessionID)) return
    if (!root || !inTmux) return
    inflight.add(sessionID)
    try {
      // BOUNDARY (do not "complete" this into a restamp): this binds ROUTING ONLY —
      // a bare `tap in` that stamps the registry seat. Do NOT add a launcher manifest
      // restamp here. For OpenCode the manifest is backfill-owned (CONTRACT.md); a
      // hook-side restamp would make this a SECOND manifest writer — the two-authorities
      // failure the corpse/identity machinery exists to prevent (fable ruling, tap-9kvd).
      // OpenCode identity capture rides the launcher backfill; this hook only ensures the
      // pane is reachable→routable again after a native resume.
      //
      // `tap in` reads OPENCODE_SESSION_ID for its registry identity capture; the pane is
      // derived from the inherited TMUX/TMUX_PANE. ONE rung: pick an executable by
      // availability (PATH `tap`, else install sibling `plugins/tap` → checkout
      // bin/tap), run it once, return its exit code unchanged. Never retry a
      // semantic nonzero through a second dispatcher, and never look under the
      // team root for a checkout courier (sol #xxx — team root ≠ TAP install).
      const sh = $.env({ ...process.env, OPENCODE_SESSION_ID: sessionID, TAP_SKIP_VERSION_BRIEFING: "1" }).cwd(root).nothrow()
      const bind: Promise<number> = (async () => {
        const which = spawnSync("bash", ["-c", "command -v tap"], {
          encoding: "utf8",
          env: process.env,
        })
        let tapCmd = (which.stdout || "").trim()
        if (!tapCmd) {
          try {
            const sibling = join(dirname(fileURLToPath(import.meta.url)), "tap")
            if (existsSync(sibling)) tapCmd = sibling
          } catch {
            // fall through
          }
        }
        if (!tapCmd) return -1
        // Absolute sibling path: invoke via bash so Bun does not require it on PATH.
        //
        // `< /dev/null` is load-bearing (tap-kq65d root cause, 2026-09-02). Bun's `$`
        // hands the child OUR stdin, which under the launcher is the pane tty; stdout and
        // stderr are already sockets under .quiet(). `bin/tap` execs a Bun runtime, and a
        // Bun (or Node) process snapshots the termios of every std fd that is a tty at
        // startup and writes that snapshot back at exit, whether or not it changed the
        // mode (Node src/node.cc ResetStdio; Bun bun_restore_stdio, oven-sh/bun#29592).
        // Under `--session` OpenCode starts this plugin BEFORE the TUI sets raw mode, so
        // when the bind outlives BIND_TIMEOUT_MS (the race does not cancel it) the tap
        // process exits AFTER the TUI went raw and puts the pane back into cooked mode:
        // the kernel echoes every key, Enter arrives as a newline, and the seat is
        // submit-dead from birth. With no tty on any std fd there is nothing to snapshot.
        const out =
          tapCmd.includes("/")
            ? await sh`bash ${tapCmd} in < /dev/null`.quiet()
            : await sh`tap in < /dev/null`.quiet()
        return out.exitCode
      })().catch(() => -1)
      let timer: ReturnType<typeof setTimeout>
      const guard = new Promise<number>((resolve) => {
        timer = setTimeout(() => resolve(-1), BIND_TIMEOUT_MS)
      })
      const code = await Promise.race([bind, guard]).catch(() => -1)
      clearTimeout(timer!)
      if (code === 0) bound.add(sessionID)
    } finally {
      inflight.delete(sessionID)
    }
  }

  const argvSession = sessionIdAtInit()
  if (argvSession) {
    await ensureBound(argvSession)
  }

  return {
    event: async ({ event }) => {
      try {
        // Only session lifecycle events that carry full info (root/child + directory).
        // session.idle/status carry only a sessionID with no parentID, so we cannot
        // prove they are root — created/updated are the identity-bearing triggers.
        if (event.type === "session.created" || event.type === "session.updated") {
          const info = event.properties.info
          if (!info || info.parentID) return // no info, or a sub-agent session -> skip
          await ensureBound(info.id)
        }
      } catch {
        // fail-open: a bind error must never surface into OpenCode's event loop
      }
    },
  }
}) satisfies Plugin
