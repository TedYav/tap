#!/usr/bin/env python3
"""Best-effort block for unsafe inline bodies and unscoped tmux teardown.

This is not a shell fence: pipeline producers, the `!` and `time` pipeline
prefixes, `coproc`, other wrappers, shell functions, and nested shell constructs
may evade it. A quoted heredoc is the reliable protection. Delimiter parsing
supports ordinary single/double quotes and escapes, not ANSI-C/locale quoting.
Accepted wrapper spellings and option consumption share one grammar table.
Every recognized wrapper consumes its declared options before command resolution.
Commands embedded inside `env -S` or `bash`/`sh -c` strings remain outside this
best-effort parser. So do scripts, functions, indirect command names, and later
tmux commands joined with tmux's escaped semicolon syntax. This is a footgun
brake for direct shell calls, not a shell or process security boundary.
"""

import getopt
import json
import re
import sys


TAP_BODY_FLAGS = {"-m", "--message", "--preview"}
# --append-notes carries prose; --notes-contains filters existing prose and is
# intentionally excluded.
BD_BODY_FLAGS = {"-d", "--description", "--notes", "--append-notes", "--body"}
WRAPPER_GRAMMARS = {
    "command": ("basename", "pVv", (), frozenset(), False),
    "env": (
        "basename",
        "0a:ivC:P:S:u:",
        """argv0= ignore-environment null unset= chdir= split-string=
        block-signal default-signal ignore-signal list-signal-handling
        debug help version""".split(),
        frozenset({"block-signal", "default-signal", "ignore-signal"}),
        True,
    ),
    "bash": (
        "basename",
        "abefhkmnptuvxBCEHPTilrsDc:O:o:",
        """debug debugger dump-po-strings dump-strings help init-file=
        login noediting noprofile norc posix pretty-print rcfile=
        restricted verbose version""".split(),
        frozenset(),
        False,
    ),
    "sh": (
        "basename",
        "abefhkmnptuvxBCHPirsDc:O:o:",
        """debug debugger dump-po-strings dump-strings help init-file=
        login noediting noprofile norc posix protected rcfile= restricted
        verbose version wordexp""".split(),
        frozenset(),
        False,
    ),
}
REDIRECTION = re.compile(
    r"^(?:(?:[0-9]+|\{[A-Za-z_][A-Za-z0-9_]*\})?"
    r"(?:<<<|<<-|<<|<>|<&|>>|>\||>&|<|>)|&>>|&>)(.*)$"
)
SHELL_WORD_BREAK = " \t\n|&;()<>"
REPAIR = (
    "BLOCKED: the composing shell would evaluate backticks or $() in the body "
    "before the recipient sees it. Write the body to a file first, then pass it: "
    "tap send <to> -f <path>. For stdin: tap send <to> -f - <<'EOF' ... EOF "
    "(the quotes on EOF are load-bearing). For bd: --body-file <path>."
)
HEREDOC_BACKTICK_REPAIR = (
    "BLOCKED: backticks in an unquoted heredoc body are evaluated by the "
    "composing shell before the command sees the text. Fix: quote the "
    "delimiter — <<'EOF' instead of <<EOF. If you intended the substitution, "
    "rewrite backticks as $(): `cmd` -> $(cmd)."
)
TMUX_REPAIR = (
    "BLOCKED: an unscoped tmux kill-server can stop the machine's shared "
    "tmux server and immediately suspend every TAP team. Name the private "
    "socket on the kill itself: tmux -L \"$name\" kill-server or "
    "tmux -S \"$path\" kill-server. If you intend to stop the shared server, "
    "run the command yourself outside the agent."
)
TMUX_CLIENT_SHORT_OPTIONS = "2CDhlNuVvc:f:L:S:T:"
TMUX_KILL_SERVER_PREFIX = "kill-ser"


def command_substitution_at(text, index):
    return text.startswith("$(", index) and not text.startswith("$((", index)


def shell_escaped(text, index):
    backslashes = 0
    index -= 1
    while index >= 0 and text[index] == "\\":
        backslashes += 1
        index -= 1
    return backslashes % 2 == 1


def shell_tokens(segment):
    """Return (value, has_unsafe_expansion, raw) tokens for one shell segment."""
    tokens = []
    value = []
    unsafe = False
    raw_start = None
    quote = None
    i = 0

    def finish(end):
        nonlocal value, unsafe, raw_start
        if raw_start is not None:
            tokens.append(("".join(value), unsafe, segment[raw_start:end]))
            value = []
            unsafe = False
            raw_start = None

    while i < len(segment):
        char = segment[i]
        if char == "\\" and quote != "'" and i + 1 < len(segment):
            if raw_start is None:
                raw_start = i
            value.append(segment[i + 1])
            i += 2
            continue
        if char == "#" and quote is None and raw_start is None:
            break
        if char in "'\"":
            if raw_start is None:
                raw_start = i
            if quote is None:
                quote = char
                i += 1
                continue
            if quote == char:
                quote = None
                i += 1
                continue
        if quote is None and char.isspace():
            finish(i)
            i += 1
            continue
        if raw_start is None:
            raw_start = i
        if quote != "'" and (
            char == "`"
            or command_substitution_at(segment, i)
        ):
            unsafe = True
        value.append(char)
        i += 1
    finish(len(segment))
    return tokens


def shell_segments(command):
    """Split on top-level shell separators; expansion openers stay in segment."""
    start = 0
    quote = None
    escaped = False
    for i, char in enumerate(command):
        if escaped:
            escaped = False
            continue
        if char == "\\" and quote != "'":
            escaped = True
            continue
        if char in "'\"":
            if quote is None:
                quote = char
            elif quote == char:
                quote = None
            continue
        redirection_part = (
            char == "&"
            and (
                (i > 0 and command[i - 1] in "<>")
                or (i + 1 < len(command) and command[i + 1] == ">")
            )
        ) or (char == "|" and i > 0 and command[i - 1] == ">")
        if quote is None and char in ";|&\n" and not redirection_part:
            yield command[start:i]
            start = i + 1
    yield command[start:]


def heredoc_word(source, position):
    """Read a complete delimiter word with Bash quote removal, on raw source.

    Backslash-LF joins physical lines; it does not quote the delimiter. Inside
    double quotes a backslash before an ordinary character remains literal.
    ANSI-C/locale quoting is outside this small scanner's supported grammar.
    """
    while position < len(source):
        if source.startswith("\\\n", position):
            position += 2
        elif source[position] in " \t":
            position += 1
        else:
            break
    start = position
    value = []
    quote = None
    quoted = False
    while position < len(source):
        char = source[position]
        if quote is None and char in SHELL_WORD_BREAK:
            break
        if quote is None and source.startswith(("$'", '$"'), position):
            return None
        if char == "\\" and quote != "'" and position + 1 < len(source):
            following = source[position + 1]
            if following == "\n":
                position += 2
                continue
            if quote is None or following in '$`"\\':
                value.append(following)
                quoted = True
                position += 2
                continue
        if char in "'\"" and quote is None:
            quote = char
            quoted = True
        elif char == quote:
            quote = None
        else:
            value.append(char)
        position += 1
    if position == start or quote is not None:
        return None
    return position, "".join(value), quoted


def arithmetic_end(source, position):
    """Skip balanced arithmetic parentheses; callers establish shell context."""
    depth = 0
    quote = None
    while position < len(source):
        char = source[position]
        if char == "\\" and quote != "'":
            position += 2
            continue
        if quote:
            if char == quote:
                quote = None
        elif char in "'\"":
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return position + 1
        position += 1
    return position


def heredoc_bodies(source):
    """Yield (start, end, quoted, tap/bd consumer, logical body) in shell order.

    Both guard scans share opener discovery and body boundaries. Only LF ends
    a shell line: CR and Unicode separators are ordinary delimiter/body bytes.
    This remains a direct-command scanner, not a recursive Bash parser.
    """
    position = segment_start = 0
    quote = None
    pending = []
    segment_openers = []
    while position < len(source):
        char = source[position]
        if char == "\\" and quote != "'":
            position += 2
            continue
        if quote:
            if char == quote:
                quote = None
            position += 1
            continue
        if char in "'\"":
            quote = char
            position += 1
            continue
        if char == "#" and (position == 0 or source[position - 1] in SHELL_WORD_BREAK):
            newline = source.find("\n", position)
            position = len(source) if newline < 0 else newline
            continue
        if source.startswith("$((", position):
            position = arithmetic_end(source, position + 1)
            continue
        if source.startswith("((", position):
            position = arithmetic_end(source, position)
            continue
        if source.startswith("<<", position) and not source.startswith("<<<", position) and (
            position == 0 or source[position - 1] != "<"
        ):
            word_start = position + 2
            strip_tabs = source.startswith("-", word_start)
            parsed = heredoc_word(source, word_start + int(strip_tabs))
            if parsed is not None:
                position, delimiter, quoted = parsed
                segment_openers.append((strip_tabs, delimiter, quoted))
                continue
        redirection_part = (char == "&" and (
            (position > 0 and source[position - 1] in "<>")
            or source[position + 1:position + 2] == ">"
        )) or (char == "|" and position > 0 and source[position - 1] == ">")
        if char in ";|&\n" and not redirection_part:
            tool_index, _ = tool_and_flags(shell_tokens(source[segment_start:position]))
            pending.extend((*opener, tool_index is not None) for opener in segment_openers)
            segment_openers = []
            position += 1
            segment_start = position
            if char == "\n":
                for strip_tabs, delimiter, quoted, is_tap_bd in pending:
                    start = position
                    body = []
                    while position < len(source):
                        logical = ""
                        while True:
                            end = source.find("\n", position)
                            end = len(source) if end < 0 else end
                            line = source[position:end]
                            position = min(end + 1, len(source))
                            trailing = len(line) - len(line.rstrip("\\"))
                            if not quoted and trailing % 2 and end < len(source):
                                logical += line[:-1]
                                continue
                            logical += line
                            break
                        closing = logical.lstrip("\t") if strip_tabs else logical
                        if closing == delimiter:
                            break
                        body.append(logical)
                    yield start, position, quoted, is_tap_bd, "\n".join(body)
                pending = []
                segment_start = position
            continue
        position += 1


def without_heredoc_bodies(command, *, quoted_only):
    """Remove recognized heredoc data before scanning executable segments."""
    pieces = []
    cursor = 0
    for start, end, quoted, _, _ in heredoc_bodies(command):
        if quoted or not quoted_only:
            pieces.append(command[cursor:start])
            cursor = end
    pieces.append(command[cursor:])
    return "".join(pieces).removesuffix("\n")


def command_words(tokens):
    """Return original-index words after Bash removes redirections."""
    words = []
    skip_target = False
    for index, (value, _, raw) in enumerate(tokens):
        if skip_target:
            skip_target = False
            continue
        match = REDIRECTION.fullmatch(raw)
        if match:
            skip_target = not bool(match.group(1))
            continue
        words.append((index, value))
    return words


def consume_wrapper_options(values, grammar):
    """Return the number of option words consumed, or None on bad syntax."""
    short_options, long_options, optional_long, bare_dash_is_i = grammar
    normalized = list(values)
    if bare_dash_is_i and normalized[:1] == ["-"]:
        normalized[0] = "-i"
    for index, value in enumerate(normalized):
        if not value.startswith("--") or "=" not in value:
            continue
        name = value[2:].split("=", 1)[0]
        if name in optional_long:
            normalized[index] = f"--{name}"
    try:
        _, remaining = getopt.getopt(normalized, short_options, long_options)
    except getopt.GetoptError:
        return None
    return len(values) - len(remaining)


def wrapper_and_grammar(value):
    """Return a recognized wrapper and its grammar, or (None, None)."""
    for wrapper, entry in WRAPPER_GRAMMARS.items():
        spelling, *grammar = entry
        if value == wrapper or (
            spelling == "basename" and value.endswith(f"/{wrapper}")
        ):
            return wrapper, grammar
    return None, None


# Bash names a simple command from the first word left after assignment words and
# redirections are removed. Resolve against that grammar, then handle only the
# named wrappers below. Tools such as gh still fail open.
# Long flags match exactly or with "=" downstream. gh's -b/--body versus
# -F/--body-file is a new collision row if gh is added, not a reason to restore
# prefix matching for long flags.
def resolved_command(tokens):
    """Return (words, values, command word index), or a missing index."""
    words = command_words(tokens)
    values = [value for _, value in words]
    index = 0
    while index < len(values) and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", values[index]):
        index += 1
    while index < len(values):
        wrapper, grammar = wrapper_and_grammar(values[index])
        if wrapper is None:
            break
        index += 1
        consumed = consume_wrapper_options(values[index:], grammar)
        if consumed is None:
            return words, values, None
        index += consumed
        if wrapper == "env":
            while index < len(values) and re.fullmatch(
                r"[A-Za-z_][A-Za-z0-9_]*=.*", values[index]
            ):
                index += 1
    if index >= len(values):
        return words, values, None
    return words, values, index


def tool_and_flags(tokens):
    """Return (tool index, body flags) for a TAP or bd command."""
    words, values, index = resolved_command(tokens)
    if index is None:
        return None, None
    value = values[index]
    if value == "tap" or value.endswith("/tap") or value.endswith("/tap.sh"):
        if index + 1 < len(values) and values[index + 1] in {"send", "reply", "escalate", "assign"}:
            return words[index][0], TAP_BODY_FLAGS
    if value == "bd" or value.endswith("/bd"):
        return words[index][0], BD_BODY_FLAGS
    return None, None


def tmux_kill_server_is_unsafe(command):
    """Whether a direct tmux kill-server lacks a preceding -L/-S socket pin."""
    command = without_heredoc_bodies(command, quoted_only=False).replace("\\\n", "")
    for segment in shell_segments(command):
        tokens = shell_tokens(segment)
        _, values, index = resolved_command(tokens)
        if index is None:
            continue
        executable = values[index]
        if executable != "tmux" and not executable.endswith("/tmux"):
            continue
        argv = values[index + 1 :]
        try:
            options, remaining = getopt.getopt(argv, TMUX_CLIENT_SHORT_OPTIONS)
        except getopt.GetoptError:
            # The exact direct form stays protected when a new client option is
            # added, but ambiguous free text remains outside this best-effort parser.
            if "kill-server" in argv:
                return True
            continue
        if not remaining:
            continue
        verb = remaining[0]
        if not verb.startswith(TMUX_KILL_SERVER_PREFIX) or not "kill-server".startswith(verb):
            continue
        if any(option in {"-L", "-S"} for option, _ in options):
            continue
        return True
    return False


def inline_body_is_unsafe(command):
    for segment in shell_segments(without_heredoc_bodies(command, quoted_only=True)):
        tokens = shell_tokens(segment)
        tool_index, flags = tool_and_flags(tokens)
        if tool_index is None:
            continue
        argv = [value for index, value in command_words(tokens) if index > tool_index]
        if flags is TAP_BODY_FLAGS and any(
            flag in ("-f", "--body-file") and path == "-" for flag, path in zip(argv, argv[1:])
        ):
            for index, (_, unsafe, raw) in enumerate(tokens):
                here_string = re.match(r"^(?:0)?<<<", raw)
                if here_string is None:
                    continue
                if raw[here_string.end():]:
                    if unsafe:
                        return True
                elif index + 1 < len(tokens) and tokens[index + 1][1]:
                    return True
        for index in range(tool_index + 1, len(tokens)):
            value, token_unsafe, _ = tokens[index]
            if token_unsafe and any(
                value.startswith(flag)
                if len(flag) == 2
                else value == flag or value.startswith(flag + "=")
                for flag in flags
            ):
                return True
            if value not in flags:
                continue
            for body_value, body_unsafe, _ in tokens[index + 1 :]:
                if body_unsafe:
                    return True
                if body_value.startswith("-"):
                    break
    return False


def _unquoted_heredoc_check(command):
    """Check expansion sites only in the shared scanner's unquoted bodies."""
    for _, _, quoted, is_tap_bd, body in heredoc_bodies(command):
        if quoted:
            continue
        for position, char in enumerate(body):
            if shell_escaped(body, position):
                continue
            if char == "`":
                return "backtick"
            if is_tap_bd and command_substitution_at(body, position):
                return "dollar_paren"
    return False


def unquoted_heredoc_is_unsafe(command):
    """Boolean interface for callers and Bun parity tests."""
    return bool(_unquoted_heredoc_check(command))


def command_and_harness(payload):
    """Normalize Claude/Codex, Cursor, and Antigravity shell hook payloads."""
    if payload.get("tool_name") == "Bash":
        tool_input = payload.get("tool_input")
        if isinstance(tool_input, dict) and isinstance(tool_input.get("command"), str):
            return tool_input["command"], "pretool"
    if isinstance(payload.get("command"), str):
        return payload["command"], "cursor"
    tool_call = payload.get("toolCall")
    if isinstance(tool_call, dict) and tool_call.get("name") == "run_command":
        arguments = tool_call.get("args")
        if isinstance(arguments, dict) and isinstance(arguments.get("CommandLine"), str):
            return arguments["CommandLine"], "antigravity"
    return None, None


def write_denial(harness, reason):
    if harness == "cursor":
        output = {
            "permission": "deny",
            "user_message": reason,
            "agent_message": reason,
        }
    elif harness == "antigravity":
        output = {"decision": "deny", "reason": reason}
    else:
        output = {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": reason,
            }
        }
    json.dump(output, sys.stdout)
    sys.stdout.write("\n")


def main():
    try:
        payload = json.load(sys.stdin)
    except (json.JSONDecodeError, OSError, TypeError):
        return 0
    if not isinstance(payload, dict):
        return 0
    command, harness = command_and_harness(payload)
    if command is None:
        return 0
    if tmux_kill_server_is_unsafe(command):
        write_denial(harness, TMUX_REPAIR)
        return 0
    if inline_body_is_unsafe(command):
        write_denial(harness, REPAIR)
        return 0
    heredoc_kind = _unquoted_heredoc_check(command)
    if heredoc_kind == "backtick":
        write_denial(harness, HEREDOC_BACKTICK_REPAIR)
        return 0
    if heredoc_kind == "dollar_paren":
        write_denial(harness, REPAIR)
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
