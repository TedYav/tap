#!/bin/bash
# tap-advisory.sh — Claude SessionStart adapter for TAP.#
# Removed (tap-hx4r): this adapter used to also be registered a second time on
# UserPromptSubmit, with TAP_HOOK_MODE=roster, to push a one-line team roster
# on every prompt. Deleted per panel ruling — see tap-session-context.sh's
# header for why.
#
# Resolves the bus root and delegates to the shared context script
# (tap-session-context.sh) which resolves the pane to a registered seat,
# injects the identity block (R8), prints the advisory, and runs the
# ensure-bound fallback on resume|clear.
#
# Root resolution order (NEVER the script's own checkout — it may be a
# different worktree than the session, injecting the wrong bus's identity):
#   1. CLAUDE_PROJECT_DIR (Claude's authoritative project root) — if SET,
#      it is AUTHORITATIVE: session-root there or SILENCE, no fall-through.
#   2. If CLAUDE_PROJECT_DIR is unset/empty: walk up from PWD.
#   3. No session root → silence (not a TAP repo).
#
# Discovery is ONE executable (tap-resolve-session-root) shared by every
# harness adapter — see registry_v20.is_session_root / walk_up_session_root.
#
# INSTALLED USER-LEVEL, BY ABSOLUTE PATH, DELIBERATELY (panel ruling, tap-pkoq,
# 2026-08-14). TAP is machine-scoped: a seat can be launched in any tree, so a
# repo-level opt-in would strand every seat working outside a repo that opted in.
# The cost is that this file runs on EVERY Claude session on the machine, which
# is why the silence branch above is load-bearing rather than tidy: outside a TAP
# session root it prints nothing and exits 0 in well under a tenth of a second.
# The absolute path pins it to the primary checkout on purpose — a $CLAUDE_PROJECT_DIR
# spelling would resolve to whichever worktree a session happens to sit in, and a
# disposable worktree can be reaped mid-session.
#
# This repo's own .claude/settings.json used to register the same hook a SECOND
# time, so every SessionStart here registered the seat twice ~0.3s apart. That is
# not cosmetic: the second registration used to launder the first one's identity
# verdict (tap-wolp). The entry is deleted; the writer-side fix lives in
# tap-register.sh so a single hook is safe too.
#
# Raw stdout → Claude reads it as SessionStart developer context.
# Safety: always exits 0; no blocking commands; under one screenful of output.

REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESOLVER="$REPO/skills/tap/scripts/tap-resolve-session-root"

ROOT=""

# 1. CLAUDE_PROJECT_DIR — Claude's authoritative project root. When set, it is
#    AUTHORITATIVE: session-root there or SILENCE — never fall through to a
#    PWD walk-up that would inject a different repo's bus.
if [ -n "${CLAUDE_PROJECT_DIR:-}" ]; then
  ROOT="$(python3 -B "$RESOLVER" exact "$CLAUDE_PROJECT_DIR" 2>/dev/null || true)"
  [ -n "$ROOT" ] || exit 0
fi

# 2. CLAUDE_PROJECT_DIR unset/empty: walk up from PWD.
if [ -z "$ROOT" ]; then
  ROOT="$(python3 -B "$RESOLVER" walk "$PWD" 2>/dev/null || true)"
fi

# 3. No session root — silence (not a TAP repo).
[ -n "$ROOT" ] || exit 0

exec bash "$REPO/hooks/tap-session-context.sh" "$ROOT"
