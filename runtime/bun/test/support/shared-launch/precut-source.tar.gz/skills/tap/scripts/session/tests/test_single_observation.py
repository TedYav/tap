"""tap-ua9l: single-observation capture (finding 7) + one generation-aware
pane-identity predicate (finding 5).

FINDING 7 (TOCTOU). Writers observed the pane facts and the server generation
in SEPARATE tmux calls, so a server rebirth landing between the two stamped
PRIOR-generation ids with the CURRENT generation — minting a false-current row
during the exact event the guard exists to handle, and defeating every reader
guard downstream (the same laundering shape as finding 3, but through time
instead of through rows). The fix is two-part and both parts are required:
capture the ids and the generation in ONE tmux record, so every id carries the
generation it was observed under; then REVALIDATE immediately before the
commit, refusing to persist when the generation moved in between.

FINDING 5 (direct equality). Three sites in tap-register.sh compared a STORED
pane id against a freshly observed one with `==`, which is exactly the
comparison a rebirth defeats: after a restart the stored id resolves on the new
server and compares equal to itself. `seat_corpse.same_pane_identity` is the
one shared replacement.

NO-WIDENING (the required per-site lens, after the reasoning failed three times
in tranche A): the predicate narrows and never widens. On an UNSTAMPED row or
an unobservable generation it is plain string equality — byte-identical to the
pre-wave comparison — and the address fallback is OPT-IN, so the two sites that
never had one do not acquire one.
"""

import importlib.machinery
import importlib.util
import json
import os
import pathlib
import tempfile
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_loader(
        name, importlib.machinery.SourceFileLoader(name, str(ROOT / f"{name}.py"))
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


launcher = _load("launcher")
seat_corpse = _load("seat_corpse")

OLD = "srv:111:1000"
NEW = "srv:222:2000"


def observed(pane, pane_id, epoch=NEW, command="claude"):
    """A PaneFacts as a LIVE observation produces one — ids and the generation
    they were observed under, from the same record."""
    return launcher.PaneFacts(
        pane=pane, pane_id=pane_id, command=command, path="/repo", server_epoch=epoch
    )


class SingleObservationRecordTests(unittest.TestCase):
    """The capture must be ONE tmux record, not two probes stitched together."""

    def _run_capture(self, stdout, returncode=0):
        calls = []

        class Result:
            pass

        def fake_run(argv, **kwargs):
            calls.append(argv)
            result = Result()
            result.returncode = returncode
            result.stdout = stdout
            return result

        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("TAP_SERVER_EPOCH", None)
            with mock.patch.object(launcher.subprocess, "run", fake_run):
                facts = launcher.tmux_pane_facts("repo/scout:0.0")
        return facts, calls

    def test_ids_and_generation_come_from_one_tmux_record(self):
        facts, calls = self._run_capture(
            "repo/scout:0.0\t%9\tclaude\t222:2000\t0\t4242\t/repo\n"
        )
        self.assertEqual(len(calls), 1, "capture must be a single tmux observation")
        fmt = calls[0][-1]
        self.assertIn("#{pane_id}", fmt)
        self.assertIn("#{pid}", fmt)
        self.assertIn("#{start_time}", fmt)
        self.assertIn("#{pane_dead}", fmt)
        self.assertIn("#{pane_pid}", fmt)
        self.assertEqual(facts.pane_id, "%9")
        self.assertEqual(facts.server_epoch, NEW)
        self.assertFalse(facts.dead)
        self.assertEqual(facts.pane_pid, 4242)

    def test_unparsable_generation_field_leaves_the_observation_unstamped(self):
        facts, _ = self._run_capture(
            "repo/scout:0.0\t%9\tclaude\tnonsense\t0\t4242\t/repo\n"
        )
        self.assertEqual(facts.pane_id, "%9")
        self.assertEqual(facts.server_epoch, "")

    def test_a_path_containing_a_tab_cannot_shift_the_generation_field(self):
        # The generation rides BEFORE the free-form path for exactly this
        # reason: the path is the only field that can contain a tab.
        facts, _ = self._run_capture(
            "repo/scout:0.0\t%9\tclaude\t222:2000\t0\t4242\t/repo/od\tdity\n"
        )
        self.assertEqual(facts.server_epoch, NEW)
        self.assertEqual(facts.path, "/repo/od\tdity")


class RevalidateBeforeCommitTests(unittest.TestCase):
    """A rebirth between capture and write must ABORT the write, never stamp
    the current generation onto ids captured under the prior one."""

    def _registry(self, tmp, entry_overrides=None, status="active"):
        root = pathlib.Path(tmp)
        registry = root / ".tap" / "bus" / "registry.json"
        registry.parent.mkdir(parents=True)
        entry = {
            "status": status, "status_reason": "", "delivery": "pane",
            "session": f"{root.name}/scout", "harness": "claude",
            "pane": f"{root.name}/scout:0.1", "pane_id": "%5",
            "pane_current_command": "claude",
            "registered_from_worktree": str(root), "registered_at": "old",
            "server_epoch": OLD,
        }
        entry.update(entry_overrides or {})
        registry.write_text(json.dumps({
            "team": {"name": root.name, "worktree_root": str(root)},
            "agents": {"scout": entry},
        }) + "\n")
        record = launcher.SessionRecord(
            name=f"{root.name}/scout", harness="claude", cwd=str(root),
            base=root.name, tag="scout", index=1,
        )
        return root, registry, record

    def test_stamp_refuses_when_the_generation_moved_since_the_observation(self):
        entry = {"pane_id": "%9"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
            with self.assertRaises(launcher.LauncherError):
                launcher.stamp_server_epoch(entry, OLD)
        self.assertNotIn("server_epoch", entry)

    def test_stamp_records_the_observed_generation_not_a_second_probe(self):
        entry = {"pane_id": "%9"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
            launcher.stamp_server_epoch(entry, NEW)
        self.assertEqual(entry["server_epoch"], NEW)

    def test_an_unstamped_observation_leaves_the_row_unstamped(self):
        # An observation that could not carry its own generation proves
        # nothing; stamping a separately probed one is the laundering this
        # bead exists to stop.
        entry = {"pane_id": "%9", "server_epoch": OLD}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
            launcher.stamp_server_epoch(entry, "")
        self.assertNotIn("server_epoch", entry)

    def test_bind_reserved_handle_aborts_instead_of_persisting_stale_ids(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            (root / ".tap" / "bus").mkdir(parents=True)
            record = launcher.SessionRecord(
                name=f"{root.name}/scout", harness="claude", cwd=str(root),
                base=root.name, tag="scout", index=1,
            )
            registry = root / ".tap" / "bus" / "registry.json"
            with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": OLD}):
                launcher.claim_pending_handle(record)
            before = registry.read_text()
            # The pane was observed under OLD; the server is reborn as NEW
            # before the bind lands.
            with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
                with self.assertRaises(launcher.LauncherError):
                    launcher.bind_reserved_handle(
                        record, observed(f"{root.name}/scout:0.0", "%9", epoch=OLD)
                    )
            self.assertEqual(registry.read_text(), before, "no write may land")




class SamePaneIdentityTests(unittest.TestCase):
    """The ONE predicate replacing three direct `==` comparisons."""

    def test_a_prior_generation_row_is_not_the_pane_we_just_observed(self):
        row = {"pane_id": "%5", "server_epoch": OLD}
        self.assertFalse(seat_corpse.same_pane_identity(row, "%5", NEW))

    def test_a_current_generation_row_with_the_same_id_is_the_same_pane(self):
        row = {"pane_id": "%5", "server_epoch": NEW}
        self.assertTrue(seat_corpse.same_pane_identity(row, "%5", NEW))

    def test_an_unstamped_row_keeps_plain_string_equality(self):
        # NO WIDENING and no new refusal: pre-wave rows compare exactly as
        # they did before this pass.
        row = {"pane_id": "%5"}
        self.assertTrue(seat_corpse.same_pane_identity(row, "%5", NEW))
        self.assertFalse(seat_corpse.same_pane_identity(row, "%6", NEW))

    def test_an_unobservable_generation_keeps_plain_string_equality(self):
        row = {"pane_id": "%5", "server_epoch": OLD}
        self.assertTrue(seat_corpse.same_pane_identity(row, "%5", None))

    def test_absent_or_empty_ids_never_match(self):
        self.assertFalse(seat_corpse.same_pane_identity({}, "%5", NEW))
        self.assertFalse(seat_corpse.same_pane_identity({"pane_id": ""}, "", NEW))
        self.assertFalse(seat_corpse.same_pane_identity({"pane_id": "%5"}, "", NEW))
        self.assertFalse(seat_corpse.same_pane_identity(None, "%5", NEW))
        self.assertFalse(seat_corpse.same_pane_identity("nonsense", "%5", NEW))

    def test_the_address_fallback_is_opt_in(self):
        # Two of the three call sites never had an address arm; passing no
        # observed address must not give them one.
        row = {"pane": "repo/scout:0.1"}
        self.assertFalse(seat_corpse.same_pane_identity(row, "%5", NEW))
        self.assertTrue(
            seat_corpse.same_pane_identity(row, "%5", NEW, observed_pane="repo/scout:0.1")
        )

    def test_the_address_fallback_never_overrides_a_stored_id(self):
        row = {"pane_id": "%5", "pane": "repo/scout:0.1"}
        self.assertFalse(
            seat_corpse.same_pane_identity(row, "%6", NEW, observed_pane="repo/scout:0.1")
        )

    def test_the_address_fallback_refuses_a_prior_generation_row(self):
        row = {"pane": "repo/scout:0.1", "server_epoch": OLD}
        self.assertFalse(
            seat_corpse.same_pane_identity(row, "%5", NEW, observed_pane="repo/scout:0.1")
        )


if __name__ == "__main__":
    unittest.main()
