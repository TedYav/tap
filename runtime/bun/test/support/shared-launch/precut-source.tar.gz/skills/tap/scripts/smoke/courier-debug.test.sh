#!/usr/bin/env bash
# Same-process on/off and the actual composer gate, through smoke-all --only.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
export TAP_HOME="$WORK/bus" TAP_INDEX_HOME="$WORK/index"
mkdir -p "$TAP_HOME/payloads" "$TAP_HOME/receipts" "$TAP_INDEX_HOME/debug" "$WORK/run"
. "$ROOT/skills/tap/scripts/lib.sh"
fail() { echo "courier-debug: $*" >&2; exit 1; }
id=peer-20260906T080000Z-aaaaaaaaaaaa
sentinel="[[TAP v0.23 ask tap/other-20260906T080000Z-bbbbbbbbbbbb]]"
# Model hard application wraps; -J cannot join these continuation rows.
printf '› [[TAP v0.23 ask\n  tap/%s]]\n\ngpt-6-astra high · Context 90%% left · /tmp\n' "$id" > "$WORK/frame"
tmux() { [ "$1" = capture-pane ] || return 1; cat "$WORK/frame"; }
check_failure() {
  local rc=0
  tap_submit_enter_ready %fixture codex "$sentinel" "$id" 0 0 2>"$WORK/error" || rc=$?
  [ "$rc" = 5 ] || fail "matcher outcome changed: $rc"
  grep -q 'composer changed before Enter' "$WORK/error" || fail 'lost refusal reason'
}
check_failure
[ ! -e "$TAP_HOME/receipts/$id.submit-unverified.frame" ] || fail 'off retained a frame'
printf '{"id":"test-run","directory":"%s"}\n' "$WORK/run" > "$TAP_INDEX_HOME/debug/enabled.json"
check_failure
# Shell command substitution strips trailing newline; preserve exactly its input.
python3 - "$WORK/frame" "$TAP_HOME/receipts/$id.submit-unverified.frame" <<'PY'
from pathlib import Path
import sys
assert Path(sys.argv[2]).read_bytes() == Path(sys.argv[1]).read_bytes().rstrip(b'\n')
PY
printf 'later unrelated frame' > "$WORK/frame"
check_failure
! grep -q 'later unrelated' "$TAP_HOME/receipts/$id.submit-unverified.frame" || fail 'overwrote first failure'
rm "$TAP_INDEX_HOME/debug/enabled.json"
id=peer-20260906T080000Z-bbbbbbbbbbbb
check_failure
[ ! -e "$TAP_HOME/receipts/$id.submit-unverified.frame" ] || fail 'existing helper ignored off'
# Ordinary v0.23 now uses the transition loop; exercise its own decision hook.
printf '{"id":"test-run","directory":"%s"}\n' "$WORK/run" > "$TAP_INDEX_HOME/debug/enabled.json"
id=peer-20260906T080000Z-eeeeeeeeeeee
printf '› [[TAP v0.23 ask\n  tap/%s]]\n\ngpt-6-astra high · Context 90%% left · /tmp\n' "$id" > "$WORK/frame"
tap_submit_identity_guard() { return 0; }
tmux() {
  case "$1" in
    capture-pane) cat "$WORK/frame" ;;
    display-message) case "${@: -1}" in *pane_in_mode*) echo 0 ;; *pane_width*) echo 69 ;; *) return 1 ;; esac ;;
    send-keys) fail 'mismatched composer received a key' ;;
    *) return 1 ;;
  esac
}
rc=0
tap_submit_transition_verify %fixture codex "$id" 0 id '' '' '' 5 '' '' "$sentinel" 2>"$WORK/transition-error" || rc=$?
[ "$rc" = 5 ] || fail 'transition mismatch outcome changed'
python3 - "$TAP_HOME/receipts/$id.submit-unverified.json" <<'PYFRAME'
import json,sys
assert json.load(open(sys.argv[1]))['stage']=='transition-changed'
PYFRAME
# Exercise the real spool diagnostic wrapper for both individual and digest ids.
printf '{"id":"test-run","directory":"%s"}\n' "$WORK/run" > "$TAP_INDEX_HOME/debug/enabled.json"
tap_submit_verify() { echo 'first observation' >&2; echo 'composer changed before Enter; Enter withheld' >&2; TAP_SUBMIT_DEFER_REASON=no-prompt; return 5; }
for members in '' 'member-one member-two'; do
  id="peer-20260906T080000Z-$( [ -z "$members" ] && printf cccccccccccc || printf dddddddddddd )"
  rc=0
  tap_debug_spool_submit "$TAP_HOME/payloads/$id.md" "$id" "$members" %fixture codex wire "$id" || rc=$?
  [ "$rc" = 5 ] || fail 'instrumentation changed spool outcome'
  [ "$TAP_SUBMIT_DEFER_REASON" = no-prompt ] || fail 'subshell lost submit state'
  python3 - "$TAP_HOME/payloads/$id.debug.attempts" "$id" "$members" <<'PY'
import json,sys
r=json.loads(open(sys.argv[1]).read())
assert r['payload_id']==sys.argv[2] and r['effect']=='possible' and r['disposition']=='stop-ambiguous'
assert 'composer changed before Enter' in r['detail'] and 'first observation\n' in r['detail']
assert not sys.argv[3] or 'members=['+sys.argv[3]+']' in r['detail']
PY
done
# Root-safe write failure: parent is a regular file, not chmod-based permissions.
printf blocked > "$WORK/not-directory"
rc=0
tap_debug_spool_submit "$WORK/not-directory/$id.md" "$id" '' %fixture codex wire "$id" 2>/dev/null || rc=$?
[ "$rc" = 5 ] || fail 'diagnostic failure changed delivery outcome'
echo 'courier-debug: original frame, first failure, live on/off, spool detail, digest members, write failure PASS'
