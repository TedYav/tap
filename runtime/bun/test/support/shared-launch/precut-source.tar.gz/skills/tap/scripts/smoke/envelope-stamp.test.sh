#!/usr/bin/env bash
# envelope-stamp.test.sh — the courier-truly-mints contract (CONTRACT §send / F9).
# A writer MAY omit id/path; tap_stamp_envelope fills the canonical payload's
# routing fields (id/from/to/kind/path) BEFORE validation, preserving every other
# frontmatter key + the body. Routing args are authoritative over writer copies.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP_HOME="$(mktemp -d)"; export TAP_HOME
trap 'rm -rf "$TAP_HOME"' EXIT
. "$ROOT/skills/tap/scripts/lib.sh"
tap_ensure_dirs

# --- 1. id-less + path-less source → minted, stamped, valid -------------------
cat > "$TAP_HOME/src.md" <<'EOF'
---
from: codex
to: claude
kind: review
re: tap-0024
---

body line — must survive the stamp.
EOF
ID="$(tap_mint_id codex)"; CANON="$(tap_payload_path "$ID")"
tap_stamp_envelope "$TAP_HOME/src.md" "$ID" codex claude review "$CANON" | tap_atomic_write "$CANON"
tap_validate_envelope "$CANON" || { echo "envelope-stamp: id-less source did not validate after stamp" >&2; exit 1; }
[ "$(tap_envelope_field "$CANON" id)"   = "$ID" ]      || { echo "envelope-stamp: id not stamped" >&2; exit 1; }
[ "$(tap_envelope_field "$CANON" path)" = "$CANON" ]   || { echo "envelope-stamp: path not stamped" >&2; exit 1; }
[ "$(tap_envelope_field "$CANON" re)"   = "tap-0024" ] || { echo "envelope-stamp: re: not preserved" >&2; exit 1; }
grep -q 'body line — must survive' "$CANON"            || { echo "envelope-stamp: body lost" >&2; exit 1; }

# --- 2. routing args win over writer-supplied copies --------------------------
cat > "$TAP_HOME/src2.md" <<'EOF'
---
id: writer-guess
from: someone
to: wrong-target
kind: discuss
re: keep-me
---

body two.
EOF
ID2="$(tap_mint_id fusion)"; CANON2="$(tap_payload_path "$ID2")"
tap_stamp_envelope "$TAP_HOME/src2.md" "$ID2" fusion claude review "$CANON2" | tap_atomic_write "$CANON2"
[ "$(tap_envelope_field "$CANON2" id)"   = "$ID2" ]    || { echo "envelope-stamp: arg id did not win" >&2; exit 1; }
[ "$(tap_envelope_field "$CANON2" to)"   = "claude" ]  || { echo "envelope-stamp: arg to did not win" >&2; exit 1; }
[ "$(tap_envelope_field "$CANON2" from)" = "fusion" ]  || { echo "envelope-stamp: arg from did not win" >&2; exit 1; }
[ "$(tap_envelope_field "$CANON2" kind)" = "review" ]  || { echo "envelope-stamp: arg kind did not win" >&2; exit 1; }
[ "$(tap_envelope_field "$CANON2" re)"   = "keep-me" ] || { echo "envelope-stamp: re: not preserved (case 2)" >&2; exit 1; }
# exactly one id line (no duplicate left behind)
[ "$(grep -c '^id:' "$CANON2")" = "1" ]                || { echo "envelope-stamp: duplicate id line" >&2; exit 1; }

# --- 3. a source with no opening frontmatter fence fails loud -----------------
# Subshell-wrap: tap_stamp_envelope dies via `exit` (fail-loud), so contain it in
# a ( ) so the `exit` returns to this `if` instead of killing the smoke.
printf 'no frontmatter here\n' > "$TAP_HOME/bad.md"
if ( tap_stamp_envelope "$TAP_HOME/bad.md" x y z k p ) >/dev/null 2>&1; then
  echo "envelope-stamp: missing-fence source did not fail closed" >&2; exit 1
fi

echo "envelope-stamp: ok"
