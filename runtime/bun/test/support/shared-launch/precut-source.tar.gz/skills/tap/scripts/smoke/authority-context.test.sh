#!/usr/bin/env bash
# authority-context.test.sh — immutable post-flip ACTS authority (#3/#4/#5/#6).
#
# One sample carries: marker, registry path, bus path, v0.20-bound.
# Rules: only absent→legacy; invalid REFUSES; bus≠dirname(registry) for
# team-registry.json; bound place never re-samples into unbound.
set -euo pipefail
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP="$ROOT/scripts/tap.sh"
# shellcheck source=helpers.sh
. "$ROOT/skills/tap/scripts/smoke/helpers.sh"
# shellcheck source=../lib.sh
. "$ROOT/skills/tap/scripts/lib.sh"

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
export TAP_INDEX_HOME="$WORK/index"
mkdir -p "$TAP_INDEX_HOME"

fail() { echo "authority-context: $*" >&2; exit 1; }

# --- (1) bus home from canonical team-registry.json (#4) ---------------------
REG="$WORK/team/.tap/team-registry.json"
mkdir -p "$(dirname "$REG")/bus"
: >"$REG"
bus="$(tap_bus_home_for_registry "$REG")" \
  || fail "tap_bus_home_for_registry failed for team-registry.json"
[ "$bus" = "$WORK/team/.tap/bus" ] \
  || fail "expected $WORK/team/.tap/bus, got $bus"
# dirname alone would wrongly yield .tap — the fence bug.
[ "$(dirname "$REG")" != "$bus" ] \
  || fail "bus must not equal dirname(team-registry.json)"
echo "authority-context: (1) bus home from team-registry.json: ok"

# --- (2) invalid flip: cancel refuses, does not treat seat as gone (#3/#5) ---
ALPHA="$WORK/alpha"
mkdir -p "$ALPHA/.tap/bus/payloads" "$ALPHA/.tap/bus/receipts" "$ALPHA/.tap/bus/archive"
cat >"$ALPHA/.tap/bus/registry.json" <<'JSON'
{
  "team": {"name": "alpha", "created_at": "t", "created_by": "t", "repo_root": "/tmp"},
  "agents": {
    "alice": {
      "status": "active", "delivery": "poll", "harness": "claude",
      "registered_at": "t", "pane": "", "pane_id": ""
    }
  }
}
JSON
# Invalid marker (wrong schema) — fail closed, never legacy.
printf '%s\n' '{"schema":"9.99"}' >"$TAP_INDEX_HOME/global-registry.json"
export TAP_HOME="$ALPHA/.tap/bus"
export TAP_REGISTRY="$TAP_HOME/registry.json"
# Stage an outstanding payload alice→bob shape for cancel-by-sender.
ID="alice-20260729T000000Z-authctx0001"
cat >"$TAP_HOME/payloads/${ID}.md" <<EOF
---
id: $ID
from: alice
to: bob
kind: discuss
path: $TAP_HOME/payloads/${ID}.md
reply: settle-only
---
body
EOF
: >"$TAP_HOME/receipts/${ID}.sent"
err="$(mktemp)"
set +e
out="$("$TAP" cancel "$ID" --by alice --team alpha 2>"$err")"
rc=$?
set -e
[ "$rc" -ne 0 ] || fail "cancel must refuse under invalid flip (rc=0); out=$out err=$(cat "$err")"
grep -Eiq 'invalid_flip|invalid' "$err" \
  || fail "cancel stderr must name invalid_flip; got: $(cat "$err")"
# Must NOT have archived/terminal-cancelled as if bob were gone.
[ ! -f "$TAP_HOME/receipts/${ID}.done" ] \
  || fail "cancel must not write .done when authority is invalid"
[ -f "$TAP_HOME/payloads/${ID}.md" ] \
  || fail "cancel must not archive payload when authority is invalid"
echo "authority-context: (2) invalid flip cancel refuses: ok"

# --- (3) authority context fields under live flip ---------------------------
rm -f "$TAP_INDEX_HOME/global-registry.json"
python3 -B - "$TAP_INDEX_HOME" "$ALPHA" <<'PY'
import json, pathlib, sys
idx, alpha = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
reg = alpha / ".tap" / "team-registry.json"
reg.parent.mkdir(parents=True, exist_ok=True)
reg.write_text(json.dumps({
  "schema": "0.20",
  "team": {"name": "alpha"},
  "seats": {"alice": {
    "status": "active", "delivery": "poll", "harness": "claude",
    "instance": "alice|I1", "registered_at": "t",
  }},
  "agents": {},
}) + "\n")
(idx / "global-registry.json").write_text(json.dumps({
  "schema": "0.20",
  "teams": {"alpha": {
    "root": str(alpha),
    "registry_location": str(reg),
  }},
}) + "\n")
PY
export TAP_HOME="$ALPHA/.tap/bus"
# shellcheck disable=SC2034
TAP_REGISTRY="$TAP_HOME/registry.json"
tap_authority_context alpha || fail "live authority_context failed: ${TAP_AUTH_STATUS:-}"
[ "$TAP_AUTH_MARKER" = "live" ] || fail "marker=$TAP_AUTH_MARKER"
[ "$TAP_AUTH_V20_BOUND" = "1" ] || fail "V20_BOUND=$TAP_AUTH_V20_BOUND"
[ "$TAP_AUTH_REGISTRY" = "$ALPHA/.tap/team-registry.json" ] \
  || fail "registry=$TAP_AUTH_REGISTRY"
[ "$TAP_AUTH_BUS" = "$ALPHA/.tap/bus" ] || fail "bus=$TAP_AUTH_BUS"
echo "authority-context: (3) live context fields: ok"

# --- (4) failed marker read REFUSES — does not select legacy (#amendment) -----
# Bidirectional: neuter import via empty TAP_SCRIPTS_DIR, then restore.
EMPTY_SCRIPTS="$WORK/empty-scripts"
mkdir -p "$EMPTY_SCRIPTS"
set +e
TAP_SCRIPTS_DIR="$EMPTY_SCRIPTS" tap_authority_context alpha 2>/dev/null
rc=$?
broken_status="${TAP_AUTH_STATUS:-}"
broken_bound="${TAP_AUTH_V20_BOUND:-}"
broken_reg="${TAP_AUTH_REGISTRY:-}"
set -e
[ "$rc" -ne 0 ] || fail "broken marker read must refuse (got rc=0 status=$broken_status)"
[ "$broken_status" = "marker_unreadable" ] \
  || fail "expected marker_unreadable, got '$broken_status'"
[ "$broken_bound" = "0" ] || fail "broken read must not set V20_BOUND"
[ -z "$broken_reg" ] || fail "broken read must not select ambient registry (got $broken_reg)"
# Discriminator: same fixture with a working read still PASSES.
tap_authority_context alpha || fail "working marker read must pass after broken case"
[ "$TAP_AUTH_STATUS" = "ok" ] || fail "working read status=$TAP_AUTH_STATUS"
[ "$TAP_AUTH_V20_BOUND" = "1" ] || fail "working read V20_BOUND=$TAP_AUTH_V20_BOUND"
echo "authority-context: (4) marker_unreadable refuses + working pass: ok"

# --- (5) tap_resolve_team_target: unreadable marker refuses legacy (#sibling) -
set +e
TAP_SCRIPTS_DIR="$EMPTY_SCRIPTS" tap_resolve_team_target "beta/bob" 2>/dev/null
# function returns 0 with TAP_TT_SCOPE set; check scope
broken_scope="${TAP_TT_SCOPE:-}"
broken_detail="${TAP_TT_DETAIL:-}"
set -e
[ "$broken_scope" = "invalid_flip" ] \
  || fail "resolve_team_target must set invalid_flip on unreadable marker (got $broken_scope)"
[[ "$broken_detail" == *"could not read"* ]] \
  || fail "resolve detail must name unreadable marker; got: $broken_detail"
# Discriminator: working read resolves live remote (or unknown_team if beta absent —
# here alpha is enrolled; use alpha/alice for a live local pass).
tap_resolve_team_target "alpha/alice" || fail "working resolve failed"
[ "$TAP_TT_SCOPE" = "local" ] || fail "working resolve scope=$TAP_TT_SCOPE (want local)"
echo "authority-context: (5) resolve_team_target unreadable refuse + working pass: ok"

# --- (6) send remote-prelude case: unreadable refuses before BOUND=0 (#sibling)
# Exercise via tap_authority_context path already covered; pin the send-side
# marker case by sourcing the same exhaustive pattern used at tap-send.sh:576.
_send_marker=""
set +e
_send_marker="$(TAP_SCRIPTS_DIR="$EMPTY_SCRIPTS" tap_registry_v20_state 2>/dev/null)" || _send_marker=""
set -e
case "$_send_marker" in
  live|absent|invalid) fail "broken scripts dir must not yield in-band marker '$_send_marker'" ;;
  *) ;; # empty/unknown — the refuse arm
esac
# Working read still yields an in-band state.
_ok_marker="$(tap_registry_v20_state)" || fail "working tap_registry_v20_state failed"
case "$_ok_marker" in
  live|absent|invalid) ;;
  *) fail "working marker read yielded '$_ok_marker'" ;;
esac
[ "$_ok_marker" = "live" ] || fail "fixture should be live, got $_ok_marker"
echo "authority-context: (6) send-prelude marker exhaustive + working live: ok"

# --- (7) absent-foreign: worktree-scan fallback (e929 hole) -------------------
# Pre-flip + empty teams.json + sibling worktree basename — must resolve, not
# unreachable. Live arm must NOT gain this fallback (covered by (3)/(4)).
rm -f "$TAP_INDEX_HOME/global-registry.json" "$TAP_INDEX_HOME/teams.json"
SENDER="$WORK/SenderTeam"
REMOTE="$WORK/RemoteTeam"
rm -rf "$SENDER" "$REMOTE"
git init -q "$SENDER"
git -C "$SENDER" config user.email tap1@example.net
git -C "$SENDER" config user.name "TAP Smoke"
touch "$SENDER/r"; git -C "$SENDER" add r; git -C "$SENDER" commit -q -m init
git -C "$SENDER" worktree add -q "$REMOTE" -b remote-team
mkdir -p "$SENDER/tmp/tap" "$REMOTE/tmp/tap"
printf '%s\n' '{"team":{"name":"SenderTeam"},"agents":{"alice":{"status":"active","delivery":"poll","harness":"claude","registered_at":"t","pane":"","pane_id":""}}}' \
  >"$SENDER/tmp/tap/registry.json"
printf '%s\n' '{"team":{"name":"RemoteTeam"},"agents":{"bob":{"status":"active","delivery":"poll","harness":"codex","registered_at":"t","pane":"","pane_id":""}}}' \
  >"$REMOTE/tmp/tap/registry.json"
export TAP_HOME="$SENDER/tmp/tap"
export TAP_REGISTRY="$TAP_HOME/registry.json"
[ "$(tap_registry_v20_state)" = "absent" ] || fail "(7) marker must be absent"
tap_authority_context RemoteTeam || fail "(7) absent-foreign worktree resolve failed: ${TAP_AUTH_STATUS:-}"
[ "$TAP_AUTH_STATUS" = "ok" ] || fail "(7) status=$TAP_AUTH_STATUS"
want_reg="$(cd "$(dirname "$REMOTE/tmp/tap/registry.json")" && pwd -P)/registry.json"
got_reg="$(cd "$(dirname "$TAP_AUTH_REGISTRY")" && pwd -P)/registry.json"
[ "$got_reg" = "$want_reg" ] || fail "(7) registry=$TAP_AUTH_REGISTRY (want $want_reg)"
[ "$TAP_AUTH_V20_BOUND" = "0" ] || fail "(7) pre-flip must leave V20_BOUND=0"
echo "authority-context: (7) absent-foreign worktree fallback: ok"

# --- (8) live + unusable stored loc + sibling worktree MUST refuse ------------
# Pins "live never worktree-scans" against a future control-flow regression.
# Construction today returns before the fallback; without this case a refactor
# that fell through would silently use the sibling and pass (7)-shaped fixtures.
# CONTRACT deletes worktree-scan at the flip — a live arm that rescues via
# worktree would be a post-flip contract violation.
#
# Reuse SenderTeam/RemoteTeam worktrees from (7). Enroll RemoteTeam live with a
# stored registry_location that does not exist; sibling basename would rescue
# under absent. Live must stay unreachable and must not bind the worktree path.
python3 -B - "$TAP_INDEX_HOME" "$REMOTE" <<'PY'
import json, pathlib, sys
idx, remote = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
missing = remote / ".tap" / "missing-team-registry.json"
(idx / "global-registry.json").write_text(json.dumps({
  "schema": "0.20",
  "teams": {"RemoteTeam": {
    "root": str(remote),
    "registry_location": str(missing),
    "state": "registered",
  }},
}) + "\n")
PY
[ "$(tap_registry_v20_state)" = "live" ] || fail "(8) marker must be live"
# Sibling worktree still has a usable legacy registry — the forbidden rescue.
[ -f "$REMOTE/tmp/tap/registry.json" ] || fail "(8) fixture needs worktree registry present"
set +e
tap_authority_context RemoteTeam
rc=$?
live_status="${TAP_AUTH_STATUS:-}"
live_reg="${TAP_AUTH_REGISTRY:-}"
live_bound="${TAP_AUTH_V20_BOUND:-}"
set -e
[ "$rc" -ne 0 ] || fail "(8) live+unusable loc must refuse (got ok reg=$live_reg)"
[ "$live_status" = "unreachable" ] \
  || fail "(8) expected unreachable, got '$live_status'"
[ -z "$live_reg" ] || fail "(8) must not bind any registry (got $live_reg)"
[ "$live_bound" = "0" ] || fail "(8) must not set V20_BOUND on refuse"
# Discriminator: absent still rescues the same sibling (control did not rot).
rm -f "$TAP_INDEX_HOME/global-registry.json"
[ "$(tap_registry_v20_state)" = "absent" ] || fail "(8) discriminator marker absent"
tap_authority_context RemoteTeam || fail "(8) discriminator absent resolve failed"
want_reg="$(cd "$(dirname "$REMOTE/tmp/tap/registry.json")" && pwd -P)/registry.json"
got_reg="$(cd "$(dirname "$TAP_AUTH_REGISTRY")" && pwd -P)/registry.json"
[ "$got_reg" = "$want_reg" ] || fail "(8) discriminator registry=$TAP_AUTH_REGISTRY"
echo "authority-context: (8) live refuses worktree rescue: ok"

echo "authority-context: ok"
