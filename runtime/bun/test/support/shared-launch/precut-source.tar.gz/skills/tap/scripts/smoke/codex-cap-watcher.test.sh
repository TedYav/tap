#!/usr/bin/env bash
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# codex-cap-watcher.test.sh — gate entry for the Codex cap watcher's controls.
#
# The controls themselves are bun tests (runtime/bun/test/codex-cap.test.ts):
# the watcher is bun, and its pure core — meter parsing, the threshold
# boundary, the exit-6 discriminator, suppression — is only testable in the
# language it is written in. This wrapper exists so the suite names the watcher
# explicitly rather than smuggling it into bun-router.test.sh, which is about
# the router.
#
# WHY IT IS SAFE TO RUN HERE: the watcher's fire path switches the operator's
# live Codex credential and replaces the process behind every Codex seat on the
# machine. Every arm hands it stub paths for all four collaborators, so no arm
# can reach a real binary — the paths are parameters, not PATH lookups. This
# wrapper additionally pins HOME into the sandbox, so even a future arm that
# forgot --state/--log would write there and not into the operator's ~/.tap.
#
# AND THE INSTRUMENT IS NOT EXEMPT FROM ITS OWN RULE. An earlier version of the
# cleanup below printed "refusing to remove" and then exited with the INCOMING
# status, which on a green body is 0 — so ownership uncertainty and a failed
# removal could both leave residue while this control reported success. That is
# the same success-shaped-signal class the watcher itself is written against,
# living inside the check meant to catch it. `reap_scratch` now turns either
# anomaly into a nonzero exit, and arms (2a)-(2d) drive both anomalies causally
# rather than trusting the branch to be right by reading.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
RUNTIME="$ROOT/runtime/bun"
BUN="${TAP_SMOKE_BUN:-$(command -v bun 2>/dev/null || true)}"
LSOF="${LSOF:-$(command -v lsof 2>/dev/null || printf '%s' /usr/sbin/lsof)}"
WORK="$(mktemp -d)"

# Prints the status the run should exit with. An incoming 0 becomes 1 on any
# cleanup anomaly; an incoming nonzero is preserved, because the body's own
# failure is the more informative one.
reap_scratch() {
  local dir="$1" status="$2" lsof_rc rm_rc
  if [ ! -e "$dir" ]; then printf '%s' "$status"; return 0; fi
  set +e
  "$LSOF" +D "$dir" >/dev/null 2>&1
  lsof_rc=$?
  set -e
  if [ "$lsof_rc" -ne 1 ]; then
    echo "codex-cap-watcher: refusing to remove scratch without an unowned lsof result ($lsof_rc): $dir" >&2
    [ "$status" -ne 0 ] || status=1
    printf '%s' "$status"; return 0
  fi
  set +e
  rm -rf "$dir"
  rm_rc=$?
  set -e
  if [ "$rm_rc" -ne 0 ] || [ -e "$dir" ]; then
    echo "codex-cap-watcher: scratch removal did not take (rm exit $rm_rc): $dir" >&2
    [ "$status" -ne 0 ] || status=1
  fi
  printf '%s' "$status"
}

cleanup() {
  local status=$? final
  final="$(reap_scratch "$WORK" "$status")"
  exit "${final:-1}"
}
trap cleanup EXIT

[ -n "$BUN" ] && [ -x "$BUN" ] || { echo "codex-cap-watcher: Bun executable unavailable" >&2; exit 1; }

mkdir -p "$WORK/home"
# --timeout 60000 replaces bun test's default 5000ms cap. Hang arms wait a 1s
# child bound plus collaborator overhead (~1.9s quiet); under suite load the
# old 5s budget raced the harness, which SIGKILLed the watcher (rc=-1, not
# exit 1) and could leave a TERM-resistant perl behind. The hang fixture is
# `sleep 30`, so a 30s cap equals the mutant overrun and can still win the
# race before elapsed/residue/finally. 60s sits above that duration. The file
# also calls setDefaultTimeout(60000); naming it here is the gate-path pin.
env -u TMUX -u TMUX_PANE -u TAP_SELF HOME="$WORK/home" \
  "$BUN" test test/codex-cap.test.ts --timeout 60000 --cwd "$RUNTIME" >"$WORK/out" 2>&1 || {
    cat "$WORK/out" >&2
    echo "codex-cap-watcher: controls failed" >&2
    exit 1
  }
tail -4 "$WORK/out"

# The suite must not have written into the operator's real watcher state: the
# arms pass explicit paths, and this is the positive check that they all did.
[ ! -e "$WORK/user/.tap/watchers" ] \
  || { echo "codex-cap-watcher: an arm wrote into HOME/.tap/watchers — a default path escaped its stub" >&2; exit 1; }
echo "codex-cap-watcher: (1) controls green, no arm escaped into HOME: ok"

# (2) The cleanup predicate, driven through both anomalies. Each arm runs
# reap_scratch in a subshell so the forced condition — a shadowing `rm`, a
# stub `lsof` — cannot leak into the real cleanup that follows.
P="$WORK/reap"; mkdir -p "$P"
printf '#!/usr/bin/env bash\nexit 0\n' >"$P/lsof-uncertain"; chmod +x "$P/lsof-uncertain"

mkdir -p "$P/a"
got="$( rm() { return 1; }; reap_scratch "$P/a" 0 2>/dev/null )"
[ "$got" = "1" ] && [ -d "$P/a" ] \
  || { echo "codex-cap-watcher: (2a) a failed removal reported '$got' and should report 1 while retaining $P/a" >&2; exit 1; }
echo "codex-cap-watcher: (2a) a removal that does not take turns a green body red: ok"

mkdir -p "$P/b"
got="$( LSOF="$P/lsof-uncertain"; reap_scratch "$P/b" 0 2>/dev/null )"
[ "$got" = "1" ] && [ -d "$P/b" ] \
  || { echo "codex-cap-watcher: (2b) an unproven-ownership refusal reported '$got' and should report 1 while retaining $P/b" >&2; exit 1; }
echo "codex-cap-watcher: (2b) refusing on unproven ownership turns a green body red: ok"

mkdir -p "$P/c"
got="$(reap_scratch "$P/c" 0)"
[ "$got" = "0" ] && [ ! -e "$P/c" ] \
  || { echo "codex-cap-watcher: (2c) a clean reap reported '$got' or left $P/c behind" >&2; exit 1; }
echo "codex-cap-watcher: (2c) a clean reap keeps a green body green and removes the tree: ok"

# The body's own failure outranks the cleanup's: an incoming 3 must survive
# both a clean reap and an anomalous one, or a real failure gets relabelled.
mkdir -p "$P/d"
got="$(reap_scratch "$P/d" 3)"
[ "$got" = "3" ] || { echo "codex-cap-watcher: (2d) a clean reap rewrote an incoming 3 to '$got'" >&2; exit 1; }
mkdir -p "$P/e"
got="$( rm() { return 1; }; reap_scratch "$P/e" 3 2>/dev/null )"
[ "$got" = "3" ] || { echo "codex-cap-watcher: (2d) a removal-failure reap rewrote an incoming 3 to '$got'" >&2; exit 1; }
# BOTH anomalous branches, not just one. Mutating only the refusal branch's
# status preservation survived a first pass of these arms, because every
# incoming-3 case drove the removal branch — a hole the tally hid rather than
# showed.
mkdir -p "$P/f"
got="$( LSOF="$P/lsof-uncertain"; reap_scratch "$P/f" 3 2>/dev/null )"
[ "$got" = "3" ] || { echo "codex-cap-watcher: (2d) a refusal reap rewrote an incoming 3 to '$got'" >&2; exit 1; }
echo "codex-cap-watcher: (2d) an incoming failure status survives cleanup in all three polarities: ok"

echo "codex-cap-watcher: ok"
