#!/usr/bin/env bash
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo 'do not source; run through smoke-all --only' >&2
  return 1 2>/dev/null || exit 1
fi
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
export TAP_HOME="$WORK/home"
mkdir -p "$TAP_HOME" "$WORK/post/.tap/bus/clear-fence" "$WORK/legacy/clear-fence"
ln -s "$WORK/post/.tap/team-registry.json" "$WORK/registry-link"
. "$ROOT/skills/tap/scripts/lib.sh"

# The real inspector remains the content authority. Count actual RUNTIME starts,
# including bus resolution, rather than asserting a machine-specific duration.
# The shim has to sit on PATH rather than be a shell function: tap_bun_call
# resolves the binary with `command -v` and invokes THAT, so a function named
# `bun` would never be consulted and every count would read zero — a
# success-shaped instrument measuring nothing.
CALLS="$WORK/runtime-calls"
REAL_BUN="$(command -v bun)"
mkdir -p "$WORK/bin"
cat > "$WORK/bin/bun" <<SHIM
#!/usr/bin/env bash
printf 'bun\n' >> "$CALLS"
exec "$REAL_BUN" "\$@"
SHIM
chmod +x "$WORK/bin/bun"
PATH="$WORK/bin:$PATH"
# Positive control: the shim is on the path the adapter actually resolves, so a
# zero below means "did not start", never "was not counted".
: > "$CALLS"
tap_bun_call probe shim clear-fence.ts inspect "$TAP_HOME" probe >/dev/null 2>&1 || true
[ -s "$CALLS" ] || { echo 'shim never intercepted a runtime start' >&2; exit 1; }
check() { # handle, explicit bus (empty resolves registry), expected state/fields, starts
  : > "$CALLS"
  TAP_CLEAR_FENCE_STATE=stale TAP_CLEAR_FENCE_SINCE=stale
  TAP_CLEAR_FENCE_PID=stale TAP_CLEAR_FENCE_NONCE=stale
  tap_clear_fence_inspect "$1" "$2"
  local result="$TAP_CLEAR_FENCE_STATE|$TAP_CLEAR_FENCE_SINCE|$TAP_CLEAR_FENCE_PID|$TAP_CLEAR_FENCE_NONCE"
  [ "$result" = "$3" ] || { echo "fence '$1': got $result, expected $3" >&2; exit 1; }
  local n=0 line
  while IFS= read -r line; do n=$((n + 1)); done < "$CALLS"
  [ "$n" = "$4" ] || { echo "fence '$1': runtime starts $n, expected $4" >&2; exit 1; }
}
marker() { printf '%s' "$2" > "$1/clear-fence/peer.json"; }
live='{"since_epoch":4102444800,"ceiling_seconds":60,"since":"stamp","pid":123,"nonce":"n"}'
expired='{"since_epoch":0,"ceiling_seconds":1,"since":"old","pid":456,"nonce":"e"}'

# Absent explicit bus starts no runtime and creates no marker directory.
check peer "$TAP_HOME" 'absent|||' 0
[ ! -e "$TAP_HOME/clear-fence" ]
# Resolving an absent marker still starts the existing resolver exactly once.
TARGET_REGISTRY="$WORK/registry-link"
check peer '' 'absent|||' 1
marker "$WORK/post/.tap/bus" "$live"
check team/peer '' 'live|stamp|123|n' 2
check peer "$WORK/post/.tap/bus" 'live|stamp|123|n' 1
check other "$WORK/post/.tap/bus" 'absent|||' 0
marker "$WORK/post/.tap/bus" "$expired"
check peer '' 'expired|old|456|e' 2
marker "$WORK/post/.tap/bus" '{torn'
check peer '' 'absent|||' 2
marker "$WORK/post/.tap/bus" ''
check peer '' 'absent|||' 2
marker "$WORK/post/.tap/bus" '{"since":"invalid","nonce":"kept"}'
check peer '' 'absent|invalid||kept' 2

# Legacy layout, linked bus, linked marker and module-normalized unusual handle.
TARGET_REGISTRY="$WORK/legacy/registry.json"
marker "$WORK/legacy" "$live"
check peer '' 'live|stamp|123|n' 2
ln -s "$WORK/legacy" "$WORK/bus-link"
check peer "$WORK/bus-link" 'live|stamp|123|n' 1
check ' team/peer ' "$WORK/legacy" 'live|stamp|123|n' 1
mv "$WORK/legacy/clear-fence/peer.json" "$WORK/marker-content"
ln -s "$WORK/marker-content" "$WORK/legacy/clear-fence/peer.json"
check peer '' 'live|stamp|123|n' 2
rm "$WORK/marker-content"
check peer '' 'absent|||' 1
rm "$WORK/legacy/clear-fence/peer.json"
mkdir "$WORK/legacy/clear-fence/peer.json"
check peer '' 'absent|||' 2
echo 'clear-fence absent fastpath: counts, states and resolved paths PASS'
