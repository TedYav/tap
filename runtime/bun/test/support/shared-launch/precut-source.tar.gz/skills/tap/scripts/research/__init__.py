"""TAP Research-Run Infrastructure (tap-b80p).

Provides:
- Research-run receipts and replay harness (sol's spec)
- Clean-pair registry (grok's design)
"""

from .receipt import (
    ResearchRunReceipt,
    ModelEffortInfo,
    VerifierVerdict,
    ReceiptStore,
    ReplayHarness,
)
from .clean_pair import (
    CleanPairRegistry,
    CleanPairCell,
    VerificationRequirement,
)

__all__ = [
    "ResearchRunReceipt",
    "ModelEffortInfo",
    "VerifierVerdict",
    "ReceiptStore",
    "ReplayHarness",
    "CleanPairRegistry",
    "CleanPairCell",
    "VerificationRequirement",
]
