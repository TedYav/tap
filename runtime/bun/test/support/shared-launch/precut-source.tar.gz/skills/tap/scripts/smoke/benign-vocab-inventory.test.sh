#!/usr/bin/env bash
# benign-vocab-inventory.test.sh — enforce the benign-vocabulary sweep mechanically.
#
# The AGENTS.md "Vocabulary convention" asks durable PROSE (comments, docstrings,
# dispatch text) in the session/registry carrier files to prefer benign systems
# vocabulary, so a partner-model reviewer does not read mundane tmux bookkeeping
# as an attack toolkit and stall on a cyber-caution gate. Three manual sweeps
# each missed survivors; this test replaces the manual claim with an
# enumerate-then-classify inventory (see benign_vocab_lint.py). It fails if any
# flavor-vocabulary hit in prose is neither neutralized nor classified in the
# lint's reasoned allowlist, and if any allowlist entry has gone stale.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

HERE="$(cd "$(dirname "$0")" && pwd)"
# Use the interpreter smoke-all resolved (TAP_PYTHON), else the repo resolver —
# never bare python3, which can pick an older floor than the suite selected.
# shellcheck source=skills/tap/scripts/smoke/smoke-preflight.sh
. "$HERE/smoke-preflight.sh"
# Enforce the interpreter floor FIRST, so a sub-3.12 box fails with the version
# error (the lint needs 3.12+ FSTRING_MIDDLE) — not the unclassified-hit guidance.
smoke_preflight_check || exit 1
PY="${TAP_PYTHON:-$(smoke_resolve_python)}"
# Validate the ACTUAL selected interpreter — an unchecked ${TAP_PYTHON} override
# (e.g. TAP_PYTHON=true, or a 3.11) must not silently no-op the gate.
smoke_assert_python "$PY" || exit 1

echo "# benign-vocab-inventory: enumerate-then-classify the carrier-file prose sweep"
if "$PY" "$HERE/benign_vocab_lint.py"; then
  echo "PASS benign-vocab-inventory"
else
  echo "FAIL benign-vocab-inventory — see unclassified hit(s)/stale entr(y/ies) above." >&2
  echo "Fix: neutralize the prose (preferred). For a genuine shell-CODE hit the coarse" >&2
  echo "whole-line scan flags (a parameter expansion, an unrenameable identifier), add a" >&2
  echo "tight, narrowly-scoped allowlist entry in benign_vocab_lint.py — never re-mask." >&2
  exit 1
fi
