#!/usr/bin/env bash
# tap-o4ae: fixture env (TMUX=/fake/socket, …) must stay in this process.
# Refuse `source` so an interactive shell cannot inherit top-level exports.
# Must run BEFORE any `set -o` so a refusal does not mutate caller options.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# seat-corpse-lockstep.test.sh — tap-rxqb: ONE corpse spec, one AUTHORITY.
#
# "Is this seat a reclaimable corpse?" is owned by session/seat_corpse.py —
# the module the session-name allocator (launcher.py) imports, and mirrored
# natively by runtime/bun/src/seat-verdict.ts — the module the native register
# ladder (verbs/register.ts's locked chooser, checkpoint C) executes. lib.sh's
# tap_seat_pane_probe mirrors that classification for bash callers and cannot
# share code across the language boundary, so this smoke pins the bash mirror
# against the python authority: both run against the SAME staged tmux state and
# must return the SAME four-way classification. If you change one, change the
# other or this fails loud. (Same intent as contract-version-lockstep.test.sh.)
#
# The #xxx gate lesson is encoded here three times over: (1) python leg A
# drives the allocator's composition (classify_pane over launcher.py's
# observation); (2) the bun leg B drives seat-verdict.ts's seatVerdict — the
# EXACT decision function the native register ladder executes under its lock —
# so all THREE implementations of the observation contract run against one
# staged fixture set (a lockstep pinning two of three and grep-pinning the
# third is the enumerate/mirror trap one layer up — sol's re-gate P1 #4);
# (3) the import pin below still fails the smoke if verbs/register.ts ever
# stops importing the module, the belt under the executed suspenders.
#
# The fake tmux models the tmux 3.6a dead-target quirk exactly — display-message
# on a dead target exits 0 with EMPTY output — because that hostile case is
# precisely where two independently-written probes drift apart. FAKE_TMUX_DOWN
# models the whole server being unreachable (nonzero + stderr), which must
# classify UNOBSERVABLE, never a corpse: absence-of-observation is not
# observation-of-absence.
#
# RC CONTRACT (bash only, asserted per case): exit 0 = the row may NOT be
# treated as dead (alive OR unobservable); exit 1 = observed-stale
# (pane_gone / pane_recycled). A caller branching only on the exit code can
# keep a row it should trim, but can never trim a row it must keep — adding
# UNOBSERVABLE at rc 1 would have re-introduced tap-67n1's live-seat deletion
# with a green suite.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
LIB="$ROOT/skills/tap/scripts/lib.sh"
REGISTER="$ROOT/runtime/bun/src/verbs/register.ts"
LAUNCHER_DIR="$ROOT/skills/tap/scripts/session"
FAKE_BIN="$(mktemp -d)"
trap 'rm -rf "$FAKE_BIN"' EXIT
export PATH="$FAKE_BIN:$PATH" TMUX="/fake/socket"

# FAKE_PANES maps "target=pane_id" pairs, space separated. A target absent from
# the map is DEAD and gets the 3.6a treatment: rc 0, empty output.
# FAKE_TMUX_DOWN simulates an unreachable server: every invocation fails loud
# (nonzero WITH stderr — lib.sh's reachable-on-empty-stderr mock exception must
# not swallow it).
cat > "$FAKE_BIN/tmux" <<'ENDTMUX'
#!/usr/bin/env bash
set -euo pipefail
if [ -n "${FAKE_TMUX_DOWN:-}" ]; then
  echo "no server running on /fake/socket" >&2
  exit 1
fi
cmd="${1:-}"; shift || true
target=""; fmt=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    -p|-e) shift ;;
    -t) target="${2:-}"; shift 2 ;;
    *) fmt="$1"; shift ;;
  esac
done
[ "$cmd" = "display-message" ] || exit 0
# FAKE_TARGET_ERROR: any -t probe fails with an OPAQUE error while the server
# is otherwise fine — the transient-failure shape that must never read as
# absence.
if [ -n "${FAKE_TARGET_ERROR:-}" ] && [ -n "$target" ]; then
  echo "lost server socket temporarily" >&2
  exit 1
fi
# FAKE_MALFORMED_OUTPUT: any -t probe answers rc 0 with this LITERAL — the
# garbled-record-framing shape (sol r4): never absence, never an identity.
if [ -n "${FAKE_MALFORMED_OUTPUT+x}" ] && [ -n "$target" ]; then
  printf '%s\n' "$FAKE_MALFORMED_OUTPUT"
  exit 0
fi
# tap-ua9l: the untargeted generation probe, opt-in via FAKE_EPOCH_RAW so the
# corpus cases above keep their existing unknown-generation behaviour.
if [ -z "$target" ] && [ -n "${FAKE_EPOCH_RAW+x}" ]; then
  case "$fmt" in *pid*start_time*) printf '%s\n' "$FAKE_EPOCH_RAW"; exit 0 ;; esac
fi
resolved=""
for pair in ${FAKE_PANES:-}; do
  case "$pair" in
    "$target="*) resolved="${pair#*=}" ;;
  esac
done
# Dead target: tmux 3.6a exits 0 and expands to NOTHING. FAKE_LEGACY_DEAD
# models the classic reply instead: nonzero + "can't find" on stderr — the
# server still ANSWERING "not there", just on the other channel.
[ -n "$resolved" ] || {
  if [ -n "${FAKE_LEGACY_DEAD:-}" ] && [ -n "$target" ]; then
    echo "can't find pane: $target" >&2
    exit 1
  fi
  printf ''; exit 0
}
out="$fmt"
out="${out//'#{pane_id}'/$resolved}"
out="${out//'#{session_name}:#{window_index}.#{pane_index}'/repo/seat:0.0}"
out="${out//'#{pane_current_command}'/claude}"
out="${out//'#{pane_current_path}'/\/tmp\/repo}"
# tap-ua9l: writers ask for the ids and the server generation in ONE record, so
# the template answers both. Bare #{session_name} is substituted AFTER the
# address composite above, which contains it.
out="${out//'#{pid}:#{start_time}'/${FAKE_EPOCH_RAW:-900:100}}"
out="${out//'#{pane_dead}'/0}"
out="${out//'#{pane_pid}'/4242}"
out="${out//'#{session_name}'/repo}"
printf '%s\n' "$out"
ENDTMUX
chmod +x "$FAKE_BIN/tmux"

bash_probe() {  # $1=stored_id $2=pane -> classification
  ( set +e
    # shellcheck disable=SC1090
    . "$LIB" >/dev/null 2>&1
    tap_seat_pane_probe "$1" "$2"
  )
}

py_probe() {  # $1=stored_id $2=pane -> classification (leg A: the allocator)
  # seat_corpse.classify_pane over launcher.py's observation — the exact
  # composition the session-name allocator executes.
  python3 -c '
import sys
sys.path.insert(0, sys.argv[1])
import seat_corpse
import launcher
sys.stdout.write(seat_corpse.classify_pane(sys.argv[2], sys.argv[3], launcher.seat_pane_observation))
' "$LAUNCHER_DIR" "$1" "$2"
}

# Leg B driver: the native register ladder's EXACT decision function
# (seat-verdict.ts's seatVerdict), driven directly, not mirrored or
# grep-pinned. The driver supplies only the ChooserView observation glue the
# ladder's caller owns — one display-message probe per target, with the
# fail-closed grammar (empty = observed absent, malformed = no observation)
# and the legacy "can't find" reply treated as the server ANSWERING not-there.
# Written under $FAKE_BIN so the corpus cases share the staged fake tmux.
cat > "$FAKE_BIN/seat-verdict-legb.ts" <<'ENDLEGB'
import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";
const src = process.env.TAP_LOCKSTEP_SRC!;
const { seatVerdict } = await import(pathToFileURL(`${src}/seat-verdict.ts`).href);
const { serverEpochFromRaw } = await import(pathToFileURL(`${src}/observe.ts`).href);
const { loads } = await import(pathToFileURL(`${src}/watch-detect.ts`).href);

function observe(target: string): string | null {
  if (!target) return "";
  const r = spawnSync("tmux", ["display-message", "-p", "-t", target, "#{pane_id}"], { encoding: "utf8" });
  const raw = (r.stdout ?? "").replace(/\n+$/, "");
  if (r.status !== 0) {
    if ((r.stderr ?? "").includes("can't find pane")) return "";
    return null;
  }
  if (raw === "") return "";
  return /^%\d+$/.test(raw) ? raw : null;
}

function epochNow(): string | null {
  const ov = process.env.TAP_SERVER_EPOCH;
  if (ov !== undefined) return ov === "" ? null : ov;
  const r = spawnSync("tmux", ["display-message", "-p", "#{pid}:#{start_time}"], { encoding: "utf8" });
  if (r.status !== 0) return null;
  try { return serverEpochFromRaw((r.stdout ?? "").replace(/\n$/, ""), process.env); } catch { return null; }
}

const stored = process.argv[2] ?? "";
const pane = process.argv[3] ?? "";
const entryJson = process.argv[4] ?? "";
const entry = entryJson
  ? loads(entryJson)
  : new Map<string, string>([["pane_id", stored], ["pane", pane]]);
const [verdict] = seatVerdict(entry, { paneIdOf: observe, sessionOf: () => "" }, epochNow());
process.stdout.write(verdict);
ENDLEGB
chmod +x "$FAKE_BIN/seat-verdict-legb.ts"

reg_probe() {  # $1=stored_id $2=pane $3=entry-json-optional -> classification (leg B: the ladder)
  TAP_LOCKSTEP_SRC="$ROOT/runtime/bun/src" bun "$FAKE_BIN/seat-verdict-legb.ts" "$1" "$2" "${3:-}"
}

fails=0
check() {  # $1=case $2=FAKE_PANES $3=stored_id $4=pane $5=expected [$6=fake-env "VAR=1"]
  local name="$1" panes="$2" stored="$3" pane="$4" want="$5" fake_env="${6:-}" got_sh got_py got_reg rc_sh want_rc
  local down="" legacy="" target_err="" malformed_set=""
  case "$fake_env" in
    FAKE_TMUX_DOWN*) down=1 ;;
    FAKE_LEGACY_DEAD*) legacy=1 ;;
    FAKE_TARGET_ERROR*) target_err=1 ;;
    FAKE_MALFORMED*) malformed_set=1 ;;   # literal supplied via LOCKSTEP_MALFORMED
  esac
  if [ -n "$malformed_set" ]; then
    export FAKE_MALFORMED_OUTPUT="${LOCKSTEP_MALFORMED-}"
  else
    unset FAKE_MALFORMED_OUTPUT
  fi
  case "$want" in
    alive|unobservable) want_rc=0 ;;
    *) want_rc=1 ;;
  esac
  set +e
  got_sh="$(FAKE_PANES="$panes" FAKE_TMUX_DOWN="$down" FAKE_LEGACY_DEAD="$legacy" FAKE_TARGET_ERROR="$target_err" bash_probe "$stored" "$pane")"
  rc_sh=$?
  set -e
  got_py="$(FAKE_PANES="$panes" FAKE_TMUX_DOWN="$down" FAKE_LEGACY_DEAD="$legacy" FAKE_TARGET_ERROR="$target_err" py_probe "$stored" "$pane" || true)"
  got_reg="$(FAKE_PANES="$panes" FAKE_TMUX_DOWN="$down" FAKE_LEGACY_DEAD="$legacy" FAKE_TARGET_ERROR="$target_err" reg_probe "$stored" "$pane" || true)"
  if [ "$got_sh" != "$want" ]; then
    echo "seat-corpse-lockstep: FAIL [$name] bash predicate: want '$want', got '$got_sh'" >&2
    fails=$((fails + 1))
  fi
  if [ "$rc_sh" -ne "$want_rc" ]; then
    echo "seat-corpse-lockstep: FAIL [$name] bash RC CONTRACT: want rc $want_rc for '$want', got rc $rc_sh" >&2
    fails=$((fails + 1))
  fi
  if [ "$got_py" != "$want" ]; then
    echo "seat-corpse-lockstep: FAIL [$name] python allocator leg: want '$want', got '$got_py'" >&2
    fails=$((fails + 1))
  fi
  if [ "$got_reg" != "$want" ]; then
    echo "seat-corpse-lockstep: FAIL [$name] bun REGISTER leg (seatVerdict): want '$want', got '$got_reg'" >&2
    fails=$((fails + 1))
  fi
  if [ "$got_sh" != "$got_py" ] || [ "$got_py" != "$got_reg" ]; then
    echo "seat-corpse-lockstep: FAIL [$name] CROSS-IMPLEMENTATION DRIFT: bash='$got_sh' allocator='$got_py' register='$got_reg'" >&2
    fails=$((fails + 1))
  fi
  [ "$got_sh" = "$want" ] && [ "$got_py" = "$want" ] && [ "$got_reg" = "$want" ] && [ "$rc_sh" -eq "$want_rc" ] \
    && echo "seat-corpse-lockstep: ok [$name] all three -> $want (bash rc $rc_sh)"
}

# 0. The import pin: the register ladder must EXECUTE the shared classifier.
#    Without this, the chooser could silently re-inline its own probe and this
#    lockstep would go back to pinning two non-authoritative mirrors — the
#    exact false confidence sol's #xxx gate caught.
for needle in 'from "../seat-verdict"' "seatVerdict(" "samePaneIdentity("; do
  if ! grep -qF -- "$needle" "$REGISTER"; then
    echo "seat-corpse-lockstep: FAIL [ladder-import-pin] verbs/register.ts no longer contains '$needle' — the ladder must import and execute the shared observation + decision functions" >&2
    fails=$((fails + 1))
  fi
done
[ "$fails" -eq 0 ] && echo "seat-corpse-lockstep: ok [ladder-import-pin] verbs/register.ts imports and executes seat-verdict observation + verdict"

# 1. Identity live -> occupied. The ordinary running seat.
check "live-identity" "%1=%1" "%1" "repo/seat:0.0" "alive"

# 2. Identity dead + address dead -> THE reclaimable corpse. This is the only
#    case that frees a session name, and the only one tap-rxqb needed.
check "both-gone" "" "%2" "repo/seat:0.0" "pane_gone"

# 3. Identity dead + address LIVE (a different pane) -> RECYCLED, still
#    occupied. tap-bau's seat-steal fix lives or dies here: the harness
#    restarted in the same tmux slot, so the address hosts someone else's
#    conversation and the seat is emphatically not a corpse.
check "recycled-pane" "repo/seat:0.0=%3" "%2" "repo/seat:0.0" "pane_recycled"

# 3b. A malformed STORED identity is corrupt registry data, not an observed
# dead/recycled pane. It must never hand a lifecycle consumer mutation permission.
check "malformed-stored-id" "repo/seat:0.0=%3" "%tap-claude" "repo/seat:0.0" "unobservable"

# 4. No stored identity at all, address live -> alive (legacy rows that predate
#    pane_id capture must not be mistaken for corpses).
check "legacy-row-address-only" "repo/seat:0.0=%5" "" "repo/seat:0.0" "alive"

# 5. No stored identity, no address -> gone. (The corpse PREDICATE never asks
#    about such a row — not pane-backed means never a corpse — this pins the
#    raw classifier only.)
check "legacy-row-nothing" "" "" "" "pane_gone"

# 6. Was RED at the #xxx gate (sol, finding 2): stable-id probe MISSES but the
#    recorded address resolves to that SAME stored id. The pane is alive and
#    IS the identity on record, so the seat is occupied. At 4aabafa BOTH
#    predicates answered pane_gone while the register ladder's address
#    fallback treated any live returned id as occupied — the drift was not
#    python-vs-bash, it was both mirrors vs the authority, which is why the
#    py leg now drives seat_corpse.classify_pane itself.
check "address-live-same-id" "repo/seat:0.0=%4" "%4" "repo/seat:0.0" "alive"

# 7. Server unreachable -> UNOBSERVABLE, rc 0, never a corpse. An unreachable
#    tmux must not read as every seat being dead at once (sol, finding 4 —
#    the third application of tap-o4ae's absence-of-observation rule).
check "server-down" "" "%1" "repo/seat:0.0" "unobservable" "FAKE_TMUX_DOWN=1"

# 7b. Server unreachable, legacy address-only row -> same fail-closed answer.
check "server-down-legacy-row" "" "" "repo/seat:0.0" "unobservable" "FAKE_TMUX_DOWN=1"

# 9. Classic (pre-3.6a) dead target: nonzero + "can't find" on stderr is the
#    server ANSWERING "not there" — the error is the answer, same corpse
#    verdict as the 3.6a empty expansion.
check "legacy-dead-cant-find" "" "%2" "repo/seat:0.0" "pane_gone" "FAKE_LEGACY_DEAD=1"

# 10. Opaque target-probe failure (nonzero, unrelated stderr) with the server
#     otherwise fine -> UNOBSERVABLE, rc 0. A failed probe is never an
#     observation of absence — the fail-closed rule exists FOR the failure
#     branch (sol, #xxx re-gate P1 #2, the nonzero arm).
check "opaque-probe-failure" "" "%1" "repo/seat:0.0" "unobservable" "FAKE_TARGET_ERROR=1"

# 11-13. RECORD-FRAMING boundaries (sol, re-gate r4): rc-0 absence is ONLY a
#     truly empty expansion; anything else must be exactly one complete live
#     record. Empty-id-with-session partitioned into an empty pid BEFORE the
#     grammar gate and read as absence in both python authorities (while bash
#     read unobservable — cross-authority drift, the exact disease this
#     lockstep exists to kill); whitespace stripped to absence in the raw
#     discriminator; a multi-line answer with a VALID first line is the shape
#     where first-line-taking drifts from whole-frame rejection.
LOCKSTEP_MALFORMED=$'\trepo'
check "framing-empty-id-with-session" "" "%41" "repo/seat:0.0" "unobservable" "FAKE_MALFORMED=1"
LOCKSTEP_MALFORMED=' '
check "framing-whitespace-only" "" "%41" "repo/seat:0.0" "unobservable" "FAKE_MALFORMED=1"
LOCKSTEP_MALFORMED=$'%41\n%42'
check "framing-multiline-valid-first" "" "%41" "repo/seat:0.0" "unobservable" "FAKE_MALFORMED=1"
unset LOCKSTEP_MALFORMED

# 8. MALFORMED answer from a reachable server -> UNOBSERVABLE, rc 0 (sol,
#    #xxx re-gate). A tmux pane id always starts with '%'; a garbage
#    resolution is a broken observation channel, never evidence of absence —
#    and never an identity either (bash's tap_pane_alive would otherwise take
#    any non-empty string as a live id, python's parse would take it as a
#    live pane_id: both sides must refuse it identically).
check "malformed-output" "%1=beefcake" "%1" "repo/seat:0.0" "unobservable"

# --- BOUNDARY CORPUS: pane-id grammar + record framing (sol, r2/r4) ----------
# The grammar is '%' + decimal digits, nothing else; the FRAMING contract is
# rc-0 absence ONLY for a truly empty expansion, and anything else must be
# exactly one complete live record. Rejection rules and their boundary pairs —
# one fixture just INSIDE and at least one just OUTSIDE each rule, per the
# corpus rule: N rejection rules demand >= 2N boundary fixtures or the corpus
# is under-specified by construction. Five rules, 12 boundary fixtures:
#   R1  must start with '%'          inside: %41       outside: bare 41 (case B3)
#   R2  payload non-empty            inside: %0  (B1)  outside: bare '%' (B4)
#   R3  payload all decimal digits   inside: %41 (B2)  outside: %beefcake (B5),
#                                                       %4x (B6), %-1 (B7)
#   R4  absence = empty expansion    inside: both-gone (case 2, empty answer)
#       only                          outside: whitespace-only (case 12)
#   R5  exactly one complete record  inside: live-identity (case 1)
#                                     outside: empty-id+session (11),
#                                              multiline-valid-first (13)
# Every case runs through ALL THREE legs — including seatVerdict, the locked
# register ladder's decision function, because the destructive consumers are
# where a fail-open grammar kills: round 2's '%beefcake' classified
# pane_recycled, and RECYCLED AUTHORIZES DESTRUCTION (register reclaims the
# base handle; team/admin refresh trim the row).

# B1/B2 — just inside: minimal and ordinary valid ids are ALIVE identities.
check "grammar-inside-minimal" "%0=%0" "%0" "repo/seat:0.0" "alive"
check "grammar-inside-ordinary" "%41=%41" "%41" "repo/seat:0.0" "alive"

# B3-B7 — just outside, in the DESTRUCTIVE position (sol's round-2 injection
# shape verbatim: stored id observed absent, address answering garbage; a
# fail-open grammar reads these as pane_recycled and authorizes reclaim/trim).
check "grammar-outside-bare-digits" "repo/seat:0.0=41" "%41" "repo/seat:0.0" "unobservable"
check "grammar-outside-percent-only" "repo/seat:0.0=%" "%41" "repo/seat:0.0" "unobservable"
check "grammar-outside-alpha" "repo/seat:0.0=%beefcake" "%41" "repo/seat:0.0" "unobservable"
check "grammar-outside-mixed" "repo/seat:0.0=%4x" "%41" "repo/seat:0.0" "unobservable"
check "grammar-outside-signed" "repo/seat:0.0=%-1" "%41" "repo/seat:0.0" "unobservable"
check "grammar-outside-unicode-digit" "repo/seat:0.0=%4²" "%41" "repo/seat:0.0" "unobservable"

# --- SERVER-EPOCH CORPUS (tap-24f) -------------------------------------------
# Pane ids are unique only within one server lifetime. seatVerdict (the
# native register ladder's decision function) voids a row's ids when its
# server_epoch stamp names a PRIOR epoch — a resolving id is then recycling
# coincidence, and classifying it ALIVE authorized handle protection from a
# stranger's pane (the suffix-mint incident). The bash mirror stays a pure
# (stored_id, pane) classifier; bash CALLERS apply the epoch arm before it
# (team/admin refresh, roster) — asserted by server-epoch-guard.test.sh.
# Here: the bun register leg's entry-level void, plus the two-language
# override pin for the epoch producer itself.

epoch_verdict() {  # $1=FAKE_PANES $2=entry-json -> verdict
  FAKE_PANES="$1" reg_probe "" "" "$2"
}

# Stale stamp + resolving id (the recycling coincidence) -> pane_gone: the ids
# are provably from a dead server, so nothing recorded is running.
got="$(TAP_SERVER_EPOCH="srv:2:2" epoch_verdict "%1=%1" '{"pane_id":"%1","pane":"repo/seat:0.0","server_epoch":"srv:1:1"}')"
if [ "$got" != "pane_gone" ]; then
  echo "seat-corpse-lockstep: FAIL [epoch-stale-void] seatVerdict: want 'pane_gone', got '$got'" >&2
  fails=$((fails + 1))
else
  echo "seat-corpse-lockstep: ok [epoch-stale-void] stale-stamp entry -> pane_gone"
fi

# Matching stamp -> classification unchanged (alive), pinning that the void
# fires ONLY on a positively observed epoch difference.
got="$(TAP_SERVER_EPOCH="srv:2:2" epoch_verdict "%1=%1" '{"pane_id":"%1","pane":"repo/seat:0.0","server_epoch":"srv:2:2"}')"
if [ "$got" != "alive" ]; then
  echo "seat-corpse-lockstep: FAIL [epoch-match-alive] seatVerdict: want 'alive', got '$got'" >&2
  fails=$((fails + 1))
else
  echo "seat-corpse-lockstep: ok [epoch-match-alive] matching stamp keeps today's verdict"
fi

# Unknown current epoch (unobservable server) -> guard disabled, never a void.
got="$(TAP_SERVER_EPOCH="" epoch_verdict "%1=%1" '{"pane_id":"%1","pane":"repo/seat:0.0","server_epoch":"srv:1:1"}')"
if [ "$got" != "alive" ]; then
  echo "seat-corpse-lockstep: FAIL [epoch-unknown-disables] seatVerdict: want 'alive', got '$got'" >&2
  fails=$((fails + 1))
else
  echo "seat-corpse-lockstep: ok [epoch-unknown-disables] unknown epoch never voids"
fi

# Two-language producer pin, override path: shell and python must honor the
# SAME TAP_SERVER_EPOCH override semantics (set=override, empty=unknown).
sh_epoch="$(TAP_SERVER_EPOCH="srv:9:9" bash -c ". '$LIB' >/dev/null 2>&1; tap_server_epoch_now" || true)"
py_epoch="$(TAP_SERVER_EPOCH="srv:9:9" python3 -c '
import sys
sys.path.insert(0, sys.argv[1])
import seat_corpse
sys.stdout.write(seat_corpse.server_epoch_now() or "")
' "$LAUNCHER_DIR")"
if [ "$sh_epoch" != "srv:9:9" ] || [ "$py_epoch" != "srv:9:9" ]; then
  echo "seat-corpse-lockstep: FAIL [epoch-override-pin] shell='$sh_epoch' python='$py_epoch' want 'srv:9:9' from both" >&2
  fails=$((fails + 1))
else
  echo "seat-corpse-lockstep: ok [epoch-override-pin] TAP_SERVER_EPOCH override identical in both languages"
fi


# --- tap-ua9l: the SINGLE-OBSERVATION capture, pinned across both languages ---
# Writers now read the ids and the generation out of one tmux record. Bash reads
# that record in tap_pane_observe and python in tmux_pane_facts, two independent
# parses of two different formats — exactly the shape that drifts. Pin them to
# the same pane id and the same generation string against one staged server.
sh_obs="$(FAKE_EPOCH_RAW=900:100 FAKE_PANES="%1=%1" bash -c ". '$LIB' >/dev/null 2>&1; tap_pane_observe %1")"
sh_obs_id="${sh_obs%%$'\t'*}"
sh_obs_rest="${sh_obs#*$'\t'}"
sh_obs_epoch="${sh_obs_rest#*$'\t'}"
py_obs="$(FAKE_EPOCH_RAW=900:100 FAKE_PANES="%1=%1" python3 -c '
import importlib.machinery, importlib.util, sys
spec = importlib.util.spec_from_loader("launcher", importlib.machinery.SourceFileLoader("launcher", sys.argv[1] + "/launcher.py"))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
facts = m.tmux_pane_facts("%1")
sys.stdout.write("{}\t{}".format(facts.pane_id if facts else "", facts.server_epoch if facts else ""))
' "$LAUNCHER_DIR")"
py_obs_id="${py_obs%%$'\t'*}"
py_obs_epoch="${py_obs#*$'\t'}"
if [ "$sh_obs_id" != "%1" ] || [ "$py_obs_id" != "%1" ] \
   || [ "$sh_obs_epoch" != "srv:900:100" ] || [ "$py_obs_epoch" != "srv:900:100" ]; then
  echo "seat-corpse-lockstep: FAIL [single-observation-pin] shell=($sh_obs_id,$sh_obs_epoch) python=($py_obs_id,$py_obs_epoch) want (%1,srv:900:100) from both" >&2
  fails=$((fails + 1))
else
  echo "seat-corpse-lockstep: ok [single-observation-pin] one record, same ids and generation in both languages"
fi

# The generation GRAMMAR itself, over the boundary corpus: one authority per
# language, and a field that is not exactly <digits>:<digits> is not a
# generation in either of them.
for raw in "900:100" "0:0" "abc" "1:2:3" "" ":5" "5:" "900:10a" " 900:100"; do
  sh_g="$(env -u TAP_SERVER_EPOCH bash -c ". '$LIB' >/dev/null 2>&1; tap_server_epoch_from_raw \"\$1\"" _ "$raw" 2>/dev/null || true)"
  py_g="$(env -u TAP_SERVER_EPOCH python3 -c '
import importlib.machinery, importlib.util, sys
spec = importlib.util.spec_from_loader("seat_corpse", importlib.machinery.SourceFileLoader("seat_corpse", sys.argv[1] + "/seat_corpse.py"))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
sys.stdout.write(m.observed_server_epoch(sys.argv[2]) or "")
' "$LAUNCHER_DIR" "$raw")"
  if [ "$sh_g" != "$py_g" ]; then
    echo "seat-corpse-lockstep: FAIL [generation-grammar '$raw'] shell='$sh_g' python='$py_g'" >&2
    fails=$((fails + 1))
  fi
done
echo "seat-corpse-lockstep: ok [generation-grammar] both languages accept and reject the same fields"

if [ "$fails" -ne 0 ]; then
  echo "seat-corpse-lockstep: FAILED ($fails assertion(s))" >&2
  exit 1
fi
echo "seat-corpse-lockstep: PASS"
