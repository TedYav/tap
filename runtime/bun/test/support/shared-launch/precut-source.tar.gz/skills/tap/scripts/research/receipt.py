"""Research-run receipt & replay harness (sol's spec — tap-b80p).

Records prompt hash, frozen/live source IDs, required item count,
DECLARED AND OBSERVED model/effort (rollout-stamp / transcript verified),
harness/tool versions, timings, claim IDs, verifier verdicts.

Provides parameter drift detection and replay validation across all paths
including in-pane /new.
"""

from dataclasses import dataclass, field, asdict
import datetime
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class ModelEffortInfo:
    declared_model: str
    observed_model: str
    declared_effort: str
    observed_effort: str

    def detect_drift(self) -> List[str]:
        drifts = []
        if self.declared_model != self.observed_model:
            drifts.append(
                f"Model drift detected: declared '{self.declared_model}' != observed '{self.observed_model}'"
            )
        if self.declared_effort != self.observed_effort:
            drifts.append(
                f"Effort drift detected: declared '{self.declared_effort}' != observed '{self.observed_effort}'"
            )
        return drifts


@dataclass
class VerifierVerdict:
    verifier_id: str
    verifier_model: str
    verifier_family: str
    verdict: str  # "pass", "fail", "inconclusive"
    claims_evaluated: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ResearchRunReceipt:
    receipt_id: str
    created_at: str
    prompt_hash: str
    frozen_source_ids: List[str]
    live_source_ids: List[str]
    required_item_count: int
    observed_item_count: int
    model_info: ModelEffortInfo
    harness: str
    harness_version: str = "1.0"
    tool_versions: Dict[str, str] = field(default_factory=dict)
    timings: Dict[str, float] = field(default_factory=dict)
    claim_ids: List[str] = field(default_factory=list)
    verifier_verdicts: List[VerifierVerdict] = field(default_factory=list)
    task_class: str = "default"
    seat: str = "unknown"
    tier: str = "unknown"
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def create(
        cls,
        prompt: str,
        frozen_source_ids: List[str],
        live_source_ids: List[str],
        required_item_count: int,
        observed_item_count: int,
        declared_model: str,
        observed_model: str,
        declared_effort: str,
        observed_effort: str,
        harness: str,
        harness_version: str = "1.0",
        tool_versions: Optional[Dict[str, str]] = None,
        timings: Optional[Dict[str, float]] = None,
        claim_ids: Optional[List[str]] = None,
        verifier_verdicts: Optional[List[VerifierVerdict]] = None,
        task_class: str = "default",
        seat: str = "unknown",
        tier: str = "unknown",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ResearchRunReceipt":
        prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
        ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
        short_hash = prompt_hash[:12]
        ts_slug = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        receipt_id = f"rrr-{ts_slug}-{short_hash}"

        model_info = ModelEffortInfo(
            declared_model=declared_model,
            observed_model=observed_model,
            declared_effort=declared_effort,
            observed_effort=observed_effort,
        )

        return cls(
            receipt_id=receipt_id,
            created_at=ts,
            prompt_hash=prompt_hash,
            frozen_source_ids=frozen_source_ids,
            live_source_ids=live_source_ids,
            required_item_count=required_item_count,
            observed_item_count=observed_item_count,
            model_info=model_info,
            harness=harness,
            harness_version=harness_version,
            tool_versions=tool_versions or {},
            timings=timings or {},
            claim_ids=claim_ids or [],
            verifier_verdicts=verifier_verdicts or [],
            task_class=task_class,
            seat=seat,
            tier=tier,
            metadata=metadata or {},
        )

    def validate(self) -> Tuple[bool, List[str]]:
        """Validate receipt completeness and detect parameter drift / denominator issues."""
        errors = []

        # 1. Parameter drift check
        drift_errors = self.model_info.detect_drift()
        errors.extend(drift_errors)

        # 2. Denominator check (fixed required item count)
        if self.observed_item_count < self.required_item_count:
            errors.append(
                f"Denominator truncation detected: observed item count {self.observed_item_count} "
                f"< required item count {self.required_item_count}"
            )

        # 3. Verifier checks
        if not self.verifier_verdicts:
            errors.append("No verifier verdicts attached to research run receipt")
        else:
            for verdict in self.verifier_verdicts:
                if verdict.verdict not in ("pass", "fail", "inconclusive"):
                    errors.append(
                        f"Invalid verifier verdict '{verdict.verdict}' from verifier '{verdict.verifier_id}'"
                    )

        # 4. Mandatory fields
        if not self.prompt_hash:
            errors.append("Missing prompt hash")

        is_valid = len(errors) == 0
        return is_valid, errors

    def is_clean(self) -> bool:
        """Returns True if valid, zero parameter drift, and all verifiers passed."""
        valid, errors = self.validate()
        if not valid:
            return False
        if any(v.verdict != "pass" for v in self.verifier_verdicts):
            return False
        return True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ResearchRunReceipt":
        data = dict(data)
        model_info_raw = data.pop("model_info", {})
        if isinstance(model_info_raw, dict):
            model_info = ModelEffortInfo(**model_info_raw)
        else:
            model_info = model_info_raw

        verdicts_raw = data.pop("verifier_verdicts", [])
        verdicts = []
        for v in verdicts_raw:
            if isinstance(v, dict):
                verdicts.append(VerifierVerdict(**v))
            else:
                verdicts.append(v)

        return cls(model_info=model_info, verifier_verdicts=verdicts, **data)


class ReceiptStore:
    def __init__(self, base_dir: Optional[Path] = None):
        if base_dir is None:
            base_dir = Path.cwd() / ".tap" / "research" / "receipts"
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def save(self, receipt: ResearchRunReceipt) -> Path:
        file_path = self.base_dir / f"{receipt.receipt_id}.json"
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(receipt.to_dict(), f, indent=2)
        return file_path

    def load(self, receipt_id: str) -> Optional[ResearchRunReceipt]:
        file_path = self.base_dir / f"{receipt_id}.json"
        if not file_path.exists():
            return None
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return ResearchRunReceipt.from_dict(data)

    def list_receipts(self) -> List[ResearchRunReceipt]:
        receipts = []
        for p in sorted(self.base_dir.glob("rrr-*.json")):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                receipts.append(ResearchRunReceipt.from_dict(data))
            except Exception:
                continue
        return receipts


class ReplayHarness:
    def __init__(self, store: ReceiptStore):
        self.store = store

    def replay_check(
        self,
        receipt_id: str,
        target_prompt: Optional[str] = None,
        expected_sources: Optional[List[str]] = None,
    ) -> Tuple[bool, List[str]]:
        receipt = self.store.load(receipt_id)
        if not receipt:
            return False, [f"Receipt '{receipt_id}' not found"]

        valid, errors = receipt.validate()
        errors = list(errors)

        if target_prompt is not None:
            expected_hash = hashlib.sha256(target_prompt.encode("utf-8")).hexdigest()
            if receipt.prompt_hash != expected_hash:
                errors.append(
                    f"Replay prompt hash mismatch: stored '{receipt.prompt_hash[:12]}' != expected '{expected_hash[:12]}'"
                )

        if expected_sources is not None:
            all_receipt_sources = set(receipt.frozen_source_ids + receipt.live_source_ids)
            missing_sources = set(expected_sources) - all_receipt_sources
            if missing_sources:
                errors.append(f"Replay missing expected sources: {sorted(missing_sources)}")

        return (len(errors) == 0), errors
