"""The seat-liveness classifier (the `seat_corpse` module) — the ONE
implementation of "is this pane-backed seat running, recycled, gone, or
unobservable?".

This module is the AUTHORITY because it is the code the register ladder
executes: `tap-register.sh`'s locked chooser imports `classify_pane` (an
import, never a subprocess under the flock), and `launcher.py`'s session-name
allocator imports the same function. The two layers disagreeing about what a
gone seat is was the tap-rxqb defect; conceptual alignment without executable
enforcement is drift that has not happened yet. `lib.sh`'s
`tap_seat_pane_probe` mirrors this classification for bash callers and is
pinned against this module by `seat-corpse-lockstep.test.sh`.

Classification (identity first, address fallback — tap-bau's seat-takeover rule):

- ALIVE: the stored pane identity resolves, OR the recorded address resolves
  to the STORED id (the pane is running and IS the identity on record), OR a
  legacy row's address resolves at all.
- PANE_RECYCLED: identity is proven gone and the address hosts a DIFFERENT
  running pane — an OCCUPIED ADDRESS, not evidence of the gone (PANE_GONE)
  verdict, though a caller's own restart policy may still release it.
- PANE_GONE: every recorded pane fact was OBSERVED absent. Only proven misses
  classify a seat as gone.
- UNOBSERVABLE: an observation could not be made (tmux absent, unreachable,
  or returning garbage). Fail-closed: an unobservable seat holds its name and
  is never treated as gone. Absence-of-observation is never observation-of-absence —
  the third time this codebase has learned that rule: (1) tap-o4ae's
  suspension refusal (a failed no-target tmux probe refuses the pane_gone
  write), (2) the GONE-row census's 'unknown' vessel state (surfaced, never
  primed or absorbed), (3) here, at allocation. Three independent surfaces
  converging on one rule is why the rule lives in this shared module.

Observation is supplied by the caller, classification is owned here: `observe(target)`
returns the pane id the target resolves to, `""` when the target was OBSERVED
absent, and `None` when no observation could be made. The CANONICAL
observation also lives here (`pane_observation` / `seat_verdict` — what the
register chooser imports and executes under its flock); the launcher's
allocator keeps its own facts-based wrapper only because the committed red
set pins its mock seams, and the lockstep executes BOTH python observations
plus the bash mirror against one staged fixture set, so none of the three
can drift silently.

A probe FAILURE is never an observation of absence (sol, #xxx re-gate,
second application in this file): the only shapes that mean observed-absent
are the server answering rc 0 with an empty expansion (tmux 3.6a gone
target) or the server answering "can't find ..." on stderr (the classic
gone-target reply). Any other failure — nonzero with opaque stderr, missing
binary, exception — is UNOBSERVABLE.
"""

import datetime
import os
import re
import subprocess
import sys
from pathlib import Path

# This leaf is also loaded with only session/ on sys.path.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import verbose

PENDING_RESERVATION_GRACE_SECONDS = 60

SEAT_ALIVE = "alive"
SEAT_PANE_RECYCLED = "pane_recycled"
SEAT_PANE_GONE = "pane_gone"
SEAT_UNOBSERVABLE = "unobservable"

_SERVER_EPOCH_RAW = re.compile(r"^(\d+):(\d+)$")


def tmux_command(*args):
    """Build a bounded tmux argv pinned to the selected socket when supplied."""
    socket_path = os.environ.get("TAP_TMUX_SOCKET_PATH", "")
    deadline = Path(__file__).resolve().parent.parent / "tmux_deadline.py"
    return [
        sys.executable,
        "-B",
        str(deadline),
        *(["-S", socket_path] if socket_path else []),
        *args,
    ]


def server_epoch_now():
    """The current tmux SERVER epoch as "srv:<pid>:<start_time>", or None when
    it cannot be observed (guard then disables — an unknown epoch never voids
    anything).

    tmux pane ids (%N) and session ids ($N) are unique only within one server
    lifetime; a server rebirth restarts the numbering, so an id captured under
    a prior epoch can resolve on the new server to a live but UNRELATED pane
    (tap-24f — the keeper LaunchAgent makes rebirth a routine event, not a
    reboot rarity). Both facts come from ONE observation so pid and start_time
    are always consistent; #{start_time} is the server start, giving pid-reuse
    a second discriminator. Never memoized: the server can die and be reborn
    mid-process. lib.sh's tap_server_epoch_now mirrors this exact string,
    pinned by server-epoch-guard.test.sh (two-language lockstep, same doctrine
    as the boot id's "boot:<sec>" invariant). TAP_SERVER_EPOCH exists purely
    so tests can simulate a rebirth; empty means "unknown".
    """
    override = os.environ.get("TAP_SERVER_EPOCH")
    if override is not None:
        return override or None
    try:
        result = verbose.run(
            tmux_command("display-message", "-p", "#{pid}:#{start_time}"),
            text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
    except Exception:
        return None
    if result.returncode != 0:
        return None
    lines = result.stdout.splitlines()
    if len(lines) != 1:
        return None
    return observed_server_epoch(lines[0])


def observed_server_epoch(raw):
    """Read a `<pid>:<start_time>` field OUT of a wider tmux record and return
    the same "srv:<pid>:<start_time>" string `server_epoch_now` produces, or
    None when the field is absent or ungrammatical.

    THE single grammar authority for the epoch, so the standalone probe and the
    single-observation capture (tap-ua9l finding 7) can never disagree about
    what a generation is called. lib.sh's tap_server_epoch_from_raw is the bash
    twin, pinned by seat-corpse-lockstep.test.sh. Honours TAP_SERVER_EPOCH for
    the same reason the probe does: a test simulating a rebirth must move the
    observation and the re-check together, or the fixture proves nothing.
    """
    override = os.environ.get("TAP_SERVER_EPOCH")
    if override is not None:
        return override or None
    if not isinstance(raw, str) or not _SERVER_EPOCH_RAW.match(raw):
        return None
    return f"srv:{raw}"


def epoch_proven(entry, epoch_now):
    """True only when the row PROVES its stored ids belong to the CURRENT tmux
    server: a stamp is present, the current epoch is observable, and the two
    match.

    This is the TERMINATION-authority predicate, deliberately stricter than
    `epoch_voided_ids`' both-known rule, and the asymmetry is the point
    (tap-24f fix wave). A READER fails OPEN on an unknown epoch — an
    unobservable tmux must not condemn the whole fleet, and a wrong "gone"
    costs availability. A session-TERMINATING decision fails CLOSED — an id it
    cannot prove fresh may name a live teammate's session, and a wrong stop
    costs someone else's work. Unstamped rows (pre-wave, or written while the
    epoch was unobservable) are therefore unkillable-by-id until they
    re-register: one-time friction, chosen deliberately over the 2026-07-24
    capture where a recycled id would have replaced a bystander's session.
    """
    if not isinstance(entry, dict):
        return False
    row_epoch = entry.get("server_epoch")
    return bool(row_epoch and epoch_now and row_epoch == epoch_now)


def epoch_voided_ids(entry, epoch_now):
    """Return the entry's (pane_id, pane) with BOTH voided ("", "") when the
    row's stamp names a PRIOR server epoch — the recorded ids are from an
    earlier server instance and may not confer identity or liveness; only the
    session NAME remains meaningful. Requires both epochs known (same both-known gating as
    the boot-id guard): an unstamped row or an unobservable current epoch
    passes the ids through unchanged, erring toward legacy semantics rather
    than condemning what cannot be checked.
    """
    stored_id = str(entry.get("pane_id") or "") if isinstance(entry, dict) else ""
    pane = str(entry.get("pane") or "") if isinstance(entry, dict) else ""
    if epoch_disagrees(entry, epoch_now):
        return "", ""
    return stored_id, pane


def epoch_disagrees(entry, epoch_now):
    """True only when the row's stamp names a DIFFERENT server generation than
    the one given — the both-known rule, extracted so every consumer of it is
    literally the same code.

    Both epochs must be known. An unstamped row or an unknown current epoch is
    never a disagreement: the guard disables rather than condemning what it
    cannot check, which is what keeps a hardening pass from inventing refusals
    the pre-wave code did not have.
    """
    if not isinstance(entry, dict):
        return False
    entry_epoch = entry.get("server_epoch")
    return bool(entry_epoch and epoch_now and entry_epoch != epoch_now)


def same_pane_identity(entry, observed_pane_id, observed_epoch, observed_pane=None):
    """THE generation-aware replacement for `entry["pane_id"] == observed_id`
    (tap-ua9l finding 5) — one predicate, every site.

    Plain `==` is exactly the comparison a server rebirth defeats: the stored
    id resolves on the NEW server and compares equal to itself, so a row left
    behind by an exited server can stand in for the pane in front of us. The three
    tap-register.sh sites that used it decide who owns a mid-launch
    reservation, who owns the row being rewritten, and — the sharpest — which
    OTHER handle's row is released and has its unsettled mail adopted. A stale
    match at that last one moves obligations between seats.

    `observed_epoch` is the generation the CALLER's own pane id was observed
    under, from the same tmux record (finding 7). Comparing against a
    separately probed "now" would reopen the window this predicate closes.

    Direction, per the tranche-A doctrine: this is an AUTHORIZER ("may I treat
    this row as the pane in my hand"), so it permits LESS, never more. It
    narrows in exactly one dimension — a row whose stamp names a PRIOR
    generation stops matching. On an unstamped row or an unobservable
    generation it is plain string equality, byte-identical to the comparison it
    replaces, so no pre-wave permission is withdrawn and no pre-wave refusal is
    widened.

    `observed_pane` is OPT-IN, for the one site that already carried an
    address fallback for rows with no stored id. The other sites pass nothing
    and therefore do not acquire an arm they never had — the address-only
    residue class that widened a guard twice during tranche A.
    """
    if not isinstance(entry, dict):
        return False
    if epoch_disagrees(entry, observed_epoch):
        return False
    stored_id = str(entry.get("pane_id") or "")
    if stored_id:
        return bool(observed_pane_id) and stored_id == observed_pane_id
    if observed_pane is None:
        return False
    return bool(observed_pane) and str(entry.get("pane") or "") == observed_pane


def is_pane_id(value):
    """The EXACT tmux pane-id grammar: '%' followed by one or more ASCII
    decimal digits, nothing else. This is the single authority on what counts
    as a pane identity; every observer consults it before believing a
    resolution (sol, #xxx re-gate round 2: a bare %-prefix check accepted a
    non-numeric value like '%bogus' as an identity, which misclassified it
    PANE_RECYCLED). That verdict is NOT a blanket "replace the seat"
    authorization — each consumer acts on its own guarded policy:
    refresh (`tap-team.sh`, native admin) drops the row from the active set,
    since a recycled seat is no longer live; the register ladder
    (`tap-register.sh`) permits a take-over only for a recognized restart shape
    (a same-session relaunch whose recycled address now hosts the registering
    pane); and the launcher's session-name allocator refuses to let a recycled
    address confer identity, so the name stays occupied; and `tap out -` holds
    an invalid stored id outside removal candidacy. A `%bogus` misread as
    PANE_RECYCLED would wrongly trip those guarded paths, which is why the
    grammar is the single authority. Anything that fails this grammar
    is a broken observation channel: UNOBSERVABLE, never running, recycled, or
    gone. lib.sh's
    tap_seat_pane_observation mirrors this
    grammar with a case pattern, pinned by the lockstep's boundary corpus."""
    return (
        isinstance(value, str)
        and len(value) > 1
        and value[0] == "%"
        and value[1:].isascii()
        and value[1:].isdigit()
    )


def classify_pane(stored_id, pane, observe):
    """Four-way classification of a seat's recorded pane facts.

    `stored_id` is the recorded pane identity (may be empty for legacy rows),
    `pane` the recorded address (may be empty), `observe` the caller-supplied
    observation function described in the module docstring. The address is
    only observed when the identity was observed absent, so a live seat costs
    one observation.
    """
    if stored_id:
        # Invalid persisted identity is unproven, not evidence that
        # the recorded address was recycled by a different pane.
        if not is_pane_id(stored_id):
            return SEAT_UNOBSERVABLE
        identity = observe(stored_id)
        if identity is None:
            return SEAT_UNOBSERVABLE
        if identity:
            return SEAT_ALIVE
        if pane:
            address = observe(pane)
            if address is None:
                return SEAT_UNOBSERVABLE
            if address == stored_id:
                return SEAT_ALIVE
            if address:
                return SEAT_PANE_RECYCLED
        return SEAT_PANE_GONE
    if pane:
        address = observe(pane)
        if address is None:
            return SEAT_UNOBSERVABLE
        if address:
            return SEAT_ALIVE
    return SEAT_PANE_GONE


def is_launch_reservation(entry):
    """A row whose name is held BY DECLARATION of the launch pipeline: a
    `pending` reservation mid-claim, or a token-bearing active/launching row
    (status=active + status_reason=launching + launch_id) between pane
    binding and harness verification. One predicate, three consumers: the
    allocator's gone-seat guard, the launcher's reservation-expiry wrapper, and
    the register chooser's protection arm (sol, #xxx re-gate r3 P1 #2 — the
    chooser protected only `pending` and pane-probed a launching row, letting
    a second register take over a mid-launch handle whose just-bound pane
    stopped before verification)."""
    if not isinstance(entry, dict):
        return False
    status = entry.get("status")
    if status == "pending":
        return True
    return (
        status == "active"
        and entry.get("status_reason") == "launching"
        and bool(entry.get("launch_id"))
    )


def parse_timestamp(value):
    """Epoch seconds for an ISO-8601 registry timestamp, or None."""
    if not isinstance(value, str) or not value:
        return None
    try:
        normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
        parsed = datetime.datetime.fromisoformat(normalized)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=datetime.timezone.utc)
    return parsed.timestamp()


def boot_ids_match(stored, current, current_legacy=None, tolerance_seconds=5):
    """Match exact boot identities, admitting only numeric legacy stamps within
    a narrow tolerance of the current boot epoch."""
    if not stored or not current:
        return False
    if stored == current:
        return True
    match = re.fullmatch(r"boot:(\d+)", str(stored))
    legacy = re.fullmatch(r"boot:(\d+)", str(current_legacy or ""))
    if not match or not legacy:
        return False
    return abs(int(match.group(1)) - int(legacy.group(1))) <= tolerance_seconds


def launch_reservation_expired(entry, live_sessions, now_epoch, boot_now, boot_legacy_now=None):
    """THE reservation-expiry rule, pure over supplied facts — the single
    implementation behind the allocator's `pending_reservation_expired`
    wrapper and the register chooser's launching-row protection. A
    reservation-shaped row (`is_launch_reservation`) is protected while its
    recorded session is live or its probe grace has not elapsed; an
    unobservable session snapshot (None) is fail-closed NOT-expired unless
    independent boot identity proves the reservation belongs to a prior boot.
    A reservation stamped under a PRIOR boot is expired the instant it is
    noticed (its reserved tmux session ended at reboot) — only when both boot ids are
    known; a caller that cannot know its boot id passes None and merely errs
    toward longer protection."""
    if not is_launch_reservation(entry):
        return False
    stored_id = entry.get("pane_id")
    if stored_id and not is_pane_id(stored_id):
        # Damaged identity is unobservable, never proof that a launch token is
        # abandoned and may be replaced.
        return False
    session = entry.get("session")
    if not isinstance(session, str) or not session:
        return False
    if live_sessions is not None and session in live_sessions:
        return False
    entry_boot = entry.get("boot_id")
    if (entry_boot is not None and boot_now is not None
            and not boot_ids_match(entry_boot, boot_now, boot_legacy_now)):
        return True
    if live_sessions is None:
        return False
    registered_at = parse_timestamp(entry.get("registered_at"))
    return (
        registered_at is not None
        and now_epoch is not None
        and now_epoch - registered_at >= PENDING_RESERVATION_GRACE_SECONDS
    )


def pane_observation(target):
    """The canonical tmux observation: (pane_id, session_name) observed at a
    live target, ("", "") when the target was OBSERVED absent, None when no
    observation could be made. One tmux call so liveness and session are
    always consistent.

    Absence requires the SERVER to have answered: rc 0 with an empty
    expansion (tmux 3.6a gone target), or a nonzero exit whose stderr says
    "can't find ..." (the classic gone-target reply — the error IS the
    answer). A nonzero exit with any other stderr, a missing binary, or an
    exception is None: the probe failed, and a failed probe is not an
    observation. A resolution that is not a %-prefixed pane id is unexpected-format —
    a broken observation channel, likewise never evidence of absence.
    """
    if not target:
        return "", ""
    try:
        result = verbose.run(
            tmux_command("display-message", "-p", "-t", target, "#{pane_id}\t#{session_name}"),
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
    except Exception:
        return None
    if result.returncode != 0:
        return ("", "") if "can't find" in (result.stderr or "") else None
    raw = result.stdout
    if raw in ("", "\n"):
        # The ONE rc-0 absence shape: a truly empty expansion (tmux 3.6a gone
        # target). Nothing else at rc 0 may read as absence — RECORD FRAMING
        # is part of the observation contract (sol, #xxx re-gate r4): an
        # empty-id-with-session line, whitespace, a truncated record, or
        # multiple lines is a garbled channel, and partitioning it into an
        # empty pid before the grammar gate silently converted unexpected-format
        # evidence into observed-absence.
        return "", ""
    lines = raw.splitlines()
    if len(lines) != 1:
        return None
    pid, tab, sess = lines[0].partition("\t")
    if not tab or not is_pane_id(pid) or not sess:
        # Not exactly one complete live record (pane id + tab + session):
        # no observation.
        return None
    return pid, sess


def seat_verdict(entry):
    """Classify a registry entry's recorded pane facts through
    `classify_pane` over the canonical observation, returning
    (verdict, live_pane_id, live_session). `classify_pane` makes at most one
    LIVE observation, so the recorded live pane is THE pane that proves the
    verdict. This is the decision function the register chooser executes; the
    lockstep drives it directly against the shared fixtures."""
    live = {"pid": "", "session": ""}

    def observe(target):
        obs = pane_observation(target)
        if obs is None:
            return None
        pid, sess = obs
        if pid:
            live["pid"], live["session"] = pid, sess
        return pid

    # tap-24f: void ids captured under a PRIOR server epoch BEFORE classifying —
    # a recycled id resolving on the reborn server would otherwise read ALIVE
    # and drive handle take-over/protection from a stranger's pane. Voided ids
    # classify PANE_GONE, which is exact: both epochs were positively observed
    # to differ, so the recorded identities are certainly not running.
    stored_id, pane = epoch_voided_ids(entry, server_epoch_now())
    verdict = classify_pane(stored_id, pane, observe)
    return verdict, live["pid"], live["session"]
