#!/usr/bin/env bash
# Public done changes no obligation state; its sole write is the audit record.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP="$ROOT/bin/tap"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
export TAP_HOME="$WORK/bus" TAP_INDEX_HOME="$WORK/index"
mkdir -p "$TAP_HOME/payloads" "$TAP_HOME/receipts" "$TAP_INDEX_HOME"
printf '%s\n' '{"team":{"name":"team"},"agents":{"worker":{"status":"active","delivery":"poll","instance":"worker|current"},"peer":{"status":"active","delivery":"poll","instance":"peer|current"}}}' > "$TAP_HOME/registry.json"
fail() { echo "done-alias: $*" >&2; exit 1; }
for reply in expected settle-only; do
  id="alias-$reply"
  cat > "$TAP_HOME/payloads/$id.md" <<PAYLOAD
---
id: $id
from: peer
to: worker
kind: discuss
reply: $reply
path: $TAP_HOME/payloads/$id.md
---
work remains open
PAYLOAD
done
# Malformed mail would expose an accidental opportunistic poll/drain mutation.
printf 'malformed remains untouched\n' > "$TAP_HOME/payloads/broken.md"
snapshot() {
  python3 - "$TAP_HOME" <<'PY'
import hashlib,pathlib,sys
root=pathlib.Path(sys.argv[1])
for p in sorted(root.rglob('*')):
 if p.is_file() and p.name!='done-alias-hits.jsonl': print(p.relative_to(root),hashlib.sha256(p.read_bytes()).hexdigest())
PY
}
before="$(snapshot)"
for reply in expected settle-only; do
  rc=0; "$TAP" done "alias-$reply" --by worker >"$WORK/out" 2>&1 || rc=$?
  [ "$rc" = 2 ] || { cat "$WORK/out" >&2; fail "open $reply exit=$rc"; }
  if [ "$reply" = expected ]; then
    grep -q 'tap reply alias-expected --by worker -f <file>' "$WORK/out" || fail 'ask repair missing'
  else
    grep -q 'tap read alias-settle-only --by worker' "$WORK/out" || fail 'note repair missing'
  fi
done
[ "$(snapshot)" = "$before" ] || fail 'public done changed a payload, receipt, registry, or generation'
LOG="$TAP_HOME/receipts/done-alias-hits.jsonl"
python3 - "$LOG" <<'PY'
import json,sys
rows=[json.loads(x) for x in open(sys.argv[1])]
assert len(rows)==2,rows
assert all(r['action']=='done_alias_hit' and r['actor']=='worker' and r['instance']=='worker|current' and r['fixture'] is True and r['rc']==2 for r in rows),rows
PY
rc=0; env -u TAP_SELF "$TAP" done --unrecognized >"$WORK/out" 2>&1 || rc=$?
[ "$rc" != 0 ] || fail 'malformed actorless invocation succeeded'
[ "$(wc -l < "$LOG" | tr -d ' ')" = 2 ] || fail 'actorless invocation wrote an event'
# Within the runner's isolated HOME, unset only the index pin to exercise the
# production-counter branch. No launch/register or external state is accessed.
rc=0; env -u TAP_INDEX_HOME "$TAP" done alias-expected --by worker >"$WORK/out" 2>&1 || rc=$?
[ "$rc" = 2 ] || fail 'live-shaped invocation did not refuse'
[ "$(python3 "$ROOT/skills/tap/scripts/tap-done-alias-count.py" "$LOG")" = 1 ] || fail 'counter includes fixtures or misses live-shaped hit'
# Real reply still discharges its ask via the private, validated primitive.
rm "$TAP_HOME/payloads/broken.md"
printf 'answer\n' > "$WORK/answer.md"
"$TAP" reply alias-expected --by worker -f "$WORK/answer.md" >"$WORK/reply.out" 2>&1 || { cat "$WORK/reply.out" >&2; fail 'private reply primitive failed'; }
python3 - "$TAP_HOME/receipts/alias-expected.done" "$LOG" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]));assert r['via']=='reply' and r['by']=='worker',r
assert len(open(sys.argv[2]).readlines())==3,'private primitive counted as alias'
PY
# Guards: public argv must never reach settlement (even with a smuggled
# --reply-payload), and the private settler filename refuses without it.
cat > "$TAP_HOME/payloads/alias-guard.md" <<PAYLOAD
---
id: alias-guard
from: peer
to: worker
kind: discuss
reply: expected
path: $TAP_HOME/payloads/alias-guard.md
---
guard payload stays open
PAYLOAD
guard_rows_before="$(wc -l < "$LOG" | tr -d ' ')"
rc=0; "$TAP" done alias-guard --by worker --reply-payload "$WORK/answer.md" >"$WORK/out" 2>&1 || rc=$?
[ "$rc" != 0 ] || fail 'public done reached settlement via --reply-payload'
[ ! -e "$TAP_HOME/receipts/alias-guard.done" ] || fail 'public argv settled an obligation'
[ "$(wc -l < "$LOG" | tr -d ' ')" = "$((guard_rows_before + 1))" ] || fail 'public --reply-payload argv bypassed the retirement alias'
python3 - "$LOG" <<'PY'
import json,sys
row=json.loads(open(sys.argv[1]).readlines()[-1])
assert row['id']=='alias-guard' and row['rc']==2,row
PY
rc=0; bash "$ROOT/skills/tap/scripts/tap-reply-settle.sh" alias-guard --by worker >"$WORK/out" 2>&1 || rc=$?
[ "$rc" != 0 ] || fail 'private settler accepted a call without --reply-payload'
[ ! -e "$TAP_HOME/receipts/alias-guard.done" ] || fail 'private settler settled without --reply-payload'
rc=0; bash "$ROOT/skills/tap/scripts/tap-reply-settle.sh" alias-guard --by worker --epoch --reply-payload >"$WORK/out" 2>&1 || rc=$?
[ "$rc" != 0 ] || fail 'flag-as-value bypass reached the settler'
[ ! -e "$TAP_HOME/receipts/alias-guard.done" ] || fail 'flag-as-value call settled without evidence'
# Explicit unindexed pointer and arbitrary epoch survive in the runnable repair.
FOREIGN="$WORK/foreign/payloads/foreign-note.md"
mkdir -p "$(dirname "$FOREIGN")"
cat > "$FOREIGN" <<PAYLOAD
---
id: foreign-note
from: peer
to: worker
kind: discuss
reply: settle-only
path: $FOREIGN
---
a note outside the enrolled index
PAYLOAD
rc=0; "$TAP" done foreign-note --by worker --payload "$FOREIGN" --epoch 'epoch value' >"$WORK/out" 2>&1 || rc=$?
[ "$rc" = 2 ] || fail 'explicit pointer alias did not refuse'
python3 - "$LOG" "$FOREIGN" "$TAP" <<'PY'
import json,pathlib,shlex,subprocess,sys
record=json.loads(open(sys.argv[1]).readlines()[-1]);cmd=shlex.split(record['repair'])
assert cmd[0]=='tap' and cmd[1]=='read' and cmd[2]=='path='+sys.argv[2],cmd
cmd[0]=sys.argv[3]
r=subprocess.run(cmd,capture_output=True,text=True)
assert r.returncode==0,(r.stdout,r.stderr)
p=pathlib.Path(sys.argv[2]).parent.parent/'receipts'/'foreign-note.done'
receipt=json.loads(p.read_text());assert receipt['via']=='read' and receipt['epoch']=='epoch value',receipt
PY
rc=0; python3 "$ROOT/skills/tap/scripts/tap-done-alias-count.py" "$WORK/missing.jsonl" >"$WORK/count.out" 2>&1 || rc=$?
[ "$rc" = 2 ] || fail 'missing audit evidence reported zero use'
# Audit writes honor the same bus reset fence as other receipt writers.
count_before="$(wc -l < "$LOG")"
printf '{}\n' > "$TAP_HOME/reset.fence.json"
rc=0; "$TAP" done alias-settle-only --by worker >"$WORK/out" 2>&1 || rc=$?
[ "$rc" != 0 ] || fail 'audit crossed reset fence'
grep -q 'mid-reset' "$WORK/out" || fail 'reset refusal not disclosed'
[ "$(wc -l < "$LOG")" = "$count_before" ] || fail 'fenced invocation wrote audit'

# ── Bus selection under the retirement alias (PR #xxxx review) ────────────
# Enrolled two-team fixture: dotdir buses, acting team-registry.json, machine
# index. The standalone pin above stays authoritative for its own cases; these
# prove selection when TAP_HOME is unset (native door) or inherited (bash door).
ALPHA="$WORK/alpha"; ALPHA_BUS="$ALPHA/.tap/bus"
BETA="$WORK/beta"; BETA_BUS="$BETA/.tap/bus"
for team in alpha beta; do
  root="$WORK/$team"
  mkdir -p "$root/.tap/bus/payloads" "$root/.tap/bus/receipts"
  git init -q "$root"
  printf '%s\n' "{\"schema\":\"0.20\",\"team\":{\"name\":\"$team\",\"worktree_root\":\"$root\"},\"seats\":{\"${team}seat\":{\"status\":\"active\",\"delivery\":\"poll\",\"instance\":\"${team}seat|cur\"}}}" > "$root/.tap/team-registry.json"
done
printf '%s\n' '{"schema":"0.20","teams":{"alpha":{"root":"'"$ALPHA"'","registry_location":"'"$ALPHA"'/.tap/team-registry.json","state":"registered"},"beta":{"root":"'"$BETA"'","registry_location":"'"$BETA"'/.tap/team-registry.json","state":"registered"}}}' > "$TAP_INDEX_HOME/global-registry.json"
payload_at() { # <bus> <id> <to> <reply> <to_team>
  mkdir -p "$1/payloads" "$1/receipts"
  cat > "$1/payloads/$2.md" <<PAYLOAD
---
id: $2
from: sender
to: $3
to_team: $5
kind: discuss
reply: $4
path: $1/payloads/$2.md
---
selection fixture body
PAYLOAD
}
# (P1) Implicit bus: with no exported TAP_HOME the alias must anchor the
# caller's enrolled bus BEFORE its lookups and audit, never the caller cwd.
payload_at "$ALPHA_BUS" p1-open worker settle-only alpha
p1rc=0; ( cd "$ALPHA" && env -u TAP_HOME "$TAP" done p1-open --by worker ) >"$WORK/p1.out" 2>&1 || p1rc=$?
[ "$p1rc" = 2 ] || { cat "$WORK/p1.out" >&2; fail "implicit-bus done exit=$p1rc"; }
[ ! -e "$ALPHA/receipts" ] || fail 'implicit bus audit landed relative to the caller cwd'
[ -f "$ALPHA_BUS/receipts/done-alias-hits.jsonl" ] || fail 'implicit bus audit missing from the selected team bus'
grep -q '"id":"p1-open"' "$ALPHA_BUS/receipts/done-alias-hits.jsonl" || fail 'implicit bus audit row missing'
[ ! -e "$ALPHA_BUS/receipts/p1-open.done" ] || fail 'implicit-bus done settled an obligation'
# (P2) --team must replace a DERIVED (non-env) inherited home through the bash
# door, while an explicit caller pin keeps its bus.
payload_at "$BETA_BUS" p2-team alphaseat settle-only beta
payload_at "$ALPHA_BUS" p2-pin alphaseat settle-only alpha
p2rc=0; ( cd "$ALPHA" && env -u TAP_HOME bash "$ROOT/skills/tap/scripts/tap.sh" done p2-team --by alphaseat --team beta ) >"$WORK/p2.out" 2>&1 || p2rc=$?
[ "$p2rc" = 2 ] || { cat "$WORK/p2.out" >&2; fail "team override done exit=$p2rc"; }
grep -q '"id":"p2-team"' "$BETA_BUS/receipts/done-alias-hits.jsonl" 2>/dev/null || fail '--team override audited outside the selected team bus'
[ ! -e "$ALPHA_BUS/receipts/p2-team.done" ] || fail '--team override settled on the ambient bus'
if [ -f "$ALPHA_BUS/receipts/done-alias-hits.jsonl" ]; then
  grep -q '"id":"p2-team"' "$ALPHA_BUS/receipts/done-alias-hits.jsonl" && fail '--team override audited on the ambient bus'
fi
p2pinrc=0; ( cd "$ALPHA" && env TAP_HOME="$ALPHA_BUS" TAP_BUS_RULE=env "$TAP" done p2-pin --by alphaseat --team beta ) >"$WORK/p2pin.out" 2>&1 || p2pinrc=$?
[ "$p2pinrc" = 2 ] || fail "caller pin done exit=$p2pinrc"
grep -q '"id":"p2-pin"' "$ALPHA_BUS/receipts/done-alias-hits.jsonl" || fail 'explicit caller pin did not keep its bus'
# (P3) Foreign-bus replay: the open-work count must use the ACTOR's selected
# team, not the resolved payload's bus.
payload_at "$ALPHA_BUS" p3-replay betaseat expected beta
payload_at "$ALPHA_BUS" p3-open betaseat settle-only beta
printf '%s\n' '{"at":"2026-09-19T00:00:00.000+00:00"}' > "$ALPHA_BUS/receipts/p3-replay.done"
p3rc=0; ( cd "$BETA" && env -u TAP_HOME "$TAP" done p3-replay --by betaseat --payload "$ALPHA_BUS/payloads/p3-replay.md" ) >"$WORK/p3.out" 2>&1 || p3rc=$?
[ "$p3rc" = 1 ] || { cat "$WORK/p3.out" >&2; fail "foreign replay exit=$p3rc"; }
grep -q 'you have 1 open: p3-open' "$WORK/p3.out" || fail "foreign open work miscounted: $(cat "$WORK/p3.out")"

echo 'done-alias: public refusals preserve obligations, audit once, exclude fixture hits; real reply settles'
