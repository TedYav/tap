#!/usr/bin/env bash
# tap-o4ae: fixture env (TMUX=/fake/socket, …) must stay in this process.
# Refuse `source` so an interactive shell cannot inherit top-level exports.
# Must run BEFORE any `set -o` so a refusal does not mutate caller options.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# socket-unreachable-no-suspend.test.sh — tap-o4ae: unreachable tmux must
# NOT false-suspend a registry seat. A dead socket is not a dead pane.
# Fail-closed: missing binary, connect errors, AND any nonempty probe stderr
# all refuse the pane_gone write. Empty-stderr mock gap stays reachable so
# legitimate dead-pane smokes still exit 3.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP="$ROOT/scripts/tap.sh"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
export TAP_HOME="$WORK/bus" TAP_INDEX_HOME="$WORK/index"
mkdir -p "$TAP_HOME/payloads" "$TAP_HOME/receipts" "$TAP_HOME/spool"

seed_alice() {
  (
    "$TAP" register bob --delivery poll >/dev/null
  )
  python3 -B - "$TAP_HOME/registry.json" <<'PY'
import json, sys
path = sys.argv[1]
reg = json.load(open(path))
reg.setdefault("agents", {})["alice"] = {
    "status": "active",
    "delivery": "pane",
    "pane": "demo/alice:0.0",
    "pane_id": "%901",
    "harness": "codex",
}
with open(path, "w") as fh:
    json.dump(reg, fh, indent=2, sort_keys=True)
    fh.write("\n")
PY
}

assert_refused_no_suspend() {
  local label="$1" rc="$2" out="$3"
  python3 -B - "$TAP_HOME/registry.json" "$rc" "$out" "$label" <<'PY'
import json, sys, re
agents = json.load(open(sys.argv[1]))["agents"]
rc = int(sys.argv[2])
out = sys.argv[3]
label = sys.argv[4]
alice = agents["alice"]
assert alice.get("status") == "active", (label, "false-suspended", alice)
assert not alice.get("status_reason"), (label, alice)
assert rc == 1, (label, rc, out)
assert re.search(r'tmux_unreachable', out), (label, out)
print(f"socket-unreachable-no-suspend: {label} refuses pane_gone write: ok")
PY
}

# --- (1) Exact #xxx leak shape: synthetic socket, real tmux binary. ----------
# Socket must live inside TMUX_TMPDIR (suite sandbox) so the isolation guard
# does not classify a path outside the sandbox as tmux-escape.
seed_alice
before="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["agents"]["alice"]["status"])' "$TAP_HOME/registry.json")"
[ "$before" = active ] || { echo "socket-unreachable: fixture alice not active" >&2; exit 1; }
DEAD_SOCK="${TMUX_TMPDIR:-$WORK}/dead.sock"
mkdir -p "$(dirname "$DEAD_SOCK")"
rm -f "$DEAD_SOCK"

set +e
out="$(
  TMUX="$DEAD_SOCK" "$TAP" send alice -m "o4ae probe" --from bob --json 2>&1
)"
rc=$?
set -e
assert_refused_no_suspend "TMUX=sandbox-dead-socket" "$rc" "$out"

# --- (2) Missing tmux binary: shadow tmux, leave PATH unchanged. -------------
python3 -B - "$TAP_HOME/registry.json" <<'PY'
import json, sys
path = sys.argv[1]
reg = json.load(open(path))
reg["agents"]["alice"]["status"] = "active"
reg["agents"]["alice"].pop("status_reason", None)
with open(path, "w") as fh:
    json.dump(reg, fh, indent=2, sort_keys=True)
    fh.write("\n")
PY
# Do not strip PATH: Ubuntu co-locates tmux with dirname in /usr/bin, and
# dropping that dir killed scripts/tap.sh before the missing-tmux path ran.
# A subshell-exported tmux() shadows the binary for bash children (tap.sh /
# tap-send.sh / lib.sh) while dirname, python3, and env stay on PATH.
set +e
out="$(
  tmux() { printf '%s\n' 'tmux: command not found' >&2; return 127; }
  export -f tmux
  "$TAP" send alice -m "missing tmux" --from bob --json 2>&1
)"
rc=$?
set -e
assert_refused_no_suspend "missing-tmux" "$rc" "$out"

# --- (3) Arbitrary nonempty probe stderr (not a known connect literal). ------
FAKE_BIN="$WORK/fake-bin"
mkdir -p "$FAKE_BIN"
cat > "$FAKE_BIN/tmux" <<'TMUX'
#!/usr/bin/env bash
# Fail every display-message with a custom nonempty stderr — must still refuse.
if [ "${1:-}" = "display-message" ]; then
  echo "weird backend glitch: protocol v99" >&2
  exit 1
fi
exit 1
TMUX
chmod +x "$FAKE_BIN/tmux"
python3 -B - "$TAP_HOME/registry.json" <<'PY'
import json, sys
path = sys.argv[1]
reg = json.load(open(path))
reg["agents"]["alice"]["status"] = "active"
reg["agents"]["alice"].pop("status_reason", None)
with open(path, "w") as fh:
    json.dump(reg, fh, indent=2, sort_keys=True)
    fh.write("\n")
PY
set +e
out="$(
  PATH="$FAKE_BIN:$PATH" TMUX=/fake/socket \
    "$TAP" send alice -m "arbitrary err" --from bob --json 2>&1
)"
rc=$?
set -e
assert_refused_no_suspend "arbitrary-nonempty-stderr" "$rc" "$out"

# --- (4) Empty-stderr mock no-target gap: still reachable → dead pane suspends.
cat > "$FAKE_BIN/tmux" <<'TMUX'
#!/usr/bin/env bash
# Implements -t probes; no-target display-message fails silently (empty stderr).
# That is the sole reachable-on-failure exception — dead panes must still suspend.
cmd="${1:-}"; shift || true
case "$cmd" in
  display-message)
    target=""; fmt=""
    while [ "$#" -gt 0 ]; do
      case "$1" in
        -p) shift ;;
        -t) target="${2:-}"; shift 2 ;;
        *)  fmt="$1"; shift ;;
      esac
    done
    if [ -z "$target" ]; then
      exit 1   # empty stderr — mock gap; treat server reachable
    fi
    case "$fmt" in
      *pane_id*) exit 1 ;;  # dead target
      *) echo ""; exit 0 ;;
    esac ;;
  *) exit 1 ;;
esac
TMUX
chmod +x "$FAKE_BIN/tmux"
python3 -B - "$TAP_HOME/registry.json" <<'PY'
import json, sys
path = sys.argv[1]
reg = json.load(open(path))
reg["agents"]["alice"]["status"] = "active"
reg["agents"]["alice"].pop("status_reason", None)
with open(path, "w") as fh:
    json.dump(reg, fh, indent=2, sort_keys=True)
    fh.write("\n")
PY
set +e
out="$(
  PATH="$FAKE_BIN:$PATH" TMUX=/fake/socket \
    "$TAP" send alice -m "dead pane mock" --from bob --json 2>&1
)"
rc=$?
set -e
python3 -B - "$TAP_HOME/registry.json" "$rc" "$out" <<'PY'
import json, sys, re
agents = json.load(open(sys.argv[1]))["agents"]
rc = int(sys.argv[2])
out = sys.argv[3]
alice = agents["alice"]
assert alice.get("status") == "suspended", ("empty-stderr mock should suspend", alice)
assert rc == 3, (rc, out)
assert re.search(r'pane_gone', out), out
print("socket-unreachable-no-suspend: empty-stderr mock gap still suspends dead pane: ok")
PY

# Sourcing this file must refuse (isolation hygiene).
set +e
# tap-52ys: derive this file's own path rather than naming its directory. The
# hardcoded skills/tap/scripts/smoke/... path broke the moment the file moved to
# regress/ — a self-referential test must not encode which bucket it lives in.
source_out="$(bash -c 'source "$1"' _ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")" 2>&1)"
source_rc=$?
set -e
[ "$source_rc" -ne 0 ] || { echo "socket-unreachable: sourced smoke should refuse" >&2; exit 1; }
[[ "$source_out" == *"do not source"* ]] \
  || { echo "socket-unreachable: source refusal missing (got: $source_out)" >&2; exit 1; }

echo "socket-unreachable-no-suspend: ok"
