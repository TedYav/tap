#!/usr/bin/env bash
# shared-checkout-pull-rebase.test.sh — a primary `git pull --rebase` may use
# detached HEAD internally; the shared-checkout guard must leave it alone.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

REMOTE="$TMP/remote.git"
SEED="$TMP/seed"
PRIMARY="$TMP/primary"
OTHER="$TMP/other"

git init -q --bare "$REMOTE"
git init -q "$SEED"
git -C "$SEED" symbolic-ref HEAD refs/heads/main
git -C "$SEED" config user.email me@example.invalid
git -C "$SEED" config user.name smoke
printf 'base\n' > "$SEED/base"
git -C "$SEED" add base
git -C "$SEED" commit -qm base
git -C "$SEED" remote add origin "$REMOTE"
git -C "$SEED" push -q -u origin main
git --git-dir="$REMOTE" symbolic-ref HEAD refs/heads/main

git clone -q "$REMOTE" "$PRIMARY"
git clone -q "$REMOTE" "$OTHER"
for repo in "$PRIMARY" "$OTHER"; do
  git -C "$repo" config user.email me@example.invalid
  git -C "$repo" config user.name smoke
done

mkdir -p "$PRIMARY/.beads/hooks"
cp "$ROOT/.beads/hooks/post-checkout" "$PRIMARY/.beads/hooks/post-checkout"
chmod +x "$PRIMARY/.beads/hooks/post-checkout"
git -C "$PRIMARY" config core.hooksPath "$PRIMARY/.beads/hooks"

printf 'local\n' > "$PRIMARY/local"
git -C "$PRIMARY" add local
git -C "$PRIMARY" commit -qm local

printf 'remote\n' > "$OTHER/remote"
git -C "$OTHER" add remote
git -C "$OTHER" commit -qm remote
git -C "$OTHER" push -q

set +e
pull_output="$(git -C "$PRIMARY" pull --rebase 2>&1)"
pull_rc=$?
set -e
[ "$pull_rc" -eq 0 ] || {
  echo "shared-checkout-pull-rebase: pull --rebase should finish (got $pull_rc)" >&2
  echo "$pull_output" >&2
  exit 1
}
[[ "$pull_output" != *"shared primary checkout is pinned"* ]] || {
  echo "shared-checkout-pull-rebase: guard fired during rebase" >&2
  echo "$pull_output" >&2
  exit 1
}
[ "$(git -C "$PRIMARY" branch --show-current)" = main ] || {
  echo "shared-checkout-pull-rebase: rebase did not return to main" >&2
  exit 1
}
[ -f "$PRIMARY/local" ] && [ -f "$PRIMARY/remote" ] || {
  echo "shared-checkout-pull-rebase: diverged commits did not both land" >&2
  exit 1
}
(cd "$PRIMARY" && [ ! -d "$(git rev-parse --git-path rebase-merge)" ] && [ ! -d "$(git rev-parse --git-path rebase-apply)" ]) || {
  echo "shared-checkout-pull-rebase: rebase state was left behind" >&2
  exit 1
}

echo "shared-checkout-pull-rebase: diverged pull --rebase finishes on main without the guard: ok"
