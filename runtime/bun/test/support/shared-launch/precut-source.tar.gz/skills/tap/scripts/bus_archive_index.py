"""Read indexed settled history without walking archive buckets."""
import json
import os
import re
import stat
import sys


def rows(bus, strict=False):
    archive = os.path.join(bus, 'archive')
    if not os.path.lexists(archive):
        return {}
    if os.path.islink(archive) or not os.path.isdir(archive):
        raise ValueError('unsafe archive directory')
    path = os.path.join(archive, 'index.ndjson')
    if not os.path.lexists(path):
        return {}
    if os.path.islink(path) or not stat.S_ISREG(os.stat(path).st_mode):
        raise ValueError('unsafe archive index')
    result = {}
    invalid = False
    with open(path, encoding='utf-8') as stream:
        for line in stream:
            if not line.strip():
                continue
            try:
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    fragment = line.strip()
                    if not fragment.endswith('}') and (fragment.startswith('{"id":') or '{"id":'.startswith(fragment)):
                        continue
                    raise
                if (not isinstance(row, dict) or not isinstance(row.get('id'), str) or not isinstance(row.get('month'), str) or not isinstance(row.get('settled_at'), str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', str(row.get('id', '')))
                        or not re.fullmatch(r'\d{4}-(?:0[1-9]|1[0-2])', str(row.get('month', '')))
                        or not re.fullmatch(r'[a-f0-9]{64}', str(row.get('payload_sha256', '')))
                        or not isinstance(row.get('receipts'), list)
                        or any(not isinstance(n, str) or os.path.basename(n) != n or not n.startswith(row['id'] + '.') for n in row['receipts'])):
                    raise ValueError('invalid archive index record')
                from datetime import datetime
                datetime.fromisoformat(row['settled_at'].replace('Z', '+00:00'))
                if row['id'] in result and result[row['id']] != row:
                    raise ValueError('conflicting archive index records')
                result[row['id']] = row
            except (ValueError, TypeError):
                invalid = True
    if invalid:
        print(f"tap: unreadable rows in {path}; ignoring them for history lookup; run tap bus archive", file=sys.stderr)
        if strict:
            raise ValueError("archive index unreadable; refusing placement")
    return result


def payload(bus, row):
    import hashlib
    path = os.path.join(bus, 'archive', row['month'], 'payloads', row['id'] + '.md')
    for part in [os.path.join(bus, 'archive', row['month']), os.path.dirname(path)]:
        if os.path.islink(part) or not os.path.isdir(part):
            raise ValueError('unsafe archive path')
    receipt_dir = os.path.join(bus, 'archive', row['month'], 'receipts')
    if os.path.islink(receipt_dir) or not os.path.isdir(receipt_dir):
        raise ValueError('unsafe archive receipt directory')
    for name in row['receipts']:
        receipt = os.path.join(receipt_dir, name)
        if os.path.islink(receipt) or not os.path.isfile(receipt):
            raise ValueError('missing or unsafe archived receipt')
    if os.path.islink(path) or not os.path.isfile(path):
        raise ValueError('missing or unsafe archived payload')
    with open(path, 'rb') as stream:
        if hashlib.sha256(stream.read()).hexdigest() != row['payload_sha256']:
            raise ValueError('archived payload hash mismatch')
    return os.path.realpath(path)


if __name__ == '__main__':
    import sys
    try:
        row = rows(sys.argv[1], strict=len(sys.argv) > 3 and sys.argv[3] == 'contains').get(sys.argv[2])
        if len(sys.argv) > 3 and sys.argv[3] == 'contains':
            raise SystemExit(0 if row else 1)
        print(payload(sys.argv[1], row) if row else '')
    except Exception as error:
        print('archive lookup: ' + str(error), file=sys.stderr)
        raise SystemExit(2)
