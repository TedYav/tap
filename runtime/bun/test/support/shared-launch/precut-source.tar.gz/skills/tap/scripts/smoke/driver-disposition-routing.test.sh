#!/usr/bin/env bash
# Refuse `source` so an interactive shell cannot inherit top-level exports.
# Must run BEFORE any `set -o` so a refusal does not mutate caller options.
# This fixture exports TMUX (it points the courier at a fake tmux), which is
# exactly what smoke-source-guard-inventory.test.sh sweeps for.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# driver-disposition-routing.test.sh — the courier routes on the DISPOSITION, not
# on a status number (TAP 1.0, tap-49kp6; found by sol-pinnacle's gate review of #xxx).
#
# Before native drivers became selectable, every failure branch in tap-send.sh
# was keyed on a tmux status code. A native driver's outcome table can map
# an unfamiliar rc — say 7 — to `stop-ambiguous` / `effect: possible`. Under
# status-keyed routing that falls through to the retryable defer and gets SPOOLED
# FOR RETRY, even though the attempt may already have taken effect. A retry after
# a possible effect is a duplicate delivery, and `retry-next-rung` REQUIRES
# `effect: none` precisely so that cannot happen.
#
# So this drives the real courier end to end with a native driver returning an
# rc no tmux path has ever produced, and asserts the send does NOT enter the
# retry spool.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP_SHIPPED="$ROOT/scripts/tap.sh"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

BUS="$WORK/repo/.tap/bus"; mkdir -p "$BUS/payloads" "$BUS/receipts" "$WORK/repo"
# tap-7r3fn.20: every arm below sends to the SAME seat, and each delivery opens
# that seat's window — so from the second send on, the courier would park inside
# the window instead of reaching the driver disposition each arm exists to test.
# This file is about WHICH DOOR a send goes through and what it does with the
# return code, never about when mail arrives; delivery-window-drain owns that.
# Clearing the clock states that premise instead of inheriting it.
# tap-7r3fn.20: this suite is about DISPOSITION ROUTING, not delivery windows,
# and it sends repeatedly to one seat — so every send after the first would park
# in that seat's window instead of reaching the routing under test. A window of
# zero is the seam that turns it off (ruling 24 keeps this variable overriding
# the short window), and it says so without knowing where the clock is stored:
# an earlier version cleared `$BUS/delivery` by hand, which put this fixture's
# correctness at the mercy of a storage layout it has no reason to know.
export TAP_AUTOSETTLE_HOLD_SECONDS=0
# This fixture asserts durable parking, not background delivery. Do not let
# detached waiters outlive the temporary tree and its fake tmux.
export TAP_SPOOL_DISABLE_DELIVERER=1
export TAP_HOME="$BUS"
XDG_CONFIG_HOME="$WORK/config"; export XDG_CONFIG_HOME
mkdir -p "$XDG_CONFIG_HOME/tap"
DRIVER_DIR="$WORK/drivers"; mkdir -p "$DRIVER_DIR"
export TAP_DRIVER_DIR="$DRIVER_DIR"
# THIS SUITE RUNS AGAINST A MUTATED COPY OF THE TREE, and that is deliberate.
#
# It drives the REAL courier as a child process, so a function override in this
# shell cannot reach it -- the child sources lib.sh fresh. The obvious fix was an
# environment seam, and sol-pinnacle showed on a live probe that an env-settable
# wired set restores the exact failure the gate exists to close -- one malformed
# native invocation, then the parked payload crossing to tmux on the next drain,
# because redelivery does not go through the dispatcher. A
# test seam that ships is not a test seam; it is a feature with a test-shaped
# comment.
#
# So the seam lives HERE instead: copy the tree, widen the wired list in the
# copy, and run the courier out of the copy. Wiredness stays a code fact in the
# shipped file, and the mutation is visible in this suite rather than exported
# from an operator's shell.
#
# The copy is then DIFFED against the shipped file, and the diff must touch
# nothing but `tap_driver_wired_list`. Without that check this suite could drift
# into testing a courier that differs from the shipped one in ways nobody
# declared -- a fixture more generous than the world, one directory up.
TREE="$WORK/tree"; mkdir -p "$TREE"
cp -R "$ROOT/scripts" "$TREE/scripts"
mkdir -p "$TREE/skills"; cp -R "$ROOT/skills/tap" "$TREE/skills/tap"
mkdir -p "$TREE/runtime/bun"; cp -R "$ROOT/runtime/bun/src" "$TREE/runtime/bun/src"
LIB_SHIPPED="$ROOT/skills/tap/scripts/lib.sh"
LIB_COPY="$TREE/skills/tap/scripts/lib.sh"
python3 - "$LIB_COPY" <<'ENDPY'
import re, sys
p = sys.argv[1]
s = open(p).read()
fixtures = "chatty deaddoor deliv6 gooddoor nonefx nosuchdriveratall possible rctwo retry0 weird tmux"
new = "tap_driver_wired_list() { # -> the wired set, space-separated. THE single source.\n  printf '%s' '" + fixtures + "'\n}"
s, n = re.subn(r"tap_driver_wired_list\(\) \{.*?\n\}", new, s, count=1, flags=re.S)
if n != 1:
    sys.exit("driver-disposition-routing: could not find tap_driver_wired_list to widen")
open(p, "w").write(s)
ENDPY
[ $? -eq 0 ] || { echo "driver-disposition-routing: could not widen the wired list in the tree copy" >&2; exit 1; }
# The diff must be exactly the one function. `diff` exits 1 when files differ,
# which is expected here; what is asserted is WHAT differs.
_diff_lines="$(diff "$LIB_SHIPPED" "$LIB_COPY" | grep -E '^[<>]' || true)"
_unexpected="$(printf '%s\n' "$_diff_lines" | grep -vE "tap_driver_wired_list|printf '%s' '|^[<>] *$|^[<>]   printf 'tmux[a-z ]*'$|^[<>] \}$" || true)"
[ -z "$_unexpected" ] || {
  echo "driver-disposition-routing: the tree copy differs from the shipped lib.sh beyond tap_driver_wired_list:" >&2
  printf '%s\n' "$_unexpected" >&2
  exit 1
}
# The courier under test is the COPY. TAP_SHIPPED stays pointed at the real tree
# for the structural assertions that must read the shipped file.
TAP="$TREE/scripts/tap.sh"


fail() { echo "driver-disposition-routing: $*" >&2; exit 1; }

cat > "$BUS/registry.json" <<JSON
{ "team": { "name": "t", "worktree_root": "$WORK/repo" },
  "agents": {
    "lead":   { "pane": "sess:0.0", "pane_id": "%1001", "session": "sess", "server_epoch": "srv:4242:100", "harness": "codex", "status": "active", "registered_from_worktree": "$WORK/repo" },
    "sender": { "pane": "sess:0.1", "pane_id": "%1002", "session": "sess", "server_epoch": "srv:4242:100", "harness": "codex", "status": "active", "registered_from_worktree": "$WORK/repo" }
  } }
JSON

# Minimal fake tmux: enough for the courier's identity and pane checks to pass,
# so the run reaches the delivery hop. The DRIVER decides the outcome here, not
# the pane — that is the whole point of the seam under test.
FAKE_BIN="$WORK/bin"; mkdir -p "$FAKE_BIN"
cat > "$FAKE_BIN/tmux" <<'ENDTMUX'
#!/usr/bin/env bash
set -euo pipefail
cmd="${1:-}"; shift || true
case "$cmd" in
  list-sessions) printf 'sess\t4242:100\n' ;;
  list-panes)
    printf 'sess\tsess:0.0\t%%1001\tcodex\t4242\t4242:100\n'
    printf 'sess\tsess:0.1\t%%1002\tcodex\t4242\t4242:100\n' ;;
  display-message)
    fmt=""; target=""
    while [ "$#" -gt 0 ]; do
      case "$1" in
        -p) shift ;;
        -t) target="${2:-}"; shift 2 ;;
        *)  fmt="$1"; shift ;;
      esac
    done
    case "$fmt" in
      *pane_id*)              case "$target" in *0.0) echo '%1001' ;; *) echo '%1002' ;; esac ;;
      *pane_in_mode*)         echo "${TAP_FAKE_IN_MODE:-0}" ;;
      *pane_current_command*) echo "codex" ;;
      *)                      echo "" ;;
    esac ;;
  capture-pane) printf '› \n' ;;
  send-keys) : ;;
esac
ENDTMUX
chmod +x "$FAKE_BIN/tmux"
export PATH="$FAKE_BIN:$PATH" TMUX="/fake/socket"

# The driver under test: an rc no tmux path produces, declared by its own table
# as possible-effect. It never touches the pane — it does not need to; the claim
# being tested is about how the COURIER routes what the driver reports.
cat > "$DRIVER_DIR/possible.sh" <<'ENDDRV'
tapdrv_possible_deliver() { return 7; }
tapdrv_possible_ceiling() { printf 'api-accepted'; }
tapdrv_possible_outcome() { printf 'stop-ambiguous\x1fpossible\x1fapi-accepted'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "possible"
ENDCFG

body="$WORK/body.md"
printf 'hello\n' > "$body"

rc=0
out="$("$TAP" send lead --ask -f "$body" --from sender --id disp-1 --json 2>"$WORK/err")" || rc="$?"

# THE ASSERTION. A possible-effect attempt must never be queued for retry.
if [ -f "$BUS/spool/disp-1.md" ] || [ -f "$BUS/spool/disp-1.meta.json" ]; then
  fail "(a) a possible-effect attempt was SPOOLED FOR RETRY — a retry here is a duplicate delivery
  spool: $(ls -A "$BUS/spool" 2>/dev/null | tr '\n' ' ')
  stdout: $out
  stderr: $(cat "$WORK/err")"
fi
echo "driver-disposition-routing: (a) a possible-effect attempt is not queued for retry: ok"

# It takes submit-unverified semantics instead, which are exactly right for it:
# the canonical stays on the bus for the recipient to poll, outstanding ages, and
# the obligation layer detects the drop (I-2).
[ "$rc" = "5" ] || fail "(b) expected exit 5 (submit-unverified), got $rc
  stdout: $out
  stderr: $(cat "$WORK/err")"
echo "driver-disposition-routing: (b) it exits 5, taking submit-unverified semantics: ok"

[ -f "$BUS/payloads/disp-1.md" ] || fail "(c) the canonical was removed; the recipient has nothing to poll"
echo "driver-disposition-routing: (c) the canonical stays on the bus: ok"

[ ! -f "$BUS/receipts/disp-1.sent" ] || fail "(d) an unconfirmed delivery wrote success telemetry"
echo "driver-disposition-routing: (d) no .sent success telemetry: ok"

[ -f "$BUS/payloads/disp-1.attempts" ] || fail "(e) no attempt record was written for the failed attempt"
python3 - "$BUS/payloads/disp-1.attempts" <<'ENDPY'
import json, sys
r = [json.loads(l) for l in open(sys.argv[1]) if l.strip()][-1]
assert r["disposition"] == "stop-ambiguous", r
assert r["effect"] == "possible", r
assert r["driver"] == "possible", r
ENDPY
echo "driver-disposition-routing: (e) the attempt record carries the driver's own disposition: ok"

# The mirror arm. An effect:none driver on the same unfamiliar rc MUST still take
# the retry path — otherwise the fix above is not "route on disposition", it is
# "never retry", which would forfeit every legal retry to buy the safety.
cat > "$DRIVER_DIR/nonefx.sh" <<'ENDDRV'
tapdrv_nonefx_deliver() { return 7; }
tapdrv_nonefx_ceiling() { printf 'api-accepted'; }
tapdrv_nonefx_outcome() { printf 'retry-next-rung\x1fnone\x1fnone'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "nonefx"
ENDCFG
rc=0
"$TAP" send lead --ask -f "$body" --from sender --id disp-2 --json >"$WORK/out2" 2>"$WORK/err2" || rc="$?"
if [ ! -f "$BUS/spool/disp-2.md" ] && [ ! -f "$BUS/spool/disp-2.meta.json" ]; then
  fail "(f) a retry-safe attempt was NOT spooled — the disposition check has become 'never retry'
  rc: $rc
  stdout: $(cat "$WORK/out2")
  stderr: $(cat "$WORK/err2")"
fi
echo "driver-disposition-routing: (f) an effect:none attempt still takes the retry path: ok"
# Isolate later driver outcomes from this deliberately queued sibling.
rm -f "$BUS/spool/disp-2.md" "$BUS/spool/disp-2.meta.json"

# --- (g) rc 2 belongs to the DRIVER, not to the dispatcher --------------------
# The dispatcher used to report its own resolution failure as rc 2, colliding with
# a perfectly legal native return. The consequence was not cosmetic: the caller
# treats an unresolved driver as a PRE-ATTEMPT failure and DELETES the canonical
# payload — so a driver returning 2 after taking effect would have its message
# destroyed. Found by sol-pinnacle on #xxx; the fix is an out-of-band flag, which
# cannot collide with any return value.
cat > "$DRIVER_DIR/rctwo.sh" <<'ENDDRV'
tapdrv_rctwo_deliver() { return 2; }
tapdrv_rctwo_ceiling() { printf 'api-accepted'; }
tapdrv_rctwo_outcome() { printf 'stop-ambiguous\x1fpossible\x1fapi-accepted'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "rctwo"
ENDCFG
rc=0
"$TAP" send lead --ask -f "$body" --from sender --id disp-3 --json >"$WORK/out3" 2>"$WORK/err3" || rc="$?"
[ -f "$BUS/payloads/disp-3.md" ] || fail "(g) a driver's own rc 2 was read as dispatcher failure and the canonical was DELETED — the recipient has nothing to poll
  rc: $rc
  stdout: $(cat "$WORK/out3")
  stderr: $(cat "$WORK/err3")"
echo "driver-disposition-routing: (g) a driver's own rc 2 does not destroy the canonical: ok"
grep -q 'driver_unavailable' "$WORK/err3" "$WORK/out3" && \
  fail "(g) a real driver return was reported as driver_unavailable"
echo "driver-disposition-routing: (g) a real driver return is not reported as a resolution failure: ok"

# The mirror: a genuinely unresolvable driver must STILL refuse loudly, or the
# fix has traded one silent wrong answer for another.
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "nosuchdriveratall"
ENDCFG
rc=0
"$TAP" send lead --ask -f "$body" --from sender --id disp-4 --json >"$WORK/out4" 2>"$WORK/err4" || rc="$?"
[ "$rc" = "1" ] || fail "(h) an unresolvable driver did not refuse; rc=$rc"
grep -q 'driver_unavailable' "$WORK/out4" "$WORK/err4" \
  || fail "(h) an unresolvable driver did not name its class: $(cat "$WORK/out4" "$WORK/err4")"
echo "driver-disposition-routing: (h) an unresolvable driver still refuses loudly: ok"

# --- (i) THE SUCCESS DIRECTION — a capped rc 0 must not become a delivery -----
# This is the arm that matters most in the file, and the file existed without it
# for a full review round. Fixing the FAILURE direction (an attempt the driver
# did not declare retry-safe never reaches the retry spool) left the SUCCESS
# direction untouched: a native rc 0 whose ceiling caps it to `stop-ambiguous`
# skipped every numeric branch and was written up as an injected delivery with a
# `.sent` receipt. The obligation would stop aging and the drop would become
# invisible — the exact failure the ceiling exists to make impossible, with the
# attempt log and the courier's own receipt contradicting each other.
#
# The fixture is the silent-drop shape on purpose: a door that returns SUCCESS
# from an unreachable path is not hypothetical, it is what two lanes measured tonight.
cat > "$DRIVER_DIR/deaddoor.sh" <<'ENDDRV'
tapdrv_deaddoor_deliver() { return 0; }
tapdrv_deaddoor_ceiling() { printf 'api-accepted'; }
tapdrv_deaddoor_outcome() { printf 'delivered\x1fpossible\x1fapi-accepted'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "deaddoor"
ENDCFG
rc=0
"$TAP" send lead --ask -f "$body" --from sender --id disp-5 --json >"$WORK/out5" 2>"$WORK/err5" || rc="$?"
[ ! -f "$BUS/receipts/disp-5.sent" ] || \
  fail "(i) a capped rc 0 wrote a .sent receipt — a dropped message reported as delivered
  stdout: $(cat "$WORK/out5")"
grep -q '"status":"injected"' "$WORK/out5" && \
  fail "(i) a capped rc 0 was reported as an injected delivery: $(cat "$WORK/out5")"
[ "$rc" = "5" ] || fail "(i) expected exit 5 (submit-unverified) for a capped rc 0, got $rc
  stdout: $(cat "$WORK/out5")
  stderr: $(cat "$WORK/err5")"
[ -f "$BUS/payloads/disp-5.md" ] || fail "(i) the canonical was removed; the recipient has nothing to poll"
echo "driver-disposition-routing: (i) a capped rc 0 does not become a delivery; it ages: ok"

# The mirror. A native driver that legitimately reaches `delivered` must still
# get its receipt — otherwise "route natives on disposition" has become "natives
# can never deliver", which would make every native driver useless rather than
# safe. Its tier must be its own declared ceiling, per the cap.
cat > "$DRIVER_DIR/gooddoor.sh" <<'ENDDRV'
tapdrv_gooddoor_deliver() { return 0; }
tapdrv_gooddoor_ceiling() { printf 'transcript-match'; }
tapdrv_gooddoor_outcome() { printf 'delivered\x1fpossible\x1ftranscript-match'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "gooddoor"
ENDCFG
rc=0
"$TAP" send lead --ask -f "$body" --from sender --id disp-6 --json >"$WORK/out6" 2>"$WORK/err6" || rc="$?"
[ "$rc" = "0" ] || fail "(j) a genuinely delivered native attempt did not succeed; rc=$rc
  stdout: $(cat "$WORK/out6")
  stderr: $(cat "$WORK/err6")"
[ -f "$BUS/receipts/disp-6.sent" ] || \
  fail "(j) a genuinely delivered native attempt wrote no .sent receipt — natives can never deliver"
echo "driver-disposition-routing: (j) a native driver that earns delivered still gets its receipt: ok"

# And tmux keeps its numeric branches: the unmodified suite is the proof of the
# extraction, so the disposition route must not have changed the tmux path.
[ "$(grep -c 'TAP_DRIVER_LAST_DRIVER:-tmux' "$ROOT/skills/tap/scripts/tap-send.sh")" -ge 1 ] || \
  fail "(j) the native route is not scoped to non-tmux drivers"
echo "driver-disposition-routing: (j) the numeric branches stay scoped to tmux: ok"

# --- (k) EVERY disposition branches before EVERY numeric case ----------------
# sol-pinnacle's two counterexamples, verbatim as arms. Two earlier drafts of the
# native route were partial, and each partial version was its own live defect —
# because a valid native status is UNRESERVED, so any numeric case still
# reachable by a native driver has a wrong tmux meaning attached to some legal
# return value.
#
# The cross-product is the assertion: each disposition against a status code
# whose tmux meaning contradicts it.

# delivered on rc 6 — tmux's identity-mismatch branch, which refuses and deletes
# the canonical. The driver said the message landed.
cat > "$DRIVER_DIR/deliv6.sh" <<'ENDDRV'
tapdrv_deliv6_deliver() { return 6; }
tapdrv_deliv6_ceiling() { printf 'transcript-match'; }
tapdrv_deliv6_outcome() { printf 'delivered\x1fpossible\x1ftranscript-match'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "deliv6"
ENDCFG
rc=0
"$TAP" send lead --ask -f "$body" --from sender --id disp-7 --json >"$WORK/out7" 2>"$WORK/err7" || rc="$?"
grep -q 'identity_mismatch' "$WORK/out7" "$WORK/err7" && \
  fail "(k) a native 'delivered' on rc 6 was refused as a tmux identity mismatch
  stdout: $(cat "$WORK/out7")
  stderr: $(cat "$WORK/err7")"
[ -f "$BUS/payloads/disp-7.md" ] || \
  fail "(k) a native 'delivered' on rc 6 had its canonical DELETED by tmux's identity branch"
[ "$rc" = "0" ] || fail "(k) a native 'delivered' on rc 6 did not succeed; rc=$rc
  stdout: $(cat "$WORK/out7")"
[ -f "$BUS/receipts/disp-7.sent" ] || fail "(k) a native 'delivered' on rc 6 wrote no receipt"
echo "driver-disposition-routing: (k) 'delivered' on a status tmux reads as identity drift still delivers: ok"

# retry-next-rung on rc 0 — tmux's success path, which writes .sent and reports
# an injected delivery. The driver said nothing happened and to try the next rung.
cat > "$DRIVER_DIR/retry0.sh" <<'ENDDRV'
tapdrv_retry0_deliver() { return 0; }
tapdrv_retry0_ceiling() { printf 'api-accepted'; }
tapdrv_retry0_outcome() { printf 'retry-next-rung\x1fnone\x1fnone'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "retry0"
ENDCFG
rc=0
"$TAP" send lead --ask -f "$body" --from sender --id disp-8 --json >"$WORK/out8" 2>"$WORK/err8" || rc="$?"
[ ! -f "$BUS/receipts/disp-8.sent" ] || \
  fail "(k) a native 'retry-next-rung' on rc 0 wrote a .sent receipt via tmux's success path"
grep -q '"status":"injected"' "$WORK/out8" && \
  fail "(k) a native 'retry-next-rung' on rc 0 was reported as an injected delivery: $(cat "$WORK/out8")"
if [ ! -f "$BUS/spool/disp-8.md" ] && [ ! -f "$BUS/spool/disp-8.meta.json" ]; then
  fail "(k) a native 'retry-next-rung' on rc 0 was not spooled for retry
  rc: $rc
  stdout: $(cat "$WORK/out8")
  stderr: $(cat "$WORK/err8")"
fi
echo "driver-disposition-routing: (k) 'retry-next-rung' on a status tmux reads as success still retries: ok"
rm -f "$BUS/spool/disp-8.md" "$BUS/spool/disp-8.meta.json"

# An unknown disposition takes the CONSERVATIVE arm. A table this courier does
# not understand must not be able to earn a delivery claim by default.
cat > "$DRIVER_DIR/weird.sh" <<'ENDDRV'
tapdrv_weird_deliver() { return 0; }
tapdrv_weird_ceiling() { printf 'api-accepted'; }
tapdrv_weird_outcome() { printf 'something-else\x1fpossible\x1fapi-accepted'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "weird"
ENDCFG
rc=0
"$TAP" send lead --ask -f "$body" --from sender --id disp-9 --json >"$WORK/out9" 2>"$WORK/err9" || rc="$?"
[ ! -f "$BUS/receipts/disp-9.sent" ] || \
  fail "(k) an UNKNOWN disposition earned a delivery receipt by default"
[ "$rc" = "5" ] || fail "(k) an unknown disposition did not take the conservative arm; rc=$rc"
echo "driver-disposition-routing: (k) an unknown disposition takes the conservative arm: ok"

# --- (l) a native driver's stdout must not reach the receipt channel ----------
# stdout IS the courier's receipt channel: with --json the caller parses it. A
# driver printing there corrupts a receipt into something a consumer cannot read,
# or worse, something it CAN read and believes.
cat > "$DRIVER_DIR/chatty.sh" <<'ENDDRV'
tapdrv_chatty_deliver() {
  printf 'DRIVER-NOISE-ON-STDOUT\n'
  printf '{"status":"injected","id":"forged"}\n'
  return 0
}
tapdrv_chatty_ceiling() { printf 'transcript-match'; }
tapdrv_chatty_outcome() { printf 'delivered\x1fpossible\x1ftranscript-match'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "chatty"
ENDCFG
"$TAP" send lead --ask -f "$body" --from sender --id disp-10 --json >"$WORK/out10" 2>"$WORK/err10" || true
grep -q 'DRIVER-NOISE-ON-STDOUT' "$WORK/out10" && \
  fail "(l) a driver's stdout reached the receipt channel: $(cat "$WORK/out10")"
grep -q 'forged' "$WORK/out10" && \
  fail "(l) a driver forged a receipt on stdout: $(cat "$WORK/out10")"
python3 - "$WORK/out10" <<'ENDPYL'
import json, sys
lines = [l for l in open(sys.argv[1]) if l.strip()]
assert len(lines) == 1, f"receipt channel carried {len(lines)} lines, not 1: {lines}"
r = json.loads(lines[0])
assert r["id"] == "disp-10", r
ENDPYL
echo "driver-disposition-routing: (l) a driver's stdout never reaches the receipt channel: ok"


# --- (pol) a parking exit cannot smuggle an unwired driver past the refusal ---
# sol-pinnacle, #xxx. Every parking exit -- --polite, the clearing fence, the
# pending-input grace, auto-settle -- returns BEFORE the delivery hop, which is
# where driver resolution used to live. A seat configured with an unwired driver
# therefore QUEUED SUCCESSFULLY, and the drain path does not go through the
# dispatcher at all, so the message later left through tmux with the loud
# refusal never emitted. The refusal has to precede parking, not delivery.
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "nosuchdoor"
ENDCFG
printf 'hello\n' > "$WORK/pol-body.md"
# EVERY pre-dispatch parking exit, not just --polite. sol-pinnacle raised this to
# P1 after an API-contract review corroborated it: copy-mode, pending-input,
# clearing, polite and auto-settle can ALL return queued success for an unwired
# driver and then redeliver through tmux. An arm covering one of them would have
# left the class open while looking like it closed it.
pol_case() { # <label> <extra-send-arg> <env-prefix-var> <env-prefix-val>
  local label="$1" arg="$2" evar="$3" eval_="$4" rc=0
  rm -f "$BUS/spool/pol-$label.md" "$BUS/spool/pol-$label.meta.json"
  if [ -n "$evar" ]; then
    env "$evar=$eval_" "$TAP" send lead --ask -f "$WORK/pol-body.md" --from sender \
      --id "pol-$label" $arg --json >"$WORK/pol-out" 2>"$WORK/pol-err" || rc="$?"
  else
    "$TAP" send lead --ask -f "$WORK/pol-body.md" --from sender \
      --id "pol-$label" $arg --json >"$WORK/pol-out" 2>"$WORK/pol-err" || rc="$?"
  fi
  [ "$rc" != 0 ] || \
    fail "(pol-$label) an unwired driver SUCCEEDED through a parking exit; the message is queued and will drain through tmux, which is the silent wrong-door delivery this preference exists to prevent"
  [ ! -f "$BUS/spool/pol-$label.md" ] && [ ! -f "$BUS/spool/pol-$label.meta.json" ] || \
    fail "(pol-$label) the message was PARKED despite an unusable driver; a refusal after parking is not a refusal
  spool: $(ls -A "$BUS/spool" 2>/dev/null | tr '\n' ' ')"
  # ASSERT THE EXACT MACHINE CONTRACT, not the presence of the word "driver".
  # The first version grepped for the word and passed against a NEW error class
  # invented at this call site (`driver_unresolvable`), which would have made the
  # same bad preference return different contracts depending on whether the send
  # happened to park -- a programmatic caller would have needed to know about the
  # parking exits to handle one error (sol-pinnacle, #xxx). A grep for prose
  # cannot see a contract change; only the class can.
  grep -q '"error_class":"driver_unavailable"' "$WORK/pol-out" || \
    fail "(pol-$label) refusal did not carry error_class=driver_unavailable, the same class the delivery hop returns
  stdout: $(cat "$WORK/pol-out")
  stderr: $(cat "$WORK/pol-err")"
  return 0
}
pol_case polite   --polite      ""                 ""
pol_case urgent   --urgent      ""                 ""
pol_case copymode ""            TAP_FAKE_IN_MODE   1
pol_case plain    ""            ""                 ""
echo "driver-disposition-routing: (pol) every pre-dispatch parking exit refuses an unwired driver instead of parking it: ok"

# MIRROR: --polite with a USABLE configuration still parks. Bounds the fix so it
# cannot turn every polite send into a refusal.
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "tmux"
ENDCFG
_pol2_rc=0
"$TAP" send lead --ask -f "$WORK/pol-body.md" --from sender --id pol-2 --polite --json \
  >"$WORK/pol2-out" 2>"$WORK/pol2-err" || _pol2_rc="$?"
[ "$_pol2_rc" = 0 ] || \
  fail "(pol-mirror) --polite with a legal driver was refused (rc=$_pol2_rc): $(cat "$WORK/pol2-err")"
[ -f "$BUS/spool/pol-2.md" ] || \
  fail "(pol-mirror) --polite with a legal driver did not park the message"
echo "driver-disposition-routing: (pol-mirror) --polite still parks a legal send: ok"
rm -f "$WORK/pol"*
rm -f "$BUS/spool/pol-2.md" "$BUS/spool/pol-2.meta.json"


# NOTE ON ORDER: (pol) must run BEFORE the (adv) block, which permanently stubs
# the tree copy's resolver to rc 4. With that stub in place no config value is
# ever read, so (pol) would be asserting against a courier that cannot see the
# unwired driver it is meant to refuse -- it reported the defect as unfixed for
# exactly that reason before being moved here.
# --- (adv) the parserless advisory survives EVERY outcome, driven end-to-end ---
# sol-pinnacle's P1. The advisory was written to the driver's detail file, which
# the rc 4 and rc 5 paths read one line from and delete -- so the "unconditional,
# repeating" warning reached the operator only when the send SUCCEEDED. A warning
# that appears only on success is the opposite of a warning.
#
# These arms drive the REAL courier, because the defect was invisible to the
# resolver in isolation: the function emitted the line correctly every time and
# the caller threw it away. Testing the producer would have greened.
adv_case() { # <label> <expected-send-rc> <expect-advisory 0|1>
  # THE EXPECTED RC IS ASSERTED, NOT MERELY CAPTURED. The first version took an
  # unused second argument, recorded rc, and never compared it -- so an arm named
  # rc5 greened on whatever path the courier happened to take, and the advisory
  # appears on rc 0 as well. The name claimed a path the check did not visit.
  local label="$1" want_rc="$2" want="$3" out rc=0
  # A config the parserless resolver cannot read. The stub lives in the COPY's
  # lib.sh (this suite already runs against a mutated tree), so the courier
  # subprocess takes the rc 4 branch for real.
  cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "tmux"
ENDCFG
  printf 'hello\n' > "$WORK/adv-body.md"
  "$TAP" send lead --ask -f "$WORK/adv-body.md" --from sender --id "adv-$label" --json \
    >"$WORK/adv-out" 2>"$WORK/adv-err" || rc="$?"
  [ "$rc" = "$want_rc" ] || \
    fail "(adv-$label) expected send rc=$want_rc, got $rc; this arm names a courier path and must visit it
  stderr: $(cat "$WORK/adv-err")"
  if [ "$want" = 1 ]; then
    grep -q 'NOT in effect' "$WORK/adv-err" || \
      fail "(adv-$label) the parserless advisory did not reach stderr (send rc=$rc)
  stderr: $(cat "$WORK/adv-err")"
  else
    grep -q 'NOT in effect' "$WORK/adv-err" && \
      fail "(adv-$label) an advisory was emitted for a config with no unreadable preference"
  fi
  rm -f "$WORK/adv-out" "$WORK/adv-err"
  return 0
}

# PLACED BEFORE THE RESOLVER STUB BELOW, DELIBERATELY: from that point on the tree copy
# answers as a python with no tomllib, so no config-driven driver can take effect and
# these three arms would pass by never reaching the code they are about.
# (preflight-leak) A REFUSED SEND STRANDS NO PREFLIGHT TEMP — tap-a6xly, sol-max's P3.
#
# The preflight's stderr capture used to be allocated before driver resolution, where
# both `tap_fail` exits leave the process before any removal and the EXIT trap covers
# only the payload wrapper temps. One stranded file per refused send, on a path an
# operator sees precisely when something is already wrong.
#
# THIS ARM REDS ON THE PRE-FIX SHAPE, which is the only reason it is worth its lines:
# with the allocation hoisted back above resolution, (a) leaves 1. Three exits, because
# the fix's claim is about WHERE the allocation lives, not about one branch:
#   (a) resolution refuses    -> nothing is ever allocated
#   (b) the builder succeeds  -> allocated and removed on the normal path
#   (c) the builder refuses   -> allocated and removed before the refusal
#
# TMPDIR is pinned to a private directory so the census counts this arm's own files and
# nothing else on the box.
PFT="$WORK/preflight-tmp"; mkdir -p "$PFT"
pf_count() { find "$PFT" -maxdepth 1 -name 'tap-send-preflight.*' 2>/dev/null | wc -l | tr -d ' '; }
printf 'hello\n' > "$WORK/pf-body.md"

cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "nosuchdriver-preflight"
ENDCFG
_pf_rc=0
env TMPDIR="$PFT" "$TAP" send lead --ask -f "$WORK/pf-body.md" --from sender --id pf-1 --json \
  >"$WORK/pf-out1" 2>"$WORK/pf-err1" || _pf_rc="$?"
[ "$_pf_rc" != 0 ] || fail "(preflight-leak a) an unresolvable driver SUCCEEDED"
[ "$(pf_count)" = 0 ] || \
  fail "(preflight-leak a) a refused send stranded $(pf_count) tap-send-preflight.* file(s) — the allocation is above the refusal again"
echo "driver-disposition-routing: (preflight-leak a) a resolution refusal allocates nothing: ok"

cat > "$DRIVER_DIR/argful.sh" <<'ENDDRV'
tapdrv_argful_args()    { [ "${TAP_TEST_ARGS_REFUSE:-0}" = 1 ] && { echo "refused for the arm" >&2; return 12; }; printf ''; }
tapdrv_argful_deliver() { return 7; }
tapdrv_argful_ceiling() { printf 'api-accepted'; }
tapdrv_argful_outcome() { printf 'stop-ambiguous\x1fpossible\x1fapi-accepted'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.codex]
driver = "argful"
ENDCFG
env TMPDIR="$PFT" "$TAP" send lead --ask -f "$WORK/pf-body.md" --from sender --id pf-2 --json \
  >"$WORK/pf-out2" 2>"$WORK/pf-err2" || true
[ "$(pf_count)" = 0 ] || \
  fail "(preflight-leak b) a send whose builder succeeded stranded $(pf_count) tap-send-preflight.* file(s)"
echo "driver-disposition-routing: (preflight-leak b) a successful builder removes its capture: ok"

_pf_rc=0
env TMPDIR="$PFT" TAP_TEST_ARGS_REFUSE=1 "$TAP" send lead --ask -f "$WORK/pf-body.md" --from sender \
  --id pf-3 --json >"$WORK/pf-out3" 2>"$WORK/pf-err3" || _pf_rc="$?"
[ "$_pf_rc" != 0 ] || fail "(preflight-leak c) a builder refusal SUCCEEDED"
grep -q '"error_class":"driver_unavailable"' "$WORK/pf-out3" || \
  fail "(preflight-leak c) the builder refusal did not carry driver_unavailable — this arm may not have reached the builder at all
  stdout: $(cat "$WORK/pf-out3")
  stderr: $(cat "$WORK/pf-err3")"
[ "$(pf_count)" = 0 ] || \
  fail "(preflight-leak c) a builder refusal stranded $(pf_count) tap-send-preflight.* file(s)"
echo "driver-disposition-routing: (preflight-leak c) a builder refusal removes its capture before failing: ok"

# Make the COPY's resolver behave as a python with no tomllib, for every case.
python3 - "$LIB_COPY" <<'ENDPY'
import re, sys
p = sys.argv[1]
s = open(p).read()
new = "tap_driver_config_resolve() { return 4; }"
s, n = re.subn(r"tap_driver_config_resolve\(\) \{.*?\nENDPY\n\}", new, s, count=1, flags=re.S)
if n != 1:
    sys.exit("driver-disposition-routing: could not stub the resolver in the tree copy")
open(p, "w").write(s)
ENDPY
[ $? -eq 0 ] || { echo "driver-disposition-routing: resolver stub failed" >&2; exit 1; }

# rc 5 (submit-unverified) is the courier path that reads ONE LINE from _sv_err
# and deletes it, and it is where the advisory was being lost. It is driven here
# for real, through the whole courier.
#
# WHAT THIS ARM DOES NOT COVER, stated rather than implied by its name: the
# post-dispatch rc 4 spool path. Reaching a genuine post-dispatch defer needs a
# fake tmux that can FAIL a submit rather than pre-empt it, and this fixture's
# cannot. The structural argument that rc 4 is also covered is that the emit
# precedes every outcome branch -- a hypothesis, not a measurement, and labelled
# as one by ruling of sol-pinnacle and grok.
#
# (This paragraph previously also said copy-mode parks before the driver hop so
# no config is read. That stopped being true when the unwired-driver refusal
# moved under PANE_CMD, and it sat here contradicting the copymode arm ten lines
# below -- one file stating both. Rewritten rather than left, because that is the
# I-11 double-write that has already bitten the ccnative appendix twice.)
#
# An earlier version of this block passed three different driver bodies and
# claimed rc0/rc4/rc5 coverage. All three produced send_rc=5: the bodies were
# never sourced, because `tap_driver_load` short-circuits when tapdrv_tmux_deliver
# is already defined by lib.sh. One path, run three times, under three names. The
# rc 4 case below is real because it changes the PANE state the courier reads,
# not a module the courier ignores.
adv_case rc5 5 1
# COPY-MODE PARKS BEFORE THE DRIVER HOP -- but the config is now read BEFORE the
# park, because the unwired-driver refusal had to move above every parking exit
# (see (pol)). So the advisory IS emitted here, and that is the improvement
# rather than the regression: an operator whose preference cannot be read learns
# it even when the send parks instead of delivering.
#
# This arm asserted the opposite until the refusal moved, and it reds either way
# -- which is the point of keeping it. It pins WHERE resolution happens relative
# to the parking exits, so that placement cannot drift silently in either
# direction.
TAP_FAKE_IN_MODE=1 adv_case copymode-preempts 0 1
echo "driver-disposition-routing: (adv) the parserless advisory survives the rc5 path that deletes _sv_err, and a copy-mode park emits it too, because resolution now precedes every park: ok"

# BOUND: an absent config must warn on none of them. Without this the fix could
# overshoot into warning about a preference nobody wrote.
rm -f "$XDG_CONFIG_HOME/tap/config.toml"
adv_noconfig() { # <label>
  printf 'hello\n' > "$WORK/adv-body.md"
  "$TAP" send lead --ask -f "$WORK/adv-body.md" --from sender --id "advn-$1" --json \
    >"$WORK/adv-out" 2>"$WORK/adv-err" || true
  grep -q 'NOT in effect' "$WORK/adv-err" && \
    fail "(adv-none-$1) an advisory was emitted with NO config at all"
  rm -f "$WORK/adv-out" "$WORK/adv-err"
  return 0
}
adv_noconfig rc5 ""
echo "driver-disposition-routing: (adv-none) no config means no advisory: ok"


# --- (nohome) no config location refuses structurally, before placement -------
# THIS ARM PINS EXISTING BEHAVIOR. It is not a fix for a defect, and an earlier
# version of this header said it was -- claiming that
# `${XDG_CONFIG_HOME:-$HOME/.config}` aborts under `set -u` after canonical
# placement, leaving no structured refusal and an orphan canonical. Both halves
# were disproved, by sol-pinnacle's real-path probe and by this arm PASSING
# against unmodified code, and both reviewers caught the header still telling the
# disproved story after the code site had been corrected.
#
# What actually happens: the nounset error fires INSIDE the config-path command
# substitution, so it fails the substitution rather than killing the courier. The
# nonzero is caught by tap_driver_for_harness, the PANE_CMD preflight maps it to
# exit 1 with error_class=driver_unavailable, and all of that precedes
# tap_send_place_canonical -- so there is no orphan to leave.
#
# The bound this arm therefore holds, against a future refactor that moves
# placement earlier or stops catching the substitution failure: a structured
# refusal, and no canonical. Driven through the real courier because both
# properties are the courier's, not the resolver's.
printf 'hello\n' > "$WORK/nh-body.md"   # own body: an earlier arm removes $WORK/pol*
_nh_before="$(find "$BUS/payloads" -maxdepth 1 -name 'nohome-1*' 2>/dev/null | wc -l | tr -d ' ')"
_nh_rc=0
env -u HOME -u XDG_CONFIG_HOME "$TAP" send lead --ask -f "$WORK/nh-body.md" --from sender \
  --id nohome-1 --json >"$WORK/nh-out" 2>"$WORK/nh-err" || _nh_rc="$?"
[ "$_nh_rc" != 0 ] || fail "(nohome) a send with no config location SUCCEEDED"
grep -q '"error_class":"driver_unavailable"' "$WORK/nh-out" || \
  fail "(nohome) refused without error_class=driver_unavailable
  rc: $_nh_rc
  stdout: $(cat "$WORK/nh-out")
  stderr: $(cat "$WORK/nh-err")"
_nh_after="$(find "$BUS/payloads" -maxdepth 1 -name 'nohome-1*' 2>/dev/null | wc -l | tr -d ' ')"
[ "$_nh_after" = "$_nh_before" ] || \
  fail "(nohome) the refusal left an orphan canonical behind ($_nh_before -> $_nh_after)"
echo "driver-disposition-routing: (nohome) no config location refuses with the structured class and no orphan: ok"

echo "driver-disposition-routing: ok"
