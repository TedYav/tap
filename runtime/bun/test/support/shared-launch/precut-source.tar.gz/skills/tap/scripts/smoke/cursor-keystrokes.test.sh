#!/usr/bin/env bash
# Record harness keys at the interrupt/submit effect seam, with synchronous frames.
set -euo pipefail
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
. "$ROOT/skills/tap/scripts/smoke/sandbox-pins.sh"
. "$ROOT/skills/tap/scripts/lib.sh"
keys=()
submitted=0
pauses=0
refuse_second=0
recorded_enters=0
fixture_frame=fixture
tap_submit_identity_guard() { return 0; }
tap_capture_pane() { printf '%s' "$fixture_frame"; }
tap_submit_phase() { recorded_enters="${_phase_enters:-0}"; }
tap_settle() { if [ "$1" = 0.25 ]; then pauses=$((pauses+1)); fi; }
tap_bun_call() {
  [ "$1" = submit-state ] || return 1
  # The real consumer reads the frame; closing it unread can SIGPIPE printf.
  cat >/dev/null
  if [ "$submitted" = 0 ]; then printf 'staged\tworking'; else printf 'empty\tworking'; fi
}
tmux() {
  case "$1" in
    display-message) case "$*" in *pane_width*) echo 80 ;; *) echo 0 ;; esac ;;
    send-keys)
      shift 3
      if [ "$refuse_second" = 1 ] && [ "${1:-}" = Enter ] && [ "$submitted" = 1 ]; then
        TAP_RECOVERY_EFFECT_NONE=1
        return 125
      fi
      for key in "$@"; do
        keys+=("$key")
        [ "$key" != Enter ] || submitted=1
      done ;;
  esac
}
check() {
  local harness="$1" urgent="$2" expected_keys="$3" expected_pauses="$4" seq rc
  keys=(); submitted=0; pauses=0
  if [ "$urgent" = 1 ]; then
    seq="$(tap_interrupt_seq "$harness")"
    [ -z "$seq" ] || tmux send-keys -t %fixture $seq
  fi
  tmux send-keys -t %fixture text
  if tap_submit_transition_verify %fixture "$harness" test-id 0 id '' '' '' 6 '' '' '[[TAP v0.23 note test-id]]' "$urgent"; then
    :
  else
    rc=$?
    printf 'FAIL: verify harness=%s urgent=%s rc=%s\n' "$harness" "$urgent" "$rc" >&2
    return "$rc"
  fi
  [ "${keys[*]}" = "$expected_keys" ] || { printf 'FAIL: %s urgent=%s keys=%s\n' "$harness" "$urgent" "${keys[*]}"; exit 1; }
  [ "$pauses" = "$expected_pauses" ] || { echo 'FAIL: Cursor second Enter pause'; exit 1; }
}
# Force the producer past pipe capacity: an unread stdin must fail reliably.
printf -v fixture_frame '%1048576s' ''
check cursor 0 'text Enter Enter' 1
fixture_frame=fixture
echo 'cursor-keystrokes: large piped frame is consumed before classification: ok'
check cursor 0 'text Enter Enter' 1
check cursor 1 'C-c text Enter' 0
for harness in claude codex; do
  check "$harness" 0 'text Enter' 0
  check "$harness" 1 'Escape text Enter' 0
done
check opencode 0 'text Enter' 0
check opencode 1 'Escape Escape text Enter' 0
echo 'cursor-keystrokes: plain/interrupt sequences and other harnesses unchanged: ok'

keys=(); submitted=0; pauses=0; refuse_second=1; recorded_enters=0
rc=0
tap_submit_transition_verify %fixture cursor test-id 0 id '' '' '' 6 '' '' '[[TAP v0.23 note test-id]]' 0 || rc=$?
[ "$rc" = 5 ] && [ "$recorded_enters" = 1 ] && [ "${keys[*]}" = Enter ] || {
  echo "FAIL: refused second Enter rc=$rc enter_count=$recorded_enters keys=${keys[*]}"; exit 1;
}
echo 'cursor-keystrokes: adapter no-effect second Enter preserves one attempted key: ok'

# A failed classifier must name the arm instead of escaping silently via set -e.
diagnostic_rc=0
diagnostic="$(
  refuse_second=0
  tap_bun_call() { cat >/dev/null; return 1; }
  check cursor 1 'C-c text Enter' 0 2>&1
)" || diagnostic_rc=$?
[ "$diagnostic_rc" = 5 ] && [[ "$diagnostic" == *'FAIL: verify harness=cursor urgent=1 rc=5'* ]] || {
  printf 'FAIL: missing verify diagnostic rc=%s output=%s\n' "$diagnostic_rc" "$diagnostic"; exit 1;
}
echo 'cursor-keystrokes: failed verification names harness, urgency, and rc: ok'
