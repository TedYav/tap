import dataclasses
import contextlib
import datetime
import io
import importlib.util
import importlib.machinery
import fcntl
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
_UNSET = object()
import threading
import types
import unittest
from unittest import mock


ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_loader(
    "launcher",
    importlib.machinery.SourceFileLoader("launcher", str(ROOT / "launcher.py")),
)
launcher = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(launcher)
import presets as preset_config  # noqa: E402


def complete_mock_launch(record):
    """Complete the launcher-owned registry transaction for orchestration tests."""
    facts = launcher.PaneFacts(
        pane=f"{record.name}:0.0",
        pane_id="%216",
        command=record.harness,
        path=record.cwd,
    )
    launcher.bind_reserved_handle(record, facts)
    launcher.mark_launch_ready(record, facts)
    return 0


@contextlib.contextmanager
def isolated_login_shell(shell="zsh"):
    """Pin TAP_LAUNCH_SHELL/SHELL so shell_command tests do not inherit the host.

    resolve_login_shell may emit an absolute path (better production contract);
    callers assert against launcher.resolve_login_shell() after entering.
    """
    with mock.patch.dict(os.environ, {"TAP_LAUNCH_SHELL": shell, "SHELL": shell}):
        yield launcher.resolve_login_shell()


def write_codex_rollout(
    sessions: pathlib.Path,
    filename_stamp: str,
    session_id: str,
    cwd: str,
    timestamp: str = "2026-07-10T00:17:44.000Z",
) -> pathlib.Path:
    rollout = sessions / "2026" / "07" / "10" / f"rollout-{filename_stamp}-{session_id}.jsonl"
    rollout.parent.mkdir(parents=True, exist_ok=True)
    rollout.write_text(json.dumps({
        "timestamp": timestamp,
        "type": "session_meta",
        "payload": {
            "id": session_id,
            "timestamp": timestamp,
            "cwd": cwd,
        },
    }) + "\n")
    return rollout


def write_claude_transcript(
    projects_root: pathlib.Path,
    cwd: str,
    session_id: str,
    timestamp: str = "2026-07-10T00:17:44.000Z",
    slug: str | None = None,
    interior_session_id: str | None = None,
) -> pathlib.Path:
    """Mint a claude transcript at ~/.claude/projects/<slug>/<id>.jsonl, mirroring
    the on-disk shape the launcher scans. `slug` overrides the derived slug (to
    stage a slug collision); `interior_session_id` overrides the body's sessionId
    (to stage a forked/renamed file)."""
    slug = slug if slug is not None else launcher.claude_cwd_slug(cwd)
    project_dir = projects_root / slug
    project_dir.mkdir(parents=True, exist_ok=True)
    path = project_dir / f"{session_id}.jsonl"
    path.write_text(json.dumps({
        "type": "attachment",
        "sessionId": interior_session_id if interior_session_id is not None else session_id,
        "cwd": cwd,
        "timestamp": timestamp,
    }) + "\n")
    return path


def opencode_session_row(session_id: str, directory: str, created_ms: int) -> dict:
    return {"id": session_id, "directory": directory, "created": created_ms, "updated": created_ms}


_TEST_STATE_ROOTS: dict[str, list[str]] = {}


def save_registry_state(path_hint, state: launcher.Manifest) -> None:
    """Write a launcher's in-memory state through the acting-registry shape.

    ``path_hint`` is retained only so the pre-registry test fixtures can be
    migrated mechanically. It is never opened as a session store.
    """
    hint = pathlib.Path(path_hint)
    grouped: dict[str, list[launcher.SessionRecord]] = {}
    for record in state.sessions:
        grouped.setdefault(launcher.root_for_cwd(record.cwd), []).append(record)
    if not grouped:
        roots = list(state.dir_aliases) or [str(hint.parent.resolve())]
        grouped = {root: [] for root in roots}

    written_roots: list[str] = []
    for root, records in grouped.items():
        resolved_root = str(pathlib.Path(root).resolve())
        base = state.dir_aliases.get(root) or state.dir_aliases.get(resolved_root)
        if not base:
            base = records[0].base if records else pathlib.Path(resolved_root).name
        registry = pathlib.Path(resolved_root) / ".tap" / "bus" / "registry.json"
        if registry.exists():
            payload = json.loads(registry.read_text())
        else:
            payload = {"team": {}, "agents": {}}
        team = payload.setdefault("team", {})
        team.update({"name": base, "worktree_root": resolved_root})
        agents = payload.setdefault("agents", {})
        for record in records:
            handle = launcher.session_handle(record)
            slash = launcher.slash_handle(record.name, record.base)
            stored_record = record
            if record.tag is None and slash and handle == record.harness and slash != record.harness:
                handle = slash
                stored_record = dataclasses.replace(record, tag=slash)
            entry = dict(agents.get(handle) or {})
            entry.setdefault("status", "active")
            entry.setdefault("delivery", "pane")
            entry.setdefault("registered_from_worktree", resolved_root)
            entry.setdefault("registered_at", record.last_launched or "2026-07-10T00:00:00Z")
            launcher.store_session_record_fields(entry, stored_record)
            agents[handle] = entry
        registry.parent.mkdir(parents=True, exist_ok=True)
        registry.write_text(json.dumps(payload) + "\n")
        written_roots.append(resolved_root)
    _TEST_STATE_ROOTS[str(hint)] = list(dict.fromkeys(
        str(pathlib.Path(root).resolve()) for root in written_roots
    ))


def load_registry_state(path_hint) -> launcher.Manifest:
    hint = pathlib.Path(path_hint)
    roots = list(dict.fromkeys(
        str(pathlib.Path(root).resolve())
        for root in _TEST_STATE_ROOTS.get(str(hint), [str(hint.parent.resolve())])
    ))
    sessions: list[launcher.SessionRecord] = []
    aliases: dict[str, str] = {}
    for root in roots:
        registry = pathlib.Path(root) / ".tap" / "bus" / "registry.json"
        payload = json.loads(registry.read_text())
        state = launcher._session_state_from_registry_payload(payload, root)
        sessions.extend(state.sessions)
        aliases.update(state.dir_aliases)
    return launcher.Manifest(sessions=sessions, dir_aliases=aliases)


def save_registry_records(path_hint, records: list[launcher.SessionRecord]) -> None:
    aliases = {launcher.root_for_cwd(record.cwd): record.base for record in records}
    save_registry_state(path_hint, launcher.Manifest(sessions=records, dir_aliases=aliases))




class TtyBuffer(io.StringIO):
    def __init__(self, value="", tty=False):
        super().__init__(value)
        self.tty = tty

    def isatty(self):
        return self.tty

    def fileno(self):
        return 0


def patched_menu_reader(keys):
    """os.read that answers fd 0 from `keys` and reads every other fd for real.

    A blind os.read patch starves subprocess's own errpipe reader the moment
    the flow under test spawns any real child (the launcher probes boot ids
    and shells out even inside unit fixtures), so the pin applies to the
    prompt's stdin only — and an over-run menu fails loudly instead of
    letting the mock decide the verdict (tap-7r3fn.24).
    """
    real_read = os.read
    pending = list(keys)

    def _read(fd, *args, **kwargs):
        if fd == 0:
            if not pending:
                raise AssertionError("menu consumed more keys than pinned")
            return pending.pop(0)
        return real_read(fd, *args, **kwargs)

    return _read


class PresentationStyleTests(unittest.TestCase):
    _TPUT_OUTPUTS = {
        ("setaf", "1"): "\x1b[31m",
        ("setaf", "3"): "\x1b[33m",
        ("bold",): "\x1b[1m",
        ("dim",): "\x1b[2m",
        ("sgr0",): "\x1b[0m",
    }

    def setUp(self):
        launcher._STYLE_TOKEN_CACHE.clear()
        which_patcher = mock.patch.object(launcher.shutil, "which", return_value="/fake/tput")
        run_patcher = mock.patch.object(launcher.subprocess, "run", side_effect=self._fake_tput)
        which_patcher.start()
        run_patcher.start()
        self.addCleanup(which_patcher.stop)
        self.addCleanup(run_patcher.stop)

    def _fake_tput(self, command, **_kwargs):
        return types.SimpleNamespace(returncode=0, stdout=self._TPUT_OUTPUTS[tuple(command[1:])])

    def test_style_enabled_honors_no_color_force_tty_and_term_precedence(self):
        tty = TtyBuffer(tty=True)
        pipe = TtyBuffer(tty=False)

        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "NO_COLOR": "", "CLICOLOR_FORCE": "1"}, clear=True):
            self.assertFalse(launcher.style_enabled(tty))
            self.assertFalse(launcher.style_enabled(pipe))
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "CLICOLOR_FORCE": "1"}, clear=True):
            self.assertTrue(launcher.style_enabled(pipe))
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "CLICOLOR_FORCE": "0"}, clear=True):
            self.assertFalse(launcher.style_enabled(pipe))
            self.assertTrue(launcher.style_enabled(tty))
        with mock.patch.dict(os.environ, {"TERM": "dumb", "CLICOLOR_FORCE": "1"}, clear=True):
            self.assertFalse(launcher.style_enabled(tty))
            self.assertFalse(launcher.style_enabled(pipe))
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "CLICOLOR_FORCE": "1"}, clear=True), \
             mock.patch.object(shutil, "which", return_value=None):
            self.assertFalse(launcher.style_enabled(pipe))
        launcher._STYLE_TOKEN_CACHE.clear()
        failed_probe = types.SimpleNamespace(returncode=1, stdout="")
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "CLICOLOR_FORCE": "1"}, clear=True), \
             mock.patch.object(shutil, "which", return_value="/fake/tput"), \
             mock.patch.object(subprocess, "run", return_value=failed_probe):
            self.assertFalse(launcher.style_enabled(pipe))

    def test_styled_wraps_only_supported_roles_when_enabled(self):
        stream = TtyBuffer(tty=False)
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "CLICOLOR_FORCE": "1"}, clear=True):
            tokens = launcher._terminal_style_tokens()
            self.assertEqual(launcher.styled("error", "problem", stream), f"{tokens['error']}problem{tokens['reset']}")
            self.assertEqual(launcher.styled("warning", "careful", stream), f"{tokens['warning']}careful{tokens['reset']}")
            self.assertEqual(launcher.styled("key", "next", stream), f"{tokens['key']}next{tokens['reset']}")
            self.assertEqual(launcher.styled("secondary", "meta", stream), f"{tokens['secondary']}meta{tokens['reset']}")
            with self.assertRaises(ValueError):
                launcher.styled("success", "no role", stream)
            with self.assertRaises(ValueError):
                launcher.styled("reset", "internal token", stream)
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "NO_COLOR": "1"}, clear=True):
            self.assertEqual(launcher.styled("error", "problem", stream), "problem")

    def test_emitters_preserve_plain_shapes_and_streams(self):
        stdout = TtyBuffer(tty=False)
        stderr = TtyBuffer(tty=False)
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "NO_COLOR": "1"}, clear=True), \
             mock.patch.object(sys, "stdout", stdout), mock.patch.object(sys, "stderr", stderr):
            launcher.emit_receipt("send", "delivered msg-1 to sol")
            launcher.emit_warning("send", "reply target is unavailable", "tap register --reply-to sol")
            launcher.emit_error_human("session", "session is busy", "tap session restart scout --force")

        self.assertEqual(stdout.getvalue(), "tap send: delivered msg-1 to sol\n")
        self.assertEqual(
            stderr.getvalue(),
            "tap send: warning: reply target is unavailable; next: tap register --reply-to sol\n"
            "tap session: session is busy; next: tap session restart scout --force\n",
        )

    def test_yes_no_prompt_is_single_key_and_refuses_non_tty(self):
        # tap-7r3fn.24: prompt_yes_no reads ONE key the way prompt_choice does
        # — the operator was just trained to single-key by the collision menu
        # and the very next prompt silently needed Enter. Enter = default.
        stderr = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stderr", stderr), \
             mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
             mock.patch.object(launcher.termios, "tcsetattr"), \
             mock.patch.object(launcher.tty, "setcbreak"), \
             mock.patch.object(launcher.os, "read", new=patched_menu_reader([b"\n"])):
            self.assertFalse(launcher.prompt_yes_no("team", "continue?", default=False))
        self.assertEqual(stderr.getvalue(), "tap team: continue? [y/N] ")

        stderr = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stderr", stderr), \
             mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
             mock.patch.object(launcher.termios, "tcsetattr"), \
             mock.patch.object(launcher.tty, "setcbreak"), \
             mock.patch.object(launcher.os, "read", new=patched_menu_reader([b"y"])):
            self.assertTrue(launcher.prompt_yes_no("team", "continue?", default=False))

        stderr = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stderr", stderr), \
             mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
             mock.patch.object(launcher.termios, "tcsetattr"), \
             mock.patch.object(launcher.tty, "setcbreak"), \
             mock.patch.object(launcher.os, "read", new=patched_menu_reader([b"x", b"n"])):
            self.assertFalse(launcher.prompt_yes_no("team", "continue?", default=False))
        self.assertIn("tap team: choose y or n", stderr.getvalue())

        stderr = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", TtyBuffer(tty=False)), \
             mock.patch.object(sys, "stderr", stderr), self.assertRaises(launcher.LauncherError):
            launcher.prompt_yes_no("team", "continue?", default=False)
        self.assertEqual(stderr.getvalue(), "")

    def test_choice_prompt_uses_default_redraws_and_omits_gloss_at_40_columns(self):
        options = (
            ("r", "resume", "Reattach to the existing session"),
            ("n", "new", "Start another session with a suffix"),
            ("q", "quit", "Leave everything unchanged"),
        )
        narrow_stderr = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", TtyBuffer("\n", tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stderr", narrow_stderr), \
             mock.patch.object(shutil, "get_terminal_size", return_value=os.terminal_size((40, 24))), \
             mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
             mock.patch.object(launcher.termios, "tcsetattr"), \
             mock.patch.object(launcher.tty, "setcbreak"), \
             mock.patch.object(launcher.os, "read", new=patched_menu_reader([b"\n"])):
            self.assertEqual(launcher.prompt_choice("session", "session exists", options, "r"), "r")
        self.assertIn("[r] resume", narrow_stderr.getvalue())
        self.assertNotIn("Reattach", narrow_stderr.getvalue())

        wide_stderr = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", TtyBuffer("xn", tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stderr", wide_stderr), \
             mock.patch.object(shutil, "get_terminal_size", return_value=os.terminal_size((80, 24))), \
             mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
             mock.patch.object(launcher.termios, "tcsetattr"), \
             mock.patch.object(launcher.tty, "setcbreak"), \
             mock.patch.object(launcher.os, "read", new=patched_menu_reader([b"x", b"n"])):
            self.assertEqual(launcher.prompt_choice("session", "session exists", options, "r"), "n")
        self.assertIn("Reattach to the existing session", wide_stderr.getvalue())
        self.assertIn("tap session: choose r, n, or q", wide_stderr.getvalue())
        self.assertEqual(wide_stderr.getvalue().count("tap session: session exists"), 2)

        with mock.patch.object(sys, "stdin", TtyBuffer("", tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stderr", TtyBuffer(tty=True)), \
             self.assertRaises(ValueError):
            launcher.prompt_choice("session", "session exists", (("r", "", "Resume"), ("q", "quit", "Quit")), "r")

    def test_choice_prompt_refuses_non_tty_without_output(self):
        stderr = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", TtyBuffer("r\n", tty=False)), \
             mock.patch.object(sys, "stderr", stderr), self.assertRaises(launcher.LauncherError):
            launcher.prompt_choice("session", "session exists", (("r", "resume", "Resume"), ("q", "quit", "Quit")), "r")
        self.assertEqual(stderr.getvalue(), "")

    def test_choice_prompt_drains_arrow_escape_without_quitting(self):
        options = (("r", "resume", "Resume"), ("n", "new", "New"), ("q", "quit", "Quit"))
        stderr = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", TtyBuffer("\x1b[An", tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stderr", stderr), \
             mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
             mock.patch.object(launcher.termios, "tcsetattr"), \
             mock.patch.object(launcher.tty, "setcbreak"), \
             mock.patch.object(launcher.select, "select", side_effect=[([0], [], []), ([0], [], []), ([], [], [])]), \
             mock.patch.object(launcher.os, "read", side_effect=[b"\x1b", b"[", b"A", b"n"]):
            self.assertEqual(launcher.prompt_choice("session", "session exists", options, "r"), "n")
        self.assertIn("tap session: choose r, n, or q", stderr.getvalue())

    def test_choice_prompt_bare_escape_quits(self):
        # Symmetric to the arrow-escape drain: a BARE Esc (no CSI suffix follows)
        # is the quit gesture the prompt advertises ("Esc quits"), not a drained
        # sequence — it returns "q" immediately without re-prompting.
        options = (("r", "resume", "Resume"), ("n", "new", "New"), ("q", "quit", "Quit"))
        stderr = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", TtyBuffer("\x1b", tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stderr", stderr), \
             mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
             mock.patch.object(launcher.termios, "tcsetattr"), \
             mock.patch.object(launcher.tty, "setcbreak"), \
             mock.patch.object(launcher.select, "select", side_effect=[([], [], [])]), \
             mock.patch.object(launcher.os, "read", side_effect=[b"\x1b"]):
            self.assertEqual(launcher.prompt_choice("session", "session exists", options, "r"), "q")
        self.assertIn("(Esc quits)", stderr.getvalue())

    def test_confirm_rename_uses_the_line_based_prompt_helper(self):
        stdout = TtyBuffer(tty=False)
        stdin = TtyBuffer(tty=True)
        with mock.patch.object(sys, "stdin", stdin), \
             mock.patch.object(sys, "stdout", stdout), \
             mock.patch.object(launcher, "prompt_yes_no", return_value=True) as prompt:
            self.assertTrue(launcher.confirm_rename("/repo", {"repo/old": "repo/new"}))
        prompt.assert_called_once_with(
            "session", "also rename matching tmux sessions and TAP registrations?", default=False
        )
        self.assertIn("Rename 1 existing session/TAP registration(s) under /repo?", stdout.getvalue())

    def test_progress_is_tty_only_and_reports_interrupt(self):
        tty = TtyBuffer(tty=True)
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "NO_COLOR": "1"}, clear=True), \
             mock.patch.object(sys, "stderr", tty):
            with launcher.progress("session", "starting 'repo/scout'"):
                pass
        self.assertIn("tap session: starting 'repo/scout'...", tty.getvalue())
        self.assertNotIn("\x1b", tty.getvalue())

        pipe = TtyBuffer(tty=False)
        with mock.patch.object(sys, "stderr", pipe):
            with launcher.progress("session", "starting 'repo/scout'"):
                pass
        self.assertEqual(pipe.getvalue(), "")

        tty = TtyBuffer(tty=True)
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "NO_COLOR": "1"}, clear=True), \
             mock.patch.object(sys, "stderr", tty), self.assertRaises(KeyboardInterrupt):
            with launcher.progress("session", "starting 'repo/scout'"):
                raise KeyboardInterrupt
        self.assertEqual(tty.getvalue().count("tap session: interrupted"), 1)

        tty = TtyBuffer(tty=True)
        with mock.patch.dict(os.environ, {"TERM": "xterm-256color", "NO_COLOR": "1"}, clear=True), \
             mock.patch.object(sys, "stderr", tty), self.assertRaises(RuntimeError):
            with launcher.progress("session", "starting 'repo/scout'"):
                raise RuntimeError("launch failed")
        line = "tap session: starting 'repo/scout'..."
        self.assertTrue(tty.getvalue().endswith(f"\r{' ' * len(line)}\r"))

    def test_run_invocation_shows_progress_line_on_tty(self):
        record = launcher.SessionRecord(
            name="repo/scout",
            harness="claude",
            cwd="/repo",
            base="repo",
            tag="scout",
            index=1,
        )
        invocation = launcher.Invocation(["claude"], {})

        def fake_run(command, **_kwargs):
            return types.SimpleNamespace(returncode=0, stdout="")

        tty = TtyBuffer(tty=True)
        with mock.patch.object(launcher, "tmux_has", return_value=False), \
             mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
             mock.patch.object(launcher, "tmux_attach", return_value=0), \
             mock.patch.object(sys, "stderr", tty):
            rc = launcher.run_invocation(record, invocation, dry_run=False)

        self.assertEqual(rc, 0)
        self.assertIn("tap session: starting 'repo/scout'...", tty.getvalue())
        line = "tap session: starting 'repo/scout'..."
        self.assertTrue(tty.getvalue().endswith(f"\r{' ' * len(line)}\r"))

        pipe = TtyBuffer(tty=False)
        with mock.patch.object(launcher, "tmux_has", return_value=False), \
             mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
             mock.patch.object(launcher, "tmux_attach", return_value=0), \
             mock.patch.object(sys, "stderr", pipe):
            rc = launcher.run_invocation(record, invocation, dry_run=False)

        self.assertEqual(rc, 0)
        self.assertEqual(pipe.getvalue(), "")


class AttachModeTests(unittest.TestCase):
    """tap-ya2e: attach-vs-detached is decided up front by isatty, and a failed
    attach on a running, registered session never tears it down."""

    def _args(self, **overrides):
        base = dict(attach=False, dry_run=False)
        base.update(overrides)
        return types.SimpleNamespace(**base)

    def test_caller_has_tty_requires_both_stdin_and_stdout(self):
        with mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)):
            self.assertTrue(launcher.caller_has_tty())
        with mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=False)):
            self.assertFalse(launcher.caller_has_tty())
        with mock.patch.object(sys, "stdin", TtyBuffer(tty=False)), \
             mock.patch.object(sys, "stdout", TtyBuffer(tty=True)):
            self.assertFalse(launcher.caller_has_tty())

    def test_resolve_attach_mode_human_tty_attaches(self):
        # INVARIANT: a real terminal (human launch) always attaches — the human
        # path is unchanged. Only TTY-less callers get the detached path.
        with mock.patch.object(launcher, "caller_has_tty", return_value=True):
            self.assertTrue(launcher.resolve_attach_mode(self._args()))

    def test_resolve_attach_mode_no_tty_detaches(self):
        with mock.patch.object(launcher, "caller_has_tty", return_value=False):
            self.assertFalse(launcher.resolve_attach_mode(self._args()))

    def test_resolve_attach_mode_force_attach_overrides_no_tty(self):
        with mock.patch.object(launcher, "caller_has_tty", return_value=False):
            self.assertTrue(launcher.resolve_attach_mode(self._args(attach=True)))

    def test_attach_after_launch_leaves_running_session_alive_on_attach_failure(self):
        record = launcher.SessionRecord(
            name="repo/scout", harness="claude", cwd="/repo", base="repo",
            tag="scout", index=1,
        )
        killed = []

        def fake_run(command, **_kwargs):
            if command[:2] == ["tmux", "kill-session"]:
                killed.append(command)
            return types.SimpleNamespace(returncode=0, stdout="")

        stderr = TtyBuffer(tty=True)
        with mock.patch.object(launcher, "tmux_attach", return_value=1), \
             mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
             mock.patch.object(sys, "stderr", stderr):
            rc = launcher.attach_after_launch(record)

        # Attach failed, but the session is healthy + registered: report success
        # and NEVER kill it (the ya2e defect was kill-session after registration).
        self.assertEqual(rc, 0)
        self.assertEqual(killed, [])
        self.assertIn("running and registered", stderr.getvalue())

    def test_attach_after_launch_success_is_byte_identical(self):
        record = launcher.SessionRecord(
            name="repo/scout", harness="claude", cwd="/repo", base="repo",
            tag="scout", index=1,
        )
        stderr = TtyBuffer(tty=True)
        with mock.patch.object(launcher, "tmux_attach", return_value=0), \
             mock.patch.object(sys, "stderr", stderr):
            rc = launcher.attach_after_launch(record)
        self.assertEqual(rc, 0)
        self.assertEqual(stderr.getvalue(), "")

    def test_tmux_attach_refuses_in_tmux_with_typed_rc_and_no_output(self):
        # Lane D D2 (tap-rxqb): the in-tmux refusal is a TYPED sentinel the tail
        # branches on — and tmux_attach itself is now silent, so the refusal can
        # never stack a failure-shaped warning under the caller's one receipt.
        # OLD: the refusal emitted the "please do not use the tap launcher within
        # an existing tmux session" warning here AND returned 1, which
        # attach_after_launch then re-narrated as "could not attach (tmux exit 1)"
        # plus an "(attach failed)" receipt — a refusal wearing failure's clothes
        # (merged-A E4≡E1 finding; verdict flip kept per ruling 5).
        #
        # tap-v0bg changed this test's PRECONDITION, not its claim. "$TMUX is
        # set" no longer means "the caller is inside a pane" — the caller must
        # be positively identified as in-pane (our tty IS that pane's tty), so
        # the fixture now models that. The assertions are unchanged: typed
        # sentinel rc, silent.
        stderr = TtyBuffer(tty=True)
        with mock.patch.dict(os.environ, {"TMUX": "/tmp/tmux-501/default,1,0", "TMUX_PANE": "%7"}), \
             mock.patch.object(launcher, "caller_tty", return_value="/dev/ttys001"), \
             mock.patch.object(launcher, "tmux_pane_tty", return_value="/dev/ttys001", create=True), \
             mock.patch.object(sys, "stderr", stderr):
            rc = launcher.tmux_attach("repo/scout")
        self.assertEqual(rc, launcher.ATTACH_REFUSED_IN_TMUX)
        self.assertEqual(stderr.getvalue(), "")

    def test_unobservable_foreground_tty_refuses_without_spawning(self):
        with mock.patch.dict(os.environ, {}, clear=True), \
             mock.patch.object(sys, "stdin", io.StringIO()), \
             mock.patch.object(launcher.subprocess, "call") as attach:
            self.assertEqual(launcher.tmux_attach("repo/scout"), launcher.ATTACH_REFUSED_TTY_OWNERSHIP)
        attach.assert_not_called()

    def test_inherited_tmux_env_does_not_refuse_attach(self):
        # tap-v0bg, the live symptom: a Cursor terminal that is NOT inside tmux
        # still carries an exported $TMUX (e.g. from the pane that launched the
        # window). The value is syntactically valid AND points at a live server,
        # so presence and does-it-parse checks both pass — and Ops was silently
        # handed a detached session instead of the attach he asked for.
        #
        # The discriminator is tty IDENTITY: our tty is not that pane's tty.
        calls = {}

        def fake_call(argv, env=None):
            calls["argv"] = argv
            calls["env"] = env
            return 0

        with mock.patch.dict(os.environ, {"TMUX": "/private/tmp/tmux-502/default,17584,52", "TMUX_PANE": "%7"}), \
             mock.patch.object(launcher, "caller_tty", return_value="/dev/ttys009"), \
             mock.patch.object(launcher, "tmux_pane_tty", return_value="/dev/ttys001", create=True), \
             mock.patch.object(launcher.subprocess, "call", fake_call), \
             mock.patch.object(launcher, "caller_owns_foreground_tty", return_value=True):
            rc = launcher.tmux_attach("repo/scout")
        self.assertEqual(rc, 0)
        self.assertEqual(calls["argv"], [
            "tmux", "-S", "/private/tmp/tmux-502/default",
            "attach-session", "-t", "=repo/scout",
        ])
        # The strip is load-bearing: tmux's OWN nesting guard also trusts bare
        # $TMUX, so leaving it would trade a wrong receipt for a wrong "sessions
        # should be nested with care" error — still no attach.
        self.assertNotIn("TMUX", calls["env"])
        self.assertNotIn("TMUX_PANE", calls["env"])

    def test_unset_tmux_attaches_without_touching_the_child_env(self):
        # The NO arm has two shapes and only the inherited one strips. A caller
        # that never had $TMUX must reach attach-session exactly as before —
        # env=None, the pre-tap-v0bg call.
        calls = {}

        def fake_call(argv, env=None):
            calls["argv"] = argv
            calls["env"] = env
            return 0

        with mock.patch.dict(os.environ, {}, clear=True), \
             mock.patch.object(launcher.subprocess, "call", fake_call), \
             mock.patch.object(launcher, "caller_owns_foreground_tty", return_value=True):
            rc = launcher.tmux_attach("repo/scout")
        self.assertEqual(rc, 0)
        self.assertIsNone(calls["env"])

    def test_exited_server_in_tmux_env_attaches_with_a_stripped_env(self):
        # tap-v0bg acceptance 2: a POSITIVELY absent server unlocks the attach.
        # Socket-path existence is not liveness (this machine keeps many stale
        # tap-selfstop-* sockets), so the pid embedded in $TMUX is the authority
        # and it is checked as a PROCESS, never by reading tmux's error text.
        calls = {}

        def fake_call(argv, env=None):
            calls["argv"] = argv
            calls["env"] = env
            return 0

        def exited(pid, sig):
            raise ProcessLookupError

        with mock.patch.dict(os.environ, {"TMUX": "/private/tmp/tmux-502/default,999999,52", "TMUX_PANE": "%7"}), \
             mock.patch.object(launcher.os, "kill", exited), \
             mock.patch.object(launcher.subprocess, "call", fake_call), \
             mock.patch.object(launcher, "caller_owns_foreground_tty", return_value=True):
            rc = launcher.tmux_attach("repo/scout")
        self.assertEqual(rc, 0)
        self.assertEqual(calls["argv"], [
            "tmux", "-S", "/private/tmp/tmux-502/default",
            "attach-session", "-t", "=repo/scout",
        ])
        self.assertNotIn("TMUX", calls["env"])
        self.assertNotIn("TMUX_PANE", calls["env"])

    def test_live_server_we_may_not_signal_is_never_treated_as_gone(self):
        # Only a POSITIVE absence unlocks. A pid we are not allowed to signal is
        # evidence of a LIVE process, so the decision must fall through to the
        # tty comparison rather than reading "cannot signal" as "not in tmux".
        def not_permitted(pid, sig):
            raise PermissionError

        with mock.patch.dict(os.environ, {"TMUX": "/tmp/tmux-501/default,1,0", "TMUX_PANE": "%7"}), \
             mock.patch.object(launcher.os, "kill", not_permitted), \
             mock.patch.object(launcher, "caller_tty", return_value="/dev/ttys001"), \
             mock.patch.object(launcher, "tmux_pane_tty", return_value="/dev/ttys001", create=True):
            self.assertEqual(launcher.tmux_attach("repo/scout"), launcher.ATTACH_REFUSED_IN_TMUX)

    def test_unverifiable_tmux_state_refuses_and_never_attaches(self):
        # Polarity is deliberately asymmetric (tap-fuz9 direction): refusing
        # wrongly prints a command the human can run; attaching wrongly nests a
        # client. So every state we cannot resolve refuses WITHOUT attaching —
        # and with its own rc, because "we could not tell" is a different fact
        # from "you are in tmux".
        def fail_if_called(*args, **kwargs):  # pragma: no cover - must not run
            raise AssertionError("an unresolved tmux state must never attach")

        env = {"TMUX": "/tmp/tmux-501/default,1,0", "TMUX_PANE": "%7"}
        cases = {
            "no tty at all (an agent's tool call)": ("", "/dev/ttys001"),
            "pane probe unobservable": ("/dev/ttys009", None),
        }
        for label, (tty, pane_tty) in cases.items():
            with self.subTest(label):
                with mock.patch.dict(os.environ, env), \
                     mock.patch.object(launcher, "caller_tty", return_value=tty), \
                     mock.patch.object(launcher, "tmux_pane_tty", return_value=pane_tty), \
                     mock.patch.object(launcher.subprocess, "call", fail_if_called):
                    rc = launcher.tmux_attach("repo/scout")
                self.assertEqual(rc, launcher.ATTACH_REFUSED_AMBIGUOUS)
        # $TMUX set with no $TMUX_PANE: nothing to compare our tty against.
        with mock.patch.dict(os.environ, {"TMUX": "/tmp/tmux-501/default,1,0"}, clear=True), \
             mock.patch.object(launcher, "caller_tty", return_value="/dev/ttys009"), \
             mock.patch.object(launcher.subprocess, "call", fail_if_called):
            self.assertEqual(launcher.tmux_attach("repo/scout"), launcher.ATTACH_REFUSED_AMBIGUOUS)

    def test_ambiguous_refusal_receipt_is_distinct_from_the_in_tmux_one(self):
        # Reporting "in-tmux caller" for a state we could not verify is the exact
        # mislabeling tap-v0bg exists to remove, and it is not the warning-pair
        # arm either — nothing failed, we declined to guess.
        record = launcher.SessionRecord(
            name="repo/scout", harness="claude", cwd="/repo", base="repo",
            tag="scout", index=1,
        )
        stdout = TtyBuffer(tty=True)
        stderr = TtyBuffer(tty=True)
        with mock.patch.object(launcher, "tmux_attach", return_value=launcher.ATTACH_REFUSED_AMBIGUOUS), \
             mock.patch.object(sys, "stdout", stdout), \
             mock.patch.object(sys, "stderr", stderr):
            rc = launcher.attach_after_launch(record)
        self.assertEqual(rc, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertNotIn("in-tmux caller", stdout.getvalue())
        self.assertIn("tmux caller state unverified", stdout.getvalue())
        self.assertIn("tmux attach -t repo/scout", stdout.getvalue())

    def test_attach_after_launch_refusal_is_one_receipt_never_a_warning(self):
        # The refusal arm's whole narration: ONE detached receipt naming the
        # mode. No "could not attach" warning stacks on top of it (E4≡E1).
        record = launcher.SessionRecord(
            name="repo/scout", harness="claude", cwd="/repo", base="repo",
            tag="scout", index=1,
        )
        stdout = TtyBuffer(tty=True)
        stderr = TtyBuffer(tty=True)
        with mock.patch.object(launcher, "tmux_attach", return_value=launcher.ATTACH_REFUSED_IN_TMUX), \
             mock.patch.object(sys, "stdout", stdout), \
             mock.patch.object(sys, "stderr", stderr):
            rc = launcher.attach_after_launch(record)
        self.assertEqual(rc, 0)
        self.assertEqual(stderr.getvalue(), "")
        self.assertIn("running detached (in-tmux caller)", stdout.getvalue())
        self.assertIn("tmux attach -t repo/scout", stdout.getvalue())

    def test_cmd_new_fresh_attach_runs_outside_reset_fence_lock(self):
        # sol 091513: fresh cmd_new alone used to pass attach_mode into
        # run_record under the outer sidecar — a blocking attach-session pins
        # reset.fence.json.lock. In-lock run must be attach=False; tail outside.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            bus = root / ".tap" / "bus"
            bus.mkdir(parents=True)
            (bus / "registry.json").write_text(
                json.dumps({"team": {"name": "repo"}, "agents": {}}) + "\n"
            )
            manifest = root / "sessions.json"
            claude_home = root / "claude-home"
            (claude_home / "projects").mkdir(parents=True)
            args = types.SimpleNamespace(
                manifest=str(manifest),
                harness="claude",
                unique=None,
                tag=None,
                label="scout",
                model=None,
                teams=False,
                dry_run=False,
                attach=True,
                json=False,
                fresh=False,
            )
            run_attach = []
            run_depth = []
            tail_depth = []

            def fake_run_record(*_a, **kwargs):
                run_attach.append(kwargs.get("attach"))
                run_depth.append(launcher._reset_fence_mutation_depth)
                return 0

            def fake_attach_after(_record):
                tail_depth.append(launcher._reset_fence_mutation_depth)
                return 0

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.dict(
                    os.environ, {"TAP_CLAUDE_HOME": str(claude_home)}
                ), mock.patch.object(
                    launcher, "tmux_sessions", return_value=set()
                ), mock.patch.object(
                    launcher, "tap_handles", return_value=set()
                ), mock.patch.object(
                    launcher, "resolve_attach_mode", return_value=True
                ), mock.patch.object(
                    launcher, "run_record", side_effect=fake_run_record
                ), mock.patch.object(
                    launcher, "attach_after_launch", side_effect=fake_attach_after
                ), mock.patch.object(
                    launcher, "emit_receipt"
                ), mock.patch.object(
                    launcher, "emit_detached_receipt"
                ), mock.patch.object(
                    launcher, "bind_reserved_handle"
                ), mock.patch.object(
                    launcher, "mark_launch_ready"
                ):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

        self.assertEqual(rc, 0)
        self.assertEqual(run_attach, [False])
        self.assertGreater(run_depth[0], 0, "run_record must still be under outer lock")
        self.assertEqual(tail_depth, [0], "attach_after_launch must run at lock depth 0")

    def test_run_invocation_detached_never_attaches(self):
        record = launcher.SessionRecord(
            name="repo/scout", harness="claude", cwd="/repo", base="repo",
            tag="scout", index=1,
        )
        invocation = launcher.Invocation(["claude"], {})
        attached = []
        commands = []

        def fake_run(command, **_kwargs):
            commands.append(command)
            return types.SimpleNamespace(returncode=0, stdout="")

        with mock.patch.object(launcher, "tmux_has", return_value=False), \
             mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
             mock.patch.object(launcher, "tmux_attach",
                               side_effect=lambda name: attached.append(name) or 0):
            rc = launcher.run_invocation(record, invocation, dry_run=False, attach=False)

        self.assertEqual(rc, 0)
        self.assertEqual(attached, [])
        created = next(command for command in commands if command[:2] == ["tmux", "new-session"])
        self.assertEqual(created[3:7], ["-x", "200", "-y", "60"])

    # --- grok P1: the ya2e rule applies to the resume/adopted paths too ---------
    def _resume_record(self):
        return launcher.SessionRecord(
            name="repo/scout", harness="claude", cwd="/repo", base="repo",
            tag="scout", index=1,
        )

    def test_resume_attach_tail_no_tty_detaches_without_attaching(self):
        record = self._resume_record()
        attached = []
        stdout = TtyBuffer(tty=True)
        with mock.patch.object(launcher, "caller_has_tty", return_value=False), \
             mock.patch.object(launcher, "tmux_attach",
                               side_effect=lambda name: attached.append(name) or 0), \
             mock.patch.object(sys, "stdout", stdout):
            rc = launcher.resume_attach_tail(record)
        # A TTY-less resume decides up front: no doomed attach, healthy session
        # left running, success returned (so no caller rollback fires).
        self.assertEqual(rc, 0)
        self.assertEqual(attached, [])
        self.assertIn("running detached", stdout.getvalue())

    def test_resume_attach_tail_tty_attach_failure_leaves_session_alive(self):
        record = self._resume_record()
        killed = []

        def fake_run(command, **_kwargs):
            if command[:2] == ["tmux", "kill-session"]:
                killed.append(command)
            return types.SimpleNamespace(returncode=0, stdout="")

        with mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(launcher, "tmux_attach", return_value=1), \
             mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
             mock.patch.object(sys, "stderr", TtyBuffer(tty=True)):
            rc = launcher.resume_attach_tail(record)
        # Attach failed with a TTY present: session stays alive, success returned,
        # never killed — attach is the tail of a resume, never its verdict.
        self.assertEqual(rc, 0)
        self.assertEqual(killed, [])

    def test_run_native_resume_ttyless_returns_zero_so_adopted_resume_never_rolls_back(self):
        # The exact grok P1: run_native_resume ran run_invocation(attach=False)
        # then a BARE tmux_attach whose nonzero bubbled into run_adopted_resume's
        # rollback_launch_transaction — orphaning a healthy, registered seat when a
        # TTY-less caller's attach failed. Now the ttyless tail returns 0.
        record = self._resume_record()
        attached = []
        with mock.patch.object(launcher, "build_native_resume_invocation",
                               return_value=launcher.Invocation(["claude"], {})), \
             mock.patch.object(launcher, "apply_launch_env", side_effect=lambda inv, rec, **kw: inv), \
             mock.patch.object(launcher, "run_invocation", return_value=0), \
             mock.patch.object(launcher, "caller_has_tty", return_value=False), \
             mock.patch.object(launcher, "tmux_attach",
                               side_effect=lambda name: attached.append(name) or 0), \
             mock.patch.object(sys, "stderr", TtyBuffer(tty=True)):
            rc = launcher.run_native_resume(record, native_query=None, dry_run=False)
        self.assertEqual(rc, 0)          # success -> run_adopted_resume's rc!=0 rollback never fires
        self.assertEqual(attached, [])   # no doomed attach attempted


class LauncherTests(unittest.TestCase):
    def test_pane_facts_bind_dead_state_to_the_same_tmux_observation(self):
        line = "repo/scout:0.0\t%41\tcodex\t900:100\t1\t4242\t/repo\n"
        facts = launcher.parse_pane_facts(line)
        self.assertIsNotNone(facts)
        self.assertTrue(facts.dead)
        self.assertEqual(facts.pane_pid, 4242)
        self.assertEqual(facts.server_epoch, "srv:900:100")

    def test_pane_facts_parse_requires_the_strict_seven_field_record(self):
        self.assertIsNone(launcher.parse_pane_facts(
            "repo/scout:0.0\t%41\tcodex\t900:100\t/repo\n"
        ))
        self.assertIsNone(launcher.parse_pane_facts(
            "repo/scout:0.0\t%41\tcodex\t900:100\t0\t/repo\n"
        ))
        self.assertIsNone(launcher.parse_pane_facts(
            "repo/scout:0.0\t%41\tcodex\t900:100\tmaybe\t4242\t/repo\n"
        ))
        self.assertIsNone(launcher.parse_pane_facts(
            "repo/scout:0.0\t%41\tcodex\t900:100\t0\tnotapid\t/repo\n"
        ))
        self.assertIsNone(launcher.parse_pane_facts(
            "\t%41\tcodex\t900:100\t0\t4242\t/repo\n"
        ))

    def test_pane_facts_path_keeps_tabs_because_it_is_last(self):
        facts = launcher.parse_pane_facts(
            "repo/scout:0.0\t%41\tcodex\t900:100\t0\t4242\t/repo\twith\ttabs\n"
        )
        self.assertIsNotNone(facts)
        self.assertFalse(facts.dead)
        self.assertEqual(facts.pane_pid, 4242)
        self.assertEqual(facts.path, "/repo\twith\ttabs")

    def test_registry_write_boundary_rejects_malformed_pane_id(self):
        line = "repo/scout:0.0\t%tap-claude\tcodex\t900:100\t0\t4242\t/repo\n"
        facts = launcher.parse_pane_facts(line)
        with self.assertRaisesRegex(
            launcher.LauncherError,
            r"identity_unverified.*invalid pane_id.*refusing registry write",
        ):
            launcher.require_registry_pane_facts(facts)

        record = launcher.SessionRecord(
            name="repo/scout", harness="codex", cwd="/repo",
            base="repo", tag="scout", index=1, launch_id="launch-token",
        )
        for writer in (launcher.bind_reserved_handle, launcher.mark_launch_ready):
            with self.subTest(writer=writer.__name__), self.assertRaisesRegex(
                launcher.LauncherError,
                r"identity_unverified.*invalid pane_id.*refusing registry write",
            ):
                writer(record, facts)

    def test_malformed_stored_pane_id_never_licenses_lifecycle_mutation(self):
        for malformed_id in ("%tap-codex", 123):
            with self.subTest(pane_id=malformed_id):
                entry = {
                    "status": "active", "delivery": "pane", "session": "repo/scout",
                    "pane": "missing-pane", "pane_id": malformed_id, "harness": "codex",
                }
                self.assertFalse(
                    launcher.seat_is_reclaimable_corpse(
                        entry, live_sessions=set(), observed_server_epoch="srv:900:100",
                        observed_boot_id="bootuuid:current",
                    )
                )
                with mock.patch.object(launcher, "tmux_pane_facts", return_value=None), \
                     mock.patch.object(launcher, "tmux_has", return_value=False):
                    self.assertFalse(launcher.entry_observed_dead(entry))

                launching = dict(entry, status_reason="launching", launch_id="token",
                                 registered_at="2026-08-11T00:00:00Z")
                self.assertFalse(
                    launcher.pending_reservation_expired(
                        launching, live_sessions=set(), now="2026-08-11T00:10:00Z"
                    )
                )

    def test_resume_all_treats_no_tmux_server_as_empty_namespace(self):
        args = types.SimpleNamespace(
            key=None,
            legacy_name=None,
            model=None,
            teams=False,
            dry_run=True,
            json=False,
        )
        state = launcher.Manifest(
            sessions=[
                launcher.SessionRecord(
                    name="repo/scout",
                    harness="claude",
                    cwd="/tmp/repo",
                    base="repo",
                    tag="scout",
                    index=1,
                )
            ],
            dir_aliases={"/tmp/repo": "repo"},
        )
        no_server_errors = (
            "no server running on /private/tmp/tmux-501/default\n",
            "error connecting to /private/tmp/tmux-501/default (No such file or directory)\n",
        )

        for stderr in no_server_errors:
            launched = []
            result = subprocess.CompletedProcess(
                args=["tmux", "list-sessions"], returncode=1, stdout="", stderr=stderr
            )
            with self.subTest(stderr=stderr), \
                 mock.patch.object(launcher, "tmux_list_sessions_result", return_value=result), \
                 mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "_reset_fence_entry_barrier"), \
                 mock.patch.object(launcher, "_refuse_if_flip_authority"), \
                 mock.patch.object(
                     launcher,
                     "run_record_detached",
                     side_effect=lambda action, record, dry_run: launched.append(
                         (action, record.name, dry_run)
                     ) or 0,
                 ):
                self.assertEqual(launcher.cmd_resume_all(args, state, "/tmp/repo"), 0)
            self.assertEqual(launched, [("resume", "repo/scout", True)])

    def test_resume_all_reuses_empty_namespace_snapshot_to_reclaim_pending_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "pending",
                        "delivery": "pane",
                        "session": "repo/scout",
                        "harness": "claude",
                        "registered_at": "2099-01-01T00:00:00Z",
                        "launch_id": "orphaned-launch",
                        "boot_id": "bootuuid:prior",
                    },
                },
            }) + "\n")
            state = launcher.Manifest(
                sessions=[
                    launcher.SessionRecord(
                        name="repo/scout",
                        harness="claude",
                        cwd=str(root),
                        base="repo",
                        tag="scout",
                        index=1,
                    )
                ],
                dir_aliases={str(root): "repo"},
            )
            args = types.SimpleNamespace(
                key=None,
                legacy_name=None,
                model=None,
                teams=False,
                dry_run=False,
                json=False,
            )
            no_server = subprocess.CompletedProcess(
                args=["tmux", "list-sessions"],
                returncode=1,
                stdout="",
                stderr="no server running on /private/tmp/tmux-501/default\n",
            )
            launched = []

            with mock.patch.object(launcher, "tmux_list_sessions_result", return_value=no_server), \
                 mock.patch.object(launcher, "tmux_sessions_or_none", side_effect=AssertionError(
                     "resume-all must reuse its authoritative namespace snapshot"
                 )), \
                 mock.patch.object(launcher, "root_for_cwd", return_value=str(root)), \
                 mock.patch.object(launcher, "writable_tap_registry_path", return_value=registry), \
                 mock.patch.object(launcher, "current_boot_id", return_value="bootuuid:current"), \
                 mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "_reset_fence_entry_barrier"), \
                 mock.patch.object(launcher, "_refuse_if_flip_authority"), \
                 mock.patch.object(launcher, "mark_reset_generation_reused"), \
                 mock.patch.object(
                     launcher,
                     "run_record_detached",
                     side_effect=lambda action, record, dry_run, **_kwargs: launched.append(
                         (action, record.name, dry_run)
                     ) or 0,
                 ):
                self.assertEqual(launcher.cmd_resume_all(args, state, str(root)), 0)

            self.assertEqual(launched, [("resume", "repo/scout", False)])
            row = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(row["status"], "pending")
            self.assertNotEqual(row["launch_id"], "orphaned-launch")
            self.assertEqual(row["boot_id"], "bootuuid:current")

    def test_resume_all_refuses_when_tmux_snapshot_is_unobservable(self):
        args = types.SimpleNamespace(
            key=None,
            legacy_name=None,
            model=None,
            teams=False,
            dry_run=False,
            json=False,
        )
        state = launcher.Manifest(sessions=[], dir_aliases={})
        result = subprocess.CompletedProcess(
            args=["tmux", "list-sessions"],
            returncode=1,
            stdout="",
            stderr="permission denied opening the tmux socket\n",
        )

        with mock.patch.object(launcher, "tmux_list_sessions_result", return_value=result), \
             mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
             mock.patch.object(launcher, "_reset_fence_entry_barrier"), \
             mock.patch.object(launcher, "_refuse_if_flip_authority"), \
             self.assertRaisesRegex(launcher.LauncherError, "snapshot is unobservable"):
            launcher.cmd_resume_all(args, state, "/tmp/repo")

    def test_no_server_and_unobservable_snapshot_have_distinct_diagnostics(self):
        no_server = subprocess.CompletedProcess(
            args=["tmux", "list-sessions"],
            returncode=1,
            stdout="",
            stderr="no server running on /private/tmp/tmux-501/default\n",
        )
        with mock.patch.object(launcher, "tmux_list_sessions_result", return_value=no_server), \
             self.assertRaisesRegex(
                 launcher.TmuxNoServerError,
                 "server is not running.*namespace is empty",
             ):
            launcher.tmux_sessions()

        unobservable = subprocess.CompletedProcess(
            args=["tmux", "list-sessions"],
            returncode=1,
            stdout="",
            stderr="permission denied opening the tmux socket\n",
        )
        with mock.patch.object(launcher, "tmux_list_sessions_result", return_value=unobservable), \
             self.assertRaisesRegex(
                 launcher.LauncherError,
                 "snapshot is unobservable.*refusing",
             ):
            launcher.tmux_sessions()

    def test_launch_snapshot_treats_only_recognized_no_server_as_empty(self):
        no_server_errors = (
            "no server running on /private/tmp/tmux-501/default\n",
            "error connecting to /private/tmp/tmux-501/default (No such file or directory)\n",
        )
        for stderr in no_server_errors:
            result = subprocess.CompletedProcess(
                args=["tmux", "list-sessions"], returncode=1, stdout="", stderr=stderr
            )
            with self.subTest(stderr=stderr), mock.patch.object(
                launcher.subprocess, "run", return_value=result
            ):
                self.assertEqual(launcher.tmux_sessions_for_namespace(), set())
                self.assertIsNone(
                    launcher.tmux_sessions_or_none(),
                    "a transient no-server response must stay unobservable to liveness classification",
                )

    def test_launch_snapshot_keeps_other_tmux_failures_unobservable(self):
        result = subprocess.CompletedProcess(
            args=["tmux", "list-sessions"],
            returncode=1,
            stdout="",
            stderr="permission denied opening the tmux socket\n",
        )
        with mock.patch.object(launcher.subprocess, "run", return_value=result):
            with self.assertRaises(launcher.LauncherError):
                launcher.tmux_sessions_for_namespace()
            self.assertIsNone(launcher.tmux_sessions_or_none())

    def test_transient_no_server_does_not_reclaim_a_prior_generation_row(self):
        entry = {
            "status": "active",
            "delivery": "pane",
            "session": "repo/scout",
            "pane": "repo/scout:0.0",
            "pane_id": "%91",
            "server_epoch": "srv:700:10",
            "boot_id": "boot:1",
        }
        self.assertFalse(
            launcher.seat_is_reclaimable_corpse(
                entry,
                live_sessions=set(),
                observed_server_epoch=None,
                observed_boot_id="boot:1",
            )
        )

    def test_allocates_next_name_from_base_harness_tag_and_existing_names(self):
        name = launcher.allocate_name(
            base="AESOP-Improvements",
            harness="codex",
            tag="ponytail",
            existing_names={
                "AESOP-Improvements/ponytail",
                "AESOP-Improvements/ponytail-2",
            },
        )

        self.assertEqual(name, "AESOP-Improvements/ponytail-3")

    def test_allocates_first_name_without_numeric_suffix(self):
        self.assertEqual(
            launcher.allocate_name(
                base="AESOP-Improvements",
                harness="claude",
                tag=None,
                existing_names=set(),
            ),
            "AESOP-Improvements/claude",
        )

    def test_allocates_second_active_duplicate_with_one_based_suffix(self):
        self.assertEqual(
            launcher.allocate_name(
                base="AESOP-Improvements",
                harness="claude",
                tag=None,
                existing_names={"AESOP-Improvements/claude"},
            ),
            "AESOP-Improvements/claude-2",
        )

    def test_make_new_record_ignores_stale_manifest_records_when_allocating(self):
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(
            sessions=[
                launcher.SessionRecord(
                    name="xx/claude",
                    harness="claude",
                    cwd=cwd,
                    base="xx",
                    index=1,
                ),
            ],
            dir_aliases={launcher.root_for_cwd(cwd): "xx"},
        )
        args = types.SimpleNamespace(harness="claude", unique=None, tag=None, label=None, model="sonnet", teams=False)
        original_tmux_sessions = launcher.tmux_sessions
        original_tap_handles = launcher.tap_handles
        try:
            launcher.tmux_sessions = lambda: set()
            launcher.tap_handles = lambda _root: set()

            record = launcher.make_new_record(args, manifest)
        finally:
            launcher.tmux_sessions = original_tmux_sessions
            launcher.tap_handles = original_tap_handles

        self.assertEqual(record.name, "xx/claude")
        self.assertEqual(record.index, 1)

    def test_make_new_record_respects_active_tmux_names_when_allocating(self):
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(sessions=[], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        args = types.SimpleNamespace(harness="claude", unique=None, tag=None, label=None, model="sonnet", teams=False)
        original_tmux_sessions = launcher.tmux_sessions
        original_tmux_sessions_or_none = launcher.tmux_sessions_or_none
        original_tap_handles = launcher.tap_handles
        try:
            launcher.tmux_sessions = lambda: {"xx/claude"}
            launcher.tmux_sessions_or_none = lambda: {"xx/claude"}
            launcher.tap_handles = lambda _root: set()

            record = launcher.make_new_record(args, manifest)
        finally:
            launcher.tmux_sessions = original_tmux_sessions
            launcher.tmux_sessions_or_none = original_tmux_sessions_or_none
            launcher.tap_handles = original_tap_handles

        self.assertEqual(record.name, "xx/claude-2")
        self.assertEqual(record.index, 2)

    def test_make_new_record_does_not_default_fable_model_to_fable_tag(self):
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(sessions=[], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        args = types.SimpleNamespace(harness="claude", unique=None, tag=None, label=None, model="fable", teams=False)
        original_tmux_sessions = launcher.tmux_sessions
        original_tap_handles = launcher.tap_handles
        try:
            launcher.tmux_sessions = lambda: set()
            launcher.tap_handles = lambda _root: set()

            record = launcher.make_new_record(args, manifest)
        finally:
            launcher.tmux_sessions = original_tmux_sessions
            launcher.tap_handles = original_tap_handles

        self.assertEqual(record.name, "xx/claude")
        self.assertIsNone(record.tag)

    def test_make_new_record_explicit_label_overrides_fable_default_tag(self):
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(sessions=[], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        args = types.SimpleNamespace(harness="claude", unique=None, tag=None, label="planner", model="fable", teams=False)
        original_tmux_sessions = launcher.tmux_sessions
        original_tap_handles = launcher.tap_handles
        try:
            launcher.tmux_sessions = lambda: set()
            launcher.tap_handles = lambda _root: set()

            record = launcher.make_new_record(args, manifest)
        finally:
            launcher.tmux_sessions = original_tmux_sessions
            launcher.tap_handles = original_tap_handles

        self.assertEqual(record.name, "xx/planner")
        self.assertEqual(record.tag, "planner")

    def test_claim_pending_handle_uses_legacy_registry_when_that_is_the_bus(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / "tmp" / "tap" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({"team": {"name": "legacy"}, "agents": {}}) + "\n")
            record = launcher.SessionRecord(
                name="legacy/scout",
                harness="codex",
                cwd=str(root),
                base="legacy",
                tag="scout",
                index=1,
            )

            launcher.claim_pending_handle(record)

            payload = json.loads(registry.read_text())
            self.assertEqual(payload["agents"]["scout"]["status"], "pending")
            self.assertFalse((root / ".tap" / "bus" / "registry.json").exists())

    # tap-94em. Launch is the INSTANTIATION moment: nothing is bound yet, so the
    # pane's own root rightly decides the binding, and these two sites must stay
    # unguarded while the recovery sites are guarded. Deleting both writes passed
    # the entire python suite before this test existed, which means the comment
    # explaining why they are exempt bound nobody -- the same shape as tap-68lp,
    # where a rule sat one line above the code that broke it. A future auditor
    # who "fixes" these for consistency with the native repair binding guard now reds
    # here instead of silently shipping an unbound seat.
    def test_launch_instantiation_decides_the_worktree_binding(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": root.name, "worktree_root": str(root)},
                "agents": {},
            }) + "\n")
            record = launcher.SessionRecord(
                name=f"{root.name}/scout",
                harness="claude",
                cwd=str(root),
                base=root.name,
                tag="scout",
                index=1,
            )

            launcher.claim_pending_handle(record)

            reserved = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(reserved["status"], "pending")
            self.assertEqual(
                reserved.get("registered_from_worktree"),
                str(root.resolve()),
                "claim_pending_handle left a fresh seat unbound; launch is the "
                "instantiation moment and is the site that DECIDES the binding",
            )

            launcher.bind_reserved_handle(
                record,
                launcher.PaneFacts(f"{root.name}/scout:0.0", "%7", "claude", str(root)),
            )

            bound = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(bound["status"], "active")
            self.assertEqual(
                bound.get("registered_from_worktree"),
                str(root.resolve()),
                "bind_reserved_handle dropped the binding decided at reservation",
            )

    def test_claim_pending_handle_clears_native_identity_on_harness_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            record = launcher.SessionRecord(
                name=f"{root.name}/sol",
                harness="codex",
                cwd=str(root),
                base=root.name,
                tag="sol",
                index=1,
            )
            registry.write_text(json.dumps({
                "team": {"name": root.name, "worktree_root": str(root)},
                "agents": {
                    "sol": {
                        "status": "active",
                        "session": record.name,
                        "harness": "claude",
                        "registered_at": "2026-07-15T00:00:00Z",
                        "harness_session_id": "claude-id",
                        "transcript_path": "/tmp/claude.jsonl",
                    }
                },
            }) + "\n")

            with mock.patch.dict(os.environ, {"TAP_INDEX_HOME": str(root / "index")}):
                launcher.claim_pending_handle(record, allow_same_session=True)

            entry = json.loads(registry.read_text())["agents"]["sol"]
            self.assertEqual(entry["harness"], "codex")
            self.assertNotIn("harness_session_id", entry)
            self.assertNotIn("transcript_path", entry)

    def test_registry_row_adapter_maps_complete_session_state_and_ignores_derived_id(self):
        root = "/work/repo"
        row = {
            "session": "tap/sol",
            "harness": "codex",
            "registered_from_worktree": root,
            "base": "tap",
            "tag": "sol",
            "index": 2,
            "model": "gpt-5.6-sol",
            "teams": True,
            "passthrough": ["-c", "model_reasoning_effort=high", 9],
            "harness_session_id": "registry-id",
            "derived_harness_session_id": "must-not-win",
            "transcript_path": "/tmp/rollout.jsonl",
            "quarantined_harness_session_id": "suspect-id",
            "quarantined_transcript_path": "/tmp/suspect.jsonl",
            "identity_quarantine_reason": "capture mismatch",
            "adopted_from_manual": True,
            "history": ["prior-id", 9],
            "last_launched": "2026-08-02T01:00:00Z",
            "last_seen": "2026-08-02T02:00:00Z",
        }

        record = launcher.session_record_from_registry_row(
            "sol", row, {"name": "tap", "worktree_root": root}, root,
        )

        self.assertIsNotNone(record)
        self.assertEqual(record.harness_session_id, "registry-id")
        self.assertEqual(record.harness_passthrough, ["-c", "model_reasoning_effort=high"])
        self.assertEqual(record.history, ["prior-id"])
        self.assertEqual(record.quarantined_harness_session_id, "suspect-id")
        self.assertEqual(record.quarantined_transcript_path, "/tmp/suspect.jsonl")
        self.assertEqual(record.identity_quarantine_reason, "capture mismatch")
        self.assertTrue(record.adopted_from_manual)
        self.assertEqual(record.last_launched, "2026-08-02T01:00:00Z")
        self.assertEqual(record.last_seen, "2026-08-02T02:00:00Z")

    def test_claim_pending_handle_round_trips_complete_session_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            root_str = str(root.resolve())
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "tap", "worktree_root": root_str},
                "agents": {},
            }) + "\n")
            record = launcher.SessionRecord(
                name="tap/sol-2",
                harness="codex",
                cwd=root_str,
                base="tap",
                tag="sol",
                index=2,
                model="gpt-5.6-sol",
                # No `teams`: the field is deleted, and the row above still carries
                # `"teams": True`. That pairing IS the legacy-row contract — a persisted key
                # the reader no longer knows must load without error and without resurrecting
                # the field, so old rows and backups stay loadable. Leaving the key in the
                # fixture is deliberate; removing it would delete the only place that promise
                # is exercised.
                harness_session_id="registry-id",
                transcript_path="/tmp/rollout.jsonl",
                quarantined_harness_session_id="suspect-id",
                quarantined_transcript_path="/tmp/suspect.jsonl",
                identity_quarantine_reason="capture mismatch",
                adopted_from_manual=True,
                harness_passthrough=["-c", "model_reasoning_effort=high"],
                harness_env={"PONYTAIL_DEFAULT_MODE": "full"},
                preset={
                    "name": "sol-max",
                    "source_path": "/tmp/presets.toml",
                    "config_digest": "sha256:" + "a" * 64,
                },
                history=["prior-id"],
                last_launched="2026-08-02T01:00:00Z",
                last_seen="2026-08-02T02:00:00Z",
            )

            with mock.patch.dict(os.environ, {"TAP_INDEX_HOME": str(root / "index")}):
                launcher.claim_pending_handle(record)

            row = json.loads(registry.read_text())["agents"]["sol-2"]
            restored = launcher.session_record_from_registry_row(
                "sol-2", row, {"name": "tap", "worktree_root": root_str}, root_str,
            )
            self.assertEqual(restored, dataclasses.replace(record, launch_id=None))

    def test_claim_pending_handle_records_capture_provenance_for_new_exact_and_picker_launches(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({"team": {"name": root.name}, "agents": {}}) + "\n")
            cases = (
                ("fresh", "claude", "new", "fresh-id", "launcher_new", "fresh-id"),
                ("exact", "claude", "resume", "exact-id", "exact_resume", "exact-id"),
                ("picker", "claude", "resume", None, "untrusted_resume", None),
                ("oc-fresh", "opencode", "resume", None, "launcher_new", None),
                ("oc-exact", "opencode", "resume", "oc-id", "exact_resume", "oc-id"),
            )

            for tag, harness, action, native_id, expected_mode, expected_id in cases:
                record = launcher.SessionRecord(
                    name=f"{root.name}/{tag}", harness=harness, cwd=str(root),
                    base=root.name, tag=tag, index=1, harness_session_id=native_id,
                    identity_capture_action=action,
                )
                launcher.claim_pending_handle(record)

            agents = json.loads(registry.read_text())["agents"]
            for tag, _harness, _action, _native_id, expected_mode, expected_id in cases:
                capture = agents[tag]["identity_capture"]
                self.assertEqual(capture["mode"], expected_mode)
                self.assertEqual(capture.get("expected_harness_session_id"), expected_id)

    def test_claim_pending_handle_refuses_existing_pending_claim(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            first = launcher.SessionRecord(
                name="team/scout",
                harness="claude",
                cwd=str(root),
                base="team",
                tag="scout",
                index=1,
            )
            second = dataclasses.replace(first, harness="codex")

            launcher.claim_pending_handle(first)

            stderr = io.StringIO()
            with contextlib.redirect_stderr(stderr), self.assertRaises(SystemExit):
                launcher.claim_pending_handle(second)

            registry = root / ".tap" / "bus" / "registry.json"
            payload = json.loads(registry.read_text())
            self.assertEqual(payload["agents"]["scout"]["harness"], "claude")
            self.assertIn("tap session resume scout", stderr.getvalue())
            self.assertNotIn("action='tap session resume scout |", stderr.getvalue())
            self.assertIn("tap session launch codex scout-2", stderr.getvalue())

    def test_bare_launch_reuses_abandoned_pending_handle(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            resolved_root = str(root.resolve())
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": resolved_root},
                "agents": {
                    "codex": {
                        "status": "pending",
                        "session": "repo/codex",
                        "harness": "codex",
                        "registered_at": "2026-07-09T00:01:00Z",
                    },
                },
            }) + "\n")
            manifest = launcher.Manifest(sessions=[], dir_aliases={resolved_root: "repo"})
            args = types.SimpleNamespace(harness="codex", unique=None, tag=None, label=None, model=None, teams=False)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", lambda: set()), mock.patch.object(
                    launcher, "tmux_sessions_or_none", lambda: set()
                ), mock.patch.object(
                    launcher, "current_timestamp", lambda: "2026-07-09T00:02:00Z"
                ):
                    record = launcher.make_new_record(args, manifest)
                    launcher.claim_pending_handle(record)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(record.name, "repo/codex")
            payload = json.loads(registry.read_text())
            self.assertEqual(set(payload["agents"]), {"codex"})
            self.assertEqual(payload["agents"]["codex"]["session"], "repo/codex")

    def test_failed_new_launch_removes_pending_reservation_and_ignores_retired_journal(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            poison = b'{"sessions":[{"name":"repo/scout","harness_session_id":"stale-id"}]}\n'
            manifest.write_bytes(poison)
            args = types.SimpleNamespace(
                manifest=str(manifest),
                harness="claude",
                unique=None,
                tag=None,
                label="scout",
                model=None,
                teams=False,
                dry_run=False,
            )
            # Hermetic claude home: an EXISTING but empty projects dir makes the
            # fresh uuid genuinely artifact-missing (rollback fires), independent
            # of the ambient ~/.claude — and distinct from an ABSENT dir, which
            # now fails closed (F3).
            claude_home = root / "claude-home"
            (claude_home / "projects").mkdir(parents=True)
            old_cwd = pathlib.Path.cwd()
            original_run_record = launcher.run_record
            original_tmux_sessions = launcher.tmux_sessions
            original_tap_handles = launcher.tap_handles
            try:
                os.chdir(root)
                launcher.tmux_sessions = lambda: set()
                launcher.tap_handles = lambda _root: set()
                launcher.run_record = lambda *_args, **_kwargs: 7

                with mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(claude_home)}):
                    self.assertEqual(launcher.cmd_new(args), 7)
            finally:
                launcher.run_record = original_run_record
                launcher.tmux_sessions = original_tmux_sessions
                launcher.tap_handles = original_tap_handles
                os.chdir(old_cwd)

            registry = root / ".tap" / "bus" / "registry.json"
            payload = json.loads(registry.read_text())
            self.assertNotIn("scout", payload.get("agents", {}))
            self.assertEqual(manifest.read_bytes(), poison)

    def test_attached_launch_arms_failure_hook_before_respawn(self):
        record = launcher.SessionRecord(
            name="repo/scout",
            harness="claude",
            cwd="/repo",
            base="repo",
            tag="scout",
            index=1,
        )
        invocation = launcher.Invocation(["claude"], {})
        commands = []

        def fake_run(command, **_kwargs):
            commands.append(command)
            if "has-session" in command:
                return types.SimpleNamespace(returncode=1, stdout="")
            return types.SimpleNamespace(returncode=0, stdout="")

        with isolated_login_shell("zsh") as shell, mock.patch.object(
            launcher.subprocess, "run", side_effect=fake_run
        ), mock.patch.object(launcher, "tmux_attach", return_value=0), mock.patch.dict(
            os.environ, {"TMUX": "/tmp/tmux,1,0"}
        ):
            rc = launcher.run_invocation(
                record,
                invocation,
                dry_run=False,
                launch_failure_argv=["python3", "handler.py"],
            )

        self.assertEqual(rc, 0)
        self.assertTrue(any("remain-on-exit" in command for command in commands))
        self.assertTrue(any("pane-died" in command for command in commands))
        remain_on = next(i for i, command in enumerate(commands) if "remain-on-exit" in command and command[-1] == "on")
        pane_hook = next(i for i, command in enumerate(commands) if "pane-died" in command)
        cleanup = next(command[-1] for command in commands if command[:2] == ["tmux", "run-shell"])
        respawn = next(i for i, command in enumerate(commands) if "respawn-pane" in command)
        self.assertLess(remain_on, pane_hook)
        self.assertLess(pane_hook, respawn)
        created = next(command for command in commands if command[:2] == ["tmux", "new-session"])
        self.assertEqual(created[3:7], ["-x", "200", "-y", "60"])
        self.assertTrue(cleanup.endswith(" >/dev/null 2>&1 || true"))
        self.assertEqual(
            commands[respawn][-1],
            f"{shell} -lic 'exec \"$0\" \"$@\"' /usr/bin/env TAP_INDEX_HOME={os.environ['TAP_INDEX_HOME']} claude",
        )

        # The delayed grace-boundary cleanup must tolerate a gone target: the pane is
        # routinely absent when it fires (session died inside the window, or the
        # operator relaunched), and an unguarded compound returns 1 — tmux then reports
        # that failure into whichever client is attached, which reads as a phantom
        # session death in an unrelated pane.
        cleanup = next(
            command
            for command in commands
            if any("run-shell" == part for part in command)
            and any("remain-on-exit off" in str(part) for part in command)
        )
        cleanup_script = cleanup[-1]
        self.assertTrue(cleanup_script.endswith(" >/dev/null 2>&1 || true"))
        self.assertIn("run-shell-logged.sh", cleanup_script)
        self.assertEqual(cleanup_script.count("|| rc=$?"), 2)
        self.assertEqual(cleanup[2:5], ["-b", "-t", f"={record.name}:0.0"])
        hook = commands[pane_hook][-1]
        self.assertIn(f"run-shell -b -t ={record.name}:0.0 ", hook)
        self.assertIn("run-shell-logged.sh", hook)
        self.assertIn("set-hook -p -u", cleanup_script)
        self.assertIn("remain-on-exit off", cleanup_script)

    @mock.patch("tmux_bootstrap.ensure_server", return_value=False)
    def test_resume_launch_rebinds_before_harness_start_and_marks_ready_after_verification(self, _bootstrap):
        record = launcher.SessionRecord(
            name="repo/scout",
            harness="claude",
            cwd="/repo",
            base="repo",
            tag="scout",
            index=1,
            launch_id="launch-token",
        )
        invocation = launcher.Invocation(["claude"], {})
        events = []
        placeholder_facts = launcher.PaneFacts("repo/scout:0.0", "%7", "wait-for", "/repo")
        harness_facts = launcher.PaneFacts(
            "repo/scout:0.0", "%7", "claude", "/repo", dead=False, pane_pid=2001,
        )

        def fake_run(command, **_kwargs):
            if command[:2] == ["tmux", "respawn-pane"]:
                events.append("start")
            return types.SimpleNamespace(returncode=0, stdout="")

        with mock.patch.object(launcher, "tmux_has", return_value=False), mock.patch.object(
            launcher.subprocess, "run", side_effect=fake_run
        ), mock.patch.object(
            launcher, "tmux_pane_facts", return_value=placeholder_facts
        ), mock.patch.object(
            launcher, "bind_reserved_handle", side_effect=lambda *_args: events.append("bind")
        ), mock.patch.object(
            launcher, "matching_session_pane", return_value=(harness_facts, "claude")
        ) as observed, mock.patch.object(
            launcher, "mark_launch_ready", side_effect=lambda *_args: events.append("ready")
        ), mock.patch.object(launcher, "tmux_attach", return_value=0):
            rc = launcher.run_invocation(
                record,
                invocation,
                dry_run=False,
                attach=False,
                launch_failure_argv=["python3", "handler.py"],
            )

        self.assertEqual(rc, 0)
        self.assertEqual(events, ["bind", "start", "ready"])
        self.assertGreaterEqual(observed.call_count, 2)

    def test_stable_harness_requires_two_observations_of_one_process(self):
        first = launcher.PaneFacts(
            "repo/scout:0.0", "%7", "claude", "/repo",
            server_epoch="srv:1:1", dead=False, pane_pid=2001,
        )
        replacement = dataclasses.replace(first, pane_pid=2002)
        samples = iter([first, replacement])
        ticks = iter([0.0, 0.0, 1.0])
        facts, reason = launcher.await_stable_harness(
            lambda: next(samples, None),
            lambda observed: observed.dead is False,
            0.5,
            monotonic=lambda: next(ticks),
            sleeper=lambda _seconds: None,
        )
        self.assertIsNone(facts)
        self.assertIsNone(reason)

        samples = iter([first, first])
        ticks = iter([0.0, 0.0, 0.0])
        facts, reason = launcher.await_stable_harness(
            lambda: next(samples, None),
            lambda observed: observed.dead is False,
            0.5,
            monotonic=lambda: next(ticks),
            sleeper=lambda _seconds: None,
        )
        self.assertEqual(facts, first)
        self.assertIsNone(reason)

    def test_stable_harness_checks_async_blocker_through_deadline(self):
        facts = launcher.PaneFacts(
            "repo/scout:0.0", "%7", "codex", "/repo",
            server_epoch="srv:1:1", dead=False, pane_pid=2001,
        )
        samples = iter([facts, facts, facts])
        blockers = iter([None, None, "zero-result picker"])
        ticks = iter([0.0, 0.0, 0.25])
        observed, reason = launcher.await_stable_harness(
            lambda: next(samples),
            lambda _observed: True,
            0.5,
            blocker=lambda _observed: next(blockers),
            monotonic=lambda: next(ticks),
            sleeper=lambda _seconds: None,
        )
        self.assertIsNone(observed)
        self.assertEqual(reason, "zero-result picker")

        samples = iter([facts, facts, facts])
        ticks = iter([0.0, 0.0, 0.25, 0.5])
        observed, reason = launcher.await_stable_harness(
            lambda: next(samples),
            lambda _observed: True,
            0.5,
            blocker=lambda _observed: None,
            monotonic=lambda: next(ticks),
            sleeper=lambda _seconds: None,
        )
        self.assertEqual(observed, facts)
        self.assertIsNone(reason)

    def test_interrupt_after_bind_kills_placeholder_session(self):
        record = launcher.SessionRecord(
            name="repo/scout", harness="claude", cwd="/repo", base="repo",
            tag="scout", index=1, launch_id="launch-token",
        )
        facts = launcher.PaneFacts("repo/scout:0.0", "%7", "wait-for", "/repo")
        commands = []

        def fake_run(command, **_kwargs):
            commands.append(command)
            if command[:2] == ["tmux", "respawn-pane"]:
                raise KeyboardInterrupt
            return types.SimpleNamespace(returncode=0, stdout="")

        with mock.patch.object(launcher, "tmux_has", return_value=False), mock.patch.object(
            launcher.subprocess, "run", side_effect=fake_run
        ), mock.patch.object(launcher, "tmux_pane_facts", return_value=facts), mock.patch.object(
            launcher, "bind_reserved_handle"
        ), self.assertRaises(KeyboardInterrupt):
            launcher.run_invocation(
                record,
                launcher.Invocation(["claude"], {}),
                dry_run=False,
                attach=False,
                launch_failure_argv=["python3", "handler.py"],
            )

        self.assertIn(["tmux", "kill-session", "-t", "=repo/scout"], commands)

    def test_stillborn_bound_launch_rolls_back_by_token(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            record = launcher.SessionRecord(
                name=f"{root.name}/scout", harness="claude", cwd=str(root),
                base=root.name, tag="scout", index=1, launch_id="launch-token",
            )
            registry.write_text(json.dumps({
                "team": {"name": root.name, "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "status_reason": "launching",
                    "session": record.name, "harness": "claude",
                    "pane": f"{record.name}:0.0", "pane_id": "%7",
                    "launch_id": "launch-token",
                }},
            }) + "\n")

            self.assertTrue(launcher.rollback_pending_handle(record))
            self.assertNotIn("scout", json.loads(registry.read_text())["agents"])

    def test_cmd_resume_adoption_claims_before_kill_and_refusal_rolls_back(self):
        """opus gate residual (grok B): the reservation must PRECEDE the
        shell-session kill, and a boundary refusal must roll the claim back
        rather than leak it — destruction is always claim-bounded."""
        for boundary_state, expect_kill in (("shell", True), ("busy", False)):
            with self.subTest(boundary_state), tempfile.TemporaryDirectory() as tmp:
                root = pathlib.Path(tmp).resolve()
                manifest_path = root / "sessions.json"
                record = launcher.SessionRecord(
                    name="repo/x", harness="claude", cwd=str(root), base="repo",
                    tag="x", index=1, harness_session_id="11111111-1111-4111-8111-111111111111",
                )
                save_registry_state(manifest_path, launcher.Manifest(
                    dir_aliases={str(root): "repo"}, sessions=[record]))
                args = types.SimpleNamespace(
                    manifest=str(manifest_path), key="x", legacy_name=None, all=False,
                    model=None, teams=False, dry_run=False, json=False,
                )
                events = []

                def claim(rec, *a, **kw):
                    rec.launch_id = "tok"
                    events.append("claim")

                def fake_run(cmd, **kw):
                    if cmd[:2] == ["tmux", "kill-session"]:
                        events.append("kill")
                    return mock.Mock(returncode=0, stdout="")

                old_cwd = pathlib.Path.cwd()
                try:
                    os.chdir(root)
                    with mock.patch.object(launcher, "session_attachable", return_value=False), \
                         mock.patch.object(launcher, "tmux_has", return_value=True), \
                         mock.patch.object(launcher, "classify_session", return_value=boundary_state), \
                         mock.patch.object(launcher, "prepare_launch_transaction", side_effect=claim), \
                         mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                         mock.patch.object(launcher, "run_record_detached", return_value=0), \
                         mock.patch.object(launcher, "tmux_attach", return_value=0), \
                         mock.patch.object(
                             launcher, "rollback_launch_transaction",
                             side_effect=lambda *a, **kw: events.append("rollback"),
                         ):
                        if expect_kill:
                            rc = launcher.cmd_resume(args)
                            self.assertEqual(rc, 0)
                            self.assertEqual(events, ["claim", "kill"],
                                             "claim must precede the kill")
                        else:
                            with self.assertRaises(launcher.LauncherError):
                                launcher.cmd_resume(args)
                            self.assertEqual(events, ["claim", "rollback"],
                                             "refusal must roll the claim back, never kill")
                finally:
                    os.chdir(old_cwd)

    def _classify_with(self, stdout, rc=0, pane_harness="zsh", children=False):
        result = mock.Mock(returncode=rc, stdout=stdout)
        with mock.patch.object(launcher.subprocess, "run", return_value=result), \
             mock.patch.object(launcher, "pane_harness", return_value=pane_harness), \
             mock.patch.object(launcher, "shell_has_children", return_value=children):
            return launcher.classify_session("x")

    def test_classifier_invariants(self):
        """opus gate #xxx: the four functions that gate tmux kill-session get
        their states pinned directly. Load-bearing invariant (sol): a failed
        or unparseable observation is 'unknown' and NEVER absorbs."""
        pane = "x:0.0\t%1\t{cmd}\t123\t{attached}\n"
        cases = [
            ("probe rc!=0", dict(stdout="", rc=1), "unknown"),
            ("malformed output", dict(stdout="garbage-no-tabs\n"), "unknown"),
            ("bare shell unattached", dict(stdout=pane.format(cmd="zsh", attached="0")), "shell"),
            ("bare shell attached", dict(stdout=pane.format(cmd="zsh", attached="1")), "attached-shell"),
            ("editor pane", dict(stdout=pane.format(cmd="vim", attached="0"), pane_harness="vim"), "busy"),
            ("live harness", dict(stdout=pane.format(cmd="zsh", attached="0"), pane_harness="claude"), "live"),
            ("shell with children", dict(stdout=pane.format(cmd="zsh", attached="0"), children=True), "busy"),
            ("unreadable shell pid", dict(stdout="x:0.0\t%1\tzsh\tnotapid\t0\n"), "busy"),
        ]
        for label, kwargs, expected in cases:
            with self.subTest(label):
                self.assertEqual(self._classify_with(**kwargs), expected)
        # session_attachable: attach only diverts for shell (revive) and
        # attached-shell (a human's shell); busy/unknown keep legacy attach.
        for state, expected in [("live", True), ("busy", True), ("unknown", True),
                                ("shell", False), ("attached-shell", False)]:
            with self.subTest(f"attachable:{state}"):
                with mock.patch.object(launcher, "tmux_has", return_value=True), \
                     mock.patch.object(launcher, "classify_session", return_value=state):
                    self.assertEqual(launcher.session_attachable("x"), expected)
        with mock.patch.object(launcher, "tmux_has", return_value=False):
            self.assertFalse(launcher.session_attachable("x"))
        # shell_has_children: pgrep rc 1 is the ONLY positive no-children
        # answer; any other failure reads busy (never absorb on failed probe).
        for rc, out, expected in [(0, "999\n", True), (1, "", False), (2, "", True)]:
            with self.subTest(f"pgrep rc={rc}"):
                with mock.patch.object(launcher.subprocess, "run",
                                       return_value=mock.Mock(returncode=rc, stdout=out)):
                    self.assertEqual(launcher.shell_has_children("123"), expected)
        # is_login_shell normalization (crew-wolf F).
        for cmd, expected in [("zsh", True), ("-zsh", True), ("/bin/zsh", True),
                              ("fish", True), ("vim", False), ("claude", False)]:
            with self.subTest(f"is_login_shell:{cmd}"):
                self.assertEqual(launcher.is_login_shell(cmd), expected)
        # entry_observed_dead: poll rows are never judged by pane content.
        self.assertFalse(launcher.entry_observed_dead({"delivery": "poll", "status": "active"}))

    def test_resolve_login_shell_falls_back_when_zsh_is_absent(self):
        # tap-2elw. The bead's original fixture (smoke/session-login-env.test.sh)
        # launched its probes through a hard-coded `/bin/zsh -c` — on zsh-less
        # hosts the `|| true` swallowed the miss and a later FileNotFoundError
        # failed the smoke. That fixture was deleted in the tap-52ys suite split
        # (2af1d7ab), taking the fallback chain's only dedicated coverage with
        # it; production resolve_login_shell was already correct. This pins the
        # acceptance in the living suite: with TAP_LAUNCH_SHELL and SHELL unset,
        # resolution walks zsh -> bash -> sh -> /bin/sh over what PATH actually
        # offers, never returns a non-POSIX shell, and with PATH offering
        # nothing still resolves /bin/sh — via the absolute-candidate branch
        # (/bin/sh is the last tuple entry), which is the realistic path on a
        # real POSIX host; the literal `return "/bin/sh"` floor beneath it is
        # armor for a state no current host presents (kimi's review note,
        # verified by corrupting the floor line).
        cases = [
            ({"zsh": "/bin/zsh", "bash": "/bin/bash", "sh": "/bin/sh"}, "/bin/zsh"),
            ({"bash": "/bin/bash", "sh": "/bin/sh"}, "/bin/bash"),
            ({"sh": "/bin/sh"}, "/bin/sh"),
            ({}, "/bin/sh"),
        ]
        for found, expected in cases:
            with self.subTest(found=sorted(found)):
                with mock.patch.dict(os.environ, {}, clear=False):
                    os.environ.pop("TAP_LAUNCH_SHELL", None)
                    os.environ.pop("SHELL", None)
                    with mock.patch.object(
                        launcher.shutil, "which", side_effect=lambda name: found.get(name)
                    ), mock.patch.object(
                        launcher.os, "access", return_value=True
                    ), mock.patch.object(
                        launcher, "_is_posix_login_shell", return_value=True
                    ):
                        got = launcher.resolve_login_shell()
                self.assertEqual(got, expected)
        # A non-POSIX SHELL (fish) is skipped, not honored: shell_command always
        # emits a POSIX `exec "$0" "$@"` wrapper that fish cannot run.
        with mock.patch.dict(
            os.environ, {"TAP_LAUNCH_SHELL": "", "SHELL": "/usr/local/bin/fish"}
        ), mock.patch.object(
            launcher.shutil, "which", side_effect=lambda name: {"bash": "/bin/bash"}.get(name)
        ), mock.patch.object(
            launcher.os, "access", return_value=True
        ), mock.patch.object(
            launcher, "_is_posix_login_shell", side_effect=lambda p: "fish" not in p
        ):
            self.assertEqual(launcher.resolve_login_shell(), "/bin/bash")

    def test_bound_replacement_rollback_restores_incumbent_by_token(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            incumbent = {
                "status": "active", "session": f"{root.name}/scout",
                "harness": "cursor", "pane": f"{root.name}/scout:0.0", "pane_id": "%201",
            }
            record = launcher.SessionRecord(
                name=f"{root.name}/scout", harness="claude", cwd=str(root),
                base=root.name, tag="scout", index=1, launch_id="launch-token",
                replacement_registry_entry=incumbent,
            )
            registry.write_text(json.dumps({
                "team": {"name": root.name, "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "status_reason": "launching",
                    "session": record.name, "harness": "claude",
                    "pane": f"{record.name}:0.0", "pane_id": "%7",
                    "launch_id": "launch-token",
                }},
            }) + "\n")

            self.assertTrue(launcher.rollback_pending_handle(record, "session_replaced"))
            self.assertEqual(json.loads(registry.read_text())["agents"]["scout"], {
                **incumbent,
                "status": "suspended",
                "status_reason": "session_replaced",
            })

    def test_late_launch_rollback_cannot_overwrite_new_owner_without_token(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            record = launcher.SessionRecord(
                name=f"{root.name}/scout", harness="claude", cwd=str(root),
                base=root.name, tag="scout", index=1, launch_id="old-token",
            )
            new_owner = {
                "status": "active", "status_reason": "", "session": record.name,
                "harness": "claude", "pane": f"{record.name}:0.1", "pane_id": "%205",
            }
            registry.write_text(json.dumps({
                "team": {"name": root.name, "worktree_root": str(root)},
                "agents": {"scout": new_owner},
            }) + "\n")

            self.assertFalse(launcher.rollback_pending_handle(record))
            self.assertEqual(json.loads(registry.read_text())["agents"]["scout"], new_owner)


    def test_resume_claim_preserves_seat_policy_through_ready(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            record = launcher.SessionRecord(
                name=f"{root.name}/scout", harness="claude", cwd=str(root),
                base=root.name, tag="scout", index=1,
            )
            registry.write_text(json.dumps({
                "team": {"name": root.name, "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "session": record.name, "harness": "claude",
                    "cost_mode": "api", "include_policy": "on_request",
                    "unattended": True, "reply_to": "lead", "custom_policy": "keep",
                }},
            }) + "\n")
            facts = launcher.PaneFacts(f"{record.name}:0.0", "%7", "claude", str(root))

            displaced = launcher.claim_pending_handle(record, allow_same_session=True)
            record.replacement_registry_entry = displaced
            launcher.bind_reserved_handle(record, facts)
            launcher.mark_launch_ready(record, facts)

            entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(entry["cost_mode"], "api")
            self.assertEqual(entry["include_policy"], "on_request")
            self.assertTrue(entry["unattended"])
            self.assertEqual(entry["reply_to"], "lead")
            self.assertEqual(entry["custom_policy"], "keep")

    def test_launch_failure_handler_surfaces_tail_and_rolls_back_stillborn_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest_path = root / "sessions.json"
            output_path = root / "caller.log"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            record = launcher.SessionRecord(
                name=f"{root.name}/scout",
                harness="claude",
                cwd=str(root),
                base=root.name,
                tag="scout",
                index=1,
                harness_session_id="11111111-1111-4111-8111-111111111111",
                launch_id="launch-token",
            )
            save_registry_state(manifest_path, launcher.Manifest(sessions=[record]))
            registry.write_text(json.dumps({
                "team": {"name": root.name, "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "active",
                        "status_reason": "launching",
                        "session": record.name,
                        "harness": "claude",
                        "pane": f"{record.name}:0.0",
                        "pane_id": "%208",
                        "launch_id": "launch-token",
                    },
                },
            }) + "\n")
            commands = []

            def fake_run(command, **_kwargs):
                commands.append(command)
                if "display-message" in command:
                    return types.SimpleNamespace(returncode=0, stdout="7\n")
                if "capture-pane" in command:
                    return types.SimpleNamespace(
                        returncode=0,
                        stdout="fatal launch detail\n\nPane is dead (status 7)\n",
                    )
                return types.SimpleNamespace(returncode=0, stdout="")

            # A true stillbirth: the claude home EXISTS but the dead session never
            # wrote a transcript, so the probe runs and reports missing -> rollback.
            # (An ABSENT home is cannot-verify and fails closed post-F3; that edge is
            # covered by test_record_has_resume_artifact_fails_closed_when_projects_dir_absent.)
            (root / "claude-home" / "projects").mkdir(parents=True)
            with mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), mock.patch.dict(
                os.environ, {"TAP_CLAUDE_HOME": str(root / "claude-home")}
            ):
                launcher.report_launch_failure(
                    record,
                    "2026-07-12T04:00:00Z",
                    str(output_path),
                )

            output = output_path.read_text()
            self.assertIn("launch failed: exit 7", output)
            self.assertIn("fatal launch detail", output)
            self.assertNotIn("scout", json.loads(registry.read_text()).get("agents", {}))
            self.assertFalse(manifest_path.exists())
            capture = next(i for i, command in enumerate(commands) if "capture-pane" in command)
            kill = next(i for i, command in enumerate(commands) if "kill-session" in command)
            self.assertLess(capture, kill)

    def test_successful_in_tmux_launch_does_not_wait_for_grace(self):
        record = launcher.SessionRecord(
            name="repo/scout",
            harness="claude",
            cwd="/repo",
            base="repo",
            tag="scout",
            index=1,
        )
        invocation = launcher.Invocation(["claude"], {})

        commands = []

        def fake_run(command, **_kwargs):
            commands.append(command)
            return types.SimpleNamespace(
                returncode=1 if "has-session" in command else 0,
                stdout="",
            )

        with mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), mock.patch.object(
            launcher, "tmux_attach", return_value=0
        ), mock.patch.object(
            launcher, "PENDING_RESERVATION_GRACE_SECONDS", 0.2
        ), mock.patch.object(
            launcher.time, "sleep", side_effect=AssertionError("launch waited for its cleanup grace")
        ), mock.patch.dict(os.environ, {"TMUX": "/tmp/tmux,1,0"}):
            self.assertEqual(launcher.run_invocation(
                record,
                invocation,
                dry_run=False,
                launch_failure_argv=["python3", "handler.py"],
            ), 0)

        cleanup = next(command for command in commands if "run-shell" in command)
        self.assertEqual(cleanup[1:7], ["run-shell", "-b", "-t", f"={record.name}:0.0", "-d", "0.2"])

    def test_upsert_record_replaces_stale_record_with_same_name(self):
        old = launcher.SessionRecord(
            name="xx-claude",
            harness="claude",
            cwd="/old",
            base="xx",
            index=1,
            harness_session_id="old-session",
        )
        new = dataclasses.replace(old, cwd="/new", harness_session_id="new-session")

        records = launcher.upsert_record([old], new)

        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].cwd, "/new")
        self.assertEqual(records[0].harness_session_id, "new-session")

    def test_default_dir_alias_uses_first_letters_of_words(self):
        self.assertEqual(launcher.default_dir_alias("CheckInQuestions-API-Design"), "ciqad")
        self.assertEqual(launcher.default_dir_alias("CommentCraftsmanReviewer"), "ccr")
        self.assertEqual(launcher.default_dir_alias("sample-app-config"), "sac")

    def test_derives_base_from_linked_worktree_before_repo_name(self):
        probe = launcher.GitProbe(
            inside=True,
            root="/Users/runner/wrk/Example-Org/trees/AESOP-Improvements",
            git_dir="/Users/runner/wrk/Example-Org/.git/worktrees/AESOP-Improvements",
            common_dir="/Users/runner/wrk/Example-Org/.git",
        )

        self.assertEqual(
            launcher.derive_base("/Users/runner/wrk/Example-Org/trees/AESOP-Improvements", probe),
            "AESOP-Improvements",
        )

    def test_builds_claude_new_with_model_session_id_and_name(self):
        # Renamed: it promised "and_teams_env" back when the builder emitted that key. It has
        # asserted env == {} since the builders stopped originating environment, and the record
        # field it set is now deleted, so the old name described neither the input nor the
        # assertion.
        record = launcher.SessionRecord(
            name="demo-app/planner",
            harness="claude",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="planner",
            index=0,
            model="opus[1m]",
            harness_session_id="11111111-1111-4111-8111-111111111111",
        )

        invocation = launcher.build_harness_invocation("new", record)

        # The builder originates NO environment now. Agent-teams is spelled as env — from a
        # preset, `--env`, or `[harness.claude.env]` — and composed in apply_launch_env.
        self.assertEqual(invocation.env, {})
        self.assertEqual(
            invocation.argv,
            [
                "claude",
                "--dangerously-skip-permissions",
                "--model",
                "opus[1m]",
                "--name",
                "demo-app/planner",
                "--session-id",
                "11111111-1111-4111-8111-111111111111",
            ],
        )

    def test_claude_launch_gets_tmux_specific_env(self):
        record = launcher.SessionRecord(
            name="demo-app-claude-color-0",
            harness="claude",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            index=0,
        )

        # Host may export CLAUDE_CODE_SCROLL_SPEED; assert the unset default.
        scrubbed = {k: v for k, v in os.environ.items() if k != "CLAUDE_CODE_SCROLL_SPEED"}
        with mock.patch.dict(os.environ, scrubbed, clear=True):
            invocation = launcher.launch_invocation("new", record)

        self.assertEqual(invocation.env["CLAUDE_CODE_TMUX_TRUECOLOR"], "1")
        self.assertEqual(invocation.env["CLAUDE_CODE_SCROLL_SPEED"], "6")

    def test_claude_resume_without_native_id_never_uses_tap_name(self):
        record = launcher.SessionRecord(
            name="tap/claude",
            harness="claude",
            cwd="/Users/runner/wrk/Example-Org/tap",
            base="tap",
            index=1,
            model="fable",
        )

        invocation = launcher.build_harness_invocation("resume", record)

        self.assertEqual(
            invocation.argv,
            [
                "claude",
                "--dangerously-skip-permissions",
                "--model",
                "fable",
                "--name",
                "tap/claude",
                "--resume",
            ],
        )

    def test_teams_on_a_non_claude_seat_is_inert_rather_than_refused(self):
        # KTD9, disclosed and accepted: with `--teams` gone, the launcher no longer polices
        # which harness may carry which env key. A TEAMS value on a codex seat is now inert
        # passthrough — the launcher passes configuration through, it does not adjudicate it.
        record = launcher.SessionRecord(
            name="demo-app-codex-0",
            harness="codex",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag=None,
            index=0,
            harness_env={"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "true"},
        )

        invocation = launcher.build_harness_invocation("new", record)
        self.assertEqual(invocation.env, {})
        self.assertEqual(
            invocation.argv, ["codex", "--dangerously-bypass-approvals-and-sandbox"]
        )
        # Follow the key all the way to the composed environment, not just to the builder:
        # "the builder does not adjudicate it" and "it reaches the child" are different
        # claims, and the second is the one the disclosure actually makes (sol P3).
        self.assertEqual(
            launcher.launch_invocation("new", record).env[
                "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS"
            ],
            "true",
        )

    def test_codex_builder_originates_no_ponytail_env(self):
        # Supersedes test_builds_codex_with_ponytail_lite_env and
        # test_builds_codex_non_ponytail_with_off_env (tap-ey7n's fix, replaced by the tier
        # model). The tag no longer decides an env value; `[harness.codex.env]` does, and a
        # preset overrides it. Both former tags are asserted here so neither can quietly
        # regrow a special case.
        for tag in ("ponytail", "sol"):
            with self.subTest(tag=tag):
                record = launcher.SessionRecord(
                    name=f"sandbox-codex-{tag}-0",
                    harness="codex",
                    cwd="/Users/runner/wrk/sandbox",
                    base="sandbox",
                    tag=tag,
                    index=0,
                    model="gpt-5.6-sol",
                )

                with isolated_login_shell("zsh") as shell:
                    invocation = launcher.build_harness_invocation("new", record)

                    self.assertEqual(invocation.env, {})
                    self.assertEqual(
                        invocation.argv,
                        [
                            "codex",
                            "--dangerously-bypass-approvals-and-sandbox",
                            "--model",
                            "gpt-5.6-sol",
                        ],
                    )
                    self.assertEqual(
                        invocation.shell_command(),
                        f"{shell} -lic 'exec \"$0\" \"$@\"' /usr/bin/env TAP_INDEX_HOME={os.environ['TAP_INDEX_HOME']} codex "
                        "--dangerously-bypass-approvals-and-sandbox --model gpt-5.6-sol",
                    )

    def test_builds_opencode_with_model(self):
        record = launcher.SessionRecord(
            name="demo-app/glm",
            harness="opencode",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="glm",
            index=1,
            model="openrouter/z-ai/glm-5.2",
        )

        invocation = launcher.build_harness_invocation("new", record)

        self.assertEqual(
            invocation.argv,
            ["opencode", "--model", "openrouter/z-ai/glm-5.2"],
        )

    def test_opencode_resume_with_model_without_native_id_starts_fresh(self):
        record = launcher.SessionRecord(
            name="demo-app/glm",
            harness="opencode",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="glm",
            index=1,
            model="openrouter/z-ai/glm-5.2",
        )

        invocation = launcher.build_harness_invocation("resume", record)

        self.assertEqual(
            invocation.argv,
            ["opencode", "--model", "openrouter/z-ai/glm-5.2"],
        )
        self.assertNotIn("--session", invocation.argv)
        self.assertNotIn("--continue", invocation.argv)

    # --- agy / Antigravity (tap-8qj7) -----------------------------------------
    def _agy_record(self, **kw):
        base = dict(name="Dev/gemini", harness="agy", cwd="/Dev", base="Dev",
                    tag="gemini", index=1)
        base.update(kw)
        return launcher.SessionRecord(**base)

    def test_agy_is_a_known_harness(self):
        self.assertIn("agy", launcher.HARNESSES)
        self.assertEqual(launcher.HARNESS_BY_CODE["ag"], "agy")

    def test_builds_agy_new_launch_with_yolo_flag(self):
        # --dangerously-skip-permissions is load-bearing (permission-prompt wedge).
        # Model comes from TUNING_CAPABILITIES (tap-ppo7); the builder used to drop it.
        invocation = launcher.build_harness_invocation("new", self._agy_record(model="gemini-3.6-flash"))
        self.assertEqual(
            invocation.argv,
            ["agy", "--dangerously-skip-permissions", "--model", "gemini-3.6-flash"],
        )

    def test_agy_effort_passthrough_splices_before_generated_flags(self):
        # resolve_tuning translates agy effort to ("--effort", "high"); inject_passthrough
        # splices it after the binary. A builder that emitted --effort itself would
        # duplicate; a builder that still dropped model would hide the table.
        record = self._agy_record(
            model="gemini-3.6-flash-high",
            harness_passthrough=["--effort", "high"],
        )
        invocation = launcher.inject_passthrough(
            launcher.build_harness_invocation("new", record), record
        )
        self.assertEqual(
            invocation.argv,
            [
                "agy",
                "--effort",
                "high",
                "--dangerously-skip-permissions",
                "--model",
                "gemini-3.6-flash-high",
            ],
        )

    def test_builds_agy_resume_with_conversation_id(self):
        invocation = launcher.build_harness_invocation(
            "resume", self._agy_record(harness_session_id="7fe99dee-01b7-4e1c-b5a3-816bd12511c3"))
        self.assertEqual(
            invocation.argv,
            ["agy", "--dangerously-skip-permissions", "--conversation", "7fe99dee-01b7-4e1c-b5a3-816bd12511c3"],
        )

    def test_builds_agy_resume_continue_when_no_id(self):
        invocation = launcher.build_harness_invocation("resume", self._agy_record())
        self.assertEqual(invocation.argv, ["agy", "--dangerously-skip-permissions", "--continue"])

    def test_agy_native_resume_prefers_query_then_id_then_continue(self):
        # native_query (tap session resume agy <uuid>) wins.
        inv = launcher.build_native_resume_invocation(self._agy_record(), "abc-uuid")
        self.assertEqual(inv.argv, ["agy", "--dangerously-skip-permissions", "--conversation", "abc-uuid"])
        # else the stored id.
        inv = launcher.build_native_resume_invocation(self._agy_record(harness_session_id="stored-id"), None)
        self.assertEqual(inv.argv, ["agy", "--dangerously-skip-permissions", "--conversation", "stored-id"])
        # else --continue.
        inv = launcher.build_native_resume_invocation(self._agy_record(), None)
        self.assertEqual(inv.argv, ["agy", "--dangerously-skip-permissions", "--continue"])

    def test_agy_revive_tier_and_mode(self):
        self.assertEqual(launcher.revive_tier("agy", "some-id"), "exact")
        self.assertEqual(launcher.revive_tier("agy", None), "latest")
        self.assertEqual(launcher.native_revive_mode("agy", None), ("resume", "agy native latest (--continue)"))

    def test_agy_resume_artifact_probes_conversation_db(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp) / "gemini"
            convos = home / "antigravity-cli" / "conversations"
            convos.mkdir(parents=True)
            uuid_present = "7fe99dee-01b7-4e1c-b5a3-816bd12511c3"
            (convos / f"{uuid_present}.db").write_bytes(b"\x00")
            with mock.patch.dict(os.environ, {"TAP_GEMINI_HOME": str(home)}):
                # id + .db on disk -> resumable.
                self.assertTrue(launcher.record_has_resume_artifact(self._agy_record(harness_session_id=uuid_present)))
                # id but no matching .db -> not resumable (a corpse, not a false-exact).
                self.assertFalse(launcher.record_has_resume_artifact(self._agy_record(harness_session_id="00000000-dead")))
            # no id at all -> no artifact.
            with mock.patch.dict(os.environ, {"TAP_GEMINI_HOME": str(home)}):
                self.assertFalse(launcher.record_has_resume_artifact(self._agy_record()))

    def test_agy_resume_artifact_fails_closed_when_store_unreadable(self):
        # An unreadable/absent store is cannot-verify -> report present (never
        # condemn a live conversation on a transient miss), same rule as claude.
        with mock.patch.dict(os.environ, {"TAP_GEMINI_HOME": "/nonexistent-gemini-home"}):
            # is_file() on a path under a missing dir returns False, so this asserts
            # the id-with-missing-db path; the OSError branch is the belt-and-braces.
            rec = self._agy_record(harness_session_id="any-id")
            # Missing dir -> is_file False -> reported missing; this is acceptable
            # (no real store to protect). The OSError fail-closed guards live stores.
            self.assertFalse(launcher.record_has_resume_artifact(rec))

    def test_adopted_registry_identity_requires_env_trust(self):
        # Only a tier-1 env-verified capture is identity (rider r1).
        self.assertEqual(
            launcher.adopted_registry_identity(
                {"session_attribution_trust": "env", "harness_session_id": "conv-uuid"}),
            "conv-uuid",
        )
        # Non-env trust -> never identity (an inferred id can't cross here anyway).
        self.assertIsNone(launcher.adopted_registry_identity(
            {"session_attribution_trust": "inferred", "harness_session_id": "conv-uuid"}))
        # No trust field -> refuse.
        self.assertIsNone(launcher.adopted_registry_identity({"harness_session_id": "conv-uuid"}))
        # Verified but empty id -> None (revive falls to --continue).
        self.assertIsNone(launcher.adopted_registry_identity(
            {"session_attribution_trust": "env", "harness_session_id": ""}))
        self.assertIsNone(launcher.adopted_registry_identity(None))

    def _mnr_agy_args(self, tag):
        return types.SimpleNamespace(
            harness="agy", unique=None, tag=tag, label=None,
            model=None, teams=False, dry_run=False, manifest="/nonexistent",
        )

    def _adopt_env(self, tag="gemini", records=None):
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(sessions=records or [], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        return cwd, manifest, self._mnr_agy_args(tag)

    def _run_gone_reclaim(self, manifest, args, entry):
        with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
             mock.patch.object(launcher, "tap_handles", lambda _root: {args.tag}), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: entry), \
             mock.patch.object(launcher, "tmux_pane_facts", lambda _target: None), \
             mock.patch.object(launcher, "entry_observed_dead", return_value=True), \
             mock.patch.object(launcher, "duplicate_registry_session_owner", lambda _t: None), \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=False)), \
             contextlib.redirect_stderr(io.StringIO()):
            return launcher.make_new_record(args, manifest)

    def test_mint_launch_session_id_skips_opencode_without_spawning_serve(self):
        # The plugin captures the TUI-created id during `tap in`; do not pay one
        # `opencode serve` spawn per launch for an unnecessary pre-mint.
        record = launcher.SessionRecord(
            name="demo-app/glm",
            harness="opencode",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="glm",
            index=1,
            model="openrouter/z-ai/glm-5.2",
        )
        with mock.patch.object(
            launcher.subprocess, "Popen", side_effect=OSError("spawn must not occur")
        ) as popen:
            updated = launcher.mint_launch_session_id(record)
        popen.assert_not_called()
        self.assertIs(updated, record)

    def test_mint_launch_session_id_cursor_success(self):
        # tap-e9v8: cursor pre-mint stamps harness_session_id (UUID format).
        record = launcher.SessionRecord(
            name="demo-app/grok",
            harness="cursor",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="grok",
            index=1,
            model="grok-4",
        )
        fake_uuid = "550e8400-e29b-41d4-a716-446655440000"
        with mock.patch.object(launcher, "cursor_mint_session", return_value=fake_uuid):
            updated = launcher.mint_launch_session_id(record)
        self.assertEqual(updated.harness_session_id, fake_uuid)
        self.assertEqual(updated.identity_capture_action, "new")

    def test_mint_launch_session_id_fail_open_on_mint_error(self):
        # tap-e9v8: mint failure returns the record UNCHANGED — fail-open,
        # launch proceeds with today's no-id behavior (#xxx doctrine).
        record = launcher.SessionRecord(
            name="demo-app/grok",
            harness="cursor",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="grok",
            index=1,
            model="grok-4",
        )
        with mock.patch.object(launcher, "cursor_mint_session", return_value=None):
            updated = launcher.mint_launch_session_id(record)
        self.assertIsNone(updated.harness_session_id)
        self.assertNotEqual(updated.identity_capture_action, "new")

    def test_mint_launch_session_id_skips_claude_and_codex(self):
        # tap-e9v8: claude and codex already have deterministic launch-time
        # capture — no mint route needed.
        for harness in ("claude", "codex"):
            record = launcher.SessionRecord(
                name=f"demo-app/{harness}",
                harness=harness,
                cwd="/Users/runner/wrk/demo-app",
                base="demo-app",
                tag=harness,
                index=1,
                model="test-model",
            )
            updated = launcher.mint_launch_session_id(record)
            self.assertIsNone(updated.harness_session_id,
                              f"{harness} should not be minted")

    def test_mint_launch_session_id_skips_when_id_already_present(self):
        # tap-e9v8: if the record already has a harness_session_id (e.g. a
        # resume), don't mint a new one.
        record = launcher.SessionRecord(
            name="demo-app/grok",
            harness="cursor",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="grok",
            index=1,
            model="grok-4",
            harness_session_id="550e8400-e29b-41d4-a716-446655440000",
        )
        with mock.patch.object(launcher, "cursor_mint_session") as mock_mint:
            updated = launcher.mint_launch_session_id(record)
        mock_mint.assert_not_called()
        self.assertEqual(
            updated.harness_session_id,
            "550e8400-e29b-41d4-a716-446655440000",
        )

    def test_cursor_mint_session_returns_none_on_subprocess_error(self):
        # tap-e9v8: fail-open — subprocess errors return None, never raise.
        with mock.patch.object(launcher.subprocess, "run", side_effect=OSError("no cursor-agent")):
            result = launcher.cursor_mint_session("/tmp/test")
        self.assertIsNone(result)

    def test_cursor_mint_session_parses_uuid_from_stdout(self):
        # tap-e9v8: create-chat prints a UUID; the parser extracts it.
        fake_result = mock.MagicMock()
        fake_result.returncode = 0
        fake_result.stdout = "Chat created: 550e8400-e29b-41d4-a716-446655440000\n"
        with mock.patch.object(launcher.subprocess, "run", return_value=fake_result):
            result = launcher.cursor_mint_session("/tmp/test")
        self.assertEqual(result, "550e8400-e29b-41d4-a716-446655440000")

    def test_builds_codex_resume_with_native_session_id(self):
        record = launcher.SessionRecord(
            name="demo-app-codex-builder",
            harness="codex",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="builder",
            index=1,
            model="gpt-5.6-sol",
            harness_session_id="019a1111-2222-7333-8444-555555555555",
        )

        invocation = launcher.build_harness_invocation("resume", record)

        self.assertEqual(
            invocation.argv,
            [
                "codex",
                "--dangerously-bypass-approvals-and-sandbox",
                "resume",
                "--model",
                "gpt-5.6-sol",
                "019a1111-2222-7333-8444-555555555555",
            ],
        )

    def test_builds_codex_resume_ignores_indexed_tap_tag_without_native_session_id(self):
        record = launcher.SessionRecord(
            name="demo-app-codex-builder-2",
            harness="codex",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="builder",
            index=2,
        )

        invocation = launcher.build_harness_invocation("resume", record)

        self.assertEqual(
            invocation.argv,
            ["codex", "--dangerously-bypass-approvals-and-sandbox", "resume"],
        )

    def test_codex_resume_without_native_id_uses_bare_picker(self):
        record = launcher.SessionRecord(
            name="demo-app-codex-builder",
            harness="codex",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="builder",
            index=1,
        )

        invocation = launcher.build_harness_invocation("resume", record)

        self.assertEqual(
            invocation.argv,
            ["codex", "--dangerously-bypass-approvals-and-sandbox", "resume"],
        )

    def test_backfills_codex_session_id_from_rollout_for_matching_cwd(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            sessions = root / "codex-sessions"
            write_codex_rollout(
                sessions,
                "2026-07-10T00-17-44",
                "019a1111-2222-7333-8444-555555555555",
                str(root),
            )
            record = launcher.SessionRecord(
                name="repo/codex",
                harness="codex",
                cwd=str(root),
                base="repo",
                index=1,
            )

            backfill = getattr(launcher, "backfill_codex_session_id", None)
            self.assertIsNotNone(backfill)
            updated = backfill(record, sessions_root=sessions)

            self.assertEqual(updated.harness_session_id, "019a1111-2222-7333-8444-555555555555")

    def test_session_record_round_trips_transcript_path(self):
        record = launcher.SessionRecord(
            name="repo/claude",
            harness="claude",
            cwd="/repo",
            base="repo",
            harness_session_id="new-id",
            transcript_path="/home/me/.claude/projects/repo/original-id.jsonl",
            quarantined_harness_session_id="suspect-id",
            quarantined_transcript_path="/home/me/.claude/projects/repo/suspect.jsonl",
            identity_quarantine_reason="picker fallback was not bound to an expected seat identity",
        )

        restored = launcher.SessionRecord.from_dict(record.to_dict())

        self.assertEqual(restored.transcript_path, record.transcript_path)
        self.assertEqual(restored.quarantined_harness_session_id, "suspect-id")
        self.assertEqual(restored.quarantined_transcript_path, "/home/me/.claude/projects/repo/suspect.jsonl")
        self.assertEqual(
            restored.identity_quarantine_reason,
            "picker fallback was not bound to an expected seat identity",
        )

    def test_transcript_probe_fails_closed_on_stat_error(self):
        record = launcher.SessionRecord(
            name="repo/fable",
            harness="claude",
            cwd="/repo",
            base="repo",
            tag="fable",
            transcript_path="/home/me/.claude/projects/repo/original-id.jsonl",
        )

        with mock.patch.object(pathlib.Path, "stat", side_effect=PermissionError):
            self.assertFalse(
                launcher.conversation_artifact_missing(record, "2026-07-01T00:00:00Z")
            )

    # --- tap-gc1n / Bug B: never exact-resume a ghost harness_session_id ---

    def test_ghost_hsid_falls_back_to_transcript_path_id(self):
        """RED on main: ghost acting hsid is still exact-targeted despite live transcript_path."""
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp)
            projects = home / "projects"
            cwd = "/Users/runner/wrk/Example-Org/tap"
            live = "dc20dfc6-382c-4351-b377-e070745078b5"
            ghost = "019fd91a-b574-7881-9e1b-e1bc5f970291"
            transcript = write_claude_transcript(projects, cwd, live)
            record = launcher.SessionRecord(
                name="tap/fable",
                harness="claude",
                cwd=cwd,
                base="tap",
                tag="fable",
                model="fable",
                harness_session_id=ghost,
                transcript_path=str(transcript),
            )
            with mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}):
                target = launcher.resolve_resume_target(record)
                invocation = launcher.build_harness_invocation("resume", record)
            self.assertEqual(target.session_id, live)
            self.assertEqual(target.source, "transcript_path")
            self.assertTrue(target.split_brain)
            self.assertEqual(
                invocation.argv,
                [
                    "claude",
                    "--dangerously-skip-permissions",
                    "--model",
                    "fable",
                    "--name",
                    "tap/fable",
                    "--resume",
                    live,
                ],
            )

    def test_resume_chain_quarantined_disclosed_when_hsid_and_transcript_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp)
            projects = home / "projects"
            cwd = "/repo"
            qid = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
            qpath = write_claude_transcript(projects, cwd, qid)
            record = launcher.SessionRecord(
                name="repo/claude",
                harness="claude",
                cwd=cwd,
                base="repo",
                tag="claude",
                harness_session_id="00000000-dead-dead-dead-000000000000",
                transcript_path=str(projects / "nope" / "missing.jsonl"),
                quarantined_harness_session_id=qid,
                quarantined_transcript_path=str(qpath),
                identity_quarantine_reason="unattested SessionStart identity differed",
            )
            with mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}):
                target = launcher.resolve_resume_target(record)
                with mock.patch("sys.stderr", new=io.StringIO()) as err:
                    invocation = launcher.build_harness_invocation("resume", record)
                    stderr = err.getvalue()
            self.assertEqual(target.session_id, qid)
            self.assertEqual(target.source, "quarantined")
            self.assertIn("quarantined", (target.disclosure or "").lower())
            self.assertIn(qid, invocation.argv)
            self.assertIn("quarantined session", stderr.lower())

    def test_resume_chain_empties_to_idless_picker(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp)
            (home / "projects").mkdir()
            record = launcher.SessionRecord(
                name="repo/claude",
                harness="claude",
                cwd="/repo",
                base="repo",
                harness_session_id="00000000-dead-dead-dead-000000000000",
                transcript_path=str(home / "projects" / "p" / "missing.jsonl"),
            )
            with mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}):
                target = launcher.resolve_resume_target(record)
                invocation = launcher.build_harness_invocation("resume", record)
            self.assertIsNone(target.session_id)
            self.assertEqual(target.source, "picker")
            self.assertEqual(
                invocation.argv,
                ["claude", "--dangerously-skip-permissions", "--name", "repo/claude", "--resume"],
            )

    def test_resume_identity_split_detected_when_hsid_disagrees_with_transcript_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp)
            projects = home / "projects"
            cwd = "/repo"
            live = "11111111-1111-1111-1111-111111111111"
            ghost = "22222222-2222-2222-2222-222222222222"
            transcript = write_claude_transcript(projects, cwd, live)
            record = launcher.SessionRecord(
                name="repo/claude",
                harness="claude",
                cwd=cwd,
                base="repo",
                harness_session_id=ghost,
                transcript_path=str(transcript),
            )
            with mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}):
                target = launcher.resolve_resume_target(record)
                with mock.patch("sys.stderr", new=io.StringIO()) as err:
                    launcher.build_harness_invocation("resume", record)
                    stderr = err.getvalue()
            self.assertTrue(target.split_brain)
            self.assertIn("resume_identity_split", stderr)

    def test_live_acting_hsid_still_exact_resumes(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp)
            projects = home / "projects"
            cwd = "/repo"
            live = "33333333-3333-3333-3333-333333333333"
            transcript = write_claude_transcript(projects, cwd, live)
            record = launcher.SessionRecord(
                name="repo/claude",
                harness="claude",
                cwd=cwd,
                base="repo",
                harness_session_id=live,
                transcript_path=str(transcript),
            )
            with mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}):
                target = launcher.resolve_resume_target(record)
                invocation = launcher.build_harness_invocation("resume", record)
            self.assertEqual(target.source, "acting_hsid")
            self.assertFalse(target.split_brain)
            self.assertIn(live, invocation.argv)

    def test_default_codex_sessions_root_prefers_tap_codex_home(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            with mock.patch.dict(os.environ, {"TAP_CODEX_HOME": str(root / "tap-codex"), "CODEX_HOME": str(root / "codex")}):
                self.assertEqual(launcher.default_codex_sessions_root(), root / "tap-codex" / "sessions")

    def test_rollout_session_meta_skips_non_object_json_lines(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            rollout = root / "rollout-2026-07-10T00-17-44-019a.jsonl"
            rollout.write_text(
                "null\n"
                "[]\n"
                + json.dumps({
                    "type": "session_meta",
                    "payload": {
                        "id": "019a1111-2222-7333-8444-555555555555",
                        "cwd": str(root),
                    },
                })
                + "\n"
            )

            self.assertEqual(
                launcher.rollout_session_meta(rollout),
                {
                    "id": "019a1111-2222-7333-8444-555555555555",
                    "cwd": str(root),
                },
            )

    def test_codex_backfill_refuses_ambiguous_same_cwd_rollouts(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            sessions = root / "codex-sessions"
            write_codex_rollout(
                sessions,
                "2026-07-10T00-17-44",
                "019a1111-2222-7333-8444-555555555555",
                str(root),
                timestamp="2026-07-10T00:17:44.000Z",
            )
            write_codex_rollout(
                sessions,
                "2026-07-10T00-18-44",
                "019a9999-2222-7333-8444-555555555555",
                str(root),
                timestamp="2026-07-10T00:18:44.000Z",
            )
            record = launcher.SessionRecord(
                name="repo/planner",
                harness="codex",
                cwd=str(root),
                base="repo",
                tag="planner",
                index=1,
            )

            updated = launcher.backfill_codex_session_id(record, sessions_root=sessions)

            self.assertIsNone(updated.harness_session_id)

    def test_codex_backfill_ignores_stale_rollout_when_launch_timestamp_is_provided(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            sessions = root / "codex-sessions"
            write_codex_rollout(
                sessions,
                "2026-07-10T00-17-44",
                "019a1111-2222-7333-8444-555555555555",
                str(root),
                timestamp="2026-07-10T00:17:44.000Z",
            )
            record = launcher.SessionRecord(
                name="repo/codex",
                harness="codex",
                cwd=str(root),
                base="repo",
                index=1,
            )

            updated = launcher.backfill_codex_session_id(
                record,
                sessions_root=sessions,
                started_after="2026-07-10T00:17:45Z",
            )

            self.assertIsNone(updated.harness_session_id)

    def test_codex_backfill_uses_single_post_launch_rollout(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            sessions = root / "codex-sessions"
            write_codex_rollout(
                sessions,
                "2026-07-10T00-17-44",
                "019a1111-2222-7333-8444-555555555555",
                str(root),
                timestamp="2026-07-10T00:17:44.000Z",
            )
            write_codex_rollout(
                sessions,
                "2026-07-10T00-17-46",
                "019a9999-2222-7333-8444-555555555555",
                str(root),
                timestamp="2026-07-10T00:17:46.000Z",
            )
            record = launcher.SessionRecord(
                name="repo/codex",
                harness="codex",
                cwd=str(root),
                base="repo",
                index=1,
            )

            updated = launcher.backfill_codex_session_id(
                record,
                sessions_root=sessions,
                started_after="2026-07-10T00:17:45Z",
            )

            self.assertEqual(updated.harness_session_id, "019a9999-2222-7333-8444-555555555555")

    def test_codex_backfill_ignores_wrong_cwd_rollout(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            sessions = root / "codex-sessions"
            wrong = root / "other"
            wrong.mkdir()
            write_codex_rollout(
                sessions,
                "2026-07-10T00-17-44",
                "019a1111-2222-7333-8444-555555555555",
                str(wrong),
            )
            record = launcher.SessionRecord(
                name="repo/codex",
                harness="codex",
                cwd=str(root),
                base="repo",
                index=1,
            )

            updated = launcher.backfill_codex_session_id(record, sessions_root=sessions)

            self.assertIsNone(updated.harness_session_id)

    # --- claude JSONL scan twin (tap-xl3f) ------------------------------------

    def _claude_record(self, cwd: str, **overrides) -> "launcher.SessionRecord":
        fields = dict(name="repo/opus", harness="claude", cwd=cwd, base="repo", index=1)
        fields.update(overrides)
        return launcher.SessionRecord(**fields)

    def test_claude_backfill_uses_single_post_launch_transcript(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            projects = root / "projects"
            write_claude_transcript(
                projects, str(root), "aaaaaaaa-1111-4222-8333-444444444444",
                timestamp="2026-07-10T00:17:46.000Z",
            )
            record = self._claude_record(str(root))

            updated = launcher.backfill_claude_session_id(
                record, projects_root=projects, started_after="2026-07-10T00:17:45Z",
            )

            self.assertEqual(updated.harness_session_id, "aaaaaaaa-1111-4222-8333-444444444444")

    def test_claude_backfill_refuses_ambiguous_same_cwd_transcripts(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            projects = root / "projects"
            write_claude_transcript(
                projects, str(root), "aaaaaaaa-1111-4222-8333-444444444444",
                timestamp="2026-07-10T00:17:46.000Z",
            )
            write_claude_transcript(
                projects, str(root), "bbbbbbbb-1111-4222-8333-444444444444",
                timestamp="2026-07-10T00:17:47.000Z",
            )
            record = self._claude_record(str(root))

            # Two sibling seats launched into one cwd: unresolvable by time, so
            # never guessed (tap-4avp — no cross-principal misassignment).
            updated = launcher.backfill_claude_session_id(
                record, projects_root=projects, started_after="2026-07-10T00:17:45Z",
            )

            self.assertIsNone(updated.harness_session_id)

    def test_claude_backfill_ignores_stale_transcript_before_anchor(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            projects = root / "projects"
            write_claude_transcript(
                projects, str(root), "aaaaaaaa-1111-4222-8333-444444444444",
                timestamp="2026-07-10T00:17:44.000Z",
            )
            record = self._claude_record(str(root))

            updated = launcher.backfill_claude_session_id(
                record, projects_root=projects, started_after="2026-07-10T00:17:45Z",
            )

            self.assertIsNone(updated.harness_session_id)

    def test_claude_backfill_verifies_interior_cwd_against_slug_collision(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            projects = root / "projects"
            target = str(root / "a.b")   # slug: <root>-a-b
            other = str(root / "a") + "/b"  # DIFFERENT cwd, SAME slug: <root>-a-b
            slug = launcher.claude_cwd_slug(target)
            self.assertEqual(slug, launcher.claude_cwd_slug(other))
            # The only transcript in the shared slug dir belongs to `other`.
            write_claude_transcript(
                projects, other, "aaaaaaaa-1111-4222-8333-444444444444",
                timestamp="2026-07-10T00:17:46.000Z", slug=slug,
            )
            record = self._claude_record(target)

            updated = launcher.backfill_claude_session_id(
                record, projects_root=projects, started_after="2026-07-10T00:17:45Z",
            )

            # Interior-cwd verification rejects the slug collision.
            self.assertIsNone(updated.harness_session_id)

    def test_claude_session_meta_skips_forked_filename_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            projects = root / "projects"
            write_claude_transcript(
                projects, str(root), "aaaaaaaa-1111-4222-8333-444444444444",
                timestamp="2026-07-10T00:17:46.000Z",
                interior_session_id="cccccccc-9999-4222-8333-444444444444",
            )
            record = self._claude_record(str(root))

            updated = launcher.backfill_claude_session_id(
                record, projects_root=projects, started_after="2026-07-10T00:17:45Z",
            )

            self.assertIsNone(updated.harness_session_id)

    def test_claude_backfill_is_empty_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            projects = root / "projects"
            write_claude_transcript(
                projects, str(root), "aaaaaaaa-1111-4222-8333-444444444444",
                timestamp="2026-07-10T00:17:46.000Z",
            )
            record = self._claude_record(str(root), harness_session_id="direct-id")

            updated = launcher.backfill_claude_session_id(
                record, projects_root=projects, started_after="2026-07-10T00:17:45Z",
            )

            self.assertEqual(updated.harness_session_id, "direct-id")

    def test_claude_cwd_slug_matches_claude_convention(self):
        # Pin the transform: every non-alphanumeric collapses to '-'. Drift in
        # claude's naming must break this loudly, not silently miss transcripts.
        self.assertEqual(
            launcher.claude_cwd_slug("/Users/runner/wrk/Example-Org/tap"),
            "-Users-runner-wrk-Example-Org-tap",
        )
        self.assertEqual(
            launcher.claude_cwd_slug("/Users/runner/.claude-mem"),
            "-Users-runner--claude-mem",
        )

    # --- opencode CLI scan (tap-xl3f) -----------------------------------------

    def _opencode_record(self, cwd: str, **overrides) -> "launcher.SessionRecord":
        fields = dict(name="repo/glm", harness="opencode", cwd=cwd, base="repo", index=1)
        fields.update(overrides)
        return launcher.SessionRecord(**fields)

    def test_opencode_backfill_uses_single_post_launch_session(self):
        anchor = "2026-07-10T00:17:45Z"
        anchor_ms = int(launcher.parse_timestamp(anchor) * 1000)
        cwd = "/tmp/repo"
        sessions = [
            opencode_session_row("ses_before", cwd, anchor_ms - 1000),
            opencode_session_row("ses_after", cwd, anchor_ms + 1000),
        ]
        record = self._opencode_record(cwd)

        updated = launcher.backfill_opencode_session_id(
            record, started_after=anchor, sessions=sessions,
        )

        self.assertEqual(updated.harness_session_id, "ses_after")

    def test_opencode_backfill_refuses_ambiguous_post_launch_sessions(self):
        anchor = "2026-07-10T00:17:45Z"
        anchor_ms = int(launcher.parse_timestamp(anchor) * 1000)
        cwd = "/tmp/repo"
        sessions = [
            opencode_session_row("ses_a", cwd, anchor_ms + 1000),
            opencode_session_row("ses_b", cwd, anchor_ms + 2000),
        ]
        record = self._opencode_record(cwd)

        updated = launcher.backfill_opencode_session_id(
            record, started_after=anchor, sessions=sessions,
        )

        self.assertIsNone(updated.harness_session_id)

    def test_opencode_backfill_ignores_wrong_cwd(self):
        anchor = "2026-07-10T00:17:45Z"
        anchor_ms = int(launcher.parse_timestamp(anchor) * 1000)
        sessions = [opencode_session_row("ses_elsewhere", "/tmp/other", anchor_ms + 1000)]
        record = self._opencode_record("/tmp/repo")

        updated = launcher.backfill_opencode_session_id(
            record, started_after=anchor, sessions=sessions,
        )

        self.assertIsNone(updated.harness_session_id)

    def test_opencode_backfill_is_empty_only(self):
        anchor = "2026-07-10T00:17:45Z"
        anchor_ms = int(launcher.parse_timestamp(anchor) * 1000)
        cwd = "/tmp/repo"
        sessions = [opencode_session_row("ses_after", cwd, anchor_ms + 1000)]
        record = self._opencode_record(cwd, harness_session_id="direct-id")

        updated = launcher.backfill_opencode_session_id(
            record, started_after=anchor, sessions=sessions,
        )

        self.assertEqual(updated.harness_session_id, "direct-id")

    # --- census/list sweep (tap-xl3f) -----------------------------------------

    def test_resolve_owned_binds_singleton_to_latest_launcher(self):
        # The blocking bug grok found: A.launch < B.launch, only B's row minted.
        # Per-record exactly-one gave ses_B to BOTH; window-bracketing binds it
        # to B alone and leaves A empty (no cross-principal poison).
        t2 = launcher.parse_timestamp("2026-07-10T00:17:50Z")
        a = self._opencode_record("/tmp/repo", name="repo/glm-a", last_launched="2026-07-10T00:17:45Z")
        b = self._opencode_record("/tmp/repo", name="repo/glm-b", last_launched="2026-07-10T00:17:50Z")
        got = launcher.resolve_owned_session_ids([a, b], [("ses_B", t2 + 1)])
        self.assertEqual(got, {"repo/glm-b": "ses_B"})

    def test_resolve_owned_refuses_simultaneous_siblings(self):
        t = launcher.parse_timestamp("2026-07-10T00:17:45Z")
        a = self._opencode_record("/tmp/repo", name="repo/glm-a", last_launched="2026-07-10T00:17:45Z")
        b = self._opencode_record("/tmp/repo", name="repo/glm-b", last_launched="2026-07-10T00:17:45Z")
        got = launcher.resolve_owned_session_ids([a, b], [("ses_X", t + 1)])
        self.assertEqual(got, {})  # tie at the owner anchor -> unownable, neither

    def test_resolve_owned_filled_sibling_blocks_empty_peer(self):
        t2 = launcher.parse_timestamp("2026-07-10T00:17:50Z")
        a = self._opencode_record("/tmp/repo", name="repo/glm-a", last_launched="2026-07-10T00:17:45Z")
        b = self._opencode_record(
            "/tmp/repo", name="repo/glm-b", last_launched="2026-07-10T00:17:50Z", harness_session_id="ses_B",
        )
        got = launcher.resolve_owned_session_ids([a, b], [("ses_B", t2 + 1)])
        self.assertEqual(got, {})  # ses_B is B's; A must not steal it

    def test_resolve_owned_single_seat_captures_its_session(self):
        t1 = launcher.parse_timestamp("2026-07-10T00:17:45Z")
        a = self._opencode_record("/tmp/repo", name="repo/glm", last_launched="2026-07-10T00:17:45Z")
        got = launcher.resolve_owned_session_ids([a], [("ses_A", t1 + 1)])
        self.assertEqual(got, {"repo/glm": "ses_A"})

    def test_resolve_owned_assert_drops_id_held_by_filled_sibling(self):
        # The shared duplicate_harness_session_owner assert (adopted at the #xxx
        # rebase) catches a collision window-bracketing alone would miss: an id
        # window-bracketing would hand to the empty seat is already the recorded
        # id of a filled sibling, so it is dropped rather than duplicated.
        t2 = launcher.parse_timestamp("2026-07-10T00:17:50Z")
        empty = self._opencode_record(
            "/tmp/repo", name="repo/glm-a", last_launched="2026-07-10T00:17:45Z",
        )
        filled = self._opencode_record(
            "/tmp/repo", name="repo/glm-b", last_launched="2026-07-10T00:17:55Z",
            harness_session_id="ses_dup",
        )
        # ses_dup created between empty.launch and filled.launch -> window-
        # bracketing would bind it to `empty`, but `filled` already owns it.
        got = launcher.resolve_owned_session_ids([empty, filled], [("ses_dup", t2)])
        self.assertEqual(got, {})

    def test_compute_backfill_anchorless_filled_peer_blocks_assignment(self):
        # F1: an anchorless FILLED peer must still vote in the ownership assert,
        # so an empty seat is never handed the id that peer already holds. Before
        # the fix, the cohort-membership gate dropped anchorless records and the
        # assert went blind.
        a = self._opencode_record("/tmp/repo", name="repo/glm-a", last_launched="2026-07-10T00:17:45Z")
        b = self._opencode_record("/tmp/repo", name="repo/glm-b", harness_session_id="ses_dup")  # no last_launched
        t1 = launcher.parse_timestamp("2026-07-10T00:17:45Z")
        fake = [opencode_session_row("ses_dup", "/tmp/repo", int((t1 + 1) * 1000))]
        with mock.patch.object(launcher, "opencode_session_list", return_value=fake):
            got = launcher.compute_backfill_ids([a, b])
        self.assertEqual(got, {})  # A must not be assigned ses_dup — B holds it

    def test_builds_cursor_agent_with_full_permissions_and_model(self):
        record = launcher.SessionRecord(
            name="demo-app-cursor-fable",
            harness="cursor",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="fable",
            index=1,
            model="claude-fable-5-high",
        )

        invocation = launcher.build_harness_invocation("new", record)

        self.assertEqual(
            invocation.argv,
            [
                "cursor-agent",
                "--force",
                "--sandbox",
                "disabled",
                "--workspace",
                "/Users/runner/wrk/demo-app",
                "--trust",
                "--model",
                "claude-fable-5-high",
            ],
        )

    def test_cursor_without_a_selected_workspace_does_not_vouch_for_one(self):
        """`--trust` names the SELECTED workspace, so no selection means no flag.

        The flag is emitted beside `--workspace <path>`, and with no path there is
        nothing to vouch for -- asserting trust in whatever directory
        cursor-agent picks for itself is a different statement than the addendum
        authorized. Without this arm the guard is unexercised: every other cursor
        case in this file carries a cwd, so removing the condition entirely would
        leave the suite green.
        """
        record = launcher.SessionRecord(
            name="demo-app/fable",
            harness="cursor",
            cwd="",
            base="demo-app",
            tag="fable",
            index=1,
            model="claude-fable-5-high",
        )

        invocation = launcher.build_harness_invocation("new", record)

        self.assertNotIn("--trust", invocation.argv)
        self.assertEqual(
            invocation.argv,
            [
                "cursor-agent",
                "--force",
                "--sandbox",
                "disabled",
                "--workspace",
                "",
                "--model",
                "claude-fable-5-high",
            ],
        )

    def test_cursor_resume_without_native_id_uses_picker(self):
        record = launcher.SessionRecord(
            name="demo-app/fable",
            harness="cursor",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            tag="fable",
            index=1,
            model="claude-fable-5-high",
        )

        invocation = launcher.build_harness_invocation("resume", record)

        self.assertEqual(
            invocation.argv,
            [
                "cursor-agent",
                "--force",
                "--sandbox",
                "disabled",
                "--workspace",
                "/Users/runner/wrk/demo-app",
                "--trust",
                "--model",
                "claude-fable-5-high",
                "--resume",
            ],
        )

    def test_pre_mint_id_reaches_argv_on_new_and_resume_for_cursor(self):
        # tap-rs1q / tap-xsgi, agreement (b) with opus-2: emission keys on
        # id-set, not mint-freshness. Gating the adoption flag on
        # action=="resume" reserved-and-dropped the cursor mint. An arm that
        # asserted "stored id on new does not emit" would encode that drop as
        # expected behavior. The OpenCode twin is pinned by the matrix below.
        minted = "550e8400-e29b-41d4-a716-446655440000"
        record = launcher.SessionRecord(
            name="repo/cursor",
            harness="cursor",
            cwd="/tmp/repo",
            base="repo",
            tag="cursor",
            index=1,
            model="test-model",
            harness_session_id=minted,
        )
        for action in ("new", "resume"):
            argv = launcher.build_harness_invocation(action, record).argv
            self.assertIn("--resume", argv, f"cursor {action} missing --resume")
            self.assertEqual(argv[argv.index("--resume") + 1], minted)

    def test_opencode_new_launch_adopts_exact_id_and_idless_starts_fresh(self):
        for session_id in (None, "ses_minted"):
            record = launcher.SessionRecord(
                name="repo/opencode",
                harness="opencode",
                cwd="/tmp/repo",
                base="repo",
                tag="opencode",
                index=1,
                model="test-model",
                harness_session_id=session_id,
            )
            for action in ("new", "launch", "clear"):
                with self.subTest(action=action, session_id=session_id):
                    invocation = launcher.build_harness_invocation(action, record)
                    suffix = ["--session", session_id] if session_id else []
                    self.assertEqual(
                        invocation.argv,
                        ["opencode", "--model", "test-model", *suffix],
                    )

    def test_native_revive_mode_opencode_is_exact_with_id_and_fresh_without(self):
        action, receipt = launcher.native_revive_mode("opencode", "ses_previous")
        self.assertEqual((action, receipt), ("resume", "opencode resume ses_previous"))

        action, receipt = launcher.native_revive_mode("opencode", None)
        self.assertEqual((action, receipt), ("new", "no conversation to resume"))

    def test_opencode_idless_resume_warning_names_fresh_not_continuation(self):
        record = launcher.SessionRecord(
            name="demo/glm",
            harness="opencode",
            cwd="/tmp/demo",
            base="demo",
        )
        stderr = io.StringIO()

        with contextlib.redirect_stderr(stderr):
            launcher.warn_native_resume_fallback(record)

        self.assertIn("starting a fresh conversation", stderr.getvalue())
        self.assertNotIn("continuation", stderr.getvalue())
        self.assertNotIn("picker", stderr.getvalue())

    def test_opencode_adopted_idless_warning_names_fresh_not_picker(self):
        record = launcher.SessionRecord(
            name="demo/glm",
            harness="opencode",
            cwd="/tmp/demo",
            base="demo",
        )
        stderr = io.StringIO()

        with contextlib.redirect_stderr(stderr):
            launcher.warn_adopted_resume(record, native_query=None)

        self.assertIn("starting a fresh conversation", stderr.getvalue())
        self.assertNotIn("picker", stderr.getvalue())

    def test_opencode_revive_tier_is_exact_with_id_and_fresh_without(self):
        self.assertEqual(launcher.revive_tier("opencode", "ses_previous"), "exact")
        self.assertEqual(launcher.revive_tier("opencode", None), "fresh")
        self.assertEqual(
            launcher.describe_revive_tier("exact"),
            "resume the recorded conversation by its native id",
        )
        self.assertEqual(
            launcher.describe_revive_tier("fresh"),
            "no conversation to resume — start a fresh session under this name",
        )

    def test_opencode_collision_picker_restores_truthful_resume_option(self):
        calls = []

        def capture(verb, question, options, default):
            calls.append((verb, question, options, default))
            return default

        with mock.patch.object(launcher, "prompt_choice", side_effect=capture):
            self.assertEqual(
                launcher.prompt_new_collision(
                    "demo/glm", "opencode", "a stopped session record", "exact"
                ),
                "r",
            )
            self.assertEqual(
                launcher.prompt_new_collision(
                    "demo/kimi", "opencode", "an id-less stopped record", "fresh"
                ),
                "r",
            )

        _, exact_question, exact_options, exact_default = calls[0]
        self.assertNotIn("temporarily disabled", exact_question)
        self.assertEqual(exact_default, "r")
        self.assertIn(
            ("r", "resume", "resume the recorded conversation by its native id"),
            exact_options,
        )

        _, fresh_question, fresh_options, fresh_default = calls[1]
        self.assertNotIn("/resume", fresh_question)
        self.assertEqual(fresh_default, "r")
        self.assertIn(
            (
                "r",
                "resume",
                "no conversation to resume — start a fresh session under this name",
            ),
            fresh_options,
        )

    def test_opencode_resume_is_exact_or_fresh_at_both_invocation_builders(self):
        for session_id in (None, "ses_previous"):
            record = launcher.SessionRecord(
                name="demo/glm",
                harness="opencode",
                cwd="/tmp/demo",
                base="demo",
                harness_session_id=session_id,
            )
            for label, builder in (
                ("stored", lambda: launcher.build_harness_invocation("resume", record)),
                ("native", lambda: launcher.build_native_resume_invocation(record, session_id)),
            ):
                with self.subTest(session_id=session_id, builder=label):
                    suffix = ["--session", session_id] if session_id else []
                    self.assertEqual(builder().argv, ["opencode", *suffix])

            invocation = launcher.build_harness_invocation("new", record)
            suffix = ["--session", session_id] if session_id else []
            self.assertEqual(invocation.argv, ["opencode", *suffix])

    def test_native_revive_mode_cursor_with_id_is_resume_not_new(self):
        # Census pin: a stored cursor id never arrives on action "new" via
        # resurrect. native_revive_mode(cursor, id) is resume; without an id
        # it is new (and make_new_record then leaves hsid None).
        action, _ = launcher.native_revive_mode(
            "cursor", "550e8400-e29b-41d4-a716-446655440000"
        )
        self.assertEqual(action, "resume")
        action, _ = launcher.native_revive_mode("cursor", None)
        self.assertEqual(action, "new")

    def test_make_new_record_cursor_and_opencode_start_new_with_no_id(self):
        # Census pin: inherited_id is assigned only under resurrect_action ==
        # "resume". A non-resurrect cursor/opencode record starts with no id;
        # cursor may mint later, while OpenCode captures its id during `tap in`.
        cwd = str(pathlib.Path.cwd().resolve())
        root = launcher.root_for_cwd(cwd)
        for harness in ("cursor", "opencode"):
            with self.subTest(harness=harness):
                args = types.SimpleNamespace(
                    harness=harness,
                    unique=None,
                    tag=None,
                    label="probe",
                    model=None,
                    teams=False,
                    harness_passthrough=[],
                    preset_resolution=None,
                )
                manifest = launcher.Manifest(sessions=[], dir_aliases={root: "xx"})
                with mock.patch.object(
                    launcher, "tmux_sessions_for_namespace", return_value=set()
                ), mock.patch.object(
                    launcher, "tap_handles", return_value=set()
                ), mock.patch.object(
                    launcher, "registry_entry", return_value=None
                ):
                    record = launcher.make_new_record(args, manifest)
                self.assertEqual(record.ensure_action, "new")
                self.assertIsNone(record.harness_session_id)

    def test_refuse_preexisting_id_on_new_mint_is_cursor_only(self):
        # Gate pin (opus-2): the mint `and not harness_session_id` clause would
        # otherwise let a future new-path leak skip mint and then --resume a
        # stored id. Claude uuid4-on-new must still pass.
        cursor = launcher.SessionRecord(
            name="repo/grok", harness="cursor", cwd="/tmp/repo", base="repo",
            tag="grok", index=1, harness_session_id="stored-id",
            ensure_action="new",
        )
        with self.assertRaisesRegex(launcher.LauncherError, "pre-existing"):
            launcher.refuse_preexisting_id_on_new_mint(cursor)
        opencode = dataclasses.replace(cursor, harness="opencode")
        try:
            launcher.refuse_preexisting_id_on_new_mint(opencode)
        except launcher.LauncherError as exc:
            self.fail(f"opencode no longer mints or adopts from argv: {exc}")
        claude = dataclasses.replace(
            cursor, harness="claude", harness_session_id="claude-uuid"
        )
        launcher.refuse_preexisting_id_on_new_mint(claude)
        empty = dataclasses.replace(cursor, harness_session_id=None)
        launcher.refuse_preexisting_id_on_new_mint(empty)
        resume = dataclasses.replace(cursor, ensure_action="resume")
        launcher.refuse_preexisting_id_on_new_mint(resume)

    def test_cmd_new_refuses_preexisting_id_on_new_mint(self):
        # Call-site pin (merge-gate #xxx): the helper test above stays green if
        # the wiring line in cmd_new is deleted. Drive cmd_new itself so that
        # mutation reds. make_new_record is mocked because no production
        # constructor builds new+stored-id; the gate exists to catch a future
        # path that would.
        leaked = launcher.SessionRecord(
            name="repo/grok", harness="cursor", cwd="/tmp/repo", base="repo",
            tag="grok", index=1, harness_session_id="stored-id",
            ensure_action="new",
        )
        args = types.SimpleNamespace(
            harness="cursor",
            unique=None,
            tag=None,
            label="probe",
            model=None,
            effort=None,
            env=None,
            preset=None,
            teams=False,
            fresh=False,
            dry_run=True,
            json=False,
            attach=False,
        )
        with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
             mock.patch.object(launcher, "_reset_fence_entry_barrier"), \
             mock.patch.object(launcher, "_refuse_if_flip_authority"), \
             mock.patch.object(
                 launcher, "registry_session_state",
                 return_value=launcher.Manifest(sessions=[], dir_aliases={}),
             ), \
             mock.patch.object(launcher, "make_new_record", return_value=leaked), \
             mock.patch.object(launcher, "run_record", return_value=0):
            with self.assertRaisesRegex(launcher.LauncherError, "pre-existing"):
                launcher.cmd_new(args)

    def test_clear_wipes_cursor_id_before_mint(self):
        # Census pin: tap clear must not --resume the conversation it is
        # replacing. The mint sees None; after tap-rs1q the composed argv
        # then carries --resume <fresh>.
        seen = []

        def fake_mint(rec):
            seen.append(rec.harness_session_id)
            updated = dataclasses.replace(rec, harness_session_id="fresh-mint-id")
            updated.identity_capture_action = "new"
            return updated

        record = launcher.SessionRecord(
            name="repo/grok", harness="cursor", cwd="/seat/cwd", base="repo",
            tag="grok", index=1, harness_session_id="old-stored-id",
            model="cursor-grok-4.6-high",
        )
        args = types.SimpleNamespace(seat="grok", message=None, dry_run=True)
        buf = io.StringIO()
        # ROOT AND REGISTRY MUST DESCRIBE THE SAME TEAM. These fixtures used to
        # return root "/target/root" with the registry in a tmpdir — a pairing no
        # real machine produces — and passed only because the bus was derived
        # from the REGISTRY path, so the fake root was never consulted. Now that
        # the fence bus comes from the root authority, that divergence points the
        # fence at a directory that does not exist. The fixture was more generous
        # than the world; using the same directory for both is what the world
        # actually supplies.
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "root_for_cwd", return_value="/root"), \
                 mock.patch.object(
                     launcher, "clear_target_pane",
                     return_value=("%41", {"session": record.name, "base": record.base, "harness": record.harness, "model": record.model, "registered_from_worktree": record.cwd, "harness_session_id": record.harness_session_id}),
                 ), \
                 mock.patch.object(
                     launcher, "registry_session_state",
                     return_value=launcher.Manifest(sessions=[record], dir_aliases={}),
                 ), \
                 mock.patch.object(launcher, "entry_session_name", return_value="repo/grok"), \
                 mock.patch.object(launcher, "resolve_exact_record", return_value=record), \
                 mock.patch.object(launcher, "mint_launch_session_id", side_effect=fake_mint), \
                 mock.patch.dict(os.environ, {"TAP_HOME": bus}, clear=False), \
                 contextlib.redirect_stdout(buf):
                rc = launcher.cmd_clear(args)
        self.assertEqual(rc, 0)
        self.assertEqual(seen, [None])
        out = buf.getvalue()
        self.assertIn("--resume", out)
        self.assertIn("fresh-mint-id", out)
        self.assertNotIn("old-stored-id", out)

    def test_builds_hermes_with_absolute_shim(self):
        record = launcher.SessionRecord(
            name="demo-app-hermes",
            harness="hermes",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            index=1,
        )

        invocation = launcher.build_harness_invocation("new", record)

        self.assertEqual(invocation.argv, ["hermes"])

    def test_builds_claude_native_resume_picker_inside_named_tmux_session(self):
        record = launcher.SessionRecord(
            name="meta-claude-0",
            harness="claude",
            cwd="/Users/runner/wrk/demo-app",
            base="meta",
            index=0,
            model="opus[1m]",
        )

        invocation = launcher.build_native_resume_invocation(record, native_query=None)

        self.assertEqual(
            invocation.argv,
            [
                "claude",
                "--dangerously-skip-permissions",
                "--model",
                "opus[1m]",
                "--name",
                "meta-claude-0",
                "--resume",
            ],
        )

    def test_native_resume_builder_originates_no_env_either(self):
        # sol P2: the deletion pins covered the launch rail but not this one, and the two
        # builders carried IDENTICAL special cases — so a regrown special case here would
        # have been invisible. Both former cases are asserted: the codex ponytail tag and a
        # claude seat that would once have been "teams".
        cases = (
            ("codex", {"tag": "ponytail", "model": "gpt-5.6-sol"}),
            # This case used to pass teams=True, because that was what INDUCED the deleted
            # claude branch — without it, restoring `if record.teams: env[...] = "true"` would
            # have stayed green against a record that never set it (sol P2). U5 deleted the
            # record field, so the induction is no longer expressible, and neither is the
            # regression: the restored line would raise AttributeError rather than pass
            # silently. That holds only WHILE THE FIELD STAYS DELETED, so the guarantee is a
            # PAIR, not one argument — test_a_row_persisted_with_teams_still_loads_and_does_
            # not_resurrect_the_field is what keeps it deleted, and this induction is what
            # makes a branch restored without the field crash instead of pass. Neither half
            # covers this alone. The case stays for the broader claim this test makes — that
            # this builder originates no env at all.
            ("claude", {"tag": "planner", "model": "opus[1m]"}),
        )
        for harness, fields in cases:
            with self.subTest(harness=harness):
                record = launcher.SessionRecord(
                    name=f"meta-{harness}-0",
                    harness=harness,
                    cwd="/Users/runner/wrk/demo-app",
                    base="meta",
                    index=0,
                    **fields,
                )
                invocation = launcher.build_native_resume_invocation(
                    record, native_query=None
                )
                self.assertEqual(invocation.env, {})

    def test_no_builder_originates_environment_for_any_harness(self):
        # tap-ctzt. "The invocation builders originate NO environment" is stated as a guarantee
        # in three places — apply_launch_env's docstring, CONTRACT.md §Harness-level environment
        # tier 2, and the empty `env.update(invocation.env)` kept in the slot where the deleted
        # per-harness tier used to live. The two tests above check that claim at two points
        # (claude on the launch rail; claude and codex on the native-resume rail). The claim is
        # universal, so this checks it universally: adding an env line to the agy, cursor,
        # hermes, or opencode builder passed everything before this test existed.
        #
        # It iterates HARNESSES rather than a literal tuple so a SEVENTH harness joins the
        # assertion by existing, not by someone remembering to extend a list here.
        #
        # The record carries the fields that used to INDUCE the deleted tiers — a tag (the
        # `record.tag == "ponytail"` branch), a model, and a harness_env key. A bare record
        # would leave a regrown special case untriggered and this test green through it.
        # harness_env is deliberately non-empty: it belongs to apply_launch_env's third tier,
        # so a builder that started forwarding it would red here rather than look like tier
        # composition working.
        self.assertTrue(
            launcher.HARNESSES >= {"agy", "claude", "codex", "cursor", "hermes", "opencode"},
            "HARNESSES shrank; an enumerating pin over an emptied set passes vacuously",
        )
        for harness in sorted(launcher.HARNESSES):
            record = launcher.SessionRecord(
                name=f"meta-{harness}-0",
                harness=harness,
                cwd="/Users/runner/wrk/demo-app",
                base="meta",
                tag="ponytail",
                index=0,
                model="some-model",
                harness_env={"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "true"},
            )
            for action in ("new", "resume"):
                with self.subTest(harness=harness, builder=f"build_harness_invocation/{action}"):
                    self.assertEqual(
                        launcher.build_harness_invocation(action, record).env, {}
                    )
            with self.subTest(harness=harness, builder="build_native_resume_invocation"):
                self.assertEqual(
                    launcher.build_native_resume_invocation(record, native_query=None).env, {}
                )

    def test_every_model_capable_builder_emits_the_table_flag(self):
        # tap-ppo7. The table is the source of --model spelling; a builder that still
        # hardcodes a subset (or drops agy) would pass the resolver tests and fail here.
        # Iterates HARNESSES; equality with TUNING_CAPABILITIES is the other direction.
        self.assertEqual(set(preset_config.TUNING_CAPABILITIES), set(launcher.HARNESSES))
        for harness in sorted(launcher.HARNESSES):
            axis = preset_config.TUNING_CAPABILITIES[harness].model
            if axis is None:
                continue
            record = launcher.SessionRecord(
                name=f"meta-{harness}-0",
                harness=harness,
                cwd="/Users/runner/wrk/demo-app",
                base="meta",
                index=0,
                model="table-pin-model",
            )
            argv = launcher.build_harness_invocation("new", record).argv
            with self.subTest(harness=harness):
                for token in axis.tokens("table-pin-model"):
                    self.assertIn(token, argv)

    def test_builds_codex_native_resume_with_query(self):
        record = launcher.SessionRecord(
            name="meta-codex-planner-0",
            harness="codex",
            cwd="/Users/runner/wrk/demo-app",
            base="meta",
            tag="planner",
            index=0,
            model="gpt-5.6-sol",
        )

        invocation = launcher.build_native_resume_invocation(record, native_query="planner")

        self.assertEqual(invocation.env, {})
        self.assertEqual(
            invocation.argv,
            [
                "codex",
                "--dangerously-bypass-approvals-and-sandbox",
                "resume",
                "--model",
                "gpt-5.6-sol",
                "planner",
            ],
        )

    def test_adopted_codex_resume_query_equal_to_harness_does_not_persist_harness_tag(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[])
            args = types.SimpleNamespace(harness="codex", resume_query="codex", name=None, model=None, teams=False)

            record, native_query = launcher.make_adopted_resume_record(args, manifest, cwd=str(root), occupied_names=set())

            self.assertIsNone(record.tag)
            self.assertIsNone(native_query)
            self.assertEqual(record.name, "repo/codex")

    def test_stamp_launched_uses_tap_watch_now(self):
        record = launcher.SessionRecord(
            name="demo-app-claude-0",
            harness="claude",
            cwd="/Users/runner/wrk/demo-app",
            base="demo-app",
            index=1,
        )
        old_now = os.environ.get("TAP_WATCH_NOW")
        try:
            os.environ["TAP_WATCH_NOW"] = "2000000000"
            stamped = launcher.stamp_launched(record)
        finally:
            if old_now is None:
                os.environ.pop("TAP_WATCH_NOW", None)
            else:
                os.environ["TAP_WATCH_NOW"] = old_now

        self.assertEqual(stamped.last_launched, "2033-05-18T03:33:20Z")

    def test_new_parser_accepts_fresh(self):
        args = launcher.build_parser().parse_args(["new", "claude", "scout", "--fresh"])

        self.assertTrue(args.fresh)

    def test_parser_rejects_retired_journal_option_and_commands(self):
        parser = launcher.build_parser()
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            parser.parse_args(["--manifest", "/tmp/sessions.json", "list"])
        for command in ("prune", "undead", "reset", "alias-dir", "archive-unseated"):
            with self.subTest(command), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                parser.parse_args([command])

    def test_resolves_base_from_dir_alias_before_raw_worktree_name(self):
        manifest = launcher.Manifest(
            sessions=[],
            dir_aliases={"/Users/runner/wrk/Example-Org/trees/AESOP-Improvements": "aesop"},
        )

        self.assertEqual(
            launcher.resolve_base_alias(
                "/Users/runner/wrk/Example-Org/trees/AESOP-Improvements",
                manifest,
                launcher.GitProbe(
                    inside=True,
                    root="/Users/runner/wrk/Example-Org/trees/AESOP-Improvements",
                    git_dir="/Users/runner/wrk/Example-Org/.git/worktrees/AESOP-Improvements",
                    common_dir="/Users/runner/wrk/Example-Org/.git",
                ),
            ),
            "aesop",
        )

    def test_expands_resume_number_to_current_base_harness_index(self):
        self.assertEqual(
            launcher.expand_resume_shorthand("2", harness="codex", base="meta"),
            "meta/codex-2",
        )

    def test_expands_resume_zero_to_unnumbered_current_base_harness(self):
        self.assertEqual(
            launcher.expand_resume_shorthand("0", harness="codex", base="meta"),
            "meta/codex",
        )

    def test_expands_resume_zero_to_default_fable_tag_when_model_is_fable(self):
        self.assertEqual(
            launcher.expand_resume_shorthand("0", harness="claude", base="meta", default_tag="fable"),
            "meta/fable",
        )

    def test_expands_resume_tag_index_to_current_base_harness_tag_index(self):
        self.assertEqual(
            launcher.expand_resume_shorthand("planner-0", harness="claude", base="meta"),
            "meta/planner",
        )

    def test_expands_plain_resume_tag_to_current_base_harness_tag(self):
        self.assertEqual(
            launcher.tag_resume_name("builder", harness="codex", base="meta"),
            "meta-codex-builder",
        )

    def test_resume_shorthand_candidates_include_legacy_zero_suffix(self):
        self.assertEqual(
            launcher.resume_shorthand_candidates("planner-0", harness="claude", base="meta"),
            ["meta/planner", "meta-claude-planner", "meta-claude-planner-0"],
        )

    def test_numeric_new_label_requests_resume(self):
        self.assertTrue(
            launcher.new_label_requests_resume(
                types.SimpleNamespace(label="0", tag=None, unique=None)
            )
        )
        self.assertFalse(
            launcher.new_label_requests_resume(
                types.SimpleNamespace(label="planner", tag=None, unique=None)
            )
        )

    def test_does_not_expand_full_resume_name_as_tag_index(self):
        self.assertIsNone(
            launcher.expand_resume_shorthand("meta-claude-planner-0", harness="claude", base="meta")
        )

    def test_numeric_new_label_redirects_to_harness_resume_end_to_end(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            root_key = str(root.resolve())
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={root_key: "meta"},
                    sessions=[
                        launcher.SessionRecord(
                            name="meta/claude-2",
                            harness="claude",
                            cwd=root_key,
                            base="meta",
                            index=2,
                        )
                    ],
                ),
            )
            args = types.SimpleNamespace(
                manifest=str(manifest),
                harness="claude",
                unique=None,
                tag=None,
                label="2",
                model=None,
                teams=False,
                dry_run=False,
            )
            captured = []
            old_cwd = pathlib.Path.cwd()
            original_run_record = launcher.run_record_detached
            try:
                os.chdir(root)
                launcher.run_record_detached = lambda action, record, dry_run: captured.append((action, record.name, dry_run)) or 0
                with mock.patch.object(launcher, "register_resumed_session", return_value=True), mock.patch.object(
                    launcher, "tmux_attach", return_value=0
                ):
                    rc = launcher.cmd_new(args)
            finally:
                launcher.run_record_detached = original_run_record
                os.chdir(old_cwd)

        self.assertEqual(rc, 0)
        self.assertEqual(captured, [("resume", "meta/claude-2", False)])

    def test_plans_adopted_resume_record_from_plain_native_query(self):
        manifest = launcher.Manifest(
            sessions=[],
            dir_aliases={"/Users/runner/wrk/demo-app": "meta"},
        )
        args = types.SimpleNamespace(harness="claude", name="planner", model="opus[1m]", teams=False)

        record, native_query = launcher.make_adopted_resume_record(
            args,
            manifest,
            cwd="/Users/runner/wrk/demo-app",
            occupied_names=set(),
        )

        self.assertEqual(record.name, "meta/planner")
        self.assertEqual(record.tag, "planner")
        self.assertEqual(record.index, 1)
        self.assertEqual(native_query, "planner")

    def test_plans_adopted_resume_record_without_name_uses_fable_default_tag(self):
        manifest = launcher.Manifest(
            sessions=[],
            dir_aliases={"/Users/runner/wrk/demo-app": "meta"},
        )
        args = types.SimpleNamespace(harness="cursor", name=None, model="claude-fable-5-high", teams=False)

        record, native_query = launcher.make_adopted_resume_record(
            args,
            manifest,
            cwd="/Users/runner/wrk/demo-app",
            occupied_names=set(),
        )

        self.assertEqual(record.name, "meta/fable")
        self.assertEqual(record.tag, "fable")
        self.assertEqual(record.index, 1)
        self.assertIsNone(native_query)

    def test_plans_adopted_resume_record_from_numeric_shorthand(self):
        manifest = launcher.Manifest(
            sessions=[],
            dir_aliases={"/Users/runner/wrk/demo-app": "meta"},
        )
        args = types.SimpleNamespace(harness="codex", name="2", model=None, teams=False)

        record, native_query = launcher.make_adopted_resume_record(
            args,
            manifest,
            cwd="/Users/runner/wrk/demo-app",
            occupied_names=set(),
        )

        self.assertEqual(record.name, "meta/codex-2")
        self.assertIsNone(record.tag)
        self.assertEqual(record.index, 2)
        self.assertIsNone(native_query)

    def test_plans_alias_dir_session_renames_without_unique_records(self):
        sessions = [
            launcher.SessionRecord(
                name="AESOP-Improvements-claude-planner-0",
                harness="claude",
                cwd="/repo/trees/AESOP-Improvements",
                base="AESOP-Improvements",
                tag="planner",
                index=0,
            ),
            launcher.SessionRecord(
                name="demo-ws",
                harness="codex",
                cwd="/repo/trees/AESOP-Improvements",
                base="AESOP-Improvements",
                index=None,
            ),
        ]

        renames = launcher.plan_dir_alias_renames(
            sessions,
            cwd="/repo/trees/AESOP-Improvements",
            alias="aesop",
            existing_names=set(),
        )

        self.assertEqual(renames, {"AESOP-Improvements-claude-planner-0": "aesop/planner"})

    def test_plans_external_tmux_or_tap_renames_for_launcher_shaped_names(self):
        renames = launcher.plan_name_alias_renames(
            names={"sample-app-config-claude-0", "sample-app-config-codex-planner-1", "demo-ws"},
            bases={"sample-app-config"},
            alias="sac",
            existing_names=set(),
        )

        self.assertEqual(
            renames,
            {
                "sample-app-config-claude-0": "sac/claude",
                "sample-app-config-codex-planner-1": "sac/planner",
            },
        )

    def test_plans_external_renames_from_previous_compact_harness_codes(self):
        renames = launcher.plan_name_alias_renames(
            names={"sample-app-config-cx-planner-1"},
            bases={"sample-app-config"},
            alias="sac",
            existing_names=set(),
        )

        self.assertEqual(renames, {"sample-app-config-cx-planner-1": "sac/planner"})

    def test_resume_all_resumes_stopped_sessions_detached_and_taps_in_pending_seat(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "pending",
                        "delivery": "pane",
                        "session": "repo/scout",
                        "harness": "claude",
                    },
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[
                        launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1),
                        launcher.SessionRecord(name="repo/live", harness="codex", cwd=str(root), base="repo", tag="live", index=1),
                    ],
                ),
            )
            args = types.SimpleNamespace(
                manifest=str(manifest),
                key=None,
                legacy_name=None,
                all=True,
                model=None,
                teams=False,
                dry_run=False,
            )
            launched = []
            old_cwd = pathlib.Path.cwd()
            original_tmux_sessions = launcher.tmux_sessions
            original_run_detached = launcher.run_record_detached
            original_tmux_session_pane = launcher.tmux_session_pane
            try:
                os.chdir(root)
                launcher.tmux_sessions = lambda: {"repo/live"}
                launcher.run_record_detached = lambda action, record, dry_run: launched.append((action, record.name, dry_run)) or complete_mock_launch(record)
                launcher.tmux_session_pane = lambda record: launcher.PaneFacts(
                    pane="repo/scout:0.0",
                    pane_id="%42",
                    command="claude",
                    path=str(root),
                )

                rc = launcher.cmd_resume(args)
            finally:
                launcher.tmux_sessions = original_tmux_sessions
                launcher.run_record_detached = original_run_detached
                launcher.tmux_session_pane = original_tmux_session_pane
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(launched, [("resume", "repo/scout", False)])
            entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual((entry["status"], entry["status_reason"]), ("active", ""))
            self.assertNotIn("launch_id", entry)

    def test_resume_all_dry_run_does_not_repair_or_mutate_registry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "pending",
                        "delivery": "pane",
                        "session": "repo/scout",
                        "harness": "claude",
                    },
                },
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1)],
                ),
            )
            before = json.loads(registry.read_text())
            args = types.SimpleNamespace(
                manifest=str(manifest),
                key=None,
                legacy_name=None,
                all=True,
                model=None,
                teams=False,
                dry_run=True,
            )
            launched = []
            old_cwd = pathlib.Path.cwd()
            original_tmux_sessions = launcher.tmux_sessions
            original_run_detached = launcher.run_record_detached
            original_tmux_session_pane = launcher.tmux_session_pane
            try:
                os.chdir(root)
                launcher.tmux_sessions = lambda: set()
                launcher.run_record_detached = lambda action, record, dry_run: launched.append((action, record.name, dry_run)) or 0
                launcher.tmux_session_pane = lambda _record: (_ for _ in ()).throw(AssertionError("dry-run should not inspect a recreated pane"))

                rc = launcher.cmd_resume(args)
            finally:
                launcher.tmux_sessions = original_tmux_sessions
                launcher.run_record_detached = original_run_detached
                launcher.tmux_session_pane = original_tmux_session_pane
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(launched, [("resume", "repo/scout", True)])
            self.assertEqual(json.loads(registry.read_text()), before)

    def test_tmux_session_pane_targets_session_active_pane(self):
        calls = []

        def fake_run(argv, **_kwargs):
            calls.append(argv)
            return types.SimpleNamespace(
                returncode=0,
                stdout="repo/scout:1.1\t%42\tclaude\t222:2000\t0\t4242\t/tmp/repo\n",
            )

        record = launcher.SessionRecord(name="repo/scout", harness="claude", cwd="/tmp/repo", base="repo", tag="scout", index=1)
        with mock.patch.object(launcher.subprocess, "run", fake_run):
            facts = launcher.tmux_session_pane(record)

        self.assertEqual(facts.pane, "repo/scout:1.1")
        self.assertEqual(calls[0][4], "=repo/scout")

    def test_tmux_session_panes_lists_the_whole_session(self):
        calls = []

        def fake_run(argv, **_kwargs):
            calls.append(argv)
            return types.SimpleNamespace(
                returncode=0,
                stdout="repo/scout:0.0\t%41\tzsh\t222:2000\t0\t4241\t/tmp/repo\n"
                       "repo/scout:1.1\t%42\tclaude\t222:2000\t0\t4242\t/tmp/repo\n",
            )

        record = launcher.SessionRecord(name="repo/scout", harness="claude", cwd="/tmp/repo", base="repo", tag="scout", index=1)
        with mock.patch.object(launcher.subprocess, "run", fake_run):
            panes = launcher.tmux_session_panes(record)

        self.assertEqual([pane.pane for pane in panes], ["repo/scout:0.0", "repo/scout:1.1"])
        self.assertIn("-s", calls[0])
        self.assertIn("=repo/scout", calls[0])

    def test_session_seat_states_includes_legacy_pane_rows_without_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {"status": "active", "session": "repo/scout", "harness": "claude"},
                    "helper": {
                        "status": "active",
                        "harness": "codex",
                        "pane": "repo/scout:0.1",
                        "pane_id": "%202",
                    },
                },
            }) + "\n")
            record = launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1)

            def fake_pane_facts(target):
                if target == "%202":
                    return launcher.PaneFacts("repo/scout:0.1", "%202", "codex", str(root))
                return None

            def fake_state(_cwd, handle):
                return {"scout": "idle", "helper": "working"}[handle]

            with mock.patch.object(launcher, "tmux_pane_facts", fake_pane_facts), mock.patch.object(
                launcher, "seat_state_for_handle", fake_state
            ):
                states = launcher.session_seat_states(record)

            self.assertEqual(states, {"scout": "idle", "helper": "working"})

    def test_resume_all_stamps_each_record_after_its_launch_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[
                        launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1),
                        launcher.SessionRecord(name="repo/planner", harness="claude", cwd=str(root), base="repo", tag="planner", index=1),
                    ],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key=None, legacy_name=None, all=True, model=None, teams=False, dry_run=False)
            launched = []

            def fake_run(_action, record, _dry_run):
                launched.append(record.name)
                return 9 if record.name == "repo/planner" else complete_mock_launch(record)

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", lambda: set()), mock.patch.object(
                    launcher, "run_record_detached", fake_run
                ), mock.patch.object(launcher, "current_timestamp", lambda: "2026-07-09T13:30:00Z"
                ):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            # tap-7r3fn.23: the verb's exit is the cohort outcome (1 when any
            # seat failed), no longer the first failed seat's own rc — that 9
            # now feeds the per-seat reason line instead.
            self.assertEqual(rc, 1)
            self.assertEqual(launched, ["repo/scout", "repo/planner"])
            saved = {record.name: record for record in load_registry_state(manifest).sessions}
            self.assertEqual(saved["repo/scout"].last_launched, "2026-07-09T13:30:00Z")
            planner = json.loads((root / ".tap" / "bus" / "registry.json").read_text())["agents"]["planner"]
            self.assertEqual(planner["status"], "suspended")
            self.assertEqual(planner["status_reason"], "repair_failed")
            self.assertNotIn("last_launched", planner)

    def test_resume_all_rolls_back_each_failed_seat_and_keeps_the_cohort(self):
        # tap-7r3fn.23: a failed seat rolls back its own launch transaction
        # (suspended/repair_failed) and the verb moves on to the rest of the
        # cohort instead of aborting; the summary reports the failure and the
        # exit is non-zero.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "active",
                        "delivery": "pane",
                        "session": "repo/scout",
                        "harness": "claude",
                        "pane": "repo/scout:0.0",
                        "pane_id": "%201",
                    },
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[
                        launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1),
                        launcher.SessionRecord(name="repo/planner", harness="codex", cwd=str(root), base="repo", tag="planner", index=1),
                    ],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key=None, legacy_name=None, all=True, model=None, teams=False, dry_run=False, json=False)
            launched = []
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", lambda: set()), mock.patch.object(
                    launcher, "run_record_detached", lambda _action, record, _dry_run: launched.append(record.name) or 2
                ):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(launched, ["repo/scout", "repo/planner"])
            self.assertEqual(rc, 1)
            entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(entry["status"], "suspended")
            self.assertEqual(entry["status_reason"], "repair_failed")

    def test_launch_collision_r_with_no_record_never_reenters_the_menu(self):
        # tap-7r3fn.24: a live tmux session sits in the seat's name, the roster
        # row is suspended with no pane (the post-restart shape), and no
        # manifest record backs a resume. The chooser's [r] delegates to
        # cmd_resume, whose create-fallback re-enters cmd_new and re-prints
        # this same menu — an unescapable dialog. Byte sequence pinned
        # ([b"r", b"q"]): today the second menu quits via q (count 2); after
        # the fix the create-fallback starts the fresh session instead of
        # re-prompting, the second byte is never consumed, and the menu prints
        # exactly once with an honest [r] gloss.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                # Ops's looping seat: the tmux session exists (left behind by
                # the failed respawn) but NO launcher/registry record backs it
                # — nothing to resume from, nothing seated. The pane's failed
                # state classifies busy, so the chooser takes the generic
                # live_or_seated arm and renders the bare "already exists"
                # menu, whose [r] delegates to cmd_resume recordless.
                "agents": {},
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]),
            )
            args = types.SimpleNamespace(
                harness="claude", label=None, tag="scout", unique=None,
                model=None, teams=False, dry_run=False,
            )
            fresh_sentinel = []
            out = TtyBuffer(tty=True)
            err = TtyBuffer(tty=True)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                # tmux_has stays with conftest (targeted probes answer
                # absent): at resume time the bare tag backs nothing, so
                # cmd_resume falls through to the create-fallback.
                with mock.patch.object(launcher, "tmux_sessions", lambda: {"repo/scout"}), \
                     mock.patch.object(launcher, "classify_session", lambda _name: "busy"), \
                     mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
                     mock.patch.object(launcher.termios, "tcsetattr"), \
                     mock.patch.object(launcher.tty, "setcbreak"), \
                     mock.patch.object(launcher.os, "read", new=patched_menu_reader([b"r", b"q"])), \
                     mock.patch.object(launcher, "execute_fresh_launch",
                                       side_effect=lambda record, _args, **_kw:
                                           fresh_sentinel.append(record) or 0), \
                     mock.patch.object(sys, "stdin", TtyBuffer("y\n", tty=True)), \
                     mock.patch.object(sys, "stdout", out), \
                     mock.patch.object(sys, "stderr", err):
                    with self.assertRaises(SystemExit) as raised:
                        launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            # The menu marker is the Choice line: identical whichever question
            # shape the chooser rendered (state_desc varies by state).
            self.assertEqual(err.getvalue().count("Choice [r] (Esc quits)"), 1)
            # [r]'s gloss must say what it will DO when no record backs it.
            self.assertIn("no conversation to resume", err.getvalue())
            # The create-fallback states the miss in one line, then acts.
            self.assertIn("no claude record", err.getvalue())
            self.assertEqual(len(fresh_sentinel), 1)
            self.assertEqual(fresh_sentinel[0].replaces_session, "repo/scout")
            self.assertTrue(fresh_sentinel[0].kill_backup_required)
            self.assertIsNotNone(fresh_sentinel[0].harness_session_id)
            self.assertEqual(raised.exception.code, 0)

    def test_resume_create_fallback_never_prompts_when_stdout_is_not_a_tty(self):
        # tap-7r3fn.24: the create-fallback gated its prompt on a bare
        # stdin-only isatty — a stdin-PTY/stdout-piped caller (an agent runner)
        # would be asked a question it cannot see. The door now uses the same
        # both-streams predicate the prompts themselves use, so it refuses
        # with the create-it command instead of prompting.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]),
            )
            args = types.SimpleNamespace(
                manifest=str(manifest), key="codex", legacy_name="scout",
                harness="codex", all=False, model=None, teams=False, dry_run=False,
            )
            err = TtyBuffer(tty=True)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
                     mock.patch.object(sys, "stdout", TtyBuffer(tty=False)), \
                     mock.patch.object(sys, "stderr", err):
                    with self.assertRaises(launcher.LauncherError) as raised:
                        launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertIn("create it with", str(raised.exception))
            self.assertNotIn("create a new session named", err.getvalue())

    def test_recordless_resume_refuses_create_when_roster_occupies_the_handle(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]),
            )
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True, exist_ok=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"occupied": {
                    "status": "active", "harness": "codex",
                    "session": "repo/occupied", "pane": "", "pane_id": "",
                }},
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), key="codex", legacy_name="occupied",
                all=False, model=None, teams=False, dry_run=False,
            )
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", return_value=False), \
                     mock.patch.object(
                         launcher, "execute_fresh_launch",
                         side_effect=AssertionError("occupied fallback must not create"),
                     ), self.assertRaises(launcher.LauncherError) as raised:
                    launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            message = str(raised.exception)
            self.assertIn("occupied on the roster", message)
            self.assertIn("[k] fresh replacement", message)
            self.assertIn("[n] suffixed sibling", message)
            self.assertIn("tap session launch codex occupied", message)

    def test_recordless_resume_does_not_treat_expired_reservation_as_occupied(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]),
            )
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True, exist_ok=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"expired": {
                    "status": "active", "status_reason": "launching",
                    "launch_id": "stale-token", "harness": "codex",
                    "session": "repo/expired", "registered_at": "2000-01-01T00:00:00Z",
                }},
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), key="codex", legacy_name="expired",
                harness="codex", all=False, model=None, teams=False, dry_run=False,
            )
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions_or_none", return_value=set()), \
                     mock.patch.object(launcher, "caller_has_tty", return_value=False), \
                     self.assertRaises(launcher.LauncherError) as raised:
                    launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            message = str(raised.exception)
            self.assertNotIn("occupied on the roster", message)
            self.assertIn("create it with tap session launch codex expired", message)

    def _resume_all_cohort_args(self, manifest, dry_run=False):
        return types.SimpleNamespace(
            manifest=str(manifest),
            key=None,
            legacy_name=None,
            all=True,
            model=None,
            teams=False,
            dry_run=dry_run,
            json=False,
        )

    def _resume_all_three_seat_manifest(self, root, manifest):
        registry = root / ".tap" / "bus" / "registry.json"
        registry.parent.mkdir(parents=True, exist_ok=True)
        registry.write_text(json.dumps({
            "team": {"name": "repo", "worktree_root": str(root)},
            "agents": {},
        }) + "\n")
        save_registry_state(
            manifest,
            launcher.Manifest(
                dir_aliases={str(root): "repo"},
                sessions=[
                    launcher.SessionRecord(name=f"repo/seat{n}", harness="codex", cwd=str(root), base="repo", tag=f"seat{n}", index=n)
                    for n in (1, 2, 3)
                ],
            ),
        )
        return registry

    def test_resume_all_continues_cohort_after_one_seat_fails(self):
        # tap-7r3fn.23: one seat's failed resume must not abort the cohort.
        # The remaining seats still resume, a terminal summary names the failed
        # seat WITH its reason, and a non-tty caller gets the per-seat manual
        # command instead of a prompt.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            self._resume_all_three_seat_manifest(root, manifest)
            args = self._resume_all_cohort_args(manifest)
            attempted = []

            def fake_run(action, record, dry_run, **_kwargs):
                attempted.append(record.name)
                if record.name == "repo/seat2":
                    return 2
                return complete_mock_launch(record)

            out = TtyBuffer(tty=False)
            err = TtyBuffer(tty=False)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                     mock.patch.object(launcher, "run_record_detached", side_effect=fake_run), \
                     mock.patch.object(sys, "stdout", out), \
                     mock.patch.object(sys, "stderr", err), \
                     mock.patch.object(sys, "stdin", TtyBuffer(tty=False)):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(attempted, ["repo/seat1", "repo/seat2", "repo/seat3"])
            self.assertNotEqual(rc, 0)
            self.assertIn("repo/seat2", out.getvalue())
            self.assertIn("exit 2", out.getvalue())
            self.assertIn("tap session resume codex seat2", out.getvalue())
            # Non-tty: no prompt. prompt_yes_no would refuse one on this stdin,
            # so its question text must never print.
            self.assertNotIn("manually?", err.getvalue())
            self.assertNotIn("manually?", out.getvalue())

    def test_resume_all_names_tmux_error_reason_and_keeps_cohort_alive(self):
        # tap-7r3fn.23, the shape Ops actually hit: tmux's respawn-pane ENXIO
        # raises CalledProcessError through check=True, and run_record_detached
        # propagates it into the cohort loop. Today that re-raises out of the
        # loop to the top-level handler and kills the rest of the cohort; it
        # must be caught per seat like any other failure.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            self._resume_all_three_seat_manifest(root, manifest)
            args = self._resume_all_cohort_args(manifest)
            attempted = []

            def respawn_enxio(action, record, dry_run, **_kwargs):
                attempted.append(record.name)
                if record.name == "repo/seat2":
                    raise subprocess.CalledProcessError(
                        1, ["tmux", "respawn-pane", "-k", "-t", "repo/seat2:0.0"]
                    )
                return complete_mock_launch(record)

            out = TtyBuffer(tty=False)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                     mock.patch.object(launcher, "run_record_detached", side_effect=respawn_enxio), \
                     mock.patch.object(sys, "stdout", out):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(attempted, ["repo/seat1", "repo/seat2", "repo/seat3"])
            self.assertNotEqual(rc, 0)
            self.assertIn("repo/seat2", out.getvalue())
            self.assertIn("tmux", out.getvalue().lower())

    def test_resume_all_offers_fresh_start_once_and_y_launches_fresh_per_failed_seat(self):
        # tap-7r3fn.23: with a tty, the terminal summary offers a fresh start
        # exactly once; Y runs the fresh path for each listed seat only.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            self._resume_all_three_seat_manifest(root, manifest)
            args = self._resume_all_cohort_args(manifest)

            def fake_run(action, record, dry_run, **_kwargs):
                if record.name == "repo/seat2":
                    return 2
                return complete_mock_launch(record)

            fresh_calls = []
            out = TtyBuffer(tty=True)
            err = TtyBuffer(tty=True)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                     mock.patch.object(launcher, "run_record_detached", side_effect=fake_run), \
                     mock.patch.object(launcher, "resume_failed_seats_fresh",
                                       side_effect=lambda records, _args: fresh_calls.extend(r.tag for r in records) or 0), \
                     mock.patch.object(sys, "stdout", out), \
                     mock.patch.object(sys, "stderr", err), \
                     mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
                     mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
                     mock.patch.object(launcher.termios, "tcsetattr"), \
                     mock.patch.object(launcher.tty, "setcbreak"), \
                     mock.patch.object(launcher.os, "read", new=patched_menu_reader([b"y"])):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(err.getvalue().count("tap team up: start a new session and resume manually? [Y/n] "), 1)
            self.assertEqual(fresh_calls, ["seat2"])
            self.assertEqual(rc, 0)

    def test_resume_all_prompt_answer_n_leaves_seats_and_stays_nonzero(self):
        # tap-7r3fn.23: N at the fresh-start offer leaves the failed seats as
        # they are (manual commands already printed) and the verb still exits
        # non-zero.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            self._resume_all_three_seat_manifest(root, manifest)
            args = self._resume_all_cohort_args(manifest)

            def fake_run(action, record, dry_run, **_kwargs):
                if record.name == "repo/seat2":
                    return 2
                return complete_mock_launch(record)

            fresh_calls = []
            out = TtyBuffer(tty=True)
            err = TtyBuffer(tty=True)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                     mock.patch.object(launcher, "run_record_detached", side_effect=fake_run), \
                     mock.patch.object(launcher, "resume_failed_seats_fresh",
                                       side_effect=lambda records, _args: fresh_calls.extend(r.tag for r in records) or 0), \
                     mock.patch.object(sys, "stdout", out), \
                     mock.patch.object(sys, "stderr", err), \
                     mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
                     mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
                     mock.patch.object(launcher.termios, "tcsetattr"), \
                     mock.patch.object(launcher.tty, "setcbreak"), \
                     mock.patch.object(launcher.os, "read", new=patched_menu_reader([b"n"])):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(err.getvalue().count("tap team up: start a new session and resume manually? [Y/n] "), 1)
            self.assertEqual(fresh_calls, [])
            self.assertIn("tap session resume codex seat2", out.getvalue())
            self.assertNotEqual(rc, 0)

    def test_resume_all_fresh_start_mints_a_new_claude_session_id(self):
        # tap-7r3fn.24 review HOLD: a cohort fresh-start must not carry the
        # failed seat's old conversation id or launch without an identity
        # expectation. The external launch stays mocked; the real fresh-record
        # construction is the behavior under test.
        old_id = "11111111-1111-4111-8111-111111111111"
        record = launcher.SessionRecord(
            name="repo/seat2",
            harness="claude",
            cwd="/repo",
            base="repo",
            tag="seat2",
            index=2,
            harness_session_id=old_id,
        )
        args = types.SimpleNamespace(dry_run=False)
        fresh_records = []

        with mock.patch.object(
            launcher,
            "execute_fresh_launch",
            side_effect=lambda fresh, _args, **_kwargs: fresh_records.append(fresh) or 0,
        ):
            self.assertEqual(launcher.resume_failed_seats_fresh([record], args), 0)

        self.assertEqual(len(fresh_records), 1)
        self.assertIsNotNone(fresh_records[0].harness_session_id)
        self.assertNotEqual(fresh_records[0].harness_session_id, old_id)

    def test_resume_all_prompt_renders_the_exact_lines_with_one_verb_prefix(self):
        # FIX-AND-SHIP (partner verdict on U3, tap-7r3fn.23): prompt_yes_no
        # supplies its own "tap " prefix, so the verb argument must be the bare
        # "team up". Assert the RENDERED lines — a substring of the question
        # survives any prefix corruption, which is exactly how the doubled
        # "tap tap team up:" rendering passed the first controls.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            self._resume_all_three_seat_manifest(root, manifest)
            args = self._resume_all_cohort_args(manifest)

            def fake_run(action, record, dry_run, **_kwargs):
                if record.name == "repo/seat2":
                    return 2
                return complete_mock_launch(record)

            fresh_calls = []
            out = TtyBuffer(tty=True)
            err = TtyBuffer(tty=True)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                     mock.patch.object(launcher, "run_record_detached", side_effect=fake_run), \
                     mock.patch.object(launcher, "resume_failed_seats_fresh",
                                       side_effect=lambda records, _args: fresh_calls.extend(r.tag for r in records) or 0), \
                     mock.patch.object(sys, "stdout", out), \
                     mock.patch.object(sys, "stderr", err), \
                     mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
                     mock.patch.object(launcher.termios, "tcgetattr", return_value=["state"]), \
                     mock.patch.object(launcher.termios, "tcsetattr"), \
                     mock.patch.object(launcher.tty, "setcbreak"), \
                     mock.patch.object(launcher.os, "read", new=patched_menu_reader([b"x", b"n"])):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertIn("tap team up: start a new session and resume manually? [Y/n] ", err.getvalue())
            self.assertIn("tap team up: choose y or n", err.getvalue())
            self.assertNotIn("tap tap team up", err.getvalue())
            self.assertEqual(fresh_calls, [])
            self.assertNotEqual(rc, 0)

    def test_resume_all_says_a_shared_collision_once_for_the_whole_cohort(self):
        # grok's cohort probe / kimi NIT-2. `resume --all` walks the cohort and re-reads harness
        # policy per seat, so three seats sharing one ambient collision printed three identical
        # lines — read as three problems. apply_launch_env's docstring already promised
        # once-per-COMMAND, so this was the code failing a contract I had written down.
        #
        # This drives the REAL emit_notice and captures stderr on purpose. The unit-level
        # ambient tests patch emit_notice out, so they cannot see de-duplication at all — a
        # detail worth stating, because it is why the dedup went in unpinned the first time and
        # a mutation removing it left the whole suite green.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[
                        launcher.SessionRecord(
                            name=f"repo/seat{n}", harness="codex", cwd=str(root),
                            base="repo", tag=f"seat{n}", index=n,
                            harness_env={"FOO": "declared"},
                        )
                        for n in (1, 2, 3)
                    ],
                ),
            )
            args = types.SimpleNamespace(
                manifest=str(manifest), key=None, legacy_name=None, all=True,
                model=None, teams=False, dry_run=True,
            )
            stderr = io.StringIO()
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.dict(os.environ, {"FOO": "from-shell"}, clear=False), \
                     mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                     mock.patch.object(launcher, "tmux_sessions_for_namespace", lambda: set()), \
                     contextlib.redirect_stderr(stderr):
                    preset_config.reset_notices()
                    launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

        collisions = [
            line for line in stderr.getvalue().splitlines() if "ambient ENV var" in line
        ]
        # Exactly one for three seats. Asserting the COUNT is the whole point — a presence
        # check passes at one, three, or thirty.
        self.assertEqual(len(collisions), 1, stderr.getvalue())
        self.assertIn("FOO", collisions[0])

    def test_resume_all_registers_sessions_without_registry_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[
                        launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1),
                        launcher.SessionRecord(name="repo/planner", harness="codex", cwd=str(root), base="repo", tag="planner", index=1),
                    ],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key=None, legacy_name=None, all=True, model=None, teams=False, dry_run=False)
            launched = []
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", lambda: set()), mock.patch.object(
                    launcher, "run_record_detached", lambda _action, record, _dry_run: launched.append(record.name) or complete_mock_launch(record)
                ), mock.patch.object(launcher, "current_timestamp", lambda: "2026-07-09T15:00:00Z"):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(launched, ["repo/scout", "repo/planner"])
            saved = {record.name: record for record in load_registry_state(manifest).sessions}
            self.assertEqual(saved["repo/scout"].last_launched, "2026-07-09T15:00:00Z")
            self.assertEqual(saved["repo/planner"].last_launched, "2026-07-09T15:00:00Z")

    def test_restart_announces_one_ambient_collision_once(self):
        # sol's P2. `restart` builds the invocation twice — a discarded pre-flight that exists
        # to fail fast, then the real build — so a single collision printed two byte-identical
        # warnings. The unit-level pins could not see it: they call apply_launch_env once, and
        # the sibling restart tests mock run_record_detached away, leaving only the pre-flight.
        # Only the command path with the real second build exercises the duplication, which is
        # why this asserts a COUNT rather than presence.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {"status": "idle", "session": "repo/scout", "harness": "codex", "pane": "repo/scout:0.0", "pane_id": "%201"},
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(
                        name="repo/scout", harness="codex", cwd=str(root), base="repo",
                        tag="scout", index=1, harness_env={"FOO": "declared"},
                    )],
                ),
            )
            args = types.SimpleNamespace(
                manifest=str(manifest), key="scout", model=None, teams=False,
                force=False, dry_run=True,
            )
            notices = []
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.dict(os.environ, {"FOO": "from-shell"}, clear=False), \
                     mock.patch.object(preset_config, "emit_notice", notices.append), \
                     mock.patch.object(launcher, "tmux_has", lambda _name: True), \
                     mock.patch.object(launcher, "seat_state_for_handle", lambda _cwd, _handle: "idle"), \
                     mock.patch.object(launcher, "entry_verified_session_name", return_value="repo/scout"):
                    launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            collisions = [n for n in notices if "ambient ENV var" in n]
            # Exactly one, and it is the right one — a count alone would pass if the pre-flight
            # were silenced by dropping the whole comparison instead of the emission.
            self.assertEqual(
                collisions,
                ["tap session: overriding ambient ENV var FOO with the declared value"],
            )

    def test_restart_relaunch_failure_restores_registry_row_as_suspended(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {"status": "active", "session": "repo/scout", "harness": "claude", "pane": "repo/scout:0.0", "pane_id": "%201"},
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1)],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key="scout", model=None, teams=False, force=False, dry_run=False)
            killed = []
            original_run = launcher.subprocess.run

            def fake_run(argv, **_kwargs):
                if argv[:2] == ["tmux", "kill-session"]:
                    killed.append(argv[-1])
                    return types.SimpleNamespace(returncode=0, stdout="")
                return original_run(argv, **_kwargs)

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", lambda _name: True), mock.patch.object(
                    launcher, "seat_state_for_handle", lambda _cwd, _handle: "idle"
                ), mock.patch.object(launcher, "entry_verified_session_name", return_value="repo/scout"
                ), mock.patch.object(launcher.subprocess, "run", fake_run), mock.patch.object(
                    launcher, "run_record_detached", lambda _action, _record, _dry_run: 9
                ):
                    rc = launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 9)
            self.assertEqual(killed, ["=repo/scout"])
            entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(entry["status"], "suspended")
            self.assertEqual(entry["status_reason"], "restart_failed")
            self.assertNotIn("last_launched", entry)

    def test_restart_aborts_when_seat_is_busy_via_seat_state_for_handle(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {"status": "active", "session": "repo/scout", "harness": "claude", "pane": "repo/scout:0.0", "pane_id": "%201"},
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1)],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key="scout", model=None, teams=False, force=False, dry_run=False)
            killed = []
            original_run = launcher.subprocess.run

            def fake_run(argv, **_kwargs):
                if argv[:2] == ["tmux", "kill-session"]:
                    killed.append(argv[-1])
                    return types.SimpleNamespace(returncode=0, stdout="")
                return original_run(argv, **_kwargs)

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", lambda _name: True), mock.patch.object(
                    launcher, "seat_state_for_handle", lambda _cwd, _handle: "working"
                ), mock.patch.object(launcher, "entry_verified_session_name", return_value="repo/scout"
                ), mock.patch.object(launcher.subprocess, "run", fake_run), mock.patch.object(
                    launcher, "run_record_detached", lambda _action, _record, _dry_run: 9
                ), self.assertRaises(SystemExit) as raised:
                    launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(raised.exception.code, 2)
            self.assertEqual(killed, [])
            self.assertIsNone(load_registry_state(manifest).sessions[0].last_launched)
            entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(entry["status"], "active")

    def test_restart_ready_transaction_does_not_depend_on_repair(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {"status": "active", "session": "repo/scout", "harness": "claude", "pane": "repo/scout:0.0", "pane_id": "%201"},
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1)],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key="scout", model=None, teams=False, force=False, dry_run=False)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", lambda _name: True), mock.patch.object(
                    launcher, "session_seat_states", lambda _record: {"scout": "idle"}, create=True
                ), mock.patch.object(launcher, "entry_verified_session_name", return_value="repo/scout"
                ), mock.patch.object(launcher.subprocess, "run", lambda *_args, **_kwargs: types.SimpleNamespace(returncode=0, stdout="")
                ), mock.patch.object(launcher, "run_record_detached", lambda _action, record, _dry_run: complete_mock_launch(record)
                ):
                    rc = launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(entry["status"], "active")
            self.assertEqual(entry["status_reason"], "")

    def test_restart_continues_when_repair_finds_no_registry_row(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1)],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key="scout", model=None, teams=False, force=False, dry_run=False)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", lambda _name: False), mock.patch.object(
                    launcher, "run_record_detached", lambda _action, record, _dry_run: complete_mock_launch(record)
                ), mock.patch.object(launcher, "emit_inbox_digest", lambda _record: None):
                    rc = launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertIsNotNone(load_registry_state(manifest).sessions[0].last_launched)

    def test_restart_validates_resume_invocation_before_killing_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {"status": "active", "session": "repo/scout", "harness": "codex", "pane": "repo/scout:0.0", "pane_id": "%201"},
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(name="repo/scout", harness="codex", cwd=str(root), base="repo", tag="scout", index=1)],
                ),
            )
            # The subject of this test is the ORDER — validate, then kill — not which
            # validation fires. It used to depend on the teams-on-non-claude guard, which
            # PR2 deletes; a test that leans on one specific guard loses its lever the day
            # that guard is retired. Injecting the refusal at the builder keeps the ordering
            # claim intact no matter which rules exist.
            args = types.SimpleNamespace(manifest=str(manifest), key="scout", model=None, force=True, dry_run=False)
            killed = []

            def fake_run(argv, **_kwargs):
                if argv[:2] == ["tmux", "kill-session"]:
                    killed.append(argv[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", lambda _name: True), mock.patch.object(
                    launcher.subprocess, "run", fake_run
                ), mock.patch.object(
                    # Incidental to the ordering claim and ambient by nature; a pin that
                    # inherits enrollment state is not a pin. (Reapplied after a
                    # shared-tree revert.)
                    launcher, "_refuse_if_flip_authority", lambda *_a, **_k: None
                ), mock.patch.object(
                    # Injected at launch_invocation, NOT at the builder: the builder is
                    # only the first half of invocation validation, and apply_launch_env
                    # — where harness-config refusals now live — runs after it. A lever
                    # at the builder would prove builder-before-kill while leaving the
                    # post-builder half of the claim untested (sol P2).
                    launcher, "launch_invocation",
                    side_effect=launcher.LauncherError("synthetic invocation refusal"),
                ), mock.patch.object(
                    launcher, "run_record_detached", lambda *_args, **_kwargs: (_ for _ in ()).throw(AssertionError("restart should validate before launch"))
                ), self.assertRaises(launcher.LauncherError) as raised:
                    launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertIn("synthetic invocation refusal", str(raised.exception))
            self.assertEqual(killed, [])
            entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(entry["status"], "active")

    def test_restart_refuses_if_any_seat_in_session_is_working(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {"status": "active", "session": "repo/scout", "harness": "claude"},
                    "helper": {"status": "active", "session": "repo/scout", "harness": "codex"},
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1)],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key="scout", model=None, teams=False, force=False, dry_run=False)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", lambda _name: True), mock.patch.object(
                    launcher, "session_seat_states", lambda _record: {"scout": "idle", "helper": "working"}, create=True
                ), mock.patch.object(launcher.subprocess, "run", lambda *_args, **_kwargs: types.SimpleNamespace(returncode=0, stdout="")
                ), mock.patch.object(launcher, "run_record_detached", lambda _action, _record, _dry_run: 0
                ), mock.patch.object(launcher, "emit_inbox_digest", lambda _record: None
                ), self.assertRaises(SystemExit) as raised:
                    launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(raised.exception.code, 2)

    def test_restart_sibling_suspend_failure_does_not_kill_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "active", "session": "repo/scout", "harness": "claude",
                        "pane": "repo/scout:0.0", "pane_id": "%201",
                    },
                    "helper": {
                        "status": "active", "session": "repo/scout", "harness": "codex",
                        "pane": "repo/scout:0.1", "pane_id": "%202",
                    },
                },
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(
                        name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1,
                    )],
                ),
            )
            original_registry = json.loads(registry.read_text())
            args = types.SimpleNamespace(
                manifest=str(manifest), key="scout", model=None, teams=False, force=True, dry_run=False,
            )
            killed = []

            def fake_run(argv, **_kwargs):
                if argv[:2] == ["tmux", "kill-session"]:
                    killed.append(argv[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(launcher, "entry_verified_session_name", return_value="repo/scout"
                ), mock.patch.object(
                    launcher, "suspend_session_registry_members", side_effect=OSError("disk full")
                ):
                    with self.assertRaisesRegex(OSError, "disk full"):
                        launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(killed, [])
            self.assertEqual(json.loads(registry.read_text()), original_registry)

    def test_restart_holds_registry_lock_through_session_kill(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "active", "session": "repo/scout", "harness": "claude",
                        "pane": "repo/scout:0.0", "pane_id": "%201",
                    },
                    "helper": {
                        "status": "active", "session": "repo/scout", "harness": "codex",
                        "pane": "repo/scout:0.1", "pane_id": "%202",
                    },
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(
                        name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1,
                    )],
                ),
            )
            args = types.SimpleNamespace(
                manifest=str(manifest), key="scout", model=None, teams=False, force=True, dry_run=False,
            )
            lock_probe_codes = []
            probe = """import fcntl, sys
handle = open(sys.argv[1], "w")
try:
    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    raise SystemExit(1)
raise SystemExit(0)
"""

            def fake_run(argv, **_kwargs):
                if argv[:2] == ["tmux", "kill-session"]:
                    child = launcher.subprocess.Popen(
                        [launcher.sys.executable, "-c", probe, str(registry) + ".lock"],
                        stdout=launcher.subprocess.DEVNULL,
                        stderr=launcher.subprocess.DEVNULL,
                    )
                    lock_probe_codes.append(child.wait())
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(launcher, "entry_verified_session_name", return_value="repo/scout"
                ), mock.patch.object(
                    launcher, "run_record_detached", side_effect=lambda _action, record, _dry_run: complete_mock_launch(record)
                ), mock.patch.object(launcher, "emit_inbox_digest", return_value=None):
                    rc = launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(lock_probe_codes, [1])

    def test_restart_suspends_other_active_seats_in_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {"status": "active", "session": "repo/scout", "harness": "claude", "pane": "repo/scout:0.0", "pane_id": "%201"},
                    "helper": {"status": "active", "session": "repo/scout", "harness": "codex", "pane": "repo/scout:0.1", "pane_id": "%202"},
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1)],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key="scout", model=None, teams=False, force=True, dry_run=False)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", lambda _name: True), mock.patch.object(
                    launcher.subprocess, "run", lambda *_args, **_kwargs: types.SimpleNamespace(returncode=0, stdout="")
                ), mock.patch.object(launcher, "entry_verified_session_name", return_value="repo/scout"
                ), mock.patch.object(launcher, "run_record_detached", lambda _action, record, _dry_run: complete_mock_launch(record)
                ), mock.patch.object(launcher, "emit_inbox_digest", lambda _record: None):
                    rc = launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            agents = json.loads(registry.read_text())["agents"]
            self.assertEqual(agents["scout"]["status"], "active")
            self.assertEqual(agents["helper"]["status"], "suspended")
            self.assertEqual(agents["helper"]["status_reason"], "session_restarted")

    def test_restart_suspends_legacy_siblings_when_session_is_already_dead(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {"status": "active", "session": "repo/scout", "harness": "claude", "pane": "repo/scout:0.0", "pane_id": "%201"},
                    "helper": {"status": "active", "harness": "codex", "pane": "repo/scout:0.1", "pane_id": "%202"},
                },
            }) + "\n")
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1)],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key="scout", model=None, teams=False, force=False, dry_run=False)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", lambda _name: False), mock.patch.object(
                    launcher, "run_record_detached", lambda _action, record, _dry_run: complete_mock_launch(record)
                ), mock.patch.object(launcher, "emit_inbox_digest", lambda _record: None):
                    rc = launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            agents = json.loads(registry.read_text())["agents"]
            self.assertEqual(agents["scout"]["status"], "active")
            self.assertEqual(agents["helper"]["status"], "suspended")
            self.assertEqual(agents["helper"]["status_reason"], "session_restarted")

    def test_restart_refuses_harness_family_key_with_matching_sessions(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[
                        launcher.SessionRecord(name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout", index=1),
                        launcher.SessionRecord(name="repo/planner", harness="claude", cwd=str(root), base="repo", tag="planner", index=1),
                    ],
                ),
            )
            args = types.SimpleNamespace(manifest=str(manifest), key="claude", model=None, teams=False, force=False, dry_run=False)
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                err = io.StringIO()
                with contextlib.redirect_stderr(err), self.assertRaises(SystemExit) as raised:
                    launcher.cmd_restart(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(raised.exception.code, 2)
            self.assertIn("matches", err.getvalue())
            self.assertIn("repo/scout", err.getvalue())
            self.assertIn("repo/planner", err.getvalue())

    def test_named_resume_reattaches_live_registry_session_before_native_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(
                        name="repo/scout",
                        harness="claude",
                        cwd=str(root),
                        base="repo",
                        tag="scout",
                        index=1,
                        harness_session_id="11111111-1111-4111-8111-111111111111",
                    )],
                ),
            )
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True, exist_ok=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "active", "session": "repo/scout", "harness": "claude",
                        "pane": "repo/scout:9.9", "pane_id": "%201",
                    },
                },
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), key="repo/scout", legacy_name=None,
                all=False, model=None, teams=False, dry_run=False,
            )
            events = []
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", side_effect=lambda name: name == "repo/scout"), mock.patch.object(
                    launcher, "register_resumed_session", side_effect=lambda record: events.append(("register", record.name)) or True
                ), mock.patch.object(
                    launcher, "caller_has_tty", return_value=True
                ), mock.patch.object(
                    launcher, "tmux_attach", side_effect=lambda name: events.append(("attach", name)) or 0
                ), mock.patch.object(
                    launcher, "run_record", side_effect=AssertionError("live resume must not build a native invocation")
                ):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(events, [("register", "repo/scout"), ("attach", "repo/scout")])

    def test_named_resume_reattaches_live_registry_row(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "sol": {
                        "status": "active",
                        "session": "repo/sol",
                        "harness": "codex",
                        "pane": "repo/sol:0.0",
                        "pane_id": "%42",
                    },
                },
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), key="sol", legacy_name=None,
                all=False, model=None, teams=False, dry_run=False,
            )
            events = []
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                # The seat's stored "%42" and its session name are resolved
                # through tmux; left unpinned both go to the developer's live
                # server, so this row's identity would depend on whatever that
                # server happens to hold. Pane ids are handed out in increasing
                # order for a server's lifetime, so "%42" is not reserved --
                # only not allocated yet. These values are what the probes
                # return for an absent pane, which is what this fixture means.
                with mock.patch.object(launcher, "tmux_has", side_effect=lambda name: name == "repo/sol"), mock.patch.object(
                    launcher, "tmux_pane_facts", return_value=None
                ), mock.patch.object(
                    launcher, "classify_session", return_value="unknown"
                ), mock.patch.object(
                    launcher, "register_resumed_session", side_effect=lambda record: events.append(("register", record.name, record.harness)) or True
                ), mock.patch.object(
                    launcher, "caller_has_tty", return_value=True
                ), mock.patch.object(
                    launcher, "tmux_attach", side_effect=lambda name: events.append(("attach", name)) or 0
                ):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(events, [("register", "repo/sol", "codex"), ("attach", "repo/sol")])
            self.assertEqual(
                [(record.name, record.harness) for record in load_registry_state(manifest).sessions],
                [("repo/sol", "codex")],
            )

    def test_named_resume_refuses_untracked_live_agent_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(manifest, launcher.Manifest(dir_aliases={str(root.resolve()): "repo"}, sessions=[]))
            args = types.SimpleNamespace(
                manifest=str(manifest), key="repo/fable", legacy_name=None,
                all=False, model=None, teams=False, dry_run=False,
            )
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", side_effect=lambda name: name == "repo/fable"), mock.patch.object(
                    launcher, "tmux_session_pane", return_value=launcher.PaneFacts("repo/fable:0.0", "%42", "claude", str(root))
                ), mock.patch.object(launcher, "pane_harness", return_value="claude"), mock.patch.object(
                    launcher, "register_resumed_session"
                ) as register, mock.patch.object(launcher, "tmux_attach", return_value=0) as attach, \
                     self.assertRaises(launcher.LauncherError) as raised:
                    launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertIn("not a relaunchable current seat", str(raised.exception))
            register.assert_not_called()
            attach.assert_not_called()

    def test_named_resume_refuses_untracked_live_non_agent_session(self):
        # WAVE 6.13: first-bad pinned at 0dc9693b (PASS @ 0a594966) — membership
        # gate replaces the older rc=2 refusal with LauncherError + relaunchable message.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(manifest, launcher.Manifest(dir_aliases={str(root.resolve()): "repo"}, sessions=[]))
            args = types.SimpleNamespace(
                manifest=str(manifest), key="repo/mystery", legacy_name=None,
                all=False, model=None, teams=False, dry_run=False,
            )
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", side_effect=lambda name: name == "repo/mystery"), mock.patch.object(
                    launcher, "tmux_session_pane", return_value=launcher.PaneFacts("repo/mystery:0.0", "%42", "zsh", str(root))
                ), mock.patch.object(launcher, "pane_harness", return_value="zsh"), mock.patch.object(
                    launcher, "tmux_attach", return_value=0
                ) as attach, self.assertRaises(launcher.LauncherError) as raised:
                    launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertIn("no relaunchable acting-registry seat", str(raised.exception))
            self.assertIn("repo/mystery", str(raised.exception))
            attach.assert_not_called()

    def test_two_argument_resume_refuses_untracked_live_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(manifest, launcher.Manifest(dir_aliases={str(root.resolve()): "repo"}, sessions=[]))
            args = types.SimpleNamespace(
                manifest=str(manifest), key="claude", legacy_name="ghost",
                all=False, model=None, teams=False, dry_run=False,
            )
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(
                    launcher, "tmux_has", side_effect=lambda name: name == "repo-claude-ghost"
                ), mock.patch.object(
                    launcher, "tmux_session_pane", return_value=launcher.PaneFacts("repo-claude-ghost:0.0", "%42", "claude", str(root))
                ), mock.patch.object(launcher, "pane_harness", return_value="claude"), mock.patch.object(
                    launcher, "register_resumed_session"
                ) as register, mock.patch.object(launcher, "tmux_attach", return_value=0) as attach, \
                     self.assertRaises(launcher.LauncherError) as raised:
                    launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertIn("not a relaunchable current seat", str(raised.exception))
            register.assert_not_called()
            attach.assert_not_called()

    def test_named_resume_recreates_dead_recordless_registry_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "grok": {
                        "status": "active",
                        "session": "repo/grok",
                        "harness": "cursor",
                        "pane": "repo/grok:0.0",
                        "pane_id": "%201",
                    },
                },
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), key="grok", legacy_name=None,
                all=False, model=None, teams=False, dry_run=False,
            )
            events = []
            err = io.StringIO()
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with contextlib.redirect_stderr(err), mock.patch.object(launcher, "tmux_has", return_value=False), mock.patch.object(
                    launcher, "run_record_detached", side_effect=lambda action, record, dry_run: events.append(("resume", record.name, record.harness, dry_run)) or complete_mock_launch(record)
                ), mock.patch.object(
                    launcher, "caller_has_tty", return_value=True
                ), mock.patch.object(
                    launcher, "tmux_attach", side_effect=lambda name: events.append(("attach", name)) or 0
                ):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(events, [
                ("resume", "repo/grok", "cursor", False),
                ("attach", "repo/grok"),
            ])
            self.assertIn("native picker", err.getvalue())
            saved = load_registry_state(manifest).sessions
            self.assertEqual([(record.name, record.harness) for record in saved], [("repo/grok", "cursor")])

    def test_named_resume_recreates_dead_session_repairs_then_attaches(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(
                        name="repo/sol",
                        harness="codex",
                        cwd=str(root),
                        base="repo",
                        tag="sol",
                        index=1,
                        harness_session_id="019a1111-2222-7333-8444-555555555555",
                    )],
                ),
            )
            args = types.SimpleNamespace(
                manifest=str(manifest), key="sol", legacy_name=None,
                all=False, model=None, teams=False, dry_run=False,
            )
            events = []
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", return_value=False), mock.patch.object(
                    launcher, "run_record_detached", side_effect=lambda action, record, dry_run: events.append(("resume", record.name, record.harness_session_id, dry_run)) or complete_mock_launch(record)
                ), mock.patch.object(
                    launcher, "caller_has_tty", return_value=True
                ), mock.patch.object(
                    launcher, "tmux_attach", side_effect=lambda name: events.append(("attach", name)) or 0
                ), mock.patch.object(
                    launcher, "run_record", side_effect=AssertionError("dead resume must repair before attach")
                ):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(events, [
                ("resume", "repo/sol", "019a1111-2222-7333-8444-555555555555", False),
                ("attach", "repo/sol"),
            ])

    def test_named_resume_warns_when_dead_record_falls_back_to_native_picker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(
                        name="repo/scout", harness="claude", cwd=str(root),
                        base="repo", tag="scout", index=1,
                    )],
                ),
            )
            args = types.SimpleNamespace(
                manifest=str(manifest), key="scout", legacy_name=None,
                all=False, model=None, teams=False, dry_run=False,
            )
            err = io.StringIO()
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with contextlib.redirect_stderr(err), mock.patch.object(launcher, "tmux_has", return_value=False), mock.patch.object(
                    launcher, "run_record_detached", return_value=0
                ), mock.patch.object(
                    launcher, "register_resumed_session", return_value=True
                ), mock.patch.object(launcher, "tmux_attach", return_value=0):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertIn("WARNING", err.getvalue())
            self.assertIn("native picker", err.getvalue())
            self.assertIn("repo/scout", err.getvalue())

    def test_resume_no_roster_row_offers_departed_history_restore(self):
        """U5: tap session resume <handle> with no active/gone row is the sole
        sanctioned restore offer — names team-history count and restore next."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            hist = root / ".tap" / "team-history"
            hist.mkdir(parents=True)
            tomb = {
                "handle": "opus",
                "instance": "opus|abc123def456",
                "retired_at": "2026-07-30T12:00:00Z",
                "retired_by": "out-1",
            }
            (hist / "opus.out-1.20260730T120000Z.json").write_text(json.dumps(tomb) + "\n")
            manifest = root / "sessions.json"
            save_registry_state(manifest, launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]))
            args = types.SimpleNamespace(
                manifest=str(manifest), key="opus", legacy_name=None,
                all=False, model=None, teams=False, dry_run=False,
            )
            err = io.StringIO()
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with contextlib.redirect_stderr(err), \
                     mock.patch.object(launcher, "_refuse_if_flip_authority", return_value=None), \
                     mock.patch.object(launcher, "refuse_if_team_reset_fenced", return_value=None), \
                     mock.patch.object(launcher, "_reset_fence_entry_barrier", return_value=None), \
                     mock.patch.object(launcher, "tap_handles", return_value=set()), \
                     mock.patch.object(launcher, "registry_entry", return_value=None), \
                     mock.patch.object(launcher, "caller_has_tty", return_value=False), \
                     self.assertRaises(launcher.LauncherError) as raised:
                    launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)
            msg = str(raised.exception)
            self.assertIn("no active seat named opus", msg)
            self.assertIn("1 departed in team-history", msg)
            self.assertIn("tap in opus --list-history", msg)
            self.assertIn("tap in opus --restore opus|abc123def456", msg)

    def test_named_launch_exists_prompt_passes_incumbent_harness_to_resume_ladder(self):
        args = types.SimpleNamespace(
            manifest="/tmp/sessions.json", harness="claude", unique=None,
            tag=None, label="grok", model=None, teams=False, dry_run=False, fresh=False,
        )
        manifest = launcher.Manifest(dir_aliases={str(pathlib.Path.cwd().resolve()): "repo"}, sessions=[])
        interactive_stdin = mock.Mock()
        interactive_stdin.isatty.return_value = True
        captured = []
        with mock.patch.object(launcher, "tmux_sessions", return_value=set()), mock.patch.object(
            launcher, "tap_handles", return_value={"grok"}
        ), mock.patch.object(
            launcher, "registry_entry", return_value={"status": "active", "harness": "cursor", "session": "repo/grok"}
        ), mock.patch.object(
            launcher, "cmd_resume", side_effect=lambda resume_args: captured.append(resume_args) or 0
        ), mock.patch.object(launcher, "caller_has_tty", return_value=True), mock.patch.object(launcher.sys, "stdin", interactive_stdin), mock.patch.object(
            launcher, "prompt_choice", return_value="r"
        ) as prompt, self.assertRaises(SystemExit) as raised:
            launcher.make_new_record(args, manifest)

        self.assertEqual(raised.exception.code, 0)
        self.assertEqual(len(captured), 1)
        self.assertEqual((captured[0].key, captured[0].legacy_name, captured[0].harness), ("cursor", "grok", "cursor"))
        prompt.assert_called_once_with(
            "session", "'repo/grok' already exists (cursor)",
            # tap-7r3fn.24: manifest-recordless seat — the [r] gloss says what
            # r will actually do (fresh), not a reattach it cannot deliver.
            (("r", "resume", "no conversation to resume — start a fresh session under this name"),
             ("n", "new", "Start another session with a suffix"),
             ("k", "fresh", "Stop the session and start over"), ("q", "quit", "Leave everything unchanged")), "r",
        )

    def test_chooser_resume_live_idless_opencode_reattaches_instead_of_session_exists(self):
        """tap-ici: collision [r] on a live id-less opencode seat must reattach, not dead-end."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(
                        name="repo/glm-b", harness="opencode", cwd=str(root),
                        base="repo", tag="glm-b", index=1, harness_session_id=None,
                    )],
                ),
            )
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "glm-b": {
                        "status": "active", "session": "repo/glm-b", "harness": "opencode",
                        "pane": "repo/glm-b:0.0", "pane_id": "%215",
                    },
                },
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="opencode", unique=None,
                tag=None, label="glm-b", model=None, teams=False, dry_run=False, fresh=False,
            )
            captured = []
            interactive_stdin = mock.Mock()
            interactive_stdin.isatty.return_value = True
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/glm-b"}), mock.patch.object(
                    launcher, "tmux_has", side_effect=lambda name: name == "repo/glm-b"
                ), mock.patch.object(
                    launcher, "classify_session", return_value="live",
                ), mock.patch.object(
                    launcher, "tap_handles", return_value={"glm-b"},
                ), mock.patch.object(
                    launcher, "registry_entry", return_value={
                        "status": "active", "session": "repo/glm-b", "harness": "opencode",
                        "pane": "repo/glm-b:0.0", "pane_id": "%215",
                    },
                ), mock.patch.object(
                    launcher, "resolve_base_alias", return_value="repo",
                ), mock.patch.object(
                    launcher, "cmd_resume",
                    side_effect=lambda resume_args: captured.append(resume_args) or 0,
                ), mock.patch.object(
                    launcher, "caller_has_tty", return_value=True,
                ), mock.patch.object(launcher.sys, "stdin", interactive_stdin), mock.patch.object(
                    launcher, "prompt_choice", return_value="r"
                ), self.assertRaises(SystemExit) as raised:
                    launcher.make_new_record(args, load_registry_state(manifest))
            finally:
                os.chdir(old_cwd)

            self.assertEqual(raised.exception.code, 0)
            self.assertEqual(len(captured), 1)
            self.assertEqual(
                (captured[0].key, captured[0].legacy_name, captured[0].harness),
                ("opencode", "glm-b", "opencode"),
            )

    def test_ensure_ladder_off_roster_poisoned_record_creates_fresh_without_reviving(self):
        """U5: a poisoned duplicate native id on an off-roster leftover record is
        ignored by launch (create-intent) — the uniqueness refuse stays on resume.
        """
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = launcher.Manifest(
                dir_aliases={str(root): "repo"},
                sessions=[
                    launcher.SessionRecord(
                        name="repo/fable", harness="claude", cwd=str(root),
                        base="repo", tag="fable", index=1, harness_session_id="fable-id",
                    ),
                    launcher.SessionRecord(
                        name="repo/opus", harness="claude", cwd=str(root),
                        base="repo", tag="opus", index=1, harness_session_id="fable-id",
                    ),
                ],
            )
            args = types.SimpleNamespace(
                manifest=str(root / "sessions.json"), harness="claude", unique=None,
                tag=None, label="opus", model=None, teams=False, dry_run=False,
                fresh=False, new=False,
            )
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "record_has_resume_artifact", return_value=True), mock.patch.object(
                    launcher, "tmux_sessions", return_value=set()
                ), mock.patch.object(
                    launcher, "tap_handles", return_value=set()
                ), mock.patch.object(
                    launcher, "registry_entry", return_value=None
                ), mock.patch.object(
                    launcher, "resolve_base_alias", return_value="repo",
                ), contextlib.redirect_stderr(io.StringIO()):
                    record = launcher.make_new_record(args, manifest)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(record.name, "repo/opus")
            self.assertNotEqual(record.harness_session_id, "fable-id")
            self.assertEqual(record.ensure_action, "new")

    def test_ensure_ladder_refuses_identity_held_only_by_another_registry_row(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            registry = root / ".tap" / "team-registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "fable": {
                        "status": "active", "harness": "claude",
                        "harness_session_id": "shared-id",
                    },
                },
            }) + "\n")
            record = launcher.SessionRecord(
                name="repo/opus", harness="claude", cwd=str(root), base="repo",
                tag="opus", index=1, harness_session_id="shared-id",
            )

            with mock.patch.object(launcher, "tap_registry_path", return_value=registry), \
                 self.assertRaises(launcher.LauncherError) as raised:
                launcher.assert_unique_harness_session_identity(
                    [record],
                    record,
                    "tap session resume",
                )

            self.assertIn("expected seat opus", str(raised.exception))
            self.assertIn("expected seat repo/fable", str(raised.exception))

    def test_claim_refuses_same_stored_session_when_pane_verifies_elsewhere(self):
        """tap-ici P1: stored session match must not clobber a pane live in a different session."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "active",
                        "session": "repo/scout",
                        "harness": "opencode",
                        "pane": "repo/other:0.0",
                        "pane_id": "%213",
                    },
                },
            }) + "\n")
            record = launcher.SessionRecord(
                name="repo/scout", harness="opencode", cwd=str(root),
                base="repo", tag="scout", index=1, harness_session_id=None,
            )
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions_or_none", return_value=set()), mock.patch.object(
                    launcher, "entry_verified_session_name", return_value="repo/other"
                ), self.assertRaises(SystemExit) as raised:
                    launcher.claim_pending_handle(record, allow_same_session=True)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(raised.exception.code, 2)
            entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(entry["status"], "active")
            self.assertEqual(entry["session"], "repo/scout")
            self.assertEqual(entry["pane_id"], "%213")
            self.assertNotIn("launch_id", entry)

    def test_named_launch_exists_menu_allocates_next_suffix(self):
        args = types.SimpleNamespace(
            manifest="/tmp/sessions.json", harness="claude", unique=None,
            tag=None, label="grok", model=None, teams=False, dry_run=False, fresh=False,
        )
        manifest = launcher.Manifest(dir_aliases={str(pathlib.Path.cwd().resolve()): "repo"}, sessions=[])
        interactive_stdin = mock.Mock()
        interactive_stdin.isatty.return_value = True
        with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/grok"}), mock.patch.object(
            launcher, "tmux_sessions_or_none", return_value={"repo/grok"}
        ), mock.patch.object(
            launcher, "tap_handles", return_value={"grok"}
        ), mock.patch.object(
            launcher, "registry_entry", return_value={"status": "active", "harness": "cursor", "session": "repo/grok"}
        ), mock.patch.object(launcher, "caller_has_tty", return_value=True), mock.patch.object(launcher.sys, "stdin", interactive_stdin), mock.patch.object(
            launcher, "prompt_choice", return_value="n"
        ):
            record = launcher.make_new_record(args, manifest)

        self.assertEqual(record.name, "repo/grok-2")
        self.assertEqual(launcher.session_handle(record), "grok-2")
        self.assertEqual(record.index, 2)

    def test_named_launch_off_roster_legacy_record_reuses_canonical_handle(self):
        """U5: a leftover legacy-named manifest record with no roster row is not
        a collision — launch creates under the canonical <team>/<handle>."""
        cwd = str(pathlib.Path.cwd().resolve())
        args = types.SimpleNamespace(
            manifest="/tmp/sessions.json", harness="claude", unique=None,
            tag=None, label="grok", model=None, teams=False, dry_run=False, fresh=False,
        )
        manifest = launcher.Manifest(
            dir_aliases={launcher.root_for_cwd(cwd): "repo"},
            sessions=[launcher.SessionRecord(
                name="repo-cursor-grok", harness="cursor", cwd=cwd, base="repo",
                tag="grok", index=1,
            )],
        )
        interactive_stdin = mock.Mock()
        interactive_stdin.isatty.return_value = True
        with mock.patch.object(launcher, "tmux_sessions", return_value=set()), mock.patch.object(
            launcher, "tap_handles", return_value=set()
        ), mock.patch.object(
            launcher, "registry_entry", return_value=None
        ), mock.patch.object(launcher, "caller_has_tty", return_value=True), mock.patch.object(launcher.sys, "stdin", interactive_stdin), mock.patch.object(
            launcher, "prompt_choice",
            side_effect=AssertionError("off-roster leftover must not open a chooser"),
        ), contextlib.redirect_stderr(io.StringIO()):
            record = launcher.make_new_record(args, manifest)

        self.assertEqual(record.name, "repo/grok")
        self.assertEqual(launcher.session_handle(record), "grok")
        self.assertEqual(record.index, 1)

    def test_named_launch_exists_menu_k_marks_the_incumbent_for_replacement(self):
        # RATIFIED case 1 at the chooser (sol, 2026-07-25): the row is unstamped,
        # so its id may not name a target — but its stored session is EXACTLY the
        # canonical name this launch derives for the handle, and that name is
        # live, so [k] may replace the seat's own session by name.
        cwd = str(pathlib.Path.cwd().resolve())
        old_id = "old-native-id"
        manifest = launcher.Manifest(
            dir_aliases={launcher.root_for_cwd(cwd): "repo"},
            sessions=[launcher.SessionRecord(
                name="repo/grok", harness="cursor", cwd=cwd, base="repo",
                tag="grok", index=1, harness_session_id=old_id,
            )],
        )
        args = types.SimpleNamespace(
            manifest="/tmp/sessions.json", harness="claude", unique=None,
            tag=None, label="grok", model=None, teams=False, dry_run=False, fresh=False,
        )
        interactive_stdin = mock.Mock()
        interactive_stdin.isatty.return_value = True
        with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/grok"}), mock.patch.object(
            launcher, "tap_handles", return_value={"grok"}
        ), mock.patch.object(
            launcher, "registry_entry", return_value={
                "status": "active", "harness": "cursor", "session": "repo/grok",
                "pane": "repo/grok:0.0", "pane_id": "%209",
            }
        ), mock.patch.object(
            launcher, "tmux_pane_facts",
            return_value=launcher.PaneFacts("repo/grok:0.0", "%209", "cursor-agent", cwd),
        ), mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
            launcher, "caller_has_tty", return_value=True
        ), mock.patch.object(launcher.sys, "stdin", interactive_stdin), mock.patch.object(
            launcher, "prompt_choice", return_value="k"
        ):
            record = launcher.make_new_record(args, manifest)

        self.assertEqual(record.name, "repo/grok")
        self.assertEqual(record.replaces_session, "repo/grok")
        self.assertEqual(record.history, [old_id])

    def test_named_launch_exists_menu_k_ignores_absent_pane_hint_and_targets_picker_name(self):
        """tap-5ils: [k] kills the canonical picker target even when its row has no pane hint."""
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(
            dir_aliases={launcher.root_for_cwd(cwd): "repo"},
            sessions=[launcher.SessionRecord(
                name="repo/opus", harness="claude", cwd=cwd, base="repo",
                tag="opus", index=1, harness_session_id="old-native-id",
            )],
        )
        args = types.SimpleNamespace(
            manifest="/tmp/sessions.json", harness="claude", unique=None,
            tag=None, label="opus", model=None, teams=False, dry_run=False, fresh=False,
        )
        entry = {
            "status": "suspended", "status_reason": "session_stopped",
            "harness": "claude", "session": "repo/opus",
            "pane": None, "pane_id": None,
        }

        with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/opus"}), mock.patch.object(
            launcher, "tap_handles", return_value={"opus"}
        ), mock.patch.object(
            launcher, "registry_entry", return_value=entry
        ), mock.patch.object(
            launcher, "tmux_pane_facts",
            side_effect=AssertionError("[k] must not inspect a pane identity"),
        ), mock.patch.object(
            launcher, "tmux_has", return_value=True
        ), mock.patch.object(
            launcher, "caller_has_tty", return_value=True
        ), mock.patch.object(
            launcher, "prompt_choice", return_value="k"
        ):
            record = launcher.make_new_record(args, manifest)

        self.assertEqual(record.replaces_session, "repo/opus")
        self.assertEqual(record.history, ["old-native-id"])

    def test_named_launch_exists_menu_k_ignores_foreign_row_stamp_and_targets_picker_name(self):
        # Ops 2026-08-06: [k] targets the canonical name shown by the picker.
        # A stale row stamp neither vetoes the kill nor redirects it elsewhere.
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(
            dir_aliases={launcher.root_for_cwd(cwd): "repo"},
            sessions=[launcher.SessionRecord(
                name="repo/grok", harness="cursor", cwd=cwd, base="repo",
                tag="grok", index=1, harness_session_id="old-native-id",
            )],
        )
        args = types.SimpleNamespace(
            manifest="/tmp/sessions.json", harness="claude", unique=None,
            tag=None, label="grok", model=None, teams=False, dry_run=False, fresh=False,
        )
        interactive_stdin = mock.Mock()
        interactive_stdin.isatty.return_value = True
        with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/grok"}), mock.patch.object(
            launcher, "tap_handles", return_value={"grok"}
        ), mock.patch.object(
            launcher, "registry_entry", return_value={
                "status": "active", "harness": "cursor", "session": "keeper",
                "pane": "keeper:0.0", "pane_id": "%209",
            }
        ), mock.patch.object(
            launcher, "tmux_pane_facts",
            return_value=launcher.PaneFacts("keeper:0.0", "%209", "cursor-agent", cwd),
        ), mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
            launcher, "tmux_session_pane_ids", return_value=["%209"]
        ), mock.patch.object(
            launcher, "caller_has_tty", return_value=True
        ), mock.patch.object(launcher.sys, "stdin", interactive_stdin), mock.patch.object(
            launcher, "prompt_choice", return_value="k"
        ):
            record = launcher.make_new_record(args, manifest)

        self.assertEqual(record.replaces_session, "repo/grok")

    def test_named_launch_exists_menu_q_quits(self):
        args = types.SimpleNamespace(
            manifest="/tmp/sessions.json", harness="claude", unique=None,
            tag=None, label="grok", model=None, teams=False, dry_run=False, fresh=False,
        )
        manifest = launcher.Manifest(dir_aliases={str(pathlib.Path.cwd().resolve()): "repo"}, sessions=[])
        interactive_stdin = mock.Mock()
        interactive_stdin.isatty.return_value = True
        with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/grok"}), mock.patch.object(
            launcher, "tap_handles", return_value={"grok"}
        ), mock.patch.object(
            launcher, "registry_entry", return_value={"status": "active", "harness": "cursor", "session": "repo/grok"}
        ), mock.patch.object(launcher, "caller_has_tty", return_value=True), mock.patch.object(launcher.sys, "stdin", interactive_stdin), mock.patch.object(
            launcher, "prompt_choice", return_value="q"
        ), self.assertRaises(SystemExit) as raised:
            launcher.make_new_record(args, manifest)

        self.assertEqual(raised.exception.code, 2)

    def test_cmd_new_fresh_replaces_live_session_and_carries_registry_history(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old_id = "11111111-1111-4111-8111-111111111111"
            save_registry_state(
                manifest,
                launcher.Manifest(
                    dir_aliases={str(root): "repo"},
                    sessions=[launcher.SessionRecord(
                        name="repo/scout", harness="cursor", cwd=str(root), base="repo",
                        tag="scout", index=1, harness_session_id=old_id, history=["older-id"],
                    )],
                ),
            )
            # Picker [k] (Ops, 2026-08-06) targets the canonical picker name even
            # when the selected row still carries a legacy session name.  The
            # unrelated legacy-session sibling therefore remains untouched.
            payload = json.loads(registry.read_text())
            payload["agents"]["scout"].update({
                "session": "repo/legacy-scout",
                "pane": "repo/legacy-scout:0.0",
                "pane_id": "%201",
                "server_epoch": "srv:7:70",
            })
            payload["agents"]["helper"] = {
                "status": "pending", "session": "repo/legacy-scout", "harness": "codex",
                "registered_at": "2026-07-14T00:00:00Z",
            }
            payload["agents"]["poller"] = {
                "status": "active", "delivery": "poll",
                "session": "repo/legacy-scout", "harness": "hermes",
            }
            registry.write_text(json.dumps(payload) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": "srv:7:70"}), mock.patch.object(
                    launcher, "tmux_sessions", return_value={"repo/legacy-scout"}
                ), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/legacy-scout"}
                ), mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
                    launcher, "tmux_session_pane_ids", return_value=["%201"]
                ), mock.patch.object(
                    launcher, "tmux_pane_facts", return_value=launcher.PaneFacts(
                        # tap-bzyz: a real tmux_pane_facts capture carries the
                        # generation it was taken under on the SAME record, and the
                        # destructive arm now corroborates the row against it. These
                        # fixtures predate the field being load-bearing; stating it is
                        # what a live capture looks like, not a concession to the fix.
                        pane="repo/legacy-scout:0.0", pane_id="%201", command="cursor-agent", path=str(root), server_epoch="srv:7:70"
                    )
                ), mock.patch.object(
                    launcher, "current_boot_id", return_value="boot:test"
                ), mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), mock.patch.object(
                    launcher, "run_record",
                    side_effect=lambda _action, launched, _dry_run, **_kw: complete_mock_launch(launched),
                ), mock.patch.object(launcher, "caller_tty", return_value="/dev/tty"):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(killed, ["=repo/scout"])
            saved = load_registry_state(manifest).sessions
            self.assertEqual([record.name for record in saved], ["repo/scout"])
            self.assertEqual(saved[0].harness, "claude")
            self.assertEqual(saved[0].history, ["older-id", old_id])
            self.assertNotEqual(saved[0].harness_session_id, old_id)
            agents = json.loads(registry.read_text())["agents"]
            self.assertEqual(agents["scout"]["status"], "active")
            self.assertEqual(agents["helper"]["status"], "pending")
            self.assertNotIn("status_reason", agents["helper"])
            self.assertEqual(agents["poller"]["status"], "active")
            self.assertNotIn("status_reason", agents["poller"])

    def test_new_fresh_targets_picker_name_when_registry_points_elsewhere(self):
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(
            dir_aliases={launcher.root_for_cwd(cwd): "repo"},
            sessions=[launcher.SessionRecord(
                name="repo/legacy-scout", harness="cursor", cwd=cwd, base="repo", tag="scout",
            )],
        )
        args = types.SimpleNamespace(
            manifest="/tmp/sessions.json", harness="claude", unique=None,
            tag=None, label="scout", model=None, teams=False, dry_run=False, fresh=True,
        )
        # tap-24f: a DESTRUCTIVE decision may only derive a target from ids it
        # can prove belong to the current server, so "the registry provably
        # points elsewhere" is now expressed as a current server_epoch stamp.
        # The unstamped variant is covered in test_server_epoch.py, where it
        # must refuse EARLIER (it can no longer reach this guard at all).
        entry = {
            "status": "active", "harness": "cursor", "session": "repo/legacy-scout",
            "pane": "repo/legacy-scout:0.0", "pane_id": "%212",
            "server_epoch": "srv:1:1",
        }
        facts = launcher.PaneFacts("repo/legacy-scout:0.0", "%212", "cursor-agent", cwd, server_epoch="srv:1:1")

        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": "srv:1:1"}), mock.patch.object(
            launcher, "tmux_sessions", return_value={"repo/scout", "repo/legacy-scout"}
        ), mock.patch.object(launcher, "tap_handles", return_value={"scout"}), mock.patch.object(
            launcher, "registry_entry", return_value=entry
        ), mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
            launcher, "tmux_session_pane_ids", return_value=["%212"]
        ), mock.patch.object(launcher, "tmux_pane_facts", return_value=facts):
            record = launcher.make_new_record(args, manifest)

        self.assertEqual(record.replaces_session, "repo/scout")

    def test_new_fresh_rejects_unique_exact_name(self):
        args = types.SimpleNamespace(
            manifest="/tmp/sessions.json", harness="claude", unique="global/scout",
            tag=None, label=None, model=None, teams=False, dry_run=False, fresh=True,
        )

        with self.assertRaisesRegex(launcher.LauncherError, "--fresh is not supported with --unique"):
            launcher.make_new_record(args, launcher.Manifest(sessions=[]))

    def test_cmd_new_fresh_failure_restores_complete_incumbent_registry_row(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old_id = "11111111-1111-4111-8111-111111111111"
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo",
                tag="scout", index=1, harness_session_id=old_id, history=["older-id"],
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            payload = json.loads(registry.read_text())
            payload["agents"]["scout"].update({
                "pane": "repo/scout:0.0", "pane_id": "%206",
            })
            registry.write_text(json.dumps(payload) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(
                    launcher.registry_v20, "resolve_team_registry_for_root",
                    return_value=("legacy", str(registry)),
                ), mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
                    launcher, "tmux_pane_facts",
                    return_value=launcher.PaneFacts("repo/scout:0.0", "%206", "cursor-agent", str(root)),
                ), mock.patch.object(
                    launcher, "current_boot_id", return_value="boot:test"
                ), mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), mock.patch.object(
                    launcher, "run_record", return_value=7
                ), mock.patch.object(launcher, "caller_tty", return_value="/dev/tty"), mock.patch.object(
                    launcher, "conversation_artifact_missing", return_value=False
                ):
                    self.assertEqual(launcher.cmd_new(args), 7)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(killed, ["=repo/scout"])
            restored_entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(restored_entry["status"], "suspended")
            self.assertEqual(restored_entry["status_reason"], "session_replaced")
            self.assertEqual(restored_entry["pane_id"], "%206")
            self.assertEqual(restored_entry["harness_session_id"], old_id)
            self.assertEqual(restored_entry["history"], ["older-id"])

    def test_cmd_new_fresh_kills_absent_pane_row_only_after_complete_backup(self):
        """tap-5ils: [k] checkpoints the full seat and launcher record before kill."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/opus", harness="claude", cwd=str(root), base="repo",
                tag="opus", index=1, model="opus[1m]",
                harness_session_id="11111111-1111-4111-8111-111111111111",
                transcript_path="/tmp/opus.jsonl",
                quarantined_harness_session_id="suspect-id",
                quarantined_transcript_path="/tmp/suspect.jsonl",
                identity_quarantine_reason="capture mismatch",
                harness_passthrough=["--permission-mode", "acceptEdits"],
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            payload = json.loads(registry.read_text())
            payload["agents"]["opus"].update({
                "status": "suspended", "status_reason": "session_stopped",
                "session": "repo/opus", "pane": None, "pane_id": None,
                "quarantined_harness_session_id": "suspect-id",
                "quarantined_transcript_path": "/tmp/suspect.jsonl",
                "identity_quarantine_reason": "capture mismatch",
                "passthrough": ["--permission-mode", "acceptEdits"],
            })
            registry.write_text(json.dumps(payload) + "\n")
            original_row = dict(payload["agents"]["opus"])
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None,
                label="opus", model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []
            receipts = io.StringIO()

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(
                    launcher.registry_v20, "resolve_team_registry_for_root",
                    return_value=("legacy", str(registry)),
                ), mock.patch.object(launcher, "tmux_sessions", return_value={"repo/opus"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/opus"}
                ), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(
                    launcher, "current_boot_id", return_value="boot:test"
                ), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(
                    launcher, "run_record", return_value=0
                ), mock.patch.object(
                    launcher, "caller_tty", return_value="/dev/tty"
                ), mock.patch.object(
                    launcher, "conversation_artifact_missing", return_value=False
                ), contextlib.redirect_stdout(receipts):
                    self.assertEqual(launcher.cmd_new(args), 0)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(killed, ["=repo/opus"])
            bundles = list((root / ".tap" / "backup" / "session-kill").glob("*/COMPLETE"))
            self.assertEqual(len(bundles), 1)
            bundle = bundles[0].parent
            row_doc = json.loads((bundle / "registry-row.json").read_text())
            record_doc = json.loads((bundle / "launcher-session-record.json").read_text())
            self.assertEqual(row_doc["agent"], original_row)
            self.assertEqual(record_doc["record"], old.to_dict())
            self.assertNotIn("manifest_path", record_doc)
            self.assertIn(str(bundle), receipts.getvalue())
            self.assertIn(f"tap restore opus --archive {bundle}", receipts.getvalue())

    def test_picker_k_without_seat_row_kills_after_forensic_backup(self):
        """An off-roster canonical collision is killable but not restorable as a seat."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {},
            }) + "\n")
            record = launcher.SessionRecord(
                name="repo/scout", harness="claude", cwd=str(root), base="repo",
                tag="scout", index=1, replaces_session="repo/scout",
                kill_backup_required=True,
            )
            killed = []
            receipts = io.StringIO()

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(
                    launcher.registry_v20, "resolve_team_registry_for_root",
                    return_value=("legacy", str(registry)),
                ), mock.patch.object(
                    launcher, "tmux_sessions", return_value={"repo/scout"}
                ), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(
                    launcher, "tmux_session_created_label", return_value="2026-08-06 23:45:00"
                ), mock.patch.object(
                    launcher, "tmux_session_pane_ids", return_value=["%201", "%202"]
                ), mock.patch.object(
                    launcher, "current_boot_id", return_value="boot:test"
                ), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), contextlib.redirect_stdout(receipts):
                    launcher.prepare_new_launch(record)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(killed, ["=repo/scout"])
            bundle = pathlib.Path(record.kill_backup_path)
            self.assertTrue((bundle / "COMPLETE").is_file())
            self.assertIsNone(json.loads((bundle / "registry-row.json").read_text())["agent"])
            self.assertIsNone(json.loads((bundle / "launcher-session-record.json").read_text())["record"])
            meta = json.loads((bundle / "meta.json").read_text())
            self.assertEqual(meta["state"], {
                "registry_row": "absent",
                "launcher_record": "absent",
                "restore_as_seat": False,
            })
            self.assertEqual(json.loads((bundle / "tmux-forensics.json").read_text()), {
                "captured_at": mock.ANY,
                "created_label": "2026-08-06 23:45:00",
                "pane_ids": ["%201", "%202"],
                "session": "repo/scout",
            })
            receipt = receipts.getvalue()
            self.assertIn("killed repo/scout", receipt)
            self.assertIn("no seat state existed", receipt)
            self.assertIn("restore as a seat is unavailable", receipt)
            self.assertIn(f"forensic backup: {bundle}", receipt)
            self.assertNotIn("tap restore", receipt)

    def test_picker_k_backup_write_failure_aborts_before_registry_or_kill(self):
        """tap-5ils: inability to guarantee a restorable backup is the kill veto."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/opus", harness="claude", cwd=str(root), base="repo",
                tag="opus", index=1, harness_session_id="old-native-id",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            payload = json.loads(registry.read_text())
            payload["agents"]["opus"].update({
                "status": "suspended", "status_reason": "session_stopped",
                "session": "repo/opus", "pane": None, "pane_id": None,
            })
            registry.write_text(json.dumps(payload) + "\n")
            original_registry = registry.read_bytes()
            record = launcher.SessionRecord(
                name="repo/opus", harness="claude", cwd=str(root), base="repo",
                tag="opus", index=1, replaces_session="repo/opus",
                replacement_record=old.to_dict(), kill_backup_required=True,
            )

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(
                    launcher.registry_v20, "resolve_team_registry_for_root",
                    return_value=("legacy", str(registry)),
                ), mock.patch.object(
                    launcher, "_fsync_path", side_effect=OSError("disk full")
                ), mock.patch.object(launcher.subprocess, "run") as run:
                    with self.assertRaisesRegex(launcher.LauncherError, "backup failed.*not killed"):
                        launcher.prepare_new_launch(record)
            finally:
                os.chdir(old_cwd)

            kill_calls = [
                call for call in run.call_args_list
                if call.args and call.args[0][:2] == ["tmux", "kill-session"]
            ]
            self.assertEqual(kill_calls, [])
            self.assertEqual(registry.read_bytes(), original_registry)
            self.assertEqual(
                list((root / ".tap" / "backup" / "session-kill").glob("*/COMPLETE")),
                [],
            )

    def test_cmd_new_fresh_nonzero_exit_keeps_registered_replacement_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo",
                tag="scout", index=1, harness_session_id="old-native-id",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "session": "repo/scout", "harness": "cursor",
                    "pane": "repo/scout:0.0", "pane_id": "%201",
                }},
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            registered_entry = {
                "status": "active", "session": "repo/scout", "harness": "claude",
                "pane": "repo/scout:0.0", "pane_id": "%205",
            }

            def fake_run(command, **_kwargs):
                return types.SimpleNamespace(returncode=0, stdout="")

            def register_then_fail(*_args, **_kwargs):
                payload = json.loads(registry.read_text())
                payload["agents"]["scout"] = registered_entry
                registry.write_text(json.dumps(payload) + "\n")
                return 7

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
                    launcher, "tmux_pane_facts",
                    return_value=launcher.PaneFacts("repo/scout:0.0", "%201", "cursor-agent", str(root)),
                ), mock.patch.object(
                    launcher, "current_boot_id", return_value="boot:test"
                ), mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), mock.patch.object(
                    launcher, "run_record", side_effect=register_then_fail
                ), mock.patch.object(launcher, "caller_tty", return_value="/dev/tty"):
                    self.assertEqual(launcher.cmd_new(args), 7)
            finally:
                os.chdir(old_cwd)

            saved = load_registry_state(manifest).sessions
            self.assertEqual([(record.harness, record.name) for record in saved], [
                ("claude", "repo/scout"),
            ])
            self.assertEqual(json.loads(registry.read_text())["agents"]["scout"], registered_entry)

    def test_cmd_new_fresh_validates_registry_before_killing_incumbent(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"},
                sessions=[launcher.SessionRecord(
                    name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
                )],
            ))
            registry.write_text("{not-json\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(
                    launcher.registry_v20, "resolve_team_registry_for_root",
                    return_value=("legacy", str(registry)),
                ), mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ):
                    with self.assertRaises(launcher.LauncherError):
                        launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(killed, [])

    def test_cmd_new_fresh_ignores_recycled_registry_pane_identity(self):
        # Ops 2026-08-06 supersedes the old refusal: a recycled id and an
        # ambient row.session cannot redirect or veto the canonical [k] target.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "session": "repo/other", "harness": "cursor",
                    "pane": "repo/other:0.0", "pane_id": "%201",
                }},
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []

            def fake_pane_facts(target):
                if target == "%201":
                    return None
                if target == "repo/other:0.0":
                    return launcher.PaneFacts("repo/other:0.0", "%205", "cursor-agent", str(root))
                return None

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/other"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/other"}
                ), mock.patch.object(launcher, "tmux_pane_facts", side_effect=fake_pane_facts), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(launcher, "run_record", return_value=0), mock.patch.object(
                    launcher, "caller_tty", return_value="/dev/tty"
                ):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(killed, ["=repo/scout"])

    def test_cmd_new_fresh_terminates_a_recycled_row_by_its_canonical_live_name(self):
        # RATIFIED case 1 end-to-end (sol, 2026-07-25) — the deliberate
        # behavior CHANGE this wave records. Same recycled unstamped row as
        # above, but its stored session IS this seat's canonical name and that
        # name is live. Pre-ruling the launcher refused outright; now it
        # terminates the seat's own session BY NAME. The assertion that matters
        # is the target: `=repo/scout`, never the stranger the id resolves to.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "session": "repo/scout", "harness": "cursor",
                    "pane": "repo/other:0.0", "pane_id": "%201",
                }},
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []

            def fake_pane_facts(target):
                if target == "%201":
                    return None
                if target == "repo/other:0.0":
                    return launcher.PaneFacts("repo/other:0.0", "%205", "cursor-agent", str(root))
                return None

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout", "repo/other"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout", "repo/other"}
                ), mock.patch.object(launcher, "tmux_pane_facts", side_effect=fake_pane_facts), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(launcher, "run_record", return_value=0), mock.patch.object(
                    launcher, "caller_tty", return_value="/dev/tty"
                ):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(killed, ["=repo/scout"])

    def test_chooser_k_kills_picker_name_despite_unprovable_row(self):
        """tap-5ils: literal chooser [k] ignores stale identity and kills its named target."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"},
                sessions=[launcher.SessionRecord(
                    name="repo/opus", harness="cursor", cwd=str(root), base="repo",
                    tag="opus", index=1, harness_session_id="old-native-id",
                )],
            ))
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"opus": {
                    "status": "active", "harness": "cursor",
                    "pane": "repo/opus:1.1", "pane_id": "%6",
                }},
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="opus",
                model=None, teams=False, dry_run=False, fresh=False,
            )
            killed = []
            # The recycled id resolves — live, and belonging to a bystander.
            stranger = launcher.PaneFacts("repo/fable:1.1", "%6", "claude", str(root))

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            interactive_stdin = mock.Mock()
            interactive_stdin.isatty.return_value = True
            interactive_stdin.fileno.return_value = -1  # prompt fixture has no attachable tty
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(
                    launcher.registry_v20, "resolve_team_registry_for_root",
                    return_value=("legacy", str(registry)),
                ), mock.patch.object(launcher, "tmux_sessions", return_value={"repo/opus", "repo/fable"}), \
                     mock.patch.object(launcher, "tmux_sessions_or_none", return_value={"repo/opus", "repo/fable"}), \
                     mock.patch.object(launcher, "tmux_pane_facts", return_value=stranger), \
                     mock.patch.object(launcher, "tmux_has", return_value=True), \
                     mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), \
                     mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                     mock.patch.object(launcher, "run_record", return_value=0), \
                     mock.patch.object(launcher, "caller_has_tty", return_value=True), \
                     mock.patch.object(launcher.sys, "stdin", interactive_stdin), \
                     mock.patch.object(launcher, "caller_tty", return_value="/dev/tty"), \
                     mock.patch.object(launcher, "prompt_choice", return_value="k"):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(killed, ["=repo/opus"])
            self.assertEqual(
                len(list((root / ".tap" / "backup" / "session-kill").glob("*/COMPLETE"))),
                1,
            )

    def test_cmd_new_fresh_ignores_registry_entry_without_stable_pane_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "session": "repo/scout", "harness": "cursor",
                    "pane": "repo/other:0.0",
                }},
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []
            foreign = launcher.PaneFacts("repo/other:0.0", "%217", "cursor-agent", str(root))

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/other"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/other"}
                ), mock.patch.object(launcher, "tmux_pane_facts", return_value=foreign), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(launcher, "run_record", return_value=0), mock.patch.object(
                    launcher, "caller_tty", return_value="/dev/tty"
                ):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(killed, ["=repo/scout"])

    def _rxqb_registry(self, root, agents):
        registry = root / ".tap" / "bus" / "registry.json"
        registry.parent.mkdir(parents=True, exist_ok=True)
        registry.write_text(json.dumps({
            "team": {"name": "repo", "worktree_root": str(root)},
            "agents": agents,
        }) + "\n")
        return registry

    def test_occupied_names_frees_a_dead_pane_backed_seat(self):
        """tap-rxqb core: a corpse must stop occupying its session name.

        Before the fix a dead-but-registered seat kept `repo/fable` occupied, so
        a native resume minted `repo/fable-2`, the SessionStart hook derived the
        handle `fable-2` from that name, and the forked handle never collided
        with `fable` — so the register ladder's dead-incumbent reclaim was never
        reached. Freeing the name is what lets the ORIGINAL handle come back.
        """
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {"fable": {
                "status": "active", "harness": "claude",
                "pane": "repo/fable:0.0", "pane_id": "%92",
            }})
            with mock.patch.object(launcher, "tmux_sessions", return_value=set()), mock.patch.object(
                launcher, "tmux_sessions_or_none", return_value=set()
            ), mock.patch.object(launcher, "tmux_pane_facts", return_value=None), mock.patch.object(
                launcher, "tmux_pane_raw_id", return_value=""
            ):
                occupied = launcher.occupied_session_names("repo", str(root))
            self.assertNotIn("repo/fable", occupied)
            # ...and the allocator therefore hands back the BASE name, not -2.
            self.assertEqual(launcher.allocate_name("repo", "claude", "fable", occupied), "repo/fable")

    def test_occupied_names_frees_current_generation_absent_name_despite_recycled_id(self):
        """Exact current-generation name absence is GONE even when the stored
        pane id now resolves live in an unrelated session."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {"fable": {
                "status": "active", "harness": "claude", "session": "repo/fable",
                "pane": "repo/fable:0.0", "pane_id": "%92",
                "server_epoch": "srv:9:90", "boot_id": "boot:9",
            }})
            foreign = launcher.PaneFacts("other/fable:0.0", "%92", "claude", str(root))
            with mock.patch.object(launcher, "current_server_epoch", return_value="srv:9:90"), \
                 mock.patch.object(launcher, "current_boot_id", return_value="boot:9"), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=foreign):
                occupied = launcher.occupied_session_names(
                    "repo", str(root), live_sessions={"other/fable"})
            self.assertNotIn("repo/fable", occupied)

    def test_occupied_names_preserves_absent_name_from_prior_server_generation(self):
        """Absent + stale generation is OFFLINE, not GONE: the native resume
        pointer and its canonical name remain reserved."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {"fable": {
                "status": "active", "harness": "claude", "session": "repo/fable",
                "pane": "repo/fable:0.0", "pane_id": "%92",
                "server_epoch": "srv:1:10", "native_session_id": "native-fable",
            }})
            with mock.patch.object(launcher, "current_server_epoch", return_value="srv:2:20"), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=None), \
                 mock.patch.object(launcher, "tmux_pane_raw_id", return_value=""):
                occupied = launcher.occupied_session_names(
                    "repo", str(root), live_sessions=set())
            self.assertIn("repo/fable", occupied)

    def test_occupied_names_preserves_absent_name_across_boot_mismatch_or_unknown(self):
        """A known boot mismatch is OFFLINE and an unobservable current boot is
        UNKNOWN; neither state opens the allocation collision door."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {"fable": {
                "status": "active", "harness": "claude", "session": "repo/fable",
                "pane": "repo/fable:0.0", "pane_id": "%92", "boot_id": "boot:1",
            }})
            for observed_boot in ("boot:2", None):
                with self.subTest(observed_boot=observed_boot), \
                     mock.patch.object(launcher, "current_boot_id", return_value=observed_boot), \
                     mock.patch.object(launcher, "tmux_pane_facts", return_value=None), \
                     mock.patch.object(launcher, "tmux_pane_raw_id", return_value=""):
                    occupied = launcher.occupied_session_names(
                        "repo", str(root), live_sessions=set())
                self.assertIn("repo/fable", occupied)

    def test_occupied_names_keeps_a_recycled_pane_seat(self):
        """tap-bau invariant: identity dead + address LIVE inside the exact
        named session is an occupied seat, never a corpse."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {"fable": {
                "status": "active", "harness": "claude",
                "pane": "repo/fable:0.0", "pane_id": "%92",
            }})
            live_at_address = launcher.PaneFacts("repo/fable:0.0", "%93", "claude", str(root))

            def facts(target):
                return None if target == "%92" else live_at_address

            with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/fable"}), mock.patch.object(
                launcher, "tmux_sessions_or_none", return_value={"repo/fable"}
            ), mock.patch.object(launcher, "tmux_pane_facts", side_effect=facts), mock.patch.object(
                launcher, "tmux_pane_raw_id", return_value=""
            ):
                occupied = launcher.occupied_session_names("repo", str(root))
            self.assertIn("repo/fable", occupied)

    def test_occupied_names_keeps_declared_seats_that_have_no_pane(self):
        """A seat with no pane is not automatically a corpse. A PENDING
        reservation is mid-claim and a POLL seat is a paneless daemon; both hold
        their name by declaration, exactly as the register ladder treats them."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {
                "claimant": {"status": "pending", "session": "repo/claimant", "harness": "claude"},
                "daemon": {"status": "active", "delivery": "poll", "harness": "claude"},
            })
            with mock.patch.object(launcher, "tmux_sessions", return_value=set()), mock.patch.object(
                launcher, "tmux_sessions_or_none", return_value=set()
            ), mock.patch.object(launcher, "tmux_pane_facts", return_value=None):
                occupied = launcher.occupied_session_names("repo", str(root))
            self.assertIn("repo/claimant", occupied)
            self.assertIn("repo/daemon", occupied)

    def test_occupied_names_multiple_dead_siblings_prefer_the_base_name(self):
        """fable's edge call: with `fable` AND `fable-2` both corpses, the base
        name wins — the seat comes back as itself, not as its own fork."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {
                "fable": {"status": "active", "harness": "claude",
                          "pane": "repo/fable:0.0", "pane_id": "%94"},
                "fable-2": {"status": "active", "harness": "claude",
                            "pane": "repo/fable-2:0.0", "pane_id": "%95"},
            })
            with mock.patch.object(launcher, "tmux_sessions", return_value=set()), mock.patch.object(
                launcher, "tmux_sessions_or_none", return_value=set()
            ), mock.patch.object(launcher, "tmux_pane_facts", return_value=None), mock.patch.object(
                launcher, "tmux_pane_raw_id", return_value=""
            ):
                occupied = launcher.occupied_session_names("repo", str(root))
            self.assertEqual(launcher.allocate_name("repo", "claude", "fable", occupied), "repo/fable")

    def test_occupied_names_keeps_a_suspended_seat_whose_pane_is_live(self):
        """The named case for the allocator/ladder ASYMMETRY. The register
        ladder would reclaim a non-active seat outright; this allocator will
        not free one whose pane is still live. The two disagree here BY DESIGN,
        in the only safe direction: the allocator never proposes a name the
        ladder would refuse, so a conservative allocator costs at most a suffix
        while an aggressive one could steal a live pane's name.
        """
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {"susp": {
                "status": "suspended", "harness": "claude",
                "pane": "repo/susp:0.0", "pane_id": "%91",
            }})
            alive = launcher.PaneFacts("repo/susp:0.0", "%91", "claude", str(root))
            with mock.patch.object(launcher, "tmux_sessions", return_value=set()), mock.patch.object(
                launcher, "tmux_sessions_or_none", return_value=set()
            ), mock.patch.object(launcher, "tmux_pane_facts", return_value=alive):
                occupied = launcher.occupied_session_names("repo", str(root))
            self.assertIn("repo/susp", occupied)

    def test_occupied_names_keeps_a_launching_reservation_inside_its_grace(self):
        """RED (sol, #xxx gate finding 1). A token-bearing launching reservation
        — status=active + status_reason=launching + launch_id — is paneless,
        non-pending and non-poll, yet `pending_reservation_expired` explicitly
        PROTECTS it for the 60s grace. The corpse predicate must not free what
        the reservation grace protects, or a launch in flight loses its name.

        The real lesson is that the by-declaration carve-out ENUMERATED two
        statuses instead of characterising the category: a seat whose ownership
        is attested by something other than a live pane. A launch token is such
        an attestation.
        """
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {"launching": {
                "status": "active", "status_reason": "launching", "launch_id": "L1",
                "harness": "claude", "session": "repo/launching",
                "registered_at": launcher.current_timestamp(), "boot_id": "boot:test",
            }})
            with mock.patch.object(launcher, "tmux_sessions", return_value=set()), mock.patch.object(
                launcher, "tmux_sessions_or_none", return_value=set()
            ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                launcher, "tmux_pane_facts", return_value=None
            ):
                entry = launcher.tap_seat_entries(str(root))["launching"]
                # Precondition: the grace really does protect this row.
                self.assertFalse(
                    launcher.pending_reservation_expired(entry, live_sessions=set()),
                    "fixture is wrong: the reservation is not inside its protected grace",
                )
                occupied = launcher.occupied_session_names("repo", str(root))
            self.assertIn("repo/launching", occupied)

    def test_seat_pane_probe_address_resolving_to_the_stored_id_is_not_a_corpse(self):
        """RED (sol, #xxx gate finding 2). Stable-id probe MISSES but the
        recorded address resolves to that SAME stored id — the pane is alive and
        is the very identity on record. `tap-register.sh`'s address fallback
        (the AUTHORITY) treats any live returned id as occupied; this predicate
        currently falls through to pane_gone and frees a live seat's name, which
        is the forbidden aggressive direction.

        Note this is a THREE-way drift, not two: the python mirrors lib.sh's
        helper faithfully, but lib.sh itself disagrees with the ladder here — so
        the lockstep was pinned to the wrong reference.
        """
        same_id = launcher.PaneFacts("repo/s:0.0", "%203", "claude", "/tmp")
        with mock.patch.object(
            launcher, "tmux_pane_facts", side_effect=lambda t: None if t == "%203" else same_id
        ):
            self.assertNotEqual(
                launcher.seat_pane_probe("%203", "repo/s:0.0"),
                launcher.SEAT_PANE_GONE,
                "a live pane at the recorded address IS the seat — never a corpse",
            )

    def test_occupied_names_keeps_a_row_that_is_not_pane_backed_at_all(self):
        """RED (sol guardrail). `seat_is_reclaimable_corpse` documents itself as
        applying to a PANE-BACKED seat, but never enforces it: a row with
        neither `pane_id` nor `pane` probes `pane_gone` and gets freed. Code
        contradicting its own docstring. A row that was never pane-backed has
        not been proven dead — nothing was observed — so it must hold its name.
        This also makes the predicate forward-compatible with row shapes that
        do not exist yet.
        """
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {"paneless": {"status": "active", "harness": "claude"}})
            with mock.patch.object(launcher, "tmux_sessions", return_value=set()), mock.patch.object(
                launcher, "tmux_sessions_or_none", return_value=set()
            ), mock.patch.object(launcher, "tmux_pane_facts", return_value=None):
                occupied = launcher.occupied_session_names("repo", str(root))
            self.assertIn("repo/paneless", occupied)

    def test_occupied_names_frees_nothing_when_tmux_is_unobservable(self):
        """RED (sol guardrail). The probe collapses 'pane is dead' and 'tmux
        could not be reached' into the same None, so an unreachable tmux server
        reads as every seat being a corpse and frees EVERY name at once — the
        worst possible blast radius, in the forbidden aggressive direction.
        Unobservable must fail CLOSED: observation unavailable is not evidence
        of death. `tmux_sessions_or_none() is None` is the codebase's existing
        signal for an unreachable server.
        """
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {"seat": {
                "status": "active", "harness": "claude",
                "pane": "repo/seat:0.0", "pane_id": "%214",
            }})
            with mock.patch.object(launcher, "tmux_sessions", return_value=set()), mock.patch.object(
                launcher, "tmux_sessions_or_none", return_value=None
            ), mock.patch.object(launcher, "tmux_pane_facts", return_value=None):
                occupied = launcher.occupied_session_names("repo", str(root))
            self.assertIn("repo/seat", occupied)

    def test_occupied_names_observes_tmux_exactly_once_when_unobservable(self):
        """sol-pinnacle (#xxx delta 2 gate): a passed live_sessions=None is the
        legitimate UNOBSERVABLE snapshot, not 'argument omitted' — one
        allocation observes tmux exactly ONCE and every seat classifies
        against that same snapshot. Before the _UNSET sentinel, the None path
        re-observed in tap_seat_entries and once per seat in
        seat_is_reclaimable_corpse (4 calls for 2 seats)."""
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            self._rxqb_registry(root, {
                "one": {"status": "active", "harness": "claude",
                        "pane": "repo/one:0.0", "pane_id": "%1"},
                "two": {"status": "active", "harness": "claude",
                        "pane": "repo/two:0.0", "pane_id": "%2"},
            })
            with mock.patch.object(launcher, "tmux_sessions_or_none", return_value=None) as probe, mock.patch.object(
                launcher, "tmux_pane_facts", return_value=None
            ) as facts:
                occupied = launcher.occupied_session_names("repo", str(root))
            self.assertEqual(probe.call_count, 1)
            # Fail-closed short-circuits BEFORE any pane probe: an unobservable
            # snapshot never spends per-seat observations either.
            self.assertEqual(facts.call_count, 0)
            self.assertEqual(occupied, {"repo/one", "repo/two"})

    def test_seat_pane_probe_matches_the_bash_four_way_spec(self):
        """ONE SPEC, one authority — seat_pane_probe delegates to
        seat_corpse.classify_pane, the module the register ladder imports, and
        lib.sh's bash mirror is pinned against it by
        seat-corpse-lockstep.test.sh. Four-way: a failed pane observation only
        proves death when the server itself answered (reachability mocked here
        so the spec is deterministic on machines without a live tmux)."""
        incumbent = launcher.PaneFacts("repo/s:0.0", "%91", "claude", "/tmp")
        recycled = launcher.PaneFacts("repo/s:0.0", "%93", "claude", "/tmp")
        malformed = launcher.PaneFacts("repo/s:0.0", "beefcake", "claude", "/tmp")
        reachable = mock.patch.object(launcher, "tmux_sessions_or_none", return_value=set())
        observed_absent = mock.patch.object(launcher, "tmux_pane_raw_id", return_value="")
        with reachable, mock.patch.object(launcher, "tmux_pane_facts", return_value=incumbent):
            self.assertEqual(launcher.seat_pane_probe("%91", "repo/s:0.0"), launcher.SEAT_ALIVE)
        with reachable, observed_absent, mock.patch.object(launcher, "tmux_pane_facts", side_effect=lambda t: None if t == "%91" else recycled):
            self.assertEqual(launcher.seat_pane_probe("%91", "repo/s:0.0"), launcher.SEAT_PANE_RECYCLED)
        with reachable, observed_absent, mock.patch.object(launcher, "tmux_pane_facts", return_value=None):
            self.assertEqual(launcher.seat_pane_probe("%91", "repo/s:0.0"), launcher.SEAT_PANE_GONE)
            self.assertEqual(launcher.seat_pane_probe("", ""), launcher.SEAT_PANE_GONE)
        with mock.patch.object(launcher, "tmux_sessions_or_none", return_value=None), mock.patch.object(
            launcher, "tmux_pane_facts", return_value=None
        ):
            self.assertEqual(launcher.seat_pane_probe("%91", "repo/s:0.0"), launcher.SEAT_UNOBSERVABLE)
            self.assertEqual(launcher.seat_pane_probe("", "repo/s:0.0"), launcher.SEAT_UNOBSERVABLE)
        # Malformed-but-reachable is UNOBSERVABLE, never observed-absent (sol,
        # #xxx re-gate P1 #2): a garbage parse and a garbage raw expansion are
        # a broken observation channel — a pane id always starts with '%'.
        with reachable, mock.patch.object(launcher, "tmux_pane_facts", return_value=malformed):
            self.assertEqual(launcher.seat_pane_probe("%91", "repo/s:0.0"), launcher.SEAT_UNOBSERVABLE)
        with reachable, mock.patch.object(launcher, "tmux_pane_facts", return_value=None), mock.patch.object(
            launcher, "tmux_pane_raw_id", return_value="garbage not an id"
        ):
            self.assertEqual(launcher.seat_pane_probe("%91", "repo/s:0.0"), launcher.SEAT_UNOBSERVABLE)
        # Sol's re-gate injection, the NONZERO arm verbatim: the raw probe
        # FAILED (None) while the server is reachable. A failed probe is never
        # an observation of absence — the fail-closed rule exists for exactly
        # this branch. Was pane_gone at 7e88f88; must be UNOBSERVABLE.
        with reachable, mock.patch.object(launcher, "tmux_pane_facts", return_value=None), mock.patch.object(
            launcher, "tmux_pane_raw_id", return_value=None
        ):
            self.assertEqual(launcher.seat_pane_probe("%91", "repo/s:0.0"), launcher.SEAT_UNOBSERVABLE)
            self.assertEqual(launcher.seat_pane_probe("", "repo/s:0.0"), launcher.SEAT_UNOBSERVABLE)

    def test_seat_corpse_pane_id_grammar_boundary_pairs(self):
        """sol (#xxx re-gate round 2): the pane-id grammar is '%' + ASCII
        decimal digits, nothing else — a bare %-prefix check accepted
        '%beefcake' as an identity and classified pane_recycled, an answer
        that AUTHORIZES destruction. Boundary pairs per rejection rule
        (inside AND outside), then sol's injection verbatim through
        seat_verdict — the locked register chooser's decision function."""
        seat_corpse = launcher.seat_corpse
        for inside in ("%0", "%41", "%999999"):
            self.assertTrue(seat_corpse.is_pane_id(inside), inside)
        for outside in ("41", "%", "%beefcake", "%4x", "%-1", "", "%４１", "% 41", "%41 ", "%4.1", None, 41):
            self.assertFalse(seat_corpse.is_pane_id(outside), repr(outside))

        # Sol's round-2 injection: stored %41 observed absent, address
        # answering %beefcake with a live session name. Must be UNOBSERVABLE —
        # pane_recycled here would authorize reclaiming the base handle.
        def fake_run(argv, **_kwargs):
            target = argv[argv.index("-t") + 1]
            if target == "%41":
                return subprocess.CompletedProcess(args=argv, returncode=0, stdout="", stderr="")
            return subprocess.CompletedProcess(args=argv, returncode=0, stdout="%beefcake\trepo\n", stderr="")

        with mock.patch.object(seat_corpse.subprocess, "run", side_effect=fake_run):
            verdict, live_pid, live_session = seat_corpse.seat_verdict(
                {"pane_id": "%41", "pane": "repo/seat:0.0"}
            )
        self.assertEqual(verdict, launcher.SEAT_UNOBSERVABLE)
        self.assertEqual((live_pid, live_session), ("", ""))

    def test_seat_corpse_pane_observation_failure_is_never_absence(self):
        """The register chooser's observation (seat_corpse.pane_observation),
        pinned at the subprocess seam — sol's re-gate P1 #2 register arm: a
        target-probe failure or exception must be None (no observation), never
        ("", "") absence. Only the server ANSWERING says absent: rc 0 with an
        empty expansion, or the classic nonzero can't-find reply."""
        seat_corpse = launcher.seat_corpse

        def run_result(returncode, stdout="", stderr=""):
            return subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr=stderr)

        with mock.patch.object(seat_corpse.subprocess, "run", side_effect=OSError("boom")):
            self.assertIsNone(seat_corpse.pane_observation("%203"))
        with mock.patch.object(seat_corpse.subprocess, "run", return_value=run_result(1, stderr="lost server socket temporarily")):
            self.assertIsNone(seat_corpse.pane_observation("%203"))
        with mock.patch.object(seat_corpse.subprocess, "run", return_value=run_result(1, stderr="can't find pane: %203")):
            self.assertEqual(seat_corpse.pane_observation("%203"), ("", ""))
        with mock.patch.object(seat_corpse.subprocess, "run", return_value=run_result(0, stdout="")):
            self.assertEqual(seat_corpse.pane_observation("%203"), ("", ""))
        with mock.patch.object(seat_corpse.subprocess, "run", return_value=run_result(0, stdout="%7\trepo/seat\n")):
            self.assertEqual(seat_corpse.pane_observation("%203"), ("%7", "repo/seat"))
        with mock.patch.object(seat_corpse.subprocess, "run", return_value=run_result(0, stdout="beefcake\trepo/seat\n")):
            self.assertIsNone(seat_corpse.pane_observation("%203"))
        # And through the ladder's actual decision function: a failed probe
        # yields UNOBSERVABLE, never a reclaimable corpse.
        with mock.patch.object(seat_corpse.subprocess, "run", return_value=run_result(1, stderr="lost server socket temporarily")):
            verdict, live_pid, _ = seat_corpse.seat_verdict({"pane_id": "%203", "pane": "repo/s:0.0"})
        self.assertEqual(verdict, launcher.SEAT_UNOBSERVABLE)
        self.assertEqual(live_pid, "")

    def test_seat_corpse_record_framing_is_part_of_the_contract(self):
        """sol (#xxx re-gate r4): rc-0 absence is ONLY a truly empty
        expansion; anything else must be exactly ONE complete live record
        (valid pane id + tab + non-empty session). Empty-id-with-session
        partitioned into an empty pid BEFORE the grammar gate and read as
        observed-absence; whitespace stripped to absence in the raw
        discriminator. Framing failures are UNOBSERVABLE, and sol's injection
        (stored %41 can't-find, address answering '\\trepo') must never
        classify pane_gone through the ladder's decision function."""
        seat_corpse = launcher.seat_corpse

        def run_result(returncode, stdout="", stderr=""):
            return subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr=stderr)

        framing_none = ["\trepo\n", " \n", "  ", "%41\n", "%41\t\n", "%41\trepo\n%42\trepo2\n", "\n\n", "\t\n"]
        for shape in framing_none:
            with mock.patch.object(seat_corpse.subprocess, "run", return_value=run_result(0, stdout=shape)):
                self.assertIsNone(seat_corpse.pane_observation("%207"), repr(shape))
        for shape, expected in (("", ("", "")), ("\n", ("", "")), ("%41\trepo\n", ("%41", "repo"))):
            with mock.patch.object(seat_corpse.subprocess, "run", return_value=run_result(0, stdout=shape)):
                self.assertEqual(seat_corpse.pane_observation("%207"), expected, repr(shape))

        # The raw discriminator obeys the same framing: whitespace and
        # multi-line are never absence; only the empty expansion is.
        with mock.patch.object(launcher.subprocess, "run", return_value=run_result(0, stdout=" \n")):
            self.assertEqual(launcher.tmux_pane_raw_id("%207"), " ")
        with mock.patch.object(launcher.subprocess, "run", return_value=run_result(0, stdout="%41\n%42\n")):
            self.assertIsNone(launcher.tmux_pane_raw_id("%207"))
        with mock.patch.object(launcher.subprocess, "run", return_value=run_result(0, stdout="\n")):
            self.assertEqual(launcher.tmux_pane_raw_id("%207"), "")

        # Sol's r4 injection verbatim: stored %41 answers can't-find, the
        # address answers empty-id + session. Was pane_gone at bd93e80; must
        # be UNOBSERVABLE — malformed evidence never authorizes a reclaim.
        def fake_run(argv, **_kwargs):
            target = argv[argv.index("-t") + 1]
            if target == "%41":
                return run_result(1, stderr="can't find pane: %41")
            return run_result(0, stdout="\trepo\n")

        with mock.patch.object(seat_corpse.subprocess, "run", side_effect=fake_run):
            verdict, live_pid, _ = seat_corpse.seat_verdict({"pane_id": "%41", "pane": "repo/seat:0.0"})
        self.assertEqual(verdict, launcher.SEAT_UNOBSERVABLE)
        self.assertEqual(live_pid, "")

    def test_cmd_new_fresh_does_not_recheck_pane_identity_before_kill(self):
        # Ops 2026-08-06: once [k]/fresh is selected, a recycled pane hint does
        # not veto or redirect the canonical name-keyed kill.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "session": "repo/scout", "harness": "cursor",
                    "pane": "repo/scout:0.0", "pane_id": "%201",
                    "server_epoch": "srv:7:70",
                }},
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []
            incumbent = launcher.PaneFacts("repo/scout:0.0", "%201", "cursor-agent", str(root))
            recycled = launcher.PaneFacts("repo/foreign:0.0", "%205", "cursor-agent", str(root))

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            def facts_effect(*_args, **_kwargs):
                # Identity readers may observe either the incumbent or a
                # recycled foreign tip; [k] does not consume either as authority.
                import traceback
                stack = "".join(traceback.format_stack(limit=40))
                if "prepare_new_launch" in stack and "claim_pending_handle" not in stack:
                    return recycled
                return incumbent

            receipts = io.StringIO()
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": "srv:7:70"}), mock.patch.object(
                    launcher, "tmux_sessions", return_value={"repo/scout"}
                ), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(
                    launcher, "tmux_pane_facts", side_effect=facts_effect
                ), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(
                    launcher, "tmux_session_pane_ids", return_value=["%201"]
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(
                    launcher, "run_record", return_value=0
                ), mock.patch.object(
                    launcher, "caller_tty", return_value="/dev/tty"
                ), contextlib.redirect_stdout(receipts):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(killed, ["=repo/scout"])

    def test_cmd_new_fresh_kills_canonical_name_with_gone_pane_hint(self):
        # A gone pane hint neither vetoes nor changes the canonical [k] target.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "session": "repo/scout", "harness": "cursor",
                    "pane": "repo/scout:0.0", "pane_id": "%201",
                }},
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(
                    launcher, "tmux_pane_facts", return_value=None
                ), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(
                    launcher, "tmux_session_pane_ids", return_value=[]
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(launcher, "run_record", return_value=0), mock.patch.object(
                    launcher, "caller_tty", return_value="/dev/tty"
                ):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(killed, ["=repo/scout"])

    def test_cmd_new_fresh_missing_target_after_claim_still_launches_fresh(self):
        # If the canonical target exits after selection, there is nothing left
        # to kill; [k] proceeds with the already-checkpointed fresh launch.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "session": "repo/scout", "harness": "cursor",
                    "pane": "repo/scout:0.0", "pane_id": "%201",
                }},
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []
            live_names = {"repo/scout"}
            real_claim = launcher.claim_pending_handle
            # The pane still answers in its recorded session before the claim;
            # the canonical session then exits before the stop boundary.
            incumbent = launcher.PaneFacts("repo/scout:0.0", "%201", "cursor-agent", str(root))

            def vanish_after_claim(record, allow_same_session=False):
                # claim_pending_handle is the first statement of
                # prepare_new_launch, so this is precisely the window between
                # backup/reservation and the name-keyed stop.
                result = real_claim(record, allow_same_session)
                live_names.clear()
                return result

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            receipts = io.StringIO()
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(
                    launcher.registry_v20, "resolve_team_registry_for_root",
                    return_value=("legacy", str(registry)),
                ), mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(launcher, "tmux_pane_facts", return_value=incumbent), mock.patch.object(
                    launcher, "tmux_has", side_effect=lambda name: name in live_names
                ), mock.patch.object(
                    launcher, "claim_pending_handle", side_effect=vanish_after_claim
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(
                    launcher, "run_record", return_value=0
                ), mock.patch.object(
                    launcher, "caller_tty", return_value="/dev/tty"
                ), contextlib.redirect_stdout(receipts):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(killed, [])
            bundles = list((root / ".tap" / "backup" / "session-kill").glob("*/COMPLETE"))
            self.assertEqual(len(bundles), 1)
            self.assertIn("repo/scout was already absent", receipts.getvalue())
            self.assertIn(f"tap restore scout --archive {bundles[0].parent}", receipts.getvalue())

    def test_cmd_new_fresh_revalidates_pending_reservation_under_kill_lock(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            incumbent_entry = {
                "status": "active", "session": "repo/scout", "harness": "cursor",
                "pane": "repo/scout:0.0", "pane_id": "%201",
            }
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": incumbent_entry},
            }) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            facts = launcher.PaneFacts("repo/scout:0.0", "%201", "cursor-agent", str(root))
            killed = []
            real_claim = launcher.claim_pending_handle

            def claim_then_replace(record):
                displaced = real_claim(record)
                payload = json.loads(registry.read_text())
                payload["agents"]["scout"] = dict(incumbent_entry)
                registry.write_text(json.dumps(payload) + "\n")
                return displaced

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(launcher, "tmux_pane_facts", return_value=facts), mock.patch.object(
                    launcher, "claim_pending_handle", side_effect=claim_then_replace
                ), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(launcher, "run_record", return_value=0), mock.patch.object(
                    launcher, "caller_tty", return_value="/dev/tty"
                ):
                    with self.assertRaisesRegex(launcher.LauncherError, "reservation changed before teardown"):
                        launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(killed, [])
            self.assertEqual(json.loads(registry.read_text())["agents"]["scout"], incumbent_entry)
            self.assertEqual([(record.harness, record.name) for record in load_registry_state(manifest).sessions], [
                ("cursor", "repo/scout"),
            ])

    def test_cmd_new_fresh_sibling_suspend_failure_does_not_kill_incumbent(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "active", "session": "repo/scout", "harness": "cursor",
                        "pane": "repo/scout:0.0", "pane_id": "%201",
                    },
                    "helper": {
                        "status": "active", "session": "repo/scout", "harness": "codex",
                        "pane": "repo/scout:0.1", "pane_id": "%202",
                    },
                },
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            facts = launcher.PaneFacts("repo/scout:0.0", "%201", "cursor-agent", str(root))
            killed = []

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(launcher, "tmux_pane_facts", return_value=facts), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(
                    launcher, "suspend_session_registry_members", side_effect=OSError("disk full")
                ):
                    with self.assertRaisesRegex(OSError, "disk full"):
                        launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(killed, [])
            self.assertEqual(json.loads(registry.read_text()), original_registry)

    def test_cmd_new_fresh_kill_failure_restores_incumbent_registry_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "active", "session": "repo/scout", "harness": "cursor",
                        "pane": "repo/scout:0.0", "pane_id": "%201",
                    },
                    "helper": {
                        "status": "active", "session": "repo/scout", "harness": "codex",
                        "pane": "repo/scout:0.1", "pane_id": "%202",
                    },
                },
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            facts = launcher.PaneFacts("repo/scout:0.0", "%201", "cursor-agent", str(root))

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(launcher, "tmux_pane_facts", return_value=facts), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess,
                    "run",
                    side_effect=launcher.subprocess.CalledProcessError(1, ["tmux", "kill-session"]),
                ):
                    with self.assertRaises(launcher.subprocess.CalledProcessError):
                        launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(json.loads(registry.read_text()), original_registry)

    def test_cmd_new_fresh_kill_failure_restores_suspended_incumbent_registry_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            old = launcher.SessionRecord(
                name="repo/scout", harness="cursor", cwd=str(root), base="repo", tag="scout",
            )
            save_registry_state(manifest, launcher.Manifest(
                dir_aliases={str(root): "repo"}, sessions=[old],
            ))
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "suspended", "status_reason": "user_removed",
                    "session": "repo/scout", "harness": "cursor",
                    "pane": "repo/scout:0.0", "pane_id": "%201",
                    "cost_mode": "subscription", "include_policy": "on_request",
                }},
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            facts = launcher.PaneFacts("repo/scout:0.0", "%201", "cursor-agent", str(root))

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo/scout"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/scout"}
                ), mock.patch.object(launcher, "tmux_pane_facts", return_value=facts), mock.patch.object(
                    launcher, "tmux_has", return_value=True
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess,
                    "run",
                    side_effect=launcher.subprocess.CalledProcessError(1, ["tmux", "kill-session"]),
                ):
                    with self.assertRaises(launcher.subprocess.CalledProcessError):
                        launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(json.loads(registry.read_text()), original_registry)

    def test_claim_pending_handle_refuses_replacing_a_nonexpired_pending_incumbent(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            original_registry = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "pending", "session": "repo/scout", "harness": "cursor",
                    "registered_at": "2026-07-14T00:00:00Z",
                }},
            }
            registry.write_text(json.dumps(original_registry) + "\n")
            replacement = launcher.SessionRecord(
                name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout",
                replaces_session="repo/scout",
            )

            with mock.patch.object(launcher, "tmux_sessions_or_none", return_value={"repo/scout"}):
                with self.assertRaises(SystemExit) as raised:
                    launcher.claim_pending_handle(replacement)

            self.assertEqual(raised.exception.code, 2)
            self.assertEqual(json.loads(registry.read_text()), original_registry)

    def test_claim_pending_handle_reclaims_expired_bound_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"scout": {
                    "status": "active", "status_reason": "launching",
                    "session": "repo/scout", "harness": "claude",
                    "pane": "repo/scout:0.0", "pane_id": "%204",
                    "launch_id": "dead-token", "registered_at": "2026-07-14T00:00:00Z",
                }},
            }) + "\n")
            replacement = launcher.SessionRecord(
                name="repo/scout", harness="claude", cwd=str(root), base="repo", tag="scout",
            )

            with mock.patch.object(launcher, "tmux_sessions_or_none", return_value=set()), mock.patch.object(
                launcher, "current_timestamp", return_value="2026-07-14T00:02:00Z"
            ):
                self.assertIsNone(launcher.claim_pending_handle(replacement))

            entry = json.loads(registry.read_text())["agents"]["scout"]
            self.assertEqual(entry["status"], "pending")
            self.assertEqual(entry["launch_id"], replacement.launch_id)
            self.assertNotEqual(entry["launch_id"], "dead-token")

    def test_entry_session_name_prefers_live_pane_over_stale_registry_session(self):
        # tap-24f: pane-first now requires an epoch-sound identity — a stamp
        # from THIS server. An unstamped id may not override stored session
        # provenance (that shape is the reborn-server recycled-id ghost; see
        # test_server_epoch.py for the unstamped and stale-stamp fixtures).
        entry = {"session": "repo/stale", "pane_id": "%211", "pane": "repo/live:0.0",
                 "server_epoch": "srv:1:1"}
        facts = launcher.PaneFacts(
            pane="repo/live:0.0", pane_id="%211", command="cursor-agent", path="/repo",
        )

        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": "srv:1:1"}), \
             mock.patch.object(launcher, "tmux_pane_facts", return_value=facts):
            self.assertEqual(launcher.entry_session_name(entry), "repo/live")

    def test_entry_session_name_ignores_recycled_pane_id_before_registry_session(self):
        entry = {"session": "repo/stored", "pane_id": "%201", "pane": "repo/stored:0.0"}
        recycled = launcher.PaneFacts(
            pane="repo/foreign:0.0", pane_id="%205", command="cursor-agent", path="/repo",
        )

        with mock.patch.object(launcher, "tmux_pane_facts", return_value=recycled):
            self.assertEqual(launcher.entry_session_name(entry), "repo/stored")

    def test_entry_session_name_prefers_stored_session_without_stable_pane_identity(self):
        entry = {"session": "repo/stored", "pane": "repo/recycled:0.0"}
        recycled = launcher.PaneFacts(
            pane="repo/foreign:0.0", pane_id="%205", command="cursor-agent", path="/repo",
        )

        with mock.patch.object(launcher, "tmux_pane_facts", return_value=recycled) as pane_facts:
            self.assertEqual(launcher.entry_session_name(entry), "repo/stored")
        pane_facts.assert_not_called()

    def test_cmd_new_fresh_kills_picker_name_without_registry_session_stamp(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            save_registry_state(manifest, launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]))
            # Name-first (2026-08-04): no session stamp → cannot authorize a
            # stop target. The old id-anchored "follow the pane" arm is E2 and
            # is retired; epoch alone does not license pane-derived kills.
            original = {
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "scout": {
                        "status": "active", "harness": "cursor",
                        "pane": "repo/legacy-scout:0.0", "pane_id": "%201",
                        "server_epoch": "srv:7:70",
                    },
                },
            }
            registry.write_text(json.dumps(original) + "\n")
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None, tag=None, label="scout",
                model=None, teams=False, dry_run=False, fresh=True,
            )
            killed = []

            def fake_run(command, **_kwargs):
                if command[:2] == ["tmux", "kill-session"]:
                    killed.append(command[-1])
                return types.SimpleNamespace(returncode=0, stdout="")

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": "srv:7:70"}), mock.patch.object(
                    launcher, "tmux_sessions", return_value={"repo/legacy-scout"}
                ), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo/legacy-scout"}
                ), mock.patch.object(launcher, "tmux_has", return_value=True), mock.patch.object(
                    launcher, "tmux_pane_facts", return_value=launcher.PaneFacts(
                        pane="repo/legacy-scout:0.0", pane_id="%201", command="cursor-agent", path=str(root), server_epoch="srv:7:70"
                    )
                ), mock.patch.object(launcher, "current_boot_id", return_value="boot:test"), mock.patch.object(
                    launcher.subprocess, "run", side_effect=fake_run
                ), mock.patch.object(
                    launcher, "run_record", return_value=0
                ), mock.patch.object(launcher, "caller_tty", return_value="/dev/tty"):
                    rc = launcher.cmd_new(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(killed, ["=repo/scout"])

    def test_named_launch_exists_prompt_resumes_registry_handle_with_different_session_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {
                    "fable": {
                        "status": "active",
                        "session": "repo-claude-fable",
                        "harness": "claude",
                        "pane": "repo-claude-fable:0.0",
                        "pane_id": "%42",
                    },
                },
            }) + "\n")
            save_registry_state(manifest, launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]))
            args = types.SimpleNamespace(
                manifest=str(manifest), harness="claude", unique=None,
                tag=None, label="fable", model=None, teams=False, dry_run=False, fresh=False,
            )
            interactive_stdin = mock.Mock()
            interactive_stdin.isatty.return_value = True
            attached = []
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                # tmux_sessions was pinned but tmux_sessions_or_none was not, so
                # the same question got one answer from the fixture and another
                # from the developer's live server. Pin both to the same set,
                # and pin the pane probes too: the stored "%42" was going to the
                # live server, and pane ids are handed out in increasing order
                # for a server's lifetime, so "%42" is not reserved -- only not
                # allocated yet. None/"" are what the probes return for an
                # absent pane, which is what this fixture means.
                with mock.patch.object(launcher, "tmux_sessions", return_value={"repo-claude-fable"}), mock.patch.object(
                    launcher, "tmux_sessions_or_none", return_value={"repo-claude-fable"}
                ), mock.patch.object(
                    launcher, "tmux_pane_facts", return_value=None
                ), mock.patch.object(
                    launcher, "tmux_pane_raw_id", return_value=""
                ), mock.patch.object(
                    launcher, "classify_session", return_value="unknown"
                ), mock.patch.object(
                    launcher, "tmux_has", side_effect=lambda name: name == "repo-claude-fable"
                ), mock.patch.object(
                    launcher, "tap_handles", return_value={"fable"},
                ), mock.patch.object(
                    launcher, "registry_entry", return_value={
                        "status": "active",
                        "session": "repo-claude-fable",
                        "harness": "claude",
                        "pane": "repo-claude-fable:0.0",
                        "pane_id": "%42",
                    },
                ), mock.patch.object(
                    launcher, "resolve_base_alias", return_value="repo",
                ), mock.patch.object(
                    launcher, "entry_verified_session_name", return_value="repo-claude-fable",
                ), mock.patch.object(
                    launcher, "cmd_resume",
                    side_effect=lambda resume_args: attached.append(resume_args.legacy_name or resume_args.key) or 0,
                ), mock.patch.object(
                    launcher, "caller_has_tty", return_value=True
                ), mock.patch.object(launcher.sys, "stdin", interactive_stdin), mock.patch.object(
                    launcher, "prompt_choice", return_value="r"
                ), self.assertRaises(SystemExit) as raised:
                    launcher.make_new_record(args, load_registry_state(manifest))
            finally:
                os.chdir(old_cwd)

            self.assertEqual(raised.exception.code, 0)
            self.assertEqual(attached, ["fable"])

    def test_unknown_two_argument_resume_refuses_noninteractive_creation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(manifest, launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]))
            args = types.SimpleNamespace(
                manifest=str(manifest),
                key="claude",
                legacy_name="planner",
                all=False,
                model=None,
                teams=False,
                dry_run=False,
            )
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", return_value=False), mock.patch.object(
                    launcher, "tmux_sessions", return_value=set()
                ), mock.patch.object(launcher, "tap_handles", return_value=set()), mock.patch.object(
                    launcher, "run_native_resume", return_value=0
                ) as native_resume, mock.patch.object(launcher.sys, "stdin", io.StringIO("")):
                    with self.assertRaisesRegex(launcher.LauncherError, "tap session launch claude planner"):
                        launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            native_resume.assert_not_called()

    def test_unknown_two_argument_resume_can_confirm_new_launch(self):
        # tap-7r3fn.24 rewrote the create-fallback: no prompt at all — one
        # line stating the miss, then the [k] fresh path through the ONE
        # extracted launcher. Re-entering cmd_new here was the loop.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(manifest, launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]))
            args = types.SimpleNamespace(
                manifest=str(manifest),
                key="claude",
                legacy_name="planner",
                all=False,
                # Resume carries no tuning: --model and --teams are retired on this verb,
                # so a confirm-new-launch reached THROUGH resume cannot smuggle them into
                # the seat it creates either. Set the model when you LAUNCH. The fresh
                # record below mints no model channel at all, which retires the
                # tap-h40s harm shape along with the cmd_new re-entry.
                model=None,
                teams=False,
                dry_run=False,
            )
            old_cwd = pathlib.Path.cwd()
            fresh = []
            try:
                os.chdir(root)
                with mock.patch.object(launcher, "tmux_has", return_value=False), mock.patch.object(
                    launcher, "execute_fresh_launch",
                    side_effect=lambda record, _args, **_kw: fresh.append(record) or 0
                ), mock.patch.object(launcher, "run_native_resume", return_value=0) as native_resume, mock.patch.object(
                    launcher, "prompt_yes_no",
                    side_effect=AssertionError("create-fallback must not prompt (tap-7r3fn.24)"),
                ), mock.patch.object(sys, "stdout", TtyBuffer(tty=True)), \
                        mock.patch.object(sys, "stderr", TtyBuffer(tty=False)), \
                        mock.patch.object(sys, "stdin", TtyBuffer(tty=True)):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(len(fresh), 1)
            created = fresh[0]
            self.assertEqual((created.harness, created.tag, created.model), ("claude", "planner", None))
            self.assertEqual(created.replaces_session, "repo/planner")
            self.assertTrue(created.kill_backup_required)
            self.assertEqual(created.ensure_action, "new")
            native_resume.assert_not_called()

    def test_resume_harness_family_fallback_still_opens_native_picker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            manifest = root / "sessions.json"
            save_registry_state(manifest, launcher.Manifest(dir_aliases={str(root): "repo"}, sessions=[]))
            args = types.SimpleNamespace(
                manifest=str(manifest),
                key="claude",
                legacy_name=None,
                all=False,
                model=None,
                teams=False,
                dry_run=False,
            )
            launched = []
            old_cwd = pathlib.Path.cwd()
            original_run_native = launcher.run_native_resume
            original_tmux_sessions = launcher.tmux_sessions
            original_tap_handles = launcher.tap_handles
            try:
                os.chdir(root)
                launcher.tmux_sessions = lambda: set()
                launcher.tap_handles = lambda _root: set()
                launcher.run_native_resume = (
                    lambda record, native_query, dry_run, **_kw: launched.append(
                        (record.harness, native_query, dry_run)
                    )
                    or 0
                )

                rc = launcher.cmd_resume(args)
            finally:
                launcher.run_native_resume = original_run_native
                launcher.tmux_sessions = original_tmux_sessions
                launcher.tap_handles = original_tap_handles
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            self.assertEqual(launched, [("claude", None, False)])

    def test_resume_uses_registry_identity_and_ignores_retired_journal(self):
        with tempfile.TemporaryDirectory() as tmp:
            base_dir = pathlib.Path(tmp)
            root = base_dir / "repo"
            root.mkdir()
            manifest = root / "sessions.json"
            stale_id = "019a1111-2222-7333-8444-555555555555"
            poison = json.dumps({"sessions": [{
                "name": "repo/planner",
                "harness": "codex",
                "harness_session_id": stale_id,
            }]}) + "\n"
            manifest.write_text(poison)
            args = types.SimpleNamespace(
                manifest=str(manifest),
                key="planner",
                legacy_name=None,
                all=False,
                model=None,
                teams=False,
                dry_run=True,
                json=True,
            )
            registry_id = "019b2222-3333-7444-8555-666666666666"
            registry_rows = {
                "planner": {
                    "status": "active",
                    "delivery": "pane",
                    "session": "repo/planner",
                    "harness": "codex",
                    "harness_session_id": registry_id,
                    "session_attribution_trust": "env",
                    "registered_from_worktree": str(root),
                },
            }
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True, exist_ok=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": registry_rows,
            }) + "\n")
            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                stdout = io.StringIO()
                with mock.patch.dict(os.environ, {"TAP_INDEX_HOME": str(root / "index")}), \
                     contextlib.redirect_stdout(stdout):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            payload = json.loads(stdout.getvalue())
            self.assertIn(registry_id, payload["argv"])
            self.assertNotIn(stale_id, payload["argv"])
            self.assertEqual(manifest.read_text(), poison)

    def test_resume_idless_registry_row_ignores_derived_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            derived_id = "019c3333-4444-7555-8666-777777777777"
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            registry.write_text(json.dumps({
                "team": {"name": "repo", "worktree_root": str(root)},
                "agents": {"planner": {
                    "status": "active",
                    "delivery": "pane",
                    "session": "repo/planner",
                    "harness": "codex",
                    "derived_harness_session_id": derived_id,
                    "registered_from_worktree": str(root),
                }},
            }) + "\n")
            args = types.SimpleNamespace(
                key="planner", legacy_name=None, all=False, model=None,
                teams=False, dry_run=True, json=True,
            )

            old_cwd = pathlib.Path.cwd()
            try:
                os.chdir(root)
                stdout = io.StringIO()
                with mock.patch.dict(os.environ, {"TAP_INDEX_HOME": str(root / "index")}), \
                     contextlib.redirect_stdout(stdout):
                    rc = launcher.cmd_resume(args)
            finally:
                os.chdir(old_cwd)

            self.assertEqual(rc, 0)
            payload = json.loads(stdout.getvalue())
            self.assertNotIn(derived_id, payload["argv"])
            self.assertEqual(payload["argv"][-1], "resume")
            self.assertNotIn("019a1111-2222-7333-8444-555555555555", payload["argv"])


class PruneAndResumabilityTests(unittest.TestCase):
    # --- DP2: resumability-gated exists-check --------------------------------

    def _mnr_args(self, tag, harness="claude"):
        return types.SimpleNamespace(
            harness=harness, unique=None, tag=tag, label=None,
            model=None, teams=False, dry_run=False, manifest="/nonexistent",
        )

    def test_record_has_resume_artifact_claude_corpse_is_not_resumable(self):
        # A claude record with a minted uuid but no transcript on disk (the
        # 2026-07-12 repro shape) has no artifact to hand back. The projects dir
        # EXISTS but holds no matching transcript — that is "missing", distinct
        # from an absent projects dir (which fails closed; see the F3 test).
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp) / "home"
            (home / "projects").mkdir(parents=True)
            record = launcher.SessionRecord(
                name="xx/corpse", harness="claude", cwd=tmp, base="xx",
                tag="corpse", harness_session_id="00000000-dead-4000-8000-000000000000",
            )
            with mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}):
                self.assertFalse(launcher.record_has_resume_artifact(record))

    def test_record_has_resume_artifact_fails_closed_when_projects_dir_absent(self):
        # F3 (grok8): an absent projects dir (wrong/empty TAP_CLAUDE_HOME) is
        # cannot-verify, NOT missing — the --verify-resumable destructive tier must
        # never sweep a real transcript it simply failed to see.
        with tempfile.TemporaryDirectory() as tmp:
            record = launcher.SessionRecord(
                name="xx/corpse", harness="claude", cwd=tmp, base="xx",
                tag="corpse", harness_session_id="00000000-dead-4000-8000-000000000000",
            )
            with mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(pathlib.Path(tmp) / "does-not-exist")}):
                self.assertTrue(launcher.record_has_resume_artifact(record))

    def test_record_has_resume_artifact_claude_with_transcript_is_resumable(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp) / "home"
            hsid = "11111111-2222-4333-8444-555555555555"
            proj = home / "projects" / "some-proj"
            proj.mkdir(parents=True)
            (proj / f"{hsid}.jsonl").write_text("{}\n")
            record = launcher.SessionRecord(
                name="xx/live", harness="claude", cwd=tmp, base="xx",
                tag="live", harness_session_id=hsid,
            )
            with mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}):
                self.assertTrue(launcher.record_has_resume_artifact(record))

    def test_record_has_resume_artifact_claude_uses_durable_transcript_after_id_rotation(self):
        with tempfile.TemporaryDirectory() as tmp:
            transcript = pathlib.Path(tmp) / "projects" / "some-proj" / "original-id.jsonl"
            transcript.parent.mkdir(parents=True)
            transcript.write_text("{}\n")
            record = launcher.SessionRecord(
                name="xx/live", harness="claude", cwd=tmp, base="xx",
                tag="live", harness_session_id="rotated-id",
                transcript_path=str(transcript), history=["original-id"],
            )

            self.assertTrue(launcher.record_has_resume_artifact(record))

    def test_make_new_record_ignores_dead_tagged_record_and_notes_it(self):
        cwd = str(pathlib.Path.cwd().resolve())
        # Dead: null hsid, no live tmux, no seat.
        dead = launcher.SessionRecord(
            name=launcher.named_session_name("xx", "authz"), harness="claude",
            cwd=cwd, base="xx", tag="authz", index=1, harness_session_id=None,
        )
        manifest = launcher.Manifest(sessions=[dead], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        args = self._mnr_args("authz")
        stderr = io.StringIO()
        with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
             mock.patch.object(launcher, "tap_handles", lambda _root: set()), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: None), \
             contextlib.redirect_stderr(stderr):
            record = launcher.make_new_record(args, manifest)
        # Launch proceeds (no SystemExit) reusing the same name — inline self-heal.
        self.assertEqual(record.name, dead.name)
        self.assertIn("ignoring leftover record", stderr.getvalue())
        self.assertIn("not on roster", stderr.getvalue())

    def test_make_new_record_not_on_roster_never_revives_manifest_history(self):
        """U5 / Ops 2026-07-30 intent-verb: launch-by-name with a leftover
        resumable manifest record and no roster row creates fresh — never
        offers or silently performs history revive (MVPAuditLogger repro)."""
        cwd = str(pathlib.Path.cwd().resolve())
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp) / "home"
            hsid = "22222222-2222-4333-8444-555555555555"
            proj = home / "projects" / "p"
            proj.mkdir(parents=True)
            (proj / f"{hsid}.jsonl").write_text("{}\n")
            resumable = launcher.SessionRecord(
                name=launcher.named_session_name("xx", "authz"), harness="claude",
                cwd=cwd, base="xx", tag="authz", index=1, harness_session_id=hsid,
            )
            manifest = launcher.Manifest(sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
            args = self._mnr_args("authz")
            stderr = io.StringIO()
            with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                 mock.patch.object(launcher, "tap_handles", lambda _root: set()), \
                 mock.patch.object(launcher, "registry_entry", lambda _root, _tag: None), \
                 mock.patch.object(launcher, "prompt_new_collision",
                                   side_effect=AssertionError("launch must not offer revive off-roster")), \
                 mock.patch.object(launcher, "caller_has_tty", return_value=True), \
                 mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
                 mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}), \
                 contextlib.redirect_stderr(stderr):
                record = launcher.make_new_record(args, manifest)
            self.assertEqual(record.name, resumable.name)
            self.assertNotEqual(record.harness_session_id, hsid)
            self.assertNotEqual(record.ensure_action, "resume")
            self.assertFalse(any("resurrected" in r for r in record.ensure_receipts), record.ensure_receipts)
            self.assertIn("not on roster", stderr.getvalue())

    def test_make_new_record_gone_roster_noninteractive_refuses_with_three_doors(self):
        """A rostered GONE seat still owns its identity.

        Noninteractive launch must refuse and name resume, different-name, and
        explicit-fresh doors instead of silently replacing the seat.
        """
        cwd = str(pathlib.Path.cwd().resolve())
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp) / "home"
            hsid = "33333333-2222-4333-8444-555555555555"
            proj = home / "projects" / "p"
            proj.mkdir(parents=True)
            (proj / f"{hsid}.jsonl").write_text("{}\n")
            resumable = launcher.SessionRecord(
                name=launcher.named_session_name("xx", "authz"), harness="claude",
                cwd=cwd, base="xx", tag="authz", index=1, harness_session_id=hsid,
            )
            manifest = launcher.Manifest(sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
            args = self._mnr_args("authz")
            dead_entry = {
                "harness": "claude",
                "pane_id": "%999",
                "session": resumable.name,
                "status": "active",
                "harness_session_id": hsid,
                "session_attribution_trust": "env",
            }
            stderr = io.StringIO()
            with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                 mock.patch.object(launcher, "tap_handles", lambda _root: {"authz"}), \
                 mock.patch.object(launcher, "registry_entry", lambda _root, _tag: dead_entry), \
                 mock.patch.object(launcher, "tmux_pane_facts", lambda _target: None), \
                 mock.patch.object(launcher, "entry_observed_dead", return_value=True), \
                 mock.patch.object(launcher, "caller_has_tty", return_value=False), \
                 mock.patch.object(sys, "stdin", TtyBuffer(tty=False)), \
                 mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}), \
                 contextlib.redirect_stderr(stderr):
                with self.assertRaises(SystemExit) as raised:
                    launcher.make_new_record(args, manifest)
            self.assertEqual(raised.exception.code, 2)
            self.assertIn("tap session resume authz", stderr.getvalue())
            self.assertIn("tap session launch claude authz-2", stderr.getvalue())
            self.assertIn("tap session launch claude authz --fresh", stderr.getvalue())

    def test_make_new_record_stdin_tty_but_stdout_piped_never_wedges_on_chooser(self):
        """grok P2 + U5: off-roster leftover record — no chooser (would wedge),
        launch creates fresh rather than silently reviving history."""
        cwd = str(pathlib.Path.cwd().resolve())
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp) / "home"
            hsid = "55555555-2222-4333-8444-555555555555"
            proj = home / "projects" / "p"
            proj.mkdir(parents=True)
            (proj / f"{hsid}.jsonl").write_text("{}\n")
            resumable = launcher.SessionRecord(
                name=launcher.named_session_name("xx", "authz"), harness="claude",
                cwd=cwd, base="xx", tag="authz", index=1, harness_session_id=hsid,
            )
            manifest = launcher.Manifest(sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
            args = self._mnr_args("authz")
            with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                 mock.patch.object(launcher, "tap_handles", lambda _root: set()), \
                 mock.patch.object(launcher, "registry_entry", lambda _root, _tag: None), \
                 mock.patch.object(launcher, "prompt_new_collision",
                                   side_effect=AssertionError("stdout-piped caller must NOT be prompted (would wedge)")), \
                 mock.patch.object(launcher, "prompt_session_exists",
                                   side_effect=AssertionError("stdout-piped caller must NOT be prompted (would wedge)")), \
                 mock.patch.object(launcher, "caller_has_tty", return_value=False), \
                 mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
                 mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}), \
                 contextlib.redirect_stderr(io.StringIO()):
                record = launcher.make_new_record(args, manifest)
            self.assertNotEqual(record.harness_session_id, hsid)
            self.assertNotEqual(record.ensure_action, "resume")

    def test_make_new_record_non_tty_off_roster_creates_fresh_silently(self):
        """U5: non-TTY launch with leftover manifest history and no roster row
        creates fresh without wedging on a prompt (history restore is resume)."""
        cwd = str(pathlib.Path.cwd().resolve())
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp) / "home"
            hsid = "44444444-2222-4333-8444-555555555555"
            proj = home / "projects" / "p"
            proj.mkdir(parents=True)
            (proj / f"{hsid}.jsonl").write_text("{}\n")
            resumable = launcher.SessionRecord(
                name=launcher.named_session_name("xx", "authz"), harness="claude",
                cwd=cwd, base="xx", tag="authz", index=1, harness_session_id=hsid,
            )
            manifest = launcher.Manifest(sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
            args = self._mnr_args("authz")
            with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                 mock.patch.object(launcher, "tap_handles", lambda _root: set()), \
                 mock.patch.object(launcher, "registry_entry", lambda _root, _tag: None), \
                 mock.patch.object(launcher, "prompt_new_collision",
                                   side_effect=AssertionError("must not prompt a non-TTY caller")), \
                 mock.patch.object(sys, "stdin", TtyBuffer(tty=False)), \
                 mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}), \
                 contextlib.redirect_stderr(io.StringIO()):
                record = launcher.make_new_record(args, manifest)
            self.assertNotEqual(record.harness_session_id, hsid)
            self.assertNotEqual(record.ensure_action, "resume")

    # --- DP1: dead-record criterion + prune verb -----------------------------

    def _assert_prune_keeps_ghost_healed_under_lock(mod):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp) / "repo"
            root.mkdir()
            path = root / "sessions.json"
            keeper = mod.SessionRecord(name="repo/keep", harness="codex", cwd=str(root),
                                       base="repo", tag="keep", harness_session_id="cx1")
            dead_ghost = mod.SessionRecord(name="repo/ghost", harness="claude", cwd=str(root),
                                           base="repo", tag="ghost", harness_session_id=None)
            live_ghost = dataclasses.replace(dead_ghost, harness_session_id="live-uuid")
            mod.save_manifest(path, mod.Manifest(dir_aliases={str(root): "repo"},
                                                 sessions=[dead_ghost, keeper]))
            real_lock = mod.manifest_lock
            state = {"healed": False}

            @contextlib.contextmanager
            def racing_lock(p, **kw):
                with real_lock(p, **kw):
                    if not state["healed"]:
                        state["healed"] = True  # commit the self-heal INSIDE the lock
                        mod.save_manifest(p, mod.Manifest(
                            dir_aliases={str(root): "repo"}, sessions=[live_ghost, keeper]))
                    yield

            args = types.SimpleNamespace(manifest=str(path), root=str(root), all=False,
                                         dry_run=False, json=False, verify_resumable=False)
            with mock.patch.object(mod, "tmux_sessions", lambda: set()), \
                 mock.patch.object(mod, "tap_handles", lambda _root: set()), \
                 mock.patch.object(mod, "manifest_lock", racing_lock), \
                 contextlib.redirect_stdout(io.StringIO()):
                mod.cmd_prune(args)
            names = {r.name for r in mod.load_manifest(path).sessions}
            assert "repo/ghost" in names, f"live-under-lock ghost was deleted: {names}"
            assert "repo/keep" in names, names

class ResetAndBootEpochTests(unittest.TestCase):
    def test_pending_reservation_prior_boot_expires_when_tmux_is_unobservable(self):
        preboot = {
            "status": "pending",
            "session": "repo/scout",
            "boot_id": "bootuuid:prior",
            "registered_at": "2999-01-01T00:00:00Z",
        }

        self.assertTrue(
            launcher.seat_corpse.launch_reservation_expired(
                preboot,
                live_sessions=None,
                now_epoch=0,
                boot_now="bootuuid:current",
            )
        )

    def test_singular_launch_paths_reclaim_prior_boot_pending_row_when_tmux_is_unobservable(self):
        cases = (
            ("launch", lambda record: launcher.prepare_new_launch(record)),
            (
                "singular-resume",
                lambda record: launcher.prepare_launch_transaction(
                    record,
                    "2026-08-07T00:00:00Z",
                    allow_same_session=True,
                ),
            ),
            (
                "restart",
                lambda record: launcher.prepare_launch_transaction(
                    record,
                    "2026-08-07T00:00:00Z",
                    allow_same_session=True,
                    failure_reason="restart_failed",
                ),
            ),
        )

        for label, invoke in cases:
            with self.subTest(path=label), tempfile.TemporaryDirectory() as tmp:
                root = pathlib.Path(tmp)
                registry = root / ".tap" / "bus" / "registry.json"
                registry.parent.mkdir(parents=True)
                registry.write_text(json.dumps({
                    "team": {"name": "repo", "worktree_root": str(root)},
                    "agents": {
                        "scout": {
                            "status": "pending",
                            "delivery": "pane",
                            "session": "repo/scout",
                            "harness": "claude",
                            "registered_at": "2999-01-01T00:00:00Z",
                            "launch_id": "orphaned-launch",
                            "boot_id": "bootuuid:prior",
                        },
                    },
                }) + "\n")
                record = launcher.SessionRecord(
                    name="repo/scout",
                    harness="claude",
                    cwd=str(root),
                    base="repo",
                    tag="scout",
                    index=1,
                )

                with mock.patch.object(launcher, "tmux_sessions_or_none", return_value=None), \
                     mock.patch.object(launcher, "writable_tap_registry_path", return_value=registry), \
                     mock.patch.object(launcher, "current_boot_id", return_value="bootuuid:current"):
                    invoke(record)

                row = json.loads(registry.read_text())["agents"]["scout"]
                self.assertEqual(row["status"], "pending")
                self.assertNotEqual(row["launch_id"], "orphaned-launch")
                self.assertEqual(row["boot_id"], "bootuuid:current")

    def test_pending_reservation_prior_boot_is_expired_without_grace(self):
        with mock.patch.dict(os.environ, {"TAP_BOOT_ID": "boot:2000"}):
            preboot = {"status": "pending", "session": "x/y", "boot_id": "boot:1000",
                       "registered_at": "2999-01-01T00:00:00Z"}  # far-future = grace NOT elapsed
            self.assertTrue(launcher.pending_reservation_expired(preboot, live_sessions=set()))
            same = {**preboot, "boot_id": "boot:2000"}
            self.assertFalse(launcher.pending_reservation_expired(same, live_sessions=set()))
            # A live reserved session is never a corpse, even across a boot mismatch.
            self.assertFalse(launcher.pending_reservation_expired(preboot, live_sessions={"x/y"}))

    def test_claim_pending_handle_stamps_boot_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            (root / ".tap" / "bus").mkdir(parents=True)
            record = launcher.SessionRecord(name=f"{root.name}/scout", harness="claude",
                                            cwd=str(root), base=root.name, tag="scout", index=1)
            with mock.patch.dict(os.environ, {"TAP_BOOT_ID": "boot:1234"}):
                launcher.claim_pending_handle(record)
            reg = json.loads((root / ".tap" / "bus" / "registry.json").read_text())
            self.assertEqual(reg["agents"]["scout"]["boot_id"], "boot:1234")


class SessionPresetGrammarTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.config_home = self.root / "config"
        self.path = self.config_home / "tap" / "presets.toml"
        self.environ = {
            "HOME": str(self.root / "home"),
            "XDG_CONFIG_HOME": str(self.config_home),
        }
        (self.root / "home").mkdir()

    def write_config(self, body=None):
        if body is None:
            body = """\
version = 2
[presets.sol-max]
harness = "codex"
params.model = "gpt-5.6-sol"
params.effort = "max"
[presets.glm-opencode]
harness = "opencode"
params.model = "glm-4.7"
params.provider = "zai"
[presets.claude-team]
harness = "claude"
"""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(body)
        self.path.chmod(0o600)

    def test_a_familys_note_is_printed_when_the_preset_resolves(self):
        # The gate's finding, pinned. `family` bound a note that NOTHING read, while the docs
        # said it followed the seat — plumbing with a documented faucet that did not exist.
        # This asserts the faucet at the launcher, not the binding in presets.py: a mutation
        # replacing the emit with `pass` left the entire 545-test suite green, because every
        # other family test checks resolution and none checked that anyone consumed it.
        self.write_config(
            'version = 2\n'
            '[presets.sol-max]\nharness = "codex"\nfamily = "codex"\n'
            '[notes]\ncodex = "Prefer she/her pronouns"\n'
        )
        notices = []
        with mock.patch.object(preset_config, "emit_notice", notices.append):
            args = self.resolve(["sol-max", "worker"])
        self.assertEqual(args.preset_resolution.note, "Prefer she/her pronouns")
        self.assertEqual(
            [n for n in notices if "she/her" in n],
            ["tap session: sol-max — Prefer she/her pronouns"],
        )

        # A preset with no family says nothing — the note is the whole reason the key exists,
        # so a launch that did not ask for one must stay quiet.
        self.write_config(
            'version = 2\n[presets.plain]\nharness = "codex"\n[notes]\ncodex = "unused"\n'
        )
        notices.clear()
        with mock.patch.object(preset_config, "emit_notice", notices.append):
            self.resolve(["plain", "worker"])
        # Filtered to the NOTE, not asserted as total silence: this class's fixture writes the
        # legacy presets.toml path, so the migration notice legitimately fires here. Demanding
        # an empty list would have failed for a reason that has nothing to do with `family`.
        self.assertEqual([n for n in notices if "unused" in n], [])

    def test_metadata_is_printed_when_the_preset_resolves(self):
        self.write_config(
            'version = 2\n'
            '[roles]\nreviewer = "Reviews"\nimplementer = "Implements"\n'
            '[presets.grok]\nharness = "codex"\n'
            '[presets.grok.metadata]\n'
            'primary_roles = ["reviewer", "implementer"]\n'
            'summary = "Adversarial sparring"\n'
        )
        notices = []
        with mock.patch.object(preset_config, "emit_notice", notices.append):
            args = self.resolve(["grok", "worker"])
        self.assertIn(
            "tap session: grok — reviewer, implementer — Adversarial sparring",
            notices,
        )
        self.assertEqual(args.harness, "codex")
        self.assertEqual(args.preset_resolution.model, None)

    def parse_new(self, argv):
        owned, passthrough = launcher.split_new_passthrough(["new", *argv])
        args = launcher.build_parser().parse_args(owned)
        args.harness_passthrough = passthrough
        return args

    def resolve(self, argv):
        args = self.parse_new(argv)
        with mock.patch.dict(os.environ, self.environ, clear=False):
            launcher.resolve_new_preset_args(args)
        return args

    def assert_preset_error(self, error_class, argv, *parts):
        with self.assertRaises(preset_config.PresetError) as raised:
            self.resolve(argv)
        self.assertEqual(raised.exception.error_class, error_class)
        for part in parts:
            self.assertIn(part, raised.exception.detail)
        return raised.exception

    def test_bare_and_explicit_forms_resolve_to_same_harness_and_label(self):
        self.write_config()

        bare = self.resolve(["sol-max", "worker", "--dry-run", "--json"])
        explicit = self.resolve(
            ["--preset", "sol-max", "worker", "--dry-run", "--json"]
        )

        for args in (bare, explicit):
            self.assertEqual(args.harness, "codex")
            self.assertEqual(args.label, "worker")
            self.assertEqual(args.preset_resolution.provenance.name, "sol-max")
        self.assertEqual(bare.preset_resolution, explicit.preset_resolution)

    def test_matching_harness_compatibility_form_succeeds(self):
        self.write_config()

        args = self.resolve(
            ["opencode", "worker", "--preset", "glm-opencode", "--dry-run"]
        )

        self.assertEqual(args.harness, "opencode")
        self.assertEqual(args.label, "worker")
        self.assertEqual(args.preset_resolution.model, "glm-4.7")
        self.assertEqual(
            args.preset_resolution.harness_passthrough, ("--provider", "zai")
        )

    def test_single_matching_compatibility_harness_is_not_misread_as_label(self):
        self.write_config()

        args = self.resolve(["opencode", "--preset", "glm-opencode"])

        self.assertEqual(args.harness, "opencode")
        self.assertIsNone(args.label)

    def test_mismatching_compatibility_harness_refuses(self):
        self.write_config()

        self.assert_preset_error(
            "preset_harness_mismatch",
            ["codex", "worker", "--preset", "glm-opencode"],
            "codex",
            "opencode",
            "glm-opencode",
        )

    def test_explicit_missing_name_retains_unambiguous_not_found_class(self):
        self.write_config()

        error = self.assert_preset_error(
            "preset_not_found",
            ["--preset", "missing", "worker"],
            "missing",
            str(self.path.resolve()),
        )
        self.assertIn("sol-max", error.action)

    def test_unknown_first_positional_names_both_possibilities_and_availability(self):
        self.write_config()

        error = self.assert_preset_error(
            "harness_or_preset_not_found",
            ["codx", "worker"],
            "codx",
            "harness",
            "preset",
            "codex",
            "claude",
            "sol-max",
            "glm-opencode",
        )
        self.assertIn("tap session launch", error.action)

    def test_unknown_first_positional_with_no_config_stays_ambiguous(self):
        error = self.assert_preset_error(
            "harness_or_preset_not_found",
            ["codx", "worker"],
            "codx",
            "harness",
            "preset",
            "codex",
            "no preset config",
        )
        self.assertNotEqual(error.error_class, "preset_config_missing")

    def test_direct_harness_performs_zero_config_io(self):
        self.write_config("version = [malformed")
        args = self.parse_new(["codex", "worker", "--dry-run"])

        with mock.patch.object(
            preset_config,
            "load_preset_catalog",
            side_effect=AssertionError("direct harness loaded presets"),
        ):
            launcher.resolve_new_preset_args(args)

        self.assertEqual(args.harness, "codex")
        self.assertEqual(args.label, "worker")
        self.assertIsNone(args.preset_resolution)

    def test_owned_preset_spellings_never_enter_passthrough(self):
        cases = (
            ["new", "codex", "worker", "--preset", "sol-max"],
            ["new", "codex", "worker", "--preset=sol-max"],
        )
        for argv in cases:
            with self.subTest(argv=argv):
                owned, passthrough = launcher.split_new_passthrough(argv)
                self.assertEqual(passthrough, [])
                self.assertTrue(
                    "--preset" in owned
                    or any(atom.startswith("--preset=") for atom in owned)
                )

    def test_preset_spelling_after_passthrough_refuses_instead_of_forwarding(self):
        cases = (
            ["new", "codex", "worker", "-c", "x=y", "--preset", "sol-max"],
            ["new", "codex", "worker", "-c", "x=y", "--preset=sol-max"],
            ["new", "codex", "worker", "--", "--preset", "sol-max"],
            ["new", "codex", "worker", "--", "--preset=sol-max"],
        )
        for argv in cases:
            with self.subTest(argv=argv), self.assertRaises(
                preset_config.PresetError
            ) as raised:
                launcher.split_new_passthrough(argv)
            self.assertEqual(raised.exception.error_class, "preset_passthrough")
            self.assertIn("never forwarded", raised.exception.detail)

    def test_explicit_json_failure_uses_preset_error_class_without_stderr(self):
        self.write_config()
        stdout = io.StringIO()
        stderr = io.StringIO()

        with mock.patch.dict(os.environ, self.environ, clear=False), \
             contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            rc = launcher.main(
                ["new", "--preset", "missing", "worker", "--dry-run", "--json"]
            )

        self.assertEqual(rc, 2)
        self.assertEqual(stderr.getvalue(), "")
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["error_class"], "preset_not_found")


class SessionPresetRecordTests(unittest.TestCase):
    def resolution(
        self,
        *,
        name="sol-pinnacle-xhigh",
        harness="codex",
        model="gpt-5.6-sol",
        passthrough=("-c", 'model_reasoning_effort="xhigh"'),
        env=None,
    ):
        return preset_config.ResolvedPreset(
            harness=harness,
            model=model,
            harness_passthrough=passthrough,
            env={"PONYTAIL_DEFAULT_MODE": "full"} if env is None else env,
            provenance=preset_config.PresetProvenance(
                name=name,
                source_path="/Users/user/.config/tap/presets.toml",
                config_digest="sha256:" + "a" * 64,
            ),
        )

    def args(self, *, resolution=None, model=None, passthrough=None):
        return types.SimpleNamespace(
            model=model,
            harness_passthrough=[] if passthrough is None else passthrough,
            preset_resolution=resolution,
        )

    def test_value_object_round_trips_effective_env_and_exact_provenance(self):
        provenance = {
            "name": "sol-pinnacle-xhigh",
            "source_path": "/Users/user/.config/tap/presets.toml",
            "config_digest": "sha256:" + "a" * 64,
        }
        record = launcher.SessionRecord(
            name="tap/sol",
            harness="codex",
            cwd="/tmp",
            base="tap",
            harness_env={"PONYTAIL_DEFAULT_MODE": "full"},
            preset=provenance,
        )

        data = record.to_dict()
        restored = launcher.SessionRecord.from_dict(data)

        self.assertEqual(data["harness_env"], {"PONYTAIL_DEFAULT_MODE": "full"})
        self.assertEqual(data["preset"], provenance)
        self.assertEqual(restored.harness_env, record.harness_env)
        self.assertEqual(restored.preset, provenance)
        self.assertIsNot(restored.harness_env, record.harness_env)
        self.assertIsNot(restored.preset, provenance)

    def test_a_row_persisted_with_teams_still_loads_and_does_not_resurrect_the_field(self):
        # U5's compatibility contract. Rows written before the field was dropped, and every
        # backup archive taken then, still carry `teams`. Loading must neither raise nor bring
        # the field back — such a row now expresses agent teams the same way everything else
        # does, as environment. Zero live rows carry it, so this is about archives and
        # rollbacks rather than a migration.
        legacy = launcher.SessionRecord.from_dict(
            {"name": "tap/legacy", "harness": "claude", "cwd": "/tmp", "teams": True}
        )
        self.assertEqual(legacy.name, "tap/legacy")
        # Not `assertFalse(legacy.teams)` — that would pass on a resurrected field defaulting
        # to False, which is exactly the regression this pins against.
        #
        # DO NOT DELETE AS REDUNDANT. This pin is load-bearing for a second test that no longer
        # looks like it needs one: test_native_resume_builder_originates_no_env_either used to
        # pass teams=True to induce the deleted claude branch, and its comment now argues the
        # regression "cannot be written" because `record.teams` would raise. That is only true
        # WHILE THE FIELD STAYS DELETED — and this assertion is what keeps it deleted. The two
        # cover each other's gap: re-adding the field reds this test, and re-adding the branch
        # without the field crashes loudly. Remove this and the other test's guarantee quietly
        # becomes an argument instead of a check.
        self.assertFalse(hasattr(legacy, "teams"))
        self.assertNotIn("teams", legacy.to_dict())
        # And the value does not survive by another route into what the seat receives.
        self.assertEqual(legacy.harness_env, {})

    def test_old_and_malformed_rows_default_additively(self):
        old = launcher.SessionRecord.from_dict(
            {"name": "tap/old", "harness": "codex", "cwd": "/tmp"}
        )
        self.assertEqual(old.harness_env, {})
        self.assertIsNone(old.preset)
        self.assertNotIn("harness_env", old.to_dict())
        self.assertNotIn("preset", old.to_dict())

        malformed = launcher.SessionRecord.from_dict(
            {
                "name": "tap/bad",
                "harness": "codex",
                "cwd": "/tmp",
                "harness_env": {"GOOD": "value", "BAD": 4, 5: "no"},
                "preset": {
                    "name": "tier",
                    "source_path": "/tmp/presets.toml",
                    "config_digest": "sha256:" + "b" * 64,
                    "extra": "not accepted",
                },
            }
        )
        self.assertEqual(malformed.harness_env, {"GOOD": "value"})
        self.assertIsNone(malformed.preset)

    def test_registry_row_round_trips_and_direct_record_clears_stale_fields(self):
        provenance = {
            "name": "sol-max",
            "source_path": "/Users/user/.config/tap/presets.toml",
            "config_digest": "sha256:" + "c" * 64,
        }
        record = launcher.SessionRecord(
            name="tap/sol",
            harness="codex",
            cwd="/work/tap",
            base="tap",
            tag="sol",
            harness_env={"PONYTAIL_DEFAULT_MODE": "full"},
            preset=provenance,
        )
        row = {}

        launcher.store_session_record_fields(row, record)
        restored = launcher.session_record_from_registry_row(
            "sol", row, {"name": "tap", "worktree_root": "/work/tap"}, "/work/tap"
        )

        self.assertEqual(row["harness_env"], record.harness_env)
        self.assertEqual(row["preset"], provenance)
        self.assertEqual(restored.harness_env, record.harness_env)
        self.assertEqual(restored.preset, provenance)

        launcher.store_session_record_fields(
            row,
            launcher.SessionRecord(
                name="tap/direct", harness="codex", cwd="/work/tap", base="tap"
            ),
        )
        self.assertNotIn("harness_env", row)
        self.assertNotIn("preset", row)

    def test_a_preset_supplies_the_model_and_env_it_resolved(self):
        # Supersedes test_preset_tuning_precedence_is_preset_then_explicit_cli (panel ruling,
        # 2026-08-11): a preset is COMPLETE, so there is no CLI-over-preset precedence left to
        # assert here. --model alongside --preset now refuses upstream; see
        # test_preset_refuses_to_compose_with_adhoc_tuning for that half of the contract.
        resolved = self.resolution()

        model, passthrough, env, provenance, from_config = launcher.resolve_new_record_tuning(
            self.args(resolution=resolved), None, False
        )
        self.assertEqual(model, "gpt-5.6-sol")
        self.assertEqual(passthrough, list(resolved.harness_passthrough))
        self.assertEqual(env, resolved.env)
        self.assertEqual(provenance["name"], "sol-pinnacle-xhigh")
        self.assertTrue(from_config)

        # Explicit tails are applied after the preserved preset baseline.
        model, passthrough, env, provenance, from_config = launcher.resolve_new_record_tuning(
            self.args(
                resolution=resolved,
                passthrough=["-c", "model_reasoning_effort=low"],
            ),
            None,
            False,
        )
        self.assertEqual(model, "gpt-5.6-sol")
        self.assertEqual(passthrough, list(resolved.harness_passthrough))
        self.assertEqual(env, resolved.env)
        self.assertEqual(provenance["config_digest"], resolved.provenance.config_digest)
        self.assertTrue(from_config)

    def test_preset_refuses_to_compose_with_adhoc_tuning(self):
        for flag, kwargs in (
            ("--model", {"model": "gpt-explicit"}),
            ("--effort", {"effort": "high"}),
        ):
            with self.subTest(flag=flag):
                fields = {
                    "preset": "sol-pinnacle-xhigh",
                    "harness": None,
                    "label": None,
                    "model": None,
                    "effort": None,
                    "env": None,
                }
                fields.update(kwargs)
                args = launcher.argparse.Namespace(**fields)
                # A real catalog is required: exclusivity is only meaningful once the name
                # resolves to an actual preset (see the harness-typo test below).
                with self.exclusivity_catalog(), \
                     self.assertRaises(preset_config.PresetError) as caught:
                    launcher.resolve_new_preset_args(args)
                self.assertEqual(caught.exception.error_class, "preset_not_composable")
                # The refusal must name the flag the operator typed, not just complain.
                self.assertIn(flag, caught.exception.detail)

    def exclusivity_catalog(self):
        """A config whose catalog actually contains the preset the exclusivity tests name."""
        return self.harness_config(
            'version = 2\n[presets.sol-pinnacle-xhigh]\nharness = "codex"\n'
            'params.model = "gpt-5.6-sol"\n'
        )

    @contextlib.contextmanager
    def harness_config(self, body: str):
        """Point the launcher at a temp operator config for the duration of a block."""
        with tempfile.TemporaryDirectory() as tmp:
            config = pathlib.Path(tmp) / "tap" / "config.toml"
            config.parent.mkdir(parents=True)
            config.write_text(body, encoding="utf-8")
            config.chmod(0o600)
            with mock.patch.dict(os.environ, {"XDG_CONFIG_HOME": tmp}, clear=False):
                yield config

    def env_for(self, record, action="new"):
        return launcher.apply_launch_env(
            launcher.build_harness_invocation(action, record), record
        ).env

    def record_for(self, harness="codex", **fields):
        base = {
            "name": f"tap/{harness}-probe",
            "harness": harness,
            "cwd": "/work/tap",
            "base": "tap",
        }
        base.update(fields)
        return launcher.SessionRecord(**base)

    def test_harness_tier_reaches_launch_and_resume_without_any_migration(self):
        # The load-bearing scenario for the whole design. The record predates the policy and
        # carries no harness_env at all; if the value only arrived via the record, an existing
        # seat would need a migration to pick it up. It arrives on RESUME too, which is what
        # lets the sweep, the admin verb, and the doctor tripwire all not exist.
        record = self.record_for(harness_env={})
        with self.harness_config('version = 2\n[harness.codex.env]\nFOO = "bar"\n'):
            self.assertEqual(self.env_for(record, "new").get("FOO"), "bar")
            self.assertEqual(self.env_for(record, "resume").get("FOO"), "bar")

    def test_harness_tier_now_supplies_the_key_the_builders_used_to_hardcode(self):
        # The flip this pin was written for. Before the deletion the builders emitted
        # PONYTAIL_DEFAULT_MODE and shadowed the harness table, so this asserted "off" (the
        # builder's value) against a table saying "lite". With the builders gone the table is
        # the only source, and the same scenario must now yield the table's value. Asserting
        # the FLIP rather than replacing the test keeps the transition legible: the merge
        # order never changed, only what feeds it.
        record = self.record_for()
        with self.harness_config(
            'version = 2\n[harness.codex.env]\nPONYTAIL_DEFAULT_MODE = "lite"\n'
        ):
            self.assertEqual(self.env_for(record).get("PONYTAIL_DEFAULT_MODE"), "lite")
        # And with no config at all, nothing supplies it — the harness sees its own default.
        record_no_config = self.record_for()
        self.assertNotIn("PONYTAIL_DEFAULT_MODE", self.env_for(record_no_config))

    def test_seat_intent_outranks_machine_policy(self):
        # Ops's anti-duplication example, asserted literally: the harness table says it once,
        # a preset (or --env) overrides it for the seat that wants something else.
        record = self.record_for(harness_env={"FOO": "from-seat"})
        with self.harness_config(
            'version = 2\n[harness.codex.env]\nFOO = "from-machine"\nBAR = "machine-only"\n'
        ):
            env = self.env_for(record)
            self.assertEqual(env.get("FOO"), "from-seat")
            # BAR proves the tier was actually LIVE while FOO was overridden. Without it this
            # test passes just as happily when tier 2 never arrives at all — it could not tell
            # "the seat won" from "there was nothing to win against".
            self.assertEqual(env.get("BAR"), "machine-only")

    def test_harness_tier_is_read_fresh_rather_than_frozen_into_the_seat(self):
        # The deliberate dual of the preset no-reread contract: preset VALUES stay frozen in
        # the record, while machine policy is re-read every time. Editing the table changes the
        # next resume of an existing seat — that is the migration-free property in motion.
        record = self.record_for(harness_env={})
        with self.harness_config('version = 2\n[harness.codex.env]\nFOO = "before"\n') as config:
            self.assertEqual(self.env_for(record, "resume").get("FOO"), "before")
            config.write_text(
                'version = 2\n[harness.codex.env]\nFOO = "after"\n', encoding="utf-8"
            )
            self.assertEqual(self.env_for(record, "resume").get("FOO"), "after")

    def test_harness_tier_never_enters_the_persisted_record(self):
        # Policy belongs to the machine; the record stays portable. If tier 2 leaked into the
        # row, moving that row to another machine would carry a foreign machine's policy.
        record = self.record_for(harness_env={})
        row = {}
        with self.harness_config('version = 2\n[harness.codex.env]\nFOO = "bar"\n'):
            self.env_for(record)
            launcher.store_session_record_fields(row, record)
        self.assertNotIn("harness_env", row)

    def test_a_broken_config_does_not_block_a_launch_or_a_resume(self):
        # Resume is the recovery verb. If a config typo could stop it, the operator would need
        # the seats they cannot start in order to fix the file that is stopping them.
        record = self.record_for()
        with self.harness_config("version = 2\n[harness.codex.env\nFOO =\n"):
            for action in ("new", "resume"):
                with self.subTest(action=action):
                    # The launch is BUILT — that is the whole claim. Policy is not applied
                    # (tier 2 resolved empty and said so), and the harness will fall back to
                    # its own default, which is the accepted louder degradation.
                    invocation = launcher.build_harness_invocation(action, record)
                    env = launcher.apply_launch_env(invocation, record).env
                    self.assertEqual(invocation.argv[0], "codex")
                    self.assertNotIn("FOO", env)
                    self.assertNotIn("PONYTAIL_DEFAULT_MODE", env)

    def env_and_notices(self, record, ambient, action="new"):
        """Compose the launch env under a given shell, capturing what the operator was told."""
        notices = []
        with mock.patch.dict(os.environ, ambient, clear=False), \
             mock.patch.object(preset_config, "emit_notice", notices.append):
            env = self.env_for(record, action)
        return env, notices

    def test_a_declared_value_beats_the_shell_and_says_so_once(self):
        # panel ruling (2026-08-11). The shell used to win silently, so `tap session launch sol`
        # produced one seat in a terminal that had exported FOO and a different one in a
        # terminal that had not, with nothing distinguishing them afterwards.
        record = self.record_for(harness_env={"FOO": "declared"})
        env, notices = self.env_and_notices(record, {"FOO": "from-shell"})
        self.assertEqual(env["FOO"], "declared")
        self.assertEqual(
            notices,
            ["tap session: overriding ambient ENV var FOO with the declared value"],
        )
        # The ambient value is not echoed. The fence keeps credential-shaped keys out of a
        # declared table, but this line is one an operator pastes into a chat, so the shape of
        # the warning should not depend on the fence holding.
        self.assertNotIn("from-shell", notices[0])

    def test_the_warning_matrix_covers_every_source_surface_and_polarity(self):
        # The plan's own scenario, run as a grid rather than as the one launch case I wrote
        # first. Two things it catches that a single cell cannot:
        #
        # RESUME. The merge point runs on resume too, so a seat resumed from a shell that
        # exports one of its declared keys must warn there as well. The resume cells carry
        # `ensure_action="resume"` on the RECORD, not just a "resume" argument to the argv
        # builder: with the default record, both halves of this axis are new-launch records
        # that differ only in argv, and a merge scoped to `record.ensure_action == "new"` stays
        # green through the whole grid. That mutation was run and did exactly that until the
        # field was set here.
        #
        # SOURCE. Tier 2 ([harness.*], re-read every invocation) and tier 3 (the record) reach
        # the merge point by different routes, and only the merged dict is compared — so both
        # must behave identically. `--env` and a preset are NOT separate cells here on purpose:
        # both land in `record.harness_env` before this code runs, so a cell for each would
        # assert the same object twice and read as coverage it is not. Their divergence is
        # upstream, in resolution, and is pinned there.
        for source in ("harness table", "record"):
            for action in ("new", "resume"):
                for polarity, ambient, expect in (
                    ("differs", {"FOO": "from-shell"}, ["FOO"]),
                    ("agrees", {"FOO": "declared"}, []),
                ):
                    with self.subTest(source=source, action=action, polarity=polarity):
                        fields = {"ensure_action": action}
                        if source == "record":
                            record = self.record_for(
                                harness_env={"FOO": "declared"}, **fields
                            )
                            config = contextlib.nullcontext()
                        else:
                            record = self.record_for(harness_env={}, **fields)
                            config = self.harness_config(
                                'version = 2\n[harness.codex.env]\nFOO = "declared"\n'
                            )
                        with config:
                            env, notices = self.env_and_notices(record, ambient, action)
                        self.assertEqual(env["FOO"], "declared")
                        self.assertEqual(
                            [n for n in notices if "ambient ENV var" in n],
                            [
                                "tap session: overriding ambient ENV var FOO"
                                " with the declared value"
                            ]
                            if expect
                            else [],
                        )

    def test_no_collision_is_silent_in_both_of_its_shapes(self):
        # A warning that fires when nothing was overridden trains the reader to ignore it, and
        # then the one real collision goes past unread.
        record = self.record_for(harness_env={"FOO": "same"})
        for label, ambient in (
            ("value agrees", {"FOO": "same"}),
            ("key unset", {}),
        ):
            with self.subTest(label):
                env, notices = self.env_and_notices(record, ambient)
                self.assertEqual(env["FOO"], "same")
                self.assertEqual(notices, [])

    def test_the_warning_names_the_value_that_actually_won(self):
        # gemini's catch, made mechanical. Warning per SOURCE rather than at the merge point
        # gets both of these wrong: the first would announce "from-machine", a value the seat
        # never sees, and the second would announce a collision against a shell whose value is
        # exactly what the seat ends up with. Only the merged result can answer either.
        record = self.record_for(harness_env={"FOO": "from-seat"})
        with self.harness_config('version = 2\n[harness.codex.env]\nFOO = "from-machine"\n'):
            env, notices = self.env_and_notices(record, {"FOO": "from-shell"})
            self.assertEqual(env["FOO"], "from-seat")
            self.assertEqual(
                notices,
                ["tap session: overriding ambient ENV var FOO with the declared value"],
            )

            # The shell already holds what the seat will get; the losing tier is not a
            # collision with anything.
            _, quiet = self.env_and_notices(record, {"FOO": "from-seat"})
            self.assertEqual(quiet, [])

    def test_the_quality_of_life_defaults_still_defer_to_the_shell(self):
        # Tier 1 is the deliberate exception: cosmetics the launcher originates itself, which
        # read the shell as their default and carry no audit weight. Sweeping them into the
        # inversion would warn an operator for setting their own scroll speed.
        record = self.record_for(harness="claude", harness_env={})
        env, notices = self.env_and_notices(record, {"CLAUDE_CODE_SCROLL_SPEED": "3"})
        self.assertEqual(env["CLAUDE_CODE_SCROLL_SPEED"], "3")
        self.assertEqual(notices, [])

    def test_ambient_collision_reaches_the_operator_through_real_argv(self):
        # The door. `--json` proves the EFFECT — the env the harness is actually handed — and
        # the one-object promise; the prose run proves the operator is told, in the ruling's
        # wording, on the stream that carries notices.
        argv = ["new", "codex", "--env", "FOO=declared", "--dry-run"]
        with mock.patch.dict(os.environ, {"FOO": "from-shell"}, clear=False):
            stdout, stderr = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                rc = launcher.main([*argv, "json-probe", "--json"])
            self.assertEqual(rc, 0, stderr.getvalue())
            self.assertEqual(stderr.getvalue(), "")
            self.assertEqual(json.loads(stdout.getvalue())["env"]["FOO"], "declared")

            stdout, stderr = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                rc = launcher.main([*argv, "prose-probe"])
            self.assertEqual(rc, 0, stderr.getvalue())
        # Both polarities of Ops's "keep the key, drop the value" ruling, at the door where an
        # operator actually reads the line. Presence alone would pass a message that names the
        # key AND leaks the value, which is the exact thing the ruling removed.
        self.assertIn(
            "tap session: overriding ambient ENV var FOO with the declared value",
            stderr.getvalue(),
        )
        self.assertIn("FOO", stderr.getvalue())
        # Neither side of the collision is echoed: not the shell's value, and not the declared
        # one. The fence cannot make the declared side safe — it is name-based and passes
        # plural forms, so a key like HF_TOKENS clears it and would print a credential here.
        self.assertNotIn("from-shell", stderr.getvalue())
        self.assertNotIn("declared value declared", stderr.getvalue())
        for line in stderr.getvalue().splitlines():
            if "ambient ENV var" in line:
                self.assertTrue(
                    line.endswith("with the declared value"),
                    f"collision line must end at the key, not carry a value: {line!r}",
                )

    def adhoc(self, **fields):
        base = {
            "harness": "claude",
            "model": None,
            "effort": None,
            "env": None,
            "harness_passthrough": None,
        }
        base.update(fields)
        return launcher.argparse.Namespace(**base)

    def test_agy_model_translates_instead_of_refusing(self):
        # OQ4 (ratified 2026-08-12) refused --model on agy because the builder had no
        # plumbing. The table is the replacement: agy has a model axis, so the same
        # argv that used to refuse now translates. A resolver that still refused agy
        # --model would red this; a resolver that accepted but whose builder dropped
        # the flag would red test_builds_agy_new_launch_with_yolo_flag.
        tuning = launcher.resolve_adhoc_tuning(
            self.adhoc(harness="agy", model="gemini-3.6-flash-high")
        )
        self.assertEqual(tuning.model, "gemini-3.6-flash-high")
        self.assertEqual(tuning.harness_passthrough, ())

    def test_model_on_a_model_capable_harness_is_accepted(self):
        # The negative arm. Without it, a resolver that refused --model everywhere would pass
        # the test above and break every claude and codex launch on the machine.
        tuning = launcher.resolve_adhoc_tuning(self.adhoc(harness="claude", model="opus"))
        self.assertEqual(tuning.model, "opus")

    def test_effort_translates_per_harness_table_and_refuses_outside_it(self):
        tuning = launcher.resolve_adhoc_tuning(self.adhoc(harness="codex", effort="high"))
        self.assertEqual(
            tuning.harness_passthrough, ("-c", 'model_reasoning_effort="high"')
        )
        tuning = launcher.resolve_adhoc_tuning(self.adhoc(harness="agy", effort="high"))
        self.assertEqual(tuning.harness_passthrough, ("--effort", "high"))
        tuning = launcher.resolve_adhoc_tuning(self.adhoc(harness="claude", effort="high"))
        self.assertEqual(tuning.harness_passthrough, ("--effort", "high"))
        with self.assertRaises(preset_config.PresetError) as caught:
            launcher.resolve_adhoc_tuning(self.adhoc(harness="cursor", effort="high"))
        self.assertEqual(caught.exception.error_class, "launch_effort_unsupported")
        self.assertIn("cursor", caught.exception.detail)
        self.assertIn("--effort", caught.exception.detail)

    def test_agy_effort_max_refuses_naming_low_medium_high(self):
        with self.assertRaises(preset_config.PresetError) as caught:
            launcher.resolve_adhoc_tuning(self.adhoc(harness="agy", effort="max"))
        self.assertEqual(caught.exception.error_class, "launch_arg_invalid")
        self.assertIn("agy", caught.exception.detail)
        self.assertIn("max", caught.exception.detail)
        self.assertIn("low, medium, high", caught.exception.detail)
        self.assertIn("low, medium, high", caught.exception.action)
        # Must not clamp or pass through.
        self.assertNotIn("model_reasoning_effort", caught.exception.detail)

    def test_effort_and_explicit_passthrough_refuse_rather_than_pick_a_winner(self):
        with self.assertRaises(preset_config.PresetError) as caught:
            launcher.resolve_adhoc_tuning(
                self.adhoc(
                    harness="codex",
                    effort="high",
                    harness_passthrough=["-c", 'model_reasoning_effort="low"'],
                )
            )
        self.assertIn("effort one way", caught.exception.action)

    def test_env_refusals_name_the_flag_not_a_preset_file(self):
        # The failure this pins: the fence is SHARED with presets, so a CLI refusal could be
        # perfectly well-formed and still send the operator to edit a file they never opened.
        with self.assertRaises(preset_config.PresetError) as caught:
            launcher.resolve_adhoc_tuning(self.adhoc(env=["TAP_HOME=/x"]))
        error = caught.exception
        self.assertEqual(error.error_class, "launch_env_forbidden")
        # Naming the flag is necessary but NOT sufficient — sol's Turn-2 finding. Any prose
        # containing "--env" and no preset filename would satisfy that, runnable or not. What
        # the operator needs is an action they can act on directly, naming the offending KEY,
        # so assert the key is present and the action reads as an instruction about THIS
        # command rather than about a file.
        self.assertIn("--env", error.action)
        self.assertIn("TAP_HOME", error.action)
        self.assertIn("from the command", error.action)
        for surface in ("preset", "presets.toml", "config.toml"):
            self.assertNotIn(surface, error.action)
            self.assertNotIn(surface, error.detail)

    def test_launch_tuning_refuses_on_both_resume_delegation_doors(self):
        # sol Turn-2 P1. `launch claude 3 --model X` used to reach cmd_resume and apply the
        # model to the RESUMED record, while --effort and --env were dropped in silence. The
        # collision chooser's [r] arm did the same. Applying one flag and discarding two leaves
        # the operator no way to learn that only one took effect.
        for door in ("a numeric-label resume", "the collision chooser's resume arm"):
            for flag, fields in (
                ("--model", {"model": "opus"}),
                ("--effort", {"effort": "high"}),
                ("--env", {"env": ["FOO=bar"]}),
                # Supplied-but-empty must refuse too, not read as absent.
                ("--model", {"model": ""}),
            ):
                with self.subTest(door=door, flag=flag, fields=fields):
                    with self.assertRaises(preset_config.PresetError) as caught:
                        launcher.refuse_tuning_on_resume_delegation(
                            self.adhoc(**fields), door
                        )
                    self.assertEqual(
                        caught.exception.error_class, "launch_tuning_not_resumable"
                    )
                    self.assertIn(flag, caught.exception.detail)
                    self.assertIn(door, caught.exception.detail)

    def test_resume_delegation_allows_an_untuned_launch(self):
        # The negative arm: the guard must not refuse the ordinary `launch claude 3` spelling.
        launcher.refuse_tuning_on_resume_delegation(self.adhoc(), "a numeric-label resume")

    def test_cmd_new_actually_reaches_the_numeric_delegation_guard(self):
        # Testing the helper alone would prove only that a guard EXISTS. This drives the real
        # entry point so the wiring is pinned too: `launch claude 3 --model opus` must refuse
        # before any registry or tmux effect, not merely be refusable in principle.
        args = launcher.argparse.Namespace(
            harness="claude",
            label="3",
            preset=None,
            tag=None,
            unique=None,
            model="opus",
            effort=None,
            env=None,
            fresh=False,
        )
        with self.assertRaises(preset_config.PresetError) as caught:
            launcher.cmd_new(args)
        self.assertEqual(caught.exception.error_class, "launch_tuning_not_resumable")

    def test_env_pairs_split_on_the_first_equals_only(self):
        tuning = launcher.resolve_adhoc_tuning(self.adhoc(env=["FOO=a=b=c"]))
        self.assertEqual(tuning.env, {"FOO": "a=b=c"})
        with self.assertRaises(preset_config.PresetError) as caught:
            launcher.resolve_adhoc_tuning(self.adhoc(env=["FOO"]))
        self.assertIn("missing '='", caught.exception.detail)

    def test_adhoc_env_ignores_the_launching_shell(self):
        # The declared value is the value: an explicit --env must not be replaced by whatever
        # the operator happens to have exported. The collision is announced at the merge point
        # (test_ambient_collision_* below), never resolved in the shell's favour here.
        with mock.patch.dict(os.environ, {"FOO": "from-shell"}):
            tuning = launcher.resolve_adhoc_tuning(self.adhoc(env=["FOO=from-flag"]))
        self.assertEqual(tuning.env, {"FOO": "from-flag"})

    def test_disabled_param_is_not_carried_as_a_conflicting_key(self):
        # `params.mode = false` renders NO --mode, so it collides with nothing.
        # param_keys carried it anyway, which made `tap ask` refuse a preset for
        # explicitly DISABLING a builder flag — the opposite of the conflict the
        # guard exists to catch.
        with tempfile.TemporaryDirectory() as home:
            cfg = pathlib.Path(home) / "tap"
            cfg.mkdir()
            (cfg / "config.toml").write_text(
                'version = 2\n\n[presets.dis]\nharness = "cursor"\n\n'
                '[presets.dis.params]\nmode = false\nfoo = "bar"\n'
            )
            with mock.patch.dict(os.environ, {"XDG_CONFIG_HOME": home}):
                resolved = preset_config.load_preset_catalog().get("dis")
        self.assertEqual(list(resolved.harness_passthrough), ["--foo", "bar"])
        # The rendering and the keys must agree about what the preset emits.
        self.assertEqual(list(resolved.param_keys), ["foo"])

    def test_new_subparser_flags_are_all_known_to_the_passthrough_splitter(self):
        # The splitter forwards any flag it does not recognise to the harness binary. A new
        # launcher-owned flag that misses these tables would not error — it would silently
        # become harness argv, which is far harder to notice than a crash.
        parser = launcher.build_parser()
        new_parser = parser._subparsers._group_actions[0].choices["new"]
        for action in new_parser._actions:
            for option in action.option_strings:
                if option in {"--help", "-h"}:
                    continue
                argv = ["new", "codex", option]
                if action.nargs != 0:
                    argv.append("value")
                own, tail = launcher.split_new_passthrough(argv)
                self.assertEqual(own, argv, option)
                self.assertEqual(tail, [], option)

    def test_tuning_refuses_before_cmd_new_touches_anything(self):
        # The ordering pin for the pre-effect hoist, placed where the boundary is OBSERVABLE.
        # Two smoke-level effect-absence probes were tried first and both stayed green with the
        # hoist removed (no registry row; no bus bootstrapped in an unenrolled worktree), so
        # neither could serve as proof. Here the first post-validation step is replaced by a
        # sentinel: reaching it at all means validation ran too late.
        class ReachedAnEffect(AssertionError):
            pass

        args = launcher.argparse.Namespace(
            harness="codex", label=None, preset=None, tag=None, unique=None,
            model=None, effort=None, env=["TAP_HOME=/x"], fresh=False,
        )
        with mock.patch.object(
            launcher, "refuse_if_team_reset_fenced",
            side_effect=ReachedAnEffect("validation ran after the first effect"),
        ), self.assertRaises(preset_config.PresetError) as caught:
            launcher.cmd_new(args)
        self.assertEqual(caught.exception.error_class, "launch_env_forbidden")

    def test_every_retired_flag_refuses_by_name_on_every_verb_that_took_it(self):
        # The whole point of the transitional release: a removed flag that still PARSES and
        # does nothing is the silent-swallow this lane exists to delete. Each retired spelling
        # must name itself and say what to do instead. The matrix is enumerated rather than
        # sampled, because a flag left off this list is exactly the one that would go quiet.
        cases = (
            ("launch", launcher.cmd_new, "--teams", {"teams": True}),
            ("resume", launcher.cmd_resume, "--model", {"model": "opus"}),
            ("resume", launcher.cmd_resume, "--teams", {"teams": True}),
            ("restart", launcher.cmd_restart, "--model", {"model": "opus"}),
            ("restart", launcher.cmd_restart, "--teams", {"teams": True}),
        )
        for verb, fn, flag, fields in cases:
            with self.subTest(verb=verb, flag=flag):
                base = {
                    "harness": "claude", "label": None, "preset": None, "tag": None,
                    "unique": None, "model": None, "effort": None, "env": None,
                    "teams": False, "fresh": False, "key": "seat", "legacy_name": None,
                    "all": False, "force": False, "dry_run": False,
                }
                base.update(fields)
                with self.assertRaises(preset_config.PresetError) as caught:
                    fn(launcher.argparse.Namespace(**base))
                self.assertEqual(caught.exception.error_class, "retired_flag")
                self.assertIn(flag, caught.exception.detail)
                self.assertIn(verb, caught.exception.detail)
                # The refusal has to be actionable, not merely correct: it names the
                # replacement spelling, which is the whole reason it exists rather than
                # letting argparse reject an unknown flag a release later.
                self.assertTrue(caught.exception.action)

    def test_retired_flags_refuse_through_the_real_argv_surface(self):
        # sol P1. The Namespace-level matrix below calls cmd_* directly, so it cannot see the
        # failure that actually matters: deleting `new`'s --teams from BOTH the parser and
        # _NEW_BOOL_FLAGS leaves that matrix green while split_new_passthrough silently
        # forwards --teams to the harness. Only argv proves the whole path — parser entry,
        # splitter table, refusal, and the structured surface an operator or script reads.
        # Each case names the remedy needle it must actually contain. A truthy-action check is
        # not enough: it stays green if the model and teams remedies are swapped, or if one is
        # replaced by irrelevant nonempty text. The needle is what makes the assertion about
        # THIS refusal rather than about refusals in general.
        # Needles come in SETS, because one is not enough to make an action runnable. A model
        # remedy reading "retry tap session resume seat --model opus" would contain `--model`
        # and avoid `pass --env`, and would loop the operator straight back into the refusal
        # it is answering — a circular remedy passes every single-needle check. So each case
        # requires the flag-shaped part AND the part that points somewhere ELSE: for model, at
        # the launch that stores it; for teams, at the config table or a relaunch, plus the
        # actual key, since "[harness.claude.env]" alone never says what to put there.
        teams_needles = ("CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=true", "[harness.claude.env]")
        model_needles = ("--model", "LAUNCHED")
        cases = (
            (
                ["new", "claude", "--teams"], "--teams", "launch",
                ("--env CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=true",),
            ),
            (["resume", "seat", "--model", "opus"], "--model", "resume", model_needles),
            (["resume", "seat", "--teams"], "--teams", "resume", teams_needles),
            (["restart", "seat", "--model", "opus"], "--model", "restart", model_needles),
            (["restart", "seat", "--teams"], "--teams", "restart", teams_needles),
        )
        for argv, flag, verb, needles in cases:
            with self.subTest(argv=" ".join(argv)):
                stdout, stderr = io.StringIO(), io.StringIO()
                with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    rc = launcher.main([*argv, "--json"])
                # The exact code, not merely nonzero — "any failure" grandfathers a drift from
                # the structured-refusal family into an unhandled crash.
                self.assertEqual(rc, 2, argv)
                # --json promises exactly one object and nothing else. Prose on stderr beside
                # it is the contamination that promise names, and a machine consumer reading
                # both streams would see it.
                self.assertEqual(stderr.getvalue(), "", argv)
                payload = json.loads(stdout.getvalue())
                # The failure discriminator itself. Without this the object could report
                # ok=true and every other assertion here would still pass — a machine consumer
                # branches on this field before reading anything else.
                self.assertIs(payload["ok"], False, argv)
                self.assertEqual(payload["error_class"], "retired_flag", argv)
                self.assertIn(flag, payload["detail"])
                self.assertIn(verb, payload["detail"])
                # The action must be RUNNABLE from here, not merely present. `resume` and
                # `restart` take no --env, so an action telling them to pass one would fail at
                # argparse the moment the operator followed it.
                action = payload["action"]
                for needle in needles:
                    self.assertIn(needle, action, f"{argv}: action lacks {needle!r}")
                if verb in ("resume", "restart"):
                    self.assertNotIn("pass --env", action)

    def test_a_retired_flag_left_unset_does_not_refuse(self):
        # Negative arm. Without it, a guard that refused every resume would pass the matrix
        # above and break every seat on the machine.
        args = launcher.argparse.Namespace(model=None, teams=False)
        for flag in ("--model", "--teams"):
            launcher.refuse_retired_flag(args, flag, "resume")

    def test_raw_passthrough_is_tuning_too_at_both_resume_doors(self):
        # sol P1. `launch codex 3 -c model_reasoning_effort="high"` carries exactly what
        # --effort carries, spelled differently, and resume neither consumes nor replays a
        # request vector — so it vanished past a guard that enumerated three named flags. The
        # class is "tuning typed for a NEW seat", not "the flags I happened to add".
        for door in ("a numeric-label resume", "the collision chooser's resume arm"):
            with self.subTest(door=door):
                args = self.adhoc(
                    harness_passthrough=["-c", 'model_reasoning_effort="high"']
                )
                with self.assertRaises(preset_config.PresetError) as caught:
                    launcher.refuse_tuning_on_resume_delegation(args, door)
                self.assertEqual(
                    caught.exception.error_class, "launch_tuning_not_resumable"
                )
                self.assertIn("passthrough", caught.exception.detail)

    def test_exclusivity_counts_a_supplied_empty_value(self):
        # sol test-gap. Reverting suppliedness to truthiness left the exclusivity tests green,
        # because every one of them passed a NON-empty value. An empty string is parser
        # reachable (`--model ""`), and under truthiness it slipped past exclusivity entirely.
        for flag, fields in (
            ("--model", {"model": ""}),
            ("--effort", {"effort": ""}),
        ):
            with self.subTest(flag=flag):
                base = {
                    "preset": "sol-pinnacle-xhigh",
                    "harness": None,
                    "label": None,
                    "model": None,
                    "effort": None,
                    "env": None,
                }
                base.update(fields)
                with self.exclusivity_catalog(), \
                     self.assertRaises(preset_config.PresetError) as caught:
                    launcher.resolve_new_preset_args(launcher.argparse.Namespace(**base))
                self.assertEqual(
                    caught.exception.error_class, "preset_not_composable", flag
                )

    def test_a_harness_typo_is_not_reported_as_a_complete_preset(self):
        # sol P2. `launch claud --model opus` reported "preset 'claud' is complete" and advised
        # dropping a --preset nobody typed. An unknown name's first problem is that it is
        # unknown; exclusivity is only meaningful once the name resolves to a real preset.
        args = launcher.argparse.Namespace(
            preset=None, harness="claud", label=None,
            model="opus", effort=None, env=None,
        )
        with self.assertRaises(preset_config.PresetError) as caught:
            launcher.resolve_new_preset_args(args)
        self.assertNotEqual(caught.exception.error_class, "preset_not_composable")
        self.assertNotIn("is complete", caught.exception.detail)

    def test_exclusivity_does_not_fire_without_adhoc_tuning(self):
        # The negative arm. Without it, a guard that refused EVERY preset launch would still
        # pass the test above. Resolution proceeds past the guard and then succeeds or fails on
        # catalog loading — any outcome except preset_not_composable proves the guard stayed
        # silent for a plain --preset launch.
        args = launcher.argparse.Namespace(
            preset="sol-pinnacle-xhigh",
            harness=None,
            label=None,
            model=None,
            effort=None,
            env=None,
        )
        try:
            launcher.resolve_new_preset_args(args)
        except preset_config.PresetError as exc:
            self.assertNotEqual(exc.error_class, "preset_not_composable")

    def test_requested_preset_clears_stale_inherited_optional_fields(self):
        existing = launcher.SessionRecord(
            name="tap/worker",
            harness="codex",
            cwd="/tmp",
            base="tap",
            model="stale-model",
            harness_passthrough=["-c", "stale=1"],
            harness_env={"STALE_VALUE": "yes"},
            preset={
                "name": "stale",
                "source_path": "/tmp/stale.toml",
                "config_digest": "sha256:" + "d" * 64,
            },
        )
        empty = self.resolution(name="empty", model=None, passthrough=(), env={})

        model, passthrough, env, provenance, from_config = launcher.resolve_new_record_tuning(
            self.args(resolution=empty), existing, True
        )

        self.assertIsNone(model)
        self.assertEqual(passthrough, [])
        self.assertEqual(env, {})
        self.assertEqual(provenance["name"], "empty")
        self.assertTrue(from_config)

    def test_no_preset_relaunch_preserves_existing_tuning_and_fresh_does_not(self):
        existing = launcher.SessionRecord(
            name="tap/worker",
            harness="codex",
            cwd="/tmp",
            base="tap",
            model="stored-model",
            harness_passthrough=["-c", "stored=1"],
            harness_env={"STORED_VALUE": "yes"},
            preset={
                "name": "stored",
                "source_path": "/tmp/stored.toml",
                "config_digest": "sha256:" + "e" * 64,
            },
        )

        inherited = launcher.resolve_new_record_tuning(
            self.args(resolution=None), existing, True
        )
        self.assertEqual(
            inherited,
            (
                "stored-model",
                ["-c", "stored=1"],
                {"STORED_VALUE": "yes"},
                existing.preset,
                False,
            ),
        )

        fresh = launcher.resolve_new_record_tuning(
            self.args(resolution=None), existing, False
        )
        self.assertEqual(fresh, (None, [], {}, None, False))

    def test_make_new_record_captures_resolved_tuning(self):
        cwd = str(pathlib.Path.cwd().resolve())
        root = launcher.root_for_cwd(cwd)
        resolution = self.resolution()
        args = types.SimpleNamespace(
            harness="codex",
            unique=None,
            tag=None,
            label=None,
            model=None,
            teams=False,
            harness_passthrough=[],
            preset_resolution=resolution,
        )
        manifest = launcher.Manifest(sessions=[], dir_aliases={root: "tap"})

        with mock.patch.object(launcher, "tmux_sessions_for_namespace", return_value=set()), \
             mock.patch.object(launcher, "tap_handles", return_value=set()), \
             mock.patch.object(launcher, "registry_entry", return_value=None):
            record = launcher.make_new_record(args, manifest)

        self.assertEqual(record.model, resolution.model)
        self.assertEqual(record.harness_passthrough, list(resolution.harness_passthrough))
        self.assertTrue(record.passthrough_from_config)
        self.assertEqual(record.harness_env, resolution.env)
        self.assertEqual(record.preset["name"], resolution.provenance.name)
        # Unnamed preset launch takes the preset name, not the harness. The
        # existing capture used to leave tag unset and allocate `tap/codex`.
        self.assertEqual(record.tag, "sol-pinnacle-xhigh")
        self.assertEqual(record.name, "tap/sol-pinnacle-xhigh")

    def test_explicit_seat_name_still_wins_over_the_preset_name(self):
        cwd = str(pathlib.Path.cwd().resolve())
        root = launcher.root_for_cwd(cwd)
        args = types.SimpleNamespace(
            harness="codex",
            unique=None,
            tag=None,
            label="worker",
            model=None,
            teams=False,
            harness_passthrough=[],
            preset_resolution=self.resolution(),
        )
        manifest = launcher.Manifest(sessions=[], dir_aliases={root: "tap"})
        with mock.patch.object(launcher, "tmux_sessions_for_namespace", return_value=set()), \
             mock.patch.object(launcher, "tap_handles", return_value=set()), \
             mock.patch.object(launcher, "registry_entry", return_value=None):
            record = launcher.make_new_record(args, manifest)
        self.assertEqual(record.tag, "worker")
        self.assertEqual(record.name, "tap/worker")

    def test_unnamed_direct_harness_still_defaults_to_the_harness(self):
        cwd = str(pathlib.Path.cwd().resolve())
        root = launcher.root_for_cwd(cwd)
        args = types.SimpleNamespace(
            harness="codex",
            unique=None,
            tag=None,
            label=None,
            model=None,
            teams=False,
            harness_passthrough=[],
            preset_resolution=None,
        )
        manifest = launcher.Manifest(sessions=[], dir_aliases={root: "tap"})
        with mock.patch.object(launcher, "tmux_sessions_for_namespace", return_value=set()), \
             mock.patch.object(launcher, "tap_handles", return_value=set()), \
             mock.patch.object(launcher, "registry_entry", return_value=None):
            record = launcher.make_new_record(args, manifest)
        self.assertIsNone(record.tag)
        self.assertEqual(record.name, "tap/codex")

    def _record_for_unnamed_preset(self, preset_name, harness="codex"):
        cwd = str(pathlib.Path.cwd().resolve())
        root = launcher.root_for_cwd(cwd)
        args = types.SimpleNamespace(
            harness=harness,
            unique=None,
            tag=None,
            label=None,
            model=None,
            teams=False,
            harness_passthrough=[],
            preset_resolution=self.resolution(name=preset_name, harness=harness),
        )
        manifest = launcher.Manifest(sessions=[], dir_aliases={root: "tap"})
        with mock.patch.object(launcher, "tmux_sessions_for_namespace", return_value=set()), \
             mock.patch.object(launcher, "tap_handles", return_value=set()), \
             mock.patch.object(launcher, "registry_entry", return_value=None):
            return launcher.make_new_record(args, manifest)

    def test_dotted_and_hyphenated_preset_names_stay_distinct_seats(self):
        # sol-pinnacle P1 / Codex thread: sanitize_component maps both spellings
        # to sol-max, so calibration misses and the two presets collide.
        dotted = self._record_for_unnamed_preset("sol.max")
        hyphen = self._record_for_unnamed_preset("sol-max")
        self.assertEqual(dotted.tag, "sol.max")
        self.assertEqual(dotted.name, "tap/sol.max")
        self.assertEqual(hyphen.tag, "sol-max")
        self.assertEqual(hyphen.name, "tap/sol-max")
        self.assertNotEqual(dotted.name, hyphen.name)
        self.assertEqual(
            launcher.allocate_name("tap", "codex", "sol.max", set(), literal_handle=True),
            "tap/sol.max",
        )
        self.assertEqual(
            launcher.allocate_name("tap", "codex", "sol.max", set()),
            "tap/sol-max",
        )

    def _colliding_unnamed_preset(self, preset_name, *, new=False, fresh=False,
                                    gone=False, tty=False, classification="live", status="active"):
        cwd = str(pathlib.Path.cwd().resolve())
        root = launcher.root_for_cwd(cwd)
        occupied = {f"tap/{preset_name}", "tap/sol-max"}
        args = types.SimpleNamespace(
            harness="codex",
            unique=None,
            tag=None,
            label=None,
            model=None,
            teams=False,
            new=new,
            fresh=fresh,
            dry_run=False,
            harness_passthrough=[],
            preset_resolution=self.resolution(name=preset_name, harness="codex"),
        )
        manifest = launcher.Manifest(sessions=[], dir_aliases={root: "tap"})
        with mock.patch.object(launcher, "tmux_sessions_for_namespace", return_value=occupied), \
             mock.patch.object(launcher, "tap_handles", return_value={preset_name}), \
             mock.patch.object(launcher, "registry_entry", return_value={"status": status, "harness": "claude", "pane_id": "%131"}), \
             mock.patch.object(launcher, "entry_observed_dead", return_value=gone), \
             mock.patch.object(launcher, "entry_verified_session_name", return_value=None), \
             mock.patch.object(launcher, "caller_has_tty", return_value=tty), \
             mock.patch.object(launcher, "occupied_session_names", return_value=occupied), \
             mock.patch.object(launcher, "classify_session", return_value=classification):
            return launcher.make_new_record(args, manifest)

    def test_dotted_preset_collision_new_keeps_literal_index(self):
        # sol-pinnacle P1 follow-up: allocate_name returns tap/sol.max-2, but the
        # suffix used to be stripped with tap/sol-max-, so index fell back to 1
        # and session_handle still addressed the incumbent sol.max.
        record = self._colliding_unnamed_preset("sol.max", new=True)
        self.assertEqual(record.name, "tap/sol.max-2")
        self.assertEqual(record.tag, "sol.max")
        self.assertEqual(record.index, 2)
        self.assertEqual(launcher.session_handle(record), "sol.max-2")

    def test_gone_preset_collision_auto_suffixes_a_new_seat_not_identity_fork(self):
        # The observed-gone exception retains automatic new-seat suffixing;
        # live/unobservable rows require an explicit choice (tap-7r3fn.131).
        with mock.patch.object(launcher, "cmd_resume") as resume:
            record = self._colliding_unnamed_preset("sol-pinnacle", gone=True)
        resume.assert_not_called()
        self.assertEqual(record.name, "tap/sol-pinnacle-2")
        self.assertEqual(launcher.session_handle(record), "sol-pinnacle-2")
        self.assertNotEqual(record.ensure_action, "resume")

    def test_live_unknown_preset_collision_asks_before_creating_another_seat(self):
        # Alex F2: an active fable row, live session, first-run wizard and
        # unknown team display is not a gone row. Neither an unknown probe nor
        # a launching shell authorizes a silent suffix or fresh replacement.
        for state in ("live", "unknown", "busy", "shell"):
            for status in ("active", "launching"):
                with self.subTest(state=state, status=status), \
                     mock.patch.object(launcher, "prompt_session_exists", return_value="n") as chooser:
                    record = self._colliding_unnamed_preset(
                        "fable", tty=True, classification=state, status=status)
                    chooser.assert_called_once()
                    self.assertEqual(record.name, "tap/fable-2")

    def test_live_unknown_preset_collision_without_tty_refuses_with_guidance(self):
        preset_name = "fable"
        out = io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(out), \
             mock.patch.object(launcher, "prompt_session_exists") as chooser:
            with self.assertRaises(SystemExit) as caught:
                self._colliding_unnamed_preset(preset_name, classification="unknown")
        self.assertEqual(caught.exception.code, 2)
        chooser.assert_not_called()
        self.assertIn(f"tap session launch {preset_name} {preset_name}-2", out.getvalue())
        self.assertIn(f"tap session launch {preset_name} {preset_name} --fresh", out.getvalue())
        self.assertNotIn("tap session launch codex", out.getvalue())

    def test_dotted_preset_fresh_replaces_the_literal_session(self):
        # Same HOLD: expected_session used named_session_name and targeted
        # tap/sol-max even when the live incumbent was tap/sol.max.
        record = self._colliding_unnamed_preset("sol.max", fresh=True)
        self.assertEqual(record.name, "tap/sol.max")
        self.assertEqual(record.tag, "sol.max")
        self.assertEqual(record.replaces_session, "tap/sol.max")
        self.assertNotEqual(record.replaces_session, "tap/sol-max")

    def test_preset_named_help_refuses_before_registry_effects(self):
        cwd = str(pathlib.Path.cwd().resolve())
        root = launcher.root_for_cwd(cwd)
        args = types.SimpleNamespace(
            harness="codex",
            unique=None,
            tag=None,
            label=None,
            model=None,
            teams=False,
            harness_passthrough=[],
            preset_resolution=self.resolution(name="help"),
        )
        manifest = launcher.Manifest(sessions=[], dir_aliases={root: "tap"})
        with mock.patch.object(launcher, "tmux_sessions_for_namespace", return_value=set()), \
             mock.patch.object(launcher, "tap_handles") as handles, \
             mock.patch.object(launcher, "registry_entry") as registry:
            with self.assertRaises(launcher.LauncherError) as caught:
                launcher.make_new_record(args, manifest)
        self.assertIn("help", str(caught.exception))
        self.assertIn("reserved", str(caught.exception))
        handles.assert_not_called()
        registry.assert_not_called()

    def test_spawned_process_receives_effective_preset_environment(self):
        # Asserts the FLIP rather than being replaced, so the transition stays legible: the
        # second column used to read "from-parent", because a key already exported by the
        # launching shell beat the preset that declared it. panel ruling (2026-08-11) inverted
        # that, and this is the only pin that carries the property all the way into a real
        # spawned process — the declared value has to survive argv construction, the shell
        # command's quoting, and a login shell that re-reads the operator's own profile.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            config_home = root / "config"
            config = config_home / "tap" / "presets.toml"
            config.parent.mkdir(parents=True)
            config.write_text(
                'version = 2\n[presets.spawned]\nharness = "hermes"\n'
                '[presets.spawned.env]\nPRESET_VALUE = "from-config"\n'
                'CONTESTED_VALUE = "declared"\n'
            )
            config.chmod(0o600)
            environ = {
                "HOME": str(root / "home"),
                "XDG_CONFIG_HOME": str(config_home),
                "CONTESTED_VALUE": "from-parent",
            }
            resolved = preset_config.load_preset_catalog(environ).require("spawned")
            fake_harness = root / "fake-hermes"
            fake_harness.write_text(
                "#!/bin/sh\n"
                "printf '%s|%s\\n' \"$PRESET_VALUE\" \"$CONTESTED_VALUE\"\n"
            )
            fake_harness.chmod(0o755)
            record = launcher.SessionRecord(
                name="tap/spawned",
                harness="hermes",
                cwd=str(root),
                base="tap",
                harness_env=resolved.env,
                preset={
                    "name": resolved.provenance.name,
                    "source_path": resolved.provenance.source_path,
                    "config_digest": resolved.provenance.config_digest,
                },
            )

            # The shell that runs the launch really exports the contested key. Seeding it only
            # in the `environ` dict above would leave the child inheriting nothing, and the
            # assertion would then hold for the wrong reason — there would be no competitor.
            with mock.patch.object(launcher, "HERMES_BIN", str(fake_harness)), \
                 mock.patch.dict(os.environ, {"CONTESTED_VALUE": "from-parent"}, clear=False), \
                 isolated_login_shell("/bin/sh"):
                invocation = launcher.launch_invocation("new", record)
                child = subprocess.run(
                    invocation.shell_command(),
                    shell=True,
                    capture_output=True,
                    text=True,
                )

        self.assertEqual(child.returncode, 0, child.stderr)
        self.assertEqual(child.stdout, "from-config|declared\n")

    def test_launch_env_order_is_qol_then_harness_tier_then_record(self):
        # Supersedes test_launch_env_order_is_builtin_then_preset_then_explicit_teams. There
        # is no "explicit teams" tier any more: the record is last, so what the operator chose
        # for THIS seat wins, and nothing re-forces a value over it afterwards.
        codex = launcher.SessionRecord(
            name="tap/sol",
            harness="codex",
            cwd="/tmp",
            base="tap",
            harness_env={"PONYTAIL_DEFAULT_MODE": "full"},
        )
        self.assertEqual(
            launcher.launch_invocation("new", codex).env["PONYTAIL_DEFAULT_MODE"],
            "full",
        )

        # The value that used to be re-forced by --teams is now just record env, and it is
        # honoured verbatim — including the value an earlier build would have overwritten.
        claude = launcher.SessionRecord(
            name="tap/fable",
            harness="claude",
            cwd="/tmp",
            base="tap",
            harness_env={"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "false"},
        )
        env = launcher.launch_invocation("new", claude).env
        self.assertEqual(env["CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS"], "false")
        # Tier 1 still supplies the claude cosmetics beneath it.
        self.assertIn("CLAUDE_CODE_TMUX_TRUECOLOR", env)

    def test_edit_after_launch_does_not_change_resume_or_restart_replay(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            config_home = root / "config"
            config = config_home / "tap" / "presets.toml"
            config.parent.mkdir(parents=True)

            def write(model, effort, value):
                config.write_text(
                    'version = 2\n[presets.durable]\nharness = "codex"\n'
                    f'params.model = "{model}"\nparams.effort = "{effort}"\n'
                    f'[presets.durable.env]\nREPLAY_VALUE = "{value}"\n'
                )
                config.chmod(0o600)

            environ = {
                "HOME": str(root / "home"),
                "XDG_CONFIG_HOME": str(config_home),
            }
            write("old-model", "high", "before")
            before = preset_config.load_preset_catalog(environ).require("durable")
            record = launcher.SessionRecord(
                name="tap/durable",
                harness="codex",
                cwd=str(root),
                base="tap",
                tag="durable",
                model=before.model,
                harness_passthrough=list(before.harness_passthrough),
                harness_env=before.env,
                preset={
                    "name": before.provenance.name,
                    "source_path": before.provenance.source_path,
                    "config_digest": before.provenance.config_digest,
                },
            )
            row = {
                "status": "suspended",
                "registered_from_worktree": str(root),
            }
            launcher.store_session_record_fields(row, record)

            write("new-model", "low", "after")
            after = preset_config.load_preset_catalog(environ).require("durable")
            self.assertNotEqual(
                before.provenance.config_digest, after.provenance.config_digest
            )
            config.unlink()
            restored = launcher.session_record_from_registry_row(
                "durable",
                row,
                {"name": "tap", "worktree_root": str(root)},
                str(root),
            )

            with mock.patch.object(
                preset_config,
                "load_preset_catalog",
                side_effect=AssertionError("revival reread presets.toml"),
            ):
                restart_invocation = launcher.launch_invocation("resume", restored)
                native_resume = launcher.compose_child_invocation(
                    launcher.build_native_resume_invocation(restored, None),
                    restored,
                )

        for invocation in (restart_invocation, native_resume):
            self.assertEqual(invocation.env["REPLAY_VALUE"], "before")
            self.assertIn("old-model", invocation.argv)
            self.assertIn("--effort", invocation.argv)
            self.assertIn("high", invocation.argv)
            self.assertNotIn("new-model", invocation.argv)
        self.assertEqual(
            restored.preset["config_digest"], before.provenance.config_digest
        )

    def test_dry_run_and_list_json_add_only_optional_provenance(self):
        provenance = {
            "name": "sol-max",
            "source_path": "/Users/user/.config/tap/presets.toml",
            "config_digest": "sha256:" + "f" * 64,
        }
        preset_record = launcher.SessionRecord(
            name="tap/sol",
            harness="codex",
            cwd="/work/tap",
            base="tap",
            tag="sol",
            preset=provenance,
            harness_env={"SECRET_NOT_LISTED": "value"},
        )
        direct_record = launcher.SessionRecord(
            name="tap/direct",
            harness="codex",
            cwd="/work/tap",
            base="tap",
            tag="direct",
        )
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            launcher.run_invocation(
                preset_record,
                launcher.Invocation(["codex"], {"SECRET_NOT_LISTED": "value"}),
                True,
                json_output=True,
            )
        self.assertEqual(json.loads(stdout.getvalue())["preset"], provenance)


class HarnessPassthroughTests(unittest.TestCase):
    """tap-9zwt: pnpm-style implicit harness passthrough — split grammar, persist,
    and replay-on-every-launch/resume-path (so harness tuning like codex
    `-c model_reasoning_effort="high"` survives resume instead of reverting)."""

    # ---- grammar: split_new_passthrough ---------------------------------------
    def test_split_bare_new_has_no_passthrough(self):
        clean, pt = launcher.split_new_passthrough(["new", "claude"])
        self.assertEqual(clean, ["new", "claude"])
        self.assertEqual(pt, [])

    def test_split_unknown_flag_after_harness_forwards(self):
        clean, pt = launcher.split_new_passthrough(
            ["new", "codex", "-c", 'model_reasoning_effort="high"'])
        self.assertEqual(clean, ["new", "codex"])
        self.assertEqual(pt, ["-c", 'model_reasoning_effort="high"'])

    def test_split_label_kept_before_passthrough(self):
        # First bare = harness, second bare = label; passthrough begins at the flag.
        clean, pt = launcher.split_new_passthrough(
            ["new", "codex", "mylabel", "-c", "foo=bar"])
        self.assertEqual(clean, ["new", "codex", "mylabel"])
        self.assertEqual(pt, ["-c", "foo=bar"])

    def test_split_own_value_flag_consumes_its_value(self):
        clean, pt = launcher.split_new_passthrough(
            ["new", "--model", "opus", "claude", "--foo", "x"])
        self.assertEqual(clean, ["new", "--model", "opus", "claude"])
        self.assertEqual(pt, ["--foo", "x"])

    def test_split_label_after_owned_options_remains_a_positional(self):
        for argv in (
            ["new", "codex", "--env", "FOO=declared", "--dry-run", "probe"],
            ["new", "--env", "FOO=declared", "codex", "--dry-run", "probe"],
            ["new", "codex", "--env=FOO=declared", "probe", "--dry-run"],
        ):
            with self.subTest(argv=argv):
                clean, passthrough = launcher.split_new_passthrough(
                    [*argv, "--", "--model", "child-model"]
                )
                # This shape is portable even on Python 3.12.3, whose argparse
                # drops the optional label after an intervening option.
                self.assertEqual(clean.index("probe"), clean.index("codex") + 1)
                args = launcher.build_parser().parse_args(clean)
                self.assertEqual((args.harness, args.label), ("codex", "probe"))
                self.assertEqual(args.env, ["FOO=declared"])
                self.assertTrue(args.dry_run)
                self.assertEqual(passthrough, ["--model", "child-model"])

    def test_split_own_value_flag_equals_form(self):
        clean, pt = launcher.split_new_passthrough(
            ["new", "codex", "--tag=ponytail", "-c", "q"])
        self.assertEqual(clean, ["new", "codex", "--tag=ponytail"])
        self.assertEqual(pt, ["-c", "q"])

    def test_split_double_dash_disambiguates_collision(self):
        # `--` is dropped; everything after forwards verbatim, even a tap-own flag.
        clean, pt = launcher.split_new_passthrough(
            ["new", "claude", "--dry-run", "--", "--model", "z"])
        self.assertEqual(clean, ["new", "claude", "--dry-run"])
        self.assertEqual(pt, ["--model", "z"])

    def test_split_own_flag_after_passthrough_forwards(self):
        # pnpm convention: once passthrough starts, a tap-own flag also forwards.
        clean, pt = launcher.split_new_passthrough(
            ["new", "codex", "-c", "a", "--dry-run"])
        self.assertEqual(clean, ["new", "codex"])
        self.assertEqual(pt, ["-c", "a", "--dry-run"])

    def test_split_third_bare_token_is_refused(self):
        # grok panel (PR #xxx): a bare passthrough token would land in the harness's
        # prompt position (claude/agy/cursor eat a leading bare word) — refuse it.
        with self.assertRaises(preset_config.PresetError) as cm:
            launcher.split_new_passthrough(["new", "codex", "lbl", "extrabare", "-c", "q"])
        self.assertIn("must start with", str(cm.exception))

    def test_split_double_dash_force_forwards_bare_token(self):
        # `--` is the explicit, caller-owns-it escape for a genuinely bare token.
        clean, pt = launcher.split_new_passthrough(
            ["new", "codex", "lbl", "--", "barecmd", "--flag"])
        self.assertEqual(clean, ["new", "codex", "lbl"])
        self.assertEqual(pt, ["barecmd", "--flag"])

    def test_split_non_new_subcommand_is_untouched(self):
        argv = ["resume", "codex", "--dry-run"]
        clean, pt = launcher.split_new_passthrough(argv)
        self.assertEqual(clean, argv)
        self.assertEqual(pt, [])

    # ---- persist: to_dict / from_dict -----------------------------------------
    def test_persist_round_trip(self):
        rec = launcher.SessionRecord(
            name="tap/x", harness="codex", cwd="/tmp", base="tmp",
            harness_passthrough=["-c", "foo=1"], passthrough_from_config=True)
        data = rec.to_dict()
        self.assertEqual(data["harness_passthrough"], ["-c", "foo=1"])
        self.assertTrue(data["passthrough_from_config"])
        restored = launcher.SessionRecord.from_dict(data)
        self.assertEqual(restored.harness_passthrough, ["-c", "foo=1"])
        self.assertTrue(restored.passthrough_from_config)

    def test_persist_omits_empty_passthrough(self):
        rec = launcher.SessionRecord(name="tap/y", harness="claude", cwd="/tmp", base="tmp")
        self.assertNotIn("harness_passthrough", rec.to_dict())
        self.assertNotIn("passthrough_from_config", rec.to_dict())

    def test_from_dict_missing_field_defaults_empty(self):
        # A pre-9zwt manifest record has no such key -> [] (backward compatible).
        rec = launcher.SessionRecord.from_dict(
            {"name": "a", "harness": "codex", "cwd": "/t"})
        self.assertEqual(rec.harness_passthrough, [])
        self.assertFalse(rec.passthrough_from_config)

    def test_from_dict_filters_non_strings(self):
        rec = launcher.SessionRecord.from_dict(
            {"name": "a", "harness": "codex", "cwd": "/t",
             "harness_passthrough": ["-c", 5, None, "ok"]})
        self.assertEqual(rec.harness_passthrough, ["-c", "ok"])

    # ---- replay: inject_passthrough splice ------------------------------------
    def test_inject_splices_after_binary(self):
        rec = launcher.SessionRecord(
            name="tap/x", harness="codex", cwd="/tmp", base="tmp",
            harness_passthrough=["-c", "foo=1"])
        inv = launcher.Invocation(
            ["codex", "--dangerously-bypass-approvals-and-sandbox", "resume", "ID"], {})
        out = launcher.inject_passthrough(inv, rec)
        self.assertEqual(
            out.argv,
            ["codex", "-c", "foo=1",
             "--dangerously-bypass-approvals-and-sandbox", "resume", "ID"])

    def test_inject_empty_passthrough_is_identity(self):
        rec = launcher.SessionRecord(name="tap/x", harness="claude", cwd="/tmp", base="tmp")
        inv = launcher.Invocation(["claude", "--resume", "ID"], {})
        self.assertIs(launcher.inject_passthrough(inv, rec).argv, inv.argv)

    def test_operator_passthrough_lands_even_when_the_builder_already_emits_the_flag(self):
        rec = launcher.SessionRecord(
            name="tap/x", harness="claude", cwd="/tmp", base="tmp",
            harness_passthrough=["--dangerously-skip-permissions"])
        inv = launcher.Invocation(
            ["claude", "--dangerously-skip-permissions", "--model", "opus"], {})
        out = launcher.inject_passthrough(inv, rec)
        self.assertEqual(out.argv.count("--dangerously-skip-permissions"), 2)
        self.assertEqual(out.argv[1], "--dangerously-skip-permissions")

    def test_config_passthrough_skips_a_builder_flag(self):
        rec = launcher.SessionRecord(
            name="tap/x", harness="claude", cwd="/tmp", base="tmp",
            harness_passthrough=["--dangerously-skip-permissions", "--effort", "high"],
            passthrough_from_config=True)
        inv = launcher.Invocation(
            ["claude", "--dangerously-skip-permissions", "--model", "opus"], {})
        out = launcher.inject_passthrough(inv, rec)
        self.assertEqual(out.argv.count("--dangerously-skip-permissions"), 1)
        self.assertEqual(out.argv[1:3], ["--effort", "high"])

    def test_launch_and_native_resume_both_replay(self):
        # The two consumption layers each splice exactly once -> a persisted seat
        # replays its passthrough on BOTH the launch rail and the native-resume rail.
        rec = launcher.SessionRecord(
            name="tap/seat", harness="codex", cwd="/tmp", base="tmp",
            harness_session_id="SID", harness_passthrough=["-c", "sandbox=off"])
        launch = launcher.launch_invocation("resume", rec)
        self.assertEqual(launch.argv[1:3], ["-c", "sandbox=off"])
        native = launcher.compose_child_invocation(
            launcher.build_native_resume_invocation(rec, None), rec
        )
        self.assertEqual(native.argv[1:3], ["-c", "sandbox=off"])

    def test_opencode_final_composition_pins_record_id_over_persisted_flags(self):
        forbidden_shapes = (
            ["--session", "ses_persisted"],
            ["--session=ses_persisted"],
            ["-s", "ses_persisted"],
            ["-s=ses_persisted"],
            ["--continue"],
            ["--continue=true"],
            ["-c"],
        )
        for forbidden in forbidden_shapes:
            with self.subTest(forbidden=forbidden):
                record = launcher.SessionRecord(
                    name="tap/glm",
                    harness="opencode",
                    cwd="/tmp",
                    base="tap",
                    model="provider/model",
                    harness_session_id="ses_record",
                    harness_passthrough=[*forbidden, "--foo", "bar"],
                )
                argv = launcher.launch_invocation("new", record).argv
                self.assertEqual(
                    argv,
                    [
                        "opencode", "--foo", "bar", "--model", "provider/model",
                        "--session", "ses_record",
                    ],
                )
                self.assertNotIn("ses_persisted", argv)
                self.assertNotIn("--continue", argv)

    def test_opencode_final_composition_pins_record_id_over_live_config(self):
        record = launcher.SessionRecord(
            name="tap/glm", harness="opencode", cwd="/tmp", base="tap",
            harness_session_id="ses_record",
        )
        with tempfile.TemporaryDirectory() as tmp:
            config = pathlib.Path(tmp) / "tap" / "config.toml"
            config.parent.mkdir(parents=True)
            config.write_text(
                "version = 2\n[harness.opencode.params]\n"
                'session = "ses_config"\ncontinue = true\nfoo = "bar"\n',
                encoding="utf-8",
            )
            config.chmod(0o600)
            with mock.patch.dict(os.environ, {"XDG_CONFIG_HOME": tmp}, clear=False):
                argv = launcher.launch_invocation("new", record).argv
        self.assertEqual(
            argv, ["opencode", "--foo", "bar", "--session", "ses_record"]
        )
        self.assertNotIn("ses_config", argv)

    # ---- integration: make_new_record captures + inherits ---------------------
    def _new_record(self, manifest, **args_over):
        base = dict(harness="codex", unique=None, tag=None, label=None,
                    model=None, teams=False, harness_passthrough=[])
        base.update(args_over)
        args = types.SimpleNamespace(**base)
        orig_tmux, orig_handles = launcher.tmux_sessions, launcher.tap_handles
        try:
            launcher.tmux_sessions = lambda: set()
            launcher.tap_handles = lambda _root: set()
            return launcher.make_new_record(args, manifest)
        finally:
            launcher.tmux_sessions, launcher.tap_handles = orig_tmux, orig_handles

    def test_make_new_record_captures_passthrough(self):
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(sessions=[], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        rec = self._new_record(manifest, harness_passthrough=["-c", "foo=1"])
        self.assertEqual(rec.harness_tail, ["-c", "foo=1"])

    def test_make_new_record_fresh_no_passthrough_is_empty(self):
        cwd = str(pathlib.Path.cwd().resolve())
        manifest = launcher.Manifest(sessions=[], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        rec = self._new_record(manifest)
        self.assertEqual(rec.harness_passthrough, [])


class ResumePickerUXTests(unittest.TestCase):
    """tap-opw9: the picker verb follows the found state (live -> resume/attach,
    GONE -> resume/recreate) and each found session gets one scannable state
    line. The hard invariant is verb-action agreement, pinned per state tier."""

    def _args(self, tag, harness="claude"):
        return types.SimpleNamespace(
            harness=harness, unique=None, tag=tag, label=None,
            model=None, teams=False, dry_run=False, manifest="/nonexistent",
        )

    def _labels(self, fn, *args):
        cap = {}

        def fake_choice(verb, question, options, default):
            cap["labels"] = [o[1] for o in options]
            cap["glosses"] = [o[2] for o in options]
            cap["question"] = question
            return "q"

        with mock.patch.object(launcher, "prompt_choice", fake_choice):
            fn(*args)
        return cap

    def test_new_launch_refuses_when_tmux_name_snapshot_is_unobservable(self):
        """No allocation mode may reinterpret an unreadable tmux namespace as
        empty: tagged, automatic, and exact names all block before mutation."""
        cwd = str(pathlib.Path.cwd().resolve())
        root = launcher.root_for_cwd(cwd)
        manifest = launcher.Manifest(sessions=[], dir_aliases={root: "xx"})
        cases = (
            self._args("authz"),
            self._args(None),
            types.SimpleNamespace(
                harness="claude", unique="xx/exact", tag=None, label=None,
                model=None, teams=False, dry_run=False, manifest="/nonexistent",
            ),
        )
        with mock.patch.object(
                 launcher, "tmux_sessions",
                 side_effect=launcher.LauncherError("tmux session-name snapshot is unobservable"),
             ), \
             mock.patch.object(launcher, "tap_handles", return_value=set()), \
             mock.patch.object(launcher, "registry_entry", return_value=None):
            for args in cases:
                with self.subTest(unique=args.unique, tag=args.tag), \
                     self.assertRaisesRegex(launcher.LauncherError, "unobservable"):
                    launcher.make_new_record(args, manifest)

    # ---- change (1): verb follows state, per tier -----------------------------
    def test_gone_chooser_uses_resume_label_and_neutral_gloss(self):
        cap = self._labels(
            launcher.prompt_new_collision,
            "xx/scout", "codex", "a gone seat row (%9) · not on roster · 3h ago", "exact")
        self.assertEqual(cap["labels"][0], "resume")
        self.assertNotIn("revive", " ".join(cap["labels"] + cap["glosses"]))

    def test_verb_live_chooser_is_resume(self):
        cap = self._labels(
            launcher.prompt_session_exists,
            "xx/scout", "claude", "live, attached · registered as scout")
        self.assertEqual(cap["labels"][0], "resume")
        self.assertIn("live, attached · registered as scout", cap["question"])

    # ---- change (2): the one-line state description ----------------------------
    def test_describe_session_state_composition(self):
        self.assertEqual(
            launcher.describe_session_state("live, attached", "scout", None),
            "live, attached · registered as scout")
        self.assertEqual(
            launcher.describe_session_state("a gone seat row (%9)", None, "3h ago"),
            "a gone seat row (%9) · not on roster · 3h ago")
        # age omitted when None (cheap-or-nothing)
        self.assertEqual(launcher.describe_session_state("live", "x", None), "live · registered as x")

    def test_relative_age_buckets_and_guards(self):
        now = datetime.datetime.now(datetime.timezone.utc)
        mk = lambda **k: (now - datetime.timedelta(**k)).isoformat().replace("+00:00", "Z")
        self.assertIsNone(launcher.relative_age(None))
        self.assertIsNone(launcher.relative_age("not-a-timestamp"))
        self.assertIsNone(launcher.relative_age((now + datetime.timedelta(hours=2)).isoformat()))
        self.assertEqual(launcher.relative_age(mk(seconds=10)), "just now")
        self.assertEqual(launcher.relative_age(mk(minutes=5)), "5m ago")
        self.assertEqual(launcher.relative_age(mk(hours=3)), "3h ago")
        self.assertEqual(launcher.relative_age(mk(days=2)), "2d ago")

    def test_expected_resume_identity_uses_resume_wording(self):
        record = launcher.SessionRecord(
            name="repo/scout", harness="codex", cwd="/tmp/repo",
            base="repo", tag="scout", index=1,
        )
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            launcher.state_expected_revive_identity(record)
        self.assertIn("resuming repo/scout", stderr.getvalue())
        self.assertNotIn("reviv", stderr.getvalue())

    def test_session_attached_fails_open_to_none(self):
        # A tmux probe failure must yield None (caller shows bare "live"), never a
        # guessed attach state.
        class _Fail:
            returncode = 1
            stdout = ""
        with mock.patch.object(launcher.subprocess, "run", return_value=_Fail()):
            self.assertIsNone(launcher.session_attached("xx/scout"))

        class _Attached:
            returncode = 0
            stdout = "1\n"
        with mock.patch.object(launcher.subprocess, "run", return_value=_Attached()):
            self.assertIs(launcher.session_attached("xx/scout"), True)

    # ---- verb-ACTION agreement (the invariant) --------------------------------
    def test_off_roster_resumable_record_never_opens_revive_chooser(self):
        # U5 intent-verb: leftover resumable record, not on roster -> create fresh,
        # never the revive chooser (history restore is resume-only).
        cwd = str(pathlib.Path.cwd().resolve())
        with tempfile.TemporaryDirectory() as tmp:
            home = pathlib.Path(tmp) / "home"
            hsid = "77777777-2222-4333-8444-555555555555"
            (home / "projects" / "p").mkdir(parents=True)
            (home / "projects" / "p" / f"{hsid}.jsonl").write_text("{}\n")
            old = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(hours=5)).isoformat()
            resumable = launcher.SessionRecord(
                name=launcher.named_session_name("xx", "authz"), harness="claude",
                cwd=cwd, base="xx", tag="authz", index=1, harness_session_id=hsid,
                last_seen=old,
            )
            manifest = launcher.Manifest(sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
            with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
                 mock.patch.object(launcher, "tap_handles", lambda _root: set()), \
                 mock.patch.object(launcher, "registry_entry", lambda _root, _tag: None), \
                 mock.patch.object(launcher, "prompt_new_collision",
                                   side_effect=AssertionError("off-roster launch must not open revive chooser")), \
                 mock.patch.object(launcher, "prompt_session_exists",
                                   side_effect=AssertionError("off-roster launch must not open resume chooser")), \
                 mock.patch.object(launcher, "caller_has_tty", return_value=True), \
                 mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
                 mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(home)}), \
                 contextlib.redirect_stderr(io.StringIO()):
                record = launcher.make_new_record(self._args("authz"), manifest)
            self.assertNotEqual(record.ensure_action, "resume")
            self.assertNotEqual(record.harness_session_id, hsid)

    def test_collision_resume_arm_refuses_tuning_end_to_end(self):
        # grok C3. The guard call inside the `[r]` arm had no end-to-end pin: deleting the line
        # left the suite green, because the only coverage drove the helper directly. A guard
        # nothing reaches is the failure mode this repo has hit before, so the door itself is
        # the thing under test — the chooser genuinely returns "r" here.
        cwd = str(pathlib.Path.cwd().resolve())
        resumable = launcher.SessionRecord(
            name=launcher.named_session_name("xx", "authz"), harness="claude",
            cwd=cwd, base="xx", tag="authz", index=1,
        )
        manifest = launcher.Manifest(
            sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"}
        )
        args = self._args("authz")
        args.model = "opus"

        with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
             mock.patch.object(launcher, "tap_handles", lambda _root: {"authz"}), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: {"harness": "claude"}), \
             mock.patch.object(launcher, "entry_verified_session_name", lambda _e: "other/authz"), \
             mock.patch.object(launcher, "prompt_session_exists", return_value="r"), \
             mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(launcher, "cmd_resume",
                               side_effect=AssertionError("tuning must refuse BEFORE resume runs")), \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             contextlib.redirect_stderr(io.StringIO()), \
             self.assertRaises(preset_config.PresetError) as caught:
            launcher.make_new_record(args, manifest)
        self.assertEqual(caught.exception.error_class, "launch_tuning_not_resumable")

    def test_collision_resume_arm_still_resumes_without_tuning(self):
        # The negative arm: the guard must not break the ordinary collision resume.
        cwd = str(pathlib.Path.cwd().resolve())
        resumable = launcher.SessionRecord(
            name=launcher.named_session_name("xx", "authz"), harness="claude",
            cwd=cwd, base="xx", tag="authz", index=1,
        )
        manifest = launcher.Manifest(
            sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"}
        )
        with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
             mock.patch.object(launcher, "tap_handles", lambda _root: {"authz"}), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: {"harness": "claude"}), \
             mock.patch.object(launcher, "entry_verified_session_name", lambda _e: "other/authz"), \
             mock.patch.object(launcher, "prompt_session_exists", return_value="r"), \
             mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(launcher, "cmd_resume", return_value=0) as resumed, \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             contextlib.redirect_stderr(io.StringIO()), \
             self.assertRaises(SystemExit):
            launcher.make_new_record(self._args("authz"), manifest)
        self.assertTrue(resumed.called)

    def test_live_elsewhere_incumbent_uses_resume_chooser_not_revive(self):
        # A verifiably-live-elsewhere incumbent -> the RESUME chooser fires (attach
        # semantics), never the revive chooser; description says where it's live.
        cwd = str(pathlib.Path.cwd().resolve())

        class _Stop(Exception):
            pass

        captured = {}

        def capture_live(name, harness, state_desc=None):
            captured["state_desc"] = state_desc
            raise _Stop

        resumable = launcher.SessionRecord(
            name=launcher.named_session_name("xx", "authz"), harness="claude",
            cwd=cwd, base="xx", tag="authz", index=1,
        )
        manifest = launcher.Manifest(sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        with mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
             mock.patch.object(launcher, "tap_handles", lambda _root: {"authz"}), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: {"harness": "claude"}), \
             mock.patch.object(launcher, "entry_verified_session_name", lambda _e: "other/authz"), \
             mock.patch.object(launcher, "prompt_session_exists", side_effect=capture_live), \
             mock.patch.object(launcher, "prompt_new_collision",
                               side_effect=AssertionError("live incumbent must not use the revive chooser")), \
             mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             contextlib.redirect_stderr(io.StringIO()), \
             self.assertRaises(_Stop):
            launcher.make_new_record(self._args("authz"), manifest)
        self.assertIsNotNone(captured["state_desc"])
        self.assertIn("live in other/authz", captured["state_desc"])

    def test_genuinely_live_incumbent_shows_attached_state_on_resume_chooser(self):
        # A session live in tmux -> resume chooser with a "live, attached · roster"
        # description; the attached/detached predicate is only claimed here.
        cwd = str(pathlib.Path.cwd().resolve())
        name = launcher.named_session_name("xx", "authz")

        class _Stop(Exception):
            pass

        captured = {}

        def capture_live(n, h, state_desc=None, revive_tier_word=None):
            captured["state_desc"] = state_desc
            raise _Stop

        resumable = launcher.SessionRecord(
            name=name, harness="claude", cwd=cwd, base="xx", tag="authz", index=1)
        manifest = launcher.Manifest(sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        with mock.patch.object(launcher, "tmux_sessions", lambda: {name}), \
             mock.patch.object(launcher, "classify_session", lambda _n: "live"), \
             mock.patch.object(launcher, "session_attached", lambda _n: True), \
             mock.patch.object(launcher, "tap_handles", lambda _root: {"authz"}), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: None), \
             mock.patch.object(launcher, "prompt_session_exists", side_effect=capture_live), \
             mock.patch.object(launcher, "prompt_new_collision",
                               side_effect=AssertionError("live incumbent must not use the revive chooser")), \
             mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             contextlib.redirect_stderr(io.StringIO()), \
             self.assertRaises(_Stop):
            launcher.make_new_record(self._args("authz"), manifest)
        self.assertEqual(captured["state_desc"], "live, attached · registered as authz")

    def test_off_roster_live_tmux_uses_create_chooser_not_resume(self):
        """Ops refinement #2: LIVE tmux, no roster row — create-intent chooser
        (suffix/fresh/quit), never prompt_session_exists with [r] resume."""
        cwd = str(pathlib.Path.cwd().resolve())
        name = launcher.named_session_name("xx", "authz")

        class _Stop(Exception):
            pass

        captured = {}

        def capture_off_roster(n, h, created_label=None):
            captured["name"] = n
            captured["created_label"] = created_label
            raise _Stop

        resumable = launcher.SessionRecord(
            name=name, harness="claude", cwd=cwd, base="xx", tag="authz", index=1)
        manifest = launcher.Manifest(sessions=[resumable], dir_aliases={launcher.root_for_cwd(cwd): "xx"})
        with mock.patch.object(launcher, "tmux_sessions", lambda: {name}), \
             mock.patch.object(launcher, "classify_session", lambda _n: "live"), \
             mock.patch.object(launcher, "tmux_session_created_label", lambda _n: "14:01"), \
             mock.patch.object(launcher, "tap_handles", lambda _root: set()), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: None), \
             mock.patch.object(launcher, "prompt_off_roster_tmux_collision",
                               side_effect=capture_off_roster), \
             mock.patch.object(launcher, "prompt_session_exists",
                               side_effect=AssertionError("off-roster live must not offer resume")), \
             mock.patch.object(launcher, "prompt_new_collision",
                               side_effect=AssertionError("off-roster live must not use revive chooser")), \
             mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             contextlib.redirect_stderr(io.StringIO()), \
             self.assertRaises(_Stop):
            launcher.make_new_record(self._args("authz"), manifest)
        self.assertEqual(captured["name"], name)
        self.assertEqual(captured["created_label"], "14:01")

    def test_prompt_off_roster_tmux_collision_wording_and_no_resume_key(self):
        """Chooser question names tmux session + created time; options omit [r]."""
        captured = {}

        def fake_choice(verb, question, options, default):
            captured["question"] = question
            captured["options"] = options
            captured["default"] = default
            return "q"

        with mock.patch.object(launcher, "prompt_choice", side_effect=fake_choice), \
             contextlib.redirect_stderr(io.StringIO()) as err:
            self.assertEqual(
                launcher.prompt_off_roster_tmux_collision("xx/sol", "codex", "14:01"),
                "q",
            )
        self.assertIn(
            "a tmux session named xx/sol already exists (created 14:01)",
            captured["question"],
        )
        self.assertIn("it is not on the team roster", captured["question"])
        self.assertEqual({opt[0] for opt in captured["options"]}, {"n", "k", "q"})
        self.assertIn("tmux attach -t xx/sol", err.getvalue())



    def test_absent_roster_incumbent_resume_arm_does_not_reenter_chooser(self):
        """tap-jcma: roster-seated + tmux-absent + NO manifest record must not make
        the collision chooser's [r] arm bounce back into the same chooser.

        The incumbent state that produces this is a desync between two stores: the
        roster row says the handle is occupied, the launcher manifest has no record
        of it. Collision is detected from the roster (:5785 live_or_seated, where
        only `seated` is true), so classification is "absent" (:5809) and every
        earlier ladder arm misses -- the catch-all at :5914 opens the resume chooser
        for an incumbent that resume cannot deliver. [r] forwards to cmd_resume,
        which finds no record, offers its create-fallback, and calls cmd_new, which
        re-enters this same ladder with `seated` still true. No state changes on the
        way round, so the operator cannot escape via [r].

        Reachability precondition: the handle must arrive EXPLICITLY, so that
        preset_derived is False. The wrapper spelling (`opus` -> tap_launch ->
        `tap session launch opus opus`) passes a name and qualifies. Bare
        `tap session launch opus` is preset-derived and takes the suffix arm at
        :5859, which never reaches the chooser -- a repro written with the bare form
        finds no loop and proves nothing.

        The assertion is deliberately the chooser ENTRY COUNT rather than any
        particular refusal text or exit code, so it stays honest whichever way the
        loop is broken: refusing in cmd_resume's fallback and re-routing the
        chooser's [r] arm both satisfy "the operator is not asked the same question
        a second time", while neither is prejudged here.
        """
        cwd = str(pathlib.Path.cwd().resolve())
        # The whole precondition: a roster row exists, and the manifest does not.
        empty = launcher.Manifest(
            sessions=[], dir_aliases={launcher.root_for_cwd(cwd): "xx"}
        )
        dead_row = {"harness": "claude", "pane_id": "%228", "status": "active"}

        class _Runaway(Exception):
            """Caps the cycle so the defect fails the test instead of hanging it."""

        entries = []

        def attach_door(name, harness, state_desc=None):
            # The buggy door. [r] here is what forwarded into the cold cmd_resume.
            entries.append("attach")
            if len(entries) > 1:
                raise _Runaway
            return "r"

        def reseat_door(name, harness, found_state, revive_tier_word):
            # The correct door for a gone incumbent. [q] stops the pass cleanly, so
            # a fixed ladder asks exactly one question and terminates.
            entries.append("reseat")
            if len(entries) > 1:
                raise _Runaway
            return "q"

        with mock.patch.object(launcher, "registry_session_state", lambda *a, **k: empty), \
             mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
             mock.patch.object(launcher, "session_attachable", lambda _n: False), \
             mock.patch.object(launcher, "tap_handles", lambda _root: {"authz"}), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: dead_row), \
             mock.patch.object(launcher, "entry_verified_session_name", lambda _e: None), \
             mock.patch.object(launcher, "prompt_session_exists", side_effect=attach_door), \
             mock.patch.object(launcher, "prompt_new_collision", side_effect=reseat_door), \
             mock.patch.object(launcher, "prompt_yes_no", lambda *a, **k: True), \
             mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             contextlib.redirect_stdout(io.StringIO()), \
             contextlib.redirect_stderr(io.StringIO()):
            with contextlib.suppress(SystemExit, launcher.LauncherError, _Runaway):
                launcher.make_new_record(self._args("authz"), empty)

        self.assertEqual(
            len(entries), 1,
            "the operator was asked {} collision questions ({}): a launch that lands "
            "on this incumbent must ask exactly one and terminate. More than one "
            "means the ladder routed back into a chooser with no state change "
            "(tap-jcma). Both doors are counted deliberately -- counting only the "
            "attach door would read a correct reseat as zero questions and a fixed "
            "ladder as broken.".format(len(entries), ", ".join(entries) or "none"),
        )

    def test_gone_preset_derived_handle_never_reaches_the_resume_chooser(self):
        """The observed-gone preset exception still auto-suffixes. Explicit
        handles keep tap-jcma's reseat door; live/unobservable preset rows use
        the ordinary chooser under the tap-7r3fn.131 ruling.
        """
        cwd = str(pathlib.Path.cwd().resolve())
        empty = launcher.Manifest(
            sessions=[], dir_aliases={launcher.root_for_cwd(cwd): "xx"}
        )
        dead_row = {"harness": "claude", "pane_id": "%228", "status": "active"}

        args = self._args("authz")
        # The preset-derived spelling: no explicit name, the handle comes from the
        # catalog entry instead.
        args.tag = None
        args.label = None
        args.preset_resolution = preset_config.ResolvedPreset(
            harness="claude",
            model="opus[1m]",
            harness_passthrough=(),
            env={},
            provenance=preset_config.PresetProvenance(
                name="authz",
                source_path="/Users/user/.config/tap/presets.toml",
                config_digest="sha256:" + "a" * 64,
            ),
        )

        chooser = mock.Mock(return_value="r")
        with mock.patch.object(launcher, "registry_session_state", lambda *a, **k: empty), \
             mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
             mock.patch.object(launcher, "session_attachable", lambda _n: False), \
             mock.patch.object(launcher, "tap_handles", lambda _root: {"authz"}), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: dead_row), \
             mock.patch.object(launcher, "entry_verified_session_name", lambda _e: None), \
             mock.patch.object(launcher, "entry_observed_dead", return_value=True), \
             mock.patch.object(launcher, "prompt_session_exists", chooser), \
             mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             contextlib.redirect_stdout(io.StringIO()), \
             contextlib.redirect_stderr(io.StringIO()):
            # Only the chooser decision is under test here; whatever the suffix arm
            # does afterwards is another test's business.
            with contextlib.suppress(Exception, SystemExit):
                launcher.make_new_record(args, empty)

        self.assertFalse(
            chooser.called,
            "an observed-gone preset handle lost its automatic suffix exception",
        )

    def _collision_doors(self, *, observed_dead):
        """Run the ladder over one fixed incumbent, varying ONLY the dead verdict.

        Returns the two chooser mocks so a caller can assert which door opened.
        Nothing but SystemExit is suppressed: swallowing Exception here would let a
        refactor that crashes before the chooser read as 'the door did not open'.
        """
        cwd = str(pathlib.Path.cwd().resolve())
        empty = launcher.Manifest(
            sessions=[], dir_aliases={launcher.root_for_cwd(cwd): "xx"}
        )
        dead_row = {
            "harness": "claude", "pane_id": "%228", "status": "active",
            "session": "xx/authz", "server_epoch": "srv:27173:1786679733",
        }
        exists_door = mock.Mock(return_value="q")
        collision_door = mock.Mock(return_value="q")

        with mock.patch.object(launcher, "registry_session_state", lambda *a, **k: empty), \
             mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
             mock.patch.object(launcher, "session_attachable", lambda _n: False), \
             mock.patch.object(launcher, "tap_handles", lambda _root: {"authz"}), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: dead_row), \
             mock.patch.object(launcher, "entry_verified_session_name", lambda _e: None), \
             mock.patch.object(launcher, "entry_observed_dead", lambda _e: observed_dead), \
             mock.patch.object(launcher, "prompt_session_exists", exists_door), \
             mock.patch.object(launcher, "prompt_new_collision", collision_door), \
             mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             contextlib.redirect_stdout(io.StringIO()), \
             contextlib.redirect_stderr(io.StringIO()):
            with contextlib.suppress(SystemExit):
                launcher.make_new_record(self._args("authz"), empty)
        return exists_door, collision_door

    def test_entry_dead_verdict_gates_which_collision_door_opens(self):
        """tap-jcma, the LAYER assertion: entry_dead's verdict must DECIDE the door.

        The entry-count fixture asserts the symptom's absence and is satisfied by
        refusing in cmd_resume's create-fallback, which ends the loop while leaving
        the resume chooser offering [r] on a seat resume cannot deliver. Verified,
        not assumed: under a four-line fallback refusal that fixture goes GREEN and
        this one stays RED.

        Asserting only 'the resume chooser did not open' would be weaker than it
        sounds -- any refactor that stops opening it for an unrelated reason would
        pass while the verdict stayed unwired, which is the failure this test exists
        to catch. So the assertion is DIFFERENTIAL over one fixed incumbent: flipping
        entry_observed_dead must change which door opens. If both arms agree, the
        verdict gates nothing, however tidy the code looks.

        The two doors are not interchangeable. prompt_session_exists is the ATTACH
        chooser -- its [r] reattaches to an existing session. prompt_new_collision is
        the RESEAT chooser, written for a gone incumbent, and its docstring carries
        the invariant this bug violates: a RESUME label must sit on the relaunch
        path. An observably-dead incumbent belongs to the second; an UNVERIFIABLE one
        must stay with the first, because unobservable means protect, not recreate --
        which is why entry_observed_dead failing open is correct rather than a second
        defect.
        """
        dead_exists, dead_collision = self._collision_doors(observed_dead=True)
        self.assertFalse(
            dead_exists.called,
            "an observably-dead incumbent was offered the ATTACH chooser, whose [r] "
            "reattaches to a session that is gone (tap-jcma)",
        )
        self.assertTrue(
            dead_collision.called,
            "an observably-dead incumbent was not routed to the RESEAT chooser, the "
            "door written for a gone incumbent (tap-jcma)",
        )
        found_state = dead_collision.call_args[0][2]
        self.assertIn(
            "gone seat row", found_state,
            "the reseat chooser opened without disclosing WHICH state was found; "
            "undead_found_state() names a gone row for exactly this verdict",
        )

        # The protect arm: unverifiable is not dead, and must not be reseated.
        live_exists, live_collision = self._collision_doors(observed_dead=False)
        self.assertTrue(
            live_exists.called,
            "an unverifiable incumbent stopped reaching the attach chooser: the "
            "verdict is now over-reaching into state it cannot observe (tap-jcma)",
        )
        self.assertFalse(
            live_collision.called,
            "an unverifiable incumbent was routed to the RESEAT chooser, offering "
            "replacement authority over a vessel nothing proved dead (tap-jcma)",
        )


    def _reseat_door(self, *, with_record):
        """Open the gone-row door once and report what it advertised and where [r] went.

        Varies ONLY whether a manifest record survives for the same handle.
        """
        cwd = str(pathlib.Path.cwd().resolve())
        records = []
        if with_record:
            records = [launcher.SessionRecord(
                name=launcher.named_session_name("xx", "authz"), harness="claude",
                cwd=cwd, base="xx", tag="authz", index=1,
                harness_session_id="11111111-2222-3333-4444-555555555555",
            )]
        manifest = launcher.Manifest(
            sessions=records, dir_aliases={launcher.root_for_cwd(cwd): "xx"}
        )
        dead_row = {
            "harness": "claude", "pane_id": "%228", "status": "active",
            "session": "xx/authz", "server_epoch": "srv:27173:1786679733",
        }
        seen = {}

        def door(name, harness, found_state, revive_tier_word):
            seen["tier"] = revive_tier_word
            return "r"

        with mock.patch.object(launcher, "registry_session_state", lambda *a, **k: manifest), \
             mock.patch.object(launcher, "tmux_sessions", lambda: set()), \
             mock.patch.object(launcher, "session_attachable", lambda _n: False), \
             mock.patch.object(launcher, "tap_handles", lambda _root: {"authz"}), \
             mock.patch.object(launcher, "registry_entry", lambda _root, _tag: dead_row), \
             mock.patch.object(launcher, "entry_verified_session_name", lambda _e: None), \
             mock.patch.object(launcher, "entry_observed_dead", lambda _e: True), \
             mock.patch.object(launcher, "prompt_new_collision", side_effect=door), \
             mock.patch.object(launcher, "prompt_session_exists",
                               side_effect=AssertionError("the attach door must not open on a gone row")), \
             mock.patch.object(launcher, "cmd_resume", return_value=0) as resumed, \
             mock.patch.object(launcher, "caller_has_tty", return_value=True), \
             mock.patch.object(sys, "stdin", TtyBuffer(tty=True)), \
             contextlib.redirect_stdout(io.StringIO()), \
             contextlib.redirect_stderr(io.StringIO()):
            with contextlib.suppress(SystemExit):
                launcher.make_new_record(self._args("authz"), manifest)
        return seen.get("tier"), resumed.called

    def test_gone_row_with_a_record_keeps_r_on_the_resume_delegation(self):
        """tap-jcma F1: reseating a gone row must not discard a recorded conversation.

        The loop fix routes an observed-gone incumbent to the reseat door. Mapping
        that door's [r] to fresh-replacement UNCONDITIONALLY would take a gone row
        that still has a manifest record -- a seat whose tmux died under a server
        restart, say -- and replace it, while the door's own gloss offered to restore
        the recorded conversation. That is the verb-action disagreement this arm
        exists to end, committed on the door that replaced the guilty one.

        Only the RECORDLESS case reseats. With a record present [r] stays on the
        existing cmd_resume delegation, which handles every tier honestly. The loop
        cannot return through it: cmd_resume reaches its create-fallback only when no
        record is found, which is exactly the case that no longer arrives here.
        """
        _tier, resumed = self._reseat_door(with_record=True)
        self.assertTrue(
            resumed,
            "a gone row WITH a manifest record was reseated instead of resumed: [r] "
            "was mapped away from cmd_resume, discarding a recorded conversation the "
            "door had just offered to restore (tap-jcma F1)",
        )

    def test_recordless_gone_row_door_advertises_fresh_not_a_picker(self):
        """tap-jcma F1: the gloss must describe what [r] will actually do.

        With no record there is nothing to resume from, so [r] reseats -- and the
        tier word must say so. Passing the record-derived tier here advertised "no
        live id -- resume opens the harness native picker" while the mapping
        delivered fresh replacement: a promise the action cannot keep, from the
        store this bug exists to say may be missing.

        The shell-vessel arm, whose [r] -> [k] mapping this one copied, passes the
        literal "fresh" for the same reason. Copying the mapping without the word is
        what produced the mismatch.
        """
        tier, _resumed = self._reseat_door(with_record=False)
        self.assertEqual(
            tier, "fresh",
            "the recordless gone-row door advertised tier {!r} while [r] reseats "
            "fresh: the gloss promises a restore path that does not exist "
            "(tap-jcma F1)".format(tier),
        )
class InitialPromptArgvTest(unittest.TestCase):
    """The argv axis `tap clear` rides on (tap-eb9h).

    Each harness spells "start interactively AND run this first instruction"
    differently, and two of the spellings are actively hostile: agy's obvious
    `--prompt` is non-interactive, and opencode has no such spelling at all.
    These tests are the mechanical half of that knowledge — the comments in
    build_harness_invocation explain, these refuse.
    """

    def _record(self, harness, **kw):
        base = dict(name=f"Dev/{harness}", harness=harness, cwd="/Dev", base="Dev", index=1)
        base.update(kw)
        return launcher.SessionRecord(**base)

    def test_no_prompt_leaves_every_harness_argv_untouched(self):
        # The axis is additive: omitting it must reproduce today's argv exactly,
        # or every existing launch path silently changed shape.
        for harness in ("claude", "codex", "opencode", "cursor", "agy", "hermes"):
            record = self._record(harness)
            with self.subTest(harness=harness):
                self.assertEqual(
                    launcher.build_harness_invocation("new", record).argv,
                    launcher.build_harness_invocation("new", record, None).argv,
                )

    def test_prompt_is_the_last_word_for_positional_harnesses(self):
        # claude/codex/cursor take `[prompt]` positionally (measured 2026-08-14).
        for harness in ("claude", "codex", "cursor"):
            with self.subTest(harness=harness):
                argv = launcher.build_harness_invocation(
                    "new", self._record(harness), "run tap in"
                ).argv
                self.assertEqual(argv[-1], "run tap in")

    def test_agy_uses_prompt_interactive_and_never_the_print_alias(self):
        # THE TRAP: agy's `--prompt` / `-p` is an alias for --print — one prompt,
        # non-interactively, then exit. Using it would make `tap clear` kill the
        # seat instead of restarting it. Whoever reaches for the obvious flag gets
        # this test, not a dead pane in production.
        argv = launcher.build_harness_invocation(
            "new", self._record("agy"), "run tap in"
        ).argv
        self.assertIn("--prompt-interactive", argv)
        self.assertEqual(argv[-1], "run tap in")
        self.assertNotIn("--prompt", argv)
        self.assertNotIn("-p", argv)
        self.assertNotIn("--print", argv)

    def test_opencode_prompt_never_rides_argv(self):
        # The positional is a PROJECT DIR. Putting the instruction there would
        # silently open a wrong-cwd session. The prompt form is non-interactive
        # and would leave an empty pane. So a prompt never raises and never
        # appears on argv — tap clear -m delivers it over the bus after rebind.
        argv = launcher.build_harness_invocation(
            "new", self._record("opencode"), "run tap in"
        ).argv
        self.assertEqual(argv[0], "opencode")
        self.assertNotIn("run tap in", argv)
        composed = launcher.launch_invocation(
            "new", self._record("opencode"), initial_prompt="run tap in"
        ).argv
        self.assertNotIn("run tap in", composed)

    def test_opencode_without_a_prompt_still_launches(self):
        # Bare clear (no -m) already works; this argv must stay a launch, not a
        # refusal. Regression arm for tap-0jtk: the prompt axis is a channel,
        # not an outage.
        argv = launcher.build_harness_invocation("new", self._record("opencode")).argv
        self.assertEqual(argv[0], "opencode")

    def test_passthrough_stays_ahead_of_the_prompt(self):
        # inject_passthrough splices after argv[0] precisely so a trailing
        # positional stays trailing. If that ordering ever flips, a tuned seat's
        # flags would be parsed as part of the prompt text.
        record = self._record("codex", harness_passthrough=["-c", 'model_reasoning_effort="high"'])
        invocation = launcher.inject_passthrough(
            launcher.build_harness_invocation("new", record, "run tap in"), record
        )
        self.assertEqual(invocation.argv[1:3], ["-c", 'model_reasoning_effort="high"'])
        self.assertEqual(invocation.argv[-1], "run tap in")

    def test_launch_invocation_threads_the_prompt_through_the_composed_path(self):
        # tap clear must go through launch_invocation, not the bare builder:
        # apply_launch_env and inject_passthrough live here, and a raw builder
        # call would silently drop a seat's env and its persisted tuning
        # (the tap-9zwt effort-reversion footgun).
        record = self._record("claude", harness_passthrough=["--add-dir", "/w"])
        argv = launcher.launch_invocation("new", record, initial_prompt="run tap in").argv
        self.assertEqual(argv[1:3], ["--add-dir", "/w"])
        self.assertEqual(argv[-1], "run tap in")

    def test_launch_invocation_splices_harness_yolo_ahead_of_the_prompt(self):
        record = self._record("cursor")
        with tempfile.TemporaryDirectory() as tmp:
            config = pathlib.Path(tmp) / "tap" / "config.toml"
            config.parent.mkdir(parents=True)
            config.write_text(
                'version = 2\n[harness.cursor]\nparams.yolo = true\n',
                encoding="utf-8",
            )
            config.chmod(0o600)
            with mock.patch.dict(os.environ, {"XDG_CONFIG_HOME": tmp}, clear=False):
                argv = launcher.launch_invocation(
                    "new", record, initial_prompt="run tap in"
                ).argv
        self.assertEqual(argv[0], "cursor-agent")
        self.assertEqual(argv[1], "--yolo")
        self.assertEqual(argv[-1], "run tap in")
        self.assertEqual(argv.count("--yolo"), 1)
        self.assertIn("--force", argv)

    def test_adopted_native_resume_splices_harness_params(self):
        # Adopted rows have empty passthrough by construction. Skipping the
        # harness-table splice on run_native_resume is how a cursor seat
        # launched with --yolo and resumed without it. Drive THIS function,
        # not compose_child_invocation: reverting run_native_resume to its
        # pre-fix shape left the suite green.
        record = self._record("cursor")
        captured = []

        def capture_invocation(_record, invocation, *_args, **_kwargs):
            captured.append(list(invocation.argv))
            return 0

        with tempfile.TemporaryDirectory() as tmp:
            config = pathlib.Path(tmp) / "tap" / "config.toml"
            config.parent.mkdir(parents=True)
            config.write_text(
                'version = 2\n[harness.cursor]\nparams.yolo = true\n',
                encoding="utf-8",
            )
            config.chmod(0o600)
            with mock.patch.dict(os.environ, {"XDG_CONFIG_HOME": tmp}, clear=False), \
                 mock.patch.object(launcher, "run_invocation", side_effect=capture_invocation):
                rc = launcher.run_native_resume(
                    record, native_query=None, dry_run=False, attach=False
                )
        self.assertEqual(rc, 0)
        self.assertEqual(len(captured), 1)
        argv = captured[0]
        self.assertEqual(argv[0], "cursor-agent")
        self.assertEqual(argv.count("--yolo"), 1)
        self.assertIn("--yolo", argv)
        self.assertIn("--force", argv)

    def test_preset_passthrough_does_not_duplicate_builder_safety_flags(self):
        record = self._record(
            "claude",
            harness_passthrough=["--dangerously-skip-permissions", "--effort", "high"],
            passthrough_from_config=True,
        )
        argv = launcher.launch_invocation("new", record).argv
        self.assertEqual(argv.count("--dangerously-skip-permissions"), 1)
        self.assertIn("--effort", argv)
        self.assertIn("high", argv)

    def test_operator_passthrough_duplicate_of_a_builder_flag_still_lands(self):
        record = self._record(
            "claude",
            harness_passthrough=["--dangerously-skip-permissions"],
        )
        argv = launcher.launch_invocation("new", record).argv
        self.assertGreaterEqual(argv.count("--dangerously-skip-permissions"), 2)


class ClearRebindPredicateTest(unittest.TestCase):
    """The witness half of `tap clear` (tap-eb9h).

    respawn-pane preserves the pane id deliberately, so `handle -> pane_id` is
    true before the clear, after it, and when the respawn does nothing at all.
    Every test here exists to prove the predicate is NOT satisfied by its own
    failure cases — a predicate that only ever goes green verifies nothing.
    """

    NONCE = "8d1c0a2e-0000-4000-8000-clear000nonce"

    def _registry(self, root, **row):
        registry = pathlib.Path(root) / ".tap" / "bus" / "registry.json"
        registry.parent.mkdir(parents=True, exist_ok=True)
        entry = {
            "status": "active",
            "delivery": "pane",
            "harness": "claude",
            "session": "repo/opus",
            "pane": "repo/opus:0.0",
            "pane_id": "%41",
            "registered_at": "2099-01-01T00:00:00Z",
        }
        entry.update(row)
        registry.write_text(json.dumps({
            "team": {"name": "repo", "worktree_root": str(root)},
            "agents": {"opus": entry},
        }) + "\n")
        return registry

    @contextlib.contextmanager
    def _bus(self, root, registry):
        with mock.patch.object(launcher, "root_for_cwd", return_value=str(root)), \
             mock.patch.object(launcher, "writable_tap_registry_path", return_value=registry), \
             mock.patch.object(launcher, "tap_registry_path", return_value=registry), \
             mock.patch.object(launcher, "current_server_epoch", return_value=None):
            yield

    def test_verifies_when_the_new_process_registered_with_this_clears_nonce(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(
                tmp, clear_nonce=self.NONCE, expected_clear_nonce=self.NONCE
            )
            with self._bus(tmp, registry):
                self.assertTrue(
                    launcher.clear_rebind_verified(str(tmp), "opus", "%41", self.NONCE)
                )

    def test_a_respawn_that_did_nothing_fails_the_predicate(self):
        # THE LOAD-BEARING ARM. The old process is still there, still bound to the
        # same handle at the same pane — the exact state a silent no-op leaves —
        # and it never carried this clear's nonce. Pane identity alone would call
        # this a success.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp, expected_clear_nonce=self.NONCE)  # nothing re-registered
            with self._bus(tmp, registry):
                self.assertFalse(
                    launcher.clear_rebind_verified(str(tmp), "opus", "%41", self.NONCE)
                )

    def test_a_previous_clears_nonce_does_not_satisfy_this_one(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(
                tmp, clear_nonce="an-older-clear", expected_clear_nonce=self.NONCE
            )
            with self._bus(tmp, registry):
                self.assertFalse(
                    launcher.clear_rebind_verified(str(tmp), "opus", "%41", self.NONCE)
                )

    def test_a_rebind_onto_a_different_pane_is_not_this_clear(self):
        # The identity fork the whole mechanism exists to prevent: something came
        # up and registered, but not in the pane we respawned.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(
                tmp, pane_id="%99", clear_nonce=self.NONCE, expected_clear_nonce=self.NONCE
            )
            with self._bus(tmp, registry):
                self.assertFalse(
                    launcher.clear_rebind_verified(str(tmp), "opus", "%41", self.NONCE)
                )

    def test_a_concurrent_clear_that_displaced_our_claim_is_not_our_success(self):
        # Two clears of one seat. The other stamped after us, so the row's
        # expectation is THEIRS — and the rebind it produced is not evidence for
        # our command, however genuine it looks. Without the expectation check
        # this returns True and the loser reports a success it did not cause.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(
                tmp, clear_nonce=self.NONCE, expected_clear_nonce="a-later-clears-nonce"
            )
            with self._bus(tmp, registry):
                self.assertFalse(
                    launcher.clear_rebind_verified(str(tmp), "opus", "%41", self.NONCE)
                )

    def test_an_unstamped_row_can_never_verify(self):
        # The expectation is written before the respawn, so its absence means no
        # clear ever claimed this row — nothing here is ours to verify.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp, clear_nonce=self.NONCE)
            with self._bus(tmp, registry):
                self.assertFalse(
                    launcher.clear_rebind_verified(str(tmp), "opus", "%41", self.NONCE)
                )

    def test_an_empty_nonce_can_never_verify(self):
        # Guards the degenerate call: if a caller ever loses its nonce, the
        # predicate must refuse rather than match a row that also has none.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            with self._bus(tmp, registry):
                self.assertFalse(launcher.clear_rebind_verified(str(tmp), "opus", "%41", ""))

    def test_stamping_the_expectation_clears_a_stale_witness(self):
        # Written before the respawn: the old clear's nonce must not survive into
        # the window where the new one is being verified.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp, clear_nonce="an-older-clear")
            with self._bus(tmp, registry):
                launcher.stamp_expected_clear_nonce(str(tmp), "opus", self.NONCE)
            row = json.loads(registry.read_text())["agents"]["opus"]
            self.assertEqual(row["expected_clear_nonce"], self.NONCE)
            self.assertNotIn("clear_nonce", row)

    def test_stamping_preserves_unrelated_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp, cost_mode="subscription")
            with self._bus(tmp, registry):
                launcher.stamp_expected_clear_nonce(str(tmp), "opus", self.NONCE)
            row = json.loads(registry.read_text())["agents"]["opus"]
            self.assertEqual(row["cost_mode"], "subscription")
            self.assertEqual(row["session"], "repo/opus")

    def test_consume_pops_only_this_clears_pending_question(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp, expected_clear_nonce=self.NONCE)
            with self._bus(tmp, registry):
                launcher.consume_expected_clear_nonce(str(tmp), "opus", self.NONCE)
            row = json.loads(registry.read_text())["agents"]["opus"]
            self.assertNotIn("expected_clear_nonce", row)

    def test_consume_leaves_a_foreign_pending_question(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp, expected_clear_nonce="a-later-clears-nonce")
            with self._bus(tmp, registry):
                launcher.consume_expected_clear_nonce(str(tmp), "opus", self.NONCE)
            row = json.loads(registry.read_text())["agents"]["opus"]
            self.assertEqual(row["expected_clear_nonce"], "a-later-clears-nonce")


class ClearDiagnosisTest(unittest.TestCase):
    """`tap clear`'s post-timeout diagnosis and calibration record (tap-36kb).

    The three generic post-timeout states were already observed and distinguished
    in prose; relaunch adds the known zero-result picker. Automation must never
    confuse still-starting, dead, wrong-process, and unusable-picker outcomes.
    """

    class _Pane:
        """Only what the diagnosis reads. `pane_harness` is patched below rather
        than left to shell out to lib.sh and walk real processes: this branch is
        being tested, not the harness classifier, and a unit test that depends on
        the host's process table is a different (worse) test."""

        def __init__(self, command):
            self.command = command
            self.pane = "repo/opus:0.0"
            self.pane_id = "%41"

    @contextlib.contextmanager
    def _classifier(self):
        with mock.patch.object(launcher, "pane_harness", side_effect=lambda facts: facts.command):
            yield

    def test_each_post_timeout_state_gets_its_own_error_class(self):
        # All three inputs, and all three classes distinct — a caller branching on
        # them cannot if two states share a name.
        with self._classifier():
            gone, _ = launcher.clear_unverified_diagnosis(None)
            stranger, stranger_prose = launcher.clear_unverified_diagnosis(self._Pane("zsh"))
            starting, _ = launcher.clear_unverified_diagnosis(self._Pane("claude"))
        self.assertEqual(gone, "rebind_unverified_pane_gone")
        self.assertEqual(stranger, "rebind_unverified_not_a_harness")
        self.assertEqual(starting, "rebind_unverified_starting")
        self.assertEqual(len({gone, stranger, starting}), 3)
        # The human sentence still names what was actually observed: the class is
        # an ADDITION for automation, not a replacement for the diagnosis.
        self.assertIn("zsh", stranger_prose)

    def test_the_starting_class_is_the_one_that_may_resolve_itself(self):
        # Pinned separately because it is the arm the fleet run produced twice and
        # the one automation must not treat as dead: a live harness that simply
        # had not registered yet.
        with self._classifier():
            klass, prose = launcher.clear_unverified_diagnosis(self._Pane("claude"))
        self.assertEqual(klass, "rebind_unverified_starting")
        self.assertIn("still", prose)

    def test_zero_result_picker_is_not_reported_as_still_starting(self):
        with self._classifier(), mock.patch.object(
            launcher, "pane_startup_blocker", return_value="codex resume picker has zero results"
        ):
            klass, prose = launcher.clear_unverified_diagnosis(
                self._Pane("codex"), "codex"
            )
        self.assertEqual(klass, "harness_start_unverified_picker")
        self.assertIn("zero results", prose)

    def test_the_timeout_is_family_keyed_and_unlisted_families_keep_the_old_value(self):
        # agy and opencode both blew through the 45s global on 2026-08-14 and then
        # registered fine seconds later: a clear reported unverified because the
        # ceiling was a guess about a different harness.
        self.assertGreater(
            launcher.clear_rebind_timeout("opencode"),
            launcher.clear_rebind_timeout("claude"),
        )
        self.assertEqual(
            launcher.clear_rebind_timeout("agy"), launcher.clear_rebind_timeout("opencode")
        )
        # An unmeasured family gets today's behavior, not a number invented for it.
        self.assertEqual(
            launcher.clear_rebind_timeout("some-harness-nobody-has-measured"),
            launcher.CLEAR_REBIND_TIMEOUT_SECONDS,
        )
        self.assertEqual(
            launcher.clear_rebind_timeout(None), launcher.CLEAR_REBIND_TIMEOUT_SECONDS
        )

    def test_await_honors_the_ceiling_it_is_handed(self):
        # Without this, the family table could be correct and unused — the exact
        # shape of a value computed and then ignored.
        with tempfile.TemporaryDirectory() as tmp:
            registry = pathlib.Path(tmp) / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True, exist_ok=True)
            registry.write_text(json.dumps({"agents": {}}) + "\n")
            import time as _time

            started = _time.monotonic()
            with mock.patch.object(launcher, "clear_rebind_verified", return_value=False):
                self.assertFalse(
                    launcher.await_clear_rebind(str(tmp), "opus", "%41", "n", 0.3)
                )
            # The point of the bound: an ignored ceiling would sit here for the
            # 45s global instead, so this fails on exactly the regression it names.
            self.assertLess(_time.monotonic() - started, 5.0)

    def test_latency_is_recorded_for_BOTH_outcomes(self):
        # The unverified lines are the point. A file holding only the runs that
        # already fit the ceiling calibrates the ceiling against itself.
        with tempfile.TemporaryDirectory() as tmp:
            launcher.record_clear_latency(tmp, "opus", "claude", "%41", True, 3.5, 45.0)
            launcher.record_clear_latency(tmp, "kimi", "opencode", "%42", False, 61.2, 45.0)
            path = pathlib.Path(tmp) / ".tap" / "clear-latency.jsonl"
            lines = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
            self.assertEqual(len(lines), 2)
            self.assertEqual([entry["verified"] for entry in lines], [True, False])
            self.assertEqual(lines[1]["seconds"], 61.2)
            self.assertEqual(lines[1]["harness"], "opencode")
            # The load hint: a rebind measured on a box running a parallel suite is
            # not the same measurement as one taken idle, and a table calibrated
            # from the two mixed together is calibrated from nothing.
            self.assertIn("loadavg1", lines[0])

    def test_recording_latency_never_fails_a_clear(self):
        # Calibration data must not be able to turn a completed clear into an
        # error. The unwritable root is the whole test.
        with tempfile.TemporaryDirectory() as tmp:
            blocked = pathlib.Path(tmp) / "ro"
            blocked.mkdir()
            blocked.chmod(0o500)
            try:
                launcher.record_clear_latency(
                    str(blocked), "opus", "claude", "%41", True, 1.0, 45.0
                )
            finally:
                blocked.chmod(0o700)


class ClearTargetPaneTest(unittest.TestCase):
    """Which panes `tap clear` refuses to respawn, and why (tap-eb9h)."""

    def _registry(self, root, **row):
        return ClearRebindPredicateTest._registry(self, root, **row)

    _bus = ClearRebindPredicateTest._bus

    def _facts(self, pane_id="%41"):
        return launcher.PaneFacts(pane=f"repo/opus:0.0", pane_id=pane_id, command="claude", path="")

    def test_resolves_a_live_pane(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=self._facts()), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value="%7"), \
                 mock.patch.dict(os.environ, {"TMUX_PANE": "%7"}, clear=False):
                pane_id, entry = launcher.clear_target_pane(str(tmp), "opus")
            self.assertEqual(pane_id, "%41")
            self.assertEqual(entry["harness"], "claude")

    def test_refuses_a_seat_that_is_not_on_the_bus(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            with self._bus(tmp, registry):
                with self.assertRaises(launcher.LauncherError) as caught:
                    launcher.clear_target_pane(str(tmp), "nobody")
            self.assertIn("no seat 'nobody'", str(caught.exception))

    def test_refuses_when_the_registered_pane_is_gone(self):
        # Clear replaces a live process in place. With no process there it has
        # nothing to do, and the operator needs the RELAUNCH path instead — so the
        # refusal names it rather than just reporting the state.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=None):
                with self.assertRaises(launcher.LauncherError) as caught:
                    launcher.clear_target_pane(str(tmp), "opus")
            self.assertIn("tap session restart opus", str(caught.exception))

    def test_refuses_when_the_probe_answers_for_a_different_pane(self):
        # NOT a real-tmux scenario: `display-message -t %41` cannot answer with
        # %99. This pins the DEFENSIVE identity re-check itself — that the code
        # compares what came back against what it asked for, rather than trusting
        # the reply — so a future refactor to a probe that CAN mismatch (a
        # list-panes scan, a cached facts map) does not silently lose the check.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=self._facts("%99")):
                with self.assertRaises(launcher.LauncherError):
                    launcher.clear_target_pane(str(tmp), "opus")

    def test_refuses_when_the_pane_id_was_recycled_into_another_session(self):
        # The real recycling case, and the one that matters: the id resolves, but
        # to a pane now living in somebody else's session. Existence alone would
        # authorize replacing a stranger's process.
        stranger = launcher.PaneFacts(
            pane="someone-else/shell:0.0", pane_id="%41", command="claude", path=""
        )
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=stranger), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value="%7"), \
                 mock.patch.dict(os.environ, {"TMUX_PANE": "%7"}, clear=False):
                with self.assertRaises(launcher.LauncherError) as caught:
                    launcher.clear_target_pane(str(tmp), "opus")
        message = str(caught.exception)
        self.assertIn("someone-else/shell", message)
        self.assertIn("recycled", message)

    def test_refuses_inside_tmux_when_the_caller_cannot_prove_its_own_pane(self):
        # The self-clear guard must FAIL CLOSED. Reading TMUX_PANE alone lets a
        # caller whose environment lost the variable — a child process, env -i, an
        # in-pane helper — walk past the refusal and end its own transaction.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            env = {k: v for k, v in os.environ.items() if k != "TMUX_PANE"}
            env["TMUX"] = "/tmp/tmux-501/default,123,0"
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=self._facts()), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
                 mock.patch.dict(os.environ, env, clear=True):
                with self.assertRaises(launcher.LauncherError) as caught:
                    launcher.clear_target_pane(str(tmp), "opus")
        self.assertIn("cannot prove it is not the target", str(caught.exception))

    def test_a_stale_tmux_pane_cannot_smuggle_a_self_clear_past_the_guard(self):
        # THE SLIVER the env var alone left open: TMUX_PANE says %7, so the cheap
        # comparison passes, but the caller's controlling tty actually belongs to
        # the TARGET pane. Trusting the inherited variable would let the command
        # end its own process; the tty-derived answer is the authoritative one.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=self._facts()), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value="%41"), \
                 mock.patch.dict(os.environ, {"TMUX_PANE": "%7"}, clear=False):
                with self.assertRaises(launcher.LauncherError) as caught:
                    launcher.clear_target_pane(str(tmp), "opus")
        self.assertIn("its own pane", str(caught.exception))

    def test_an_unprovable_caller_is_refused_even_when_tmux_pane_looks_innocent(self):
        # THE ADJACENT SLIVER: the tty walk FAILS (unobservable) while a stale
        # TMUX_PANE still holds a plausible, non-matching value. Consulting the
        # env var as a fallback would make that truthy value both pass the
        # equality AND suppress the unprovable-caller refusal — the untrusted
        # source deciding exactly the case the walk could not answer. The env var
        # is therefore not read at all; unprovable inside tmux is a refusal.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=self._facts()), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
                 mock.patch.dict(
                     os.environ,
                     {"TMUX": "/tmp/tmux-501/default,123,0", "TMUX_PANE": "%7"},
                     clear=False,
                 ):
                with self.assertRaises(launcher.LauncherError) as caught:
                    launcher.clear_target_pane(str(tmp), "opus")
        self.assertIn("cannot prove it is not the target", str(caught.exception))

    def test_allows_a_caller_outside_tmux_entirely(self):
        # Absence of TMUX is a POSITIVE discriminator, not missing evidence: a
        # caller not in tmux at all cannot be the target pane. Cron and daemon
        # callers must keep working.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            env = {k: v for k, v in os.environ.items() if k not in ("TMUX", "TMUX_PANE")}
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=self._facts()), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
                 mock.patch.dict(os.environ, env, clear=True):
                pane_id, _entry = launcher.clear_target_pane(str(tmp), "opus")
            self.assertEqual(pane_id, "%41")

    def test_tap_self_is_never_consulted_for_the_caller_identity(self):
        # AN UNSPELLABLE GUARANTEE NEEDS ITS TEST, because the code cannot show
        # it: "tap clear never reads TAP_SELF" is invisible as an absence, and a
        # future edit that adds the read breaks nothing that exists.
        #
        # Migrated coverage (tap-pz3j). The retired `tap command clear` surface
        # evidenced this as a REFUSAL — command-mode.test.sh set TAP_SELF to a
        # peer handle and asserted the initiator refusal still fired, so the
        # spoof was visible in the outcome. That surface is gone, and the same
        # spoof against `tap clear` produces no observable difference at all,
        # which is stronger and also unfalsifiable by outcome alone. Hence a
        # structural arm: the caller identity comes from the controlling tty, and
        # a TAP_SELF naming a DIFFERENT seat changes nothing about the decision.
        #
        # Both directions, because "nothing happened" is satisfied by a function
        # that does nothing: the spoof must not create a refusal where the tty
        # says elsewhere, AND must not suppress one where the tty says self.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            spoof = {"TAP_SELF": "opus", "TMUX": "/tmp/tmux-501/default,123,0"}
            # Caller is provably a DIFFERENT pane; TAP_SELF claims to be the
            # target's own handle. Allowed, because the tty is the authority.
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=self._facts()), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value="%99"), \
                 mock.patch.dict(os.environ, spoof, clear=False):
                pane_id, _entry = launcher.clear_target_pane(str(tmp), "opus")
            self.assertEqual(pane_id, "%41")
            # Caller IS the target pane; TAP_SELF names an unrelated seat. Still
            # refused — a spoofed identity cannot buy a self-clear.
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=self._facts()), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value="%41"), \
                 mock.patch.dict(os.environ, {**spoof, "TAP_SELF": "someone-else"}, clear=False):
                with self.assertRaises(launcher.LauncherError) as caught:
                    launcher.clear_target_pane(str(tmp), "opus")
            # "from inside its own pane" and not "its own pane": the SIBLING
            # unprovable-caller guard says "cannot identify its own pane", so the
            # looser substring is satisfied by a different refusal than the one
            # under test — and a TAP_SELF read that empties caller_pane falls
            # through to exactly that sibling. Direction 2 exists because
            # "nothing happened" is satisfied by a function that does nothing; a
            # shared phrase makes it satisfiable by the wrong guard firing.
            self.assertIn("from inside its own pane", str(caught.exception))

    def test_refuses_to_clear_the_pane_it_is_running_in(self):
        # Self-clear kills the command mid-transaction: the respawn never returns
        # to verify, so the seat comes back with nobody watching.
        with tempfile.TemporaryDirectory() as tmp:
            registry = self._registry(tmp)
            with self._bus(tmp, registry), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=self._facts()), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value="%41"), \
                 mock.patch.dict(os.environ, {"TMUX_PANE": "%41"}, clear=False):
                with self.assertRaises(launcher.LauncherError) as caught:
                    launcher.clear_target_pane(str(tmp), "opus")
            self.assertIn("its own pane", str(caught.exception))


class ClearYieldToResetFenceTest(unittest.TestCase):
    """tap-dgdn round 4: after acquiring its fence, clear RECHECKS the reset fence.

    The one-time check at cmd_clear entry runs before the clear fence exists,
    so a reset acquiring its fence in that interval revalidates against an
    empty clear-fence dir. Whichever side claims second must see the other's
    claim; this pins the clear side of that handshake, including the release
    (a refused clear must not leave a fence that parks courier traffic).
    """

    def test_yields_and_releases_when_reset_fenced(self):
        with tempfile.TemporaryDirectory() as bus:
            bus_path = pathlib.Path(bus)
            held = launcher.clear_fence.try_acquire(
                bus_path, "seat", "n-race", os.getpid(), "codex", 90.0,
            )
            self.assertIsNotNone(held, "fresh bus must grant the fence")
            (bus_path / "reset.fence.json").write_text("{}")
            with mock.patch.object(launcher, "_team_bus_home", return_value=bus_path):
                with self.assertRaises(launcher.LauncherError):
                    launcher._clear_yield_if_reset_fenced(held)
            marker = launcher.clear_fence.fence_path(bus_path, "seat")
            self.assertEqual(
                marker.read_text().strip(), "",
                "yielding must RELEASE the claim (truncate-in-place), not abandon it live",
            )

    def test_no_reset_fence_keeps_claim(self):
        with tempfile.TemporaryDirectory() as bus:
            bus_path = pathlib.Path(bus)
            held = launcher.clear_fence.try_acquire(
                bus_path, "seat", "n-calm", os.getpid(), "codex", 90.0,
            )
            with mock.patch.object(launcher, "_team_bus_home", return_value=bus_path):
                launcher._clear_yield_if_reset_fenced(held)
            marker = launcher.clear_fence.fence_path(bus_path, "seat")
            self.assertEqual(
                json.loads(marker.read_text())["nonce"], "n-calm",
                "a passing recheck must not disturb the claim",
            )
            held.release()

    def test_replacement_transaction_wires_the_recheck_after_acquire(self):
        # A helper with zero callers is the classic way this dies silently.
        #
        # The call lives in replace_harness_in_pane, the ONE in-pane replacement
        # transaction both tap clear and tap session relaunch run. Asserting it
        # there rather than in cmd_clear is what keeps this guard honest after the
        # extraction: checking cmd_clear's own source would now pass on a body that
        # merely delegates, and would go silent for relaunch entirely.
        import inspect as _inspect

        src = _inspect.getsource(launcher.replace_harness_in_pane)
        self.assertIn(
            "_clear_yield_if_reset_fenced",
            src,
            "the in-pane replacement transaction must call the recheck",
        )
        self.assertLess(
            src.index("clear_fence.try_acquire"),
            src.index("_clear_yield_if_reset_fenced"),
            "the recheck must come AFTER the fence is visible (store-then-load), not before",
        )

    def test_both_verbs_route_through_the_one_transaction(self):
        # The extraction's whole value is that neither verb owns a second copy of
        # the fence/nonce/remain-on-exit window. If either stops delegating, every
        # guarantee asserted against the transaction above goes silent for it.
        import inspect as _inspect

        # relaunch_one, not cmd_relaunch: since unit 2b, cmd_relaunch is a
        # dispatcher (single seat vs --harness batch) and the in-pane work lives in
        # relaunch_one. This is the second time this guard has needed re-aiming
        # after a refactor — that is the cost of a source-inspection guard, and it
        # is worth paying here because the property it protects (neither verb owns
        # a second copy of the fence/nonce/remain-on-exit window) is invisible to
        # any behavioural test that mocks the transaction out.
        for verb in (launcher.cmd_clear, launcher.relaunch_one):
            src = _inspect.getsource(verb)
            self.assertIn(
                "replace_harness_in_pane",
                src,
                f"{verb.__name__} must delegate to the shared replacement transaction",
            )
            self.assertNotIn(
                "clear_fence.try_acquire",
                src,
                f"{verb.__name__} must not open a second fence of its own",
            )


class SessionRelaunchTest(unittest.TestCase):
    """`tap session relaunch` — same seat, SAME conversation (tap-834qn).

    The mechanism is tap clear's and is asserted against the shared transaction
    elsewhere. What is unique to this verb, and what these arms pin, is the
    CONTRACT: it is machine-scoped, it fences the TARGET team, and it refuses
    rather than silently degrading into a fresh conversation.
    """

    def _record(self, harness="codex", native_id="01a04591-310e-7fa3-86ae-368bfd51a104"):
        return launcher.SessionRecord(
            name="tap/luna", harness=harness, cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id=native_id,
        )

    # The row and the launcher record must describe the SAME seat. An earlier
    # version carried neither harness nor conversation id here while the record
    # carried both, so once the record was bound to the guarded identity the
    # guard correctly reported drift the FIXTURE had invented.
    ROW = {"session": "tap/luna", "delivery": "pane", "status": "active",
           "pane_id": "%41", "pane": "tap/luna:0.0", "harness": "codex",
           "harness_session_id": "01a04591-310e-7fa3-86ae-368bfd51a104"}

    def _run(self, key="tap/luna", record=None, dry_run=True, message=None, calls=None, env=None,
             expect=None, acting_row=None, expect_resume=_UNSET,
             rebind_verified=True, pane_facts=_UNSET, pane_dead=False,
             rebind_timeout=None, stamp_calls=None, after_pane_pid=2002,
             registry_row=None, pane_capture="", overrides=None):
        record = record or self._record()
        if pane_facts is _UNSET:
            pane_facts = launcher.PaneFacts(
                pane="tap/luna:0.0", pane_id="%41", command=record.harness,
                path=record.cwd, server_epoch="srv:1:1", dead=pane_dead,
                pane_pid=1001,
            )
        elif pane_facts is not None:
            pane_facts.dead = pane_dead
            pane_facts.server_epoch = pane_facts.server_epoch or "srv:1:1"
        respawned = []

        def current_facts(*_a, **_k):
            if pane_facts is None:
                return None
            if respawned:
                return dataclasses.replace(pane_facts, pane_pid=after_pane_pid)
            return pane_facts

        args = types.SimpleNamespace(seat=key, message=message, dry_run=dry_run)

        def fake_run(cmd, **kwargs):
            if calls is not None:
                calls.append(list(cmd))
            if cmd and len(cmd) > 1 and cmd[1] == "respawn-pane":
                respawned.append(True)
            stdout = pane_capture if cmd and len(cmd) > 1 and cmd[1] == "capture-pane" else ""
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout=stdout, stderr="")

        out, err = io.StringIO(), io.StringIO()
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher.registry_v20, "resolve_team_from_global",
                                   return_value=("ok", bus, f"{bus}/team-registry.json")), \
                 mock.patch.object(launcher, "refuse_if_team_reset_fenced") as fenced, \
                 mock.patch.object(launcher, "registry_entry",
                                   return_value=dict(registry_row or self.ROW)), \
                 mock.patch.object(launcher, "clear_target_pane",
                                   return_value=("%41", acting_row or dict(self.ROW))), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[record], dir_aliases={})), \
                 mock.patch.object(launcher, "entry_session_name", return_value="tap/luna"), \
                 mock.patch.object(
                     launcher, "stamp_expected_clear_nonce",
                     side_effect=(
                         (lambda *a, **kw: stamp_calls.append(a))
                         if stamp_calls is not None else None
                     ),
                 ), \
                 mock.patch.object(launcher, "consume_expected_clear_nonce"), \
                 mock.patch.object(launcher, "await_clear_rebind", return_value=rebind_verified), \
                 mock.patch.object(launcher, "tmux_pane_facts", side_effect=current_facts), \
                 mock.patch.object(
                     launcher, "clear_rebind_timeout",
                     return_value=(
                         launcher.CLEAR_REBIND_TIMEOUT_SECONDS
                         if rebind_timeout is None else rebind_timeout
                     ),
                 ), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ, env or {}, clear=False), \
                 contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                if expect is None:
                    rc = launcher.cmd_relaunch(args)
                else:
                    kw = {} if expect_resume is _UNSET else {"expect_resume": expect_resume}
                    try:
                        rc = launcher.relaunch_one(key, message, dry_run, expect=expect, overrides=overrides, **kw)
                    except BaseException as exc:
                        # THE CAPTURED OUTPUT MUST SURVIVE THE RAISE. `_run`
                        # redirects stdout internally, so an outer
                        # `redirect_stdout` in a caller sees nothing and any
                        # "printed nothing" assertion built on it is vacuous
                        # twice over. Attaching the buffer to the exception lets
                        # a refusal arm assert on what was actually emitted
                        # before the raise.
                        exc.captured_stdout = out.getvalue()
                        exc.captured_stderr = err.getvalue()
                        raise
        return rc, out.getvalue(), err.getvalue(), fenced

    def test_overrides_keep_conversation_and_reach_the_persisted_recipe(self):
        record = self._record()
        record.harness_env = {"WINDOW": "old", "KEEP": "yes"}
        record.harness_tail = ["-c", "model_context_window=100000"]
        seen = {}
        @contextlib.contextmanager
        def stamp(*args, **kwargs):
            seen.update(kwargs)
            yield
        calls = []
        with mock.patch.object(launcher, "authorized_clear_stamp", stamp):
            rc, out, err, _ = self._run(
                record=record, dry_run=False, calls=calls,
                expect=launcher.relaunch_identity(self.ROW),
                overrides={"unset_env": ["WINDOW"], "argv": ["-c", "model_context_window=250000"]})
        self.assertEqual(rc, 0, out + err)
        self.assertEqual(seen["recipe"], {
            "harness_env": {"KEEP": "yes"}, "harness_unset_env": ["WINDOW"],
            "harness_tail": ["-c", "model_context_window=100000", "-c", "model_context_window=250000"]})
        command = next(call[-1] for call in calls if call[1] == "respawn-pane")
        self.assertIn(record.harness_session_id, command)
        self.assertIn("-u WINDOW", command)
        self.assertTrue(command.endswith("model_context_window=250000"), command)

    def test_override_recipe_persists_only_after_identity_authorization(self):
        recipe = {"harness_env": {"WINDOW": "new"}, "harness_unset_env": ["OLD"], "harness_tail": ["-c", "x=1"]}
        expected = launcher.relaunch_identity(self.ROW)
        calls, err = self._authz(expect=expected, expect_resume="same", resume="same", recipe=recipe)
        self.assertIsNone(err)
        for key, value in recipe.items():
            self.assertEqual(calls["row"][key], value)
        calls, err = self._authz(expect=expected, row={**self.ROW, "pane_id": "%99"}, recipe=recipe)
        self.assertIsNotNone(err)
        self.assertEqual(calls["respawn"], 0)
        self.assertNotIn("harness_tail", calls["row"])

    def test_relaunch_returns_seven_when_process_identity_is_unchanged(self):
        # THE OLD HARNESS ALREADY SATISFIES pane/server/alive/command. A no-op
        # respawn that leaves #{pane_pid} unchanged must not count as readiness,
        # or the fleet can report resumed onto new credentials while every old
        # process remains.
        facts = launcher.PaneFacts(
            pane="tap/luna:0.0", pane_id="%41", command="codex", path="/seat/cwd",
            pane_pid=1001, dead=False,
        )
        rc, out, err, _ = self._run(
            dry_run=False,
            rebind_verified=False,
            pane_facts=facts,
            after_pane_pid=1001,
            rebind_timeout=0,
        )
        self.assertEqual(rc, 7, out + err)
        self.assertNotIn("resumed in place", out)

    def test_relaunch_accepts_a_started_harness_without_fresh_registration(self):
        # Relaunch preserves the existing seat row and conversation. A resumed
        # Codex session can therefore be fully usable without writing this
        # command's TAP_CLEAR_ID back through `tap register`; requiring that
        # fresh-clear witness produced a false exit 7 after a successful respawn.
        facts = launcher.PaneFacts(
            pane="tap/luna:0.0", pane_id="%41", command="codex", path="/seat/cwd",
            pane_pid=1001, dead=False,
        )
        rc, out, err, _ = self._run(
            dry_run=False, rebind_verified=False, pane_facts=facts,
            after_pane_pid=2002,
        )
        self.assertEqual(rc, 0, out + err)
        self.assertIn("respawned tap/luna", out)
        self.assertIn("waiting for codex to start", out)

    def test_relaunch_returns_seven_for_a_dead_pane_that_still_names_the_harness(self):
        # remain-on-exit keeps the pane and its last command visible after a
        # stillborn respawn. Command-name equality alone would therefore turn a
        # dead `codex` pane into a false success.
        facts = launcher.PaneFacts(
            pane="tap/luna:0.0", pane_id="%41", command="codex", path="/seat/cwd",
            pane_pid=1001, dead=True,
        )
        rc, out, err, _ = self._run(
            dry_run=False,
            pane_facts=facts,
            pane_dead=True,
            rebind_timeout=0,
        )
        self.assertEqual(rc, 7, out + err)
        self.assertNotIn("resumed in place", out)
        self.assertIn("the resumed harness process exited before readiness was observed", err)

    def test_relaunch_returns_seven_for_zero_result_resume_picker(self):
        facts = launcher.PaneFacts(
            pane="tap/luna:0.0", pane_id="%41", command="codex", path="/seat/cwd",
            pane_pid=1001, dead=False,
        )
        rc, out, err, _ = self._run(
            dry_run=False,
            pane_facts=facts,
            after_pane_pid=2002,
            pane_capture="No results for your search\n0 / 0 · 100%\nenter resume   esc clear",
        )
        self.assertEqual(rc, 7, out + err)
        self.assertNotIn("resumed in place", out)
        self.assertIn("resume picker has zero results", err)

    def test_relaunch_readiness_rejects_process_change_between_confirmations(self):
        first = launcher.PaneFacts(
            pane="tap/luna:0.0", pane_id="%41", command="codex", path="/seat/cwd",
            server_epoch="srv:1:1", pane_pid=2002, dead=False,
        )
        gone = dataclasses.replace(first, dead=True)
        with mock.patch.object(
            launcher, "tmux_pane_facts", side_effect=[first, gone]
        ) as observed, mock.patch.object(
            launcher.time, "monotonic", side_effect=[0.0, 0.0, 1.0]
        ), mock.patch.object(launcher.time, "sleep"):
            self.assertFalse(
                launcher.await_harness_start(
                    "%41", "codex", 0.5,
                    expected_server_epoch="srv:1:1", previous_pane_pid=1001,
                )
            )
        self.assertEqual(observed.call_count, 2)

    def test_harness_start_rejects_a_different_pane_or_server_generation(self):
        for facts in (
            launcher.PaneFacts(
                pane="tap/luna:0.0", pane_id="%42", command="codex",
                path="/seat/cwd", server_epoch="srv:1:1", dead=False, pane_pid=2002,
            ),
            launcher.PaneFacts(
                pane="tap/luna:0.0", pane_id="%41", command="codex",
                path="/seat/cwd", server_epoch="srv:2:1", dead=False, pane_pid=2002,
            ),
        ):
            with self.subTest(facts=facts), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=facts):
                self.assertFalse(
                    launcher.await_harness_start(
                        "%41", "codex", 0, expected_server_epoch="srv:1:1",
                        previous_pane_pid=1001,
                    )
                )

    def test_harness_start_rejects_the_same_process_identity(self):
        facts = launcher.PaneFacts(
            pane="tap/luna:0.0", pane_id="%41", command="codex",
            path="/seat/cwd", server_epoch="srv:1:1", dead=False, pane_pid=1001,
        )
        with mock.patch.object(launcher, "tmux_pane_facts", return_value=facts):
            self.assertFalse(
                launcher.await_harness_start(
                    "%41", "codex", 0, expected_server_epoch="srv:1:1",
                    previous_pane_pid=1001,
                )
            )

    def test_harness_start_requires_the_observed_server_generation(self):
        with self.assertRaises(TypeError):
            launcher.await_harness_start("%41", "codex", 0)

    def test_harness_start_requires_the_replaced_process_identity(self):
        with self.assertRaises(TypeError):
            launcher.await_harness_start(
                "%41", "codex", 0, expected_server_epoch="srv:1:1"
            )

    def test_relaunch_prints_no_progress_before_final_authorization(self):
        @contextlib.contextmanager
        def refuse_at_boundary(*_args, **_kwargs):
            raise launcher.LauncherError("final identity drift")
            yield  # pragma: no cover

        with mock.patch.object(launcher, "authorized_clear_stamp", refuse_at_boundary), \
             self.assertRaises(launcher.LauncherError) as caught:
            self._run(
                dry_run=False,
                expect=launcher.relaunch_identity(self.ROW),
                expect_resume=self.ROW["harness_session_id"],
            )
        self.assertNotIn("respawned", caught.exception.captured_stdout)
        self.assertNotIn("waiting for", caught.exception.captured_stdout)

    def test_missing_pre_respawn_facts_refuse_before_stamping_or_effect(self):
        stamps = []
        with self.assertRaises(launcher.LauncherError):
            self._run(
                dry_run=False,
                pane_facts=None,
                stamp_calls=stamps,
            )
        self.assertEqual(stamps, [], "a refusal must not leave expected_clear_nonce behind")

    def test_missing_pre_respawn_process_identity_refuses_before_stamping_or_effect(self):
        stamps = []
        facts = launcher.PaneFacts(
            pane="tap/luna:0.0", pane_id="%41", command="codex", path="/seat/cwd",
            server_epoch="srv:1:1", pane_pid=0, dead=False,
        )
        with self.assertRaises(launcher.LauncherError):
            self._run(
                dry_run=False,
                pane_facts=facts,
                stamp_calls=stamps,
            )
        self.assertEqual(stamps, [], "a refusal must not leave expected_clear_nonce behind")

    def test_drift_in_the_ACTING_row_is_refused_before_any_invocation(self):
        # THE ROW THAT MATTERS IS THE ONE THAT DRIVES THE EFFECT. `relaunch_one`
        # reads the registry and checks the expectation, then calls
        # `clear_target_pane`, which RE-READS the registry and returns a fresh
        # row that rebinds `entry`. Session name, resume identity, the rendered
        # invocation, the fence and the respawn all use that second row — which
        # the first comparison never saw.
        #
        # My earlier arm could not detect this: it drifted `registry_entry`
        # before the first guard while stubbing `clear_target_pane` to a fixed
        # row, so the acting row never moved. Here the FIRST read matches the
        # expectation exactly and ONLY the acting row drifts.
        drifted = dict(self.ROW, harness="claude", harness_session_id="sess-new")
        # DERIVED from the fixture row, never hand-written: a literal expectation
        # goes stale the moment the row gains a field, and then reds for a reason
        # that has nothing to do with the arm.
        expect = launcher.relaunch_identity(self.ROW)
        # The guard raises LauncherError; the BATCH turns that into a per-seat
        # refusal and exit 6 (pinned separately). At this level the contract is
        # the raise, and asserting it here rather than a code keeps the two
        # levels honest about which one owns the aggregation.
        with self.assertRaises(launcher.LauncherError) as caught:
            self._run(expect=expect, acting_row=drifted)
        self.assertIn("changed since enumeration", str(caught.exception))
        self.assertIn("harness", str(caught.exception), "the refusal names what moved")

    # NO "no invocation was rendered" ARM LIVES HERE, DELIBERATELY.
    #
    # There were two attempts. The first ran with `dry_run=True` and asserted no
    # subprocess ran — on a path that never subprocesses, so it passed for a
    # reason unrelated to its name and survived the mutation that deletes the
    # guard (grok's panel finding). The second asserted no `--resume` or
    # `would-resume` text appeared, and survived the SAME mutation: measured
    # with the acting-row check deleted, the drifted run still raises — from the
    # session-ownership cross-check further down — and prints nothing either
    # way. Both stdout and stderr are empty with the guard and without it.
    #
    # An observable that is identical in both worlds cannot discriminate, and a
    # third rewording would only hide that behind a better name. The raise arm
    # above IS the control for this property: it fails when the guard is
    # removed, which is the whole question. Adding a companion that cannot fail
    # would inflate the count and weaken the file.

    def _third_snapshot_run(self, record, expect, row=None):
        """Both guarded reads return `row`; the THIRD snapshot returns `record`."""
        row = row or dict(self.ROW, harness="codex", harness_session_id="old-id")
        out, err = io.StringIO(), io.StringIO()
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher.registry_v20, "resolve_team_from_global",
                                   return_value=("ok", bus, f"{bus}/team-registry.json")), \
                 mock.patch.object(launcher, "registry_entry", return_value=row), \
                 mock.patch.object(launcher, "clear_target_pane", return_value=("%41", row)), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[record])), \
                 mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                rc = launcher.relaunch_one("tap/luna", None, True, expect=expect)
        return rc, out.getvalue() + err.getvalue()

    def test_a_drifted_THIRD_snapshot_cannot_retarget_the_launch(self):
        # THE THIRD READ. `registry_session_state` independently re-reads the
        # acting registry, and the SessionRecord chosen from THAT snapshot
        # supplies record.harness, the resume identity and the rendered
        # invocation. Both earlier guards compare `entry`; the object that
        # becomes the command line is `record`. The only cross-check was handle
        # plus session name — neither of which moves when a seat re-registers
        # under a different harness with a new conversation.
        #
        # Measured before this fix (Sol's panel probe): both guarded reads
        # returned the enumerated codex row, the third snapshot returned a claude
        # record with a new id, and a `--harness codex` batch rendered
        # `claude ... --resume new-id` and returned 0.
        drifted = launcher.SessionRecord(
            name="tap/luna", harness="claude", cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id="new-id")
        expect = {"harness": "codex", "pane_id": "%41", "harness_session_id": "old-id"}
        with self.assertRaises(launcher.LauncherError) as caught:
            self._third_snapshot_run(drifted, expect)
        self.assertIn("changed since enumeration", str(caught.exception))
        self.assertIn("claude", str(caught.exception), "the refusal names what it drifted to")

    def test_each_ratified_field_alone_stops_a_retarget(self):
        # Drift in EITHER field the record owns must refuse on its own, so the
        # guard cannot be satisfied by catching only the harness change.
        for harness, native, moved in (("claude", "old-id", "harness"),
                                       ("codex", "new-id", "harness_session_id")):
            with self.subTest(field=moved):
                rec = launcher.SessionRecord(
                    name="tap/luna", harness=harness, cwd="/seat/cwd", base="tap",
                    tag="luna", index=1, harness_session_id=native)
                expect = {"harness": "codex", "pane_id": "%41", "harness_session_id": "old-id"}
                with self.assertRaises(launcher.LauncherError) as caught:
                    self._third_snapshot_run(rec, expect)
                self.assertIn(moved, str(caught.exception))

    def test_the_helper_ignores_fields_the_caller_did_not_hand_it(self):
        # THE NARROWING IS LOAD-BEARING AND ITS MUTANT SURVIVED, so it gets its
        # own arm rather than a comment. The third-snapshot call site holds only
        # harness and session id — a SessionRecord has no pane — and passes a
        # two-key expectation. Comparing the full triple there would test
        # `pane_id` against a record that never had one.
        #
        # Through relaunch_one that mutation is invisible: both sides normalize
        # the missing pane to None, so it never differs. Called directly with a
        # found-row that HAS a pane, the difference is observable, which is the
        # only way to pin the behaviour rather than the coincidence.
        launcher.refuse_on_identity_drift(
            "tap/alpha",
            {"harness": "codex", "harness_session_id": "s-1"},
            {"harness": "codex", "harness_session_id": "s-1", "pane_id": "%99"})

        # ...and a field it WAS handed still refuses.
        with self.assertRaises(launcher.LauncherError):
            launcher.refuse_on_identity_drift(
                "tap/alpha",
                {"harness": "codex", "harness_session_id": "s-1"},
                {"harness": "claude", "harness_session_id": "s-1", "pane_id": "%99"})

    def test_an_unchanged_third_snapshot_still_proceeds(self):
        # The polarity that keeps the third comparison from refusing every seat.
        rec = launcher.SessionRecord(
            name="tap/luna", harness="codex", cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id="old-id")
        expect = {"harness": "codex", "pane_id": "%41", "harness_session_id": "old-id"}
        _rc, text = self._third_snapshot_run(rec, expect)
        self.assertNotIn("changed since enumeration", text)

    def test_an_absent_conversation_id_that_BECOMES_one_is_refused(self):
        # THE REACHABLE CASE, and the one `is not None` let through. A codex row
        # with no stored conversation id is a valid enumerated member:
        # `seat_is_relaunchable` does not require one and batch enumeration
        # requires only a readable harness. The expectation therefore carries
        # `harness_session_id: None` as a MEANINGFUL value.
        #
        # Filtering the check by "value is not None" dropped that field, so a
        # third snapshot supplying `new-id` was accepted and rendered
        # `codex ... resume new-id` at exit 0 — a conversation the batch never
        # classified, which is precisely the promise this verb makes.
        row = {"session": "tap/luna", "delivery": "pane", "status": "active",
               "pane_id": "%41", "pane": "tap/luna:0.0", "harness": "codex"}
        rec = launcher.SessionRecord(
            name="tap/luna", harness="codex", cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id="new-id")
        with self.assertRaises(launcher.LauncherError) as caught:
            self._third_snapshot_run(rec, launcher.relaunch_identity(row), row=row)
        self.assertIn("harness_session_id", str(caught.exception))
        self.assertIn("None -> 'new-id'", str(caught.exception))

    def test_an_absent_conversation_id_that_STAYS_absent_proceeds(self):
        # The polarity for the same field: a seat that legitimately has no stored
        # id must still relaunch, or the fix refuses every id-less codex seat —
        # which is a large fraction of a real fleet.
        row = {"session": "tap/luna", "delivery": "pane", "status": "active",
               "pane_id": "%41", "pane": "tap/luna:0.0", "harness": "codex"}
        rec = launcher.SessionRecord(
            name="tap/luna", harness="codex", cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id=None)
        _rc, text = self._third_snapshot_run(rec, launcher.relaunch_identity(row), row=row)
        self.assertNotIn("changed since enumeration", text)

    def test_an_unchanged_acting_row_still_proceeds(self):
        # The polarity that stops the second comparison from refusing every seat:
        # the same row through both reads must run exactly as before.
        # DERIVED from the fixture row, never hand-written: a literal expectation
        # goes stale the moment the row gains a field, and then reds for a reason
        # that has nothing to do with the arm.
        expect = launcher.relaunch_identity(self.ROW)
        rc, out, err, _ = self._run(expect=expect)
        self.assertNotIn("changed since enumeration", out + err)
        self.assertEqual(rc, 0)

    def _authz(self, *, expect, expect_resume=None, row=None, resume=None, recipe=None):
        """Drive `authorized_clear_stamp` against a real registry file.

        A real file, not a mock: the whole finding is that this function opens
        the registry ITSELF, so a stubbed loader would test the wrong object —
        the mistake that let three earlier controls pass over live defects.
        """
        import contextlib as _c
        calls = {"consume": 0, "respawn": 0}
        with tempfile.TemporaryDirectory() as root:
            reg = pathlib.Path(root) / ".tap" / "bus" / "registry.json"
            reg.parent.mkdir(parents=True)
            reg.write_text(json.dumps({"schema": "0.20", "team": {"name": "tap"},
                                       "agents": {"luna": row or dict(self.ROW)}}))
            kw = {} if expect_resume is _UNSET else {"expect_resume": expect_resume}
            with mock.patch.object(launcher, "resolved_resume_identity",
                                   return_value=resume), \
                 mock.patch.object(launcher, "consume_expected_clear_nonce",
                                   side_effect=lambda *a, **k: calls.__setitem__("consume", calls["consume"] + 1)):
                try:
                    with launcher.authorized_clear_stamp(
                        root, "luna", "our-nonce", tag="tap/luna", expect=expect, recipe=recipe, **kw
                    ):
                        calls["respawn"] += 1
                    err = None
                except launcher.LauncherError as exc:
                    err = str(exc)
            calls["row"] = json.loads(reg.read_text())["agents"]["luna"]
        return calls, err

    def test_stamp_time_drift_writes_nothing_and_never_reaches_the_effect(self):
        # THE MEASURED DEFECT. The stamp opened the registry by handle 38 lines
        # before the respawn and wrote our nonce onto whatever row was there — a
        # seat this batch refused to touch — then consume popped it, leaving that
        # seat's concurrent clear with neither expectation nor witness.
        stranger = dict(self.ROW, harness="claude", pane_id="%99",
                        harness_session_id="new-id",
                        expected_clear_nonce="stranger-nonce",
                        clear_nonce="stranger-witness")
        calls, err = self._authz(expect=launcher.relaunch_identity(self.ROW), row=stranger)
        self.assertIsNotNone(err, "a drifted row must refuse")
        self.assertIn("changed since enumeration", err)
        self.assertEqual(calls["respawn"], 0, "no effect may run for an unauthorized row")
        self.assertEqual(calls["consume"], 0, "the refusal must not reach consume")
        # The stranger's OWN nonce fields are untouched — the property the
        # measured defect violated.
        self.assertEqual(calls["row"]["expected_clear_nonce"], "stranger-nonce")
        self.assertEqual(calls["row"]["clear_nonce"], "stranger-witness")

    def test_effective_resume_drift_refuses_though_the_raw_field_never_moved(self):
        # P1-2. `resolved_resume_identity` walks a chain, so for claude the
        # conversation that reaches argv can change while the row's bytes do not
        # — a transcript file appearing on disk suffices. Comparing the raw
        # stored id cannot see it; the resolver has to run.
        calls, err = self._authz(expect=launcher.relaunch_identity(self.ROW),
                                 expect_resume="ghost-id", resume="new-id")
        self.assertIsNotNone(err)
        self.assertIn("different conversation", err)
        self.assertEqual(calls["respawn"], 0)
        self.assertNotIn("expected_clear_nonce", calls["row"],
                         "a refusal must not stamp")

    def test_effective_none_to_some_refuses(self):
        # The transition the `is not None` class of bug always lets through.
        _calls, err = self._authz(expect=launcher.relaunch_identity(self.ROW),
                                  expect_resume=None, resume="new-id")
        self.assertIsNotNone(err)
        self.assertIn("None", err)

    def test_an_authorized_row_stamps_and_runs_the_effect_under_the_lock(self):
        # The polarity: an unchanged row must stamp, clear any previous witness,
        # and run the caller's effect.
        # THE ROW MUST CARRY A PREVIOUS WITNESS FOR ITS REMOVAL TO MEAN ANYTHING.
        # Without one, `assertNotIn("clear_nonce", ...)` passes whether or not the
        # pop runs — measured: deleting the pop survived this arm. A stale witness
        # left behind would let a respawn that never registers verify against a
        # previous clear's evidence, which is the whole reason the pop exists.
        stale = dict(self.ROW, clear_nonce="previous-witness")
        calls, err = self._authz(expect=launcher.relaunch_identity(self.ROW),
                                 expect_resume="same-id", resume="same-id", row=stale)
        self.assertIsNone(err)
        self.assertEqual(calls["respawn"], 1)
        self.assertEqual(calls["row"]["expected_clear_nonce"], "our-nonce")
        self.assertNotIn("clear_nonce", calls["row"],
                         "a previous clear's witness must not survive this stamp")

    def test_the_registry_lock_is_actually_HELD_across_the_effect(self):
        # COUNTING CALLS PROVES NOTHING ABOUT A LOCK. The earlier arm incremented
        # a counter inside the context and called that evidence; it would have
        # passed just as well with no lock at all. This one attempts a real
        # non-blocking flock from a second descriptor at the moment the caller's
        # effect runs — it must FAIL — and again after the context exits, where
        # it must SUCCEED, which is what "released before await" means.
        import fcntl as _f
        with tempfile.TemporaryDirectory() as root:
            reg = pathlib.Path(root) / ".tap" / "bus" / "registry.json"
            reg.parent.mkdir(parents=True)
            reg.write_text(json.dumps({"schema": "0.20", "team": {"name": "tap"},
                                       "agents": {"luna": dict(self.ROW)}}))
            lock_path = pathlib.Path(str(launcher.writable_tap_registry_path(root)) + ".lock")

            def other_holder_can_acquire():
                with lock_path.open("w") as probe:
                    try:
                        _f.flock(probe, _f.LOCK_EX | _f.LOCK_NB)
                        _f.flock(probe, _f.LOCK_UN)
                        return True
                    except OSError:
                        return False

            with mock.patch.object(launcher, "resolved_resume_identity", return_value="same-id"):
                with launcher.authorized_clear_stamp(
                    root, "luna", "our-nonce", tag="tap/luna",
                    expect=launcher.relaunch_identity(self.ROW), expect_resume="same-id",
                ):
                    held_during = not other_holder_can_acquire()
                free_after = other_holder_can_acquire()

        self.assertTrue(held_during,
                        "the registry lock must be HELD while the caller's respawn runs")
        self.assertTrue(free_after,
                        "and released on the way out, so the awaited registration can bind")

    def test_expect_none_does_NOT_hold_the_lock_across_the_effect(self):
        # tap clear's polarity: it stamps through the old path and must not
        # inherit a longer lock window. Same probe, opposite expectation.
        import fcntl as _f
        with tempfile.TemporaryDirectory() as root:
            reg = pathlib.Path(root) / ".tap" / "bus" / "registry.json"
            reg.parent.mkdir(parents=True)
            reg.write_text(json.dumps({"schema": "0.20", "team": {"name": "tap"},
                                       "agents": {"luna": dict(self.ROW)}}))
            lock_path = pathlib.Path(str(launcher.writable_tap_registry_path(root)) + ".lock")

            def free():
                with lock_path.open("w") as probe:
                    try:
                        _f.flock(probe, _f.LOCK_EX | _f.LOCK_NB)
                        _f.flock(probe, _f.LOCK_UN)
                        return True
                    except OSError:
                        return False

            with launcher.authorized_clear_stamp(root, "luna", "our-nonce", tag="tap/luna"):
                during = free()

        self.assertTrue(during,
                        "tap clear must not hold the registry lock across its respawn")

    def test_expect_none_keeps_tap_clears_behaviour_exactly(self):
        # `tap clear` has no enumeration to drift from. It must stamp through the
        # old path and yield with no registry lock held across the effect.
        calls, err = self._authz(expect=None)
        self.assertIsNone(err)
        self.assertEqual(calls["respawn"], 1)
        self.assertEqual(calls["row"]["expected_clear_nonce"], "our-nonce")

    def test_relaunch_one_hands_BOTH_expectations_to_the_boundary(self):
        # THE WIRING, WHICH THE CONTEXT-MANAGER ARMS CANNOT SEE. Those arms call
        # `authorized_clear_stamp` directly, so they stay green even if
        # `relaunch_one` never passes it anything — measured: deleting either
        # argument at the call site survived every other control. What makes the
        # boundary real is that the caller feeds it the enumerated identity AND
        # the same effective id that reaches argv.
        seen = {}

        @contextlib.contextmanager
        def spy(root, handle, nonce, *, tag, expect=None, expect_resume=None, permissions=None, recipe=None):
            seen["expect"] = expect
            seen["expect_resume"] = expect_resume
            yield

        expect = launcher.relaunch_identity(self.ROW)
        with mock.patch.object(launcher, "authorized_clear_stamp", spy):
            self._run(expect=expect,
                      expect_resume=self.ROW["harness_session_id"], dry_run=False)

        self.assertEqual(seen["expect"], expect,
                         "the enumerated identity must reach the final boundary")
        self.assertEqual(seen["expect_resume"], self.ROW["harness_session_id"],
                         "the boundary must receive the id ENUMERATION resolved, "
                         "not one this turn resolved for itself")

    def test_a_transcript_appearing_AFTER_enumeration_cannot_retarget_the_turn(self):
        # SOL'S CAUSAL CONTROL, and the one my first wiring arm masked: its
        # fixture made the raw and effective ids equal, so it could not tell an
        # enumeration-bound expectation from a turn-resolved one.
        #
        # Here enumeration resolved `ghost-id`. Between the census and this
        # serialized member's turn — minutes, on a real fleet — a claude
        # transcript for `new-id` appears on disk, so the TURN's own resolve
        # returns `new-id` while the row's raw fields never moved. The turn must
        # refuse rather than adopt the conversation and then confirm its own
        # adoption.
        seen = {"stamp": 0}

        @contextlib.contextmanager
        def spy(root, handle, nonce, *, tag, expect=None, expect_resume=None, permissions=None, recipe=None):
            seen["stamp"] += 1
            # The real boundary compares a fresh resolve against this value.
            if expect_resume != "new-id":
                raise launcher.LauncherError(
                    f"seat '{tag}' now resolves to a different conversation than the one "
                    f"enumerated ({expect_resume!r} -> 'new-id')"
                )
            yield

        # The refusal is a LauncherError; the batch turns it into a per-seat
        # refusal and exit 6 (pinned separately). At this level the contract is
        # the raise, and the seat is never respawned.
        with mock.patch.object(launcher, "authorized_clear_stamp", spy), \
             mock.patch.object(launcher, "resolved_resume_identity", return_value="new-id"), \
             self.assertRaises(launcher.LauncherError) as caught:
            self._run(expect=launcher.relaunch_identity(self.ROW),
                      expect_resume="ghost-id", dry_run=False)

        # The refusal now lands BEFORE argv is built, so the boundary is never
        # reached — which is stronger than refusing at it: no invocation was ever
        # rendered from the intermediate id.
        self.assertEqual(seen["stamp"], 0,
                         "a retargeted conversation must be refused before argv exists")
        self.assertIn("different conversation", str(caught.exception))
        self.assertIn("ghost-id", str(caught.exception),
                      "the refusal names the conversation enumeration authorized")

    def test_a_FLIP_BACK_between_the_turn_and_the_boundary_cannot_ship_the_wrong_argv(self):
        # THE TIMELINE NEITHER EARLIER ARM REACHES. Drift that PERSISTS is caught
        # at the locked boundary. A flip-back is not:
        #
        #   1. enumeration authorizes `ghost-id`
        #   2. before the turn, disk resolves `new-id` -> argv built as --resume new-id
        #   3. before the locked read, disk returns to `ghost-id`
        #   4. the boundary compares fresh `ghost-id` to enumerated `ghost-id`,
        #      approves, and respawns the invocation already carrying `new-id`
        #
        # Two agreeing resolves at different instants are not the same fact. The
        # refusal therefore has to happen where argv is built, not only where the
        # nonce is stamped.
        resolves = iter(["new-id", "ghost-id", "ghost-id"])
        rendered = []

        @contextlib.contextmanager
        def spy(root, handle, nonce, *, tag, expect=None, expect_resume=None, permissions=None, recipe=None):
            yield

        with mock.patch.object(launcher, "authorized_clear_stamp", spy), \
             mock.patch.object(launcher, "resolved_resume_identity",
                               side_effect=lambda *a, **k: next(resolves)), \
             mock.patch.object(launcher, "launch_invocation",
                               side_effect=lambda *a, **k: rendered.append(k.get("resume_identity"))), \
             self.assertRaises(launcher.LauncherError) as caught:
            self._run(expect=launcher.relaunch_identity(self.ROW),
                      expect_resume="ghost-id", dry_run=False)

        self.assertEqual(rendered, [],
                         "no invocation may be built from the intermediate conversation")
        self.assertIn("new-id", str(caught.exception),
                      "the refusal names the conversation it declined to resume")

    def test_a_batch_builds_argv_from_the_ENUMERATED_id_not_the_turns(self):
        # The positive half: when the turn agrees, the value passed to
        # launch_invocation is the enumerated one — the same object that
        # authorized the run, so argv and the authorization cannot diverge even
        # if the two resolves happen to be equal by coincidence today.
        rendered = []

        @contextlib.contextmanager
        def spy(root, handle, nonce, *, tag, expect=None, expect_resume=None, permissions=None, recipe=None):
            yield

        # TWO EQUAL-BUT-DISTINCT OBJECTS, so `is` can tell which one was used.
        # An earlier version compared equal strings, which cannot distinguish
        # "argv was rebound to the enumerated value" from "argv kept the turn's
        # value that happened to match" — measured: deleting the rebinding
        # survived it.
        enumerated = "".join(["01a04591-310e-7fa3-86ae-", "368bfd51a104"])
        turn_value = self.ROW["harness_session_id"]
        self.assertEqual(enumerated, turn_value)
        self.assertIsNot(enumerated, turn_value)
        sentinel = enumerated
        with mock.patch.object(launcher, "authorized_clear_stamp", spy), \
             mock.patch.object(launcher, "resolved_resume_identity", return_value=turn_value), \
             mock.patch.object(launcher, "launch_invocation",
                               side_effect=lambda *a, **k: rendered.append(k.get("resume_identity")) or launcher.Invocation(argv=("x",), env={})):
            self._run(expect=launcher.relaunch_identity(self.ROW),
                      expect_resume=sentinel, dry_run=False)
        self.assertEqual(len(rendered), 1)
        self.assertIs(rendered[0], enumerated,
                      "argv must be built from the ENUMERATED object, not the turn's "
                      "resolve that merely compares equal to it")

    def test_a_DRY_RUN_cannot_print_an_unauthorized_conversation(self):
        # GROK'S PATH, and the one this lane has used as the P1 observable every
        # round: rendering. `--dry-run` returns BEFORE `authorized_clear_stamp`,
        # so a boundary-only fix leaves the dry run printing
        # `claude ... --resume new-id` at exit 0 for a conversation the census
        # never authorized. The earlier arms could not see it: the wiring arm
        # spies the stamp and never looks at argv, and the causal arm forces
        # dry_run=False.
        # ASSERTS ON WHAT `_run` ACTUALLY CAPTURED. An earlier version appended
        # stdout on the line after the raising call — unreachable, so the buffer
        # was always empty; a second version wrapped the call in an outer
        # `redirect_stdout`, which `_run`'s own redirect makes blind. Both held
        # regardless of what was printed. The helper now attaches its captured
        # output to the exception, so a print-then-raise mutant reds.
        with mock.patch.object(launcher, "resolved_resume_identity", return_value="new-id"), \
             self.assertRaises(launcher.LauncherError) as caught:
            self._run(expect=launcher.relaunch_identity(self.ROW),
                      expect_resume="ghost-id", dry_run=True)

        emitted = getattr(caught.exception, "captured_stdout", "")
        self.assertNotIn("--resume", emitted,
                         "no invocation may be printed for an unauthorized id")
        self.assertNotIn("new-id", emitted)
        self.assertIn("new-id", str(caught.exception))
        self.assertIn("ghost-id", str(caught.exception))

    def test_a_dry_run_on_an_authorized_seat_still_prints(self):
        # The polarity: the refusal must not silence legitimate dry runs.
        sentinel = self.ROW["harness_session_id"]
        with mock.patch.object(launcher, "resolved_resume_identity", return_value=sentinel):
            rc, out, err, _ = self._run(
                expect=launcher.relaunch_identity(self.ROW),
                expect_resume=sentinel, dry_run=True)
        self.assertEqual(rc, 0)
        # The fixture is a codex seat, whose resume is `resume <id>` rather than
        # claude's `--resume <id>`. Assert the ID, which is the thing that must
        # survive — asserting a harness-specific flag would make this arm fail
        # on a seat family it has no opinion about.
        self.assertIn(sentinel, out)

    def test_the_single_seat_form_hands_the_boundary_no_expectation(self):
        # The polarity: `tap session relaunch <team/handle>` and `tap clear` have
        # no enumeration, so the boundary must stay inert for them.
        seen = {}

        @contextlib.contextmanager
        def spy(root, handle, nonce, *, tag, expect=None, expect_resume=None, permissions=None, recipe=None):
            seen["expect"] = expect
            seen["expect_resume"] = expect_resume
            yield

        with mock.patch.object(launcher, "authorized_clear_stamp", spy):
            self._run(dry_run=False)
        self.assertIsNone(seen["expect"])
        self.assertIs(seen["expect_resume"], launcher._UNSET_RESUME_EXPECTATION)

    def test_a_bare_handle_is_refused_rather_than_resolved_against_the_caller(self):
        # The seat this verb exists for lives in ANOTHER team's worktree. Silently
        # resolving a bare handle against the caller's team is how a fleet verb
        # relaunches the wrong seat.
        with self.assertRaises(launcher.LauncherError) as ctx:
            launcher.relaunch_target("luna-cleanup-researcher")
        self.assertIn("team/handle", str(ctx.exception))

    def test_an_unknown_or_historical_team_is_refused_by_name(self):
        for status, needle in (("missing", "not enrolled"), ("historical", "historical"),
                               ("unreachable", "registry is missing")):
            with mock.patch.object(launcher.registry_v20, "resolve_team_from_global",
                                   return_value=(status, "/r", "/r/.tap/team-registry.json")):
                with self.assertRaises(launcher.LauncherError) as ctx:
                    launcher.relaunch_target("ghost/seat")
                self.assertIn(needle, str(ctx.exception))

    def test_it_fences_the_target_teams_bus_not_the_callers(self):
        # A cross-team verb that fenced its own bus would mutate one team's
        # registry under another team's guarantee, and the target's courier and
        # reset would never observe the fence meant to stop them.
        rc, out, err, fenced = self._run()
        self.assertEqual(rc, 0)
        self.assertEqual(fenced.call_count, 1)
        passed_bus = fenced.call_args.kwargs.get("bus")
        self.assertIsNotNone(passed_bus, "relaunch must pass an explicit bus")
        self.assertNotEqual(
            str(passed_bus), str(launcher._team_bus_home() or ""),
            "the fence must be taken against the TARGET registry's bus",
        )

    def test_it_refuses_a_seat_with_no_exact_resume_identity_before_dry_run_prints(self):
        # Relaunch promises the same conversation. Without a verified id the
        # harness returns at its picker or in a NEW conversation — tap clear
        # wearing this verb's name, on a working seat. --dry-run must report the
        # refusal, not an invocation nobody would run.
        rc, out, err, _ = self._run(record=self._record(native_id=None), dry_run=True)
        self.assertEqual(rc, 2)
        self.assertIn("no resumable conversation id", err)
        self.assertNotIn("codex --", out, "no invocation may be printed past the gate")

    def test_opencode_relaunch_uses_the_ordinary_exact_identity_gate(self):
        record = self._record(harness="opencode", native_id="ses_previous")
        row = dict(
            self.ROW,
            harness="opencode",
            harness_session_id="ses_previous",
        )
        rc, out, err, _ = self._run(
            record=record,
            registry_row=row,
            acting_row=row,
            dry_run=True,
        )
        self.assertEqual(rc, 0, out + err)
        self.assertIn("opencode --session ses_previous", out)

    def test_idless_opencode_relaunch_uses_the_generic_exact_identity_refusal(self):
        record = self._record(harness="opencode", native_id=None)
        row = dict(self.ROW, harness="opencode", harness_session_id=None)
        rc, out, err, _ = self._run(
            record=record,
            registry_row=row,
            acting_row=row,
            dry_run=True,
            env={"TAP_JSON": "1"},
        )
        self.assertEqual(rc, 2)
        self.assertIn("no_exact_resume_identity", out + err)
        self.assertNotIn("opencode_relaunch_unavailable", out + err)

    def test_the_refusal_carries_its_machine_readable_class(self):
        # CONTRACT names error_class=no_exact_resume_identity, and error_class is
        # emitted only under TAP_JSON=1 — so the human arm above cannot prove it.
        # The cap watcher reads this class to decide skip-and-log vs stop.
        rc, out, err, _ = self._run(
            record=self._record(native_id=None), env={"TAP_JSON": "1"}
        )
        self.assertEqual(rc, 2)
        self.assertIn("no_exact_resume_identity", out + err)

    def test_the_refusal_names_a_cross_team_recovery_not_a_bare_tap_clear(self):
        # tap clear is caller-team-scoped, so a bare `tap clear <handle>` copied
        # out of a machine-scoped refusal acts on whatever same-named seat lives
        # in the team the operator happens to be standing in.
        rc, out, err, _ = self._run(record=self._record(native_id=None))
        text = err + out
        # ASSERTS THE PROPERTY, NOT A FIXTURE LITERAL. This used to look for the
        # string "/target/root", which the fixture supplied as a root that did
        # not match its own registry — a pairing no machine produces, and one
        # that only ever worked because the bus was derived from the registry
        # path rather than the root. The property is what matters: the recovery
        # cd's somewhere absolute FIRST, so a machine-scoped refusal cannot be
        # copy-pasted into whatever team the operator is standing in.
        self.assertRegex(
            text, r"cd /\S+ && tap clear ",
            "the recovery must cd to the TARGET root before naming tap clear",
        )
        self.assertNotRegex(
            text, r"next: tap clear ",
            "a bare, caller-scoped tap clear is the wrong recovery here",
        )

    def test_it_resumes_the_stored_id_and_carries_m_as_the_resume_prompt(self):
        # This is what deletes the separate wake verb: the continuation text is
        # submitted BY the resume, so no keystroke is simulated into the pane.
        rc, out, err, _ = self._run(message="Continue: the account was switched.")
        self.assertEqual(rc, 0)
        self.assertIn("resume", out)
        self.assertIn("01a04591-310e-7fa3-86ae-368bfd51a104", out)
        self.assertIn("Continue: the account was switched.", out)

    def test_it_does_not_clear_the_scrollback(self):
        # The conversation survives, so the operator's local record of it must
        # too. clear-history here would destroy the only local evidence of what
        # the seat was doing when it was replaced.
        calls = []
        rc, out, err, _ = self._run(dry_run=False, calls=calls)
        self.assertEqual(rc, 0)
        joined = [" ".join(c) for c in calls]
        self.assertTrue(any("respawn-pane" in c for c in joined), joined)
        self.assertFalse(any("clear-history" in c for c in joined),
                         "relaunch must not discard the pane's scrollback")

    def test_there_is_no_soft_exit_path(self):
        # A harness whose turn was just refused cannot be relied on to process
        # /exit, and a fallback after typing it is a retry after possible effect.
        calls = []
        self._run(dry_run=False, calls=calls)
        joined = " ".join(" ".join(c) for c in calls)
        self.assertNotIn("send-keys", joined, "relaunch must never type into the pane")


class SessionRelaunchRefusalTest(unittest.TestCase):
    """The refusals unit-1 review found missing (sol-tidying-sponsor, 042759Z).

    Each arm here corresponds to a defect that was LIVE at 598519ac, not to a
    hypothetical. The crew one in particular rendered a claude --resume of the
    driver's own conversation id against a codex crew pane.
    """

    def _driver_and_crew(self):
        driver = launcher.SessionRecord(
            name="tap/opus-builder", harness="claude", cwd="/seat/cwd", base="tap",
            tag="opus-builder", index=1, harness_session_id="drv-1111",
        )
        # The crew row's SESSION is the driver's; the crew has no record of its own.
        crew_entry = {"session": "tap/opus-builder", "crew": True, "delivery": "pane",
                      "status": "active", "pane_id": "%9", "pane": "tap/opus-builder:2.0"}
        return driver, crew_entry

    def _run(self, key, entry, records, dry_run=True, calls=None, env=None):
        args = types.SimpleNamespace(seat=key, message=None, dry_run=dry_run)

        def fake_run(cmd, **kwargs):
            if calls is not None:
                calls.append(list(cmd))
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

        out, err = io.StringIO(), io.StringIO()
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher.registry_v20, "resolve_team_from_global",
                                   return_value=("ok", bus, f"{bus}/team-registry.json")), \
                 mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "registry_entry", return_value=entry), \
                 mock.patch.object(launcher, "clear_target_pane", return_value=("%9", entry)), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=records, dir_aliases={})), \
                 mock.patch.object(launcher, "stamp_expected_clear_nonce") as stamp, \
                 mock.patch.object(launcher, "consume_expected_clear_nonce"), \
                 mock.patch.object(launcher, "await_clear_rebind", return_value=True), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=None), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ, env or {}, clear=False), \
                 contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                rc = launcher.cmd_relaunch(args)
        return rc, out.getvalue(), err.getvalue(), stamp

    def test_a_crew_row_is_refused_and_never_renders_its_drivers_invocation(self):
        # THE unit-1 defect. A crew seat shares its driver's tmux session, so
        # resolving by session name returned the DRIVER's record — a different
        # harness and a different conversation. Live at 598519ac:
        # relaunch tap/sol-pinnacle-design (codex crew) rendered
        # `claude ... --name tap/opus-tidying-creator --resume <driver id>`.
        driver, crew_entry = self._driver_and_crew()
        rc, out, err, stamp = self._run("tap/sol-crew", crew_entry, [driver])
        self.assertEqual(rc, 2)
        self.assertNotIn("claude", out, "the driver's invocation must never render")
        self.assertNotIn("drv-1111", out + err, "the driver's conversation id must not leak")
        self.assertEqual(stamp.call_count, 0, "no registry write on a refusal")

    def test_a_row_whose_session_belongs_to_another_seat_is_refused(self):
        # The second, independent guard: even if the relaunchable predicate ever
        # admits such a row, the record must be the requested handle's own.
        driver, crew_entry = self._driver_and_crew()
        not_crew = dict(crew_entry)
        not_crew.pop("crew")
        rc, out, err, stamp = self._run("tap/sol-crew", not_crew, [driver])
        self.assertEqual(rc, 2)
        self.assertIn("belongs to", err)
        self.assertNotIn("claude", out)
        self.assertEqual(stamp.call_count, 0)

    def test_a_ghost_conversation_id_is_refused_rather_than_parked_at_a_picker(self):
        # revive_tier reads harness_session_id and says 'exact'. claude resolves
        # its own target and falls back to the picker when no transcript exists,
        # so the tier is a proxy the invocation can contradict. The gate reads the
        # BUILT argv instead.
        ghost = launcher.SessionRecord(
            name="tap/luna", harness="claude", cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id="ghost-does-not-exist",
        )
        entry = {"session": "tap/luna", "delivery": "pane", "status": "active",
                 "pane_id": "%9", "pane": "tap/luna:0.0"}
        self.assertEqual(
            launcher.revive_tier(ghost.harness, ghost.harness_session_id), "exact",
            "precondition: the listing proxy calls this exact",
        )
        with mock.patch.object(launcher, "resolve_resume_target",
                               return_value=launcher.ResumeTarget(session_id=None, source="picker")), \
             mock.patch.object(launcher, "claude_session_transcript_exists", return_value=False):
            rc, out, err, stamp = self._run("tap/luna", entry, [ghost])
        self.assertEqual(rc, 2)
        self.assertIn("no resumable conversation id", err)
        self.assertNotIn("--resume", out, "an id-less invocation must not print")
        self.assertEqual(stamp.call_count, 0)

    def test_a_ghost_id_echoed_by_the_prompt_still_refuses(self):
        # THE DISCRIMINATOR for the unsound first fix. That gate asked "is the
        # stored id somewhere in the built argv" — so `-m` text equal to the ghost
        # id made the membership test pass while claude had silently resolved to
        # its picker. Only a gate reading the resolver's own answer can tell these
        # apart, and this arm is what proves the argv form is gone.
        ghost = launcher.SessionRecord(
            name="tap/luna", harness="claude", cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id="ghost-does-not-exist",
        )
        entry = {"session": "tap/luna", "delivery": "pane", "status": "active",
                 "pane_id": "%9", "pane": "tap/luna:0.0"}
        args = types.SimpleNamespace(seat="tap/luna", message="ghost-does-not-exist",
                                     dry_run=True)
        out, err = io.StringIO(), io.StringIO()
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher.registry_v20, "resolve_team_from_global",
                                   return_value=("ok", bus, f"{bus}/team-registry.json")), \
                 mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "registry_entry", return_value=entry), \
                 mock.patch.object(launcher, "clear_target_pane", return_value=("%9", entry)), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[ghost], dir_aliases={})), \
                 mock.patch.object(launcher, "resolve_resume_target",
                                   return_value=launcher.ResumeTarget(session_id=None, source="picker")), \
                 mock.patch.object(launcher, "stamp_expected_clear_nonce") as stamp, \
                 contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                rc = launcher.cmd_relaunch(args)
        self.assertEqual(rc, 2, "the prompt echoing the ghost id must not satisfy the gate")
        self.assertEqual(stamp.call_count, 0)

    def test_the_resume_identity_is_resolved_once_and_bound_to_the_launch(self):
        # THE TWO-CALL DISCRIMINATOR (sol-tidying-sponsor, round 3 HOLD).
        # resolve_resume_target reads mutable on-disk transcript state, so a gate
        # and a builder that each call it are two decisions, not one: with the
        # disk changing between them the gate can see an identity while argv is
        # built id-less, and the seat is replaced by a picker invocation.
        #
        # side_effect=[picker, exact] is the shape that discriminates. Under the
        # unbound form the builder resolved first (picker -> id-less argv) and the
        # gate resolved second (exact -> pass), and the verb proceeded. Bound, the
        # gate resolves FIRST and its answer is handed to the builder, so this
        # must refuse — and the resolver must be consulted exactly once.
        ghost = launcher.SessionRecord(
            name="tap/luna", harness="claude", cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id="ghost-does-not-exist",
        )
        entry = {"session": "tap/luna", "delivery": "pane", "status": "active",
                 "pane_id": "%9", "pane": "tap/luna:0.0"}
        args = types.SimpleNamespace(seat="tap/luna", message=None, dry_run=True)
        resolver = mock.Mock(side_effect=[
            launcher.ResumeTarget(session_id=None, source="picker"),
            launcher.ResumeTarget(session_id="ghost-does-not-exist", source="stored"),
        ])
        out, err = io.StringIO(), io.StringIO()
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher.registry_v20, "resolve_team_from_global",
                                   return_value=("ok", bus, f"{bus}/team-registry.json")), \
                 mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "registry_entry", return_value=entry), \
                 mock.patch.object(launcher, "clear_target_pane", return_value=("%9", entry)), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[ghost], dir_aliases={})), \
                 mock.patch.object(launcher, "resolve_resume_target", resolver), \
                 mock.patch.object(launcher, "stamp_expected_clear_nonce") as stamp, \
                 contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                rc = launcher.cmd_relaunch(args)
        self.assertEqual(rc, 2, "the FIRST resolution decides; a later 'exact' must not rescue it")
        self.assertEqual(
            resolver.call_count, 1,
            "the identity must be resolved once and bound, not recomputed by the builder",
        )
        self.assertNotIn("--resume", out, "no id-less invocation may print")
        self.assertEqual(stamp.call_count, 0)

    def test_a_bound_identity_is_used_verbatim_and_not_re_resolved(self):
        # The positive half: when the caller has already decided, the builder must
        # consume that value rather than consult the resolver again.
        rec = launcher.SessionRecord(
            name="tap/luna", harness="claude", cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id="stored-id",
        )
        resolver = mock.Mock(side_effect=AssertionError("builder must not re-resolve"))
        with mock.patch.object(launcher, "resolve_resume_target", resolver):
            inv = launcher.build_harness_invocation("resume", rec, None, "bound-id")
        self.assertIn("bound-id", inv.argv)
        self.assertNotIn("stored-id", inv.argv)
        self.assertEqual(resolver.call_count, 0)

    def test_a_valid_target_not_equal_to_the_stored_id_is_accepted(self):
        # Completeness, the other half: claude may legitimately resume from
        # transcript_path or a quarantined id rather than record.harness_session_id.
        # The argv-membership form read that as "no identity" and would have
        # refused a healthy seat.
        rec = launcher.SessionRecord(
            name="tap/luna", harness="claude", cwd="/seat/cwd", base="tap",
            tag="luna", index=1, harness_session_id=None,
        )
        with mock.patch.object(launcher, "resolve_resume_target",
                               return_value=launcher.ResumeTarget(session_id="from-transcript",
                                                                  source="transcript_path")):
            self.assertEqual(launcher.resolved_resume_identity(rec), "from-transcript")

    def test_the_crew_refusal_does_not_recommend_tap_clear(self):
        # tap clear resolves its record by SESSION name, so on a crew handle it
        # renders the driver's invocation — verified live. Naming it as the
        # recovery would recreate, as sanctioned advice, the wrong-record class
        # this refusal exists to stop.
        driver, crew_entry = self._driver_and_crew()
        rc, out, err, stamp = self._run("tap/sol-crew", crew_entry, [driver])
        self.assertEqual(rc, 2)
        self.assertNotRegex(err, r"next:.*tap clear ",
                            "tap clear is not a safe recovery for a crew row")
        self.assertIn("tap/opus-builder", err, "name the driver's session the crew lives in")

    def test_capped_restart_suggestions_exclude_crew_handles(self):
        # session_seat_states has NO crew exclusion: it returns every active row
        # whose session matches, which for a driver session includes its crew. An
        # unfiltered suggestion would send an operator to `tap session relaunch
        # <crew>`, which refuses — a dead end at the moment they are already stuck.
        seats = {"driver": {"session": "tap/d", "delivery": "pane", "status": "active",
                            "pane_id": "%1", "pane": "tap/d:0.0"},
                 "crew": {"session": "tap/d", "crew": True, "delivery": "pane",
                          "status": "active", "pane_id": "%2", "pane": "tap/d:1.0"}}
        keep = [h for h in ("driver", "crew")
                if launcher.registry_v20.seat_is_relaunchable(seats.get(h))]
        self.assertEqual(keep, ["driver"], "the crew handle must not be suggested")

    def test_the_post_acquire_recheck_reads_the_target_bus_not_the_callers(self):
        # Source order proves only that SOME recheck happens. This pins WHICH bus
        # it reads: a fence published on the caller's bus must not be what a
        # cross-team relaunch inspects.
        seen = {}

        def fake_refuse(action, bus=None):
            seen.setdefault("busses", []).append(str(bus) if bus else None)

        held = mock.Mock()
        with mock.patch.object(launcher, "refuse_if_team_reset_fenced", side_effect=fake_refuse):
            launcher._clear_yield_if_reset_fenced(held, bus=pathlib.Path("/target/bus"),
                                                  action="tap session relaunch")
        self.assertEqual(seen["busses"], ["/target/bus"])

    def test_a_target_fence_appearing_after_acquire_releases_the_claim(self):
        held = mock.Mock()
        with mock.patch.object(launcher, "refuse_if_team_reset_fenced",
                               side_effect=launcher.LauncherError("mid-reset")):
            with self.assertRaises(launcher.LauncherError):
                launcher._clear_yield_if_reset_fenced(held, bus=pathlib.Path("/target/bus"))
        held.release.assert_called_once()

    def test_cross_team_refusals_name_the_target_root_not_a_bare_command(self):
        # A bare `tap session restart <handle>` copied out of a machine-scoped
        # refusal restarts a same-named seat in the CALLER's team. Half the fleet
        # is called `sol`.
        with mock.patch.object(launcher, "registry_entry", return_value=None):
            with self.assertRaises(launcher.LauncherError) as ctx:
                launcher.clear_target_pane(
                    "/target/root", "sol", "tap session relaunch",
                    restart_hint="cd /target/root && tap session restart sol",
                    roster_hint="cd /target/root && tap team",
                )
        self.assertIn("cd /target/root && tap team", str(ctx.exception))


class RelaunchTargetBusTest(unittest.TestCase):
    """The fence bus comes from the ROOT authority, not from the registry's path."""

    @staticmethod
    def _real(p):
        # macOS makes TMPDIR a symlink (/var -> /private/var) and the resolver
        # resolves it. Compare real paths so these arms red on the DEFECT rather
        # than on the symlink.
        return pathlib.Path(p).resolve()

    def _resolve(self, root, location):
        with mock.patch.object(launcher.registry_v20, "global_registry_path",
                               return_value="/dev/null"), \
             mock.patch.object(launcher.registry_v20, "resolve_team_from_global",
                               return_value=("ok", str(root), str(location))):
            return launcher.relaunch_target("Team/alpha")

    def test_a_relocated_registry_still_fences_the_root_derived_bus(self):
        # THE DIVERGENCE. `busForRegistry` special-cases exactly one
        # shape — a parent named `.tap` containing `bus/` — and otherwise returns
        # the registry's own parent. A relocated acting registry therefore fenced
        # `<root>/.tap/elsewhere`, while the courier and reset observe the root
        # authority's `<root>/.tap/bus`. The clearing fence, the reset-fence
        # check, and the recheck that closes the clear-vs-reset race all landed
        # somewhere nothing looks.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp) / "Team"
            (root / ".tap" / "bus").mkdir(parents=True)
            relocated = root / ".tap" / "elsewhere"
            relocated.mkdir()
            location = relocated / "registry.json"
            location.write_text("{}")

            _team, _handle, got_root, bus = self._resolve(root, location)
            self.assertEqual(self._real(got_root), self._real(root))
            self.assertEqual(
                self._real(bus), self._real(root / ".tap" / "bus"),
                "the fence must land on the bus the courier and reset actually observe")
            self.assertNotEqual(
                self._real(bus), self._real(relocated),
                "deriving the bus from the registry's parent is the defect")

    def test_a_legacy_bus_layout_is_honoured_by_the_same_authority(self):
        # The root authority prefers an existing `.tap/bus`, else an existing
        # legacy `tmp/tap`. Asserting the legacy case too, so the fix cannot be
        # satisfied by hard-coding `.tap/bus`.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp) / "Legacy"
            (root / "tmp" / "tap").mkdir(parents=True)
            (root / ".tap").mkdir(parents=True)
            location = root / ".tap" / "team-registry.json"
            location.write_text("{}")

            _t, _h, _r, bus = self._resolve(root, location)
            self.assertEqual(self._real(bus), self._real(root / "tmp" / "tap"))

    def test_the_ordinary_dotdir_layout_is_unchanged(self):
        # The polarity that keeps the fix from moving the common case.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp) / "Ordinary"
            (root / ".tap" / "bus").mkdir(parents=True)
            location = root / ".tap" / "team-registry.json"
            location.write_text("{}")

            _t, _h, _r, bus = self._resolve(root, location)
            self.assertEqual(self._real(bus), self._real(root / ".tap" / "bus"))


class SessionRelaunchBatchTest(unittest.TestCase):
    """`tap session relaunch --harness <h>` — the fleet form (ruling 36, unit 2b)."""

    def _members(self):
        # Four-tuples: enumeration now carries the EFFECTIVE resume target it
        # resolved alongside the row it classified, so the member's turn compares
        # against what this census saw rather than against a value the turn
        # resolved for itself.
        return [
            ("tap", "alpha", {"pane_id": "%1", "harness": "codex"}, "id-alpha"),
            ("tap", "bravo", {"pane_id": "%2", "harness": "codex"}, "id-bravo"),
            ("other", "charlie", {"pane_id": "%3", "harness": "codex"}, "id-charlie"),
        ]

    def _run(self, results, caller_pane="", team="*", dry_run=False, skipped=None,
             capture_expect=None):
        args = types.SimpleNamespace(seat=None, harness="codex", team=team,
                                     message=None, dry_run=dry_run)
        calls = []

        def fake_one(key, message, dry, expect=None, expect_resume=None):
            calls.append(key)
            if capture_expect is not None:
                capture_expect[key] = expect
            outcome = results.get(key, 0)
            if isinstance(outcome, Exception):
                raise outcome
            return outcome

        out = io.StringIO()
        with mock.patch.object(launcher, "relaunch_batch_members",
                               return_value=(self._members(), skipped or [], None)), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=caller_pane), \
             mock.patch.object(launcher, "seat_corpse") as corpse, \
             mock.patch.object(launcher, "current_server_epoch", return_value="srv:1:1"), \
             mock.patch.object(launcher, "relaunch_one", side_effect=fake_one), \
             contextlib.redirect_stdout(out):
            corpse.epoch_voided_ids.side_effect = lambda row, epoch: (row.get("pane_id"), None)
            rc = launcher.cmd_relaunch(args)
        return rc, out.getvalue(), calls

    def test_all_resumed_exits_zero(self):
        rc, out, calls = self._run({})
        self.assertEqual(rc, 0)
        self.assertCountEqual(calls, ["tap/alpha", "tap/bravo", "other/charlie"])

    def test_every_selected_seat_starts_before_any_one_is_allowed_to_finish(self):
        args = types.SimpleNamespace(
            seat=None, harness="codex", team=None, message=None, dry_run=False
        )
        started = set()
        lock = threading.Lock()
        all_started = threading.Event()
        release = threading.Event()
        result = {}

        def fake_one(key, *_args, **_kwargs):
            with lock:
                started.add(key)
                if len(started) == 3:
                    all_started.set()
            release.wait(2)
            return 0

        def run_batch():
            result["rc"] = launcher.cmd_relaunch(args)

        with mock.patch.object(
            launcher, "relaunch_batch_members", return_value=(self._members(), [], "ok")
        ), mock.patch.object(
            launcher.registry_v20, "enrolled_team_name_for_root", return_value=("ok", "tap")
        ), mock.patch.object(
            launcher, "resolve_caller_pane_id", return_value=""
        ), mock.patch.object(
            launcher, "seat_corpse"
        ) as corpse, mock.patch.object(
            launcher, "current_server_epoch", return_value="srv:1:1"
        ), mock.patch.object(
            launcher, "relaunch_one", side_effect=fake_one
        ), contextlib.redirect_stdout(io.StringIO()):
            corpse.epoch_voided_ids.side_effect = lambda row, epoch: (row.get("pane_id"), None)
            worker = threading.Thread(target=run_batch)
            worker.start()
            concurrent = all_started.wait(0.5)
            release.set()
            worker.join(3)

        self.assertFalse(worker.is_alive(), "the batch must finish after the seats are released")
        self.assertTrue(concurrent, f"selected seats started serially: {sorted(started)}")
        self.assertEqual(result.get("rc"), 0)

    def test_parallel_batch_uses_the_standard_bounded_executor(self):
        import inspect as _inspect

        src = _inspect.getsource(launcher.cmd_relaunch)
        self.assertIn("ThreadPoolExecutor()", src)
        self.assertNotIn(
            "max_workers=len(selected)", src,
            "a machine-wide cohort must not mint one polling thread per seat",
        )

    def test_a_per_seat_refusal_degrades_the_batch_without_aborting_it(self):
        # The operator is mid-outage; the seats after the refusal are the point.
        rc, out, calls = self._run({"tap/alpha": launcher.LauncherError("crew row")})
        self.assertEqual(rc, 6, "a per-seat refusal degrades (6), it does not fail (1)")
        self.assertCountEqual(calls, ["tap/alpha", "tap/bravo", "other/charlie"],
                              "the batch must continue past a refusal")
        self.assertIn("tap/alpha · refused", out)

    def test_exit_code_2_from_a_seat_is_a_refusal_not_a_hard_failure(self):
        rc, out, _ = self._run({"tap/bravo": 2})
        self.assertEqual(rc, 6)
        self.assertIn("tap/bravo · refused · nothing changed", out)

    def test_a_hard_failure_exits_one_and_says_to_look_at_the_pane(self):
        # 7 means the process is already replaced and the rebind is unconfirmed —
        # never the same class as "nothing changed".
        rc, out, _ = self._run({"other/charlie": 7})
        self.assertEqual(rc, 1)
        self.assertIn("FAILED · exit 7", out)
        self.assertIn("look at the pane", out)

    def test_the_batch_carries_each_row_identity_into_its_own_turn(self):
        # THE GAP THIS CLOSES. Enumeration classifies a ROW — its harness, its
        # pane, its conversation — and the loop used to keep only
        # `(team, handle)` and discard it, so `relaunch_one` re-resolved
        # everything from the key at effect time. A serialized batch over a
        # real fleet runs for minutes between the two.
        seen = {}
        rc, _out, calls = self._run({}, capture_expect=seen)
        self.assertEqual(rc, 0)
        self.assertCountEqual(calls, ["tap/alpha", "tap/bravo", "other/charlie"])
        self.assertEqual(
            seen["tap/alpha"],
            {"harness": "codex", "pane_id": "%1", "harness_session_id": None},
            "each turn must carry the identity enumeration classified, not just the key",
        )

    def test_a_member_that_re_registers_to_another_harness_is_not_respawned(self):
        # DRIVES THE REAL CALL SITE. An earlier version of this arm called
        # `refuse_on_identity_drift` from its own stub, which proved the guard
        # works and NOT that `relaunch_one` consults it — deleting the
        # production call left the arm green. It now runs the real
        # `relaunch_one` against a registry that has drifted underneath it, so
        # only the production guard can produce the refusal.
        rows = {
            "alpha": {"pane_id": "%1", "harness": "codex", "status": "active"},
            # bravo re-registers as claude between enumeration and its turn
            "bravo": {"pane_id": "%2", "harness": "claude", "status": "active"},
            "charlie": {"pane_id": "%3", "harness": "codex", "status": "active"},
        }
        args = types.SimpleNamespace(seat=None, harness="codex", team="*",
                                     message=None, dry_run=True)
        replaced, out = [], io.StringIO()

        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "relaunch_batch_members",
                                   return_value=(self._members(), [], None)), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
                 mock.patch.object(launcher, "seat_corpse") as corpse, \
                 mock.patch.object(launcher, "current_server_epoch", return_value="srv:1:1"), \
                 mock.patch.object(launcher.registry_v20, "global_registry_path",
                                   return_value="/dev/null"), \
                 mock.patch.object(launcher.registry_v20, "resolve_team_from_global",
                                   return_value=("ok", bus, f"{bus}/team-registry.json")), \
                 mock.patch.object(launcher, "registry_entry",
                                   side_effect=lambda root, handle: rows.get(handle)), \
                 mock.patch.object(launcher, "replace_harness_in_pane",
                                   side_effect=lambda *a, **k: replaced.append(k.get("tag") or a) or 0), \
                 mock.patch.object(launcher, "resolved_resume_identity",
                                   return_value=("exact", "sess-1")), \
                 mock.patch.object(launcher, "clear_target_pane",
                                   return_value=("%41", {"pane_id": "%41"})), \
                 contextlib.redirect_stdout(out):
                corpse.epoch_voided_ids.side_effect = lambda row, epoch: (row.get("pane_id"), None)
                rc = launcher.cmd_relaunch(args)

        text = out.getvalue()
        self.assertIn("tap/bravo \u00b7 refused", text,
                      "the seat that drifted to another harness must be refused")
        self.assertIn("harness", text, "the refusal must name what changed")
        self.assertEqual(rc, 6, "a drift refusal degrades the batch; nothing was replaced")

    def test_identity_drift_is_refused_even_when_the_harness_still_matches(self):
        # Harness alone is not identity: a seat that was replaced by a
        # different seat on the same harness has a different pane and a
        # different conversation, and relaunch promises the SAME conversation.
        with self.assertRaises(launcher.LauncherError) as caught:
            launcher.refuse_on_identity_drift(
                "tap/bravo",
                {"harness": "codex", "pane_id": "%2", "harness_session_id": "s-1"},
                {"harness": "codex", "pane_id": "%9", "harness_session_id": "s-2"})
        self.assertIn("since enumeration", str(caught.exception))

    def test_an_unchanged_row_is_not_refused(self):
        # The polarity that stops the guard from refusing every seat. Benign
        # churn in unrelated fields must not trip it.
        launcher.refuse_on_identity_drift(
            "tap/alpha",
            {"harness": "codex", "pane_id": "%1", "harness_session_id": "s-1"},
            {"harness": "codex", "pane_id": "%1", "harness_session_id": "s-1",
             "last_seen": "2026-08-28T13:00:00Z", "status": "active"})

    def test_no_expectation_never_refuses_so_the_single_seat_path_is_unchanged(self):
        # `tap session relaunch <team/handle>` has no enumeration step and
        # therefore no expectation; the guard must be inert for it.
        launcher.refuse_on_identity_drift("tap/alpha", None, {"harness": "claude"})

    def test_a_subprocess_failure_in_one_seat_does_not_strand_the_rest(self):
        # THE CAP SCENARIO, EXACTLY. `replace_harness_in_pane` runs `tmux
        # respawn-pane` with check=True (launcher.py:8190), so a pane that
        # disappears between the liveness check and the respawn raises
        # CalledProcessError. Catching only LauncherError/SystemExit let it
        # escape to main and abort the batch, so ONE lost pane stranded every
        # later seat — during an outage, with the credential already switched.
        boom = subprocess.CalledProcessError(1, ["tmux", "respawn-pane"])
        rc, out, calls = self._run({"tap/alpha": boom})
        self.assertCountEqual(calls, ["tap/alpha", "tap/bravo", "other/charlie"],
                              "a subprocess failure must not abort the other seats")
        self.assertEqual(rc, 1, "an unexpected subprocess failure is HARD (1), not a refusal (6)")
        self.assertIn("tap/alpha · FAILED", out)
        self.assertIn("look at the pane", out,
                      "the respawn may already have taken effect; say so rather than implying nothing changed")

    def test_an_unexpected_error_in_one_seat_does_not_strand_the_rest(self):
        # The same property one class wider. Any exception the transaction can
        # raise — not just the one shape we happen to have seen — must degrade
        # its own seat rather than the run. Anything else means the batch's
        # completeness depends on which bug fires.
        rc, out, calls = self._run({"tap/bravo": RuntimeError("unexpected")})
        self.assertCountEqual(calls, ["tap/alpha", "tap/bravo", "other/charlie"])
        self.assertEqual(rc, 1)
        self.assertIn("tap/bravo · FAILED", out)

    def test_the_callers_own_seat_is_excluded_by_construction_and_says_so(self):
        # THE SAFETY PROPERTY. A verb that replaces the process it runs in cannot
        # survive to finish the run, and the seats after it pay. Exclusion is a
        # property of the SELECTION, not of the per-seat guard.
        rc, out, calls = self._run({}, caller_pane="%2")
        self.assertEqual(rc, 0)
        self.assertNotIn("tap/bravo", calls, "the caller's own seat must never be relaunched")
        self.assertIn("tap/bravo · excluded · caller-pane", out,
                      "the exclusion must be visible, not silent")
        self.assertEqual(calls, ["tap/alpha", "other/charlie"])

    def test_no_caller_pane_excludes_nothing_which_is_correct_for_cron(self):
        # A watcher invocation is not a seat: it has no conversation to lose and
        # no turn to end, so nothing is excluded and that is the point.
        rc, out, calls = self._run({}, caller_pane="")
        self.assertEqual(len(calls), 3)
        self.assertNotIn("excluded", out)

    def test_an_explicitly_empty_team_refuses_instead_of_widening_to_the_fleet(self):
        # THE WIDENING. argparse preserves `--team ""` as an explicit empty
        # string, and every scope check in this path was `if team_filter:`, so
        # the empty string read as "no --team at all". Probed on the live
        # machine before the fix: `--harness codex --team "" --dry-run` returned
        # 6 and enumerated 59 rows across every enrolled team — a request the
        # operator scoped to one team silently became a machine-wide respawn.
        #
        # Asserts the ENUMERATOR IS NEVER REACHED, not merely that the exit code
        # is 2: a refusal that still walked the machine would satisfy a
        # code-only assertion while doing the thing the arm forbids.
        args = types.SimpleNamespace(seat=None, harness="codex", team="",
                                     message=None, dry_run=True)
        reached = []

        def fake_members(harness, team_filter):
            reached.append(team_filter)
            return ([("tap", "alpha", {"pane_id": "%1", "harness": "codex"}, "id-a")], [], "ok")

        err = io.StringIO()
        with mock.patch.object(launcher, "relaunch_batch_members", side_effect=fake_members), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             mock.patch.object(launcher, "relaunch_one", return_value=0), \
             contextlib.redirect_stderr(err):
            rc = launcher.cmd_relaunch(args)
        self.assertEqual(rc, 2, "an explicitly empty --team is a refusal, not an unscoped run")
        self.assertEqual(reached, [], "the fleet must not be enumerated for a scope that cannot be resolved")
        self.assertIn("--team", err.getvalue())

    def test_a_whitespace_only_team_is_refused_on_the_same_ground(self):
        # `--team " "` names no team either, and would reach the enumerator as a
        # filter that matches nothing — an empty selection reported as a run.
        args = types.SimpleNamespace(seat=None, harness="codex", team="   ",
                                     message=None, dry_run=True)
        reached = []
        err = io.StringIO()
        with mock.patch.object(launcher, "relaunch_batch_members",
                               side_effect=lambda h, t: (reached.append(t), ([], [], "ok"))[1]), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             contextlib.redirect_stderr(err):
            rc = launcher.cmd_relaunch(args)
        self.assertEqual(rc, 2)
        self.assertEqual(reached, [])

    def test_an_omitted_team_defaults_to_the_current_team(self):
        seen = {}
        with mock.patch.object(launcher, "relaunch_batch_members",
                               side_effect=lambda h, t: (seen.update(team=t),
                                   ([("tap", "alpha", {"pane_id": "%1", "harness": "codex"}, "id-a")], [], "ok"))[1]), \
             mock.patch.object(launcher.registry_v20, "enrolled_team_name_for_root",
                               return_value=("ok", "tap")), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             mock.patch.object(launcher, "seat_corpse") as corpse, \
             mock.patch.object(launcher, "current_server_epoch", return_value="srv:1:1"), \
             mock.patch.object(launcher, "relaunch_one", return_value=0), \
             contextlib.redirect_stdout(io.StringIO()):
            corpse.epoch_voided_ids.side_effect = lambda row, epoch: (row.get("pane_id"), None)
            rc = launcher.cmd_relaunch(types.SimpleNamespace(
                seat=None, harness="codex", team=None, message=None, dry_run=False))
        self.assertEqual(rc, 0)
        self.assertEqual(seen["team"], "tap")

    def test_team_star_explicitly_widens_to_the_machine_fleet(self):
        seen = {}
        with mock.patch.object(launcher, "relaunch_batch_members",
                               side_effect=lambda h, t: (seen.update(team=t),
                                   ([("tap", "alpha", {"pane_id": "%1", "harness": "codex"}, "id-a")], [], None))[1]), \
             mock.patch.object(launcher.registry_v20, "enrolled_team_name_for_root",
                               return_value=("ok", "tap")), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             mock.patch.object(launcher, "seat_corpse") as corpse, \
             mock.patch.object(launcher, "current_server_epoch", return_value="srv:1:1"), \
             mock.patch.object(launcher, "relaunch_one", return_value=0), \
             contextlib.redirect_stdout(io.StringIO()):
            corpse.epoch_voided_ids.side_effect = lambda row, epoch: (row.get("pane_id"), None)
            rc = launcher.cmd_relaunch(types.SimpleNamespace(
                seat=None, harness="codex", team="*", message=None, dry_run=False))
        self.assertEqual(rc, 0)
        self.assertIsNone(seen["team"], "--team=* must be the explicit machine-wide form")

    def test_foreign_and_star_opencode_batch_instructions_reach_their_seats(self):
        # tap-74h2l: the cross-team refusal was a temporary public door. The
        # courier now addresses `<team>/<handle>`, so a foreign named-team and
        # the machine-wide form must proceed through enumeration and reach the
        # selected seats with the instruction intact.
        seen = []
        err = io.StringIO()
        members = [("other", "kimi", {"pane_id": "%3", "harness": "opencode"}, "id-kimi")]
        with mock.patch.object(launcher.registry_v20, "enrolled_team_name_for_root",
                               return_value=("ok", "tap")), \
             mock.patch.object(launcher, "relaunch_batch_members",
                               return_value=(members, [], "ok")), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             mock.patch.object(launcher, "seat_corpse") as corpse, \
             mock.patch.object(launcher, "current_server_epoch", return_value="srv:1:1"), \
             mock.patch.object(launcher, "relaunch_one",
                               side_effect=lambda key, message, dry, **_kwargs:
                                   seen.append((key, message)) or 0), \
             contextlib.redirect_stdout(io.StringIO()), \
             contextlib.redirect_stderr(err):
            corpse.epoch_voided_ids.side_effect = lambda row, epoch: (row.get("pane_id"), None)
            for team in ("other", "*"):
                rc = launcher.cmd_relaunch(types.SimpleNamespace(
                    seat=None, harness="opencode", team=team, message="hello", dry_run=False))
                self.assertEqual(rc, 0, err.getvalue())
        self.assertEqual(seen, [("other/kimi", "hello"), ("other/kimi", "hello")])

    def test_opencode_batch_instruction_stays_allowed_for_the_callers_team(self):
        calls = []
        with mock.patch.object(launcher.registry_v20, "enrolled_team_name_for_root",
                               return_value=("ok", "tap")), \
             mock.patch.object(launcher, "relaunch_batch_members",
                               return_value=([("tap", "alpha", {"pane_id": "%1", "harness": "opencode"}, "id-a")], [], "ok")), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             mock.patch.object(launcher, "seat_corpse") as corpse, \
             mock.patch.object(launcher, "current_server_epoch", return_value="srv:1:1"), \
             mock.patch.object(launcher, "relaunch_one",
                               side_effect=lambda key, message, dry, **_kwargs: calls.append((key, message)) or 0), \
             contextlib.redirect_stdout(io.StringIO()):
            corpse.epoch_voided_ids.side_effect = lambda row, epoch: (row.get("pane_id"), None)
            rc = launcher.cmd_relaunch(types.SimpleNamespace(
                seat=None, harness="opencode", team="tap", message="hello", dry_run=False))
        self.assertEqual(rc, 0)
        self.assertEqual(calls, [("tap/alpha", "hello")])

    def test_enumeration_resolves_the_effective_target_with_the_row_it_classifies(self):
        # THE ENUMERATOR'S OWN RESOLVE, which every other batch arm stubs away by
        # handing `relaunch_batch_members` a ready-made tuple — so deleting the
        # resolve survived them all. This drives the real enumerator against a
        # real global registry and a real team registry, and asserts the member
        # carries the conversation THIS census saw.
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp) / "Team"
            (root / ".tap" / "bus").mkdir(parents=True)
            team_reg = root / ".tap" / "bus" / "registry.json"
            team_reg.write_text(json.dumps({
                "schema": "0.20", "team": {"name": "Team"},
                "agents": {"alpha": {"session": "Team/alpha", "delivery": "pane",
                                     "status": "active", "pane_id": "%1",
                                     "pane": "Team/alpha:0.0", "harness": "codex",
                                     "harness_session_id": "census-id"}},
            }))
            global_reg = pathlib.Path(tmp) / "global-registry.json"
            global_reg.write_text(json.dumps({
                "schema": "0.20",
                "teams": {"Team": {"root": str(root), "registry_location": str(team_reg),
                                   "state": "registered"}},
            }))
            with mock.patch.object(launcher.registry_v20, "global_registry_path",
                                   return_value=str(global_reg)):
                members, _skipped, _status = launcher.relaunch_batch_members("codex", None)

        self.assertEqual(len(members), 1)
        _team, handle, _row, resume = members[0]
        self.assertEqual(handle, "alpha")
        self.assertEqual(resume, "census-id",
                         "enumeration must carry the effective target it resolved, "
                         "not None and not a value the turn resolves later")

    def test_team_reaches_the_enumerator_as_the_filter(self):
        # The previous version of this arm asserted only rc == 0 and never
        # recorded the enumerator's argument, so it would have passed with --team
        # ignored entirely. Assert the value actually arrives.
        seen = {}

        def fake_members(harness, team_filter):
            seen["harness"] = harness
            seen["team"] = team_filter
            return ([("tap", "alpha", {"pane_id": "%1", "harness": "codex"}, "id-a")], [], "ok")

        with mock.patch.object(launcher, "relaunch_batch_members", side_effect=fake_members), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             mock.patch.object(launcher, "seat_corpse") as corpse, \
             mock.patch.object(launcher, "current_server_epoch", return_value="srv:1:1"), \
             mock.patch.object(launcher, "relaunch_one", return_value=0), \
             contextlib.redirect_stdout(io.StringIO()):
            corpse.epoch_voided_ids.side_effect = lambda row, epoch: (row.get("pane_id"), None)
            rc = launcher.cmd_relaunch(types.SimpleNamespace(
                seat=None, harness="codex", team="tap", message=None, dry_run=False))
        self.assertEqual(rc, 0)
        self.assertEqual(seen, {"harness": "codex", "team": "tap"})

    def _enumerate(self, globaldoc, files=None):
        files = files or {}

        def fake_load(path):
            if "global" in str(path) or str(path).endswith("g.json"):
                return globaldoc
            return files.get(str(path), {})

        err = io.StringIO()
        with mock.patch.object(launcher.registry_v20, "global_registry_path", return_value="/g.json"), \
             mock.patch.object(launcher.registry_v20, "load_state_doc", side_effect=fake_load), \
             contextlib.redirect_stderr(err):
            members, skipped, _status = launcher.relaunch_batch_members("codex", None)
        return members, skipped, err.getvalue()

    def test_every_unreadable_enrolled_team_is_RECORDED_not_silently_continued(self):
        # Four shapes that all used to leave the fleet through a bare `continue`,
        # so the aggregate said 0 for scope nobody examined. A printed skip is not
        # enough — it has to be RETURNED.
        good = {"schema": launcher.registry_v20.SCHEMA, "seats": {"alpha": {"harness": "codex", "delivery": "pane", "status": "active",
                                    "pane_id": "%1", "pane": "t/alpha:0.0", "session": "t/alpha"}}}
        globaldoc = {"schema": launcher.registry_v20.SCHEMA, "teams": {
            "no_location":  {"state": "registered"},
            "empty_loc":    {"state": "registered", "registry_location": ""},
            "missing_file": {"state": "registered", "registry_location": "/gone.json"},
            "not_an_object": "nonsense",
            "healthy":      {"state": "registered", "registry_location": "/healthy.json"},
            "historical":   {"state": "historical", "registry_location": "/old.json"},
        }}
        members, skipped, err = self._enumerate(globaldoc, {"/healthy.json": good})
        names = sorted(t for t, _ in skipped)
        self.assertEqual(names, ["empty_loc", "missing_file", "no_location", "not_an_object"])
        self.assertEqual([(t, h) for t, h, _, _r in members], [("healthy", "alpha")])
        # historical is deliberately NOT a skip: it is not addressable, so its
        # absence is the answer rather than a gap.
        self.assertNotIn("historical", names)
        for n in names:
            self.assertIn(n, err)

    def test_a_missing_registry_file_is_not_read_as_an_empty_team(self):
        # load_state_doc returns {} for a missing file — measured. Without an
        # emptiness check the try/except treats a disappeared registry as a
        # readable team with no seats, which is the quietest erasure of the set.
        globaldoc = {"schema": launcher.registry_v20.SCHEMA,
                     "teams": {"gone": {"state": "registered", "registry_location": "/gone.json"}}}
        members, skipped, _ = self._enumerate(globaldoc, {})
        self.assertEqual(members, [])
        self.assertEqual([t for t, _ in skipped], ["gone"])

    def _members_for(self, doc):
        with mock.patch.object(launcher.registry_v20, "global_registry_path", return_value="/g.json"), \
             mock.patch.object(launcher.registry_v20, "load_state_doc", return_value=doc):
            members, skipped, _status = launcher.relaunch_batch_members("codex", None)
            return members, skipped

    def test_an_omitted_teams_key_is_VALID_EMPTY_not_a_refusal(self):
        # PRESENCE-SENSITIVE, per registry_v20.flip_marker_state and CONTRACT: an
        # omitted `teams` key is valid and means empty. An earlier version of this
        # file refused it, which contradicted the documented rule for a
        # legitimately empty machine — a regression I introduced while closing the
        # malformed-container hole, and exactly the over-correction that turns a
        # safety fix into a new failure.
        members, skipped = self._members_for({"schema": launcher.registry_v20.SCHEMA})
        self.assertEqual((members, skipped), ([], []))

    def test_a_present_non_dict_teams_map_is_a_typed_refusal(self):
        for bad in ([], None, "nonsense", 3):
            doc = {"schema": launcher.registry_v20.SCHEMA, "teams": bad}
            with self.assertRaises(launcher.LauncherError) as ctx:
                self._members_for(doc)
            self.assertIn("tap doctor", str(ctx.exception))

    def test_an_unsanctioned_global_schema_refuses_before_authorizing_a_cohort(self):
        # This document decides which teams exist and therefore which cohort gets
        # respawned. An unsanctioned schema reaching relaunch_one means an invalid
        # authority authorized the action.
        doc = {"schema": "0.19", "teams": {"a": {"state": "registered",
                                                 "registry_location": "/a.json"}}}
        with self.assertRaises(launcher.LauncherError) as ctx:
            self._members_for(doc)
        self.assertIn("schema", str(ctx.exception))
        self.assertIn("tap doctor", str(ctx.exception))

    def test_a_team_registry_with_no_seat_axis_is_a_skip_not_an_empty_team(self):
        # `_seat_map` maps a document with neither `seats` nor `agents` to {}, so a
        # structurally invalid registry read as "a team with no seats" and left the
        # fleet silently — the same erasure wearing a nonempty shape. seat_axis
        # distinguishes valid-empty (the key IS a dict) from missing entirely.
        S = launcher.registry_v20.SCHEMA
        globaldoc = {"schema": S, "teams": {"chosen": {"state": "registered",
                                                       "registry_location": "/c.json"}}}
        members, skipped, _ = self._enumerate(globaldoc, {"/c.json": {"schema": S, "team": {"name": "chosen"}}})
        self.assertEqual(members, [])
        self.assertEqual([t for t, _ in skipped], ["chosen"])
        # ...while a registry whose axis is present-but-empty is a real empty team.
        members2, skipped2, _ = self._enumerate(globaldoc, {"/c.json": {"schema": S, "seats": {}}})
        self.assertEqual((members2, skipped2), ([], []))

    def test_a_team_registry_without_a_schema_key_is_ACCEPTED(self):
        # MEASURED AGAINST THE WORLD, not assumed. SCHEMA is enforced on the
        # GLOBAL registry by flip_marker_state and nowhere else; 21 of 48 enrolled
        # team registries on this machine carry no `schema` key and are live.
        # A version of this file required one and turned all 21 into skips —
        # dropping real teams out of the fleet, which is the erasure the
        # validation exists to prevent, produced by the validation itself.
        S = launcher.registry_v20.SCHEMA
        row = {"harness": "codex", "delivery": "pane", "status": "active",
               "pane_id": "%1", "pane": "t/alpha:0.0", "session": "t/alpha"}
        globaldoc = {"schema": S, "teams": {"chosen": {"state": "registered",
                                                       "registry_location": "/c.json"}}}
        for team_doc in ({"seats": {"alpha": row}},                 # no schema key
                         {"schema": "0.19", "seats": {"alpha": row}},  # older schema
                         {"schema": S, "seats": {"alpha": row}}):      # current
            members, skipped, _ = self._enumerate(globaldoc, {"/c.json": team_doc})
            self.assertEqual([(t, h) for t, h, _, _r in members], [("chosen", "alpha")],
                             f"a live team must be enumerated regardless of its schema key: {team_doc.get('schema')!r}")
            self.assertEqual(skipped, [])

    def test_a_scoped_team_ignores_an_unrelated_corrupt_row(self):
        # The key filter must run BEFORE row validation. Validating first let an
        # unrelated team's corruption degrade a scoped run — the exact thing
        # walking team by team exists to prevent.
        S = launcher.registry_v20.SCHEMA
        globaldoc = {"schema": S, "teams": {
            "chosen": {"state": "registered", "registry_location": "/c.json"},
            "unrelated_corrupt": "not-an-object",
        }}
        files = {"/c.json": {"schema": S, "seats": {}}}
        members, skipped, _ = self._enumerate_team(globaldoc, files, "chosen")
        self.assertEqual((members, skipped), ([], []),
                         "a scoped run must not be degraded by an unrelated team")
        # ...but machine-wide the same row is still a recorded skip.
        members2, skipped2, _ = self._enumerate(globaldoc, files)
        self.assertEqual([t for t, _ in skipped2], ["unrelated_corrupt"])

    def _enumerate_team(self, globaldoc, files, team):
        def fake_load(path):
            if "g.json" in str(path):
                return globaldoc
            return files.get(str(path), {})
        err = io.StringIO()
        with mock.patch.object(launcher.registry_v20, "global_registry_path", return_value="/g.json"), \
             mock.patch.object(launcher.registry_v20, "load_state_doc", side_effect=fake_load), \
             contextlib.redirect_stderr(err):
            members, skipped, _status = launcher.relaunch_batch_members("codex", team)
        return members, skipped, err.getvalue()

    def test_an_unclassifiable_row_skips_its_whole_team_and_relaunches_none_of_it(self):
        # A READABLE AXIS IS NOT ENOUGH. A row nobody can classify means the team's
        # answer is unknown, not empty — and relaunching that team's OTHER rows
        # would present a partial cohort as a complete one, the same defect one
        # level down.
        S = launcher.registry_v20.SCHEMA
        live = {"harness": "codex", "delivery": "pane", "status": "active",
                "pane_id": "%1", "pane": "t/a:0.0", "session": "t/a"}
        globaldoc = {"schema": S, "teams": {"chosen": {"state": "registered",
                                                       "registry_location": "/c.json"}}}
        for axis, why in (
            ({"mystery": "not-an-object"}, "non-object row"),
            ({"a": {"status": "active"}}, "no harness key"),
            ({"a": {"harness": 7}}, "non-string harness"),
        ):
            axis = dict(axis); axis["good"] = live
            members, skipped, _ = self._enumerate(globaldoc, {"/c.json": {"seats": axis}})
            self.assertEqual(members, [], f"{why}: no row of a skipped team may be relaunched")
            self.assertEqual([t for t, _ in skipped], ["chosen"], why)

    def test_a_row_of_a_different_ruled_harness_is_an_exclusion_not_a_skip(self):
        # That is the answer, not a gap.
        S = launcher.registry_v20.SCHEMA
        other = {"harness": "claude", "delivery": "pane", "status": "active",
                 "pane_id": "%1", "pane": "t/a:0.0", "session": "t/a"}
        globaldoc = {"schema": S, "teams": {"chosen": {"state": "registered",
                                                       "registry_location": "/c.json"}}}
        members, skipped, _ = self._enumerate(globaldoc, {"/c.json": {"seats": {"a": other}}})
        self.assertEqual((members, skipped), ([], []))

    def test_the_requested_team_verdict_comes_from_the_ENUMERATED_snapshot(self):
        # TOCTOU. Resolving the team from one read of the global registry and
        # enumerating from a second let a team removed or made historical between
        # the two produce an empty selection and a clean 0 — the ruled typed
        # refusal downgraded by a race. One snapshot answers both questions, so
        # these transitions are simply what that snapshot says.
        S = launcher.registry_v20.SCHEMA
        for teams, want in (
            ({}, "missing"),
            ({"chosen": {"state": "historical", "registry_location": "/c.json"}}, "historical"),
            ({"chosen": {"state": "registered", "registry_location": "/c.json"}}, "ok"),
        ):
            with mock.patch.object(launcher.registry_v20, "global_registry_path", return_value="/g.json"), \
                 mock.patch.object(launcher.registry_v20, "load_state_doc",
                                   side_effect=lambda p, t=teams: {"schema": S, "teams": t}
                                   if "g.json" in str(p) else {"seats": {}}), \
                 contextlib.redirect_stderr(io.StringIO()):
                _m, _s, status = launcher.relaunch_batch_members("codex", "chosen")
            self.assertEqual(status, want)

    def _rc_for(self, teams, files, team, raiser=False):
        S = launcher.registry_v20.SCHEMA

        def load(path):
            if "g.json" in str(path):
                return {"schema": S, "teams": teams}
            if raiser:
                raise OSError("unparseable")
            return files.get(str(path), {})

        with mock.patch.object(launcher.registry_v20, "global_registry_path", return_value="/g.json"), \
             mock.patch.object(launcher.registry_v20, "load_state_doc", side_effect=load), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            return launcher.cmd_relaunch(types.SimpleNamespace(
                seat=None, harness="codex", team=team, message=None, dry_run=True))

    def test_an_explicit_team_that_cannot_be_LOCATED_refuses_rather_than_degrading(self):
        # 6 means a fleet was processed but degraded; here the selected fleet
        # could not be resolved and NOTHING was processed. The one-snapshot
        # refactor briefly lost this: it fixed the verdict at 'ok' before checking
        # the location, so all three shapes degraded to 6 instead of refusing.
        for teams, why in (
            ({"chosen": {"state": "registered"}}, "no registry_location"),
            ({"chosen": {"state": "registered", "registry_location": ""}}, "empty registry_location"),
            ({"chosen": {"state": "registered", "registry_location": "/gone.json"}}, "registry file absent"),
        ):
            self.assertEqual(self._rc_for(teams, {}, "chosen"), 2, why)

    def test_an_absent_registry_and_a_present_empty_one_are_NOT_the_same(self):
        # THE FIXTURE HAS TO TOUCH THE FILESYSTEM. load_state_doc returns {} for a
        # missing file AND for a file containing {}, so the two are
        # indistinguishable from the parsed value alone — which is exactly why the
        # earlier control passed while the code conflated them. Mocking only the
        # loader cannot express this difference, so this arm writes real files.
        S = launcher.registry_v20.SCHEMA
        import json as _json, os as _os, tempfile as _tempfile

        # THE FIXTURE OWNS AND RELEASES ITS OWN FILESYSTEM STATE. mkdtemp() with no
        # cleanup accumulates one directory per gate run, and an unclosed
        # json.load(open(...)) leaks a handle — a control that litters the machine
        # it protects, which this lane has now paid for three times.
        with _tempfile.TemporaryDirectory() as d:
            present = _os.path.join(d, "present-empty.json")
            with open(present, "w") as fh:
                fh.write("{}")
            absent = _os.path.join(d, "gone.json")
            self._assert_absence_polarity(S, present, absent, _json, _os)

    def _assert_absence_polarity(self, S, present, absent, _json, _os):
        def run(loc, team):
            def load(path):
                if "g.json" in str(path):
                    return {"schema": S, "teams": {"chosen": {"state": "registered",
                                                              "registry_location": loc}}}
                if not _os.path.isfile(path):
                    return {}
                with open(path) as fh:
                    return _json.load(fh)
            out, err = io.StringIO(), io.StringIO()
            with mock.patch.object(launcher.registry_v20, "global_registry_path", return_value="/g.json"), \
                 mock.patch.object(launcher.registry_v20, "load_state_doc", side_effect=load), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
                 contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                rc = launcher.cmd_relaunch(types.SimpleNamespace(
                    seat=None, harness="codex", team=team, message=None, dry_run=True))
            return rc, out.getvalue() + err.getvalue()

        rc_present, text_present = run(present, "chosen")
        self.assertEqual(rc_present, 6,
                         "a located-but-invalid registry is a degraded run, not a missing team")
        self.assertNotIn("missing at", text_present,
                         "a registry that exists must never be described as missing")
        rc_absent, _ = run(absent, "chosen")
        self.assertEqual(rc_absent, 2, "an absent registry means the team cannot be located")
        # Machine-wide neither is a refusal: the run happened, a team could not be
        # examined.
        self.assertEqual(run(present, "*")[0], 6)
        self.assertEqual(run(absent, "*")[0], 6)

    def test_a_present_but_unparseable_registry_stays_a_degraded_run(self):
        # The distinction predates the refactor: resolve_team_from_global checked
        # only existence, so a present-but-unparseable registry resolved 'ok' and
        # failed later as a skip. Preserved deliberately rather than collapsed
        # into the refusal above.
        teams = {"chosen": {"state": "registered", "registry_location": "/bad.json"}}
        self.assertEqual(self._rc_for(teams, {}, "chosen", raiser=True), 6)

    def test_the_same_shapes_are_ordinary_skips_machine_wide(self):
        # Machine-wide there is no "selected fleet that could not be resolved" —
        # the run happened, one team could not be examined, which is exactly 6.
        self.assertEqual(self._rc_for({"chosen": {"state": "registered"}}, {}, "*"), 6)

    def test_machine_wide_missing_location_reaches_aggregate_six(self):
        # The end-to-end polarity: an unexaminable registered team must not let
        # the command report 0.
        globaldoc = {"schema": launcher.registry_v20.SCHEMA,
                     "teams": {"broken": {"state": "registered"}}}

        def fake_load(path):
            return globaldoc if "g.json" in str(path) else {}

        out = io.StringIO()
        with mock.patch.object(launcher.registry_v20, "global_registry_path", return_value="/g.json"), \
             mock.patch.object(launcher.registry_v20, "load_state_doc", side_effect=fake_load), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             contextlib.redirect_stdout(out), contextlib.redirect_stderr(io.StringIO()):
            rc = launcher.cmd_relaunch(types.SimpleNamespace(
                seat=None, harness="codex", team="*", message=None, dry_run=False))
        self.assertEqual(rc, 6, "an unexaminable registered team must degrade, not exit 0")
        self.assertIn("broken/* · skipped", out.getvalue())

    def test_a_skipped_team_degrades_the_run_even_when_every_seat_resumed(self):
        # THE WATCHER'S QUESTION. If a team could not be read, the caller has not
        # been told about every seat of this harness — exit 0 would say it was.
        rc, out, calls = self._run({}, skipped=[("broken", "registry unreadable")])
        self.assertEqual(rc, 6, "a skipped team must degrade, not report all-resumed")
        self.assertIn("broken/* · skipped", out)
        self.assertEqual(len(calls), 3, "the readable teams still run")

    def test_an_empty_fleet_is_only_a_clean_zero_when_nothing_was_skipped(self):
        with mock.patch.object(launcher, "relaunch_batch_members", return_value=([], [], None)), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             contextlib.redirect_stdout(io.StringIO()):
            clean = launcher.cmd_relaunch(types.SimpleNamespace(
                seat=None, harness="codex", team="*", message=None, dry_run=False))
        with mock.patch.object(launcher, "relaunch_batch_members",
                               return_value=([], [("broken", "unreadable")], None)), \
             mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
             contextlib.redirect_stdout(io.StringIO()):
            dirty = launcher.cmd_relaunch(types.SimpleNamespace(
                seat=None, harness="codex", team="*", message=None, dry_run=False))
        self.assertEqual((clean, dirty), (0, 6),
                         "an empty fleet with a skipped team must not read as 'nothing to do'")

    def test_a_requested_team_that_does_not_resolve_refuses(self):
        # A misspelled or historical --team otherwise enumerates nothing and exits
        # 0 as "no relaunchable seats" — a success-shaped answer for a fleet that
        # was never examined.
        for status, needle in (("missing", "not enrolled"), ("historical", "historical")):
            err = io.StringIO()
            with mock.patch.object(launcher, "relaunch_batch_members",
                                   return_value=([], [], status)), \
                 contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
                rc = launcher.cmd_relaunch(types.SimpleNamespace(
                    seat=None, harness="codex", team="ghost", message=None, dry_run=False))
            self.assertEqual(rc, 2, f"{status} must refuse, not report an empty fleet")
            self.assertIn(needle, err.getvalue())

    def test_batch_harness_is_limited_to_the_ruled_families(self):
        # The batch form selects and respawns an ENTIRE COHORT, so an over-wide
        # choices list is a destructive surface nobody ruled on, not help drift.
        # The positional single-seat form stays generic. Cursor is in: auth is
        # verified and the operator approved this exact widening. Ops ruled on
        # opencode on 2026-09-17; agy and hermes stay refused.
        self.assertEqual(tuple(launcher.RELAUNCH_BATCH_HARNESSES), ("claude", "codex", "cursor", "opencode"))
        parser = launcher.build_parser() if hasattr(launcher, "build_parser") else None
        if parser is None:
            self.skipTest("no parser accessor")
        for bad in ("agy", "hermes"):
            with self.assertRaises(SystemExit), contextlib.redirect_stderr(io.StringIO()):
                parser.parse_args(["relaunch", "--harness", bad])
        for good in ("claude", "codex", "cursor", "opencode"):
            ns = parser.parse_args(["relaunch", "--harness", good])
            self.assertEqual(ns.harness, good)

    def test_a_cursor_batch_member_carries_its_enumerated_resume_id_into_relaunch_one(self):
        # Real parse → real enumerator → real cmd_relaunch; only relaunch_one is
        # captured. A Cursor row with a stored conversation id must reach
        # relaunch_one as expect_resume — the same rail claude/codex already use.
        # parse_args is the allowlist gate: today --harness cursor is refused, so
        # this fails as feature-missing rather than as a stub of the carry path.
        resume_id = "550e8400-e29b-41d4-a716-446655440000"
        parser = launcher.build_parser()
        args = parser.parse_args(["relaunch", "--harness", "cursor", "--team", "*"])
        self.assertEqual(args.harness, "cursor")

        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp) / "Team"
            (root / ".tap" / "bus").mkdir(parents=True)
            team_reg = root / ".tap" / "bus" / "registry.json"
            team_reg.write_text(json.dumps({
                "schema": launcher.registry_v20.SCHEMA, "team": {"name": "Team"},
                "agents": {"alpha": {"session": "Team/alpha", "delivery": "pane",
                                     "status": "active", "pane_id": "%1",
                                     "pane": "Team/alpha:0.0", "harness": "cursor",
                                     "harness_session_id": resume_id}},
            }))
            global_reg = pathlib.Path(tmp) / "global-registry.json"
            global_reg.write_text(json.dumps({
                "schema": launcher.registry_v20.SCHEMA,
                "teams": {"Team": {"root": str(root), "registry_location": str(team_reg),
                                   "state": "registered"}},
            }))
            seen = {}

            def fake_one(key, message, dry, expect=None, expect_resume=None):
                seen[key] = expect_resume
                return 0

            with mock.patch.object(launcher.registry_v20, "global_registry_path",
                                   return_value=str(global_reg)), \
                 mock.patch.object(launcher, "resolve_caller_pane_id", return_value=""), \
                 mock.patch.object(launcher, "seat_corpse") as corpse, \
                 mock.patch.object(launcher, "current_server_epoch", return_value="srv:1:1"), \
                 mock.patch.object(launcher, "relaunch_one", side_effect=fake_one), \
                 contextlib.redirect_stdout(io.StringIO()), \
                 contextlib.redirect_stderr(io.StringIO()):
                corpse.epoch_voided_ids.side_effect = lambda row, epoch: (row.get("pane_id"), None)
                rc = launcher.cmd_relaunch(args)

        self.assertEqual(rc, 0)
        self.assertEqual(
            seen.get("Team/alpha"), resume_id,
            "cmd_relaunch must hand the enumerator's Cursor resume id to relaunch_one",
        )

    def test_a_seat_and_harness_together_are_refused(self):
        args = types.SimpleNamespace(seat="tap/alpha", harness="codex", team=None,
                                     message=None, dry_run=False)
        with self.assertRaises(launcher.LauncherError) as ctx:
            launcher.cmd_relaunch(args)
        self.assertIn("not both", str(ctx.exception))

    def test_neither_a_seat_nor_harness_is_refused_with_usage(self):
        args = types.SimpleNamespace(seat=None, harness=None, team=None,
                                     message=None, dry_run=False)
        with self.assertRaises(launcher.LauncherError) as ctx:
            launcher.cmd_relaunch(args)
        self.assertIn("usage:", str(ctx.exception))

    def test_a_dry_run_does_not_claim_seats_were_resumed(self):
        # "resumed" for a dry run is a receipt for work that did not happen.
        rc, out, _ = self._run({}, dry_run=True)
        self.assertEqual(rc, 0)
        self.assertIn("would-resume", out)
        self.assertNotIn("· resumed ·", out)

    def test_an_unreadable_team_is_skipped_rather_than_vetoing_the_fleet(self):
        # BEHAVIOURAL, not a source grep. An earlier version of this arm asserted
        # the machine-wide walk was absent from the source and failed on the
        # docstring that explains why it is NOT used — a check that could not
        # tell a mention from a call. The walk has since been deleted with the
        # list port; the property below is what still matters.
        #
        # The property: that walk raises on the first unreadable registry anywhere
        # on the machine, so one unrelated team's corruption would veto a fleet
        # relaunch — the situation this verb exists for.
        good = {"schema": launcher.registry_v20.SCHEMA, "seats": {"alpha": {"harness": "codex", "delivery": "pane",
                                    "status": "active", "pane_id": "%1",
                                    "pane": "t/alpha:0.0", "session": "t/alpha"}}}
        globaldoc = {"schema": launcher.registry_v20.SCHEMA, "teams": {
            "broken": {"state": "registered", "registry_location": "/broken.json"},
            "healthy": {"state": "registered", "registry_location": "/healthy.json"},
        }}

        def fake_load(path):
            if str(path).endswith("global-registry.json") or "global" in str(path):
                return globaldoc
            if str(path) == "/broken.json":
                raise OSError("registry unreadable")
            return good

        err = io.StringIO()
        with mock.patch.object(launcher.registry_v20, "global_registry_path",
                               return_value="/global-registry.json"), \
             mock.patch.object(launcher.registry_v20, "load_state_doc", side_effect=fake_load), \
             contextlib.redirect_stderr(err):
            members, skipped, _status = launcher.relaunch_batch_members("codex", None)

        self.assertEqual(skipped and skipped[0][0], "broken",
                         "the skip must be RETURNED, not only printed — the aggregate depends on it")
        self.assertEqual([(t, h) for t, h, _, _r in members], [("healthy", "alpha")],
                         "the healthy team's seats must survive an unreadable sibling")
        self.assertIn("skipping team", err.getvalue())
        self.assertIn("broken", err.getvalue())


class SessionHelpSurfaceTest(unittest.TestCase):
    def test_every_session_subcommand_stays_visible_from_the_canonical_help(self):
        # A second `session)` arm added ahead of the canonical one shadowed it:
        # `tap help session` showed relaunch ONLY, and the trailing pointer looped
        # back to the same text. Live at 598519ac.
        repo = pathlib.Path(__file__).resolve().parents[5]
        out = subprocess.run(
            ["bash", str(repo / "skills/tap/scripts/tap.sh"), "help", "session"],
            capture_output=True, text=True,
        ).stdout
        for spelling in ("tap session [list]", "tap session launch", "tap session resume",
                         "tap session restart", "tap session relaunch", "tap session repair"):
            self.assertIn(spelling, out, f"{spelling} vanished from tap help session")


class ClearRespawnSequenceTest(unittest.TestCase):
    """The ORDER of the tmux calls tap clear makes (tap-eb9h).

    Ordering is the whole protection here: remain-on-exit has to be armed BEFORE
    anything is replaced, or a harness that fails on the way up takes the pane —
    and a single-window seat's session — with it. Arming it after the respawn
    would look identical in a diff and protect nothing.
    """

    def _run_clear(self, verified=True):
        calls = []

        def fake_run(cmd, **kwargs):
            calls.append(list(cmd))
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

        record = launcher.SessionRecord(
            name="repo/opus", harness="claude", cwd="/seat/cwd", base="repo",
            tag="opus", index=1,
        )
        args = types.SimpleNamespace(seat="opus", message="hello", dry_run=False)
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "root_for_cwd", return_value="/root"), \
                 mock.patch.object(launcher, "clear_target_pane", return_value=("%41", {"session": record.name, "base": record.base, "harness": record.harness, "model": record.model, "registered_from_worktree": record.cwd, "harness_session_id": record.harness_session_id})), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[record], dir_aliases={})), \
                 mock.patch.object(launcher, "entry_session_name", return_value="repo/opus"), \
                 mock.patch.object(launcher, "resolve_exact_record", return_value=record), \
                 mock.patch.object(launcher, "stamp_expected_clear_nonce"), \
                 mock.patch.object(launcher, "consume_expected_clear_nonce"), \
                 mock.patch.object(launcher, "await_clear_rebind", return_value=verified), \
                 mock.patch.object(launcher, "tmux_pane_facts", return_value=None), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ, {"TAP_HOME": bus}, clear=False), \
                 contextlib.redirect_stdout(io.StringIO()), \
                 contextlib.redirect_stderr(io.StringIO()):
                rc = launcher.cmd_clear(args)
        return rc, calls

    def _index_of(self, calls, *needles):
        for i, call in enumerate(calls):
            joined = " ".join(call)
            if all(n in joined for n in needles):
                return i
        self.fail(f"no tmux call matching {needles!r} in {calls!r}")

    def test_remain_on_exit_is_armed_before_the_respawn_and_dropped_after(self):
        rc, calls = self._run_clear()
        self.assertEqual(rc, 0)
        armed = self._index_of(calls, "set-option", "remain-on-exit", "on")
        respawned = self._index_of(calls, "respawn-pane")
        dropped = self._index_of(calls, "set-option", "remain-on-exit", "off")
        self.assertLess(armed, respawned, "remain-on-exit must be armed BEFORE the respawn")
        self.assertLess(respawned, dropped, "it must stay armed across the respawn")

    def test_it_stays_armed_across_the_rebind_wait_not_just_the_respawn(self):
        # A harness can fail a second into its start, after respawn returns. The
        # protection has to cover the whole window the verb is responsible for.
        rc, calls = self._run_clear()
        dropped = self._index_of(calls, "set-option", "remain-on-exit", "off")
        self.assertEqual(dropped, len(calls) - 1, "disarm must be the LAST tmux call")

    def test_it_is_dropped_even_when_the_rebind_is_never_verified(self):
        rc, calls = self._run_clear(verified=False)
        self.assertEqual(rc, 7)
        self._index_of(calls, "set-option", "remain-on-exit", "off")

    def test_a_failed_arming_warns_loudly_and_still_proceeds(self):
        # written-is-not-binding: CONTRACT promises the pane survives a stillborn
        # harness. If arming fails and we say nothing, the promise stays written
        # and unkept, and the operator finds out by losing a seat. Not a refusal —
        # a flaky set-option should not brick the verb — but never silent.
        calls = []

        def fake_run(cmd, **kwargs):
            calls.append(list(cmd))
            rc = 1 if ("set-option" in cmd and "on" in cmd) else 0
            return subprocess.CompletedProcess(args=cmd, returncode=rc, stdout="", stderr="")

        record = launcher.SessionRecord(
            name="repo/opus", harness="claude", cwd="/seat/cwd", base="repo", tag="opus", index=1
        )
        args = types.SimpleNamespace(seat="opus", message=None, dry_run=False)
        err = io.StringIO()
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "root_for_cwd", return_value="/root"), \
                 mock.patch.object(launcher, "clear_target_pane", return_value=("%41", {"session": record.name, "base": record.base, "harness": record.harness, "model": record.model, "registered_from_worktree": record.cwd, "harness_session_id": record.harness_session_id})), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[record], dir_aliases={})), \
                 mock.patch.object(launcher, "entry_session_name", return_value="repo/opus"), \
                 mock.patch.object(launcher, "resolve_exact_record", return_value=record), \
                 mock.patch.object(launcher, "stamp_expected_clear_nonce"), \
                 mock.patch.object(launcher, "consume_expected_clear_nonce"), \
                 mock.patch.object(launcher, "await_clear_rebind", return_value=True), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ, {"TAP_HOME": bus}, clear=False), \
                 contextlib.redirect_stdout(io.StringIO()), \
                 contextlib.redirect_stderr(err):
                rc = launcher.cmd_clear(args)
        self.assertEqual(rc, 0, "a failed arming must not brick the verb")
        self.assertIn("could not arm remain-on-exit", err.getvalue())
        # It proceeded, and did not try to disarm something it never armed.
        self.assertTrue(any("respawn-pane" in " ".join(c) for c in calls))
        self.assertFalse(
            any("set-option" in " ".join(c) and "off" in c for c in calls),
            "nothing to disarm when arming failed",
        )

    def test_a_raising_respawn_disarms_and_propagates_without_a_name_error(self):
        # The failure path grok flagged. It does NOT currently produce a
        # NameError — the exception propagates through `finally` and never
        # reaches the verified check — and this pins that, so a later `except`
        # cannot silently turn a tmux failure into a crash.
        calls = []

        def fake_run(cmd, **kwargs):
            calls.append(list(cmd))
            if "respawn-pane" in cmd:
                raise subprocess.CalledProcessError(1, cmd)
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

        record = launcher.SessionRecord(
            name="repo/opus", harness="claude", cwd="/seat/cwd", base="repo", tag="opus", index=1
        )
        args = types.SimpleNamespace(seat="opus", message=None, dry_run=False)
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "root_for_cwd", return_value="/root"), \
                 mock.patch.object(launcher, "clear_target_pane", return_value=("%41", {"session": record.name, "base": record.base, "harness": record.harness, "model": record.model, "registered_from_worktree": record.cwd, "harness_session_id": record.harness_session_id})), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[record], dir_aliases={})), \
                 mock.patch.object(launcher, "entry_session_name", return_value="repo/opus"), \
                 mock.patch.object(launcher, "resolve_exact_record", return_value=record), \
                 mock.patch.object(launcher, "stamp_expected_clear_nonce"), \
                 mock.patch.object(launcher, "consume_expected_clear_nonce"), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ, {"TAP_HOME": bus}, clear=False), \
                 contextlib.redirect_stdout(io.StringIO()), \
                 contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(subprocess.CalledProcessError):
                    launcher.cmd_clear(args)
        # The pane option must not be left armed for the rest of the seat's life.
        self.assertTrue(
            any("set-option" in " ".join(c) and "off" in c for c in calls),
            "a raising respawn must still disarm remain-on-exit",
        )

    def test_the_respawn_targets_the_seats_own_cwd(self):
        # The pane's directory follows whatever the previous process cd'd to, and
        # registration resolves the bus from cwd.
        rc, calls = self._run_clear()
        respawn = calls[self._index_of(calls, "respawn-pane")]
        self.assertIn("-c", respawn)
        self.assertEqual(respawn[respawn.index("-c") + 1], "/seat/cwd")
        self.assertIn("-k", respawn)

    def test_a_second_clear_exits_2_having_changed_nothing(self):
        # The flock serializes writers. Acquire happens BEFORE stamp, so a
        # refused concurrent clear must not write expected_clear_nonce and
        # must not respawn. Distinct from recipient_clearing (courier, exit 1).
        record = launcher.SessionRecord(
            name="repo/opus", harness="claude", cwd="/seat/cwd", base="repo",
            tag="opus", index=1,
        )
        args = types.SimpleNamespace(seat="opus", message=None, dry_run=False)
        stamp = mock.Mock()
        out = io.StringIO()
        with tempfile.TemporaryDirectory() as bus:
            held = launcher.clear_fence.try_acquire(
                bus, "opus", "holder-nonce", os.getpid(), "claude", 45.0,
            )
            self.assertIsNotNone(held)
            try:
                with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                     mock.patch.object(launcher, "root_for_cwd", return_value="/root"), \
                     mock.patch.object(launcher, "clear_target_pane", return_value=("%41", {"session": record.name, "base": record.base, "harness": record.harness, "model": record.model, "registered_from_worktree": record.cwd, "harness_session_id": record.harness_session_id})), \
                     mock.patch.object(launcher, "registry_session_state",
                                       return_value=launcher.Manifest(sessions=[record], dir_aliases={})), \
                     mock.patch.object(launcher, "entry_session_name", return_value="repo/opus"), \
                     mock.patch.object(launcher, "resolve_exact_record", return_value=record), \
                     mock.patch.object(launcher, "stamp_expected_clear_nonce", stamp), \
                     mock.patch.object(launcher.subprocess, "run") as tmux, \
                     mock.patch.dict(os.environ, {"TAP_HOME": bus, "TAP_JSON": "1"}, clear=False), \
                     contextlib.redirect_stdout(out), \
                     contextlib.redirect_stderr(io.StringIO()):
                    rc = launcher.cmd_clear(args)
            finally:
                held.release()
        self.assertEqual(rc, 2)
        payload = json.loads(out.getvalue())
        self.assertEqual(payload["error_class"], "clear_in_progress")
        stamp.assert_not_called()
        tmux.assert_not_called()


class OpenCodeClearInstructionTest(unittest.TestCase):
    """tap-0jtk: opencode -m rides the bus, never argv, while the fence is held."""

    def _run(self, *, message, verified=True, send_rc=0, deliver_ctx=None):
        order = []
        calls = []
        err = io.StringIO()
        record = launcher.SessionRecord(
            name="repo/kimi", harness="opencode", cwd="/seat/cwd",
            base="repo", tag="kimi", index=1,
        )
        args = types.SimpleNamespace(seat="kimi", message=message, dry_run=False)

        class Held:
            def release(self):
                order.append("release")

        def fake_run(cmd, **kwargs):
            calls.append(list(cmd))
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

        def fake_deliver(handle, instruction, *rest, **kwargs):
            order.append(("send", handle, instruction))
            if deliver_ctx is not None:
                deliver_ctx["rest"] = rest
                deliver_ctx["kwargs"] = kwargs
            return send_rc

        def fake_mint(rec):
            return dataclasses.replace(rec, harness_session_id="ses_test")

        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "root_for_cwd", return_value="/root"), \
                 mock.patch.object(launcher, "clear_target_pane",
                                   return_value=("%41", {"session": record.name, "base": record.base, "harness": record.harness, "model": record.model, "registered_from_worktree": record.cwd, "harness_session_id": record.harness_session_id})), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[record], dir_aliases={})), \
                 mock.patch.object(launcher, "entry_session_name", return_value="repo/kimi"), \
                 mock.patch.object(launcher, "resolve_exact_record", return_value=record), \
                 mock.patch.object(launcher, "mint_launch_session_id", side_effect=fake_mint), \
                 mock.patch.object(launcher, "stamp_expected_clear_nonce"), \
                 mock.patch.object(launcher, "consume_expected_clear_nonce"), \
                 mock.patch.object(launcher, "await_clear_rebind", return_value=verified), \
                 mock.patch.object(launcher, "record_clear_latency"), \
                 mock.patch.object(launcher.clear_fence, "try_acquire", return_value=Held()), \
                 mock.patch.object(launcher, "deliver_clear_instruction_via_send",
                                   side_effect=fake_deliver), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ, {"TAP_HOME": bus}, clear=False), \
                 contextlib.redirect_stdout(io.StringIO()), \
                 contextlib.redirect_stderr(err):
                rc = launcher.cmd_clear(args)
        return rc, order, calls, err.getvalue()

    def test_minus_m_sends_once_before_the_fence_releases(self):
        # Drain delivers this send before any send parked later only if it is
        # parked while the fence is still held. A future fence that delivers
        # during await would silently break that ordering.
        deliver_ctx: dict = {}
        rc, order, calls, _err = self._run(message="resume the review",
                                           deliver_ctx=deliver_ctx)
        self.assertEqual(rc, 0)
        self.assertEqual(order[0], ("send", "kimi", "resume the review"))
        self.assertEqual(order.count(("send", "kimi", "resume the review")), 1)
        self.assertIn("release", order)
        self.assertLess(order.index(("send", "kimi", "resume the review")), order.index("release"))
        respawn = " ".join(next(c for c in calls if "respawn-pane" in c))
        self.assertNotIn("resume the review", respawn)
        # CONTROL (tap-74h2l): the CLEAR side never supplies target-team
        # context; the courier recipient stays the bare handle.
        self.assertEqual(deliver_ctx.get("rest"), ())
        self.assertIsNone(deliver_ctx.get("kwargs", {}).get("team"))

    def test_bare_clear_does_not_send(self):
        rc, order, _calls, _err = self._run(message=None)
        self.assertEqual(rc, 0)
        self.assertEqual([item for item in order if item != "release"], [])
        self.assertIn("release", order)

    def test_unverified_rebind_does_not_send(self):
        rc, order, _calls, _err = self._run(message="resume the review", verified=False)
        self.assertEqual(rc, 7)
        self.assertEqual([item for item in order if item != "release"], [])

    def test_send_failure_after_verified_rebind_exits_6(self):
        # Seat is already restarted, so this is not a refusal (2) and not an
        # unverified rebind (7). Exit 0 would report a delivery that did not
        # happen. 6 is the compact dropped-focus polarity. The repair names
        # --from so a pane-less caller can actually run it.
        with mock.patch.dict(os.environ):
            for key in ("TAP_SELF", "TMUX", "TMUX_PANE", "TAP_JSON"):
                os.environ.pop(key, None)
            rc, order, _calls, err = self._run(message="resume the review", send_rc=1)
        self.assertEqual(rc, 6)
        self.assertIn("release", order)
        self.assertIn("did not land", err)
        self.assertIn("tap send kimi -f", err)
        self.assertIn("--fyi", err)
        self.assertIn("--from <your-handle>", err)

    def test_send_failure_repair_names_tap_self_when_set(self):
        with mock.patch.dict(os.environ, {"TAP_SELF": "cronbot"}, clear=False):
            os.environ.pop("TAP_JSON", None)
            rc, _order, _calls, err = self._run(message="resume the review", send_rc=1)
        self.assertEqual(rc, 6)
        self.assertIn("--from cronbot", err)

    def test_outside_tmux_clear_minus_m_exits_6_and_omits_from(self):
        # cmd_clear + real deliver, identity stripped. A TAP_SELF-only arm
        # re-proves the registered path and misses the hole the gate ran.
        send_cmds = []
        order = []
        err = io.StringIO()
        record = launcher.SessionRecord(
            name="repo/kimi", harness="opencode", cwd="/seat/cwd",
            base="repo", tag="kimi", index=1,
        )
        args = types.SimpleNamespace(seat="kimi", message="resume the review", dry_run=False)

        class Held:
            def release(self):
                order.append("release")

        def fake_run(cmd, **kwargs):
            if any("tap-send.sh" in str(part) for part in cmd):
                send_cmds.append(list(cmd))
                return subprocess.CompletedProcess(args=cmd, returncode=1, stdout="", stderr="")
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

        def fake_mint(rec):
            return dataclasses.replace(rec, harness_session_id="ses_test")

        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "root_for_cwd", return_value="/root"), \
                 mock.patch.object(launcher, "clear_target_pane",
                                   return_value=("%41", {"session": record.name, "base": record.base, "harness": record.harness, "model": record.model, "registered_from_worktree": record.cwd, "harness_session_id": record.harness_session_id})), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[record], dir_aliases={})), \
                 mock.patch.object(launcher, "entry_session_name", return_value="repo/kimi"), \
                 mock.patch.object(launcher, "resolve_exact_record", return_value=record), \
                 mock.patch.object(launcher, "mint_launch_session_id", side_effect=fake_mint), \
                 mock.patch.object(launcher, "stamp_expected_clear_nonce"), \
                 mock.patch.object(launcher, "consume_expected_clear_nonce"), \
                 mock.patch.object(launcher, "await_clear_rebind", return_value=True), \
                 mock.patch.object(launcher, "record_clear_latency"), \
                 mock.patch.object(launcher.clear_fence, "try_acquire", return_value=Held()), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ, {"TAP_HOME": bus}, clear=False), \
                 contextlib.redirect_stdout(io.StringIO()), \
                 contextlib.redirect_stderr(err):
                for key in ("TAP_SELF", "TMUX", "TMUX_PANE", "TAP_JSON"):
                    os.environ.pop(key, None)
                rc = launcher.cmd_clear(args)
        self.assertEqual(rc, 6)
        self.assertEqual(len(send_cmds), 1)
        self.assertNotIn("--from", send_cmds[0])
        self.assertIn("--from <your-handle>", err.getvalue())
        self.assertIn("release", order)

    def test_dry_run_notes_the_bus_channel_and_touches_nothing(self):
        record = launcher.SessionRecord(
            name="repo/kimi", harness="opencode", cwd="/seat/cwd",
            base="repo", tag="kimi", index=1,
        )
        args = types.SimpleNamespace(seat="kimi", message="resume the review", dry_run=True)
        out = io.StringIO()
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "root_for_cwd", return_value="/root"), \
                 mock.patch.object(launcher, "clear_target_pane",
                                   return_value=("%41", {"session": record.name, "base": record.base, "harness": record.harness, "model": record.model, "registered_from_worktree": record.cwd, "harness_session_id": record.harness_session_id})), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[record], dir_aliases={})), \
                 mock.patch.object(launcher, "entry_session_name", return_value="repo/kimi"), \
                 mock.patch.object(launcher, "resolve_exact_record", return_value=record), \
                 mock.patch.object(
                     launcher, "mint_launch_session_id",
                     side_effect=lambda rec: dataclasses.replace(rec, harness_session_id="ses_test"),
                 ), \
                 mock.patch.object(launcher, "deliver_clear_instruction_via_send") as deliver, \
                 mock.patch.object(launcher.subprocess, "run") as tmux, \
                 mock.patch.dict(os.environ, {"TAP_HOME": bus}, clear=False), \
                 contextlib.redirect_stdout(out):
                rc = launcher.cmd_clear(args)
        self.assertEqual(rc, 0)
        deliver.assert_not_called()
        tmux.assert_not_called()
        text = out.getvalue()
        self.assertIn("opencode", text)
        self.assertNotIn("resume the review", text.split("\n")[0])
        self.assertIn("tap send", text)
        self.assertIn("fence", text)

    def test_deliver_uses_a_body_file_and_settle_only(self):
        seen = {}

        def fake_run(cmd, **kwargs):
            seen["cmd"] = list(cmd)
            path = cmd[cmd.index("-f") + 1]
            seen["body"] = pathlib.Path(path).read_text(encoding="utf-8")
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

        with tempfile.TemporaryDirectory() as bus:
            bus_path = pathlib.Path(bus)
            with mock.patch.object(launcher, "_team_bus_home", return_value=bus_path), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ):
                os.environ.pop("TAP_SELF", None)
                rc = launcher.deliver_clear_instruction_via_send("kimi", "resume the review")
            leftovers = list((bus_path / "tmp").glob(".tap-clear-instruction.*"))
        self.assertEqual(rc, 0)
        self.assertIn("--fyi", seen["cmd"])
        self.assertIn("-f", seen["cmd"])
        self.assertEqual(seen["cmd"][2], "kimi")
        self.assertNotIn("-m", seen["cmd"])
        self.assertNotIn("--from", seen["cmd"])
        self.assertIn("bus, not as process argv", seen["body"])
        self.assertIn("resume the review", seen["body"])
        self.assertEqual(leftovers, [])

    def test_deliver_targets_the_named_team_when_team_is_supplied(self):
        # tap-74h2l: with a target team the courier recipient is the qualified
        # `other/kimi`, which selects the target team's registry and pane; a
        # bare `kimi` would resolve the caller-team's same-named seat instead.
        seen = {}

        def fake_run(cmd, **kwargs):
            seen["cmd"] = list(cmd)
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "_team_bus_home", return_value=pathlib.Path(bus)), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ):
                os.environ.pop("TAP_SELF", None)
                rc = launcher.deliver_clear_instruction_via_send(
                    "kimi", "resume the review", team="other")
        self.assertEqual(rc, 0)
        self.assertEqual(seen["cmd"][2], "other/kimi")
        self.assertNotIn("kimi", seen["cmd"])

    def test_deliver_passes_from_when_tap_self_is_set(self):
        seen = {}

        def fake_run(cmd, **kwargs):
            seen["cmd"] = list(cmd)
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "_team_bus_home", return_value=pathlib.Path(bus)), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ, {"TAP_SELF": "cronbot"}, clear=False):
                rc = launcher.deliver_clear_instruction_via_send("kimi", "resume the review")
        self.assertEqual(rc, 0)
        self.assertIn("--from", seen["cmd"])
        self.assertEqual(seen["cmd"][seen["cmd"].index("--from") + 1], "cronbot")

    def test_outside_tmux_deliver_without_identity_returns_send_rc(self):
        # A test that only runs with TAP_SELF set re-proves the registered path.
        # This arm is the hole: no TMUX, no TAP_SELF, send refuses, deliver
        # must not look like success.
        def fake_run(cmd, **kwargs):
            self.assertNotIn("--from", cmd)
            return subprocess.CompletedProcess(args=cmd, returncode=1, stdout="", stderr="unregistered")

        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher, "_team_bus_home", return_value=pathlib.Path(bus)), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ):
                for key in ("TAP_SELF", "TMUX", "TMUX_PANE"):
                    os.environ.pop(key, None)
                rc = launcher.deliver_clear_instruction_via_send("kimi", "resume the review")
        self.assertEqual(rc, 1)


class OpenCodeRelaunchInstructionDeliveryTest(unittest.TestCase):
    """tap-74h2l: the relaunch -m instruction is addressed to the TARGET team.

    The qualified recipient `<team>/<handle>` is what makes the send resolve
    the target team's registry and pane and consult the target clearing fence;
    custody of the canonical payload stays on the sender's bus (tap-send.sh).
    """

    def _run(self, *, send_rc=0):
        record = launcher.SessionRecord(
            name="other/kimi", harness="opencode", cwd="/seat/cwd",
            base="other", tag="kimi", index=1,
            harness_session_id="ses_previous",
        )
        row = {"session": "other/kimi", "delivery": "pane", "status": "active",
               "pane_id": "%51", "pane": "other/kimi:0.0", "harness": "opencode",
               "harness_session_id": "ses_previous"}
        respawned = []
        sends = []

        def current_facts(*_a, **_k):
            facts = launcher.PaneFacts(
                pane="other/kimi:0.0", pane_id="%51", command="opencode",
                path="/seat/cwd", server_epoch="srv:1:1", dead=False, pane_pid=1001,
            )
            if respawned:
                return dataclasses.replace(facts, pane_pid=2002)
            return facts

        args = types.SimpleNamespace(seat="other/kimi", message="hello", dry_run=False)

        def fake_run(cmd, **kwargs):
            if any("tap-send.sh" in str(part) for part in cmd):
                sends.append(list(cmd))
                return subprocess.CompletedProcess(args=cmd, returncode=send_rc, stdout="", stderr="")
            if cmd and len(cmd) > 1 and cmd[1] == "respawn-pane":
                respawned.append(list(cmd))
            return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

        out, err = io.StringIO(), io.StringIO()
        with tempfile.TemporaryDirectory() as bus:
            with mock.patch.object(launcher.registry_v20, "resolve_team_from_global",
                                   return_value=("ok", bus, f"{bus}/team-registry.json")), \
                 mock.patch.object(launcher, "refuse_if_team_reset_fenced"), \
                 mock.patch.object(launcher, "registry_entry", return_value=dict(row)), \
                 mock.patch.object(launcher, "clear_target_pane", return_value=("%51", dict(row))), \
                 mock.patch.object(launcher, "registry_session_state",
                                   return_value=launcher.Manifest(sessions=[record], dir_aliases={})), \
                 mock.patch.object(launcher, "entry_session_name", return_value="other/kimi"), \
                 mock.patch.object(launcher, "stamp_expected_clear_nonce"), \
                 mock.patch.object(launcher, "consume_expected_clear_nonce"), \
                 mock.patch.object(launcher, "await_clear_rebind", return_value=True), \
                 mock.patch.object(launcher, "tmux_pane_facts", side_effect=current_facts), \
                 mock.patch.object(launcher, "clear_rebind_timeout",
                                   return_value=launcher.CLEAR_REBIND_TIMEOUT_SECONDS), \
                 mock.patch.object(launcher.subprocess, "run", side_effect=fake_run), \
                 mock.patch.dict(os.environ, {"TAP_SELF": "other/glm"}, clear=False), \
                 contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                rc = launcher.cmd_relaunch(args)
        return rc, sends, respawned, out.getvalue(), err.getvalue()

    def test_the_post_rebind_instruction_is_addressed_to_the_target_team(self):
        # tap-74h2l. This control pins the ADDRESS the relaunch emits: the
        # qualified spelling `other/kimi`, not a bare `kimi`, which would
        # resolve the caller-team's same-named seat. That the exact qualified
        # spelling routes to the target pane and never the caller-team
        # same-handle seat is proven by the unchanged cross-team smoke
        # same-handle-xwt-guard.test.sh (sender bus custody, one inject).
        # The instruction rides the bus after the verified rebind, never the
        # respawn argv (tap-0jtk).
        rc, sends, respawns, out, err = self._run()
        self.assertEqual(rc, 0, out + err)
        self.assertEqual(len(sends), 1)
        self.assertEqual(sends[0][2], "other/kimi")
        self.assertNotIn("kimi", sends[0])
        self.assertIn("--fyi", sends[0])
        self.assertIn("--wake", sends[0])
        self.assertIn("-f", sends[0])
        self.assertEqual(len(respawns), 1)
        self.assertNotIn("hello", " ".join(respawns[0]))

    def test_an_undelivered_instruction_names_the_target_team_recipient(self):
        # Seat already restarted, so the failure polarity is the compact
        # dropped-focus 6, and the recovery must be runnable as printed: the
        # recipient it names must be the one the send actually needed.
        rc, _sends, _respawns, _out, err = self._run(send_rc=1)
        self.assertEqual(rc, 6)
        self.assertIn("tap send other/kimi -f", err)


if __name__ == "__main__":
    unittest.main()


class FailedSeatResumeTests(unittest.TestCase):
    def test_named_resume_recovers_operationally_suspended_seat(self):
        for reason in ("pane_gone", "session_replaced", "repair_failed", "restart_failed", "user_removed"):
            with self.subTest(reason=reason), tempfile.TemporaryDirectory() as tmp:
                root = pathlib.Path(tmp).resolve()
                index = root / "index"
                index.mkdir()
                registry = root / ".tap" / "team-registry.json"
                registry.parent.mkdir()
                (registry.parent / "bus").mkdir()
                row = {"status": "suspended", "status_reason": reason,
                       "delivery": "pane", "session": "repo/coach", "harness": "cursor",
                       "harness_session_id": "stored-conversation", "tag": "coach",
                       "registered_from_worktree": str(root)}
                registry.write_text(json.dumps({"schema": "0.20", "team": {"name": "repo", "worktree_root": str(root)}, "seats": {"coach": row}}))
                (index / "global-registry.json").write_text(json.dumps({"schema": "0.20", "teams": {"repo": {"root": str(root), "registry_location": str(registry)}}}))
                before = registry.read_bytes()
                args = launcher.build_parser().parse_args(["resume", "coach", "--dry-run", "--json"])
                with mock.patch.dict(os.environ, {"TAP_INDEX_HOME": str(index), "TAP_HOME": str(registry.parent / "bus")}), \
                     mock.patch.object(pathlib.Path, "cwd", return_value=root), \
                     contextlib.redirect_stdout(io.StringIO()) as out, \
                     contextlib.redirect_stderr(io.StringIO()) as err:
                    if reason == "user_removed":
                        # tap-swsnr: the user_removed tombstone still occupies the
                        # roster handle, so #xxxx's occupied-handle refusal fires
                        # ahead of the old "resume key not found" fallthrough.
                        with self.assertRaisesRegex(
                            launcher.LauncherError,
                            r"resume refused — handle 'coach' is occupied on the roster "
                            r"but has no launcher record to resume",
                        ):
                            launcher.cmd_resume(args)
                        self.assertEqual(registry.read_bytes(), before)
                        continue
                    self.assertEqual(launcher.cmd_resume(args), 0)
                self.assertIn(f"would resume repo/coach from suspended/{reason}", err.getvalue())
                payload = json.loads(out.getvalue())
                self.assertIn("stored-conversation", payload["argv"])
                self.assertEqual(registry.read_bytes(), before)
                self.assertFalse(launcher.registry_v20.seat_is_relaunchable(row), "bulk resume must retain its existing exclusions")

    def test_failed_resume_rollback_preserves_named_retry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            registry = root / ".tap" / "bus" / "registry.json"
            registry.parent.mkdir(parents=True)
            incumbent = {"status": "active", "delivery": "pane", "session": "repo/coach",
                         "harness": "cursor", "harness_session_id": "stored-conversation", "tag": "coach"}
            record = launcher.SessionRecord(name="repo/coach", harness="cursor", cwd=str(root),
                base="repo", tag="coach", launch_id="claim", replacement_registry_entry=incumbent)
            payload = {"team": {"name": "repo", "worktree_root": str(root)},
                       "agents": {"coach": {**incumbent, "status": "pending", "launch_id": "claim"}}}
            registry.write_text(json.dumps(payload))
            self.assertTrue(launcher.rollback_pending_handle(record, "session_replaced"))
            restored = json.loads(registry.read_text())
            self.assertEqual(launcher._session_state_from_registry_payload(restored, str(root)).sessions, [])
            retry = launcher._failed_resume_record(launcher._session_state_from_registry_payload(restored, str(root)), str(root), "coach")
            self.assertEqual(retry.harness_session_id, "stored-conversation")

    def test_named_resume_cannot_revive_removed_poll_or_crew(self):
        for delta in ({"status_reason": "user_removed"}, {"delivery": "poll"}, {"crew": True}):
            row = {"status": "suspended", "status_reason": "session_replaced", "delivery": "pane", "session": "repo/coach", **delta}
            self.assertFalse(launcher.registry_v20.seat_is_relaunchable(row, explicit_resume=True))


class FailedSeatResumeBoundaryTests(unittest.TestCase):
    @contextlib.contextmanager
    def registry(self, entries):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp).resolve()
            index = root / "index"
            index.mkdir()
            registry = root / ".tap" / "team-registry.json"
            registry.parent.mkdir()
            (registry.parent / "bus").mkdir()
            rows = {handle: {"delivery": "pane", "harness": "cursor", "session": f"repo/{handle}",
                            "tag": handle, "harness_session_id": f"id-{handle}", "registered_from_worktree": str(root), **entry}
                    for handle, entry in entries.items()}
            registry.write_text(json.dumps({"schema": "0.20", "team": {"name": "repo", "worktree_root": str(root)}, "seats": rows}))
            (index / "global-registry.json").write_text(json.dumps({"schema": "0.20", "teams": {"repo": {"root": str(root), "registry_location": str(registry)}}}))
            with mock.patch.dict(os.environ, {"TAP_INDEX_HOME": str(index), "TAP_HOME": str(registry.parent / "bus")}), \
                 mock.patch.object(pathlib.Path, "cwd", return_value=root):
                yield registry

    def test_harness_resume_does_not_adopt_create_from_failed_iterator_member(self):
        with self.registry({"live": {"status": "active"}, "gone": {"status": "suspended", "status_reason": "pane_gone"}}), \
             mock.patch.object(launcher, "session_attachable", side_effect=lambda name: name == "repo/live"), \
             mock.patch.object(launcher, "reattach_live_session", return_value=0) as attach, \
             mock.patch.object(launcher, "run_adopted_resume", side_effect=AssertionError("must not create third seat")):
            args = launcher.build_parser().parse_args(["resume", "cursor"])
            self.assertEqual(launcher.cmd_resume(args), 0)
            self.assertEqual(attach.call_args.args[0], "repo/live")

    def test_failed_row_with_live_name_cannot_rebind_occupant(self):
        with self.registry({"coach": {"status": "suspended", "status_reason": "session_replaced"}}) as registry, \
             mock.patch.object(launcher, "session_attachable", return_value=True), \
             mock.patch.object(launcher, "finish_resume", side_effect=AssertionError("must not rebind live occupant")) as finish:
            before = registry.read_bytes()
            args = launcher.build_parser().parse_args(["resume", "coach"])
            with self.assertRaisesRegex(launcher.LauncherError, "suspended/session_replaced"):
                launcher.cmd_resume(args)
            finish.assert_not_called()
            self.assertEqual(registry.read_bytes(), before)


class StartupTracePassthroughTests(unittest.TestCase):
    def test_trace_transport_failure_never_changes_main_result_or_original_exception(self):
        for error in (subprocess.TimeoutExpired("bun", 0.2), FileNotFoundError("bun"), subprocess.CalledProcessError(7, "bun")):
            with mock.patch.object(launcher.startup_trace, "_RUN", side_effect=error), mock.patch.object(launcher, "current_boot_id", return_value="test"), mock.patch.object(launcher.lifecycle_diagnostics, "begin"), contextlib.redirect_stderr(io.StringIO()) as stderr:
                with mock.patch.object(launcher, "_main", return_value=7):
                    self.assertEqual(launcher.main(["new", "codex", "seat"]), 7)
                original = RuntimeError("original launch failure")
                with mock.patch.object(launcher, "_main", side_effect=original), self.assertRaises(RuntimeError) as caught:
                    launcher.main(["new", "codex", "seat"])
                self.assertIs(caught.exception, original)
                self.assertIsNone(launcher.startup_trace._context)
                self.assertEqual(stderr.getvalue(), "")

    def test_actual_trace_bridge_preserves_prerequisite_activation_and_main_result(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(os.environ, {"TAP_INDEX_HOME": tmp}):
            def operation(tokens):
                launcher.startup_trace.activate()
                launcher.startup_trace.phase("respawn_pane", session="fixture/seat")
                return 7
            with mock.patch.object(launcher, "_main", side_effect=operation):
                self.assertEqual(launcher.main(["new", "codex", "seat", "--", "--help"]), 7)
            rows = [json.loads(line) for line in (pathlib.Path(tmp) / "logs/startup.jsonl").read_text().splitlines()]
            self.assertEqual([row["event"] for row in rows], ["launch_start", "launch_failure"])
            self.assertEqual(rows[-1]["phase"], "respawn_pane")
            self.assertEqual(rows[-1]["exit_code"], 7)
            self.assertEqual(rows[0]["operation_id"], rows[1]["operation_id"])
            self.assertIsNone(launcher.startup_trace._context)

    def test_harness_help_does_not_disable_lifecycle_trace(self):
        for flag in ("--help", "-h", "--dry-run"):
            with mock.patch.object(launcher, "_main", return_value=0), mock.patch.object(launcher.startup_trace, "begin") as begin, mock.patch.object(launcher.startup_trace, "finish"):
                self.assertEqual(launcher.main(["new", "codex", "seat", "--", flag]), 0)
                begin.assert_called_once()
            with mock.patch.object(launcher, "_main", return_value=0), mock.patch.object(launcher.startup_trace, "begin") as begin:
                launcher.main(["new", "codex", "seat", flag])
                begin.assert_not_called()

class RebootMembershipTests(unittest.TestCase):
    def test_positive_same_socket_staleness_and_unknown_controls(self):
        row = {"server_socket": "/tmp/test", "boot_id": "boot:100", "server_epoch": "srv:1:100"}
        with mock.patch.object(launcher, "boot_ids_match", side_effect=lambda a,b: a == b):
            self.assertTrue(launcher.stale_seat_generation(row, ("boot:200", "srv:2:200", "/tmp/test")))
            self.assertFalse(launcher.stale_seat_generation(row, ("boot:100", "srv:1:100", "/tmp/test")))
            for obs in [(None, None, None), ("boot:200", None, "/tmp/test"), ("boot:200", "srv:2:200", "/tmp/other")]:
                self.assertFalse(launcher.stale_seat_generation(row, obs))
            self.assertFalse(launcher.stale_seat_generation({"server_socket": "/tmp/test"}, ("boot:200", "srv:2:200", "/tmp/test")))

    def test_reboot_membership_preserves_reason_and_excludes_removed_poll_crew(self):
        rows = {}
        for name, delta in {"eligible": {}, "removed": {"status_reason": "user_removed"}, "poll": {"delivery": "poll"}, "crew": {"crew": True}, "unstamped": {"boot_id": None, "server_epoch": None}}.items():
            rows[name] = {"status": "suspended", "status_reason": "pane_gone", "delivery": "pane", "harness": "cursor", "session": f"repo/{name}", "tag": name,
                          "harness_session_id": f"id-{name}", "server_socket": "/tmp/test", "boot_id": "boot:100", "server_epoch": "srv:1:100", **delta}
        before = json.dumps(rows, sort_keys=True)
        with mock.patch.object(launcher, "registry_entries", return_value=rows), mock.patch.object(launcher, "root_for_cwd", return_value="/repo"), mock.patch.object(launcher, "boot_ids_match", return_value=False):
            records = launcher.reboot_resume_records("/repo", ("boot:200", "srv:2:200", "/tmp/test"))
        self.assertEqual([r.tag for r in records], ["eligible"])
        self.assertEqual(records[0].harness_session_id, "id-eligible")
        self.assertEqual(json.dumps(rows, sort_keys=True), before)

    def test_prior_boot_live_occupant_refuses_before_registration(self):
        record = launcher.SessionRecord(name="repo/coach", harness="cursor", cwd="/repo", base="repo", tag="coach")
        with mock.patch.object(launcher, "registry_entry", return_value={"status_reason": "server_restarted"}), mock.patch.object(launcher, "stale_seat_generation", return_value=True), mock.patch.object(launcher, "finish_resume", side_effect=AssertionError("must not register")):
            with self.assertRaisesRegex(launcher.LauncherError, "prior boot/server"):
                launcher.reattach_live_session(record.name, record)

    def test_bulk_adds_stale_row_and_names_skipped_live_occupant(self):
        stopped = launcher.SessionRecord(name="repo/stopped", harness="cursor", cwd="/repo", base="repo", tag="stopped", harness_session_id="id-stopped")
        occupied = dataclasses.replace(stopped, name="repo/occupied", tag="occupied", harness_session_id="id-occupied")
        args = launcher.build_parser().parse_args(["resume", "--all", "--dry-run", "--json"])
        with mock.patch.object(launcher, "refuse_if_team_reset_fenced"), mock.patch.object(launcher, "_reset_fence_entry_barrier"), \
             mock.patch.object(launcher, "_refuse_if_flip_authority"), mock.patch.object(launcher, "tmux_sessions_for_namespace", return_value={"repo/occupied"}), \
             mock.patch.object(launcher, "current_server_epoch", return_value="srv:2:200"), mock.patch.object(launcher, "current_server_socket", return_value="/tmp/test"), \
             mock.patch.object(launcher, "current_boot_id", return_value="boot:200"), mock.patch.object(launcher, "reboot_resume_records", return_value=[stopped, occupied]), \
             mock.patch.object(launcher, "registry_entry", return_value={"status": "suspended", "status_reason": "pane_gone"}), \
             mock.patch.object(launcher, "stale_seat_generation", return_value=True), mock.patch.object(launcher, "in_scope", return_value=True), \
             mock.patch.object(launcher, "assert_unique_harness_session_identity"), mock.patch.object(launcher, "state_expected_revive_identity"), \
             mock.patch.object(launcher, "run_record_detached", return_value=0) as run, \
             contextlib.redirect_stderr(io.StringIO()) as err:
            self.assertEqual(launcher.cmd_resume_all(args, launcher.Manifest(sessions=[], dir_aliases={}), "/repo"), 0)
        self.assertEqual(run.call_count, 1)
        self.assertEqual(run.call_args.args[1].name, "repo/stopped")
        self.assertIn("skipped unverified live occupants after restart: occupied", err.getvalue())


class NoticeInitializerTransportTests(unittest.TestCase):
    """A failed notice INITIALIZER is a startup transport fault.

    `suppress_notices`/`reset_notices` are bridge RPCs now, and `_main` calls
    them inside its existing `try` -- so a missing bun renders as the concise
    `missing command` line with status 127 and a failed child as
    `command failed (exit N)` with that status, exactly like every other
    transport failure. Neither may escape `_main` as a traceback.
    """

    def test_failed_notice_initializer_returns_through_transport_rendering(self):
        # The FileNotFoundError is REAL in the way the handler consumes it: its
        # `.filename` is "bun" (errno, strerror, filename), because the
        # missing-command line prints `exc.filename`, not the message.
        cases = [
            (FileNotFoundError(2, "No such file or directory", "bun"), 127,
             "missing command: bun"),
            (subprocess.CalledProcessError(3, ["bun", "preset-api.ts"]), 3,
             "command failed (exit 3)"),
        ]
        for exc, expected_rc, fragment in cases:
            with self.subTest(exc=type(exc).__name__):
                with mock.patch.object(preset_config, "suppress_notices", side_effect=exc), \
                     contextlib.redirect_stderr(io.StringIO()) as err:
                    rc = launcher._main(["help"])
                self.assertEqual(rc, expected_rc)
                self.assertIn("tap session: " + fragment, err.getvalue())
                self.assertNotIn("Traceback", err.getvalue())
