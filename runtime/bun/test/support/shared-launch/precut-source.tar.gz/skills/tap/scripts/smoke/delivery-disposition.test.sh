#!/usr/bin/env bash
# Public send controls reuse the existing pane/registry fixture, not policy mocks.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
python3 - "$ROOT" "$WORK/probe.sh" <<'PY'
from pathlib import Path
import shlex, sys
root=Path(sys.argv[1]); source=(root/'skills/tap/scripts/smoke/courier-digest.test.sh').read_text()
source=source.split('# ---- (0) identity drift',1)[0]
source=source.replace('ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"', 'ROOT='+shlex.quote(str(root)))
source=source.replace('. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"', '. '+shlex.quote(str(root/'skills/tap/scripts/smoke/sandbox-pins.sh')))
source=source.replace('select-pane) echo "$*" >> "$state/tint.log" ;;', 'select-pane) echo "$*" >> "$state/tint.log"; echo "STYLE $*" >> "$state/send-keys.log" ;;')
source=source.replace('  capture-pane)\n', '  capture-pane)\n    if [ -f "$state/frame" ]; then cat "$state/frame"; exit 0; fi\n')
Path(sys.argv[2]).write_text(source+r'''
failures=0
printf 'bounded probe body\n' > "$WORK/probe-body.md"
check() { if ! "$@"; then printf 'FAIL: %s: %s\n' "$scenario" "$*"; failures=$((failures+1)); fi; }
for scenario in bare draft urgent urgent-bare queued; do
  reset_bus
  : > "$WORK/tmux/tint.log"
  rm -f "$WORK/tmux/input" "$WORK/tmux/frame"
  case "$scenario" in draft|urgent) printf 'human draft to preserve' > "$WORK/tmux/input" ;; esac
  if [ "$scenario" = queued ]; then printf '↳ queued followup\n❯ \n shift + ← edit last queued message\n' > "$WORK/tmux/frame"; fi
  flags=(); case "$scenario" in urgent|urgent-bare) flags=(--urgent) ;; esac
  bash "$TAPSH" send peer --from alice --id "$scenario" "${flags[@]}" -m 'bounded fixture notice' > "$WORK/send-$scenario.log" 2>&1
  check test ! -e "$BUS/receipts/$scenario.done"
  if [ "$scenario" = bare ] || [ "$scenario" = urgent-bare ]; then
    check test -f "$BUS/receipts/$scenario.sent"
    check test ! -e "$BUS/spool/$scenario.md"
    check test ! -s "$WORK/tmux/tint.log"
  elif [ "$scenario" = urgent ]; then
    check test -f "$BUS/receipts/$scenario.sent"
    check test ! -f "$BUS/spool/$scenario.md"
    check grep -q 'bg=red' "$WORK/tmux/tint.log"
    check grep -q 'Escape' "$WORK/tmux/send-keys.log"
    check rg -q 'human draft to preserve' "$BUS/input-backups"
    python3 - "$WORK/tmux/send-keys.log" <<'ORDER' || failures=$((failures+1))
import sys
rows=open(sys.argv[1]).read().splitlines()
import re
red=[i for i,s in enumerate(rows) if 'STYLE ' in s and 'bg=red' in s]
interrupt=[i for i,s in enumerate(rows) if 'Escape' in s.split()]
inject=[i for i,s in enumerate(rows) if re.search(r'\[\[TAP v0\.23 (ask|note) urgent( |\]\])',s)]
assert red and interrupt and inject, rows
assert red[0] < interrupt[0] < inject[0], rows
ORDER
  elif [ "$scenario" = queued ]; then
    check test "$(tap_spool_meta_field "$scenario" reason)" = queued-input
    check test ! -s "$WORK/tmux/tint.log"
    cp "$WORK/tmux/send-keys.log" "$WORK/keys-before"
    deadline="$(tap_spool_meta_field "$scenario" deadline_epoch)"
    tap_spool_drain_once "$((deadline+1))" 8 peer "$REG"
    check cmp "$WORK/keys-before" "$WORK/tmux/send-keys.log"
    check test ! -s "$WORK/tmux/tint.log"
    rm -f "$WORK/tmux/frame"
    tap_spool_drain_once "$((deadline+2))" 8 peer "$REG"
    check test -f "$BUS/receipts/$scenario.sent"
  else
    check test -f "$BUS/spool/$scenario.md"
    check test "$(tap_spool_meta_field "$scenario" reason)" = pending-input
    first="$(tap_spool_meta_field "$scenario" first_spooled_epoch)"
    deadline="$(tap_spool_meta_field "$scenario" deadline_epoch)"
    check test "$((deadline-first))" = 30
    check grep -q 'bg=green' "$WORK/tmux/tint.log"
    : > "$WORK/tmux/tint.log"
    tap_spool_drain_once "$((first+19))" 8 peer "$REG"
    check test ! -s "$WORK/tmux/tint.log"
    tap_spool_drain_once "$((first+20))" 8 peer "$REG"
    check grep -q 'bg=red' "$WORK/tmux/tint.log"
    check test ! -e "$BUS/receipts/$scenario.sent"
    check test "$(cat "$WORK/tmux/input")" = 'human draft to preserve'
  fi
done

# A watcher probe carries its configured probe_timeout on EVERY park path
# (CONTRACT.md, Probe acceptance state machine: "including visible pending
# input"). Each path supplies its own grace -- the disposition's constant for a
# draft, zero for a staged band, none at all for the clearing fence -- so this
# checks the shared parking boundary rather than one caller.
park_grace() { # <id> -> deadline - first_spooled
  local _f _d
  _f="$(tap_spool_meta_field "$1" first_spooled_epoch)"; _d="$(tap_spool_meta_field "$1" deadline_epoch)"
  [ -n "$_f" ] && [ -n "$_d" ] || { printf 'missing(first=%s deadline=%s)' "$_f" "$_d"; return 0; }
  printf '%s' "$((_d - _f))"
}
write_live_fence() { # <handle>
  python3 -B - "$BUS" "$1" <<'FENCE'
import json, os, sys, time
bus, handle = sys.argv[1], sys.argv[2]
path = os.path.join(bus, "clear-fence", handle + ".json")
os.makedirs(os.path.dirname(path), exist_ok=True)
json.dump({"nonce": "fence-nonce", "since": "2099-01-01T00:00:00Z", "since_epoch": time.time(),
           "pid": 2147483646, "handle": handle, "harness": "codex", "ceiling_seconds": 45},
          open(path, "w"))
FENCE
}
for scenario in probe-draft probe-staged probe-fence ordinary-draft ambient-draft; do
  reset_bus
  : > "$WORK/tmux/tint.log"
  rm -f "$WORK/tmux/input" "$WORK/tmux/frame"; rm -rf "$BUS/clear-fence"
  case "$scenario" in
    probe-staged) printf '↳ queued followup\n❯ \n shift + ← edit last queued message\n' > "$WORK/tmux/frame" ;;
    probe-fence)  write_live_fence peer ;;
    *)            printf 'human draft to preserve' > "$WORK/tmux/input" ;;
  esac
  case "$scenario" in
    ordinary-draft) TAP_SEND_GRACE_SECONDS=17 bash "$TAPSH" send peer --from alice --id "$scenario" \
                      -m 'bounded fixture notice' > "$WORK/send-$scenario.log" 2>&1 ;;
    ambient-draft)  SUPERVISOR_GRACE_SECONDS=7 bash "$TAPSH" send peer --from alice --id "$scenario" \
                      -m 'bounded fixture notice' > "$WORK/send-$scenario.log" 2>&1 ;;
    *)              TAP_SELF=watcher TAP_SEND_GRACE_SECONDS=17 bash "$TAPSH" send peer "$WORK/probe-body.md" \
                      --from watcher --kind probe --fyi --id "$scenario" > "$WORK/send-$scenario.log" 2>&1 ;;
  esac
  check test -f "$BUS/spool/$scenario.md"
  case "$scenario" in
    probe-draft)    check test "$(tap_spool_meta_field "$scenario" reason)" = pending-input
                    check test "$(park_grace "$scenario")" = 17 ;;
    probe-staged)   check test "$(tap_spool_meta_field "$scenario" reason)" = queued-input
                    check test "$(park_grace "$scenario")" = 17 ;;
    probe-fence)    check test "$(tap_spool_meta_field "$scenario" reason)" = clearing
                    check test "$(park_grace "$scenario")" = 17 ;;
    # The public knob is copied into the grace only for a watcher --fyi probe:
    # an ordinary sender keeps the generic draft window.
    ordinary-draft) check test "$(tap_spool_meta_field "$scenario" reason)" = pending-input
                    check test "$(park_grace "$scenario")" = 30 ;;
    # And SUPERVISOR_GRACE_SECONDS is tap-send.sh's own local, never a knob a
    # caller can set: an ambient value must not reach the park.
    ambient-draft)  check test "$(tap_spool_meta_field "$scenario" reason)" = pending-input
                    check test "$(park_grace "$scenario")" = 30 ;;
  esac
done
rm -rf "$BUS/clear-fence"

reset_bus
: > "$WORK/tmux/tint.log"
rm -f "$WORK/tmux/input" "$WORK/tmux/frame"
# The invalid decision is injected for the DELIVERY-DISPOSITION slice only. A
# plain send now consults the order-shape classifier first (tap-oglkh), and a
# blanket fake that answers every module with a disposition-shaped body makes
# THAT guard refuse first, with its own text — so this arm would fail on the
# classifier's refusal and never reach the validator it is written to test.
# Order-independent: FAKE_BIN is first on PATH, so `command -v bun` names the
# real binary only while no fake exists yet. Resolve through the runner's pin
# and refuse a fake outright, so a future fake placed earlier in this file is a
# named failure rather than a recursion into itself (opus-xhigh-2).
REAL_BUN="${TAP_SMOKE_BUN:-$(command -v bun)}"
case "$REAL_BUN" in "$FAKE_BIN"/*) echo "fixture bug: real bun resolved inside FAKE_BIN" >&2; exit 1 ;; esac
cat > "$FAKE_BIN/bun" <<BADBUN
#!/usr/bin/env bash
case "\${1:-}" in
  # Pass-throughs, not exemptions: each names a module the send path must reach
  # NORMALLY for this arm to get as far as the disposition validator it exists
  # to test. A blanket fake makes whichever guard runs first refuse with its own
  # text, and the arm then fails on the wrong refusal.
  #   order-shape.ts — the order-shape classifier (tap-oglkh)
  #   observe.ts     — seat observation, on this path since the classifier moved
  #                    out of tap_observe_seats.py and into the Bun runtime
  #   message-construction.ts — the parse/stage/obligation slice (D1, #xxxx):
  #                    every send reaches it before the disposition validator
  #   spool-state.ts — the spool listing (A1b, #xxxx): the sibling count the
  #                    disposition takes as input is read through it, and its
  #                    adapter refuses an answer without the completion marker
  *order-shape.ts|*observe.ts|*message-construction.ts|*spool-state.ts) exec "$REAL_BUN" "\$@" ;;
  *) printf '%s\\n' '{"action":"invalid"}' ;;
esac
BADBUN
chmod +x "$FAKE_BIN/bun"
scenario=optimized-invalid-action
rc=0
  # The Bash-body pin: the fake bun injects the invalid decision into the send
  # body's validator subprocess, so this arm must enter the inner tap.sh as a
  # direct caller with the internal guard — the root shim (scripts/tap.sh)
  # unsets that guard for fresh invocations, and any entry that bridges to bun
  # hands the WHOLE runtime to the fake, which would answer the entry itself
  # instead of the validator. The inner shim documents the guard as the
  # stay-on-Bash pin a direct caller may set.
  PYTHONOPTIMIZE=1 TAP_INTERNAL_OVERDUE_CHECKED=1 bash "$ROOT/skills/tap/scripts/tap.sh" send peer --from alice --id invalid-action -m 'validator control' > "$WORK/invalid.log" 2>&1 || rc=$?
check test "$rc" != 0
check grep -q 'invalid decision' "$WORK/invalid.log"
check test ! -s "$WORK/tmux/send-keys.log"
check test ! -s "$WORK/tmux/tint.log"
check test ! -e "$BUS/receipts/invalid-action.sent"
check test ! -e "$BUS/payloads/invalid-action.md"
check test ! -e "$BUS/receipts/invalid-action.placed"
rm -f "$FAKE_BIN/bun"
[ "$failures" = 0 ]
''')
PY
bash "$WORK/probe.sh"
