#!/usr/bin/env bash
# tap-3fiyo: Claude Code's desktop-backed Bash tool has no TMUX variables, its
# process ancestry ends at launchd, and its controlling tty is not the tmux pane
# tty. A background daemon's validated job owner may recover its active Claude
# row even though the daemon and interactive pane have different session ids,
# but only after that row's pane and generation are freshly verified.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"
. "$(dirname "${BASH_SOURCE[0]}")/helpers.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "${WORK:?}"' EXIT
FIXTURE="$WORK/team"
BUS="$FIXTURE/.tap/bus"
REG="$BUS/registry.json"
BIN="$WORK/bin"
JOB="$WORK/jobs/bg123456"
HISTORY="$FIXTURE/.tap/team-history"
mkdir -p "$BUS/payloads" "$BUS/receipts" "$BIN" "$JOB" "$HISTORY"
CLAUDE_STORE="$WORK/.claude/projects/${FIXTURE//\//-}"
mkdir -p "$CLAUDE_STORE"
: >"$CLAUDE_STORE/daemon-session.jsonl"

cat >"$BIN/ps" <<'PS'
#!/usr/bin/env bash
printf '1 ttys003\n'
PS
cat >"$BIN/tmux" <<'TMUX'
#!/usr/bin/env bash
selected_socket=0
if [ "${1:-}" = -S ]; then
  [ "${2:-}" = /fixture/tmux.sock ] || { printf 'wrong socket: %s\n' "${2:-}" >&2; exit 96; }
  selected_socket=1
  shift 2
fi
cmd="${1:-}"; shift || true
[ "${TMUX_MOCK_SLEEP:-0}" != 1 ] || sleep 0.2
replace_owner_if_requested() {
  [ -n "${TMUX_MOCK_REPLACE_ON_OBSERVE_FILE:-}" ] || return 0
  [ ! -e "$TMUX_MOCK_REPLACE_ON_OBSERVE_FILE" ] || return 0
  python3 -B - "${TMUX_MOCK_REGISTRY:?}" <<'PY'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
d["seats"]["fable"]["instance"] = "fable|successor"
with open(p, "w") as f:
    json.dump(d, f)
PY
  : >"$TMUX_MOCK_REPLACE_ON_OBSERVE_FILE"
}
case "$cmd" in
  list-sessions)
    if [ "${TMUX_MOCK_REQUIRE_TRANSACTION_SOCKET:-0}" = 1 ] && [ "$selected_socket" != 1 ]; then
      printf 'transaction session lookup did not preserve selected socket\n' >&2
      exit 98
    fi
    printf 'T/fable\t900:200\t1\n'
    ;;
  list-panes)
    if [ "${TMUX_MOCK_DEFAULT_UNAVAILABLE:-0}" = 1 ] && [ "$selected_socket" != 1 ]; then
      exit 1
    fi
    if [[ "$*" != *pane_tty* ]]; then printf 'T/fable\tT/fable:0.0\t%%9\tclaude\t4242\t900:200\n'
    elif [ "${TMUX_MOCK_CHANGED:-0}" = 1 ]; then printf '%%8\t/dev/ttys003\n'; else printf '%%9\t/dev/ttys004\n'; fi
    ;;
  display-message)
    if [ "${TMUX_MOCK_REQUIRE_TRANSACTION_SOCKET:-0}" = 1 ] && [ "$selected_socket" != 1 ]; then
      printf 'transaction display lookup did not preserve selected socket\n' >&2
      exit 98
    fi
    target=""; fmt=""
    while [ "$#" -gt 0 ]; do
      case "$1" in
        -p) shift ;;
        -t) target="${2:-}"; shift 2 ;;
        *) fmt="$1"; shift ;;
      esac
    done
    case "$fmt" in
      $'#{pane_id}\t#{pane_tty}\t#{session_name}\t#{pid}:#{start_time}')
        printf '%%9\t/dev/ttys004\tT/fable\t900:200\n' ;;
      $'#{pane_id}\t#{pane_tty}\t#{session_name}\t#{pid}:#{start_time}\t#{socket_path}')
        replace_owner_if_requested
        printf '%%9\t/dev/ttys004\tT/fable\t900:200\t/fixture/tmux.sock\n' ;;
      $'#{pane_id}\t#{session_name}\t#{pid}:#{start_time}')
        printf '%%9\tT/fable\t900:200\n' ;;
      $'#{pane_id}\t#{session_name}\t#{pid}:#{start_time}\t#{socket_path}')
        replace_owner_if_requested
        printf '%%9\tT/fable\t900:200\t/fixture/tmux.sock\n' ;;
      '#{socket_path}') printf '/fixture/tmux.sock\n' ;;
      '#{pid}:#{start_time}') printf '900:200\n' ;;
      '#{pane_current_command}') printf 'claude\n' ;;
      '#{pane_pid}') printf '4242\n' ;;
      '#{pane_current_path}') printf '%s\n' "${TMUX_MOCK_PANE_PATH:-/fixture}" ;;
      '#{session_name}:#{window_index}.#{pane_index}')
        if [ "${TMUX_MOCK_REQUIRE_ADDRESS_SOCKET:-0}" = 1 ] && [ "$selected_socket" != 1 ]; then
          printf 'address lookup did not preserve selected socket\n' >&2
          exit 98
        fi
        printf 'T/fable:0.0\n'
        ;;
      '#{pane_id}') printf '%%9\n' ;;
      *) printf 'tmux mock: unexpected display format %s target %s\n' "$fmt" "$target" >&2; exit 97 ;;
    esac
    ;;
  *) printf 'tmux mock: unexpected command %s\n' "$cmd" >&2; exit 97 ;;
esac
TMUX
chmod +x "$BIN/ps" "$BIN/tmux"

write_one() {
  cat >"$REG" <<JSON
{"team":{"name":"T","worktree_root":"$FIXTURE"},"seats":{"fable":{"status":"active","delivery":"pane","harness":"claude","harness_session_id":"interactive-session","instance":"fable|fixture","pane":"T/fable:0.0","pane_id":"%9","session":"T/fable","server_epoch":"srv:900:200","server_socket":"/fixture/tmux.sock"}}}
JSON
  printf '%s\n' '{"instance":"fable|fixture","ts":"2026-09-18T00:00:00Z"}' >"$HISTORY/fable.lineage.jsonl"
}
write_job() {
  cat >"$JOB/state.json" <<JSON
{"template":"bg","sessionId":"bg-session","name":"$1","cwd":"$FIXTURE","createdAt":"2026-09-18T00:00:01Z"}
JSON
}
write_one
write_job T/fable
TAP_INDEX_HOME="$WORK/index" tap_smoke_enroll_current "$FIXTURE" "$BUS" T

BASE_ENV=(env -u TMUX -u TMUX_PANE -u TAP_HARNESS_SESSION_ID
  PATH="$BIN:/usr/bin:/bin:/opt/homebrew/bin"
  HOME="$WORK" TAP_HOME="$BUS" TAP_INDEX_HOME="$WORK/index"
  TMUX_MOCK_REGISTRY="$REG"
  TMUX_MOCK_PANE_PATH="$FIXTURE"
  TMUX_MOCK_REQUIRE_TRANSACTION_SOCKET=1
  CLAUDE_CODE_SESSION_ID=bg-session CLAUDE_JOB_DIR="$JOB")
SESSION_ENV=(env -u TMUX -u TMUX_PANE -u TAP_HARNESS_SESSION_ID
  -u CLAUDE_CODE_SESSION_KIND -u CLAUDE_JOB_DIR
  PATH="$BIN:/usr/bin:/bin:/opt/homebrew/bin"
  HOME="$WORK" TAP_HOME="$BUS" TAP_INDEX_HOME="$WORK/index"
  CLAUDE_CODE_SESSION_ID=session-live)

fail() { printf 'claude-tool-caller-identity: %s\n' "$1" >&2; exit 1; }

who="$(${BASE_ENV[@]} bash "$ROOT/bin/tap" whoami 2>"$WORK/who.err")" \
  || fail "whoami refused: $(cat "$WORK/who.err")"
[ "$who" = fable ] || fail "whoami returned '$who', expected fable"
printf '  ok   native whoami binds a validated Claude background owner without TMUX\n'

private_only="$(${BASE_ENV[@]} TMUX_MOCK_DEFAULT_UNAVAILABLE=1 bash "$ROOT/bin/tap" whoami 2>"$WORK/private-only.err")" \
  || fail "whoami required an unrelated default tmux server: $(cat "$WORK/private-only.err")"
[ "$private_only" = fable ] || fail "private-socket whoami returned '$private_only', expected fable"
printf '  ok   background recovery proves outside against the selected private socket when default tmux is absent\n'

bash_seen="$(${BASE_ENV[@]} TAP_REGISTRY="$REG" bash -c '. "$1"; tap_caller_pane_id' _ \
  "$ROOT/skills/tap/scripts/lib.sh")" || fail "Bash caller resolver refused"
[ "$bash_seen" = %9 ] || fail "Bash caller resolver returned '$bash_seen', expected %9"
printf '  ok   Bash registration/self resolver returns the verified pane id\n'

bash_private="$(${BASE_ENV[@]} TMUX_MOCK_DEFAULT_UNAVAILABLE=1 TAP_REGISTRY="$REG" bash -c '. "$1"; tap_caller_pane_id' _ \
  "$ROOT/skills/tap/scripts/lib.sh")" || fail "Bash resolver required an unrelated default tmux server"
[ "$bash_private" = %9 ] || fail "Bash private-socket resolver returned '$bash_private', expected %9"
printf '  ok   Bash background recovery uses the selected private socket for outside evidence\n'

pinned="$(${BASE_ENV[@]} TAP_REGISTRY="$REG" TMUX_MOCK_REQUIRE_ADDRESS_SOCKET=1 bash -c \
  '. "$1"; tap_caller_pane_id pane; tap_pin_selected_tmux_socket; tmux display-message -p -t "$pane" "#{session_name}:#{window_index}.#{pane_index}"' _ \
  "$ROOT/skills/tap/scripts/lib.sh")" || fail "selected socket was not preserved downstream"
[ "$pinned" = T/fable:0.0 ] || fail "pinned address lookup returned '$pinned'"
printf '  ok   downstream tmux calls stay on the selected row\x27s socket\n'

set +e
deadline_output="$(${BASE_ENV[@]} TMUX_MOCK_SLEEP=1 TAP_TMUX_TIMEOUT_SECONDS=0.01 bash -c \
  '. "$1"; TAP_CALLER_SELECTED_SOCKET=/fixture/tmux.sock; tap_pin_selected_tmux_socket; tmux display-message -p "#{socket_path}"' _ \
  "$ROOT/skills/tap/scripts/lib.sh" 2>&1)"
deadline_rc=$?
set -e
[ "$deadline_rc" = 124 ] || fail "pinned socket bypassed the bounded tmux client: rc=$deadline_rc out=$deadline_output"
grep -Fq 'tmux client deadline expired' <<<"$deadline_output" \
  || fail "pinned socket timeout lacked the bounded-client diagnostic: $deadline_output"
printf '  ok   selected-socket routing retains the bounded tmux client\n'

python_deadline_output="$(${BASE_ENV[@]} TMUX_MOCK_SLEEP=1 TAP_TMUX_TIMEOUT_SECONDS=0.01 \
  TAP_TMUX_SOCKET_PATH=/fixture/tmux.sock python3 -B - "$ROOT/skills/tap/scripts/session" <<'PY'
import subprocess, sys
sys.path.insert(0, sys.argv[1])
import seat_corpse
result = subprocess.run(
    seat_corpse.tmux_command("display-message", "-p", "#{socket_path}"),
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
)
print(result.returncode)
print(result.stderr, end="")
PY
)"
grep -qx '124' <<<"$(printf '%s\n' "$python_deadline_output" | head -1)" \
  || fail "Python transaction probe bypassed the bounded tmux client: $python_deadline_output"
grep -Fq 'tmux client deadline expired' <<<"$python_deadline_output" \
  || fail "Python transaction timeout lacked the bounded-client diagnostic: $python_deadline_output"
printf '  ok   Python transaction probes retain the bounded tmux client\n'

# Socket provenance was added after the registry row existed. Legacy rows stay
# readable: observe them through the incumbent default tmux namespace, without
# inventing a socket claim to pin downstream.
python3 -B - "$REG" <<'PY'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
d["seats"]["fable"].pop("server_socket", None)
with open(p, "w") as f:
    json.dump(d, f)
PY
legacy_socketless="$(${BASE_ENV[@]} TMUX_MOCK_REQUIRE_TRANSACTION_SOCKET=0 bash "$ROOT/bin/tap" whoami 2>"$WORK/socketless.err")" \
  || fail "socketless legacy row was not readable: $(cat "$WORK/socketless.err")"
[ "$legacy_socketless" = fable ] || fail "socketless legacy row returned '$legacy_socketless'"
printf '  ok   socketless legacy rows remain readable through the default tmux namespace\n'
write_one

set +e
in_output="$(${BASE_ENV[@]} TAP_VERBOSE=1 bash "$ROOT/bin/tap" in 2>&1)"
in_rc=$?
set -e
[ "$in_rc" = 0 ] || fail "implicit tap in from the background job failed: $in_output"
hook="$(${BASE_ENV[@]} bash "$ROOT/hooks/tap-session-context.sh" "$FIXTURE" \
  <<<'{"hook_event_name":"SessionStart","source":"startup"}')"
grep -Fq 'TAP: registered as fable on team T.' <<<"$hook" \
  || fail "SessionStart did not recognize the registered seat: $hook"
python3 -B - "$REG" <<'PY' || fail "SessionStart did not preserve the interactive owner identity"
import json, sys
row = json.load(open(sys.argv[1]))["seats"]["fable"]
assert row.get("harness_session_id") == "interactive-session", row
for key in ("derived_harness_session_id", "session_store_path", "session_store_kind"):
    assert key not in row, row
PY
printf '  ok   implicit tap in re-registers the owner without scanning daemon session metadata\n'

cat >"$REG" <<JSON
{"team":{"name":"T","worktree_root":"$FIXTURE"},"seats":{"aaa":{"status":"active","delivery":"pane","harness":"claude","harness_session_id":"other-session","pane":"T/fable:0.0","pane_id":"%9","session":"T/fable","server_epoch":"srv:900:200","server_socket":"/fixture/tmux.sock"},"fable":{"status":"active","delivery":"pane","harness":"claude","harness_session_id":"interactive-session","instance":"fable|fixture","pane":"T/fable:0.0","pane_id":"%9","session":"T/fable","server_epoch":"srv:900:200","server_socket":"/fixture/tmux.sock"}}}
JSON
who="$(${BASE_ENV[@]} bash "$ROOT/bin/tap" whoami 2>"$WORK/selected.err")" \
  || fail "selected-handle whoami refused: $(cat "$WORK/selected.err")"
[ "$who" = fable ] || fail "job selected fable but generic pane order returned '$who'"
printf '  ok   verified Claude context preserves its selected handle\n'

python3 -B - "$REG" <<'PY'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
d["seats"]["fable"]["instance"] = "fable|successor"
with open(p, "w") as f:
    json.dump(d, f)
PY
printf '%s\n' '{"instance":"fable|successor","ts":"2026-09-18T00:00:02Z"}' >>"$HISTORY/fable.lineage.jsonl"
set +e
successor="$(${BASE_ENV[@]} bash "$ROOT/bin/tap" whoami 2>&1)"
successor_rc=$?
set -e
[ "$successor_rc" -ne 0 ] && grep -Fq 'caller pane is not observable' <<<"$successor" \
  || fail "stale background job followed a replacement seat: rc=$successor_rc out=$successor"
printf '  ok   background jobs refuse after the named seat instance is replaced\n'
write_one

python3 -B - "$REG" <<'PY'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
d["seats"]["fable"]["instance"] = "fable|same-second-successor"
with open(p, "w") as f:
    json.dump(d, f)
PY
printf '%s\n' '{"instance":"fable|same-second-successor","ts":"2026-09-18T00:00:01Z"}' >>"$HISTORY/fable.lineage.jsonl"
set +e
same_second="$(${BASE_ENV[@]} bash "$ROOT/bin/tap" whoami 2>&1)"
same_second_rc=$?
set -e
[ "$same_second_rc" -ne 0 ] && grep -Fq 'caller pane is not observable' <<<"$same_second" \
  || fail "coarse same-second successor was treated as creation-time history: rc=$same_second_rc out=$same_second"
printf '  ok   whole-second lineage refuses creation-second ordering ambiguity\n'
write_one

RACE_WHO_FLAG="$WORK/replace-on-observe-who"
set +e
race_who="$(${BASE_ENV[@]} TMUX_MOCK_REPLACE_ON_OBSERVE_FILE="$RACE_WHO_FLAG" \
  bash "$ROOT/bin/tap" whoami 2>&1)"
race_who_rc=$?
set -e
[ "$race_who_rc" -ne 0 ] && grep -Eq 'caller pane is not observable|pane %9 is not registered' <<<"$race_who" \
  || fail "whoami followed a same-pane successor after validation: rc=$race_who_rc out=$race_who"
printf '  ok   whoami rechecks the selected instance at the final registry read\n'

write_one
RACE_IN_FLAG="$WORK/replace-on-observe-in"
set +e
race_in="$(${BASE_ENV[@]} TMUX_MOCK_REPLACE_ON_OBSERVE_FILE="$RACE_IN_FLAG" \
  bash "$ROOT/bin/tap" in 2>&1)"
race_in_rc=$?
set -e
[ "$race_in_rc" -ne 0 ] && grep -Fq 'owner instance changed' <<<"$race_in" \
  || fail "tap in followed a same-pane successor into the locked write: rc=$race_in_rc out=$race_in"
printf '  ok   tap in rechecks the selected instance under the registry lock\n'

write_one
RACE_EFFECT_FLAG="$WORK/replace-on-observe-effect"
set +e
${BASE_ENV[@]} TMUX_MOCK_REPLACE_ON_OBSERVE_FILE="$RACE_EFFECT_FLAG" TAP_REGISTRY="$REG" bash -c \
  '. "$1"; tap_caller_pane_id pane; tap_revalidate_selected_instance' _ \
  "$ROOT/skills/tap/scripts/lib.sh" >/dev/null 2>"$WORK/race-effect.err"
race_effect_rc=$?
set -e
[ "$race_effect_rc" -ne 0 ] \
  || fail "Bash pane-effect boundary accepted a replacement seat instance"
printf '  ok   Bash pane effects recheck the selected instance before acting\n'
write_one

cat >"$REG" <<JSON
{"team":{"name":"stale","worktree_root":"$WORK/stale-root"},"seats":{"fable":{"status":"active","delivery":"pane","harness":"claude","harness_session_id":"interactive-session","instance":"fable|fixture","pane":"T/fable:0.0","pane_id":"%9","session":"T/fable","server_epoch":"srv:900:200","server_socket":"/fixture/tmux.sock"}}}
JSON
set +e
authoritative="$(${BASE_ENV[@]} TAP_REGISTRY="$REG" bash -c \
  '. "$1"; authoritative_root="$2"; tap_require_acting_registry() { return 0; }; tap_spool_team_name() { printf T; }; tap_team_dir_from_bus() { printf "%s" "$authoritative_root"; }; tap_caller_pane_id' _ \
  "$ROOT/skills/tap/scripts/lib.sh" "$FIXTURE" 2>"$WORK/authoritative.err")"
authoritative_rc=$?
set -e
[ "$authoritative_rc" = 0 ] || fail "authoritative acting metadata did not override stale embedded metadata: $(tail -40 "$WORK/authoritative.err")"
[ "$authoritative" = %9 ] || fail "authoritative acting metadata returned '$authoritative'"
printf '  ok   job ownership uses selector-derived acting team and root\n'

write_one
set +e
TMUX_MOCK_CHANGED=1 ${BASE_ENV[@]} TAP_REGISTRY="$REG" bash -c '. "$1"; tap_caller_pane_id' _ \
  "$ROOT/skills/tap/scripts/lib.sh" >/dev/null 2>"$WORK/changed.err"
changed_rc=$?
set -e
[ "$changed_rc" -ne 0 ] || fail "observed-but-changed pane fell through to the background owner"
printf '  ok   observed-pane failures do not switch to a registry-selected pane\n'

set +e
${BASE_ENV[@]} TAP_REGISTRY="$REG" bash -c '. "$1"; tap_resolve_self_handle' _ \
  "$ROOT/skills/tap/scripts/lib.sh" >/dev/null 2>"$WORK/actor.err"
actor_rc=$?
set -e
[ "$actor_rc" -ne 0 ] || fail "shared actor resolver accepted background job identity"
printf '  ok   shared transport actor resolution remains process-owned\n'

cat >"$REG" <<JSON
{"team":{"name":"T","worktree_root":"$FIXTURE"},"seats":{"fable":{"status":"active","delivery":"pane","harness":"claude","harness_session_id":"session-live","pane":"T/fable:0.0","pane_id":"%9","session":"T/fable","server_epoch":"srv:900:200","server_socket":"/fixture/tmux.sock"},"copy":{"status":"active","delivery":"pane","harness":"claude","harness_session_id":"session-live","pane":"T/copy:0.0","pane_id":"%10","session":"T/copy","server_epoch":"srv:900:200","server_socket":"/fixture/tmux.sock"}}}
JSON
set +e
duplicate="$(${SESSION_ENV[@]} bash "$ROOT/bin/tap" whoami 2>&1)"
duplicate_rc=$?
set -e
[ "$duplicate_rc" -ne 0 ] && grep -Fq 'caller pane is not observable' <<<"$duplicate" \
  || fail "duplicate session id was not refused: rc=$duplicate_rc out=$duplicate"
printf '  ok   duplicate native session ids refuse instead of choosing a row\n'

cat >"$REG" <<JSON
{"team":{"name":"T","worktree_root":"$FIXTURE"},"seats":{"fable":{"status":"active","delivery":"pane","harness":"claude","harness_session_id":"interactive-session","pane":"T/fable:0.0","pane_id":"%9","session":"T/fable"}}}
JSON
set +e
incomplete="$(${BASE_ENV[@]} bash "$ROOT/bin/tap" whoami 2>&1)"
incomplete_rc=$?
set -e
[ "$incomplete_rc" -ne 0 ] && grep -Fq 'caller pane is not observable' <<<"$incomplete" \
  || fail "row without a stored server generation was accepted: rc=$incomplete_rc out=$incomplete"
printf '  ok   incomplete registry identity cannot authorize the fallback\n'

write_one
python3 -B - "$REG" <<'PY'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
d["seats"]["fable"]["server_socket"] = "/fixture/wrong.sock"
with open(p, "w") as f:
    json.dump(d, f)
PY
set +e
wrong_socket="$(${BASE_ENV[@]} bash "$ROOT/bin/tap" whoami 2>&1)"
wrong_socket_rc=$?
set -e
[ "$wrong_socket_rc" -ne 0 ] \
  || fail "stored socket mismatch was accepted: rc=$wrong_socket_rc out=$wrong_socket"
printf '  ok   fallback observes only the registry row\x27s recorded tmux socket\n'

cat >"$REG" <<JSON
{"team":{"name":"T","worktree_root":"$FIXTURE"},"seats":{"fable":{"status":"active","delivery":"pane","harness":"claude","harness_session_id":"bg-session","pane":"T/fable:0.0","pane_id":"%9","session":"T/fable","server_epoch":"srv:900:200","server_socket":"/fixture/tmux.sock"}}}
JSON
write_job T/missing
unseen="$(${BASE_ENV[@]} bash "$ROOT/hooks/tap-session-context.sh" "$FIXTURE" \
  <<<'{"hook_event_name":"SessionStart","source":"startup"}')"
grep -Fq 'caller pane is not observable' <<<"$unseen" \
  || fail "SessionStart collapsed an unobservable caller into unregistered: $unseen"
printf '  ok   SessionStart distinguishes caller-unobservable from unregistered\n'

grep -Fq 'observeCallingPane(env)' "$ROOT/runtime/bun/src/verbs/register.ts" \
  || fail "tap in is not wired to the identity-aware caller resolver"
grep -Fq 'env.TAP_TMUX_SOCKET_PATH = selected.selectedSocket' "$ROOT/runtime/bun/src/verbs/register.ts" \
  || fail "tap in does not preserve the verified tmux socket"
grep -Fq 'const suppressCapture = env.TAP_REGISTER_SUPPRESS_IDENTITY_CAPTURE === "1" || env.TAP_CALLER_SELECTED_JOB === "1";' \
  "$ROOT/runtime/bun/src/verbs/register.ts" \
  || fail "tap in can stamp a background daemon identity onto its owner pane"
grep -Fq 'env.TAP_CALLER_SELECTED_JOB = "1"' "$ROOT/runtime/bun/src/verbs/register.ts" \
  && grep -Fq 'env.TAP_REGISTER_SUPPRESS_IDENTITY_CAPTURE = "1";' "$ROOT/runtime/bun/src/verbs/register.ts" \
  || fail "tap in does not clear background-daemon identity before re-registering the owner"
grep -Fq 'tap_caller_pane_id _SELF_CALLER_PANE' "$ROOT/skills/self/scripts/self.sh" \
  || fail "self.sh is not wired to the identity-aware caller resolver"
grep -Fq 'tap_pin_selected_tmux_socket' "$ROOT/skills/self/scripts/self.sh" \
  || fail "self.sh does not preserve the verified tmux socket"
grep -Fq '_require_selected_owner' "$ROOT/skills/self/scripts/self.sh" \
  || fail "self.sh does not recheck the verified seat instance at pane-effect boundaries"
grep -Fq '"$TAP_SUBMIT_OWNER_HANDLE" "$TAP_SUBMIT_OWNER_INSTANCE" "$_OWNER_REGISTRY" "$TAP_SUBMIT_OWNER_PANE"' \
  "$ROOT/skills/self/scripts/self.sh" \
  || fail "self.sh does not pass the owner and pane-binding witness into the detached compact submitter"
printf '  ok   tap in and self.sh share the verified Bash resolver\n'

printf 'claude-tool-caller-identity: ok\n'
