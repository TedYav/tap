#!/usr/bin/env bash
# Keep Git fixtures, PATH and exports inside the runner.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "do not source" >&2; return 1 2>/dev/null || exit 1
fi
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
PRIMARY="$WORK/primary"; SIBLING="$WORK/sibling"
mkdir -p "$PRIMARY/.beads" "$WORK/bin"
git -C "$PRIMARY" init -q -b main
git -C "$PRIMARY" -c core.hooksPath=/dev/null -c user.name=fixture -c user.email=dev@example.invalid commit -q --allow-empty -m base
git -C "$PRIMARY" -c core.hooksPath=/dev/null worktree add -q -b sibling "$SIBLING"
# Real bd0.55.4 was observed exporting PRIMARY from a sibling pre-commit. Keep
# that effect deterministic here; no external database is needed by this gate.
export PRIMARY
cat > "$WORK/bin/bd" <<'BD'
#!/usr/bin/env sh
printf 'export\n' >> "$PRIMARY/calls"
[ "$*" = 'hook pre-commit' ] || exit 91
cp "$PRIMARY/database" "$PRIMARY/.beads/issues.jsonl"
BD
chmod +x "$WORK/bin/bd"
export PATH="$WORK/bin:$PATH"
HOOK="$ROOT/.beads/hooks/pre-commit"
printf 'old export\n' > "$PRIMARY/.beads/issues.jsonl"
printf 'pending database update\n' > "$PRIMARY/database"
for marker in rebase-merge rebase-apply; do
  mkdir "$PRIMARY/.git/$marker"
  for caller in "$PRIMARY" "$SIBLING"; do
    (cd "$caller" && sh "$HOOK")
    (cd "$caller" && sh "$ROOT/.beads/hooks/post-checkout" 0 0 1)
    [ ! -e "$PRIMARY/calls" ] || { echo "export ran during primary $marker" >&2; exit 1; }
    [ "$(cat "$PRIMARY/.beads/issues.jsonl")" = 'old export' ] || exit 1
  done
  rmdir "$PRIMARY/.git/$marker"
done
# A linked checkout's own intermediate JSONL is equally unsuitable for import.
sibling_git="$(git -C "$SIBLING" rev-parse --absolute-git-dir)"
for marker in rebase-merge rebase-apply; do
  mkdir "$sibling_git/$marker"
  (cd "$SIBLING" && sh "$ROOT/.beads/hooks/post-checkout" 0 0 1)
  [ ! -e "$PRIMARY/calls" ] || exit 1
  rmdir "$sibling_git/$marker"
done
# The next normal hook exports all pending DB bytes, not the older branch copy.
(cd "$SIBLING" && sh "$HOOK")
cmp "$PRIMARY/database" "$PRIMARY/.beads/issues.jsonl"
[ "$(wc -l < "$PRIMARY/calls" | tr -d ' ')" = 1 ] || exit 1
# A sibling's own rebase is not a primary replay; do not disable ordinary exports.
mkdir "$sibling_git/rebase-merge"
printf 'newer database update\n' > "$PRIMARY/database"
(cd "$SIBLING" && sh "$HOOK")
rmdir "$sibling_git/rebase-merge"
cmp "$PRIMARY/database" "$PRIMARY/.beads/issues.jsonl"
[ "$(wc -l < "$PRIMARY/calls" | tr -d ' ')" = 2 ] || exit 1
echo 'beads-rebase-export: primary and linked callers defer; next ordinary export retains DB bytes'

# Exhausted Dolt retries report the process opening the PRIMARY lock file even from a linked tree.
cat > "$WORK/bin/bd" <<'BD'
#!/usr/bin/env sh
printf 'retry\n' >> "$PRIMARY/retries"
echo '[signal SIGSEGV: segmentation violation]' >&2
echo 'doltdb.(*DoltDB).SetCrashOnFatalError' >&2
exit 2
BD
cat > "$WORK/bin/lsof" <<'LSOF'
#!/usr/bin/env sh
printf '%s\n' "$*" > "$PRIMARY/lsof-args"
printf '12345\n'
LSOF
cat > "$WORK/bin/ps" <<'PS'
#!/usr/bin/env sh
[ "$*" = '-p 12345 -o pid= -o ppid= -o etime= -o command=' ] || exit 93
printf '12345 11111 06:12 bd ready -n 3 --json\n'
PS
chmod +x "$WORK/bin/lsof" "$WORK/bin/ps"
rc=0
(cd "$SIBLING" && sh "$HOOK") >"$WORK/failure" 2>&1 || rc=$?
[ "$rc" = 1 ] || { cat "$WORK/failure"; exit 1; }
[ "$(wc -l < "$PRIMARY/retries" | tr -d ' ')" = 3 ] || exit 1
grep -Fq '12345 11111 06:12 bd ready -n 3 --json' "$WORK/failure" || { cat "$WORK/failure"; exit 1; }
[ "$(cat "$PRIMARY/lsof-args")" = "-t $(cd "$PRIMARY" && pwd -P)/.beads/dolt-access.lock" ] || { cat "$PRIMARY/lsof-args"; exit 1; }
echo 'beads retry exhaustion: primary lock-file opener identified from linked checkout'
