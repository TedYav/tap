#!/usr/bin/env python3
"""v0.20 cutover: tap admin migrate-registry --yes (U6/U7).

Operator-only big-bang: inventory + backup copies first, seats-first team
registries with U7-minted row-incarnation ids, one-file launcher-manifest
archive, global-registry.json schema 0.20 written LAST. Resume from
backup/0.20-migration/inventory.json. Never invokes legacy team down.

tap-lemb resume-path TRACE: this module never calls tap-admin's
`_admin_set_bus_for_root` and never reads ambient TAP_REGISTRY. Buses and
team registries are resolved via registry_v20.bus_home / team_registry_path.
Interrupted resume therefore cannot silently skip registry reads after the
bus file is dual-written or retired mid-run — there is no setter dependence.
"""
from __future__ import annotations

import argparse
import datetime
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any, Mapping, MutableMapping, Optional

import registry_v20

LAUNCH_FIELDS = ("model", "base", "tag", "teams", "passthrough", "harness_session_id", "transcript_path")


class MigrateError(Exception):
    def __init__(self, klass: str, detail: str, action: str = "tap help admin"):
        self.klass = klass
        self.detail = detail
        self.action = action
        super().__init__(detail)


def _index_home() -> str:
    return os.environ.get("TAP_INDEX_HOME") or os.path.expanduser("~/.tap")


def _home() -> str:
    return os.environ.get("HOME") or os.path.expanduser("~")


def _utc() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _branch_at_bootstrap(root: str) -> str:
    """Match the incumbent shell derivation exactly, including failure corners."""
    try:
        result = subprocess.run(
            ["git", "-C", root, "symbolic-ref", "--quiet", "--short", "HEAD"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            check=False,
        )
    except OSError:
        return "unknown"
    return result.stdout.rstrip("\n") if result.returncode == 0 else "unknown"


def _load_json(path: str) -> Any:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _atomic_write(path: str, data: Mapping[str, Any]) -> None:
    registry_v20.save_state_doc(path, data)


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _backup_candidates() -> list[str]:
    """Ordered backup dirs. Specimen plants inventory at $HOME/backup/0.20-migration."""
    home = _home()
    return [
        os.path.join(home, "backup", "0.20-migration"),
        os.path.join(home, ".tap", "backup", "0.20-migration"),
        os.path.join(_index_home(), "backup", "0.20-migration"),
    ]


def _resolve_backup() -> tuple[str, str, bool]:
    """Return (backup_dir, inventory_path, resuming)."""
    cands = _backup_candidates()
    for d in cands:
        inv = os.path.join(d, "inventory.json")
        if os.path.isfile(inv):
            return d, inv, True
    # Fresh migrate: prefer $HOME/.tap/backup (operator layout); specimen
    # still gets a mirror under $HOME/backup via _mirror_backup.
    primary = os.path.join(_home(), ".tap", "backup", "0.20-migration")
    return primary, os.path.join(primary, "inventory.json"), False


def _teams_index_path() -> str:
    return os.path.join(_index_home(), "teams.json")


def _enrolled_teams() -> list[tuple[str, str]]:
    """Return every teams.json enrollment with a non-empty root.

    Reachability is NOT filtered here (KTD-14 / tap-5y6p): a vanished root is
    observed evidence. Pre-flip migrate refuses unreachable enrolled roots
    before publishing the flip marker; silent drop would stamp a reduced
    global-registry and leave the team unrecovered when the root returns.

    WAVE 6.11 / 3682836485: the entire ``teams`` map is validated before any
    migrate write. A non-object entry or missing/empty root REFUSES — never
    silently skips — so migrate cannot publish a reduced schema-0.20 marker.
    """
    idx = _teams_index_path()
    if not os.path.isfile(idx):
        return []
    try:
        data = _load_json(idx)
    except Exception:
        return []
    teams = data.get("teams") or {}
    out: list[tuple[str, str]] = []
    if not isinstance(teams, dict):
        raise MigrateError(
            "malformed_teams_index",
            "teams.json 'teams' is not an object — refusing migrate",
            "repair teams.json so every enrollment is an object with a root, then re-run migrate",
        )
    for name, ent in teams.items():
        if not isinstance(ent, dict):
            raise MigrateError(
                "malformed_teams_index",
                f"teams.json entry '{name}' is not an object — refusing migrate "
                "(would publish a reduced global-registry)",
                "repair or remove the malformed enrollment, then re-run migrate",
            )
        root = ent.get("root") or ""
        if not isinstance(root, str) or not str(root).strip():
            raise MigrateError(
                "malformed_teams_index",
                f"teams.json entry '{name}' has missing/invalid root — refusing migrate "
                "(would publish a reduced global-registry)",
                "repair or remove the malformed enrollment, then re-run migrate",
            )
        root = str(root)
        # Preserve the indexed path string for refuse diagnostics; realpath
        # only when the root exists so vanished paths stay nameable.
        if os.path.isdir(root):
            out.append((str(name), os.path.realpath(root)))
        else:
            out.append((str(name), root))
    return out


def _unreachable_enrolled(teams: list[tuple[str, str]]) -> list[tuple[str, str]]:
    return [(name, root) for name, root in teams if not os.path.isdir(root)]


def _bus_for_root(root: str) -> Optional[str]:
    return registry_v20.bus_home(root) if root else None


def _count_unsettled(bus: str) -> list[str]:
    """Unsettled canonical payloads AND parked spool entries (WAVE 6.5 / 3682216622).

    Parked spool retains pre-flip ``target_registry``; CONTRACT requires ALL
    unsettled traffic settled or cancelled before cutover. A bus with spool
    traffic and no payloads/ directory must still refuse.
    """
    receipts = os.path.join(bus, "receipts")
    unsettled: list[str] = []
    payloads = os.path.join(bus, "payloads")
    if os.path.isdir(payloads):
        for name in os.listdir(payloads):
            if not name.endswith(".md"):
                continue
            pid = name[:-3]
            if os.path.isfile(os.path.join(receipts, f"{pid}.done")):
                continue
            if os.path.isfile(os.path.join(receipts, f"{pid}.cancelled")):
                continue
            unsettled.append(pid)
    spool = os.path.join(bus, "spool")
    if os.path.isdir(spool):
        for name in os.listdir(spool):
            if not name.endswith(".md"):
                continue
            pid = name[:-3]
            # Parked entries are unsettled until withdrawn/redelivered; they do
            # not use .done on the spool path.
            if pid not in unsettled:
                unsettled.append(pid)
    return unsettled


def _manifest_path() -> str:
    env = os.environ.get("TAP_SESSION_MANIFEST")
    if env:
        return os.path.expanduser(env)
    return os.path.join(_home(), ".tap", "launcher", "sessions.json")


def _manifest_sessions(manifest_path: str) -> list[dict[str, Any]]:
    """Load launcher sessions for migrate fold. Absent file → empty cohort.

    WAVE 6.5 / 3682162328: malformed JSON or a non-list ``sessions`` value
    MUST refuse (not collapse to []) — otherwise the flip marker can publish
    without the ratified launch-config fold.
    """
    if not os.path.isfile(manifest_path):
        return []
    try:
        doc = _load_json(manifest_path)
    except Exception as exc:
        raise MigrateError(
            "manifest_invalid",
            f"launcher sessions.json is malformed or unreadable ({exc})",
            "repair TAP_SESSION_MANIFEST / ~/.tap/launcher/sessions.json, then re-run migrate",
        ) from exc
    if not isinstance(doc, dict):
        raise MigrateError(
            "manifest_invalid",
            "launcher sessions.json root must be a JSON object",
            "repair TAP_SESSION_MANIFEST / ~/.tap/launcher/sessions.json, then re-run migrate",
        )
    rows = doc.get("sessions")
    if rows is None:
        return []
    if not isinstance(rows, list):
        raise MigrateError(
            "manifest_invalid",
            "launcher sessions.json 'sessions' must be a JSON array",
            "repair TAP_SESSION_MANIFEST / ~/.tap/launcher/sessions.json, then re-run migrate",
        )
    return [r for r in rows if isinstance(r, dict)]


def _cwd_under_team_root(cwd: str, team_root: str) -> bool:
    """True when cwd is the team root or nested under it (3681979283).

    Same polarity as launcher ``path_is_under`` — exact cwd equality silently
    dropped nested-subdirectory launch records during config fold.
    """
    try:
        c = os.path.realpath(cwd)
        r = os.path.realpath(team_root)
    except OSError:
        return False
    if c == r:
        return True
    prefix = r if r.endswith(os.sep) else r + os.sep
    return c.startswith(prefix)


def _join_config(
    team_root: str,
    handle: str,
    sessions: list[dict[str, Any]],
) -> tuple[Optional[dict[str, Any]], Optional[str]]:
    """(team root, handle) join via path_is_under. Returns (fields, error_detail)."""
    matches: list[dict[str, Any]] = []
    for rec in sessions:
        cwd = rec.get("cwd") or ""
        handle_field = rec.get("handle") or rec.get("tag") or ""
        name = str(rec.get("name") or "")
        if handle_field != handle and not name.endswith("/" + handle):
            continue
        if not cwd:
            continue
        if not _cwd_under_team_root(str(cwd), team_root):
            continue
        matches.append(rec)
    if len(matches) > 1:
        names = [str(m.get("name") or m.get("tag") or "?") for m in matches]
        return None, (
            f"ambiguous config join for handle '{handle}': candidates {names} "
            f"(alice-dup / refuse)"
        )
    if not matches:
        return {}, None
    rec = matches[0]
    fields = {k: rec[k] for k in LAUNCH_FIELDS if k in rec and rec[k] not in (None, "")}
    return fields, None


def _fold_seat(
    handle: str,
    entry: MutableMapping[str, Any],
    team_root: str,
    sessions: list[dict[str, Any]],
) -> MutableMapping[str, Any]:
    seat = dict(entry)
    # Preserve existing instance; mint if absent (U7).
    registry_v20.ensure_seat_instance(seat, handle)
    delivery = seat.get("delivery") or "pane"
    is_crew = seat.get("crew") is True or seat.get("crew") == 1
    cfg, err = _join_config(team_root, handle, sessions)
    if err:
        raise MigrateError("ambiguous_join", err, "fix launcher duplicate records then re-run migrate")
    if not cfg or delivery == "poll" or is_crew:
        # Poll/crew: never import session lineage from the manifest.
        return seat
    for k in ("model", "base", "tag", "teams", "passthrough"):
        if k in cfg:
            seat[k] = cfg[k]
    for k in ("harness_session_id", "transcript_path"):
        if k in cfg and not seat.get(k):
            seat[k] = cfg[k]
    # Load-bearing for post-flip resume synthesize (WAVE 5 fold-in): carry the
    # exact manifest session name when the bus row never recorded one.
    if not (isinstance(seat.get("session"), str) and seat.get("session")):
        for rec in sessions:
            name = str(rec.get("name") or "")
            handle_field = rec.get("handle") or rec.get("tag") or ""
            if handle_field == handle or name.endswith("/" + handle):
                if _cwd_under_team_root(str(rec.get("cwd") or ""), team_root) and name:
                    seat["session"] = name
                    break
    return seat


def _ensure_migration_lineage(root: str, handle: str, seat: Mapping[str, Any]) -> None:
    """Give a migrated incumbent a creation-time instance witness once."""
    instance = seat.get("instance")
    if not isinstance(instance, str) or not instance:
        return
    registered_at = seat.get("registered_at")
    if not isinstance(registered_at, str) or not registered_at:
        return
    try:
        stamp = datetime.datetime.fromisoformat(registered_at.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            return
    except ValueError:
        return
    history_dir = registry_v20.team_history_dir(root)
    path = os.path.join(history_dir, f"{handle}.lineage.jsonl")
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                try:
                    record = json.loads(line)
                    # A later same-instance rebind does not prove the instance
                    # existed when a pre-migration job was created. Only an
                    # explicit creation/continuity witness can suppress the
                    # epoch seed; unknown legacy notes are not temporal proof.
                    if (
                        record.get("instance") == instance
                        and record.get("note") in {"migration", "fresh", "restore"}
                    ):
                        return
                except Exception:
                    continue
    except FileNotFoundError:
        pass
    registry_v20.append_pane_session_log(
        history_dir,
        handle,
        instance,
        pane=str(seat.get("pane") or ""),
        pane_id=str(seat.get("pane_id") or ""),
        harness_session_id=str(seat.get("harness_session_id") or ""),
        note="migration",
        # `registered_at` is the earliest point this migration can prove the
        # current occupant was present. Backdating to the epoch lets an older
        # occupant's retained job claim a successor that happened to be in the
        # row at cutover. Jobs older than this witness therefore refuse.
        timestamp=registered_at,
    )


def _live_team_registries() -> list[tuple[str, str, str]]:
    """Return reachable acting registries from the live global authority."""
    try:
        doc = _load_json(registry_v20.global_registry_path(_index_home()))
    except Exception:
        return []
    teams = doc.get("teams") if isinstance(doc, dict) else None
    if not isinstance(teams, dict):
        return []
    out: list[tuple[str, str, str]] = []
    for name, entry in teams.items():
        if not isinstance(entry, dict) or entry.get("state") == "historical":
            continue
        root = entry.get("root")
        registry = entry.get("registry_location")
        if (
            isinstance(root, str)
            and root
            and isinstance(registry, str)
            and registry
            and os.path.isdir(root)
            and os.path.isfile(registry)
        ):
            out.append((str(name), os.path.realpath(root), registry))
    return out


def _backfill_live_migration_lineage(root: str, registry: str) -> None:
    """Idempotently repair migration lineage for one live acting registry."""
    doc = _load_json(registry)
    for handle, seat in registry_v20._seat_map(doc).items():
        if isinstance(seat, dict):
            _ensure_migration_lineage(root, handle, seat)


def _copy_file(src: str, dest: str) -> None:
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    try:
        if os.path.exists(dest) and os.path.samefile(src, dest):
            return
    except OSError:
        pass
    if os.path.abspath(src) == os.path.abspath(dest):
        return
    shutil.copy2(src, dest)


def _mirror_backup(backup: str, basename: str) -> None:
    """Keep specimen-visible $HOME/backup mirror when primary is elsewhere."""
    src = os.path.join(backup, basename)
    if not os.path.isfile(src):
        return
    for d in _backup_candidates():
        if os.path.abspath(d) == os.path.abspath(backup):
            continue
        dest = os.path.join(d, basename)
        try:
            if os.path.exists(dest) and os.path.samefile(src, dest):
                continue
        except OSError:
            pass
        _copy_file(src, dest)


def migrate(yes: bool = False) -> int:
    if not yes:
        raise MigrateError(
            "confirmation_required",
            "refusing migrate-registry without --yes",
            "tap admin migrate-registry --yes",
        )

    state = registry_v20.flip_marker_state(_index_home())
    if state == "invalid":
        raise MigrateError(
            "invalid_flip",
            "global-registry.json is present but unreadable or wrong schema — refusing migrate",
            "tap doctor",
        )

    backup, inv_path, resuming = _resolve_backup()

    migration_lock = os.path.join(_index_home(), "migrate-registry.lock")
    os.makedirs(_index_home(), exist_ok=True)
    lock_fh = open(migration_lock, "w")
    try:
        fcntl.flock(lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        lock_fh.close()
        raise MigrateError(
            "migrate_in_progress",
            "another migrate-registry holds the migration lock",
            "retry tap admin migrate-registry --yes",
        ) from exc

    # 3681625756: hold teams.json.lock from enrollment snapshot through marker
    # publication so a concurrent tap_index_enroll_team cannot decide preflip,
    # wait on the lock, then write retired teams.json after the marker lands.
    teams_idx = _teams_index_path()
    os.makedirs(os.path.dirname(os.path.abspath(teams_idx)) or ".", exist_ok=True)
    teams_lock_fh = open(teams_idx + ".lock", "a+")
    try:
        # tap-rcs3: LOCK_NB so a held lock refuses (teams_index_locked) instead of hanging
        fcntl.flock(teams_lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        teams_lock_fh.close()
        try:
            fcntl.flock(lock_fh, fcntl.LOCK_UN)
        except Exception:
            pass
        lock_fh.close()
        raise MigrateError(
            "teams_index_locked",
            "could not acquire teams.json.lock for migrate",
            "retry tap admin migrate-registry --yes",
        ) from exc

    try:
        # WAVE 6.14 / 3683112927: live no-op must not raise no_teams when
        # teams.json is empty/retired. Marker state is already in hand.
        # Empty enrollments → immediate already-live. Non-empty → still take
        # registry locks before succeeding (composite 9.3: a held
        # registry.json.lock must not see a silent already-live success).
        if state == "live":
            # Validate the retired index when it is present, but discover live
            # acting registries from the flip marker. A completed migration may
            # legitimately leave teams.json empty; that cannot skip lineage
            # repair for the incumbents recorded in global-registry.json.
            teams = [(n, r) for n, r in _enrolled_teams() if os.path.isdir(r)]
            live_teams = _live_team_registries()
            if not teams and not live_teams:
                print("tap admin migrate-registry: already live (schema 0.20) — no-op")
                return 0
            manifest_path = _manifest_path()
            manifest_lock_fh = None
            locks: list[Any] = []
            try:
                lock_path = manifest_path + ".lock"
                os.makedirs(os.path.dirname(os.path.abspath(lock_path)) or ".", exist_ok=True)
                manifest_lock_fh = open(lock_path, "a+")
                try:
                    # tap-rcs3: LOCK_NB — held lock refuses, never hangs
                    fcntl.flock(manifest_lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError as exc:
                    manifest_lock_fh.close()
                    manifest_lock_fh = None
                    raise MigrateError(
                        "manifest_locked",
                        "could not acquire launcher sessions.json.lock for migrate",
                        "retry tap admin migrate-registry --yes",
                    ) from exc
                for name, root in teams:
                    bus = _bus_for_root(root)
                    if not bus:
                        continue
                    reg_path = os.path.join(bus, "registry.json")
                    lf = open(reg_path + ".lock", "a+")
                    try:
                        fcntl.flock(lf, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError as exc:
                        lf.close()
                        raise MigrateError(
                            "registry_locked",
                            f"could not acquire registry lock for team '{name}'",
                            "retry tap admin migrate-registry --yes",
                        ) from exc
                    locks.append(lf)
                for name, root, team_reg in live_teams:
                    lf = open(team_reg + ".lock", "a+")
                    try:
                        fcntl.flock(lf, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError as exc:
                        lf.close()
                        raise MigrateError(
                            "team_registry_locked",
                            f"could not acquire team-registry.json.lock for team '{name}'",
                            "retry tap admin migrate-registry --yes",
                        ) from exc
                    locks.append(lf)
                    _backfill_live_migration_lineage(root, team_reg)
                print("tap admin migrate-registry: already live (schema 0.20) — no-op")
                return 0
            finally:
                for lf in locks:
                    try:
                        fcntl.flock(lf, fcntl.LOCK_UN)
                    except Exception:
                        pass
                    lf.close()
                if manifest_lock_fh is not None:
                    try:
                        fcntl.flock(manifest_lock_fh, fcntl.LOCK_UN)
                    except Exception:
                        pass
                    manifest_lock_fh.close()

        teams = _enrolled_teams()
        if not teams:
            raise MigrateError(
                "no_teams",
                "no enrolled teams in teams.json — nothing to migrate",
                "tap init / tap in from a team worktree first",
            )

        # tap-5y6p / KTD-14: refuse BEFORE the flip marker when any already-
        # indexed enrolled root is unavailable. Silent drop stamps a reduced
        # global-registry; U7 cut exhaustive discovery, not indexed teams.
        bad = _unreachable_enrolled(teams)
        if bad:
            sample = ", ".join(f"{n} root={r}" for n, r in bad[:8])
            raise MigrateError(
                "unreachable_enrolled_root",
                f"refusing migrate: {len(bad)} enrolled team root(s) unavailable ({sample})",
                "restore the root directory or remove the teams.json enrollment, then re-run migrate",
            )

        unsettled_all: list[str] = []
        for name, root in teams:
            bus = _bus_for_root(root)
            if not bus:
                continue
            for pid in _count_unsettled(bus):
                unsettled_all.append(f"{name}/{pid}")
        if unsettled_all:
            sample = ", ".join(unsettled_all[:8])
            raise MigrateError(
                "unsettled_traffic",
                f"refusing migrate while {len(unsettled_all)} unsettled payload(s) remain ({sample})",
                "tap outstanding / tap done or tap cancel, then re-run migrate",
            )

        manifest_path = _manifest_path()
        # U8 / tap-saaz: flock the launcher sidecar across read, backup, and fold
        # so a concurrent launch cannot split generations mid-cutover.
        # UNCONDITIONAL — including when manifest+sidecar are both initially
        # absent (sol 863bb / fable 872a0). A conditional isfile gate left that
        # hole open: launch could create the sidecar after the check while
        # migrate continued with sessions=[] and no byte-preserved snapshot.
        manifest_lock_fh = None
        lock_path = manifest_path + ".lock"
        os.makedirs(os.path.dirname(os.path.abspath(lock_path)) or ".", exist_ok=True)
        manifest_lock_fh = open(lock_path, "a+")
        try:
            # tap-rcs3: LOCK_NB — held lock refuses, never hangs
            fcntl.flock(manifest_lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            manifest_lock_fh.close()
            manifest_lock_fh = None
            raise MigrateError(
                "manifest_locked",
                "could not acquire launcher sessions.json.lock for migrate",
                "retry tap admin migrate-registry --yes",
            ) from exc
        sessions = _manifest_sessions(manifest_path)

        # Manifest sidecar lock (above) stays held across ambiguity check, backup,
        # and fold (tap-saaz / U8).
        locks: list[Any] = []
        try:
            # Detect ambiguous joins before any write
            for name, root in teams:
                bus = _bus_for_root(root)
                if not bus:
                    continue
                reg_path = os.path.join(bus, "registry.json")
                if not os.path.isfile(reg_path):
                    continue
                try:
                    reg = _load_json(reg_path)
                except Exception:
                    continue
                for handle, entry in registry_v20._seat_map(reg).items():
                    if not isinstance(entry, dict):
                        continue
                    _, err = _join_config(root, handle, sessions)
                    if err:
                        raise MigrateError(
                            "ambiguous_join", err,
                            "fix launcher duplicate records then re-run migrate",
                        )

            os.makedirs(backup, exist_ok=True)
            for d in _backup_candidates():
                os.makedirs(d, exist_ok=True)

            for name, root in teams:
                bus = _bus_for_root(root)
                if not bus:
                    continue
                reg_path = os.path.join(bus, "registry.json")
                # Always touch the lock path (registry may be rewritten mid-cutover)
                lf = open(reg_path + ".lock", "a+")
                try:
                    fcntl.flock(lf, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError as exc:
                    raise MigrateError(
                        "registry_locked",
                        f"could not acquire registry lock for team '{name}'",
                        "retry tap admin migrate-registry --yes",
                    ) from exc
                locks.append(lf)

            files_meta: list[dict[str, str]] = []

            def record(path: str, basename: str) -> None:
                files_meta.append({"path": path, "basename": basename})

            # --- backups (copy; live stores remain until seats rewrite) ---
            if os.path.isfile(manifest_path):
                dest = os.path.join(backup, "sessions.json")
                if not resuming or not os.path.isfile(dest):
                    _copy_file(manifest_path, dest)
                record(dest, "sessions.json")
                _mirror_backup(backup, "sessions.json")
                lock = manifest_path + ".lock"
                if os.path.isfile(lock):
                    ldest = os.path.join(backup, "sessions.json.lock")
                    if not resuming or not os.path.isfile(ldest):
                        _copy_file(lock, ldest)
                    record(ldest, "sessions.json.lock")
                    _mirror_backup(backup, "sessions.json.lock")

            teams_idx = _teams_index_path()
            if os.path.isfile(teams_idx):
                dest = os.path.join(backup, "teams.json")
                if not resuming or not os.path.isfile(dest):
                    _copy_file(teams_idx, dest)
                record(dest, "teams.json")

            primary_reg_backup = ""
            for name, root in teams:
                bus = _bus_for_root(root)
                if not bus:
                    continue
                for base in ("registry.json", "registry-events.log"):
                    src = os.path.join(bus, base)
                    if not os.path.isfile(src):
                        if base == "registry-events.log":
                            open(src, "a", encoding="utf-8").close()
                        else:
                            continue
                    dest = os.path.join(backup, base)
                    team_bak = os.path.join(root, ".tap", "backup", "0.20-migration")
                    os.makedirs(team_bak, exist_ok=True)
                    team_dest = os.path.join(team_bak, base)
                    if not resuming or not os.path.isfile(team_dest):
                        _copy_file(src, team_dest)
                    if not primary_reg_backup and base == "registry.json":
                        if not resuming or not os.path.isfile(dest):
                            _copy_file(src, dest)
                        primary_reg_backup = dest
                        record(dest, "registry.json")
                        _mirror_backup(backup, "registry.json")
                    if base == "registry-events.log" and not any(
                        f.get("basename") == base for f in files_meta
                    ):
                        if not resuming or not os.path.isfile(dest):
                            _copy_file(src, dest)
                        record(dest, "registry-events.log")
                        _mirror_backup(backup, "registry-events.log")

            inventory = {
                "migration_id": "0.20-migration",
                "at": _utc(),
                "phase": "copied",
                "files": files_meta,
                "teams": [{"name": n, "root": r} for n, r in teams],
                "manifest": manifest_path,
            }
            _atomic_write(inv_path, inventory)
            for d in _backup_candidates():
                if os.path.abspath(d) != os.path.abspath(backup):
                    _atomic_write(os.path.join(d, "inventory.json"), inventory)

            global_teams: dict[str, Any] = {}
            for name, root in teams:
                bus = _bus_for_root(root)
                if not bus:
                    continue
                reg_path = os.path.join(bus, "registry.json")
                if not os.path.isfile(reg_path):
                    # Empty team — still enroll
                    team_reg = registry_v20.team_registry_path(root)
                    doc = registry_v20.empty_team_registry(name=name, worktree_root=root)
                    doc["team"]["branch_at_bootstrap"] = _branch_at_bootstrap(root)
                    _atomic_write(team_reg, doc)
                    global_teams[name] = {
                        "root": root,
                        "registry_location": team_reg,
                        "state": "registered",
                    }
                    continue

                pre = _load_json(reg_path)
                agents = registry_v20._seat_map(pre)
                team_reg = registry_v20.team_registry_path(root)
                # 3681754860: hold team-registry.json.lock across prior-instance
                # read + acting write (not the bus lock). Pre-marker writers are
                # marker-aware elsewhere; prior-instance reuse alone is enough —
                # do NOT prior-wins-union acting rows (can resurrect removals).
                os.makedirs(os.path.dirname(team_reg) or ".", exist_ok=True)
                team_reg_lock_fh = open(team_reg + ".lock", "a+")
                try:
                    # tap-rcs3: LOCK_NB — held lock refuses, never hangs
                    fcntl.flock(team_reg_lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError as exc:
                    team_reg_lock_fh.close()
                    raise MigrateError(
                        "team_registry_locked",
                        f"could not acquire team-registry.json.lock for team '{name}'",
                        "retry tap admin migrate-registry --yes",
                    ) from exc
                try:
                    # tap-tku9: if resume already wrote team-registry, reuse minted
                    # instances — do not remint from the bus mirror across the
                    # team-registry/bus write crash boundary.
                    prior_instances: dict[str, str] = {}
                    if resuming and os.path.isfile(team_reg):
                        try:
                            prior_doc = _load_json(team_reg)
                            for h, ent in registry_v20._seat_map(prior_doc).items():
                                if (
                                    isinstance(ent, dict)
                                    and isinstance(ent.get("instance"), str)
                                    and ent["instance"]
                                ):
                                    prior_instances[h] = ent["instance"]
                        except Exception:
                            prior_instances = {}
                    seats: dict[str, Any] = {}
                    for handle, entry in agents.items():
                        if not isinstance(entry, dict):
                            continue
                        folded_in = dict(entry)
                        if handle in prior_instances and not folded_in.get("instance"):
                            folded_in["instance"] = prior_instances[handle]
                        seats[handle] = _fold_seat(handle, folded_in, root, sessions)

                    # One-time repair (opus 101637): stop stripped delivery from
                    # every pane seat it suspended (poll never enters that path).
                    # Stamp delivery=pane on session_stopped+absent so the
                    # post-flip registry is fully explicit.
                    for s in seats.values():
                        if not isinstance(s, dict):
                            continue
                        if s.get("delivery"):
                            continue
                        if (
                            s.get("status") == "suspended"
                            and s.get("status_reason") == "session_stopped"
                        ):
                            s["delivery"] = "pane"

                    # Fold-in (opus/fable WAVE 5): session is load-bearing for
                    # post-flip resume synthesize. Refuse loud at migrate time.
                    # Key on the SAME shared relaunchable predicate — never a
                    # hand-rolled twin (corpses / restore-stripped poll out).
                    # WAVE 6.2 (fable option b): no carve-out — coords-only
                    # session-less rows are not relaunchable, so they never
                    # enter this set.
                    missing_session = [
                        h
                        for h, s in seats.items()
                        if registry_v20.seat_is_relaunchable(s)
                        and not (isinstance(s.get("session"), str) and s.get("session"))
                    ]
                    if missing_session:
                        named = ", ".join(sorted(missing_session))
                        raise MigrateError(
                            "missing_session",
                            f"relaunchable seat(s) lack session: {named}",
                            "tap register / tap session resume to stamp session=<tmux-name> "
                            "(or set delivery=poll for pane-less seats), then re-run migrate",
                        )

                    team_meta = pre.get("team") if isinstance(pre.get("team"), dict) else {}
                    doc = {
                        "schema": registry_v20.SCHEMA,
                        "team": {
                            "name": team_meta.get("name") or name,
                            "worktree_root": team_meta.get("worktree_root") or root,
                        },
                        "seats": seats,
                    }
                    _atomic_write(team_reg, doc)
                    # Acting authority is team-registry post-marker. Keep a seats
                    # mirror on bus for composite/specimen readers; consumers are
                    # marker-aware (completion/rebuild) so preflip stays on bus.
                    _atomic_write(reg_path, doc)
                    for handle, seat in seats.items():
                        if isinstance(seat, dict):
                            _ensure_migration_lineage(root, handle, seat)
                    global_teams[name] = {
                        "root": root,
                        "registry_location": team_reg,
                        "state": "registered",
                    }
                finally:
                    try:
                        fcntl.flock(team_reg_lock_fh, fcntl.LOCK_UN)
                    except Exception:
                        pass
                    team_reg_lock_fh.close()

            # WAVE 6.5 / 3682216641: inventory phase=complete MUST be durable
            # BEFORE the flip marker (global-registry.json). Marker-present
            # must imply inventory-complete; the live no-op path stays a no-op.
            inventory["phase"] = "complete"
            _atomic_write(inv_path, inventory)
            for d in _backup_candidates():
                if os.path.abspath(d) != os.path.abspath(backup):
                    _atomic_write(os.path.join(d, "inventory.json"), inventory)

            # Test-only: widen the locked pre-marker window for deterministic
            # send/migrate interleave pins (WAVE 6.12 G).
            _hook = os.environ.get("TAP_MIGRATE_BEFORE_MARKER_HOOK")
            if _hook:
                subprocess.run(["bash", "-c", _hook], check=False)

            # WAVE 6.11 / 3682836473: FINAL unsettled rescan under teams.json.lock
            # immediately before marker publication. The early scan alone left a
            # window where pre-cutover send could place after scan and before
            # marker — producing live marker + unbound payload. Same lock as
            # tap_send_place_under_cutover_barrier.
            unsettled_final: list[str] = []
            for name, root in teams:
                bus = _bus_for_root(root)
                if not bus:
                    continue
                for pid in _count_unsettled(bus):
                    unsettled_final.append(f"{name}/{pid}")
            if unsettled_final:
                sample = ", ".join(unsettled_final[:8])
                raise MigrateError(
                    "unsettled_traffic",
                    f"refusing migrate while {len(unsettled_final)} unsettled payload(s) "
                    f"remain at marker boundary ({sample})",
                    "tap outstanding / tap done or tap cancel, then re-run migrate",
                )

            # Marker LAST — every other store already durable.
            gpath = registry_v20.global_registry_path(_index_home())
            global_doc = {
                "schema": registry_v20.SCHEMA,
                "migrated": {
                    "at": _utc(),
                    "backups": {
                        "dir": backup,
                        "manifest": os.path.join(backup, "sessions.json"),
                        "inventory": inv_path,
                    },
                },
                "teams": global_teams,
            }
            _atomic_write(gpath, global_doc)

            print("tap admin migrate-registry: cutover complete (schema 0.20)")
            print(f"tap admin migrate-registry:   backup={backup}")
            print(f"tap admin migrate-registry:   inventory={inv_path}")
            print(f"tap admin migrate-registry:   global={gpath}")
            print(f"tap admin migrate-registry:   teams={len(global_teams)}")
            return 0
        finally:
            for lf in locks:
                try:
                    fcntl.flock(lf, fcntl.LOCK_UN)
                except Exception:
                    pass
                lf.close()
            if manifest_lock_fh is not None:
                try:
                    fcntl.flock(manifest_lock_fh, fcntl.LOCK_UN)
                except Exception:
                    pass
                manifest_lock_fh.close()
    finally:
        try:
            fcntl.flock(teams_lock_fh, fcntl.LOCK_UN)
        except Exception:
            pass
        teams_lock_fh.close()
        try:
            fcntl.flock(lock_fh, fcntl.LOCK_UN)
        except Exception:
            pass
        lock_fh.close()


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="tap admin migrate-registry")
    p.add_argument("--yes", action="store_true")
    p.add_argument("--json", action="store_true")
    args = p.parse_args(argv)
    try:
        return migrate(yes=args.yes)
    except MigrateError as exc:
        if args.json or os.environ.get("TAP_JSON") == "1":
            print(json.dumps({
                "ok": False,
                "error_class": exc.klass,
                "action": exc.action,
                "detail": exc.detail,
            }, separators=(",", ":")))
        else:
            print(f"tap admin migrate-registry: {exc.detail}; next: {exc.action}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
