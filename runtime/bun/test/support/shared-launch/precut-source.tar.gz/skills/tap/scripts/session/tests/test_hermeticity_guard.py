"""The hermeticity guard's own contract (conftest.py).

The guard is load-bearing for the merge gate: it is what stops this suite's
verdict from moving with whatever the developer's tmux server happens to hold.
A guard nobody checks is a guard that can rot silently, so its behavior is
pinned here rather than trusted.

Every assertion below is machine-independent, and that is the whole point --
these answers must be the same on a busy workstation, on a fresh checkout, and
on a runner with no tmux installed at all.
"""

import importlib.machinery
import importlib.util
import pathlib
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_loader(
    "launcher",
    importlib.machinery.SourceFileLoader("launcher", str(ROOT / "launcher.py")),
)
launcher = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(launcher)


class HermeticityGuardTests(unittest.TestCase):
    def test_whole_server_queries_report_an_empty_server(self):
        """A running server holding nothing -- observable, not unobservable.

        set() rather than None matters: None means "tmux could not be observed",
        which sends callers like seat_pane_observation down a different branch.
        """
        self.assertEqual(launcher.tmux_sessions(), set())
        self.assertEqual(launcher.tmux_sessions_or_none(), set())
        self.assertEqual(launcher.tmux_sessions_under(str(ROOT)), set())

    def test_targeted_probes_report_the_target_absent(self):
        # Low pane ids and plausible session names are exactly the values a
        # busy server is most likely to actually hold; the guard must answer
        # for them no matter what is really running.
        self.assertIsNone(launcher.tmux_pane_facts("%1"))
        self.assertIsNone(launcher.tmux_pane_facts("some/session:0.0"))
        self.assertFalse(launcher.tmux_has("some/session"))
        self.assertEqual(launcher.classify_session("some/session"), "unknown")

    def test_absent_pane_is_observed_absent_not_unobservable(self):
        """tmux_pane_raw_id tells the two apart by reading stderr.

        "" means tmux answered and the pane is gone; None means the probe
        itself failed. The guard's `can't find` stderr is what keeps this on
        the observed-absent side, so it is pinned here.
        """
        self.assertEqual(launcher.tmux_pane_raw_id("%1"), "")

    def test_a_per_test_mock_layers_on_top_and_wins(self):
        """The guard sets the floor; a test that wants specific behavior still
        gets it. This is what lets the suite keep its existing mocks unedited."""
        with mock.patch.object(launcher, "tmux_sessions", return_value={"x/y"}):
            self.assertEqual(launcher.tmux_sessions(), {"x/y"})
        with mock.patch.object(launcher, "tmux_has", return_value=True):
            self.assertTrue(launcher.tmux_has("some/session"))
        # ...and the floor is back in force once the mock is released.
        self.assertEqual(launcher.tmux_sessions(), set())
        self.assertFalse(launcher.tmux_has("some/session"))

    def test_a_bash_child_gets_the_same_answer_for_a_targeted_probe(self):
        """The shell half, pinned from outside: argv[0] is bash, not tmux.

        Two launcher paths shell out to `bash -c '. lib.sh; ...'` and lib.sh
        calls tmux itself, past where a patched stdlib can follow; only the
        PATH shim covers them. Running tmux THROUGH bash is what makes this
        test see the shim -- a direct tmux argv would be answered by the Python
        half and prove nothing about the shell one.

        The shim deliberately disagrees with real tmux here, and the
        disagreement is the point: real tmux answers a targeted
        `display-message` with rc 0 and empty stdout, reserving rc 1 + `can't
        find` for capture-pane, has-session and list-panes. Both lib.sh
        display-message callers discard the rc and branch on an empty result,
        so one model shared by both halves beats reproducing that split at the
        language boundary. Do not "fix" this into agreement with real tmux.
        """
        import subprocess

        result = subprocess.run(
            ["bash", "-c", "tmux display-message -p -t some/session:0.0 '#{pane_id}'"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        # The bash-side reader of this text is lib.sh's
        # tap_seat_pane_observation, in the `*"can't find"*` arm of its rc!=0
        # case. It is pinned so both choke points keep answering from one
        # shared model -- the guard's holds-both invariant, above -- not
        # because a consumer reachable from this suite reads it today:
        # launcher.py's two `bash -c '. lib.sh; ...'` calls never reach
        # tap_seat_pane_observation, which is only reached through
        # tap_seat_pane_probe, whose callers (tap-team.sh, native admin) this
        # suite never spawns. This protects the contract ahead of that
        # consumer, not a breakage that already happened.
        self.assertIn("can't find", result.stderr)

    def test_a_bash_child_gets_the_same_answer_for_a_whole_server_query(self):
        """The untargeted arm: a running server that simply holds nothing.

        The shim branches on `-t`, so both arms need pinning -- a change that
        collapsed them would leave this half agreeing with the Python one on
        only one shape.
        """
        import subprocess

        result = subprocess.run(
            ["bash", "-c", "tmux list-sessions"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertEqual(result.stderr, "")

    def test_non_tmux_commands_are_not_intercepted(self):
        """The launcher shells out for more than tmux -- the boot id probe uses
        sysctl, and rewriting that would break callers with no tmux involvement.
        current_boot_id() is cached, so this reads through the real path once."""
        import subprocess

        result = subprocess.run(
            ["echo", "passthrough"], text=True, stdout=subprocess.PIPE,
        )
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "passthrough")


if __name__ == "__main__":
    unittest.main()
