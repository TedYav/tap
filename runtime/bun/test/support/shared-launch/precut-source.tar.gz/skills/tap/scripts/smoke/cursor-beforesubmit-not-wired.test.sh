#!/usr/bin/env bash
# tap-o4ae: fixture env must stay in this process. Refuse `source` so an
# interactive shell cannot inherit top-level exports.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# cursor-beforesubmit-not-wired.test.sh — tap-he46 follow-up.
#
# #xxx wired the prompt-time roster line into Cursor's `beforeSubmitPrompt`. That
# event returns `continue` and `user_message` ONLY — no context-injection field
# (only `sessionStart` and `postToolUse` accept `additional_context`). The line
# was discarded on every prompt while `hooks.json` showed it installed: cost with
# no effect, and invisible to "nobody complained".
#
# Two halves, failing differently:
#   (1) the installer must never wire it again — checked against install.sh text,
#       since the installer is the thing that would reintroduce it.
#   (2) the de-wire must actually remove an entry an earlier version wrote, and
#       must not touch anyone else's. Machines that ran the #xxx installer carry
#       the no-op right now; a fix that only stops ADDING leaves them paying.
#
# The de-wire is a standalone script precisely so this fixture can drive it. An
# earlier draft ran the whole installer to exercise one JSON edit, which relinks
# user-level skills as a side effect — from a disposable worktree that is the
# "never run the installer from a worktree" rule (AGENTS.md) violated inside a
# test that reads as harmless.
set -euo pipefail

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
DEWIRE="$ROOT/runtime/bun/src/install-roster-hook-cleanup.ts"
# shellcheck source=sandbox-pins.sh
. "$ROOT/skills/tap/scripts/smoke/sandbox-pins.sh"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
fail() { echo "cursor-beforesubmit-not-wired: $*" >&2; exit 1; }

# --- (1) the installer never WIRES beforeSubmitPrompt, by any idiom -----------
# Not `grep bsp.append`: that pins one spelling, and `insert(0, …)`, `+= […]`, or
# a setdefault chain would re-wire the event and sail past it (opus-2, gate on
# #xxx — the written-is-not-binding shape). The tight assertion is available for
# free: the string occurs in install.sh exactly once, in a comment. Anything that
# wires the event has to name it on a code line.
_bsp_code="$(grep -n 'beforeSubmitPrompt' "$ROOT/install.sh" | grep -v ':[[:space:]]*#' || true)"
[ -z "$_bsp_code" ] \
  || fail "(1) install.sh names beforeSubmitPrompt on a non-comment line — that event discards additional_context: $_bsp_code"
grep -q 'install-roster-hook-cleanup.ts" cursor' "$ROOT/install.sh" \
  || fail "(1) install.sh no longer calls the de-wire — machines carrying the #xxx entry stay broken"

# --- (2) removal is real, targeted, idempotent, and spares sessionStart -------
HOOKS="$WORK/hooks.json"
cat > "$HOOKS" <<'JSON'
{
  "metadata": {"9": 1.0, "2": 9007199254740993123456789, "unicode": "café 🐎 \u007f", "float": 1E-7, "negative": -0.0, "overflow": 1e400, "empty": [{}, []]},
  "version": 1,
  "hooks": {
    "sessionStart": [
      {"command": "bash /somewhere/tap-cursor-session-start.sh"}
    ],
    "beforeSubmitPrompt": [
      {"command": "\"/Users/user/../Scripts/other-tool\" cursor context"},
      {"command": "TAP_HOOK_MODE=roster bash /somewhere/tap-cursor-session-start.sh"}
    ]
  }
}
JSON

python3 -B - "$HOOKS" "$WORK/expected.json" <<'PY'
import json, sys
data = json.load(open(sys.argv[1]))
data['hooks']['beforeSubmitPrompt'].pop(1)
with open(sys.argv[2], 'w') as out:
    json.dump(data, out, indent=2)
    out.write('\n')
PY
bun "$DEWIRE" cursor "$HOOKS" >"$WORK/out1" 2>&1 || fail "(2) de-wire exited non-zero: $(cat "$WORK/out1")"
cmp "$WORK/expected.json" "$HOOKS" || fail "(2) changed-file bytes differ from Python"
grep -q 'removed the no-op' "$WORK/out1" \
  || fail "(2) de-wire ran silently on a file that HAD the entry: $(cat "$WORK/out1")"

check_state() { # <label>
  python3 -B - "$HOOKS" "$1" <<'PY'
import json, sys
path, label = sys.argv[1:3]
data = json.load(open(path))
hooks = data.get("hooks", {})
bsp = hooks.get("beforeSubmitPrompt", [])
cmds = [e.get("command", "") for e in bsp if isinstance(e, dict)]
problems = []
if any("TAP_HOOK_MODE=roster" in c for c in cmds):
    problems.append("the no-op entry survived")
if not any("other-tool" in c for c in cmds):
    problems.append("another tool's entry was eaten")
if not hooks.get("sessionStart"):
    problems.append("sessionStart was damaged — that is the cursor wiring that WORKS")
if problems:
    print(f"{label}: " + "; ".join(problems), file=sys.stderr)
    raise SystemExit(1)
PY
}
check_state "after removal" || fail "(2) $(check_state 'after removal' 2>&1)"

# Idempotent: a second run changes nothing and says nothing.
cp "$HOOKS" "$WORK/unchanged.json"
bun "$DEWIRE" cursor "$HOOKS" >"$WORK/out2" 2>&1 || fail "(2) second de-wire exited non-zero"
cmp "$WORK/unchanged.json" "$HOOKS" || fail "(2) second de-wire rewrote the file"
[ -s "$WORK/out2" ] && fail "(2) de-wire is not idempotent — it reported work on a clean file: $(cat "$WORK/out2")"
check_state "after second run" || fail "(2) $(check_state 'after second run' 2>&1)"

# --- (3) safe on the shapes a real machine presents ---------------------------
: > "$WORK/empty.json"
bun "$DEWIRE" cursor "$WORK/empty.json" >/dev/null 2>&1 || fail "(3) an unparseable hooks.json must not fail the install"
bun "$DEWIRE" cursor "$WORK/does-not-exist.json" >/dev/null 2>&1 || fail "(3) a missing hooks.json must not fail the install"

# Sole entry: the event key is removed rather than left as an empty list.
cat > "$WORK/solo.json" <<'JSON'
{"version": 1, "hooks": {"beforeSubmitPrompt": [{"command": "TAP_HOOK_MODE=roster bash /x.sh"}]}}
JSON
bun "$DEWIRE" cursor "$WORK/solo.json" >/dev/null 2>&1
python3 -B -c '
import json, sys
d = json.load(open(sys.argv[1]))
assert "beforeSubmitPrompt" not in d.get("hooks", {}), "empty beforeSubmitPrompt key left behind"
' "$WORK/solo.json" || fail "(3) removing the sole entry left an empty beforeSubmitPrompt key"

# --- (4) an unwritable target must NOT fail the install -----------------------
# The script's header promises it never fails an install, and install.sh runs
# under `set -euo pipefail`, so a propagated write error aborts everything after
# the call — the Claude/Codex/Hermes wiring already done, and every step below.
# That promise was false when this fixture was first written: it lived only in a
# comment, which binds nothing. This arm is what binds it.
UNWRITABLE="$WORK/ro"
mkdir -p "$UNWRITABLE"
cat > "$UNWRITABLE/hooks.json" <<'JSON'
{"version": 1, "hooks": {"beforeSubmitPrompt": [{"command": "TAP_HOOK_MODE=roster bash /x.sh"}]}}
JSON
chmod 500 "$UNWRITABLE"
_rc=0
bun "$DEWIRE" cursor "$UNWRITABLE/hooks.json" >"$WORK/ro.out" 2>"$WORK/ro.err" || _rc="$?"
chmod 700 "$UNWRITABLE"
[ "$_rc" = 0 ] \
  || fail "(4) an unwritable ~/.cursor made the de-wire exit $_rc — under install.sh's set -e that aborts the whole install"
grep -q 'could NOT remove' "$WORK/ro.err" \
  || fail "(4) the failure must still be LOUD on stderr, or a stale entry rots silently: $(cat "$WORK/ro.err")"

# And the same call under a caller that behaves like install.sh must continue.
#
# THE CALLER MUST BE ITS OWN PROCESS. An inline `( set -euo pipefail; … ) || true`
# cannot fail: bash suppresses errexit for every command in a `||` list except
# the last, and that suppression reaches INSIDE the subshell — so the `set -e`
# is inert and `echo reached` runs whatever the script returns. Driven against
# stubs exiting 0 and 1, that shape passes both ways (opus-2, re-review of #xxx,
# who found it by testing the assertion's own discriminating power after two
# mutation attempts failed to answer it).
#
# Pointed at the UNWRITABLE target, not a missing one: a missing file exits via
# an early guard and never reaches the write.
cat > "$WORK/caller.sh" <<'CALLER'
set -euo pipefail
bun "$1" cursor "$2" >/dev/null 2>&1
echo reached
CALLER
# ITS OWN FIXTURE, not the one above. Sharing sub-check 1's file made this
# depend on a fact it never asserts: that the file still holds a TAP entry —
# true today only because sub-check 1's write FAILED. Let that write ever
# succeed (a reordered chmod, a changed path) and this file would carry no
# entry, the script would exit 0 through the nothing-to-remove early return
# WITHOUT attempting the write, and the assertion would pass for exactly the
# reason the first two versions of it did: never reaching the code under test
# (opus-2, re-review 2 of #xxx).
UNWRITABLE2="$WORK/ro2"
mkdir -p "$UNWRITABLE2"
cat > "$UNWRITABLE2/hooks.json" <<'JSON'
{"version": 1, "hooks": {"beforeSubmitPrompt": [{"command": "TAP_HOOK_MODE=roster bash /x.sh"}]}}
JSON
grep -q 'TAP_HOOK_MODE=roster' "$UNWRITABLE2/hooks.json" \
  || fail "(4) fixture invalid: no TAP entry to remove, so the write is never attempted"
chmod 500 "$UNWRITABLE2"
bash "$WORK/caller.sh" "$DEWIRE" "$UNWRITABLE2/hooks.json" > "$WORK/setE.out" 2>&1 || true
chmod 700 "$UNWRITABLE2"
grep -q reached "$WORK/setE.out" \
  || fail "(4) a set -euo pipefail caller did not survive the de-wire call"

echo "cursor-beforesubmit-not-wired: ok"
