#!/usr/bin/env bash
# tap-o4ae: fixture env must stay in this process.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# compaction-chrome-anchor.test.sh — the compaction detector must not fire on
# PROSE ABOUT compaction (tap-ieiy follow-on).
#
# tap_wait_compaction gates the post-compaction wake ping: until a compaction is
# observably under way, the ping is withheld, because a plain message queued
# mid-turn is handed to the model at a tool-call boundary while the /compact
# waits for the turn to END. If the detector fires early the ping is submitted
# into the still-running turn — the exact failure the gate exists to prevent.
#
# An UNANCHORED substring match fires on any transcript containing the words. The
# panes most likely to contain them are the ones DISCUSSING compaction: a seat
# working on this code, a seat reading this test, a seat that was sent a message
# about the wake. The detector's own authors are its most likely false positives.
#
# WHY THE NEGATIVE ARM IS THE POINT. A fixture that renders the real chrome and
# asks "does it match" tests only the happy direction; it cannot fail on an
# over-broad pattern, because its only negative is a pane with NO compaction text
# rather than a pane with the WRONG KIND of it. That is how this shipped green.
#
# The chrome strings are pinned from a LIVE CAPTURE (specimen below), not from
# memory. A harness that re-words its chrome drops out of the table and the gate
# falls back to its timeout arm — loud and slow, never silently permissive.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
fail() { echo "compaction-chrome-anchor: FAIL $*" >&2; exit 1; }

BIN="$WORK/bin"; mkdir -p "$BIN"
cat > "$BIN/tmux" <<'TMUX'
#!/usr/bin/env bash
case "${1:-}" in
  capture-pane) cat "${FAKE_PANE_TEXT:?}" ;;
  display-message) printf '%%1\n' ;;
esac
exit 0
TMUX
chmod +x "$BIN/tmux"
export PATH="$BIN:$PATH"
# shellcheck source=skills/tap/scripts/lib.sh
. "$ROOT/skills/tap/scripts/lib.sh"

count() { FAKE_PANE_TEXT="$1" tap_compaction_chrome_count "%1" claude "$2"; }

# --- (1) PROSE ABOUT COMPACTION MUST NOT COUNT AS COMPACTION ------------------
# Every line here is something a real pane on this board has held tonight.
cat > "$WORK/prose.txt" <<'PROSE'
❯ the detector fires when Compacting conversation appears, which is the bug
⏺ I am reading tap_wait_compaction: it polls for Compacting conversation… and for
  a new Compacted ( line, and returns 0 on either.
  ⎿  Read skills/tap/scripts/lib.sh (40 lines)
❯ so a pane discussing Compacting conversation would trigger it? and Compacted (…) too?
PROSE
n="$(count "$WORK/prose.txt" inflight)"
[ "$n" = 0 ] || fail "(1) in-flight detector fired $n time(s) on TRANSCRIPT PROSE — a pane discussing compaction reads as a pane compacting"
n="$(count "$WORK/prose.txt" done)"
[ "$n" = 0 ] || fail "(1b) done detector fired $n time(s) on transcript prose"
echo "  (1) prose about compaction does not register as compaction ok"

# --- (2) THE REAL CHROME MUST STILL COUNT ------------------------------------
# Specimen: captured live from a disposable claude pane during a real /compact
# (Lane C, 2026-08-19), sampled at 0.3s. Kept verbatim — including the leading
# tree glyph and trailing hint — because those are what distinguish chrome from
# a sentence, and re-typing them from memory is how the unanchored pattern was
# written in the first place.
cat > "$WORK/done.txt" <<'DONE'
  ⎿  Compacted (ctrl+o to see full summary)
DONE
n="$(count "$WORK/done.txt" done)"
[ "$n" -ge 1 ] || fail "(2) the real 'Compacted (' chrome line no longer registers — the gate would never observe a finished compaction"
n="$(count "$WORK/done.txt" inflight)"
[ "$n" = 0 ] || fail "(2b) the DONE line registered as IN-FLIGHT; the two states must stay distinguishable"

# The in-flight specimen, same capture. The spinner cycles between glyphs, so
# both observed forms are pinned: a pattern keyed on one glyph would work for
# half of every second and be maddening to debug.
printf '\xe2\x9c\xbd Compacting conversation\xe2\x80\xa6 (16s)\n\xc2\xb7 Compacting conversation\xe2\x80\xa6 (17s)\n' > "$WORK/inflight.txt"
n="$(count "$WORK/inflight.txt" inflight)"
[ "$n" -ge 2 ] || fail "(2c) the real in-flight chrome registered $n time(s); both spinner glyphs must match"
n="$(count "$WORK/inflight.txt" done)"
[ "$n" = 0 ] || fail "(2d) the IN-FLIGHT line registered as DONE — the gate would treat a running compaction as a finished one"
echo "  (2) the real chrome registers, in-flight and done, each only as itself ok"

# --- (3) an unrelated pane registers nothing ---------------------------------
cat > "$WORK/quiet.txt" <<'QUIET'
❯ bash scripts/smoke-all.sh
  ⎿  all 147 files passed (134s, -j 12)
QUIET
[ "$(count "$WORK/quiet.txt" inflight)" = 0 ] && [ "$(count "$WORK/quiet.txt" done)" = 0 ] \
  || fail "(3) a pane with no compaction at all registered one"
echo "  (3) an unrelated pane registers nothing ok"

# --- (4) A STATIC PANE IS NEVER A COMPACTION, WHATEVER IT CONTAINS ------------
# The anchored pattern killed inline prose and left the shape it could not tell
# apart: a markdown bullet, a blockquote, and a verbatim specimen are all
# `punctuation + space + phrase`, exactly like `glyph + space + phrase`. A pane
# displaying THIS FILE, or a payload quoting the chrome, is indistinguishable
# from a compacting pane by content alone — and content is what a quote
# reproduces perfectly.
#
# So the predicate is no longer lexical. tap_wait_compaction observes a
# compaction only when the pane CHANGES: the in-flight text must tick (chrome is
# rewritten in place ~1/s; the live capture caught 109 distinct frames), or the
# done-count must rise above its entry baseline. That is a property of two
# instants, not of one — so NO static text can satisfy it, whatever glyph,
# punctuation or quoting it uses. This arm is deliberately not an enumeration of
# adversarial lines: it asserts the class, by holding the worst content still.
FRAMES="$WORK/frames"; mkdir -p "$FRAMES"
cat > "$BIN/tmux" <<'TMUX'
#!/usr/bin/env bash
case "${1:-}" in
  capture-pane)
    n=0
    [ -f "$FAKE_SEQ/.n" ] && n="$(cat "$FAKE_SEQ/.n")"
    n=$((n+1)); printf '%s' "$n" > "$FAKE_SEQ/.n"
    last="$(ls "$FAKE_SEQ" | grep -c '^f')"
    [ "$n" -gt "$last" ] && n="$last"
    cat "$FAKE_SEQ/f$n"
    ;;
  display-message) printf '%%1\n' ;;
esac
exit 0
TMUX
chmod +x "$BIN/tmux"

STATIC="$WORK/static"; mkdir -p "$STATIC"
cat > "$STATIC/f1" <<'STATICTXT'
- Compacting conversation… (16s) is the in-flight line we anchor on
* Compacting conversation… appears in the smoke fixture as a specimen
> Compacting conversation… (17s · ↑ 1.5k tokens)
  ⎿  Compacted (ctrl+o to see full summary)
STATICTXT
rm -f "$STATIC/.n"
if FAKE_SEQ="$STATIC" tap_wait_compaction "%1" claude 1 0.05; then
  fail "(4) a STATIC pane quoting the chrome — bullets, a blockquote, a verbatim specimen — was observed as a live compaction; the wake would be submitted into the still-running turn"
fi
echo "  (4) a static pane quoting the chrome is not a compaction ok"

# --- (5) A TICKING PANE IS ----------------------------------------------------
# The positive direction, so (4) cannot be satisfied by a detector that never
# fires. Frames are the real capture: the timer advances and the spinner glyph
# changes, which is what no quoted specimen does.
TICK="$WORK/tick"; mkdir -p "$TICK"
printf '\xe2\x9c\xbd Compacting conversation\xe2\x80\xa6 (16s)\n' > "$TICK/f1"
printf '\xe2\x9c\xbd Compacting conversation\xe2\x80\xa6 (16s)\n' > "$TICK/f2"
printf '\xc2\xb7 Compacting conversation\xe2\x80\xa6 (17s)\n' > "$TICK/f3"
rm -f "$TICK/.n"
FAKE_SEQ="$TICK" tap_wait_compaction "%1" claude 3 0.05 \
  || fail "(5) a pane whose compaction chrome TICKED was not observed — the gate would burn its timeout on a real compaction"
echo "  (5) a ticking pane is observed as a compaction ok"

# --- (6) A COMPACTION THAT FINISHES BETWEEN POLLS STILL COUNTS ----------------
# The tick predicate must not become the only door: a compaction short enough
# that no two distinct in-flight frames are sampled still ends with a NEW
# `Compacted (` line, and the done arm's baseline is what makes that a rise
# rather than a presence. The static specimen in frame 1 is the trap — it is
# there at entry, so only the SECOND one may count.
FAST="$WORK/fast"; mkdir -p "$FAST"
cat > "$FAST/f1" <<'FAST1'
> quoting the chrome:   ⎿  Compacted (ctrl+o to see full summary)
FAST1
cat > "$FAST/f2" <<'FAST2'
> quoting the chrome:   ⎿  Compacted (ctrl+o to see full summary)
FAST2
cat > "$FAST/f3" <<'FAST3'
> quoting the chrome:   ⎿  Compacted (ctrl+o to see full summary)
  ⎿  Compacted (ctrl+o to see full summary)
FAST3
rm -f "$FAST/.n"
FAKE_SEQ="$FAST" tap_wait_compaction "%1" claude 3 0.05 \
  || fail "(6) a compaction observed only by its completed line was missed; the done arm must still rise above its entry baseline"
echo "  (6) a compaction seen only as a completed line still counts ok"

# --- (7) THE ELLIPSIS MAY BE THREE ASCII DOTS ---------------------------------
# U+2026 is the least stable byte in the pattern — one locale, accessibility or
# fallback path away from "...". Requiring it is load-bearing (without it a
# transcript bullet clears the glyph anchor), so both spellings are accepted
# rather than the requirement being dropped. An earlier comment in lib.sh
# claimed the ellipsis "costs nothing to require"; kimi falsified that against
# the live pattern, which is why this arm exists.
printf '\xe2\x9c\xbd Compacting conversation... (16s)\n' > "$WORK/ascii.txt"
FAKE_SEQ= ; unset FAKE_SEQ
cat > "$BIN/tmux" <<'TMUX'
#!/usr/bin/env bash
args="$*"
case "${1:-}" in
  capture-pane)
    if [ -n "${FAKE_WRAP_AT:-}" ] && ! printf '%s' "$args" | grep -q 'J'; then
      # tmux without -J hands back the pane's PHYSICAL lines: a long chrome line
      # arrives already split at the pane edge.
      fold -w "$FAKE_WRAP_AT" "${FAKE_PANE_TEXT:?}"
    else
      cat "${FAKE_PANE_TEXT:?}"
    fi
    ;;
  display-message) printf '%%1\n' ;;
esac
exit 0
TMUX
chmod +x "$BIN/tmux"
n="$(count "$WORK/ascii.txt" inflight)"
[ "$n" -ge 1 ] || fail "(7) in-flight chrome spelled with three ASCII dots did not register; the gate goes blind on any harness that stops emitting U+2026"
echo "  (7) an ASCII-dots ellipsis still registers ok"

# --- (8) A WRAPPED CHROME LINE STILL REGISTERS --------------------------------
# capture-pane must be called with -J. Without it tmux returns physical lines, so
# a pane narrower than the chrome line splits it and the ^-anchored pattern stops
# matching — the detector goes silent with no error. Latent on today's geometry
# (the line needs ~26 columns; the narrowest pane on this machine is 53) and live
# the moment someone rearranges panes, which is why it is fixed rather than
# noted.
printf '\xe2\x9c\xbd Compacting conversation\xe2\x80\xa6 (1m 11s \xc2\xb7 \xe2\x86\x91 1.5k tokens)\n' > "$WORK/wide.txt"
n="$(FAKE_WRAP_AT=24 count "$WORK/wide.txt" inflight)"
[ "$n" -ge 1 ] || fail "(8) chrome wrapped at 24 columns did not register — capture-pane is missing -J"
echo "  (8) chrome wrapped by a narrow pane still registers ok"

echo "compaction-chrome-anchor: ok"
