#!/usr/bin/env bash
# claude-arg-hint.test.sh — tap-tx3s.1 A1/A2, helper-direct, no tmux.
#
# REGRESS NEVER BLOCKS A MERGE. The gate share is submit-verify.test.sh P1/N1
# (assembled typed-prefix path). This file binds 18 of the 26
# claude-slash-*.ansi fixtures that tap-52ys orphaned, plus the live
# truecolor 53-column truncated capture and the live truecolor 80-column
# whole-placeholder capture, to native stripClaudeArgHint via a test-only bridge. Eight of the 26
# stay unbound because they are not helper accept/refuse cases under A1/A2:
# hint-cursor-blink (painted vs unpainted already bound), hint-goal-unpainted
# (goal painted and compact unpainted bound), hint-theme-dark and
# hint-theme-light (A2 colour-not-authority is bound by hint-white /
# hint-neargray), idle-band (no hint to strip), second-command and
# unknown-command (command is None refuses before the table), wrapped-draft
# (draft wrap, not a placeholder). Call the helper; do not go through tmux.
#
# Polarities: P0 (live truecolor 80-col whole placeholder) / P1-bytes /
# hint-white / hint-neargray strip; N2-N7, unreadable-width, and the two
# ellipsis-conjunct KEEPs. Mutants M1-M4 each red the named arm; M2b/M2c
# red the matching conjunct. BASE-vs-HEAD on truecolor bytes: BASE@80
# strips; BASE@53 KEEPS because the ellipsis misses the table (38;2 gray
# present, so HINT_FG is not the reason); HEAD strips both. The 256-colour
# file is a HEAD-only environment regression, never a BASE input.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
DIR="$ROOT/skills/tap/scripts"
FIXTURES="$DIR/smoke/fixtures/submit-verify"
# shellcheck source=skills/tap/scripts/lib.sh
. "$DIR/lib.sh"

# Keep the fixture/mutation contract on the native export after the Bash helper
# was retired. This bridge is test-only; BASE below still calls its pinned Bash.
READER="$ROOT/runtime/bun/src/pane/reader.ts"
ARG_HINT_READER="$READER"
tap_strip_claude_arg_hint() {
  bun -e 'const {stripClaudeArgHint} = await import(process.argv[1]);
    process.stdout.write(stripClaudeArgHint(process.argv[2], process.argv[3], process.argv[4]));' \
    "$ARG_HINT_READER" "$1" "$2" "$3"
}

fail() { echo "claude-arg-hint: $*" >&2; exit 1; }

# Load (typed, plain_prompt_row) from a fixture. typed is the glyph-stripped
# prompt line; row is the full plain prompt line (A1 cell count).
load_prompt() {
  python3 -B - "$1" <<'PY'
import re, sys
raw = open(sys.argv[1], encoding="utf-8").read()
raw = re.sub(r"\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)", "", raw)
plain = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", raw)
row = None
for line in plain.splitlines():
    s = line.lstrip(" ")
    if s.startswith("❯") or s.startswith("›"):
        row = line
        break
if row is None:
    sys.exit(2)
typed = row.lstrip(" ❯›\u00a0\u276f\u203a")
print(typed.rstrip())
print(row)
PY
}

# Escaped prompt line as the BASE helper saw it (SGR intact). Prompt-row bytes
# are unmodified; OSC is stripped only so a footer hyperlink cannot steal the
# line match.
load_escaped_prompt() {
  python3 -B - "$1" <<'PY'
import re, sys
raw = open(sys.argv[1], encoding="utf-8").read()
raw = re.sub(r"\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)", "", raw)
csi = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
for line in raw.splitlines():
    plain = csi.sub("", line)
    s = plain.lstrip(" ")
    if s.startswith("❯") or s.startswith("›"):
        print(line)
        sys.exit(0)
sys.exit(2)
PY
}

expect_strip() {
  local name="$1" fixture="$2" width="$3" want="$4"
  local typed row got
  typed="$(load_prompt "$fixture" | sed -n '1p')"
  row="$(load_prompt "$fixture" | sed -n '2p')"
  got="$(tap_strip_claude_arg_hint "$typed" "$row" "$width")"
  [ "$got" = "$want" ] || fail "$name: expected '$want', got '$got' (typed='$typed' width='$width')"
}

expect_keep() {
  local name="$1" fixture="$2" width="$3"
  local typed row got
  typed="$(load_prompt "$fixture" | sed -n '1p')"
  row="$(load_prompt "$fixture" | sed -n '2p')"
  got="$(tap_strip_claude_arg_hint "$typed" "$row" "$width")"
  [ "$got" = "$typed" ] || fail "$name: expected KEEP typed='$typed', got '$got'"
}

LIVE53="$FIXTURES/claude-slash-hint-compact-truncated-53.ansi"
[ -f "$LIVE53" ] || fail "missing live 53-column truecolor fixture $LIVE53"
LIVE80="$FIXTURES/claude-slash-hint-compact-full.ansi"
[ -f "$LIVE80" ] || fail "missing live 80-column truecolor fixture $LIVE80"
REG256="$FIXTURES/claude-slash-hint-compact-full-256.ansi"
[ -f "$REG256" ] || fail "missing 256-colour environment-regression fixture $REG256"

# --- P0: live 80-col truecolor whole placeholder (restored BASE prediction) ---
expect_strip "P0-helper live 80 truecolor" "$LIVE80" "80" "/compact"
# HEAD-only: 256-colour regression must still strip (plain-text helper).
expect_strip "HEAD-only 256-colour environment regression" "$REG256" "80" "/compact"
echo "claude-arg-hint: P0-helper live 80 truecolor + HEAD-only 256 regression: ok"

# --- P1 bytes at the helper (live 53-col capture, exact-fill) -----------------
expect_strip "P1-helper live 53" "$LIVE53" "53" "/compact"
# Same bytes at a wide pane must KEEP (N1 at helper granularity).
expect_keep "N1-helper live 53 at width 80" "$LIVE53" "80"
# Unreadable width KEEP for the truncated form; verbatim is tested below.
expect_keep "unreadable-width empty" "$LIVE53" ""
expect_keep "unreadable-width zero" "$LIVE53" "0"
expect_keep "unreadable-width junk" "$LIVE53" "nope"
echo "claude-arg-hint: P1-helper / N1-helper / unreadable-width KEEP: ok"

# --- A2: colour is not an authority. These used to be negatives. --------------
expect_strip "hint-white A2" "$FIXTURES/claude-slash-hint-white.ansi" "80" "/compact"
expect_strip "hint-neargray A2" "$FIXTURES/claude-slash-hint-neargray.ansi" "80" "/compact"
expect_strip "hint-compact painted" "$FIXTURES/claude-slash-hint-compact.ansi" "80" "/compact"
expect_strip "hint-compact unpainted" "$FIXTURES/claude-slash-hint-compact-unpainted.ansi" "80" "/compact"
expect_strip "hint-goal" "$FIXTURES/claude-slash-hint-goal.ansi" "80" "/goal"
expect_strip "hint-loop" "$FIXTURES/claude-slash-hint-loop.ansi" "80" "/loop"
expect_strip "hint-clear" "$FIXTURES/claude-slash-hint-clear.ansi" "80" "/clear"
echo "claude-arg-hint: A2 positives (white/neargray) and full-width table: ok"

# --- N2 prefix is not a prefix of the table entry -----------------------------
N2="$FIXTURES/claude-slash-hint-compact-truncated-n2-custum.ansi"
# Pass width == row cells so the full-row check is not the reason.
N2_WIDTH="$(python3 -B -c 'import unicodedata,sys; r=sys.argv[1]
def c(s):
  return sum(2 if unicodedata.east_asian_width(ch) in ("F","W") else 1 for ch in s)
print(c(r))' "$(load_prompt "$N2" | sed -n '2p')")"
expect_keep "N2 custum not a prefix" "$N2" "$N2_WIDTH"

# --- N3 empty prefix (`/compact  …`) ------------------------------------------
N3="$FIXTURES/claude-slash-hint-compact-truncated-n3-empty.ansi"
N3_WIDTH="$(python3 -B -c 'import sys; print(len(sys.argv[1]))' "$(load_prompt "$N3" | sed -n '2p')")"
expect_keep "N3 empty prefix" "$N3" "$N3_WIDTH"

# --- N4 truncated compact hint under /goal ------------------------------------
N4="$FIXTURES/claude-slash-hint-compact-truncated-n4-wrong-command.ansi"
N4_WIDTH="$(python3 -B -c 'import sys; print(len(sys.argv[1]))' "$(load_prompt "$N4" | sed -n '2p')")"
expect_keep "N4 wrong command" "$N4" "$N4_WIDTH"
echo "claude-arg-hint: N2 N3 N4: ok"

# --- Ellipsis conjuncts (FIX-AND-SHIP item 4). Production KEEP on both.
# Dropping `prefix != placeholder` strips the first; `startswith` -> `in`
# strips the second. Direct helper calls; regular space after the glyph.
PH='<optional custom summarization instructions>'
ELL="$(python3 -B -c 'print("\u2026")')"
TYPED_PH="/compact  ${PH}${ELL}"
ROW_PH="❯ /compact  ${PH}${ELL}"
got="$(tap_strip_claude_arg_hint "$TYPED_PH" "$ROW_PH" "57")"
[ "$got" = "$TYPED_PH" ] || fail "placeholder+ellipsis @57: expected KEEP, got '$got'"
TYPED_SUB="/compact  custom summarization instructi${ELL}"
ROW_SUB="❯ /compact  custom summarization instructi${ELL}"
got="$(tap_strip_claude_arg_hint "$TYPED_SUB" "$ROW_SUB" "43")"
[ "$got" = "$TYPED_SUB" ] || fail "substring-not-prefix @43: expected KEEP, got '$got'"
echo "claude-arg-hint: ellipsis conjuncts KEEP: ok"

# --- N5 blank-count: zero / one / three with the (full) hint ------------------
expect_keep "N5 cursor-home (zero blanks)" "$FIXTURES/claude-slash-hint-cursor-home.ansi" "80"
expect_keep "N5 cursor-left (one blank)" "$FIXTURES/claude-slash-hint-cursor-left.ansi" "80"
expect_keep "N5 cursor-left2" "$FIXTURES/claude-slash-hint-cursor-left2.ansi" "80"
expect_keep "N5 three-blanks" "$FIXTURES/claude-slash-hint-three-blanks.ansi" "80"
expect_keep "N5 hint-before-cursor" "$FIXTURES/claude-slash-hint-before-cursor.ansi" "80"
echo "claude-arg-hint: N5 blank-count: ok"

# --- N6 table conjunct: muted real draft is not a placeholder -----------------
expect_keep "N6 muted-real-draft" "$FIXTURES/claude-slash-muted-real-draft.ansi" "80"

# --- N7 remaining table/text refusals -----------------------------------------
expect_keep "N7 wording-drift" "$FIXTURES/claude-slash-hint-wording-drift.ansi" "80"
expect_keep "N7 mismatched-command" "$FIXTURES/claude-slash-mismatched-command.ansi" "80"
expect_keep "N7 bare-hint-text" "$FIXTURES/claude-slash-bare-hint-text.ansi" "80"
expect_keep "N7 typed-angle-arg" "$FIXTURES/claude-slash-typed-angle-arg.ansi" "80"
expect_keep "N7 courier-residue" "$FIXTURES/claude-slash-courier-residue.ansi" "80"
echo "claude-arg-hint: N6 N7: ok"

# --- Mutants: copy native sources, apply one wrong edit, named arm must flip --
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
cp -R "$ROOT/runtime/bun/src" "$WORK/src"
cp "$DIR/python-runtime.sh" "$WORK/python-runtime.sh"
cp -R "$DIR/python-bin" "$WORK/python-bin"

run_mutant() {
  local name="$1" sed_expr="$2" arm="$3"
  cp "$READER" "$WORK/src/pane/reader.ts"
  python3 -B - "$WORK/src/pane/reader.ts" "$sed_expr" <<'PY'
import pathlib, sys
path, needle_repl = pathlib.Path(sys.argv[1]), sys.argv[2]
old, new = needle_repl.split(">>>", 1)
text = path.read_text()
if text.count(old) != 1:
    sys.exit("mutant needle must occur exactly once: " + old[:80])
path.write_text(text.replace(old, new, 1))
PY
  ARG_HINT_READER="$WORK/src/pane/reader.ts"
  local typed row got
  case "$arm" in
    N1)
      typed="$(load_prompt "$LIVE53" | sed -n '1p')"
      row="$(load_prompt "$LIVE53" | sed -n '2p')"
      got="$(tap_strip_claude_arg_hint "$typed" "$row" "80")"
      [ "$got" = "/compact" ] || fail "$name: expected N1 to go green (strip), got '$got'"
      ;;
    N2)
      typed="$(load_prompt "$N2" | sed -n '1p')"
      row="$(load_prompt "$N2" | sed -n '2p')"
      got="$(tap_strip_claude_arg_hint "$typed" "$row" "$N2_WIDTH")"
      [ "$got" = "/compact" ] || fail "$name: expected N2 to go green (strip), got '$got'"
      ;;
    N5)
      typed="$(load_prompt "$FIXTURES/claude-slash-hint-three-blanks.ansi" | sed -n '1p')"
      row="$(load_prompt "$FIXTURES/claude-slash-hint-three-blanks.ansi" | sed -n '2p')"
      got="$(tap_strip_claude_arg_hint "$typed" "$row" "80")"
      [ "$got" = "/compact" ] || fail "$name: expected N5/three-blanks to go green, got '$got'"
      ;;
    N6)
      typed="$(load_prompt "$FIXTURES/claude-slash-muted-real-draft.ansi" | sed -n '1p')"
      row="$(load_prompt "$FIXTURES/claude-slash-muted-real-draft.ansi" | sed -n '2p')"
      got="$(tap_strip_claude_arg_hint "$typed" "$row" "80")"
      [ "$got" = "/compact" ] || fail "$name: expected N6 to go green (strip draft), got '$got'"
      ;;
    PH57)
      got="$(tap_strip_claude_arg_hint "$TYPED_PH" "$ROW_PH" "57")"
      [ "$got" = "/compact" ] || fail "$name: expected placeholder+ellipsis @57 to go green (strip), got '$got'"
      ;;
    SUB43)
      got="$(tap_strip_claude_arg_hint "$TYPED_SUB" "$ROW_SUB" "43")"
      [ "$got" = "/compact" ] || fail "$name: expected substring-not-prefix @43 to go green (strip), got '$got'"
      ;;
    *) fail "$name: unknown arm $arm" ;;
  esac
  # Restore the production export for the next mutant.
  ARG_HINT_READER="$READER"
}

# M1 drop full-row check → N1 strips the truncated-wide row.
run_mutant "M1" \
  'if (Number.isFinite(width) && width > 0 && cells(row) === width)>>>if (true)' \
  N1
echo "claude-arg-hint: M1 drop full-row check reds N1: ok"

# M2 accept any ellipsis suffix → N2 (custum…) strips.
run_mutant "M2" \
  'if (prefix && prefix !== placeholder && placeholder.startsWith(prefix))>>>if (true)' \
  N2
echo "claude-arg-hint: M2 any-ellipsis reds N2: ok"

# Item 4: each ellipsis conjunct alone. M2 collapses both, so it cannot
# name either.
run_mutant "M2b" \
  'prefix && prefix !== placeholder && placeholder.startsWith(prefix)>>>prefix && placeholder.startsWith(prefix)' \
  PH57
echo "claude-arg-hint: M2b drop prefix!=placeholder reds placeholder+ellipsis @57: ok"

run_mutant "M2c" \
  'placeholder.startsWith(prefix)>>>placeholder.includes(prefix)' \
  SUB43
echo "claude-arg-hint: M2c startswith->in reds substring-not-prefix @43: ok"

# M3 != 2  →  < 2  so three blanks pass.
run_mutant "M3" \
  'if (blanks !== BLANKS_BEFORE_HINT)>>>if (blanks < BLANKS_BEFORE_HINT)' \
  N5
echo "claude-arg-hint: M3 blanks<2 reds N5/three-blanks: ok"

# M4 delete table lookup → N6 muted real draft strips.
run_mutant "M4" \
  'let accepted = hint === placeholder;>>>let accepted = true;' \
  N6
echo "claude-arg-hint: M4 delete table lookup reds N6: ok"

# Restore the production export after mutants before BASE-vs-HEAD.
ARG_HINT_READER="$READER"

# BASE-vs-HEAD on truecolor bytes (replaces dishonest M5). BASE at 0cf152b0
# takes (typed, escaped) and requires muted 38;2 gray. BASE@80 strips
# (restored prediction: colour never blocked production). BASE@53 KEEPS
# because the ellipsis-suffixed placeholder misses the table — asserted as
# reason, not rc: the escaped row carries 38;2;153;153;153 (HINT_FG would
# match) AND U+2026. HEAD strips both. The 256-colour file is not a BASE input.
BASE_PIN=0cf152b00274286d0231badc0c942c43ab28a9b4
if git -C "$ROOT" cat-file -e "$BASE_PIN^{commit}" 2>/dev/null; then
  git -C "$ROOT" show "$BASE_PIN:skills/tap/scripts/lib.sh" > "$WORK/lib-base.sh"
else
  # Self-contained baseline for shallow checkouts (e.g. actions/checkout@v4 depth 1).
  # Exact tap_strip_claude_arg_hint implementation from commit 0cf152b00274286d0231badc0c942c43ab28a9b4.
  cat <<'BASE_LIB_EOF' > "$WORK/lib-base.sh"
tap_strip_claude_arg_hint() {
  local typed="$1" escaped="$2"
  python3 -B - "$typed" "$escaped" <<'PY'
import re, sys

typed, escaped = sys.argv[1], sys.argv[2]
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
HINT_FG = re.compile(r"\x1b\[38;2;(\d{1,3});(\d{1,3});(\d{1,3})m")
HINTS = {
    "/compact": "<optional custom summarization instructions>",
    "/goal": "[<condition> | clear]",
    "/loop": "[interval] [prompt]",
    "/clear": "[name]",
}
MUTED_LO, MUTED_HI = 96, 176
BLANKS_BEFORE_HINT = 2


def refuse():
    sys.stdout.write(typed)
    sys.exit(0)


tail = escaped.rstrip()
m = None
for cand in HINT_FG.finditer(tail):
    m = cand
if m is None:
    refuse()

r, g, b = (int(x) for x in m.groups())
if not (r == g == b and MUTED_LO <= r <= MUTED_HI):
    refuse()

rest = tail[m.end():]
if ANSI.search(re.sub(r"(?:\x1b\[(?:0|39|49|22|27)?m)+$", "", rest)):
    refuse()
hint_plain = ANSI.sub("", rest)
if not hint_plain.strip():
    refuse()

pre = ANSI.sub("", tail[:m.start()])
blanks = len(pre) - len(pre.rstrip(" "))
if blanks != BLANKS_BEFORE_HINT:
    refuse()

command = pre.strip().strip("\u276f\u203a").strip()
if HINTS.get(command) != hint_plain.strip():
    refuse()

if not typed.endswith(hint_plain):
    refuse()
remainder = typed[: -len(hint_plain)].rstrip()
if remainder != command:
    refuse()
sys.stdout.write(remainder)
PY
}
BASE_LIB_EOF
fi
grep -q 'HINT_FG' "$WORK/lib-base.sh" || fail "BASE helper missing HINT_FG"

run_base() {
  local typed="$1" escaped="$2"
  (
    # shellcheck disable=SC1090
    . "$WORK/lib-base.sh"
    tap_strip_claude_arg_hint "$typed" "$escaped"
  )
}

esc53="$(load_escaped_prompt "$LIVE53")"
python3 -B -c 'import sys
s=sys.argv[1]
assert "38;2;153;153;153" in s, "BASE@53 reason: escaped 53 lacks 38;2;153;153;153 (HINT_FG would not match — wrong render)"
assert "\u2026" in s, "BASE@53 reason: escaped 53 lacks U+2026"
assert "38;5;" not in s, "BASE@53 reason: escaped 53 still has 38;5 (wrong render)"
' "$esc53" || fail "BASE@53 reason assertion failed"
esc80="$(load_escaped_prompt "$LIVE80")"
python3 -B -c 'import sys
s=sys.argv[1]
assert "38;2;153;153;153" in s, "BASE@80 reason: escaped 80 lacks 38;2;153;153;153"
assert "38;5;" not in s, "BASE@80 reason: escaped 80 still has 38;5 (wrong render)"
' "$esc80" || fail "BASE@80 reason assertion failed"

typed80="$(load_prompt "$LIVE80" | sed -n '1p')"
got80="$(run_base "$typed80" "$esc80")"
[ "$got80" = "/compact" ] || fail "BASE@80 truecolor should strip, got '$got80'"

typed53="$(load_prompt "$LIVE53" | sed -n '1p')"
got53="$(run_base "$typed53" "$esc53")"
[ "$got53" = "$typed53" ] || fail "BASE@53 truecolor should KEEP (ellipsis misses table), got '$got53'"

expect_strip "HEAD strip live 53 truecolor" "$LIVE53" "53" "/compact"
expect_strip "HEAD strip live 80 truecolor" "$LIVE80" "80" "/compact"
echo "claude-arg-hint: BASE-vs-HEAD truecolor reason-bearing: ok"

echo "claude-arg-hint: ok"
