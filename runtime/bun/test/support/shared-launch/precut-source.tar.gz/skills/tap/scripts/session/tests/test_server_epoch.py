"""tap-24f: server-epoch guard for pane-bearing registry rows.

tmux pane ids (%N) and session ids ($N) are unique only within ONE server
lifetime. The keeper LaunchAgent rebirths the server after any death, so an id
captured before the death routinely resolves on the new server to a live but
UNRELATED pane — the 2026-07-24 incident: a stored id made the launcher claim
"session tap/fable is live in demo-app/opus", and the collision path minted
tap/sol-2 against a ghost row whose recycled id read as alive.

The guard: every pane-bearing write stamps server_epoch ("srv:<pid>:<start>",
both facts from one tmux probe). Readers void a row's stored ids when its
stamp names a PRIOR epoch (both epochs known — a failed probe disables the
guard, it never condemns). Unstamped rows cannot be epoch-checked, so a
numeric id may not OVERRIDE stored session provenance when the two disagree:
name provenance wins on the revival paths (Ops's directive — revival resolves
by session NAME, never a stored numeric id).
"""

import importlib.machinery
import importlib.util
import json
import os
import pathlib
import tempfile
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_loader(
    "launcher",
    importlib.machinery.SourceFileLoader("launcher", str(ROOT / "launcher.py")),
)
launcher = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(launcher)

CORPSE_SPEC = importlib.util.spec_from_loader(
    "seat_corpse",
    importlib.machinery.SourceFileLoader("seat_corpse", str(ROOT / "seat_corpse.py")),
)
seat_corpse = importlib.util.module_from_spec(CORPSE_SPEC)
CORPSE_SPEC.loader.exec_module(seat_corpse)

OLD = "srv:111:1000"
NEW = "srv:222:2000"


def facts(pane, pane_id, command="claude", server_epoch=NEW):
    # tap-ua9l: a real observation carries the generation it was taken under in
    # the SAME record, and these fixtures run with TAP_SERVER_EPOCH=NEW — so
    # NEW is what a live capture looks like here, not a convenience default.
    return launcher.PaneFacts(pane=pane, pane_id=pane_id, command=command,
                              path="/repo", server_epoch=server_epoch)


class ServerEpochPrimitiveTests(unittest.TestCase):
    def test_override_is_honoured_live_and_empty_means_unknown(self):
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": OLD}):
            self.assertEqual(launcher.current_server_epoch(), OLD)
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
            self.assertEqual(launcher.current_server_epoch(), NEW)
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": ""}):
            self.assertIsNone(launcher.current_server_epoch())

    def test_probe_formats_pid_and_start_time_from_one_observation(self):
        completed = mock.Mock(returncode=0, stdout="75847:1784917840\n")
        with mock.patch.dict(os.environ, {}, clear=False), \
             mock.patch.object(seat_corpse.subprocess, "run", return_value=completed) as run:
            os.environ.pop("TAP_SERVER_EPOCH", None)
            self.assertEqual(seat_corpse.server_epoch_now(), "srv:75847:1784917840")
        run.assert_called_once()
        argv = run.call_args[0][0]
        self.assertEqual(
            argv,
            seat_corpse.tmux_command("display-message", "-p", "#{pid}:#{start_time}"),
        )

    def test_probe_failure_means_unknown_never_a_verdict(self):
        completed = mock.Mock(returncode=1, stdout="", stderr="no server")
        with mock.patch.dict(os.environ, {}, clear=False), \
             mock.patch.object(seat_corpse.subprocess, "run", return_value=completed):
            os.environ.pop("TAP_SERVER_EPOCH", None)
            self.assertIsNone(seat_corpse.server_epoch_now())

    def test_epoch_voided_ids_requires_both_epochs_known(self):
        entry = {"pane_id": "%5", "pane": "tap/fable:1.1", "server_epoch": OLD}
        self.assertEqual(seat_corpse.epoch_voided_ids(entry, NEW), ("", ""))
        self.assertEqual(seat_corpse.epoch_voided_ids(entry, OLD), ("%5", "tap/fable:1.1"))
        # A caller that cannot know the current epoch merely errs toward
        # today's semantics — the guard disables, it never voids.
        self.assertEqual(seat_corpse.epoch_voided_ids(entry, None), ("%5", "tap/fable:1.1"))
        unstamped = {"pane_id": "%5", "pane": "tap/fable:1.1"}
        self.assertEqual(seat_corpse.epoch_voided_ids(unstamped, NEW), ("%5", "tap/fable:1.1"))


class BootSessionPrimitiveTests(unittest.TestCase):
    def test_macos_probe_prefers_stable_boot_session_uuid(self):
        def probe(argv, **_kwargs):
            if argv[-1] == "kern.bootsessionuuid":
                return mock.Mock(
                    returncode=0,
                    stdout="7D669766-8A0C-4A4D-9B80-A2476810F46C\n",
                )
            return mock.Mock(
                returncode=0,
                stdout="{ sec = 1785910737, usec = 900000 }\n",
            )

        with mock.patch.object(launcher.subprocess, "run", side_effect=probe) as run:
            self.assertEqual(
                launcher._probe_boot_id(),
                "bootuuid:7d669766-8a0c-4a4d-9b80-a2476810f46c",
            )
        self.assertEqual(run.call_count, 1)

    def test_legacy_boot_second_accepts_slew_but_not_a_real_mismatch(self):
        current = "bootuuid:7d669766-8a0c-4a4d-9b80-a2476810f46c"
        self.assertTrue(launcher.boot_ids_match("boot:1785910737", current, "boot:1785910738"))
        self.assertFalse(launcher.boot_ids_match("boot:1785910700", current, "boot:1785910738"))
        self.assertFalse(
            launcher.boot_ids_match(
                "bootuuid:11111111-1111-4111-8111-111111111111",
                current,
                "boot:1785910738",
            )
        )


class EntryVerifiedSessionNameTests(unittest.TestCase):
    """The alive-elsewhere claim behind 'tap/fable is live in demo-app/opus'."""

    def test_stale_epoch_voids_the_resolving_id(self):
        entry = {"session": "tap/fable", "pane_id": "%5", "pane": "tap/fable:1.1",
                 "server_epoch": OLD}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("demo-app/opus:1.1", "%5")):
            self.assertIsNone(launcher.entry_verified_session_name(entry))

    def test_unstamped_id_may_not_override_stored_provenance(self):
        entry = {"session": "tap/fable", "pane_id": "%5", "pane": "tap/fable:1.1"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("demo-app/opus:1.1", "%5")):
            self.assertIsNone(launcher.entry_verified_session_name(entry))

    def test_same_epoch_keeps_fork_protection_exact(self):
        # Within one epoch a resolving id IS the seat — a genuine fork/rename
        # must still be claimed, disagreement with provenance included.
        entry = {"session": "tap/fable", "pane_id": "%5", "pane": "tap/fable:1.1",
                 "server_epoch": NEW}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/fable-fork:1.1", "%5")):
            self.assertEqual(launcher.entry_verified_session_name(entry), "tap/fable-fork")

    def test_unknown_current_epoch_disables_the_guard(self):
        # tap-bzyz: this fixture must state server_epoch="" explicitly. The
        # helper defaults to NEW, and once the verifier began reading the
        # generation off the SAME record (rather than only the separate probe),
        # a NEW-stamped record against an OLD-stamped row became POSITIVE
        # evidence of a replacement — which correctly refuses, and would have
        # made this test assert the opposite of its own name. "Unknown" has to
        # mean unknown on BOTH sources for the fail-open contract to be the
        # thing under test.
        entry = {"session": "tap/fable", "pane_id": "%5", "pane": "tap/fable:1.1",
                 "server_epoch": OLD}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": ""}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/fable:1.1", "%5", server_epoch="")):
            self.assertEqual(launcher.entry_verified_session_name(entry), "tap/fable")

    def test_unstamped_agreement_still_verifies(self):
        entry = {"session": "tap/fable", "pane_id": "%5", "pane": "tap/fable:1.1"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/fable:1.1", "%5")):
            self.assertEqual(launcher.entry_verified_session_name(entry), "tap/fable")

    def test_unstamped_without_provenance_keeps_legacy_behavior(self):
        entry = {"pane_id": "%5", "pane": "tap/fable:1.1"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("demo-app/opus:1.1", "%5")):
            self.assertEqual(launcher.entry_verified_session_name(entry), "demo-app/opus")


class EntrySessionNameTests(unittest.TestCase):
    def test_stale_epoch_falls_back_to_stored_provenance(self):
        entry = {"session": "tap/fable", "pane_id": "%5", "pane": "tap/fable:1.1",
                 "server_epoch": OLD}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("demo-app/opus:1.1", "%5")) as probe:
            self.assertEqual(launcher.entry_session_name(entry), "tap/fable")
        # Voided ids are not probed: the stale id must not even be dereferenced.
        for call in probe.call_args_list:
            self.assertNotIn("%5", call.args)

    def test_unstamped_disagreement_prefers_stored_provenance(self):
        entry = {"session": "tap/fable", "pane_id": "%5", "pane": "tap/fable:1.1"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("demo-app/opus:1.1", "%5")):
            self.assertEqual(launcher.entry_session_name(entry), "tap/fable")

    def test_same_epoch_keeps_pane_first_rename_tracking(self):
        entry = {"session": "repo/stale", "pane_id": "%7", "pane": "repo/live:0.0",
                 "server_epoch": NEW}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("repo/live:0.0", "%7")):
            self.assertEqual(launcher.entry_session_name(entry), "repo/live")


class EntryObservedDeadTests(unittest.TestCase):
    """The ghost row behind the tap/sol-2 mint: its recycled id resolves, so
    entry_observed_dead said False and the collision ladder refused to absorb."""

    def _no_session(self, name):
        return False

    def test_stale_epoch_row_with_resolving_id_and_dead_name_is_dead(self):
        entry = {"session": "tap/sol", "pane_id": "%5", "pane": "tap/sol:1.1",
                 "server_epoch": OLD, "harness": "codex"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("keeper:0.0", "%5", command="zsh")), \
             mock.patch.object(launcher, "tmux_has", side_effect=self._no_session):
            self.assertTrue(launcher.entry_observed_dead(entry))

    def test_unstamped_row_with_disagreeing_id_and_dead_name_is_dead(self):
        entry = {"session": "tap/sol", "pane_id": "%5", "pane": "tap/sol:1.1",
                 "harness": "codex"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("keeper:0.0", "%5", command="zsh")), \
             mock.patch.object(launcher, "tmux_has", side_effect=self._no_session):
            self.assertTrue(launcher.entry_observed_dead(entry))

    def test_stale_epoch_row_whose_session_name_is_live_stays_protected(self):
        entry = {"session": "tap/sol", "pane_id": "%5", "pane": "tap/sol:1.1",
                 "server_epoch": OLD, "harness": "codex"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("keeper:0.0", "%5", command="zsh")), \
             mock.patch.object(launcher, "tmux_has", return_value=True), \
             mock.patch.object(launcher, "classify_session", return_value="live"):
            self.assertFalse(launcher.entry_observed_dead(entry))

    def test_same_epoch_resolving_id_stays_protected(self):
        entry = {"session": "tap/sol", "pane_id": "%5", "pane": "tap/sol:1.1",
                 "server_epoch": NEW, "harness": "codex"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/sol:1.1", "%5", command="codex")):
            self.assertFalse(launcher.entry_observed_dead(entry))


class ReclaimableCorpseTests(unittest.TestCase):
    def test_stale_epoch_absent_name_keeps_its_recovery_pointer(self):
        entry = {"session": "tap/sol", "pane_id": "%5", "pane": "tap/sol:1.1",
                 "server_epoch": OLD, "harness": "codex", "status": "active"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
            # The id is void and the name is absent, but that absence belongs
            # to a later server generation. The row is OFFLINE, not GONE, so
            # its native-resume pointer remains reserved.
            self.assertFalse(launcher.seat_is_reclaimable_corpse(entry, live_sessions=set()))

    def test_stale_epoch_ghost_with_live_name_keeps_it(self):
        entry = {"session": "tap/sol", "pane_id": "%5", "pane": "tap/sol:1.1",
                 "server_epoch": OLD, "harness": "codex", "status": "active"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
            self.assertFalse(
                launcher.seat_is_reclaimable_corpse(entry, live_sessions={"tap/sol"})
            )

    def test_unstamped_current_absence_releases_name_even_if_id_resolves(self):
        entry = {"session": "tap/sol", "pane_id": "%5", "pane": "tap/sol:1.1",
                 "harness": "codex", "status": "active"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "seat_pane_probe",
                               return_value=launcher.SEAT_ALIVE):
            # A readable current snapshot positively omitted the exact name.
            # An unrelated resolving id is not authority to retain it.
            self.assertTrue(launcher.seat_is_reclaimable_corpse(entry, live_sessions=set()))


class DestructiveTargetTests(unittest.TestCase):
    """tap-24f fix wave (grok finding 1, sol finding 6 — the CAPTURED incident).

    Readers fail OPEN on an unknown epoch (availability). A session-TERMINATING
    decision must fail CLOSED: an id it cannot prove belongs to the current
    server may name a live teammate's session. The 2026-07-24 capture is the
    chooser [k] path — an unstamped row with no session provenance whose
    recycled id resolves onto a bystander, handed to kill-session.

    RATIFIED NAME-FALLBACK SEMANTICS (sol, 2026-07-25, payload
    sol-20260725T033054Z-39b09c4aea77). For an unproven or voided stored id,
    exact-name destructive fallback is authorized IFF all three hold:
      1. the row still carries a stable `pane_id` (an address-only or pane-less
         row keeps the OLD refusal — no widening);
      2. `entry["session"]` EXACTLY equals the canonical session the CALLER
         derived independently from the current team and the TARGET handle —
         never read off the row, never a "contains a slash" heuristic;
      3. that exact name is live, both at authorization and at the caller's
         pre-action re-check.
    Epoch-proven rows keep id-anchored legacy behavior, noncanonical session
    names included. The matrix below is that ruling, case by case.
    """

    def test_epoch_proven_requires_stamp_and_observable_now(self):
        self.assertTrue(seat_corpse.epoch_proven({"server_epoch": NEW}, NEW))
        self.assertFalse(seat_corpse.epoch_proven({"server_epoch": OLD}, NEW))
        self.assertFalse(seat_corpse.epoch_proven({"server_epoch": NEW}, None))
        self.assertFalse(seat_corpse.epoch_proven({}, NEW))
        self.assertFalse(seat_corpse.epoch_proven(None, NEW))

    def test_unstamped_row_without_provenance_never_names_a_target(self):
        # THE captured incident: old opus id recycled onto live fable. The row
        # carries no session provenance at all, so nothing can vouch for it.
        entry = {"pane_id": "%6", "pane": "tap/opus:1.1"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/fable:1.1", "%6")):
            self.assertIsNone(
                launcher.destructive_session_target(entry, "tap/opus"))

    def test_stale_stamped_row_with_canonical_live_name_may_be_terminated(self):
        # Ops: stop by name; epoch mismatch alone does not refuse.
        entry = {"pane_id": "%6", "pane": "tap/opus:1.1", "server_epoch": OLD,
                 "session": "tap/opus"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=True), \
             mock.patch.object(launcher, "tmux_session_pane_ids",
                               return_value=["%6"]), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/opus:1.1", "%6")):
            self.assertEqual(
                launcher.destructive_session_target(entry, "tap/opus"), "tap/opus")

    def test_stale_stamped_row_whose_named_session_is_gone_names_nothing(self):
        entry = {"pane_id": "%6", "pane": "tap/opus:1.1", "server_epoch": OLD,
                 "session": "tap/opus"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=False):
            self.assertIsNone(
                launcher.destructive_session_target(entry, "tap/opus"))

    def test_stamped_row_with_unobservable_now_may_still_authorize_by_name(self):
        entry = {"pane_id": "%6", "pane": "tap/opus:1.1", "server_epoch": OLD,
                 "session": "tap/opus"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": ""}), \
             mock.patch.object(launcher, "tmux_has", return_value=True), \
             mock.patch.object(launcher, "tmux_session_pane_ids",
                               return_value=["%6"]), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/opus:1.1", "%6")):
            self.assertEqual(
                launcher.destructive_session_target(entry, "tap/opus"), "tap/opus")

    def test_unproven_row_with_live_name_provenance_may_be_terminated(self):
        # Ops: name+live authorizes; epoch stamp not required.
        entry = {"pane_id": "%6", "pane": "tap/opus:1.1", "session": "tap/opus"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=True), \
             mock.patch.object(launcher, "tmux_session_pane_ids",
                               return_value=["%6"]), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/opus:1.1", "%6")):
            self.assertEqual(
                launcher.destructive_session_target(entry, "tap/opus"), "tap/opus")

    def test_unproven_row_whose_named_session_is_gone_names_nothing(self):
        entry = {"pane_id": "%6", "pane": "tap/opus:1.1", "session": "tap/opus"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=False):
            self.assertIsNone(
                launcher.destructive_session_target(entry, "tap/opus"))

    def test_unproven_row_naming_an_ambient_live_session_names_nothing(self):
        # RATIFIED case 2 — ambient live REFUSES. `keeper` is a real live tmux
        # session, but it is not this seat's canonical name, so an unproven row
        # pointing at it may not hand it to kill-session. Liveness alone never
        # authorizes; canonicality does.
        entry = {"pane_id": "%6", "pane": "keeper:0.0", "session": "keeper"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=True):
            self.assertIsNone(
                launcher.destructive_session_target(entry, "tap/opus"))

    def test_unproven_row_naming_another_seat_names_nothing(self):
        # RATIFIED case 3 — wrong-handle REFUSES, and it must refuse on the
        # EXACT-equality rule, not on a "looks like a session name" heuristic:
        # `tap/fable` is slash-shaped, live, and still the wrong seat.
        entry = {"pane_id": "%6", "pane": "tap/fable:1.1", "session": "tap/fable"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=True):
            self.assertIsNone(
                launcher.destructive_session_target(entry, "tap/opus"))

    def test_unproven_row_without_stable_pane_identity_names_nothing(self):
        # RATIFIED case 4 — pane-address-only residue keeps the OLD refusal
        # even when its session name is canonical and live (no widening).
        entry = {"pane": "tap/opus:1.1", "session": "tap/opus"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=True):
            self.assertIsNone(
                launcher.destructive_session_target(entry, "tap/opus"))

    def test_fallback_needs_a_caller_derived_expectation(self):
        # A caller with no canonical expectation to offer gets no fallback: the
        # authorization is fail-closed, so an absent expectation is a refusal,
        # never a wildcard.
        entry = {"pane_id": "%6", "pane": "tap/opus:1.1", "session": "tap/opus"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=True):
            self.assertIsNone(launcher.destructive_session_target(entry, None))
            self.assertIsNone(launcher.destructive_session_target(entry, ""))

    def test_fallback_requires_the_exact_pane_id_grammar(self):
        # The stable-identity precondition is a GRAMMAR test, not a truthiness
        # test (gate review, tap-24f). `%bogus` is a garbled observation
        # channel, never an identity — `seat_corpse.is_pane_id` is the single
        # authority on that grammar and every observer already consults it — so
        # a row carrying one has no more stable identity than a pane-less row
        # and keeps the same refusal. Non-string junk is refused for the same
        # reason.
        for junk in ("%bogus", "%", "%1x", "1", "", 6, None):
            entry = {"pane_id": junk, "pane": "tap/opus:1.1", "session": "tap/opus"}
            with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
                 mock.patch.object(launcher, "tmux_has", return_value=True):
                self.assertIsNone(
                    launcher.destructive_session_target(entry, "tap/opus"),
                    f"pane_id {junk!r} is not the tmux pane-id grammar")

    def test_proven_row_with_pane_live_elsewhere_refuses(self):
        # E2 / Amendment 9: same-epoch stored id alive on a FOREIGN session —
        # name-first refuses (the old id-anchored arm returned the foreign name).
        entry = {"pane_id": "%6", "pane": "tap/opus:1.1", "server_epoch": NEW,
                 "session": "tap/opus"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=True), \
             mock.patch.object(launcher, "tmux_session_pane_ids",
                               return_value=["%7"]), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/fable:1.1", "%6")):
            self.assertIsNone(
                launcher.destructive_session_target(entry, "tap/opus"))

    def test_proven_row_name_keyed_aligned_authorizes(self):
        # Happy path: registry session == expected, name live, pane member.
        entry = {"pane_id": "%6", "pane": "tap/opus:1.1", "server_epoch": NEW,
                 "session": "tap/opus"}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_has", return_value=True), \
             mock.patch.object(launcher, "tmux_session_pane_ids",
                               return_value=["%6"]), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=facts("tap/opus:1.1", "%6")):
            self.assertEqual(
                launcher.destructive_session_target(entry, "tap/opus"),
                "tap/opus")






class WriteSiteStampTests(unittest.TestCase):
    def test_bind_reserved_handle_stamps_server_epoch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            (root / ".tap" / "bus").mkdir(parents=True)
            record = launcher.SessionRecord(
                name=f"{root.name}/scout", harness="claude", cwd=str(root),
                base=root.name, tag="scout", index=1,
            )
            with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
                launcher.claim_pending_handle(record)
                launcher.bind_reserved_handle(
                    record, facts(f"{root.name}/scout:0.0", "%9")
                )
            reg = json.loads((root / ".tap" / "bus" / "registry.json").read_text())
            self.assertEqual(reg["agents"]["scout"]["server_epoch"], NEW)

    def test_bind_reserved_handle_refreshes_boot_id_on_active_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            (root / ".tap" / "bus").mkdir(parents=True)
            record = launcher.SessionRecord(
                name=f"{root.name}/scout", harness="claude", cwd=str(root),
                base=root.name, tag="scout", index=1,
            )
            with mock.patch.object(launcher, "current_boot_id", return_value="boot:reservation"):
                launcher.claim_pending_handle(record)
            with mock.patch.object(launcher, "current_boot_id", return_value="boot:bound"), \
                 mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
                launcher.bind_reserved_handle(record, facts(f"{root.name}/scout:0.0", "%9"))
            reg = json.loads((root / ".tap" / "bus" / "registry.json").read_text())
            self.assertEqual(reg["agents"]["scout"]["boot_id"], "boot:bound")

    def test_mark_launch_ready_drops_an_unobservable_boot_stamp(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            (root / ".tap" / "bus").mkdir(parents=True)
            record = launcher.SessionRecord(
                name=f"{root.name}/scout", harness="claude", cwd=str(root),
                base=root.name, tag="scout", index=1,
            )
            with mock.patch.object(launcher, "current_boot_id", return_value="boot:bound"), \
                 mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
                launcher.claim_pending_handle(record)
                launcher.bind_reserved_handle(record, facts(f"{root.name}/scout:0.0", "%9"))
            with mock.patch.object(launcher, "current_boot_id", return_value=None), \
                 mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}):
                launcher.mark_launch_ready(record, facts(f"{root.name}/scout:0.0", "%9"))
            reg = json.loads((root / ".tap" / "bus" / "registry.json").read_text())
            self.assertNotIn("boot_id", reg["agents"]["scout"])


if __name__ == "__main__":
    unittest.main()


class SameRecordGenerationTests(unittest.TestCase):
    """tap-bzyz: the verifier read the generation and the pane identity as TWO
    observations, so a server replacement landing between them let it return
    the REPLACEMENT server's session while gated on the EARLIER generation.

    The fix is nearly free: tmux_pane_facts already carries the generation the
    ids were observed under, on the SAME record (PANE_FACTS_FORMAT asks tmux
    for #{pid}:#{start_time} alongside the ids), and the function ignored it.
    """

    def _facts_from_replacement_server(self):
        # Same numeric id, recycled by the replacement server onto a stranger's
        # session, and carrying THAT server's generation on its own record.
        return launcher.PaneFacts(
            pane="other/fable:1.1", pane_id="%5", command="claude",
            path="/repo", server_epoch=NEW,
        )

    def test_replacement_server_session_is_not_returned_under_the_earlier_generation(self):
        entry = {"session": "tap/opus", "pane_id": "%5", "pane": "tap/opus:1.1",
                 "server_epoch": OLD}
        # The separately-read generation still says OLD — the replacement landed
        # after that read and before the identity read.
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": OLD}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=self._facts_from_replacement_server()):
            self.assertIsNone(launcher.entry_verified_session_name(entry))

    def test_destructive_wrapper_refuses_the_same_shape(self):
        entry = {"session": "tap/opus", "pane_id": "%5", "pane": "tap/opus:1.1",
                 "server_epoch": OLD}
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": OLD}), \
             mock.patch.object(launcher, "tmux_pane_facts",
                               return_value=self._facts_from_replacement_server()):
            self.assertIsNone(launcher.destructive_session_target(entry, "tap/opus"))

    def test_empty_record_generation_refuses_for_the_AUTHORIZER_only(self):
        # PaneFacts defaults server_epoch to "" and parse_pane_facts ends its
        # assignment with `or ""`, so a live identity carrying NO generation is
        # reachable. Decided on purpose, and the decision SPLITS BY ROLE:
        # an authorizer refuses what it cannot verify, while the same function
        # used as a DETECTOR stays fail-open, because observed_server_epoch
        # honours TAP_SERVER_EPOCH and a force-unknown pin empties the record —
        # refusing there would silently convert tap-24f's ratified reader
        # semantics into fail-closed, which is not this lane's to change.
        entry = {"session": "tap/opus", "pane_id": "%5", "pane": "tap/opus:1.1",
                 "server_epoch": OLD}
        blank = launcher.PaneFacts(pane="tap/opus:1.1", pane_id="%5",
                                   command="claude", path="/repo", server_epoch="")
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": OLD}), \
             mock.patch.object(launcher, "tmux_pane_facts", return_value=blank), \
             mock.patch.object(launcher, "tmux_has", return_value=True):
            self.assertIsNone(
                launcher.entry_verified_session_name(entry, require_observed_generation=True)
            )
            # ...and the detector is deliberately unchanged.
            self.assertEqual(launcher.entry_verified_session_name(entry), "tap/opus")

    def test_GREEN_GUARD_same_generation_record_still_resolves(self):
        # The guard that makes the reds meaningful: when the record's own
        # generation agrees with the row's, the seat still resolves — including
        # to a NONCANONICAL name, which the proven arm is entitled to do.
        entry = {"session": "tap/opus", "pane_id": "%5", "pane": "tap/opus:1.1",
                 "server_epoch": OLD}
        same = launcher.PaneFacts(pane="tap/opus-fork:1.1", pane_id="%5",
                                  command="claude", path="/repo", server_epoch=OLD)
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": OLD}), \
             mock.patch.object(launcher, "tmux_pane_facts", return_value=same):
            self.assertEqual(launcher.entry_verified_session_name(entry), "tap/opus-fork")

    def test_GREEN_GUARD_unstamped_row_behavior_is_untouched(self):
        # tap-zk1w's carve-out: a row making NO generation claim is governed by
        # the unstamped-row policy, which this lane does not decide.
        entry = {"session": "tap/opus", "pane_id": "%5", "pane": "tap/opus:1.1"}
        same = launcher.PaneFacts(pane="tap/opus:1.1", pane_id="%5",
                                  command="claude", path="/repo", server_epoch=NEW)
        with mock.patch.dict(os.environ, {"TAP_SERVER_EPOCH": NEW}), \
             mock.patch.object(launcher, "tmux_pane_facts", return_value=same):
            self.assertEqual(launcher.entry_verified_session_name(entry), "tap/opus")
