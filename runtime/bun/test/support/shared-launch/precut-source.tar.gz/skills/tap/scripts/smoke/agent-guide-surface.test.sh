#!/usr/bin/env bash
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
VALIDATOR="$ROOT/runtime/bun/src/validate-agent-guide.ts"

bun "$VALIDATOR" "$ROOT"

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

# Copy every git-tracked file once: with byte-freezing gone, a structural
# check (reachability, bounds, named routes) can walk past the mutated page
# into any other real link — an incomplete sandbox would misreport that as
# the injected defect instead of a sandbox gap. Tracked-only (not "$ROOT"/*)
# so untracked scratch (tmp/<seat>/, ignored build output) never rides along.
git -C "$ROOT" ls-files -z | tar -C "$ROOT" -c --null -T - -f - | tar -C "$WORK" -xf -

# Positive control: Unicode letters/numbers, per-space and duplicate anchors,
# quoted TSV fields containing quotes/tabs, and BOM as a word character.
python3 - "$WORK" <<'PY'
import csv
from pathlib import Path
import sys
root = Path(sys.argv[1])
page = 'skills/tap/protocol/delivery/sentinel-the-wire-poke-zero-authority-part-01.md'
heading = 'CAFÉ  β²_ — "quoted"\tß'
physical = root / 'fixture-physical'
(physical / 'nested').mkdir(parents=True)
(physical / 'leaf.md').write_text('# Physical link\n')
(root / page).parent.joinpath('fixture-link').symlink_to(physical / 'nested', target_is_directory=True)
with (root / page).open('a') as f:
    f.write(f'\n# {heading}\n# {heading}\n')
    f.write('[Symlink parent](fixture-link/../leaf.md)\n')
mapping = root / 'docs/artifacts/agent-guide-migration-map.tsv'
header = next(line for line in mapping.read_text().splitlines() if line.startswith('record_type\t')).split('\t')
with mapping.open('a', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=header, delimiter='\t', quoting=csv.QUOTE_ALL)
    for n, anchor in enumerate(('café--β²_--quotedß', 'café--β²_--quotedß-1')):
        writer.writerow(dict(record_type='anchor', source_id=f'fixture-{n}', new_path=page, new_heading=heading, new_anchor=anchor))
(root / 'skills/tap/scripts/CONTRACT.md').write_text('w\ufeffw ' * 600)
PY
bun "$VALIDATOR" "$WORK"
cp "$ROOT/skills/tap/protocol/delivery/sentinel-the-wire-poke-zero-authority-part-01.md" "$WORK/skills/tap/protocol/delivery/sentinel-the-wire-poke-zero-authority-part-01.md"
cp "$ROOT/docs/artifacts/agent-guide-migration-map.tsv" "$WORK/docs/artifacts/agent-guide-migration-map.tsv"
cp "$ROOT/skills/tap/scripts/CONTRACT.md" "$WORK/skills/tap/scripts/CONTRACT.md"

# Negative control 1: a missing routed page must fail reachability/link validation.
python3 - "$WORK/skills/tap/GUIDE.md" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1]); p.write_text(p.read_text().replace('protocol/messages/reading-your-own-mail-tap-read-v0-23-part-01.md', 'protocol/messages/missing.md', 1))
PY
if bun "$VALIDATOR" "$WORK" >"$WORK/link-mutant.out" 2>&1; then
  echo "FAIL: agent-guide-surface: broken-link mutant survived" >&2
  exit 1
fi
grep -q 'broken local link' "$WORK/link-mutant.out"

# Negative control 2: removing a closing fence must unbalance that page's fences.
cp "$ROOT/skills/tap/GUIDE.md" "$WORK/skills/tap/GUIDE.md"
python3 - "$WORK/skills/tap/protocol/delivery/cli-surface-the-whole-thing-part-03.md" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1]); raw = p.read_bytes(); suffix = b'\n```\n'; assert raw.endswith(suffix); p.write_bytes(raw[:-len(suffix)])
PY
if bun "$VALIDATOR" "$WORK" >"$WORK/fence-mutant.out" 2>&1; then
  echo "FAIL: agent-guide-surface: unbalanced-fence mutant survived" >&2
  exit 1
fi
grep -q 'unbalanced Markdown fence' "$WORK/fence-mutant.out"

# Negative control 3: mapped anchors must be real headings outside code fences.
cp "$ROOT/skills/tap/protocol/delivery/cli-surface-the-whole-thing-part-03.md" "$WORK/skills/tap/protocol/delivery/cli-surface-the-whole-thing-part-03.md"
python3 - "$WORK/docs/artifacts/agent-guide-migration-map.tsv" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1]); lines = p.read_text().splitlines(); header = next(line for line in lines if line.startswith('record_type\t')).split('\t'); index = header.index('new_anchor')
for n, line in enumerate(lines):
    fields = line.split('\t')
    if fields[:2] == ['anchor', 'anchor-0047']:
        fields[index] = 'reviewer-proven-nonexistent-anchor'; lines[n] = '\t'.join(fields); break
else: raise AssertionError('anchor-0047 missing')
p.write_text('\n'.join(lines) + '\n')
PY
if bun "$VALIDATOR" "$WORK" >"$WORK/anchor-mutant.out" 2>&1; then
  echo "FAIL: agent-guide-surface: nonexistent-anchor mutant survived" >&2
  exit 1
fi
grep -q 'anchor destination missing or fenced' "$WORK/anchor-mutant.out"

# Negative control 4: measure UTF-8 bytes and Python's Unicode word boundaries.
cp "$ROOT/docs/artifacts/agent-guide-migration-map.tsv" "$WORK/docs/artifacts/agent-guide-migration-map.tsv"
python3 - "$WORK/skills/tap/scripts/CONTRACT.md" <<'PY'
from pathlib import Path
import sys
Path(sys.argv[1]).write_text('é' * 2048 + 'x')
PY
if bun "$VALIDATOR" "$WORK" >"$WORK/bounds-mutant.out" 2>&1; then
  echo "FAIL: agent-guide-surface: oversized-contract mutant survived" >&2
  exit 1
fi
grep -q 'CONTRACT exceeds 4096 bytes: 4097' "$WORK/bounds-mutant.out"
python3 - "$WORK/skills/tap/scripts/CONTRACT.md" <<'PY'
from pathlib import Path
import sys
Path(sys.argv[1]).write_text('w\x1f' * 601)
PY
if bun "$VALIDATOR" "$WORK" >"$WORK/words-mutant.out" 2>&1; then
  echo "FAIL: agent-guide-surface: word-limit mutant survived" >&2
  exit 1
fi
grep -q 'CONTRACT exceeds 600 words: 601' "$WORK/words-mutant.out"

# Malformed UTF-8 must not be silently decoded with replacement characters.
printf '\377' >"$WORK/skills/tap/scripts/CONTRACT.md"
if bun "$VALIDATOR" "$WORK" >"$WORK/encoding-mutant.out" 2>&1; then
  echo "FAIL: agent-guide-surface: malformed-UTF-8 mutant survived" >&2
  exit 1
fi

echo "agent-guide-surface: negative controls: ok"
