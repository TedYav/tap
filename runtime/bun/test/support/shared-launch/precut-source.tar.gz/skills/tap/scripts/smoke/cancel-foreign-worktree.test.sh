#!/usr/bin/env bash
# cancel-foreign-worktree.test.sh — foreign cancel via pre-flip worktree scan.
#
# Pins the e929a79f hole that left tap_authority_context's absent-foreign arm
# teams.json-only: send smokes went green once the helper learned worktree
# fallback, but cancel at tap-cancel.sh:132 had the same hole and nothing
# covered it. Fixture: marker absent, RemoteTeam NOT in teams.json, sibling
# worktree basename match — cancel must observe the foreign registry (gone →
# succeed), never refuse unreachable_team.
set -euo pipefail
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP="$ROOT/scripts/tap.sh"

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
export TAP_INDEX_HOME="$WORK/index"
mkdir -p "$TAP_INDEX_HOME"
# Explicitly empty — RemoteTeam is worktree-only, not indexed.
: >"$TAP_INDEX_HOME/teams.json" 2>/dev/null || true
rm -f "$TAP_INDEX_HOME/teams.json" "$TAP_INDEX_HOME/global-registry.json"

fail() { echo "cancel-foreign-worktree: $*" >&2; exit 1; }

SENDER="$WORK/SenderTeam"
REMOTE="$WORK/RemoteTeam"
git init -q "$SENDER"
git -C "$SENDER" config user.email tap1@example.net
git -C "$SENDER" config user.name "TAP Smoke"
touch "$SENDER/README.md"
git -C "$SENDER" add README.md
git -C "$SENDER" commit -q -m init
git -C "$SENDER" worktree add -q "$REMOTE" -b remote-team

mkdir -p "$SENDER/tmp/tap/payloads" "$SENDER/tmp/tap/receipts" \
         "$REMOTE/tmp/tap"
cat >"$SENDER/tmp/tap/registry.json" <<'JSON'
{
  "team": { "name": "SenderTeam" },
  "agents": {
    "alice": {
      "status": "active", "delivery": "poll", "harness": "claude",
      "registered_at": "t", "pane": "", "pane_id": ""
    }
  }
}
JSON
# Foreign seat GONE — cancel must succeed after observing this registry.
cat >"$REMOTE/tmp/tap/registry.json" <<'JSON'
{
  "team": { "name": "RemoteTeam" },
  "agents": {
    "sol": {
      "status": "active", "delivery": "poll", "harness": "codex",
      "registered_at": "t", "pane": "", "pane_id": ""
    }
  }
}
JSON

export TAP_HOME="$SENDER/tmp/tap"
export TAP_REGISTRY="$TAP_HOME/registry.json"

ID="alice-20260729T000000Z-cfwt0001"
cat >"$TAP_HOME/payloads/${ID}.md" <<EOF
---
id: $ID
from: alice
to: bob
kind: discuss
path: $TAP_HOME/payloads/${ID}.md
reply: settle-only
cross_worktree: true
from_team: SenderTeam
to_team: RemoteTeam
---
foreign cancel via worktree
EOF
: >"$TAP_HOME/receipts/${ID}.sent"

err="$(mktemp)"
set +e
out="$(cd "$SENDER" && env TAP_HOME="$TAP_HOME" TAP_INDEX_HOME="$TAP_INDEX_HOME" \
  "$TAP" cancel "$ID" --by alice 2>"$err")"
rc=$?
set -e

[ "$rc" -eq 0 ] || fail "cancel must succeed when foreign seat is gone (rc=$rc out=$out err=$(cat "$err"))"
grep -qi "cancelled" <<<"$out" \
  || fail "stdout must report cancelled; got: $out"
# The e929 surface: must NOT refuse unreachable before observing the registry.
grep -Eiq 'unreachable_team|acting registry unreachable|cannot observe team' "$err" \
  && fail "must not refuse unreachable_team (helper missed worktree); err=$(cat "$err")"
[ -f "$TAP_HOME/receipts/${ID}.cancelled" ] \
  || fail ".cancelled receipt missing"

echo "cancel-foreign-worktree: (1) gone foreign seat via worktree: ok"

# --- (2) active foreign seat still blocks (proves observation, not skip) ------
ID2="alice-20260729T000000Z-cfwt0002"
cat >"$REMOTE/tmp/tap/registry.json" <<'JSON'
{
  "team": { "name": "RemoteTeam" },
  "agents": {
    "bob": {
      "status": "active", "delivery": "poll", "harness": "codex",
      "registered_at": "t", "pane": "", "pane_id": ""
    }
  }
}
JSON
cat >"$TAP_HOME/payloads/${ID2}.md" <<EOF
---
id: $ID2
from: alice
to: bob
kind: discuss
path: $TAP_HOME/payloads/${ID2}.md
reply: settle-only
cross_worktree: true
from_team: SenderTeam
to_team: RemoteTeam
---
foreign cancel active seat
EOF
: >"$TAP_HOME/receipts/${ID2}.sent"
set +e
out2="$(cd "$SENDER" && env TAP_HOME="$TAP_HOME" TAP_INDEX_HOME="$TAP_INDEX_HOME" \
  "$TAP" cancel "$ID2" --by alice 2>"$err")"
rc2=$?
set -e
[ "$rc2" -ne 0 ] || fail "(2) active foreign seat must block cancel (got: $out2)"
grep -qiE 'seat_active|still an active' <<<"$out2$(cat "$err")" \
  || fail "(2) expected seat_active; got out=$out2 err=$(cat "$err")"
[ ! -f "$TAP_HOME/receipts/${ID2}.cancelled" ] \
  || fail "(2) must not write .cancelled while foreign seat active"
echo "cancel-foreign-worktree: (2) active foreign seat blocks: ok"

# --- (3) canonical non-regular + ABSENT legacy -> uncertainty refusal ---------
# The resolved canonical authority `.tap/bus/registry.json` EXISTS but is not a
# regular file, and the pre-flip `tmp/tap/registry.json` fallback is absent. The
# absent-file gone-escape must key on TRUE absence: a canonical path that exists
# as a directory/FIFO is uncertainty, and falling through to the absent legacy
# path would manufacture a gone verdict from a half-present authority.
mkdir -p "$REMOTE/.tap/bus/registry.json"
rm -f "${REMOTE:?}/tmp/tap/registry.json"
[ -d "$REMOTE/.tap/bus/registry.json" ] || fail "fixture: (3) needs a directory AT the canonical registry path"
ID3="alice-20260729T000000Z-cfwt0003"
cat >"$TAP_HOME/payloads/${ID3}.md" <<EOF
---
id: $ID3
from: alice
to: bob
kind: discuss
path: $TAP_HOME/payloads/${ID3}.md
reply: settle-only
cross_worktree: true
from_team: SenderTeam
to_team: RemoteTeam
---
foreign cancel, canonical registry is a directory
EOF
: >"$TAP_HOME/receipts/${ID3}.sent"
set +e
out3="$(cd "$SENDER" && env TAP_HOME="$TAP_HOME" TAP_INDEX_HOME="$TAP_INDEX_HOME" \
  "$TAP" cancel "$ID3" --by alice 2>"$err")"
rc3=$?
set -e
[ "$rc3" -ne 0 ] || fail "(3) a canonical registry that EXISTS as a directory must refuse — absence needs TRUE absence; got: $out3"
grep -q "not a regular file" <<<"$(cat "$err")" \
  || fail "(3) refusal must come from the regular-file guard; err=$(cat "$err")"
[ -f "$TAP_HOME/payloads/${ID3}.md" ] \
  || fail "(3) must not archive the payload on a refusal"
[ ! -f "$TAP_HOME/receipts/${ID3}.cancelled" ] \
  || fail "(3) must not write .cancelled for a non-regular canonical registry"
echo "cancel-foreign-worktree: (3) canonical directory + absent legacy refuses: ok"

# --- (4) canonical FIFO + ABSENT legacy -> refusal without opening ------------
rm -rf "${REMOTE:?}/.tap/bus"
mkdir -p "$REMOTE/.tap/bus"
mkfifo "$REMOTE/.tap/bus/registry.json"
[ -p "$REMOTE/.tap/bus/registry.json" ] || fail "fixture: (4) needs a FIFO at the canonical path"
ID4="alice-20260729T000000Z-cfwt0004"
cat >"$TAP_HOME/payloads/${ID4}.md" <<EOF
---
id: $ID4
from: alice
to: bob
kind: discuss
path: $TAP_HOME/payloads/${ID4}.md
reply: settle-only
cross_worktree: true
from_team: SenderTeam
to_team: RemoteTeam
---
foreign cancel, canonical registry is a FIFO
EOF
: >"$TAP_HOME/receipts/${ID4}.sent"
set +e
out4="$(cd "$SENDER" && env TAP_HOME="$TAP_HOME" TAP_INDEX_HOME="$TAP_INDEX_HOME" \
  "$TAP" cancel "$ID4" --by alice 2>"$err")"
rc4=$?
set -e
[ "$rc4" -ne 0 ] || fail "(4) a canonical registry that EXISTS as a FIFO must refuse; got: $out4"
grep -q "not a regular file" <<<"$(cat "$err")" \
  || fail "(4) refusal must come from the regular-file guard (metadata, never an open); err=$(cat "$err")"
[ -f "$TAP_HOME/payloads/${ID4}.md" ] \
  || fail "(4) must not archive the payload on a refusal"
[ ! -f "$TAP_HOME/receipts/${ID4}.cancelled" ] \
  || fail "(4) must not write .cancelled for a non-regular canonical registry"
echo "cancel-foreign-worktree: (4) canonical FIFO + absent legacy refuses unopened: ok"

# --- (5) standalone bus outside Git + same-basename worktree in cwd's repo ----
# No cwd fallback may replace selected-bus authority: a standalone TAP_HOME with
# no Git ancestor, invoked from an unrelated repo that happens to contain a
# same-basename team worktree, must REFUSE — never let the shell's cwd donate a
# foreign registry that authorizes the cancel.
LOOSE="$WORK/Loose"
OTHER="$WORK/Elsewhere/repo"
mkdir -p "$LOOSE/bus/payloads" "$LOOSE/bus/receipts" "$OTHER/LoneTeam/tmp/tap"
git init -q "$OTHER"
git -C "$OTHER" config user.email tap1@example.net
git -C "$OTHER" config user.name "TAP Smoke"
cat >"$OTHER/LoneTeam/tmp/tap/registry.json" <<'JSON'
{
  "team": { "name": "LoneTeam" },
  "agents": {}
}
JSON
ID5="alice-20260729T000000Z-cfwt0005"
cat >"$LOOSE/bus/payloads/${ID5}.md" <<EOF
---
id: $ID5
from: alice
to: whoever
kind: discuss
path: $LOOSE/bus/payloads/${ID5}.md
reply: settle-only
from_team: SenderTeam
to_team: LoneTeam
---
cancel from a standalone bus must not borrow the cwd's repo
EOF
: >"$LOOSE/bus/receipts/${ID5}.sent"
set +e
out5="$(cd "$OTHER" && env TAP_HOME="$LOOSE/bus" TAP_INDEX_HOME="$TAP_INDEX_HOME" \
  "$TAP" cancel "$ID5" --by alice 2>"$err")"
rc5=$?
set -e
[ "$rc5" -ne 0 ] || fail "(5) a standalone bus outside Git must refuse rather than scan the cwd's unrelated repo; got: $out5"
[ -f "$LOOSE/bus/payloads/${ID5}.md" ] \
  || fail "(5) must not archive the payload on a refusal"
[ ! -f "$LOOSE/bus/receipts/${ID5}.cancelled" ] \
  || fail "(5) must not write .cancelled via a borrowed worktree"
cmp -s "$OTHER/LoneTeam/tmp/tap/registry.json" <(printf '{\n  "team": { "name": "LoneTeam" },\n  "agents": {}\n}\n') \
  || fail "(5) the unrelated repo's registry must not be mutated"
echo "cancel-foreign-worktree: (5) standalone bus refuses the cwd's same-basename worktree: ok"

echo "cancel-foreign-worktree: ok"
