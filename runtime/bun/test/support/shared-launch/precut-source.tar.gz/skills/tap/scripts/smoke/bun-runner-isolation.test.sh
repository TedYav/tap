#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
WORK="$(mktemp -d /tmp/tap-br.XXXXXX)"
WORK="$(cd "$WORK" && pwd -P)"
FIXTURE="$WORK/repo"
RUNNER="$FIXTURE/runtime/bun/test/run.sh"
FIXTURE_MARKER="$FIXTURE/.tap/probe-marker"
trap 'rm -rf "$WORK"' EXIT
mkdir -p "$WORK/engine" "$WORK/guard" "$WORK/caller-home" "$WORK/outer-tmux" \
  "$FIXTURE/runtime/bun/test" "$FIXTURE/scripts"
cp "$ROOT/runtime/bun/test/run.sh" "$RUNNER"
cp "$ROOT/scripts/ignored-state-tripwire.py" "$FIXTURE/scripts/ignored-state-tripwire.py"

# The selected Bun's directory also contains a competing tmux. Only the
# caller's guard may receive a child lookup; no real tmux is used in this probe.
cat > "$WORK/engine/bun" <<'BUN'
#!/bin/bash
set -eu
if [ "$1" = --child ]; then : > "$BUN_RUNNER_CHILD"; exit 0; fi
[ "$1" = test ]
if [ "${BUN_RUNNER_ESCAPE:-0}" = 1 ]; then
  mkdir -p "$BUN_RUNNER_REPO/.tap"
  : > "$BUN_RUNNER_REPO/.tap/probe-marker"
fi
printf '%s\n' "$HOME" > "$BUN_RUNNER_HOME"
[ -d "$TAP_HOME" ]
printf '%s\n' "$TAP_HOME" > "$BUN_RUNNER_TAP_HOME"
: > "$HOME/runner-write"
tmux
bun --child
BUN
printf '#!/bin/sh\nprintf guard > "$BUN_RUNNER_TMUX"\n' > "$WORK/guard/tmux"
printf '#!/bin/sh\nprintf bypass > "$BUN_RUNNER_TMUX"\n' > "$WORK/engine/tmux"
chmod +x "$WORK/engine/bun" "$WORK/guard/tmux" "$WORK/engine/tmux"

set +e
normal_out="$(env HOME="$WORK/caller-home" PATH="$WORK/guard:/usr/bin:/bin:/usr/sbin:/sbin" \
  TMUX_TMPDIR="$WORK/outer-tmux" TAP_SMOKE_BUN="$WORK/engine/bun" \
  BUN_RUNNER_HOME="$WORK/home-observed" BUN_RUNNER_TMUX="$WORK/tmux-observed" \
  BUN_RUNNER_TAP_HOME="$WORK/tap-home-observed" \
  BUN_RUNNER_CHILD="$WORK/child-ran" bash "$RUNNER" 2>&1)"
normal_rc=$?
set -e
[ "$normal_rc" = 0 ] \
  || { echo "bun-runner-isolation: clean inner runner failed rc=$normal_rc: $normal_out" >&2; exit 1; }

failures=0
if [ "$(cat "$WORK/home-observed")" = "$WORK/caller-home" ] || [ -e "$WORK/caller-home/runner-write" ]; then
  echo 'bun-runner-isolation: child wrote into caller HOME' >&2; failures=1
fi
case "$(cat "$WORK/tap-home-observed")" in
  "$WORK/outer-tmux"/tb.*/bus) ;;
  *) echo 'bun-runner-isolation: child TAP_HOME is outside runner scratch' >&2; failures=1 ;;
esac
if [ "$(cat "$WORK/tmux-observed")" != guard ]; then
  echo 'bun-runner-isolation: Bun directory bypassed caller tmux guard' >&2; failures=1
fi
[ -f "$WORK/child-ran" ] || { echo 'bun-runner-isolation: pinned Bun unavailable to child' >&2; failures=1; }
[ "$failures" = 0 ] || exit 1
case "$normal_out" in
  *"bun test: ignored-state-roots: 1 checked, 0 new or changed"*) ;;
  *) echo "bun-runner-isolation: clean receipt omitted ignored-state anchor: $normal_out" >&2; exit 1 ;;
esac

rm -f "$WORK/child-ran"
[ ! -e "$FIXTURE_MARKER" ] && [ ! -L "$FIXTURE_MARKER" ] \
  || { echo "bun-runner-isolation: refusing to overwrite pre-existing $FIXTURE_MARKER" >&2; exit 1; }
set +e
escape_out="$(env HOME="$WORK/caller-home" PATH="$WORK/guard:/usr/bin:/bin:/usr/sbin:/sbin" \
  TMUX_TMPDIR="$WORK/outer-tmux" TAP_SMOKE_BUN="$WORK/engine/bun" \
  BUN_RUNNER_HOME="$WORK/home-observed" BUN_RUNNER_TMUX="$WORK/tmux-observed" \
  BUN_RUNNER_TAP_HOME="$WORK/tap-home-observed" \
  BUN_RUNNER_CHILD="$WORK/child-ran" BUN_RUNNER_ESCAPE=1 BUN_RUNNER_REPO="$FIXTURE" \
  bash "$RUNNER" 2>&1)"
escape_rc=$?
set -e
rm -f "$FIXTURE_MARKER"
rmdir "$FIXTURE/.tap" 2>/dev/null || true
[ "$escape_rc" -ne 0 ] || { echo "bun-runner-isolation: ignored-state escape returned green: $escape_out" >&2; exit 1; }
case "$escape_out" in
  *"ignored-state mutation: root=$FIXTURE path=.tap/probe-marker change=new window=bun:"*) ;;
  *) echo "bun-runner-isolation: ignored-state red omitted path/window: $escape_out" >&2; exit 1 ;;
esac
case "$escape_out" in
  *"bun test: ignored-state-roots: 1 checked, 1 new or changed, 0 observation failure(s)"*) ;;
  *) echo "bun-runner-isolation: ignored-state red omitted summary: $escape_out" >&2; exit 1 ;;
esac
echo 'bun-runner-isolation: private HOME, retained tmux guard and pinned child Bun: ok'
