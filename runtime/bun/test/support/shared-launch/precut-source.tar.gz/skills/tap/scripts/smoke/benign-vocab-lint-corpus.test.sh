#!/usr/bin/env bash
# benign-vocab-lint-corpus.test.sh — prove the benign-vocab lint is not a placebo.
#
# The inventory test (benign-vocab-inventory.test.sh) only runs today's carrier
# files; a lint that cannot be SHOWN to FAIL on known-bad inputs proves nothing.
# This runs the red-fixture boundary corpus: inside/outside pairs pinning the
# prose forms the extractor must SEE (f-string literals, and — because shell is
# scanned raw whole-line — heredoc bodies, multiline quotes, and command-
# substitution / parameter-default output), the code forms word boundaries still
# EXCLUDE (identifiers like seat_corpse/undead), f-string expression/format-spec
# identifiers, the term morphology it must match, hit-scoped exemption, and
# end-to-end fail-on-unclassified / fail-on-stale / fail-on-mixed-line-masking.
# Keep it in lockstep with the lint.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

HERE="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=skills/tap/scripts/smoke/smoke-preflight.sh
. "$HERE/smoke-preflight.sh"
# Enforce the interpreter floor FIRST — the corpus exercises the lint end-to-end,
# which requires 3.12+ (FSTRING_MIDDLE); fail with the version error, not a fixture.
smoke_preflight_check || exit 1
PY="${TAP_PYTHON:-$(smoke_resolve_python)}"
# Validate the ACTUAL selected interpreter — an unchecked ${TAP_PYTHON} override
# must not silently no-op the corpus.
smoke_assert_python "$PY" || exit 1

echo "# benign-vocab-lint-corpus: red fixtures proving the lint fails on known-bad"
if "$PY" "$HERE/benign_vocab_lint_corpus.py"; then
  echo "PASS benign-vocab-lint-corpus"
else
  echo "FAIL benign-vocab-lint-corpus — a boundary fixture regressed (see above)." >&2
  exit 1
fi
