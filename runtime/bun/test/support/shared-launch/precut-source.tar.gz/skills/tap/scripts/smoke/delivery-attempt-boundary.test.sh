#!/usr/bin/env bash
# A retry-safe submit refusal must not become possible-effect evidence. The
# marker belongs at the first pane effect, after the compositor prechecks.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then return 1; fi
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "${WORK:?}"' EXIT
export TAP_HOME="$WORK/bus"
mkdir -p "$TAP_HOME/spool" "$TAP_HOME/payloads" "$TAP_HOME/receipts"
touch "$TAP_HOME/.tap-bus-authority"

# shellcheck source=skills/tap/scripts/lib.sh
. "$ROOT/skills/tap/scripts/lib.sh"
eval "$(declare -f tap_delivery_attempt_begin | sed '1s/tap_delivery_attempt_begin/real_delivery_attempt_begin/')"

fail() { echo "delivery-attempt-boundary: $*" >&2; exit 1; }

# Redelivery has completed its routing checks, but submit itself refuses before
# touching the pane. The caller must not pre-mint the marker.
id=refused-before-effect
printf '%s\n' body > "$TAP_HOME/spool/$id.md"
printf '%s\n' '{}' > "$TAP_HOME/spool/$id.meta.json"
eval "$(declare -f tap_bun_call | sed '1s/tap_bun_call/real_bun_call/')"
tap_bun_call() {
  if [ "$1" = redelivery-eligibility ]; then printf '%s\n' eligible
  else real_bun_call "$@"
  fi
}
tap_spool_home_authorized_or_warn() { return 0; }
tap_registry_matches_team() { return 0; }
tap_bound_pane_identity_state() { printf '%s\n' match; }
tap_clear_fence_inspect() { TAP_CLEAR_FENCE_STATE=absent; }
tap_exit_copy_mode() { return 0; }
tap_reconstruct_sentinel() { printf '%s\n' '[[TAP v0.23 note refused-before-effect]]'; }
tap_submit_reprobe_pending() { return 1; }
tap_debug_spool_submit() { TAP_SUBMIT_DEFER_REASON=no-prompt; return 4; }
tap_spool_reown_after_repark() { return 0; }
tap_obligation_lock() { return 0; }

rc=0
tap_spool_redeliver "$id" peer pane %1 team registry || rc=$?
[ "$rc" = 1 ] || fail "pre-effect refusal returned $rc, expected retry-owned rc 1"
[ -f "$TAP_HOME/spool/$id.md" ] || fail "pre-effect refusal lost spool custody"
[ ! -e "$TAP_HOME/receipts/$id.attempted" ] \
  || fail "pre-effect refusal minted possible-effect evidence"

# The shared submit body owns the same negative edge. A real compositor
# precheck refusal must return before the marker boundary.
tap_recorded_permissions() { printf '%s\n' manual; }
tap_queue_prefix() { return 0; }
tap_pending_input_text() { return 3; }
TAP_DELIVERY_ATTEMPT_IDS=body-refused
rc=0
tap_submit_verify_body pane claude '[[TAP v0.23 note body-refused]]' body-refused peer 0 id || rc=$?
[ "$rc" = 4 ] || fail "submit-body precheck returned $rc, expected retry-safe rc 4"
[ ! -e "$TAP_HOME/receipts/body-refused.attempted" ] \
  || fail "submit-body precheck minted possible-effect evidence"

# The real submit body owns the opposite edge. Once it reaches injection, the
# marker must exist before the injecting primitive runs, even when that primitive
# immediately fails. This prevents a retry after a possibly applied keystroke.
tap_pending_input_text() { return 0; }
tap_submit_identity_guard() { return 0; }
tap_submit_owner_guard() { return 0; }
tap_input_has_paste_collapse() { return 1; }
tap_inject_text() {
  [ -f "$TAP_HOME/receipts/effect-entered.attempted" ] \
    || fail "injecting primitive ran before possible-effect evidence"
  return 1
}

TAP_DELIVERY_ATTEMPT_IDS=effect-entered
rc=0
tap_submit_verify_body pane claude '[[TAP v0.23 note effect-entered]]' effect-entered peer 0 id || rc=$?
[ "$rc" = 3 ] || fail "failed injection returned $rc, expected pane-gone rc 3"
[ -f "$TAP_HOME/receipts/effect-entered.attempted" ] \
  || fail "effect boundary did not mint possible-effect evidence"

# The submit primitive is shared with self-control commands such as `/clear`.
# Only courier callers opt into delivery evidence, and slash command ids are not
# valid receipt names in the first place.
unset TAP_DELIVERY_ATTEMPT_IDS
TAP_DELIVERY_EFFECT_STARTED=0
tap_delivery_effect_begin /clear || fail "non-courier submit was forced through courier evidence"
attempt_count="$(find "$TAP_HOME/receipts" -type f -name '*.attempted' | wc -l | tr -d ' ')"
[ "$attempt_count" = 1 ] || fail "non-courier submit created delivery evidence"

# Native status codes are classified before conservative evidence is minted.
# ccnative's 10-14 surface is effect:none, so those retry-safe refusals must not
# turn into possible-effect markers merely because the native door ran.
tap_driver_for_harness() { printf '%s\n' probe; }
tap_driver_load() { return 0; }
tapdrv_probe_deliver() { return "$PROBE_RC"; }
tapdrv_probe_outcome() {
  case "$1" in
    10|11|12|13|14) printf 'retry-next-rung\037none\037none\n' ;;
    *) printf 'stop-ambiguous\037possible\037none\n' ;;
  esac
}
tapdrv_probe_ceiling() { printf '%s\n' transcript-match; }
for PROBE_RC in 10 11 12 13 14; do
  probe_id="native-none-$PROBE_RC"
  probe_payload="$TAP_HOME/payloads/$probe_id.md"
  : > "$probe_payload"
  rc=0
  TAP_DELIVERY_ATTEMPT_IDS="$probe_id" tap_driver_deliver "$probe_payload" "$probe_id" queue probe || rc=$?
  [ "$rc" = "$PROBE_RC" ] || fail "native rc $PROBE_RC changed to $rc"
  [ ! -e "$TAP_HOME/receipts/$probe_id.attempted" ] \
    || fail "native effect:none rc $PROBE_RC minted possible-effect evidence"
done

PROBE_RC=15
probe_id=native-possible
probe_payload="$TAP_HOME/payloads/$probe_id.md"
: > "$probe_payload"
rc=0
TAP_DELIVERY_ATTEMPT_IDS="$probe_id" tap_driver_deliver "$probe_payload" "$probe_id" queue probe || rc=$?
[ "$rc" = 15 ] || fail "native possible-effect rc changed to $rc"
[ -f "$TAP_HOME/receipts/$probe_id.attempted" ] \
  || fail "native possible effect was routed before durable evidence"

# An unwritable evidence boundary is its own hard failure. It must not collapse
# into rc 4, which the send router accepts and queues as an ordinary busy pane.
tap_delivery_attempt_begin() { return 1; }
PROBE_RC=15
probe_id=native-evidence-failure
probe_payload="$TAP_HOME/payloads/$probe_id.md"
: > "$probe_payload"
rc=0
TAP_DELIVERY_ATTEMPT_IDS="$probe_id" tap_driver_deliver "$probe_payload" "$probe_id" queue probe || rc=$?
[ "$rc" = 8 ] || fail "attempt evidence failure returned $rc, expected hard-failure rc 8"
[ "${TAP_DRIVER_ATTEMPT_EVIDENCE_UNWRITABLE:-0}" = 1 ] \
  || fail "attempt evidence failure did not reach the router's hard-failure channel"
eval "$(declare -f real_delivery_attempt_begin | sed '1s/real_delivery_attempt_begin/tap_delivery_attempt_begin/')"

echo "delivery-attempt-boundary: pre-effect refusal stays retryable; injection is marked first: ok"
