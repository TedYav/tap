#!/usr/bin/env bash
# ledger.sh - driver-owned issue ledger for TAP convergence (tap-5h9).
#
# Append-only NDJSON at threads/<thread_id>/ledger.ndjson; an item's current state
# is its last event. The ledger is driver-owned thread-authoritative state, so
# every mutator gates at thread-lib.sh assert_driver before touching disk.
#
#   ledger.sh add <tid> <item_id> <status> <evidence_class> <evidence> <rationale> \
#                  --by <h> [--source-msg-id <id>]
#   ledger.sh transition <tid> <item_id> <new_status> [evidence_ref] [rationale] \
#                  --by <h> [--source-msg-id <id>]
#   ledger.sh list <tid> --by <h>        # current state, one JSON/line
#   ledger.sh source-ids <tid> --by <h>  # every source_msg_id on the ledger, one/line
#
# status         ∈ proposed|accepted|rejected_with_reason|resolved_by_revision|human_decision|deferred
# evidence_class ∈ evidence_bearing|assertion_only|judgment
# evidence       = citation-shaped (a message id + optional ref/file:line)
# rationale      = the disposition take (kept SEPARATE from evidence)
#
# MONOTONIC SEQ (tap-5h9 amendment, per sol §9 + fable amendment): every ledger
# line carries a mandatory integer `seq`, allocated under the per-run fcntl lock.
# Replay validation requires seq=1 for the first line and exact +1 thereafter.
# `at` timestamps are display-only — they NEVER decide ledger order. The anti-
# sycophancy freshness check ("evidence INTRODUCED to the ledger after the
# rejection") is expressed via source-event SEQUENCE, not message timestamps:
# the accept cites a PRIOR SAME-ITEM introduction event with
# rejection_seq < introduction_seq < accept_seq. The accept stamps THAT PRIOR
# EVENT's seq as evidence_seq; replay locates that exact prior event and
# rechecks all four relationships. Timestamp comparison would violate the
# monotonic-order invariant (sol §9).
#
# ADAPTATIONS (tap-5h9, six named adaptations — #1-#3 original, V1-V3 gate fixes):
#   #1 — HANDLE_RE widened from collab's ^[a-z0-9][a-z0-9_-]*$ to TAP_ID_RE
#        ^[A-Za-z0-9][A-Za-z0-9._-]*$ (skills/tap/scripts/lib.sh:169).
#   #2 — _scan_payloads replaces collab's _scan_messages_for_thread: evidence
#        resolves against TAP's canonical payloads dir (<TAP_HOME>/payloads/<id>.md)
#        via payload_meta.py (YAML frontmatter, not JSON). Thread-scoping is
#        dropped (TAP payloads don't carry a thread_id; the lane consumer in PR4
#        layers thread semantics on top). Whole-ass: THE one message source.
#   #3 — State home: COLLAB_DIR env override (absolute-path-required), default
#        <repo>/.tap/bus/collab/ (auto-ignored, archived by tap team reset).
#   V1 — lib.sh non-git fallback walks 4-up to repo root (was 3-up, landing at skills/).
#   V2 — refuse at first ledger use on a legacy tmp/tap bus (names 'tap init').
#   V3 — availability-safe + fail-closed _scan_payloads: skip torn with warning,
#        specific error for cited torn evidence (never die on bus-wide scan).
#
# FAIL-LOUD ANTI-SYCOPHANCY INVARIANT (F2, sol §1 option B — re-anchored to seq):
# a rejected_with_reason → accepted transition on an evidence_bearing item MUST
# cite an evidence payload introduced by a PRIOR SAME-ITEM ledger event satisfying
# rejection_seq < introduction_seq < accept_seq. The introduction event has
# source_msg_id == evidence_message_id(evidence_ref) (normalized — @ref suffix
# stripped) and its own evidence/evidence_ref normalizes to the same payload ID.
# The accept stamps THAT PRIOR EVENT's seq as evidence_seq (never its own); replay
# locates that exact prior event and rechecks all four relationships. A direct
# rejected→accepted with no qualifying introduction fails loud. Judgment/assertion
# items are exempt (F5). The seen-set is normalized to PAYLOAD IDs (sol §2) so
# the same payload cannot evade via a different @ref suffix alias.
#
# PRECISION NOTE (sol §4): this proves ledger-visible introduction after rejection,
# NOT physical payload creation time. If the stronger requirement is send-time
# postdating against a potentially dishonest/backfilling driver, TAP needs a
# courier-assigned monotonic arrival sequence — not present tonight, not claimed.
#
# IDEMPOTENCY MARKER (NR-4): add/transition accept an optional --source-msg-id <id>.
# When present it stamps "source_msg_id": <id> onto the appended event — the ledger-native
# record of WHICH proposal message produced this event. fold.sh (deferred, PR4) reads
# this via `source-ids` for crash-idempotent re-fold.
#
# DEFERRED SCRIPTS (P2-LC9 adjudication, tmp/design/overnight-forks.md:223-229):
# fold.sh, is-converged.sh, round-count.sh are /discuss LOOP choreography with no
# tap consumer tonight — deferred by name on tap-5h9. The LEDGER is the shared
# mechanism; the convergence loop stays upstream.
#
# HOUSE IDIOM: thin bash wrapper sources thread-lib.sh, gates
# at the sink, then exec python3 - "$@" <<'PY' (quoted heredoc; argv reads only).
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ledger/thread-lib.sh
. "$DIR/thread-lib.sh"

cmd="${1:-}"
[ -n "$cmd" ] || die "usage: ledger.sh {add|transition|list|source-ids} <thread_id> ... --by <h>"

# Split the driver flag out of the positional args.
# Every command (incl. read-only `list`) is gated, so --by is always required:
# the ledger is driver-owned, and a non-driver should not even enumerate it as if it
# owned it — reads route through the driver context.
by=""; source_msg_id=""
pos=()
shift  # drop cmd
while [ "$#" -gt 0 ]; do
  case "$1" in
    --by)            by="${2:-}"; shift 2 ;;
    --source-msg-id) source_msg_id="${2:-}"; shift 2 ;;
    *) pos+=("$1"); shift ;;
  esac
done
[ "${#pos[@]}" -ge 1 ] || die "ledger.sh $cmd: missing <thread_id>"
tid="${pos[0]}"

# `events` is READ-ONLY: no --by gate, no assert_driver. Any driver can read
# the validated event stream, including historical lane negotiation records.
# The single-writer principle applies to WRITES (add/transition), not reads.
if [ "$cmd" != "events" ]; then
  [ -n "$by" ] || die "ledger.sh $cmd: --by <handle> is required (the driver)"
  # SINGLE-WRITER SINK: only the live opened_by driver may touch this ledger.
  if ! assert_driver "$tid" "$by"; then
    exit 1  # assert_driver already printed the REJECT diagnostic
  fi
fi

exec python3 - "$COLLAB_DIR" "$DIR" "$cmd" "$source_msg_id" "${pos[@]}" <<'PY'
import contextlib, fcntl, json, sys, os, datetime, re

collab_dir = sys.argv[1]
script_dir = sys.argv[2]
cmd = sys.argv[3]
# NR-4: the proposal message id whose op this is (or "" for a driver's own direct op).
# Stamped onto the event so a crash-interrupted re-fold can detect the already-applied op.
source_msg_id = sys.argv[4] or None
a = sys.argv[5:]   # a[0] = thread_id, then command-specific positional args
sys.path.insert(0, script_dir)
from payload_meta import parse_payload

STATUSES = {"proposed", "accepted", "rejected_with_reason", "resolved_by_revision", "human_decision", "deferred"}
ECLASSES = {"evidence_bearing", "assertion_only", "judgment"}
OPEN = {"proposed", "accepted"}
HANDLE_RE = re.compile(r"\A[A-Za-z0-9][A-Za-z0-9._-]*\Z")  # tap-5h9 adaptation #1: TAP_ID_RE (skills/tap/scripts/lib.sh:169)
THREAD_RE = re.compile(r"\A[A-Za-z0-9][A-Za-z0-9_-]*\Z")


def die(msg):
    sys.exit(f"tap ledger: {msg}")


def tdir(tid):
    if not THREAD_RE.match(tid or ""):
        die(f"invalid thread_id {tid!r} (no path separators)")
    return os.path.join(collab_dir, "threads", tid)


def lpath(tid):
    return os.path.join(tdir(tid), "ledger.ndjson")


def lock_path(tid):
    return os.path.join(tdir(tid), "ledger.lock")


@contextlib.contextmanager
def ledger_lock(tid, exclusive=True):
    os.makedirs(tdir(tid), exist_ok=True)
    fd = os.open(lock_path(tid), os.O_RDWR | os.O_CREAT, 0o644)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        yield
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def now():
    # Display-only timestamp (sol §9: `at` never decides ledger order; seq does).
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def evidence_message_id(evidence_ref):
    return evidence_ref.split("@", 1)[0]


def _normalize_payload_id(s):
    # sol §2: normalize citation strings to PAYLOAD IDs (strip the optional @ref suffix)
    # so the same payload cannot evade the seen-set via a different @ref alias.
    # E.g. "peer-X@src/a.ts:1" and "peer-X@src/b.ts:2" both normalize to "peer-X".
    # A string with no "@" is returned as-is (e.g. a free-form evidence note on add).
    if not s:
        return None
    return s.split("@", 1)[0]


def _scan_payloads():
    # tap-5h9 adaptation #2: replaces collab's _scan_messages_for_thread (which
    # scanned threads/<tid>/messages/*.json). TAP payloads live flat on the bus
    # at <TAP_HOME>/payloads/<id>.md (YAML frontmatter, not JSON). Thread-scoping
    # is dropped — TAP payloads don't carry a thread_id, and the lane consumer
    # (PR4) layers thread semantics on top of this shared mechanism. Whole-ass:
    # this is THE one message source — no dual-source fallback.
    #
    # V3 revised (opus gate analysis, lead-adjudicated v3): AVAILABILITY-SAFE +
    # FAIL-CLOSED. An unparseable/torn payload is SKIPPED with a stderr warning
    # (never die) — skip-torn is fail-closed for the guard because skipped
    # evidence reads as not-on-bus and the accept is refused. A malformed
    # from-handle is also skip+warn (never die) — one malformed payload anywhere
    # on the bus must never block every evidence-validated accept (bus-wide DoS).
    # The write-time check distinguishes "not on bus" from "torn" so the refusal
    # error can name the specific failure for the cited evidence payload.
    #
    # Returns (ok_ids, torn_ids): ok_ids = parseable + valid; torn_ids =
    # exists-but-unreadable/malformed.
    ok_ids = set()
    torn_ids = set()
    payloads_dir = os.path.join(os.path.dirname(collab_dir), "payloads")
    if not os.path.isdir(payloads_dir):
        return ok_ids, torn_ids

    for name in os.listdir(payloads_dir):
        if name.startswith(".") or not name.endswith(".md"):
            continue
        if name.startswith("_"):
            continue  # CONTRACT §Bus layout: _*.md reserved for drafts, ignored
        path = os.path.join(payloads_dir, name)
        try:
            pid, _, metadata = parse_payload(path)
        except OSError as exc:
            sys.stderr.write(f"tap ledger: warning: unreadable payload {path} skipped during evidence scan: {exc}\n")
            torn_ids.add(os.path.splitext(name)[0])
            continue
        except ValueError as exc:
            sys.stderr.write(f"tap ledger: warning: malformed payload {path} skipped during evidence scan (torn frontmatter?): {exc}\n")
            torn_ids.add(os.path.splitext(name)[0])
            continue
        from_handle = metadata.get("from") or ""
        if from_handle and not HANDLE_RE.match(from_handle):
            sys.stderr.write(f"tap ledger: warning: payload {path} has invalid from handle {from_handle!r}; skipped during evidence scan\n")
            torn_ids.add(pid)
            continue
        ok_ids.add(pid)
    return ok_ids, torn_ids


def _antisycophancy_prior(prior, evref, eclass):
    # The BUS-FREE, prior-events-only half of the anti-sycophancy invariant, shared by the
    # write path AND the read-time replay. `prior` = the item's events BEFORE this accept.
    # Returns (exempt, err, last_rej):
    #   exempt=True  → the guard does not apply (judgment/assertion, or never rejected) — no
    #                  evidence required; callers stamp nothing.
    #   err set      → a guard violation that needs no message lookup (missing evref, or an evref already
    #                  on the table at rejection time). last_rej is None.
    #   else         → caller must locate a prior introduction event; last_rej is the most-recent rejection index.
    rej = [i for i, e in enumerate(prior) if e.get("status") == "rejected_with_reason"]
    if eclass != "evidence_bearing" or not rej:
        return True, None, None
    if not evref:
        return (False,
                "accepting an evidence_bearing item that was rejected_with_reason MUST carry an "
                "evidence_ref citing a payload introduced to the ledger after the rejection (anti-sycophancy guard)",
                None)
    last_rej = max(rej)
    seen = set()
    for e in prior[: last_rej + 1]:
        # sol §2: normalize to PAYLOAD IDs so the same payload cannot evade via a
        # different @ref suffix alias.
        if e.get("evidence"):
            nid = _normalize_payload_id(e["evidence"])
            if nid:
                seen.add(nid)
        if e.get("evidence_ref"):
            nid = _normalize_payload_id(e["evidence_ref"])
            if nid:
                seen.add(nid)
    if _normalize_payload_id(evref) in seen:
        return (False,
                f"evidence_ref {evref!r} (payload {_normalize_payload_id(evref)!r}) was already on the table at rejection time; a reversal needs visible NEW evidence",
                None)
    return False, None, last_rej


def _find_introduction(prior, evref, last_rej, accept_seq):
    # sol §1 (option B): find a qualifying PRIOR SAME-ITEM event that introduced
    # the evidence into the authoritative ledger AFTER the most-recent rejection
    # but BEFORE this accept. The introduction event must have:
    #   - source_msg_id == evidence_message_id(evref)  (the evidence payload authored it)
    #   - its own evidence/evidence_ref normalizes to the same payload ID  (it cites the evidence)
    #   - seq > prior[last_rej]["seq"]  (after the rejection)
    #   - seq < accept_seq  (before the accept)
    # Returns the event dict or None.
    target_pid = _normalize_payload_id(evref)
    if not target_pid:
        return None
    rej_seq = prior[last_rej].get("seq") if last_rej is not None else None
    for e in prior:
        e_seq = e.get("seq")
        if e_seq is None:
            continue
        if rej_seq is not None and e_seq <= rej_seq:
            continue  # must be AFTER the rejection
        if e_seq >= accept_seq:
            continue  # must be BEFORE the accept
        if e.get("source_msg_id") != target_pid:
            continue  # must be authored by the evidence payload
        # its own evidence/evidence_ref must normalize to the same payload id
        ev_pid = _normalize_payload_id(e.get("evidence")) or _normalize_payload_id(e.get("evidence_ref"))
        if ev_pid != target_pid:
            continue
        return e
    return None


def _antisycophancy_write(prior, evref, tid, eclass, accept_seq):
    # WRITE-TIME anti-sycophancy check (sol §1, option B — re-anchored to seq):
    # The accept must cite an evidence payload introduced by a PRIOR SAME-ITEM
    # ledger event satisfying rejection_seq < introduction_seq < accept_seq.
    # The introduction event has source_msg_id == evidence_message_id(evref)
    # and its own evidence/evidence_ref normalizes to the same payload ID.
    #
    # The accept stamps THAT PRIOR EVENT's seq as evidence_seq (never its own).
    # Replay locates that exact prior event and rechecks all four relationships.
    # A direct rejected→accepted with no qualifying introduction fails loud.
    #
    # Returns (err, stamp): on success stamp = {"evidence_msg_id", "evidence_seq"}.
    # An exempt item yields (None, None) — nothing to stamp.
    exempt, err, last_rej = _antisycophancy_prior(prior, evref, eclass)
    if exempt or err:
        return err, None
    ref_mid = evidence_message_id(evref)
    ok_payloads, torn_payloads = _scan_payloads()
    if ref_mid in torn_payloads:
        return f"evidence payload {ref_mid!r} exists on the bus but is unreadable/torn — the guard cannot validate evidence it cannot parse", None
    if ref_mid not in ok_payloads:
        return f"evidence_ref {evref!r} must point to a payload id on the bus; arbitrary unseen strings are not evidence", None
    introduction = _find_introduction(prior, evref, last_rej, accept_seq)
    if introduction is None:
        rej_seq = prior[last_rej].get("seq") if last_rej is not None else None
        return (f"no qualifying prior evidence-introduction event for {evref!r}; a reversal requires a prior same-item event "
                f"with source_msg_id == {ref_mid!r}, seq > rejection_seq ({rej_seq}), and seq < accept_seq ({accept_seq}). "
                f"Two-step: transition to proposed with --source-msg-id {ref_mid!r} citing the evidence, then accept citing it.", None)
    intro_seq = introduction["seq"]
    return None, {"evidence_msg_id": ref_mid, "evidence_seq": intro_seq}


def _antisycophancy_replay(prior, ev, eclass):
    # READ-TIME anti-sycophancy replay (sol §1, option B): validates the accept
    # event `ev` against its OWN IMMUTABLE STAMP (evidence_msg_id/evidence_seq).
    # The stamp references a PRIOR SAME-ITEM introduction event; replay locates
    # that event by seq and rechecks all four relationships:
    #   1. stamp present (proves the write-time guard ran)
    #   2. evidence_msg_id == evidence_message_id(evidence_ref)  (stamp matches claim)
    #   3. evidence_seq != ev's own seq  (not self-referential — the accept stamps
    #      the INTRODUCTION's seq, never its own)
    #   4. a prior same-item event with seq == evidence_seq exists
    #   5. that event's source_msg_id == evidence_msg_id  (the evidence authored it)
    #   6. that event's evidence/evidence_ref normalizes to evidence_msg_id  (it cites the evidence)
    #   7. rejection_seq < evidence_seq < accept_seq  (ordering invariant)
    # Returns an error string on violation, else None. `prior` = the item's events
    # BEFORE this accept.
    evref = ev.get("evidence_ref")
    exempt, err, last_rej = _antisycophancy_prior(prior, evref, eclass)
    if exempt or err:
        return err
    ref_mid = evidence_message_id(evref)
    stamp_id = ev.get("evidence_msg_id")
    stamp_seq = ev.get("evidence_seq")
    if not stamp_id or stamp_seq is None:
        return (f"evidence_ref {evref!r} accept is MISSING its write-time stamp "
                f"(evidence_msg_id/evidence_seq); a legitimate accept always carries it")
    if stamp_id != ref_mid:
        return (f"stamped evidence_msg_id {stamp_id!r} != the evidence_ref message id {ref_mid!r} "
                f"(forged/mismatched stamp)")
    ev_seq = ev.get("seq")
    if ev_seq is not None and stamp_seq == ev_seq:
        return (f"stamped evidence_seq {stamp_seq} == the accept's own seq; a legitimate accept stamps "
                f"the INTRODUCTION's seq, never its own (self-referential forgery)")
    # Locate the prior same-item event with seq == stamp_seq (the cited introduction)
    introduction = None
    for e in prior:
        if e.get("seq") == stamp_seq:
            introduction = e
            break
    if introduction is None:
        return (f"evidence_seq {stamp_seq} does not match any prior same-item event's seq; "
                f"the cited introduction event does not exist")
    # Verify the introduction was authored by the evidence payload
    intro_source = introduction.get("source_msg_id")
    if intro_source != ref_mid:
        return (f"introduction event seq {stamp_seq} has source_msg_id {intro_source!r} != evidence payload id {ref_mid!r}; "
                f"the introduction was not authored by the evidence payload")
    # Verify the introduction cites the evidence payload
    intro_ev_pid = _normalize_payload_id(introduction.get("evidence")) or _normalize_payload_id(introduction.get("evidence_ref"))
    if intro_ev_pid != ref_mid:
        return (f"introduction event seq {stamp_seq} does not cite the evidence payload "
                f"(cites {intro_ev_pid!r}, expected {ref_mid!r})")
    # Verify ordering: rejection < introduction < accept
    rej_seq = prior[last_rej].get("seq") if last_rej is not None else None
    if rej_seq is not None and stamp_seq <= rej_seq:
        return (f"evidence_seq {stamp_seq} (introduction) is not later than the most-recent rejection seq {rej_seq}; "
                f"a reversal needs evidence INTRODUCED to the ledger after the rejection")
    if ev_seq is not None and stamp_seq >= ev_seq:
        return (f"evidence_seq {stamp_seq} (introduction) is not earlier than the accept's own seq {ev_seq}; "
                f"the introduction must precede the accept")
    return None


def _validate_event_stream(p, evs):
    # Validate the event STREAM, not just per-line JSON: a hand-edited/forged valid-JSON line
    # appended directly (not via the API) must be detectable corruption, so it cannot become a
    # new "truth" that bypasses the transition-time guards.
    #
    # MONOTONIC SEQ (sol §9): seq=1 for the first line, exact +1 thereafter. A
    # gap, duplicate, or out-of-order seq is corruption — fail loud.
    expected_seq = 1
    history = {}
    for i, e in enumerate(evs, 1):
        if not isinstance(e, dict):
            die(f"corrupt ledger {p} (event #{i}): not an object")
        ev, iid, status, eclass = e.get("event"), e.get("id"), e.get("status"), e.get("evidence_class")
        seq = e.get("seq")
        if seq != expected_seq:
            die(f"corrupt ledger {p} (event #{i}, seq={seq!r}): expected seq={expected_seq} (monotonic +1 invariant, sol §9)")
        expected_seq += 1
        if ev not in ("add", "transition"):
            die(f"corrupt ledger {p} (event #{i}): event must be add|transition, got {ev!r}")
        if not iid:
            die(f"corrupt ledger {p} (event #{i}): missing id")
        if status not in STATUSES:
            die(f"corrupt ledger {p} (event #{i}, {iid}): bad status {status!r}")
        if eclass not in ECLASSES:
            die(f"corrupt ledger {p} (event #{i}, {iid}): bad evidence_class {eclass!r}")
        prior = history.get(iid, [])
        if ev == "add":
            if prior:
                die(f"corrupt ledger {p}: duplicate add for {iid} (create-only)")
        else:
            if not prior:
                die(f"corrupt ledger {p}: transition before add for {iid}")
            if e.get("from") != prior[-1].get("status"):
                die(f"corrupt ledger {p}: {iid} transition from {e.get('from')!r} != previous status {prior[-1].get('status')!r} (forged/out-of-order)")
            if eclass != prior[-1].get("evidence_class"):
                die(f"corrupt ledger {p}: {iid} evidence_class changed {prior[-1].get('evidence_class')!r} -> {eclass!r}")
            if status == "accepted":
                # READ-TIME: replay against the event's OWN immutable stamp.
                err = _antisycophancy_replay(prior, e, eclass)
                if err:
                    die(f"corrupt ledger {p}: forged accept for {iid} bypasses the anti-sycophancy guard — {err}")
        history.setdefault(iid, []).append(e)


def events(tid):
    p = lpath(tid)
    out = []
    if os.path.exists(p):
        for ln, line in enumerate(open(p), 1):
            if not line.strip():
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                die(f"malformed ledger line {p}:{ln} (fail loud)")
        _validate_event_stream(p, out)
    return out


def current(tid):
    st = {}
    for e in events(tid):
        st[e["id"]] = e
    return st


def _next_seq(tid):
    # Caller must hold ledger_lock(tid). Reads the validated event stream and
    # returns the next seq (1 for a fresh thread, last_seq + 1 otherwise).
    evs = events(tid)
    if not evs:
        return 1
    return evs[-1].get("seq", 0) + 1


def append(tid, ev, seq):
    # Caller must hold ledger_lock(tid): the transition guards + seq allocation
    # depend on a serialized events() → append() span, not just an atomic line append.
    ev["seq"] = seq
    with open(lpath(tid), "a") as f:
        f.write(json.dumps(ev) + "\n")


if cmd == "add":
    if len(a) != 6:
        die("usage: ledger.sh add <tid> <item_id> <status> <evidence_class> <evidence> <rationale> --by <driver>")
    tid, iid, status, eclass, evidence, rationale = a[0], a[1], a[2], a[3], a[4], a[5]
    if status not in STATUSES:
        die(f"invalid status '{status}' (valid: {sorted(STATUSES)})")
    if eclass not in ECLASSES:
        die(f"invalid evidence_class '{eclass}' (valid: {sorted(ECLASSES)})")
    with ledger_lock(tid):
        if iid in current(tid):
            die(f"item '{iid}' already exists in thread {tid} — use `transition` to change "
                f"state, never re-`add` (a re-add could silently downgrade evidence_class past the guard)")
        seq = _next_seq(tid)
        ev = {"seq": seq, "event": "add", "at": now(), "thread_id": tid, "id": iid, "status": status,
              "evidence_class": eclass, "evidence": evidence, "rationale": rationale}
        # NR-4: stamp the producing proposal's id so a crash-interrupted re-fold is idempotent.
        if source_msg_id is not None:
            ev["source_msg_id"] = source_msg_id
        append(tid, ev, seq)
    print(f"ledger {tid}: added {iid} [{status}/{eclass}]")

elif cmd == "transition":
    if len(a) < 3:
        die("usage: ledger.sh transition <tid> <item_id> <new_status> [evidence_ref] [rationale] --by <driver>")
    tid, iid, new = a[0], a[1], a[2]
    evref = a[3] if len(a) > 3 and a[3] else None
    rationale = a[4] if len(a) > 4 and a[4] else None
    if new not in STATUSES:
        die(f"invalid status '{new}' (valid: {sorted(STATUSES)})")
    with ledger_lock(tid):
        item_events_all = events(tid)
        cur = {}
        for event in item_events_all:
            cur[event["id"]] = event
        if iid not in cur:
            die(f"unknown item '{iid}' in thread {tid} (add it first)")
        item = cur[iid]
        old = item["status"]
        eclass = item.get("evidence_class")
        # Anti-sycophancy guard at the WRITE boundary (re-anchored to seq per sol §9).
        # Fires whenever an evidence_bearing item that was EVER rejected_with_reason
        # is transitioned to accepted. Judgment/assertion items are exempt (F5).
        # The write-time check validates evref against the LIVE BUS and stamps
        # evidence_msg_id + evidence_seq (the accept's own seq) onto the accept event.
        item_events = [e for e in item_events_all if e["id"] == iid]
        seq = _next_seq(tid)
        stamp = None
        if new == "accepted":
            err, stamp = _antisycophancy_write(item_events, evref, tid, eclass, seq)
            if err:
                die(f"PROTOCOL ERROR — {iid}: {err}")
        ev = {"seq": seq, "event": "transition", "at": now(), "thread_id": tid, "id": iid, "status": new,
              "evidence_class": eclass, "evidence_ref": evref, "rationale": rationale, "from": old}
        # Stamp the evidence message's id + observed seq onto a guarded accept so
        # the ledger is self-contained — only present when the guard actually ran
        # on an evidence_bearing reversal.
        if stamp is not None:
            ev.update(stamp)
        # NR-4: stamp the producing proposal's id so a crash-interrupted re-fold is idempotent.
        if source_msg_id is not None:
            ev["source_msg_id"] = source_msg_id
        append(tid, ev, seq)
    print(f"ledger {tid}: {iid} {old} -> {new}")

elif cmd == "list":
    if len(a) < 1:
        die("usage: ledger.sh list <thread_id> --by <driver>")
    tid = a[0]
    with ledger_lock(tid, exclusive=False):
        for iid, e in current(tid).items():
            print(json.dumps({"id": iid, "status": e["status"],
                              "evidence_class": e.get("evidence_class"), "open": e["status"] in OPEN}))

elif cmd == "source-ids":
    # NR-4: print every source_msg_id present on the thread ledger, one per line — the
    # idempotency bookmark set. Routed through events() so the read is VALIDATED
    # (_validate_event_stream); a forged/torn ledger fails loud here, never silently
    # yields a half-set that would let a reapply slip the guard.
    if len(a) < 1:
        die("usage: ledger.sh source-ids <thread_id> --by <driver>")
    tid = a[0]
    emitted = set()
    with ledger_lock(tid, exclusive=False):
        for e in events(tid):
            sid = e.get("source_msg_id")
            if sid and sid not in emitted:
                emitted.add(sid)
                print(sid)

elif cmd == "events":
    # READ-ONLY: output the full validated event stream as NDJSON. Not gated by
    # --by: historical lane records remain readable after the lane CLI retirement.
    # Routed through events() → _validate_event_stream so a forged/torn ledger
    # fails loud here, same as list/source-ids.
    if len(a) < 1:
        die("usage: ledger.sh events <thread_id>")
    tid = a[0]
    with ledger_lock(tid, exclusive=False):
        for e in events(tid):
            print(json.dumps(e))

else:
    die(f"unknown command '{cmd}' (use add|transition|list|source-ids|events)")
PY
