"""Own one reply's active send process group until completion or cancellation."""
import os
import signal
import subprocess
import sys
import time


def main(argv):
    child = None
    cancelled = 0

    def cancel(signum, _frame):
        nonlocal cancelled
        cancelled = cancelled or signum
        if child is not None and child.returncode is None:
            # No grace interval in which a TERM-ignoring transport can deliver.
            # The leader remains unreaped, reserving this private group id.
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

    signals = (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)
    for signum in signals:
        signal.signal(signum, cancel)
    if cancelled:
        return 128 + cancelled
    child = subprocess.Popen(argv, start_new_session=True)
    # A handler may run while Popen is returning, before child is published.
    if cancelled:
        cancel(cancelled, None)
    # Reap and publish returncode while signals are blocked, so a handler cannot
    # target a reused group id. Unmask between polls: blocking wait() under the
    # mask would prevent cancellation of a still-running send. Unlike waitid,
    # poll()/waitpid is available on macOS Python 3.11.
    rc = None
    while rc is None:
        old_mask = signal.pthread_sigmask(signal.SIG_BLOCK, signals)
        try:
            rc = child.poll()
        finally:
            signal.pthread_sigmask(signal.SIG_SETMASK, old_mask)
        if rc is None:
            time.sleep(0.01)
    return 128 + cancelled if cancelled else (128 - rc if rc < 0 else rc)


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
