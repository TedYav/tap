#!/usr/bin/env bash
# .101: the real drain must preserve timeout uncertainty and possible-effect custody.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
export TAP_SPOOL_DISABLE_DELIVERER=1 TAP_HOME="$WORK/bus"
. "$ROOT/skills/tap/scripts/lib.sh"
tap_ensure_dirs
mkdir -p "$TAP_SPOOL"
cat > "$TAP_REGISTRY" <<'JSON'
{"team":{"name":"fixture"},"agents":{"alice":{"status":"active","pane":"sess:0.1","pane_id":"%402","harness":"codex"},"peer":{"status":"active","pane":"sess:0.0","pane_id":"%401","harness":"codex"}}}
JSON
# Platform observations only; grouping, claims, attempt markers, notice selection,
# clock updates, canonical promotion and the final drain status stay real.
tap_spool_home_authorized_or_warn() { return 0; }
tap_registry_matches_team() { return 0; }
tap_bound_pane_identity_state() { printf match; }
tap_spool_pane_ready() { printf ready; }
tap_acting_registry() { printf '%s' "$TAP_REGISTRY"; }
tap_spool_team_name() { printf fixture; }
tap_pane_harness_command() { printf codex; }
tmux() { printf codex; }
tap_submit_verify() {
  if [ "$5" = peer ]; then
    # A timeout/uncertain return after an observable attempt, not a no-effect refusal.
    # This stub replaces the submit body, so it must cross the same first-effect
    # boundary before recording the simulated recipient effect.
    tap_delivery_effect_begin "$4" || return 1
    printf '%s\n' "$4" >> "$WORK/recipient-effects"
    return "$submit_rc"
  fi
  printf '%s\n' "$4" >> "$WORK/sender-effects"
  return 0
}
# The sender notice runs natively end to end (spool-deadline.ts -> notice-submit.ts);
# alice's registered pane does not exist on the runner's server, so its wake is
# honestly unverified and the DURABLE digest notice's publication is the observable.
# Missing/empty runtime cases target the digest seam. Keep the real retirement
# preflight available so an earlier dependency failure cannot mask that control.
digest_runtime_path="$PATH"
eval "$(declare -f tap_bun_call | sed '1s/tap_bun_call/real_bun_call/')"
tap_bun_call() {
  if [ "$1" = spool-retired ]; then
    PATH="$digest_runtime_path" real_bun_call "$@"
  else real_bun_call "$@"; fi
}
digest_notice() { printf '%s/%s-alice-delivery-unconfirmed.md' "$TAP_PAYLOADS" "$1"; }
failures=0
check() { if ! "$@"; then printf 'FAIL: rc=%s: %s\n' "$submit_rc" "$*"; failures=$((failures+1)); fi; }
for submit_rc in 0 5 124 7 missing empty; do
  for id in "a-$submit_rc" "b-$submit_rc"; do
    cat > "$TAP_SPOOL/$id.md" <<PAYLOAD
---
id: $id
from: alice
to: peer
kind: discuss
reply: settle-only
path: $TAP_PAYLOADS/$id.md
---
body $id
PAYLOAD
    printf '{"id":"%s","target":"peer","reason":"auto-settle","reason_class":"busy","policy":"autosettle","first_spooled_epoch":1,"hold_until_epoch":0,"deadline_epoch":9999999999,"pane":"sess:0.0","pane_id":"%%401","to_team":"fixture","target_registry":"%s","attempts":0}\n' "$id" "$TAP_REGISTRY" > "$TAP_SPOOL/$id.meta.json"
  done
  : > "$WORK/recipient-effects"; : > "$WORK/sender-effects"
  clock="$(tap_delivery_clock_path "$TAP_REGISTRY" peer)"
  mkdir -p "$(dirname "$clock")"
  printf '{"last_delivered_at":1}\n' > "$clock"
  before="$(tap_delivery_clock_read "$TAP_REGISTRY" peer)"
  notices_before_plus_one="$(( $({ rg -l '^kind: delivery-failed$' "$TAP_PAYLOADS" 2>/dev/null || true; } | wc -l | tr -d ' ') + 1 ))"
  saved_path="$PATH"
  case "$submit_rc" in
    missing)
      PATH=/usr/bin:/bin
      if command -v bun >/dev/null; then echo 'fixture PATH still has bun'; exit 99; fi
      ;;
    empty)
      mkdir -p "$WORK/bin"
      printf '#!/bin/sh\nexit 0\n' > "$WORK/bin/bun"
      chmod +x "$WORK/bin/bun"
      PATH="$WORK/bin:$PATH"
      ;;
  esac
  drain_rc=0
  tap_spool_drain_once 100 8 peer "$TAP_REGISTRY" > "$WORK/drain-$submit_rc.log" 2>&1 || drain_rc=$?
  PATH="$saved_path"
  after="$(tap_delivery_clock_read "$TAP_REGISTRY" peer)"
  case "$submit_rc" in
    missing|empty)
      code=slice_failed; [ "$submit_rc" != missing ] || code=runtime_missing
      # The drain's FIRST native touch is the listing (spool-state, since A1b)
      # or the entry claim (spool-sidecar), so a missing or empty runtime
      # refuses there before the digest slice is ever reached. Any of those
      # slices naming the refusal is the property; no effects, no clock motion
      # and retained entries are the assertions that matter, and they follow.
      check rg -q "$code id=.* slice=(digest|spool-sidecar|spool-state)" "$WORK/drain-$submit_rc.log"
      check test ! -s "$WORK/recipient-effects"
      check test ! -s "$WORK/sender-effects"
      check test "$after" = "$before"
      for id in "a-$submit_rc" "b-$submit_rc"; do
        check test -f "$TAP_SPOOL/$id.md"
        check test ! -e "$TAP_RECEIPTS/$id.attempted"
        check test ! -e "$TAP_SPOOL/$id.claim"
        tap_spool_remove "$id"
      done
      continue
      ;;
  esac
  check test "$(wc -l < "$WORK/recipient-effects" | tr -d ' ')" = 1
  did="$(cat "$WORK/recipient-effects")"
  check test -f "$(tap_digest_index_path "$did")"
  if [ "$submit_rc" = 0 ]; then
    check test "$drain_rc" = 0
    check test -n "$after"
    check test "$after" != "$before"
  elif [ "$submit_rc" = 7 ]; then
    check test "$drain_rc" = 0
    check test "$after" = "$before"
    check test ! -s "$WORK/sender-effects"
    for id in "a-$submit_rc" "b-$submit_rc"; do
      check test -f "$TAP_RECEIPTS/$id.harness-queued"
      check test ! -e "$TAP_RECEIPTS/$id.sent"
      check test ! -e "$TAP_RECEIPTS/$id.done"
    done
  else
    check test "$drain_rc" != 0
    check test "$after" = "$before"
    # Both members are from alice: one durable notice for this digest and sender,
    # naming the digest, with one attempt record behind it.
    check test -f "$(digest_notice "$did")"
    check rg -q "^Digest notice: $did-alice-delivery-unconfirmed\$" "$(digest_notice "$did")"
    check test "$({ rg -l '^kind: delivery-failed$' "$TAP_PAYLOADS" || true; } | wc -l | tr -d ' ')" = "$notices_before_plus_one"
    check test -f "${TAP_PAYLOADS}/$did-alice-delivery-unconfirmed.attempts"
    cp "${TAP_PAYLOADS}/$did-alice-delivery-unconfirmed.attempts" "$WORK/notice-$submit_rc.attempts"
    for id in "a-$submit_rc" "b-$submit_rc"; do
      check test ! -e "$TAP_RECEIPTS/$id.done"
      check test ! -e "$TAP_RECEIPTS/$id.sent"
    done
    if [ "$submit_rc" = 124 ]; then
      check rg -q 'timeout' "$WORK/drain-$submit_rc.log"
    fi
  fi
  for id in "a-$submit_rc" "b-$submit_rc"; do
    check test -f "$TAP_PAYLOADS/$id.md"
    check test ! -e "$TAP_SPOOL/$id.md"
    check test -f "$TAP_RECEIPTS/$id.attempted"
    cp "$TAP_RECEIPTS/$id.attempted" "$WORK/$id.attempted"
  done
  # A second drain must not touch the pane or rewrite the attempt markers — nor
  # wake the sender again: the durable notice is re-validated, never re-submitted.
  tap_spool_drain_once 101 8 peer "$TAP_REGISTRY"
  check test "$(wc -l < "$WORK/recipient-effects" | tr -d ' ')" = 1
  for id in "a-$submit_rc" "b-$submit_rc"; do
    check cmp "$TAP_RECEIPTS/$id.attempted" "$WORK/$id.attempted"
  done
  case "$submit_rc" in 5|124)
    check cmp "${TAP_PAYLOADS}/$did-alice-delivery-unconfirmed.attempts" "$WORK/notice-$submit_rc.attempts" ;;
  esac
done
[ "$failures" = 0 ]
