#!/usr/bin/env bash
# acting-registry-reader-enum.test.sh — mechanical guard for the
# early-return-on-legacy-TAP_REGISTRY / missing-rebind class (opus/fable wave 3).
#
# Every production .sh under skills/tap/scripts/ and hooks/ that *reads*
# $TAP_REGISTRY must either:
#   (a) call tap_require_acting_registry / tap_rebind_acting_registry /
#       tap_acting_registry in the same function before the first read, OR
#   (b) appear on the exemption list below with a non-empty reason string.
#
# Shape guard: an exemption entry without a reason fails this smoke — the
# allowlist is not an escape hatch (same polarity as session-root-gate-enum).
#
# Bidirectional validation (fable/opus 2026-07-30): scratch-revert the
# cmd_restore require line → RED attributed to tap-teardown/cmd_restore;
# remove one exemption → RED; restore both → GREEN.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
cd "$ROOT"

fail() { echo "acting-registry-reader-enum: $*" >&2; exit 1; }

# file:function → reason (reason REQUIRED — empty fails shape guard)
# shellcheck disable=SC2034  # consumed by the python enumerator
EXEMPTIONS="$(cat <<'EOF'
skills/tap/scripts/lib.sh:tap_require_acting_registry|choke point itself — rebind then existence check
skills/tap/scripts/lib.sh:tap_rebind_acting_registry|choke point writer — sets TAP_REGISTRY from acting sample
skills/tap/scripts/lib.sh:tap_acting_registry|choke point reader — samples authority context
skills/tap/scripts/lib.sh:tap_spool_team_name|must not call require — authority_context live arm calls this (recursion); reads sibling team-registry directly
skills/tap/scripts/lib.sh:tap_apply_team_override|sets bus TAP_REGISTRY then explicitly rebinds — the ambient assignment is pre-rebind setup
skills/tap/scripts/lib.sh:*|lib.sh shared helpers: remaining TAP_REGISTRY reads are post-rebind ambient after caller require/rebind, or pre-flip bootstrap (tap_registry_ensure_team)
skills/tap/scripts/tap-send.sh:*|bus-oriented courier — payloads/receipts on TAP_HOME; acting registry sampled via tap_authority_context / apply_team_override at verb entry
skills/tap/scripts/tap-reply.sh:*|bus-oriented — delegates to send/done after apply_team_override
skills/tap/scripts/tap-reply-settle.sh:*|bus-oriented settlement — apply_team_override + acting_registry sample for external settle
skills/tap/scripts/tap-cancel.sh:*|bus-oriented — apply_team_override; acting_registry for foreign cancel
skills/tap/scripts/tap-doctor.sh:*|observational bus health — reports ambient/bus paths by design
skills/tap/scripts/init-storage.sh:*|marker-sampled first (WAVE 6.11): only absent licenses pre-cutover bus registry ensure/migrate; live uses resolve; invalid refuses before any registry write
skills/tap/scripts/smoke/*:*|fixture/smoke scripts — exercise the system under test; not production readers
skills/tap/scripts/regress/*:*|fixture/regress scripts — exercise the system under test; not production readers
EOF
)"

# Validate shape: every exemption line is path|reason with non-empty reason
while IFS= read -r line; do
  [ -n "$line" ] || continue
  case "$line" in
    '#'*) continue ;;
  esac
  case "$line" in
    *'|'*)
      reason="${line#*|}"
      [ -n "$reason" ] || fail "shape guard: exemption lacks reason: $line"
      ;;
    *) fail "shape guard: exemption must be file:func|reason: $line" ;;
  esac
done <<<"$EXEMPTIONS"

export ACTING_ENUM_EXEMPTIONS="$EXEMPTIONS"
python3 -B - "$ROOT" <<'PY'
import os, re, sys
from pathlib import Path

root = Path(sys.argv[1])
fail = lambda msg: (_ for _ in ()).throw(SystemExit(f"acting-registry-reader-enum: {msg}"))

# Parse exemptions: file:func|reason  (func may be *)
exempt = {}  # (file, func) -> reason ; also (file, "*")
for line in os.environ["ACTING_ENUM_EXEMPTIONS"].splitlines():
    line = line.strip()
    if not line or line.startswith("#"):
        continue
    if "|" not in line:
        fail(f"shape guard: exemption must be file:func|reason: {line}")
    key, reason = line.split("|", 1)
    if not reason.strip():
        fail(f"shape guard: exemption lacks reason: {line}")
    if ":" not in key:
        fail(f"shape guard: exemption key must be file:func: {line}")
    fpath, func = key.split(":", 1)
    exempt[(fpath, func)] = reason.strip()

RE_FUNC = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*\(\)\s*\{")
RE_READ = re.compile(r"\$\{?TAP_REGISTRY\}?")
RE_ASSIGN = re.compile(r"^\s*TAP_REGISTRY=")
RE_CHOKE = re.compile(
    r"\b(tap_require_acting_registry|tap_rebind_acting_registry|tap_acting_registry)\b"
)
# Skip comment-only lines
RE_COMMENT = re.compile(r"^\s*(#|//)")

scan_roots = [
    root / "skills" / "tap" / "scripts",
    root / "hooks",
]
# Skip smoke/ and session/ python; only .sh production + hooks
files = []
for base in scan_roots:
    if not base.is_dir():
        continue
    for p in base.rglob("*.sh"):
        rel = str(p.relative_to(root))
        # tap-52ys: fixtures exercise the system in BOTH suite buckets.
        if "/smoke/" in rel.replace("\\", "/") or "/regress/" in rel.replace("\\", "/"):
            continue  # covered by smoke/* exemption; skip enumeration noise
        files.append(p)

unsanctioned = []

def is_exempt(rel: str, func: str) -> bool:
    if (rel, func) in exempt:
        return True
    if (rel, "*") in exempt:
        return True
    return False

for path in sorted(files):
    rel = str(path.relative_to(root)).replace("\\", "/")
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    # Top-level choke persists across helper-function definitions in linear
    # scripts (tap-register / tap-unregister): a rebind at line 289 still
    # covers later top-level reads after a helper function is *defined*.
    toplevel = {"name": "__toplevel__", "choke_line": None, "reads": []}
    current = toplevel
    brace_depth = 0
    in_func = False

    def flush(cur):
        if not cur["reads"]:
            cur["reads"] = []
            return
        name = cur["name"]
        if is_exempt(rel, name) or is_exempt(rel, "*"):
            cur["reads"] = []
            return
        first_read = cur["reads"][0][0]
        choke_before = cur.get("choke_line")
        # Top-level may inherit nothing; named functions must choke themselves
        # (file-level rebind does NOT cover cmd_restore — that was the bug).
        if name == "__toplevel__" and choke_before is not None and choke_before <= first_read:
            cur["reads"] = []
            return
        if name != "__toplevel__" and choke_before is not None and choke_before <= first_read:
            cur["reads"] = []
            return
        for lineno, snippet in cur["reads"]:
            unsanctioned.append((rel, name, lineno, snippet))
        cur["reads"] = []

    i = 0
    while i < len(lines):
        lineno = i + 1
        line = lines[i]
        m = RE_FUNC.match(line)
        if m and not in_func:
            flush(toplevel)
            current = {"name": m.group(1), "choke_line": None, "reads": []}
            in_func = True
            brace_depth = line.count("{") - line.count("}")
            i += 1
            # Handle one-line functions: foo() { ... }
            if in_func and brace_depth <= 0:
                if RE_CHOKE.search(line) and current["choke_line"] is None:
                    current["choke_line"] = lineno
                if RE_READ.search(line) and not RE_ASSIGN.match(line) and not RE_COMMENT.match(line):
                    current["reads"].append((lineno, line.strip()[:80]))
                flush(current)
                current = toplevel
                in_func = False
            continue
        if in_func:
            brace_depth += line.count("{") - line.count("}")
        if RE_COMMENT.match(line):
            i += 1
            if in_func and brace_depth <= 0:
                flush(current)
                current = toplevel
                in_func = False
            continue
        if RE_CHOKE.search(line):
            if current.get("choke_line") is None:
                current["choke_line"] = lineno
            # Also record top-level chokes when at top level
            if current is toplevel and toplevel["choke_line"] is None:
                toplevel["choke_line"] = lineno
        if RE_ASSIGN.match(line):
            i += 1
            if in_func and brace_depth <= 0:
                flush(current)
                current = toplevel
                in_func = False
            continue
        if RE_READ.search(line):
            current["reads"].append((lineno, line.strip()[:80]))
        if in_func and brace_depth <= 0:
            flush(current)
            current = toplevel
            in_func = False
        i += 1
    flush(toplevel if current is toplevel else current)
    if current is not toplevel:
        flush(toplevel)

if unsanctioned:
    print("acting-registry-reader-enum: UNSANCTIONED readers:", file=sys.stderr)
    for rel, name, lineno, snippet in unsanctioned:
        print(f"  {rel}:{name}:{lineno}: {snippet}", file=sys.stderr)
    fail(f"unsanctioned TAP_REGISTRY readers: {len(unsanctioned)}")

# WAVE 6.11: failed acting sample must NEVER be followed by ambient TAP_REGISTRY
# substitution (the class that let settlement authorize via a bus decoy).
# Matches:  reg="$(tap_acting_registry ... || true)" / then
#           [ -n "$reg" ] || reg="$TAP_REGISTRY"
RE_ACTING_ASSIGN = re.compile(
    r"""(?:^|\n)\s*(\w+)=\$\(\s*tap_acting_registry\b[^)]*\|\|\s*true\s*\)"""
)
RE_AMBIENT_FALLBACK = re.compile(
    r"""\[\s*-n\s+\"\$\{?(\w+)\}?\"\s*\]\s*\|\|\s*\1=\"\$TAP_REGISTRY\""""
)
ambient_hits = []
appendix_files = [
    root / "skills/tap/scripts/lib.sh",
    root / "skills/tap/scripts/tap-reply.sh",
    root / "skills/tap/scripts/tap-reply-settle.sh",
    root / "skills/tap/scripts/tap-cancel.sh",
]
for path in appendix_files:
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8", errors="replace")
    rel = str(path.relative_to(root)).replace("\\", "/")
    # Any line that assigns ambient after a non-empty check on a var that was
    # filled from tap_acting_registry || true in the same file.
    acting_vars = set()
    for m in RE_ACTING_ASSIGN.finditer(text):
        acting_vars.add(m.group(1))
    for i, line in enumerate(text.splitlines(), 1):
        if RE_COMMENT.match(line):
            continue
        m = RE_AMBIENT_FALLBACK.search(line)
        if m and m.group(1) in acting_vars:
            ambient_hits.append(f"{rel}:{i}: {line.strip()[:100]}")
        # Also catch the classic two-token form without capture reuse
        if re.search(r'\|\|\s*\w+=\"\$TAP_REGISTRY\"', line) and "tap_acting" not in line:
            # only flag if previous non-comment line was acting||true assign
            pass
    # Broader: any `|| <var>="$TAP_REGISTRY"` immediately after acting||true
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if "tap_acting_registry" in line and "||" in line and "true" in line:
            for j in range(i + 1, min(i + 4, len(lines))):
                nxt = lines[j]
                if RE_COMMENT.match(nxt):
                    continue
                if re.search(r'=\s*"\$TAP_REGISTRY"', nxt) and "||" in nxt:
                    ambient_hits.append(
                        f"{rel}:{j+1}: ambient fallback after acting||true — {nxt.strip()[:100]}"
                    )
                break

if ambient_hits:
    print("acting-registry-reader-enum: AMBIENT FALLBACK AFTER FAILED ACTING:", file=sys.stderr)
    for h in ambient_hits:
        print(f"  {h}", file=sys.stderr)
    fail(f"ambient TAP_REGISTRY substitution after failed acting sample: {len(ambient_hits)}")

print("acting-registry-reader-enum: 0 unsanctioned readers; exemptions shaped: ok")
print("acting-registry-reader-enum: 0 ambient-after-acting fallbacks; ok")
print("acting-registry-reader-enum: all checks passed")
PY
