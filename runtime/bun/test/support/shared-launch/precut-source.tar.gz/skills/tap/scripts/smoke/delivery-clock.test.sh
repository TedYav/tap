#!/usr/bin/env bash
# delivery-clock.test.sh — tap-7r3fn.20 U1+2. The recipient's delivery clock:
# it lives on the RECIPIENT's bus resolved from `target_registry`, it holds one
# field, and on an unbound send it does nothing at all.
#
# The containment arm is the point of this file. Ruling 43 says the unbound
# `--cross-worktree --pane` route never enters the window, and an empty
# `target_registry` has TWO wrong answers available to it rather than one:
#
#   - `tap_clear_fence_bus` defaults an empty argument to
#     `${TARGET_REGISTRY:-$TAP_REGISTRY}` (lib.sh:295), so a helper that passed
#     the empty string through keeps the SENDER's own bus and windows every
#     recipient against one shared clock. This is the failure the arm observes:
#     removing the refusal resolves `peer` onto `$TAP_HOME/delivery/peer.json`.
#   - `busForRegistry("")` returns the resolved empty path's parent, the
#     PARENT of the courier's working directory — a stray `delivery/` tree inside
#     a repository checkout during an ordinary send.
#
# THE SECOND ONE IS NOT REACHABLE THROUGH THIS HELPER, AND THE COMMENT SAYS SO
# RATHER THAN TAKING CREDIT FOR IT. `TAP_REGISTRY` is assigned unconditionally at
# lib.sh:94, so the shell default always substitutes something non-empty and the
# empty string never reaches python by this path — running the mutated helper with
# `TAP_REGISTRY=` still lands on the sender bus, not the CWD. The arm watches the
# working directory and its parent anyway: it costs one `find`, and it pins the
# property directly if that default is ever removed.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
# Physical path: bus_for_registry() calls Path.resolve(), and on macOS /var is a
# symlink to /private/var — a logical mktemp path would make every comparison
# below fail on the symlink rather than on the behavior.
WORK="$(cd "$(mktemp -d)" && pwd -P)"
trap 'rm -rf "$WORK"' EXIT

export TAP_HOME="$WORK/sender-bus"
export TAP_INDEX_HOME="$WORK/index"
mkdir -p "$TAP_HOME"
# shellcheck source=skills/tap/scripts/lib.sh
. "$ROOT/skills/tap/scripts/lib.sh"

fail() { echo "delivery-clock: FAIL — $*" >&2; exit 1; }
ok()   { echo "  ok   $*"; }

# A recipient bus with its registry beside it (the pre-flip layout
# busForRegistry handles: registry.json lives IN the bus).
RECIP_BUS="$WORK/recipient-bus"
mkdir -p "$RECIP_BUS"
REG="$RECIP_BUS/registry.json"
echo '{}' > "$REG"

# --- 1. the path resolves onto the RECIPIENT's bus, not the sender's ----------
path="$(tap_delivery_clock_path "$REG" "peer")"
[ -n "$path" ] || fail "expected a path for a bound registry, got empty"
case "$path" in
  "$RECIP_BUS"/delivery/peer.json) ok "path lands on the recipient bus: \${bus}/delivery/peer.json" ;;
  *) fail "path resolved to '$path', expected '$RECIP_BUS/delivery/peer.json'" ;;
esac
case "$path" in
  "$TAP_HOME"/*) fail "path resolved onto the SENDER's bus ($TAP_HOME) — the clock is the recipient's fact" ;;
  *) ok "path is not on the sender's bus" ;;
esac

# --- 2. a team-qualified handle is stripped, like clear_fence.fence_path ------
qualified="$(tap_delivery_clock_path "$REG" "tap/peer")"
[ "$qualified" = "$path" ] || fail "'tap/peer' resolved to '$qualified', expected the same file as 'peer'"
ok "a <team>/<handle> address names the same file as the bare handle"

# --- 3. stamp then read round-trips one field --------------------------------
tap_delivery_clock_stamp "$REG" "peer" 1788000000
[ -f "$path" ] || fail "stamp wrote no file at $path"
got="$(tap_delivery_clock_read "$REG" "peer")"
[ "$got" = 1788000000 ] || fail "read returned '$got', expected 1788000000"
ok "stamp then read round-trips the epoch"

keys="$(python3 -B -c 'import json,sys; print(",".join(sorted(json.load(open(sys.argv[1])))))' "$path")"
[ "$keys" = "handle,last_delivered_at" ] \
  || fail "clock file carries keys '$keys'; ruling 22 cut everything but last_delivered_at"
ok "the file carries only last_delivered_at (plus the handle it is about)"

# --- 4. a later stamp advances it; the reader sees the newest ----------------
tap_delivery_clock_stamp "$REG" "peer" 1788000600
got="$(tap_delivery_clock_read "$REG" "peer")"
[ "$got" = 1788000600 ] || fail "after a second stamp read returned '$got', expected 1788000600"
ok "a later verified delivery advances the clock"

# --- 4b. the clock never goes backward (out-of-order completion) -------------
# sol's R1 finding. Two couriers can deliver to one seat at once and
# submit-verify takes real time, so the LATER delivery can finish FIRST. A
# last-writer-wins rewrite would then move the clock behind a delivery that
# already happened, and every entry armed against it flushes early — the
# recipient gets the flood the window exists to prevent, at the one moment they
# were demonstrably busy.
tap_delivery_clock_stamp "$REG" "peer" 1788001000
tap_delivery_clock_stamp "$REG" "peer" 1788000900   # an older delivery finishing late
got="$(tap_delivery_clock_read "$REG" "peer")"
[ "$got" = 1788001000 ] \
  || fail "an out-of-order stamp moved the clock backward to '$got'; it must keep the newest verified delivery (1788001000)"
tap_delivery_clock_stamp "$REG" "peer" 1788001500   # a genuinely newer one still advances
got="$(tap_delivery_clock_read "$REG" "peer")"
[ "$got" = 1788001500 ] \
  || fail "a newer stamp did not advance the clock (got '$got'); monotonic must not mean frozen"
ok "an older stamp arriving late is ignored; a newer one still advances the clock"

# --- 4c. concurrent stampers do not lose each other -------------------------
# The lock, not just the comparison. Eight writers race with descending epochs,
# so a lost update or a torn read shows up as anything but the maximum.
race_clock="$(tap_delivery_clock_path "$REG" "racer")"
mkdir -p "$(dirname "$race_clock")"
rm -f "$race_clock"
for i in 8 7 6 5 4 3 2 1; do
  tap_delivery_clock_stamp "$REG" "racer" "$(( 1788002000 + i ))" &
done
wait
got="$(tap_delivery_clock_read "$REG" "racer")"
[ "$got" = 1788002008 ] \
  || fail "after eight concurrent stamps the clock reads '$got', expected the maximum 1788002008"
python3 -B -c 'import json,sys; json.load(open(sys.argv[1]))' "$race_clock" \
  || fail "concurrent stamps left the clock file unparseable; a reader can see a torn write"
ok "eight concurrent stamps leave the maximum and a well-formed file"

# --- 5. an unknown seat reads empty, not an error ----------------------------
got="$(tap_delivery_clock_read "$REG" "never-heard-from")"
[ -z "$got" ] || fail "an unstamped seat read '$got', expected empty (first message is instant)"
ok "an unstamped seat reads empty — the first-message-instant rule"

# --- 6. a corrupt clock reads empty rather than aborting a delivery ----------
bad="$(tap_delivery_clock_path "$REG" "corrupt")"
mkdir -p "$(dirname "$bad")"
printf 'not json at all' > "$bad"
got="$(tap_delivery_clock_read "$REG" "corrupt")"
[ -z "$got" ] || fail "a corrupt clock read '$got', expected empty"
printf '{"last_delivered_at": "soon"}' > "$bad"
got="$(tap_delivery_clock_read "$REG" "corrupt")"
[ -z "$got" ] || fail "a non-numeric last_delivered_at read '$got', expected empty"
printf '{"last_delivered_at": true}' > "$bad"
got="$(tap_delivery_clock_read "$REG" "corrupt")"
[ -z "$got" ] || fail "a boolean last_delivered_at read '$got', expected empty (true is an int in Python)"
ok "a corrupt, non-numeric, or boolean clock reads empty rather than aborting"

# --- 7. CONTAINMENT: an unbound send touches nothing, anywhere ---------------
# The whole reason this arm exists: Path("") resolves to the CWD, so an empty
# registry that was not refused would write here.
PROBE="$WORK/cwd-probe/inner"
mkdir -p "$PROBE"
before="$(find "$WORK/cwd-probe" "$TAP_HOME" "$RECIP_BUS" -newer "$REG" -type f 2>/dev/null | sort)"
(
  cd "$PROBE"
  empty_path="$(tap_delivery_clock_path "" "peer")"
  [ -z "$empty_path" ] || { echo "delivery-clock: FAIL — an empty registry resolved to '$empty_path'" >&2; exit 1; }
  tap_delivery_clock_stamp "" "peer" 1788009999
  got="$(tap_delivery_clock_read "" "peer")"
  [ -z "$got" ] || { echo "delivery-clock: FAIL — an empty registry read '$got'" >&2; exit 1; }
) || exit 1
# The working directory AND its parent: bus_for_registry("") returns the parent.
[ -z "$(find "$WORK/cwd-probe" -type f 2>/dev/null)" ] \
  || fail "an unbound stamp wrote near the CWD: $(find "$WORK/cwd-probe" -type f)"
after="$(find "$WORK/cwd-probe" "$TAP_HOME" "$RECIP_BUS" -newer "$REG" -type f 2>/dev/null | sort)"
[ "$before" = "$after" ] || fail "an unbound stamp changed files: $(diff <(echo "$before") <(echo "$after") | tr '\n' ' ')"
ok "an unbound send resolves to no path, writes nothing, and reads empty"

# --- 8. a handle with no registry is equally inert ---------------------------
[ -z "$(tap_delivery_clock_path "$REG" "")" ] || fail "an empty handle resolved to a path"
ok "an empty handle resolves to no path"

# =============================================================================
# END TO END: a real `tap send` advances the clock; a poll delivery does not.
# The unit arms above prove the helper; these prove it is WIRED to the event that
# is supposed to move it, which is a separate claim and the one that regresses.
# =============================================================================
(
  E2E="$WORK/e2e"
  FAKE_BIN="$E2E/bin"
  mkdir -p "$FAKE_BIN" "$E2E/tmux" "$E2E/repo"
  cat > "$FAKE_BIN/tmux" <<'TMUXMOCK'
#!/usr/bin/env bash
set -euo pipefail
state="${FAKE_TMUX_STATE:?}"; mkdir -p "$state"
# tmux resolves numeric pane ids and session addresses to the same input band.
args=()
for arg in "$@"; do
  case "$arg" in %401) arg=sess:0.0 ;; %402) arg=sess:0.1 ;; %403) arg=sess:0.2 ;; esac
  args+=("$arg")
done
set -- "${args[@]}"
cmd="$1"; shift
case "$cmd" in
  list-sessions) printf 'sess\t4242:100\n' ;;
  list-panes)
    printf 'sess\tsess:0.0\t%%401\t%s\t5001\t4242:100\n' "${FAKE_TMUX_CMD:-codex}" ;;
  display-message)
    fmt="${@: -1}"
    case "$fmt" in
      *pane_id*session_name*pane_pid*pane_current_command*) printf '%s\tsess\t4242\t%s\n' "${FAKE_PANE_ID:-%401}" "${FAKE_TMUX_CMD:-codex}" ;;
      '#{pid}:#{start_time}') printf '4242:100\n' ;;
      *pane_id*pane_tty*session_name*) printf '%s\t/dev/faketty\tsess\t4242:100\n' "${FAKE_PANE_ID:-%401}" ;;
      *pane_id*session_name*) printf '%s\tsess\t4242:100\n' "${FAKE_PANE_ID:-%401}" ;;
      *session_name*)         echo "sess" ;;
      *pane_id*)              echo "${FAKE_PANE_ID:-%401}" ;;
      *pane_pid*)             echo "4242" ;;
      *pane_in_mode*)         echo "0" ;;
      *pane_current_command*) echo "${FAKE_TMUX_CMD:-codex}" ;;
      *pane_current_path*)    echo "${FAKE_WORKTREE:?}" ;;
      *window_activity*)      echo "100" ;;
      *)                      echo "" ;;
    esac ;;
  capture-pane)
    target=""
    while [ $# -gt 0 ]; do case "$1" in -t) target="$2"; shift 2 ;; *) shift ;; esac; done
    key="${target//[:.\/]/_}"
    if [ -f "$state/input.$key" ]; then printf '❯ %s\n' "$(cat "$state/input.$key")"
    else printf '❯ \n'; fi ;;
  send-keys)
    echo "$*" >> "$state/send-keys.log"
    key=""
    [ "${1:-}" = "-t" ] && { key="${2//[:.\/]/_}"; shift 2; }
    if [ "${1:-}" = "-l" ]; then
      shift; [ "${1:-}" = "--" ] && shift
      printf '%s' "${1:-}" > "$state/input.$key"
      exit 0
    fi
    if [ "${1:-}" = "Enter" ]; then rm -f "$state/input.$key"; exit 0; fi
    ;;
esac
TMUXMOCK
  chmod +x "$FAKE_BIN/tmux"
  export PATH="$FAKE_BIN:$PATH" TMUX="/fake/socket" FAKE_TMUX_STATE="$E2E/tmux" \
         FAKE_WORKTREE="$E2E/repo" FAKE_TMUX_CMD="codex" FAKE_PANE_ID="%401"
  export TAP_SERVER_EPOCH="srv:4242:100" TAP_BOOT_ID="boot:1"
  BUS="$E2E/repo/.tap/bus"; mkdir -p "$BUS/payloads" "$BUS/receipts" "$BUS/spool"
  export TAP_HOME="$BUS"
  cat > "$BUS/registry.json" <<JSON
{ "team": { "name": "t", "worktree_root": "$E2E/repo" },
  "agents": {
    "peer":  { "session": "sess", "pane": "sess:0.0", "pane_id": "%401", "harness": "codex", "status": "active", "server_epoch": "srv:4242:100", "boot_id": "boot:1", "registered_from_worktree": "$E2E/repo" },
    "alice": { "session": "sess", "pane": "sess:0.0", "pane_id": "%401", "harness": "codex", "status": "active", "server_epoch": "srv:4242:100", "boot_id": "boot:1", "registered_from_worktree": "$E2E/repo" },
    "ghost": { "delivery": "poll", "unattended": true, "status": "active", "harness": "codex" }
  } }
JSON
  CLOCK_DIR="$BUS/delivery"

  # A --wake send injects (it declines the hold), so it is a verified pane delivery.
  [ ! -e "$CLOCK_DIR/peer.json" ] || fail "e2e: a clock existed before any delivery"
  TAP_AUTOSETTLE_HOLD_SECONDS=99999 bash "$ROOT/skills/tap/scripts/tap.sh" \
    send peer -m "hello" --id e2e1 --from alice --wake >/dev/null 2>&1 \
    || fail "e2e: --wake send failed"
  [ -f "$BUS/receipts/e2e1.sent" ] || fail "e2e: the send wrote no .sent receipt"
  [ -f "$CLOCK_DIR/peer.json" ] \
    || fail "e2e: a verified pane delivery did not stamp the recipient clock"
  stamped="$(python3 -B -c 'import json,sys; print(json.load(open(sys.argv[1]))["last_delivered_at"])' "$CLOCK_DIR/peer.json")"
  case "$stamped" in ''|*[!0-9]*) fail "e2e: clock holds '$stamped', expected an epoch" ;; esac
  ok "a verified pane send stamps the recipient's clock"

  # A poll recipient never has its pane touched. The SAME `.sent` writer runs for
  # it, which is why the stamp is gated on `delivery`, not on reaching that line.
  TAP_AUTOSETTLE_HOLD_SECONDS=99999 bash "$ROOT/skills/tap/scripts/tap.sh" \
    send ghost -m "queued" --id e2e2 --from alice --wake >/dev/null 2>&1 \
    || fail "e2e: poll send failed"
  [ -f "$BUS/receipts/e2e2.sent" ] || fail "e2e: the poll send wrote no .sent receipt"
  [ ! -e "$CLOCK_DIR/ghost.json" ] \
    || fail "e2e: a poll queue-up stamped a clock — a recipient reading its own mail is not a wake"
  ok "a poll delivery writes .sent but stamps no clock"
) || exit 1

echo "delivery-clock: ok"
