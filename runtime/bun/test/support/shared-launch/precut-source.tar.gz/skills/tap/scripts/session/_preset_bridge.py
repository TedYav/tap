"""Forwarding bridge to the native preset engine.

This module holds NO catalog reader, NO selection rule and NO notice policy. It
serializes a request, runs `runtime/bun/src/slices/preset-api.ts`, and turns one
response back into the values and exceptions `presets.py`'s callers already
handle.

**The packet is the signal, not the exit code.** A DESIGNED refusal — an
unusable catalog, a preset that is not there — is a successful conversation: the
door exits 0 and returns ``{"ok": false, "refusal": {...}}``, and that becomes
``PresetError``. Everything that stops the conversation happening stays a
transport failure and keeps its own type:

    bun not on PATH .................. FileNotFoundError
    non-zero exit, or exit 0 with
    unparseable/truncated stdout ..... CalledProcessError

Those are the three classes ``launcher.py`` already separates, so nothing here
invents a taxonomy its callers have to learn. **No transport failure may become
a PresetError**, and in particular none may become ``preset_config_missing``:
``tap-ask.py`` renders that class as "not a known harness, and no preset config
was loaded", so a flattened transport failure would tell an operator their
config is absent when the truth is that Bun never ran. Infrastructure failure
never maps to predicate-false.

**Notice state travels as a value.** ``{"suppressed": bool, "said": [str]}`` is
carried here between calls and handed back to the engine untouched. A command
suppresses once and emits at several later sites; each of those is a separate
child, so the lifetime has to be data or the fourth emit forgets what the first
said. This module never inspects that value — the dedup and suppression policy
stays on the engine side, which is the whole reason the state is opaque here.
"""
from __future__ import annotations

import json
import os
import pathlib
import subprocess
import sys
from typing import Any

# scripts/session -> scripts -> tap -> skills -> repo root. The sibling
# modules that reach runtime/ from scripts/ use parents[3]; this one is a
# directory deeper.
_DOOR = pathlib.Path(__file__).resolve().parents[4] / "runtime/bun/src/slices/preset-api.ts"

# The transport is bound HERE, at import, and never looked up again.
#
# `subprocess.run` is one shared attribute on one shared module object, so
# `mock.patch.object(launcher.subprocess, "run", ...)` -- which the launcher
# tests use to fake tmux -- also replaces the function this bridge would call.
# The fake answers a question about tmux with a tmux-shaped result, the bridge
# reads it as a truncated packet, and a preset lookup fails because something
# else was being tested. A test double for one transport must not silently
# become the transport for another.
#
# A caller that genuinely needs to stub the engine stubs `call` itself, which is
# this module's seam. A test that needs to fake `bun` builds a PATH containing a
# fake `bun`, which is what `preset-bridge-transport.test.sh` does -- that
# exercises the real transport instead of replacing it.
_RUN = subprocess.run

# How `bun` is found, in the order the repo already established.
#
# `scripts/smoke-all.sh` resolves bun from the CALLER's environment and admits it
# as `TAP_SMOKE_BUN` before re-execing workers under a fixed PATH; that fixed
# PATH does not necessarily contain bun, which is exactly why the variable
# exists. `runtime/bun/test/run.sh` reads it the same way. Honouring it here is
# using that seam rather than inventing one -- a bare `bun` works in production
# and stops working the moment a caller narrows PATH deliberately.
def _bun() -> str:
    override = os.environ.get("TAP_SMOKE_BUN")
    return override if override else "bun"

# The notice lifetime, carried across calls. Opaque by design: see the module
# docstring. `reset_notices()` is what clears it at a command boundary.
_state: dict[str, Any] = {"suppressed": False, "said": []}


def _transport(completed: subprocess.CompletedProcess[str], argv: list[str]) -> None:
    """Raise a transport failure, never with a SUCCESS returncode.

    `launcher.py:10838-10840` prints "command failed (exit N)" and then returns
    N. A CalledProcessError carrying returncode 0 -- which is exactly what a
    truncated write from an exit-0 process produces -- would print a failure and
    return success. The substituted code is the door's own "could not answer"
    exit, so the failure stays a failure all the way out.
    """
    raise subprocess.CalledProcessError(
        completed.returncode or 3, argv, completed.stdout, completed.stderr
    )


def _raise_preset_error(refusal: dict[str, Any]) -> None:
    from presets import PresetError  # circular by construction; the DTO lives there

    # Every field is present and a string by the time this is reached
    # (`_valid_refusal`), so nothing here substitutes or coerces. Defaulting was
    # how an absent `action` became an empty repair instruction.
    raise PresetError(refusal["error_class"], refusal["action"], refusal["detail"])


def _packet_field(packet: dict[str, Any], key: str) -> Any:
    """Absent is not null. A response that OMITS `value` is malformed, not empty."""
    if key not in packet:
        raise KeyError(key)
    return packet[key]


def _valid_state(state: Any) -> bool:
    """The notice lifetime, by TYPE. Key presence alone accepts `said: "bad"`."""
    return (
        isinstance(state, dict)
        and isinstance(state.get("suppressed"), bool)
        and isinstance(state.get("said"), list)
        and all(isinstance(item, str) for item in state["said"])
    )


def _valid_refusal(refusal: Any) -> bool:
    """A refusal carries three fields and all three are strings.

    `error_class` alone is not a refusal: defaulting the other two to "" invents
    an empty repair instruction, and a refusal that says what is wrong but not
    what to do is the exact regression `PresetError.action` exists to prevent.
    """
    return (
        isinstance(refusal, dict)
        and isinstance(refusal.get("error_class"), str) and bool(refusal["error_class"])
        and isinstance(refusal.get("action"), str)
        and isinstance(refusal.get("detail"), str)
    )


def call(op: str, **payload: Any) -> Any:
    """Run one op against the native engine and return its value.

    Raises PresetError for a designed refusal; FileNotFoundError or
    CalledProcessError for a transport failure. Never converts one into the
    other, and never invents a field the engine did not send.
    """
    global _state
    request = {"op": op, "state": _state, "env": dict(os.environ), **payload}
    argv = [_bun(), str(_DOOR)]
    try:
        completed = _RUN(
            argv,
            input=json.dumps(request),
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        # bun is not installed. A missing runtime is not a statement about the
        # operator's catalog, so it keeps its own type and its own message.
        raise FileNotFoundError(
            f"tap: the preset engine needs bun on PATH (running {op})"
        ) from None

    # Unconditional relay. The facade does not decide which of the child's bytes
    # are notices -- the engine already decided by writing them.
    if completed.stderr:
        sys.stderr.write(completed.stderr)

    # TRANSPORT IS CHECKED FIRST, BEFORE THE PACKET IS BELIEVED AT ALL.
    #
    # A failed child's refusal packet is not a refusal. A `bun` that writes a
    # coded `preset_config_missing` and then exits 7 was not answering a question
    # about the catalog, and accepting that packet is precisely the
    # transport-to-missing-config mapping rule 19 forbids -- `tap-ask.py:171`
    # would render it as "no preset config was loaded" to an operator whose
    # config is fine. A success packet from a failed process was already refused
    # here; its refusal packet has to be refused on the same grounds.
    if completed.returncode != 0:
        _transport(completed, argv)

    stdout = completed.stdout.strip()
    packet: Any = None
    if stdout:
        try:
            packet = json.loads(stdout)
        except json.JSONDecodeError:
            packet = None
    if not isinstance(packet, dict):
        # Exit 0 with nothing parseable is still a transport failure: a truncated
        # write is indistinguishable from a successful empty answer unless we
        # refuse it here.
        _transport(completed, argv)

    ok = packet.get("ok")
    if ok is False:
        refusal = packet.get("refusal")
        if not _valid_refusal(refusal):
            # A malformed refusal is not a refusal. Classing it would invent an
            # error the engine did not make, and defaulting its missing fields
            # would put words in the operator's repair instruction.
            _transport(completed, argv)
        # The lifetime is validated and stored BEFORE raising. A refusing op
        # still emitted notices on its way to refusing, and raising first threw
        # that history away -- the next call in the same command then repeated
        # them.
        #
        # An INVALID state on a refusal is a transport failure, exactly as it is
        # on a success. Accepting the refusal while quietly discarding the state
        # would drop the command's notice context with nothing to show for it,
        # which is the same silent-context loss in a different costume.
        if not _valid_state(packet.get("state")):
            _transport(completed, argv)
        _state = packet["state"]
        _raise_preset_error(refusal)
    if ok is not True:
        # Exactly `true`. A missing or null `ok` is a malformed packet, not a
        # success with nothing in it.
        _transport(completed, argv)

    if not _valid_state(packet.get("state")):
        # The state is how the notice lifetime survives; a response that drops or
        # corrupts it would silently restart dedup and un-suppress a quiet
        # command. Checking key presence alone accepted `said: "bad"`.
        _transport(completed, argv)
    try:
        value = _packet_field(packet, "value")
    except KeyError:
        _transport(completed, argv)
    _state = packet["state"]
    return value
