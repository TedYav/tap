#!/usr/bin/env python3
"""Benign-vocabulary inventory lint (tap-4dyn / PR #xxx).

Purpose
-------
Make the vocabulary sweep MECHANICAL instead of manual. The AGENTS.md
"Vocabulary convention" asks that durable PROSE (comments, docstrings, and
user-facing dispatch/receipt text) prefer benign systems vocabulary, so a
GPT-family reviewer does not read mundane tmux-session bookkeeping as an attack
toolkit and trip a cybersecurity-caution gate. Manual sweeps missed survivors
(PR #xxx rounds r1-r3): a manual sweep only confirms the filter you happened to
write, never proves completeness. This lint replaces the manual claim with an
enumerate-then-classify inventory: every flavor-vocabulary hit is either
NEUTRALIZED (absent) or exempted by a hit-scoped ALLOWLIST entry that names why
it is legitimate; an unclassified hit or a stale entry fails the gate.

Two extraction modes, by the tool available
-------------------------------------------
The failure this lint must never have is its own: a prose form that goes
UNSCANNED, so a flavor word survives behind a green gate (rounds r4/r5 found
several). The defense differs by language, because the trustworthy primitive
differs:

  * Python HAS a canonical lexer (`tokenize`). Use it: scan only COMMENT,
    STRING, and FSTRING_MIDDLE tokens, so code identifiers (`is_seat_dead`, the
    `seat_corpse` module) and f-string `{expr}` parts are excluded precisely and
    no literal prose form is missed. This REQUIRES Python 3.12+, where an
    f-string is tokenized into FSTRING_MIDDLE literal segments with true source
    positions; pre-3.12 emits the whole f-string as one STRING token with no
    per-segment columns, which breaks hit-scoping. The smoke test floor is 3.12
    (smoke-preflight.sh, bead tap-w0t3); this lint asserts it rather than
    silently mis-reading f-strings on an older interpreter.

  * Shell has NO stdlib lexer, and hand-rolling one (quote state, heredoc
    delimiter grammar, which command consumes a redirection) leaked green-while-
    red edge cases round after round. So shell is scanned WHOLE-LINE on the RAW
    physical text: every line is searched, with NOTHING masked or extracted.
    Blanking `$`-interpolations was itself a bypass (a `$(printf 'prose')` or a
    `${x:-default prose}` hides literal dispatch text), so it is gone: there is
    no extraction step of any kind, which retires the whole "input X hides
    prose" class. This is deliberately COARSE — a flavor word in shell CODE is
    flagged too, not just prose. That is a feature: word boundaries exclude the
    identifiers (`undead`, the underscore `seat_corpse`), and empirically the
    carrier shell files reduce to a single already-classified hit, so the
    coarseness costs nothing real. When a genuine shell-CODE survivor does
    appear (e.g. a parameter expansion whose text happens to match), do NOT
    reintroduce masking — classify that concrete path/source span narrowly in
    the allowlist, exactly as for a Python identifier that cannot be renamed.
    Coarser-but-complete beats precise-but-bypassable.

Scope boundary
--------------
The convention targets tone, not the API. Word boundaries drop identifier and
CLI substrings for free (`undead`, `deadline`, `injective`, the underscore
`seat_corpse`), and genuine command/identifier/contract survivors are named in
the allowlist. The boundary corpus (`benign-vocab-lint-corpus.test.sh`) proves,
as red fixtures, that the extractor SEES the prose forms it claims to and
EXCLUDES the code forms it claims to; keep them in lockstep.

Boundary: the reviewer's-eye SOURCE TEXT (threat model)
------------------------------------------------------
The lint checks the CONTIGUOUS RAW SOURCE SPELLING, and deliberately NOT the
runtime-reconstructed value. A flavor word hidden by an escape (`atta\\x63k`),
by adjacent-string concatenation (`"att" "ack"`), by an ANSI-C `$'\\x61ttack'`,
or across a backslash-newline is OUT OF SCOPE — on purpose, not as a gap. The
convention's entire threat surface IS the raw source text, because that is what
both a GPT reviewer and its safety classifier consume: `atta\\x63k` does not
read as the trigger word to either, so obfuscated source is already benign on
the only surface that matters. Deliberate escape-obfuscation is an
adversarial-author threat this convention never claimed to cover — an
adversarial insider defeats any lint, and that is a different control. The
contrast with a heredoc is the test: heredoc prose IS read as the word (in
scope), an escape is NOT (out of scope) — the boundary is the READING, not the
syntax. The corpus pins escape/reconstruction cases as exit-0 fixtures WITH this
why named inline, so a future round cannot mistake the boundary for a miss.

Run standalone: python3 benign_vocab_lint.py [--show]
  exit 0 = every prose hit classified; exit 1 = unclassified hit or stale entry.
"""

import io
import os
import re
import sys
import tokenize

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))

# The durable-prose carrier files sol's inventory covers (PR #xxx). The
# tap-register.sh entry retired with the file itself (checkpoint C): its
# kill-prose hits went away with the body, and the seat_verdict vocabulary
# now lives in the native seat-verdict.ts, which this lint does not carry.
FILES = [
    "skills/tap/scripts/session/seat_corpse.py",
    "skills/tap/scripts/session/launcher.py",
]

# Flavor vocabulary — the incident cluster (corpse / steal / dead / kill /
# inject / destructive / adversarial / %beefcake) plus the ordinary-prose forms
# sol's rounds surfaced (dead / reclaim / wedge) and the documented substitution
# families (malformed). Word-boundaried and case-insensitive, with explicit
# morphology: `\bdead\b` matches the bare word and `dead-end` but NOT `undead` /
# `deadline`; the `inject` alternation matches `injection`/`injected` but NOT
# `injective`; `seat_corpse` is excluded by its underscore. Pinned by the corpus.
TERMS = re.compile(
    r"\b("
    r"corpses?|steals?|stole|stolen|stealing|"
    r"dead|died|dies|dying|"
    r"destruct\w*|destroy\w*|"
    r"kill\w*|inject(?:ion|ions|ed|ing|s)?|"  # inject* but NOT "injective"
    r"malformed|"
    r"beefcake|adversar\w*|reclaim\w*|"
    r"victim\w*|wedge|wedges|wedged|wedging|attack\w*|zombie\w*"
    r")\b",
    re.I,
)

# --- ALLOWLIST -------------------------------------------------------------
# The classification table: (file_suffix, pattern, reason[, require_literal]). A
# hit is exempt when its file matches file_suffix AND some match of `pattern` has a
# SPAN that CONTAINS the hit's [col, col+len(term)) span — hit-scoped, so a
# legitimate token exempts only the occurrence it covers, never an unrelated
# same-line hit. The optional 4th field `require_literal` (default False) ADDS a
# token-provenance guard: when True, the hit must have come from a STANDALONE string
# literal (is_literal), so prose merely SHAPED like the pattern — a comment or a
# docstring — is flagged, not exempted (see the enum "dead" entry, sol r10 #1).
# Keep patterns TIGHT (anchored on the identifier / command / value) and each
# must classify at least one live hit (a stale entry fails the lint). Ordinary
# prose has NO business here: neutralize it instead of exempting it.
ALLOWLIST = [
    # Literal tmux command — the convention keeps real command names nameable.
    (".py", r"kill-session", "literal tmux kill-session command"),
    # Literal tmux hook name (a comment mention or a string argument).
    (".py", r"pane-died", "literal tmux pane-died hook name"),
    # Established test-file identifier named in prose (hyphenated, so the word
    # boundary catches it; the underscore `seat_corpse` module never reaches here).
    (".py", r"seat-corpse-lockstep\.test\.sh", "names the seat-corpse-lockstep test file"),
    # Grep-stable receipt CONTRACT — scoped to the ONE launcher file that
    # constructs it (CONTRACT.md documents `reclaimed dead seat row '<handle>'`
    # as a stable receipt users grep for). Contract surface, not free prose;
    # debenign-ifying it would be a separate versioned migration, not a tone
    # sweep. Path-scoped so the phrase is not exempted elsewhere.
    ("session/launcher.py", r'f"reclaimed dead seat row', "grep-stable receipt contract (CONTRACT.md)"),
    # Precise security-vulnerability term: "prompt injection" is the named attack
    # class documented in the #xxx passthrough safety rationale, not tone prose —
    # rewording would lose the exact meaning. Path-scoped to that launcher comment,
    # exactly like the receipt-contract exemption above.
    # Unrenameable Python IDENTIFIER named in a comment ABOUT that function
    # (tap-bzyz). The role-split note records which caller opts into the strict
    # form, and it cannot say that without naming destructive_session_target —
    # a paraphrase would make the comment worse at the one job it has, and the
    # convention's own rule is that softening a word carrying precise meaning is
    # a semantic bug rather than a win. Two things keep this narrow: the
    # identifier is DEFINED in this same file, so a mention adds no exposure a
    # reader of launcher.py does not already have; and `destruct\w*` swallows the
    # whole identifier (`_` is a word character), so the hit span IS the
    # identifier and the entry is exactly as tight as the thing it exempts.
    # Path-scoped like the receipt-contract entry above.
    ("session/launcher.py", r"destructive_session_target",
     "unrenameable identifier: the function this comment is about (defined in this file)"),
    # Established registry-events wire token shared with team-stop (`action=killed`);
    # the event spelling is the API, not tone prose — team-stop consumers grep it.
    ("session/launcher.py", r'"killed"',
     "registry-events wire token shared with team-stop (API spelling, action=killed)"),
    # Stable on-disk recovery namespace introduced by tap-5ils. The directory
    # spelling is part of receipts and restore paths, so it is an API path, not
    # free prose; hit-scoping covers only the hyphenated path token.
    ("session/launcher.py", r"session-kill",
     "picker recovery archive directory name (API path)"),
    # These operator-facing outcomes distinguish a completed stop from the
    # safety-veto guarantee. Rewording either loses the exact lifecycle fact.
    ("session/launcher.py", r"session was not killed",
     "precise picker backup failure guarantee: stop did not occur"),
    ("session/launcher.py", r'f"killed \{record\.replaces_session\}',
     "precise picker replacement receipt: canonical session stop completed"),
]

# Python 3.12+ tokenizes f-strings into FSTRING_START/MIDDLE/END. FSTRING_MIDDLE
# is the literal text between `{expr}` parts, with true source positions — so
# scanning it gets f-string prose precisely and excludes interpolated
# identifiers, with no pre-3.12 special case. The 3.12 floor is enforced by
# smoke-preflight and asserted in main(); see the module docstring / tap-w0t3.
_FSTRING_MIDDLE = getattr(tokenize, "FSTRING_MIDDLE", None)
_PY_PROSE_TOKENS = {tokenize.COMMENT, tokenize.STRING}
if _FSTRING_MIDDLE is not None:
    _PY_PROSE_TOKENS.add(_FSTRING_MIDDLE)


def _py_prose_spans(src):
    """[(line, col, text, ttype)] for python prose tokens (comments, strings,
    f-string literal segments). ttype is the tokenize type, so a caller can tell a
    STANDALONE string literal (an enum value) from a comment or docstring that
    merely contains code-shaped prose. Returns [] on a tokenize error at EOF."""
    spans = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(src).readline):
            if tok.type in _PY_PROSE_TOKENS:
                spans.append((tok.start[0], tok.start[1], tok.string, tok.type))
    except tokenize.TokenError:
        pass
    return spans


def _sh_scan_spans(path):
    """[(line, col, text, ttype)] scanning EVERY shell line's RAW text — no masking,
    no comment/string/heredoc extraction. Nothing is removed, so nothing can be
    bypassed; a genuine code survivor is classified narrowly in the allowlist. ttype
    is None (shell has no lexer — the token/literal distinction is Python-only)."""
    spans = []
    with open(path, "r") as fh:
        for lineno, line in enumerate(fh, start=1):
            spans.append((lineno, 0, line.rstrip("\n"), None))
    return spans


def hits_for(path):
    """[{line, col, term, source}] for every flavor term in scanned text."""
    abspath = os.path.join(ROOT, path)
    with open(abspath, "r") as fh:
        file_lines = fh.read().split("\n")
    if path.endswith(".py"):
        with open(abspath, "r") as fh:
            spans = _py_prose_spans(fh.read())
    else:
        spans = _sh_scan_spans(abspath)

    seen = set()
    out = []
    for start_line, start_col, text, ttype in spans:
        for m in TERMS.finditer(text):
            before = text[: m.start()]
            nl = before.count("\n")
            if nl == 0:
                line = start_line
                col = start_col + m.start()
            else:
                line = start_line + nl
                col = m.start() - (before.rindex("\n") + 1)
            term = m.group(0)
            key = (line, col, term.lower())
            if key in seen:
                continue
            seen.add(key)
            source = file_lines[line - 1] if 0 <= line - 1 < len(file_lines) else text
            # is_literal: the hit's originating token is a STANDALONE string literal
            # whose whole content is the term (e.g. the enum value `"dead"`), NOT a
            # comment or a larger docstring that merely contains code-shaped prose.
            # Lets an allowlist entry require executable-literal context (sol r10 #1).
            is_literal = ttype == tokenize.STRING and text.strip() in (f'"{term}"', f"'{term}'")
            out.append({"line": line, "col": col, "term": term, "source": source, "is_literal": is_literal})
    out.sort(key=lambda h: (h["line"], h["col"]))
    return out


def classify(path, hit):
    """Return (reason, entry_index) if some allowlist entry's match SPAN contains
    the hit span, else (None, None). Hit-scoped: the entry covers only the
    occurrence it spans, never an unrelated same-line hit.

    An entry is a 3-tuple (suffix, pattern, reason) or a 4-tuple with a trailing
    require_literal flag; when set, the hit must have come from a standalone string
    literal (is_literal), so prose merely shaped like the pattern is not exempted."""
    hit_start = hit["col"]
    hit_end = hit["col"] + len(hit["term"])
    source = hit["source"]
    for idx, entry in enumerate(ALLOWLIST):
        suffix, pattern, reason = entry[0], entry[1], entry[2]
        require_literal = entry[3] if len(entry) > 3 else False
        if not path.endswith(suffix):
            continue
        if require_literal and not hit.get("is_literal"):
            continue
        for m in re.finditer(pattern, source):
            if m.start() <= hit_start and m.end() >= hit_end:
                return reason, idx
    return None, None


def main():
    if _FSTRING_MIDDLE is None:  # pre-3.12: f-string prose would be missed silently
        print(
            f"benign-vocab-lint: requires Python >= 3.12 (running {sys.version_info.major}."
            f"{sys.version_info.minor}); f-string prose has no per-segment tokens before 3.12. "
            "The smoke test floor is 3.12 (smoke-preflight.sh / tap-w0t3).",
            file=sys.stderr,
        )
        return 2
    show = "--show" in sys.argv
    total_hits = 0
    unclassified = []
    used_entries = set()

    for path in FILES:
        hits = hits_for(path)
        total_hits += len(hits)
        if show:
            print(f"\n== {path} ({len(hits)} hit(s)) ==")
        for h in hits:
            reason, idx = classify(path, h)
            if reason is None:
                unclassified.append((path, h))
                if show:
                    print(f"  UNCLASSIFIED  L{h['line']}: {h['source'].strip()}")
            else:
                used_entries.add(idx)
                if show:
                    print(f"  ok [{reason}]  L{h['line']}: {h['term']}")

    stale = [ALLOWLIST[i] for i in range(len(ALLOWLIST)) if i not in used_entries]

    print(
        f"\nbenign-vocab inventory: {total_hits} hit(s) across {len(FILES)} files; "
        f"{total_hits - len(unclassified)} classified, {len(unclassified)} unclassified; "
        f"{len(ALLOWLIST)} allowlist entr(y/ies), {len(stale)} stale."
    )

    ok = True
    if unclassified:
        ok = False
        print("\nFAIL: unclassified flavor-vocabulary hit(s) — neutralize the prose or")
        print("add a tight, hit-scoped allowlist entry that names why it is legitimate:")
        for path, h in unclassified:
            print(f"  {path}:{h['line']}  {h['source'].strip()}")
    if stale:
        ok = False
        print("\nFAIL: stale allowlist entr(y/ies) matching no live hit (remove or fix):")
        for entry in stale:
            print(f"  {tuple(entry)!r}")  # whole entry incl. optional require_literal

    if ok:
        print("PASS: every flavor-vocabulary hit is classified.")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
