"""Launch must not implicitly turn each linked worktree into a new team."""
import json
import subprocess

import pytest
import launcher


@pytest.fixture
def repositories(tmp_path, monkeypatch):
    primary = tmp_path / 'MainTeam'
    item = tmp_path / 'bb-item'
    primary.mkdir()
    subprocess.run(['git', 'init', '-q', str(primary)], check=True)
    subprocess.run(['git', '-C', str(primary), '-c', 'user.name=Fixture', '-c',
                    'user.email=fixture@example.invalid', 'commit', '--allow-empty', '-qm', 'fixture'], check=True)
    subprocess.run(['git', '-C', str(primary), 'worktree', 'add', '-qb', 'item', str(item)], check=True)
    index = tmp_path / 'index'
    index.mkdir()
    registry = index / 'global-registry.json'
    registry.write_text(json.dumps({'schema': '0.20', 'teams': {}}))
    monkeypatch.setenv('TAP_INDEX_HOME', str(index))
    monkeypatch.delenv('TAP_HOME', raising=False)
    return primary, item, registry


@pytest.mark.parametrize("dry_run", [False, True])
def test_launch_from_linked_worktree_refuses_before_enrollment(repositories, monkeypatch, capsys, dry_run):
    _, item, registry = repositories
    before = registry.read_bytes()
    monkeypatch.chdir(item)
    launched = []
    monkeypatch.setattr(launcher, 'execute_fresh_launch', lambda *args, **kwargs: launched.append(args) or 0)
    rc = launcher.main(['new', 'codex', 'builder'] + (['--dry-run'] if dry_run else []))
    assert rc == 2, capsys.readouterr()
    assert 'bb-item' in capsys.readouterr().err
    assert registry.read_bytes() == before
    assert not (item / '.tap').exists()
    assert not launched


def test_primary_repository_can_still_bootstrap(repositories):
    primary, _, registry = repositories
    launcher._bootstrap_if_live_unenrolled(str(primary))
    assert 'MainTeam' in json.loads(registry.read_text())['teams']


def test_already_enrolled_worktree_is_not_refused(repositories, monkeypatch):
    _, item, _ = repositories
    monkeypatch.setattr(launcher.registry_v20, 'resolve_team_registry_for_root', lambda root: ('live', '/registry'))
    launcher._bootstrap_if_live_unenrolled(str(item))
