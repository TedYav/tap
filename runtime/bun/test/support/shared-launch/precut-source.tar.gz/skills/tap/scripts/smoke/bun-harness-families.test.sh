#!/usr/bin/env bash
# bun-harness-families.test.sh — the native roster's shallow-process family
# set must remain identical to lib.sh's single source.
set -euo pipefail

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"

python3 -B - "$ROOT/skills/tap/scripts/lib.sh" "$ROOT/runtime/bun/src/verbs/team.ts" <<'PY'
import json
import re
import sys

lib = open(sys.argv[1], encoding="utf-8").read()
team = open(sys.argv[2], encoding="utf-8").read()

shell_match = re.search(r'^TAP_HARNESS_FAMILIES="([^"]*)"', lib, re.MULTILINE)
native_match = re.search(r'^const AGENT_FAMILIES = new Set\((\[[^;]+\])\);', team, re.MULTILINE)
if not shell_match or not native_match:
    raise SystemExit("bun-harness-families: could not read both family declarations")

shell_families = shell_match.group(1).split()
native_families = json.loads(native_match.group(1))
if native_families != shell_families:
    raise SystemExit(
        f"bun-harness-families: native {native_families!r} != lib.sh {shell_families!r}"
    )
PY

echo "bun-harness-families: ok"
