#!/usr/bin/env bash
# chip-unreadable-preserves-draft.test.sh — a chip predicate that COULD NOT READ
# must not blank the pane owner's text.
#
# The band predicates answer 0 yes, 1 no, 2 could not read. Two consumers wrote
# the two shapes that silently collapse three answers into two:
#
#   tap_slice_delivery_disposition:  `... && ! tap_text_has_paste_collapse ...`
#   tap_submit_verify_body (opencode): `... || tap_input_has_paste_collapse ... || typed_input=""`
#
# `!` inverts rc 2 to true, and a bare `||` chain falls rc 2 through to the
# blanking arm. Both then treat "the chip reader failed to run" as "there is no
# chip", which blanks text the pane owner typed — the delivery slice toward
# inject-eligible, the opencode arm toward outright draft loss.
#
# WHAT EACH CASE PROVES, because the two halves are not equally strong.
# Cases 1-4 TRANSCRIBE the two arms and run the transcription: they are
# executable documentation of the intended three-state semantics, and they pass
# whether or not lib.sh is correct. They earn their place by pairing each rc 2
# arm with an rc 1 control, so a "never blank anything" fix cannot satisfy them.
# Case 5 is the one that reads PRODUCTION: it asserts neither collapsing shape
# survives in lib.sh. If you are deciding what to trust here, trust case 5 and
# read 1-4 as the specification it is enforcing.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
LIB="$ROOT/skills/tap/scripts/lib.sh"
fail() { echo "chip-unreadable: $1" >&2; exit 1; }

# --- 1. the delivery slice: rc 2 must not blank the composer ----------------
slice_composer() { # <chip-rc> -> the composer the slice would hand on
  CHIP_RC="$1" bash -c '
    . "$1" >/dev/null 2>&1
    tap_dim_prompt_input() { return 0; }          # placeholder-shaped
    tap_text_has_paste_collapse() { return "$CHIP_RC"; }
    tap_escaped_prompt_from_frame() { printf ""; }
    tap_prompt_glyph_re() { printf ">"; }
    composer="human draft"
    if tap_dim_prompt_input "$composer" "" ">" claude; then
      local_rc=0
      tap_text_has_paste_collapse claude "$composer" || local_rc=$?
      if [ "$local_rc" -eq 1 ]; then composer=""; fi
    fi
    printf "%s" "$composer"
  ' _ "$LIB"
}

got="$(slice_composer 2)"
[ "$got" = "human draft" ] || fail "(1) rc 2 blanked the composer (got '$got') — an unreadable chip check became idle-band evidence"
echo "chip-unreadable: (1) delivery slice keeps the draft when the chip check cannot read: ok"

got="$(slice_composer 1)"
[ -z "$got" ] || fail "(2) rc 1 did NOT blank the composer (got '$got') — the placeholder path stopped working"
echo "chip-unreadable: (2) delivery slice still blanks on a positive 'no chip': ok"

# --- 2. the opencode staged-anchor arm: rc 2 must not discard typed input ---
opencode_typed() { # <chip-rc> -> the typed_input that survives the arm
  CHIP_RC="$1" bash -c '
    . "$1" >/dev/null 2>&1
    tap_input_has_paste_collapse() { return "$CHIP_RC"; }
    typed_input="human draft"; match_mode=normal
    case "${typed_input#"${typed_input%%[![:space:] ]*}"}" in
      "[[TAP"*) ;;
      *)
        if [ "$match_mode" != exact ]; then
          chip_rc=0
          tap_input_has_paste_collapse "%p" opencode || chip_rc=$?
          if [ "$chip_rc" -eq 1 ]; then typed_input=""; fi
        fi ;;
    esac
    printf "%s" "$typed_input"
  ' _ "$LIB"
}

got="$(opencode_typed 2)"
[ "$got" = "human draft" ] || fail "(3) rc 2 discarded the pane owner's draft (got '$got') — a chip reader that failed to run destroyed typed input"
echo "chip-unreadable: (3) opencode arm keeps the draft when the chip check cannot read: ok"

got="$(opencode_typed 1)"
[ -z "$got" ] || fail "(4) rc 1 did NOT clear typed_input (got '$got') — the non-chip residue path stopped working"
echo "chip-unreadable: (4) opencode arm still clears on a positive 'no chip': ok"

# --- 3. the shapes themselves are gone from the production bodies -----------
# Cases 1-4 transcribe; THIS is the case that reads production. Comments are
# stripped first: the first version of this guard matched the comment in lib.sh
# that EXPLAINS the defect, so it reddened on the fix — a guard that could not
# tell code from its own documentation.
#
# `grep -q ... && fail` is deliberately NOT used: under `set -e` a grep that
# correctly finds nothing returns 1, the `&&` compound returns 1, and the script
# exits as though the check had failed. The explicit `if` is what makes a clean
# result mean "clean".
# A ZERO THAT LICENSES A PASS NEEDS AN INSTRUMENT THAT CAN REFUSE. If $LIB
# resolved wrong, the strip yields nothing, grep matches nothing, and this case
# would report "clean" about a file it never read. Positive controls first.
[ -s "$LIB" ] || fail "(5) LIB is missing or empty: '$LIB' — the guard would pass vacuously"
grep -q '^tap_submit_verify_body()' "$LIB" \
  || fail "(5) LIB does not contain tap_submit_verify_body: '$LIB' — wrong file, guard is blind"

# The stripped copy is a FILE, and grep reads it directly. It is not piped, and
# that is load-bearing rather than stylistic:
#
#   printf '%s' "$code" | grep -q PATTERN
#
# reports a MATCH as a non-match under `set -o pipefail`. `grep -q` exits the
# moment it matches, `printf` is then killed by SIGPIPE (141), and pipefail
# takes the rightmost non-zero status — so the more certainly the pattern is
# present, the more reliably the `if` goes false. `grep -c` hides it by reading
# to EOF, which is how the first version of this guard passed while its own
# debug line printed hits=1. Same family as "a pipeline's exit is not the
# verdict"; the remedy is to not build a pipeline.
stripped="$(mktemp "${TMPDIR:-/tmp}/chip-unreadable.XXXXXX")"
trap 'rm -f "$stripped"' EXIT
sed 's/[[:space:]]*#.*$//' "$LIB" > "$stripped"
[ "$(wc -c < "$stripped")" -gt 100000 ] \
  || fail "(5) comment-stripped lib.sh is only $(wc -c < "$stripped") bytes — the strip ate the file"
if grep -q '! tap_text_has_paste_collapse' "$stripped"; then
  fail "(5) the '! tap_text_has_paste_collapse' shape is back in lib.sh"
fi
if grep -qE '\|\| tap_input_has_paste_collapse [^|]*\|\| typed_input=""' "$stripped"; then
  fail "(5) the '|| ... || typed_input=\"\"' shape is back in lib.sh"
fi
echo "chip-unreadable: (5) neither collapsing shape remains in lib.sh: ok"

echo "chip-unreadable: ok"