#!/usr/bin/env bash
# lib.sh - shared base for the TAP collaboration ledger (tap-5h9).
#
# NOTE: COLLAB_DIR and the .tap/bus/collab/ state home keep their original
# spelling on purpose. The /collab skill was renamed to /discuss as a ROUTING
# change (Ops, 2026-08-18); renaming these would be a state migration whose
# blast radius is every live thread on every bus. Leave them.
#
# Adaptation #3 (tap-5h9, per sol §9 + fable amendment): state home parameterized
# via COLLAB_DIR (absolute-path-required env override, mirroring the original upstream
# resolution), default <repo>/.tap/bus/collab/ (under the auto-ignored .tap/bus/
# tree — run-scoped state archived by tap team reset). The lane consumer (PR4)
# picks its dir by exporting COLLAB_DIR.

die() {
  echo "tap ledger: $*" >&2
  exit 1
}

valid_handle() {
  [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || die "invalid handle '$1' (expected ^[A-Za-z0-9][A-Za-z0-9._-]*$ - no path separators)"
}

_resolve_collab_dir() {
  if [ -n "${COLLAB_DIR:-}" ]; then
    case "$COLLAB_DIR" in
      /*) ;;
      *) die "COLLAB_DIR must be an absolute path (got '$COLLAB_DIR')" ;;
    esac
    printf '%s' "$COLLAB_DIR"
    return
  fi
  local root
  if root="$(git rev-parse --show-toplevel 2>/dev/null)" && [ -n "$root" ]; then
    printf '%s/.tap/bus/collab' "$root"
    return
  fi
  local here
  here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  # TAP depth: skills/tap/scripts/ledger/ → 4-up to repo root.
  # (the upstream layout was also 4-up; the original
  # vendor used 3-up, which was wrong for both — fixed here per V1.)
  printf '%s/.tap/bus/collab' "$(cd "$here/../../../.." && pwd)"
}

# BS2 fix: track whether COLLAB_DIR was explicitly set as an env var BEFORE
# _resolve_collab_dir runs (the $(...) subshell loses any variable set inside
# the function). Was a never-set COLLAB_DIR_OVERRIDE var; now correctly tracks
# the actual COLLAB_DIR env presence.
_COLLAB_DIR_WAS_OVERRIDDEN=0
[ -n "${COLLAB_DIR:-}" ] && _COLLAB_DIR_WAS_OVERRIDDEN=1

COLLAB_DIR="$(_resolve_collab_dir)"
export COLLAB_DIR

# V2 (grok finding): refuse at first ledger use on a legacy tmp/tap bus. The
# default COLLAB_DIR is <repo>/.tap/bus/collab/; if a non-empty <repo>/tmp/tap
# exists, TAP's bus resolution (lib.sh:14-26 R19 chain) uses the legacy layout,
# so payloads live at <repo>/tmp/tap/payloads/ while _scan_payloads reads
# <repo>/.tap/bus/payloads/ — split-brain. Mirrors the AE8 precedent
# (tap send --polite refuses a legacy bus, CONTRACT.md:148-159): refuse loudly,
# name 'tap init' as the recovery. An explicit COLLAB_DIR env override bypasses
# this check (the caller chose its dir and owns correctness).
if [ "$_COLLAB_DIR_WAS_OVERRIDDEN" = 0 ]; then
  case "$COLLAB_DIR" in
    */.tap/bus/collab)
      _ledger_legacy="${COLLAB_DIR%/.tap/bus/collab}/tmp/tap"
      if [ -d "$_ledger_legacy" ] && [ -n "$(ls -A "$_ledger_legacy" 2>/dev/null)" ]; then
        die "tap ledger refuses a legacy tmp/tap bus (split-brain: payloads live at $_ledger_legacy/payloads/ while COLLAB_DIR default resolves to $COLLAB_DIR); run 'tap init' to migrate, or export COLLAB_DIR to an explicit absolute path."
      fi
      ;;
  esac
fi
