"""Kernel PTY/process-group controls; the tmux executable only records its tty."""
import errno
import json
import os
import pathlib
import pty
import select
import time
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class AttachTTYTests(unittest.TestCase):
    def test_attach_requires_foreground_ownership(self):
        for background in (True, False):
            with self.subTest(background=background), tempfile.TemporaryDirectory() as tmp:
                work = pathlib.Path(tmp)
                fake = work / "tmux"
                fake.write_text("#!" + sys.executable + "\n" +
                    "import json,os,pathlib\n" +
                    "pathlib.Path(os.environ['ATTACH_CALLED']).write_text(json.dumps({"
                    "'pgid':os.getpgrp(),'foreground':os.tcgetpgrp(0),'tty':os.ttyname(0)}))\n")
                fake.chmod(0o755)
                helper = work / "caller.py"
                helper.write_text("""
import fcntl,json,os,pathlib,signal,subprocess,sys
sys.path.insert(0, sys.argv[1])
import launcher
if sys.argv[2] != 'worker':
    fcntl.ioctl(0, __import__('termios').TIOCSCTTY, 0)
    os.tcsetpgrp(0, os.getpgrp())
    if sys.argv[2] == 'background':
        result = subprocess.run([sys.executable, __file__, sys.argv[1], 'worker'], process_group=0, timeout=5)
        sys.exit(result.returncode)
# A background wrapper can ignore job-control signals; ownership must be checked,
# not inferred from whether the subprocess happened to stop itself.
signal.signal(signal.SIGTTIN, signal.SIG_IGN)
signal.signal(signal.SIGTTOU, signal.SIG_IGN)
record = launcher.SessionRecord(name='fixture/seat', harness='claude', cwd='/fixture', base='fixture', tag='seat', index=1)
rc = launcher.attach_after_launch(record)
pathlib.Path(os.environ['ATTACH_RESULT']).write_text(json.dumps({'rc':rc,'pgid':os.getpgrp(),'foreground':os.tcgetpgrp(0)}))
""")
                env = {k: v for k, v in os.environ.items() if k not in ('TMUX', 'TMUX_PANE')}
                env.update(PATH=str(work) + os.pathsep + env['PATH'],
                           ATTACH_CALLED=str(work / 'called'), ATTACH_RESULT=str(work / 'result'))
                master, slave = pty.openpty()
                run = None
                try:
                    run = subprocess.Popen([sys.executable, str(helper), str(ROOT),
                                          'background' if background else 'foreground'],
                                         stdin=slave, stdout=slave, stderr=slave,
                                         start_new_session=True, env=env)
                    os.close(slave)
                    slave = -1
                    output = bytearray()
                    deadline = time.monotonic() + 8
                    # Child exit does not mean its terminal output was consumed.
                    while True:
                        self.assertLess(time.monotonic(), deadline, "PTY caller exceeded deadline")
                        if select.select([master], [], [], 0.05)[0]:
                            try:
                                chunk = os.read(master, 65536)
                                if not chunk:
                                    break
                                output.extend(chunk)
                            except OSError as error:
                                if error.errno != errno.EIO:
                                    raise
                                break  # slave closed (EIO on Linux)
                    self.assertEqual(run.wait(timeout=1), 0)
                    result = json.loads((work / 'result').read_text())
                    self.assertEqual(result['rc'], 0)
                    called = work / 'called'
                    if background:
                        self.assertNotEqual(result['pgid'], result['foreground'])
                        evidence = called.read_text() if called.exists() else ''
                        self.assertFalse(called.exists(), 'background attach shared tty: ' + evidence)
                        receipt = output.decode()
                        self.assertIn('running detached (caller does not own foreground tty)', receipt)
                        self.assertIn('tmux attach -t fixture/seat', receipt)
                    else:
                        self.assertEqual(result['pgid'], result['foreground'])
                        observed = json.loads(called.read_text())
                        self.assertEqual(observed['pgid'], observed['foreground'])
                finally:
                    os.close(master)
                    if slave >= 0:
                        os.close(slave)
                    if run is not None and run.poll() is None:
                        run.kill()
                        run.wait(timeout=1)
