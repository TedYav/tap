#!/usr/bin/env python3
import argparse
import concurrent.futures
import contextlib
import dataclasses
import datetime
import fcntl
import io
import itertools
import json
import os
import pathlib
import re
import select
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import termios
import time
import tty
import uuid

# Refuse before imports or evaluated annotations that require Python 3.10.
if sys.version_info < (3, 10):
    print(
        "tap session: Python 3.10 or newer is required for the launcher; "
        f"found {sys.version.split()[0]} at {sys.executable}. "
        "Install a newer Python and put its python3 first on PATH, then retry.",
        file=sys.stderr,
    )
    raise SystemExit(2)

# The completion leaf lives beside this file. Bootstrap its dir onto sys.path so
# the import resolves whether launcher.py is run as a script or loaded by the
# test suite's SourceFileLoader (which does not add ROOT to sys.path).
_LAUNCHER_DIR = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(_LAUNCHER_DIR))
sys.path.insert(0, str(_LAUNCHER_DIR.parent))  # skills/tap/scripts — registry_v20
import completion  # noqa: E402  (leaf module; handle-mapping single source of truth)
import _preset_bridge
import presets  # noqa: E402  (strict resolve-once session launch configuration)
import seat_corpse  # noqa: E402  (the seat-liveness classifier; also imported by tap-register.sh's locked chooser)
import registry_v20  # noqa: E402
import verbose  # opt-in command diagnostics
import _startup_trace_bridge as startup_trace

import tmux_bootstrap

import lifecycle_diagnostics
import clear_fence  # noqa: E402  (per-seat clearing fence; content is the courier signal)


HERMES_BIN = "hermes"
HARNESSES = completion.HARNESSES  # single source lives in the completion leaf
# Path/root resolution lives in the completion leaf so the zsh completion producer
# can self-resolve without importing this module. Re-exported here (one definition,
# two importers) so every launcher call site — and the tests — keep using them
# unchanged, and completion resolves exactly the way this launcher does.
GitProbe = completion.GitProbe
_resolve_git_path = completion._resolve_git_path
run_git_probe = completion.run_git_probe
root_for_cwd = completion.root_for_cwd
tap_registry_path = completion.tap_registry_path
RegistryAuthorityError = completion.RegistryAuthorityError
HARNESS_BY_CODE = {"c": "claude", "cx": "codex", "oc": "opencode", "cu": "cursor", "he": "hermes", "ag": "agy"}
# The reservation grace and expiry rule live in seat_corpse (shared with the
# register chooser's launching-row protection); re-exported for callers/tests.
PENDING_RESERVATION_GRACE_SECONDS = seat_corpse.PENDING_RESERVATION_GRACE_SECONDS
HARNESS_START_TIMEOUT_SECONDS = 5
HARNESS_READY_CONFIRMATIONS = 2
DETACHED_SESSION_SIZE = ("-x", "200", "-y", "60")

# Live pane coordinates that cannot survive a reservation rewrite or a
# team-restore park (tap-9tqt amendment B). One tuple, every strip site.
# ``delivery`` is a seat property (poll-ness), NOT a pane coordinate — never
# strip it (opus 101205 / WAVE 5: stripping forced absent→pane defaulting and
# false-relaunch / false-migrate-refuse on restored poll seats).
STALE_BINDING_KEYS = (
    "pane",
    "pane_id",
    "pane_current_command",
    "wake_url",
    "status_reason",
    "exited_at",
)


def strip_stale_bindings(entry: dict) -> None:
    """Remove live pane coordinates from a registry row in place.

    Does not touch ``delivery`` (seat identity). Callers that need a post-strip
    reason (e.g. restore → restored_from_archive) must stamp it AFTER this runs —
    strip pops status_reason (tap-9tqt A).
    """
    for key in STALE_BINDING_KEYS:
        entry.pop(key, None)


def _team_bus_home() -> pathlib.Path | None:
    """Resolve the active team bus for fence/generation guards.

    Honors TAP_HOME, then the git/worktree root via root_for_cwd (not bare cwd),
    so nested-directory session launch/resume/restart cannot bypass the fence
    (sol 054106). Mirrors lib.sh bus resolution order: .tap/bus then legacy tmp/tap.
    """
    env = os.environ.get("TAP_HOME")
    if env:
        return pathlib.Path(env)
    cwd = pathlib.Path.cwd().resolve()
    try:
        root = pathlib.Path(root_for_cwd(str(cwd)))
    except Exception:
        root = cwd
    for base in (root, cwd):
        for candidate in (base / ".tap" / "bus", base / "tmp" / "tap"):
            if candidate.is_dir():
                return candidate
    return None


def append_registry_session_stop_event(
    *,
    actor: str,
    handle: str,
    session: str,
    detail: str = "",
) -> None:
    """Best-effort registry-events breadcrumb after a session-stop succeeds.

    Routes to the ONE writer (runtime/bun/src/events.ts) through lib.sh's
    adapter, the same bridge this file already uses for pane_harness and
    seat_state. This function used to hold a second copy of the lock, the
    bounded rewrite and the line format; the two copies had drifted (this one
    dropped whitespace-only history rows and inferred the team from the bus
    path, while lib.sh kept them and resolved enrollment identity).

    The registry-events action token stays action="killed", the wire spelling
    team-stop consumers grep for. The chooser-[k] path historically omitted this
    line, so registry-events silence was not negative evidence a session
    survived (opus sweep, E2). Append failures are swallowed — the stop already
    happened; the log is forensics only.
    """
    bus = _team_bus_home()
    if bus is None:
        return
    lib = pathlib.Path(__file__).resolve().parents[1] / "lib.sh"
    try:
        verbose.run(
            [
                "bash", "-c",
                f'. {shlex.quote(str(lib))} >/dev/null 2>&1 || exit 1; '
                'tap_registry_event_append "$1" "$2" "$3" "$4" "$5"',
                "tap-session-stop-event", actor, "killed", handle, session, detail,
            ],
            env={**os.environ, "TAP_HOME": str(bus)},
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return


def _contending_clearer(bus: pathlib.Path | str, handle: str) -> tuple[str, str]:
    """Pid and stamp of the clearer that already holds the fence.

    NOT a fence reader. `try_acquire` has just failed, so liveness is already
    decided and none of the reader's work — the ceiling arithmetic, the
    absent/live/expired verdict — is wanted here. The only question left is who
    to name, and that is two fields off a record.

    This stays a plain read on purpose: the caller's contract is that a losing
    clear changes NOTHING, and `test_a_second_clear_exits_2_having_changed_nothing`
    enforces it by refusing any subprocess on this path. Both values fall back to
    "unknown", which is what the refusal already printed for a torn marker.
    """
    try:
        rec = json.loads(clear_fence.fence_path(bus, handle).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "unknown", "unknown"
    if not isinstance(rec, dict):
        return "unknown", "unknown"
    return str(rec.get("pid") or "unknown"), str(rec.get("since") or "unknown")


def refuse_if_team_reset_fenced(
    action: str, bus: pathlib.Path | None = None
) -> None:
    """Refuse launch/resume/restart while $TAP_HOME/reset.fence.json is present (tap-9tqt).

    `bus` is REQUIRED of any caller acting on a team other than its own. The default
    resolves the CALLER's bus, which is correct for every verb that only ever touches
    its own team — and silently wrong for one that does not: a cross-team verb left
    ambient would mutate the target's registry while fencing the caller's bus, so the
    target's own reset would not observe the fence that was supposed to stop it.
    """
    if bus is None:
        bus = _team_bus_home()
    if bus is None:
        return
    fence = bus / "reset.fence.json"
    if fence.is_file():
        raise LauncherError(
            f"refusing {action} — team bus is mid-reset (fence at {fence}); "
            "next: tap team reset"
        )


def _reset_fence_entry_barrier() -> None:
    """Scratch-only after-entry pause (mirrors tap-register.sh; fable 075157)."""
    import reset_fence

    reset_fence._test_barrier("after-entry-guard")


# Re-entrancy for nested registry mutations under one outer hold.
_reset_fence_mutation_depth = 0


@contextlib.contextmanager
def reset_fence_mutation_lock(action: str, bus: pathlib.Path | None = None):
    """Hold reset.fence.json.lock, recheck fence presence, then yield for durable writes.

    Same sidecar lock tap_reset_fence_acquire uses (sol 063932). An early
    is_file() guard alone leaves a window where a mutator passes, reset fences,
    and the mutator still commits. Nesting is re-entrant in-process.

    `bus` carries the same cross-team obligation as refuse_if_team_reset_fenced.
    """
    global _reset_fence_mutation_depth
    if _reset_fence_mutation_depth > 0:
        yield
        return
    if bus is None:
        bus = _team_bus_home()
    if bus is None:
        yield
        return
    import reset_fence

    try:
        with reset_fence.mutation_lock(bus, action):
            _reset_fence_mutation_depth += 1
            try:
                yield
            finally:
                _reset_fence_mutation_depth -= 1
    except reset_fence.ResetFenceError as exc:
        raise LauncherError(str(exc)) from exc


def mark_reset_generation_reused(why: str = "launcher") -> None:
    """Flip pristine reset-generation.json to reused on first post-reset mutation."""
    bus = _team_bus_home()
    if bus is None:
        return
    path = bus / "reset-generation.json"
    if not path.is_file():
        return
    try:
        rec = json.loads(path.read_text())
    except Exception:
        return
    if rec.get("state") != "pristine":
        return
    rec["state"] = "reused"
    rec["first_mutation"] = why
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tap-gen.")
    try:
        with os.fdopen(fd, "w") as fh:
            json.dump(rec, fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


# Sentinel default for optional live-session snapshots: distinguishes "caller
# did not pass a snapshot — observe once yourself" from "caller passed None,
# the legitimate UNOBSERVABLE snapshot" (tmux_sessions_or_none's failure
# value). Conflating the two made every consumer re-observe per seat exactly
# when the first observation failed (sol-pinnacle, #xxx delta 2).
_UNSET = object()

_STYLE_COMMANDS = {
    "error": ("setaf", "1"),
    "warning": ("setaf", "3"),
    "key": ("bold",),
    "secondary": ("dim",),
    "reset": ("sgr0",),
}
_STYLE_TOKEN_CACHE = {}


def _terminal_style_tokens():
    executable = shutil.which("tput")
    if not executable:
        return None
    cache_key = (executable, os.environ.get("TERM", ""))
    if cache_key in _STYLE_TOKEN_CACHE:
        return _STYLE_TOKEN_CACHE[cache_key]

    tokens = {}
    for role, arguments in _STYLE_COMMANDS.items():
        try:
            result = verbose.run(
                [executable, *arguments],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
            )
        except OSError:
            _STYLE_TOKEN_CACHE[cache_key] = None
            return None
        if result.returncode != 0 or not result.stdout:
            _STYLE_TOKEN_CACHE[cache_key] = None
            return None
        tokens[role] = result.stdout
    _STYLE_TOKEN_CACHE[cache_key] = tokens
    return tokens


def _style_tokens(stream):
    if "NO_COLOR" in os.environ:
        return None
    term = os.environ.get("TERM", "")
    if not term or term == "dumb":
        return None
    force = os.environ.get("CLICOLOR_FORCE")
    if force and force != "0":
        capable = True
    else:
        try:
            capable = bool(stream.isatty())
        except (AttributeError, OSError):
            capable = False
    if not capable:
        return None
    return _terminal_style_tokens()


def style_enabled(stream) -> bool:
    return _style_tokens(stream) is not None


def styled(role: str, text: str, stream) -> str:
    if role == "reset" or role not in _STYLE_COMMANDS:
        raise ValueError(f"unknown style role: {role}")
    tokens = _style_tokens(stream)
    if tokens is None:
        return text
    return f"{tokens[role]}{text}{tokens['reset']}"


def emit_receipt(verb: str, message: str) -> None:
    print(f"tap {verb}: {message}", file=sys.stdout)


def emit_warning(verb: str, problem: str, next_action: str | None = None) -> None:
    line = f"tap {verb}: {styled('warning', 'warning', sys.stderr)}: {problem}"
    if next_action:
        line += f"; next: {next_action}"
    print(line, file=sys.stderr)


def emit_error_human(verb: str, problem: str, next_actions=()) -> None:
    prefix = styled("error", f"tap {verb}:", sys.stderr)
    actions = (next_actions,) if isinstance(next_actions, str) else tuple(next_actions)
    if len(actions) == 1:
        print(f"{prefix} {problem}; next: {actions[0]}", file=sys.stderr)
        return
    print(f"{prefix} {problem}", file=sys.stderr)
    if actions:
        print(file=sys.stderr)
        for index, action in enumerate(actions):
            print(f"  {'next' if index == 0 else 'or':<4}  {action}", file=sys.stderr)


def emit_error_json(error_class: str, action: str, detail: str) -> None:
    obj = {"ok": False, "error_class": error_class, "action": action}
    if detail:
        obj["detail"] = detail
    print(json.dumps(obj, separators=(",", ":")))


def _require_prompt_tty() -> None:
    """A prompt may appear only for a caller who can also SEE it (tap-7r3fn.24).

    Both streams, matching caller_has_tty(): a stdin-PTY/stdout-piped agent
    runner would be asked a question it cannot read (the grok P2 rule that
    already gates the collision chooser). This is the ONE gate both
    interactive prompts share, so they agree on when they may appear by
    construction; doors that decide WHETHER to prompt use the same predicate
    (caller_has_tty), never a bare stdin-only isatty.
    """
    if not caller_has_tty():
        raise LauncherError("interactive prompt requires a TTY")


def prompt_yes_no(verb: str, question: str, default: bool = False) -> bool:
    """One key answers, like prompt_choice (tap-7r3fn.24). Enter = default.

    The chooser must never hand off to a line-mode prompt mid-dialog: the
    operator was just trained to single-key, and the very next prompt
    silently needing Enter was the first strike in the [r] loop incident.
    """
    _require_prompt_tty()
    choices = "Y/n" if default else "y/N"
    try:
        fd = sys.stdin.fileno()
        original = termios.tcgetattr(fd)
    except (AttributeError, OSError, termios.error) as exc:
        raise LauncherError("interactive prompt requires a terminal") from exc
    try:
        tty.setcbreak(fd)
        while True:
            sys.stderr.write(f"tap {verb}: {question} [{choices}] ")
            sys.stderr.flush()
            answer = os.read(fd, 1).decode(errors="replace")
            if answer == "":
                raise LauncherError("interactive prompt ended before a choice")
            if answer in {"\r", "\n"}:
                return default
            if answer in {"y", "Y"}:
                return True
            if answer in {"n", "N"}:
                return False
            print(f"tap {verb}: choose y or n", file=sys.stderr)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, original)


def _choice_keys_text(keys) -> str:
    if len(keys) == 1:
        return keys[0]
    if len(keys) == 2:
        return f"{keys[0]} or {keys[1]}"
    return f"{', '.join(keys[:-1])}, or {keys[-1]}"


def prompt_choice(verb: str, question: str, options, default: str) -> str:
    _require_prompt_tty()
    normalized = tuple(tuple(option) for option in options)
    if not normalized or any(len(option) != 3 for option in normalized):
        raise ValueError("choice options must be key, label, gloss triples")
    keys = tuple(option[0] for option in normalized)
    if any(len(key) != 1 or "\n" in key or "|" in key for key in keys):
        raise ValueError("choice keys must be one character")
    if default not in keys:
        raise ValueError("choice default must name an option")
    if "q" not in keys:
        raise ValueError("choice options must include q")
    if any(not label or not gloss for _, label, gloss in normalized):
        raise ValueError("choice labels and glosses cannot be empty")
    if any("\n" in value or "|" in value for option in normalized for value in option[1:]):
        raise ValueError("choice labels and glosses cannot contain newlines or pipes")

    width = shutil.get_terminal_size(fallback=(80, 24)).columns
    label_width = max(len(option[1]) for option in normalized)
    try:
        fd = sys.stdin.fileno()
        original = termios.tcgetattr(fd)
    except (AttributeError, OSError, termios.error) as exc:
        raise LauncherError("interactive prompt requires a terminal") from exc

    try:
        tty.setcbreak(fd)
        while True:
            print(f"tap {verb}: {question}\n", file=sys.stderr)
            for key, label, gloss in normalized:
                if width <= 40:
                    print(f"  [{key}] {label}", file=sys.stderr)
                else:
                    print(f"  [{key}] {label:<{label_width}}  {gloss}", file=sys.stderr)
            sys.stderr.write(f"\nChoice [{default}] (Esc quits): ")
            sys.stderr.flush()
            answer = os.read(fd, 1).decode(errors="replace")
            if answer == "":
                raise LauncherError("interactive prompt ended before a choice")
            if answer in {"\r", "\n"}:
                answer = default
            elif answer == "\x1b":
                sequence = ""
                while True:
                    ready, _, _ = select.select([fd], [], [], 0.1)
                    if not ready:
                        break
                    suffix = os.read(fd, 1).decode(errors="replace")
                    if not suffix:
                        break
                    sequence += suffix
                answer = "" if sequence else "q"
            if answer in keys:
                return answer
            print(f"tap {verb}: choose {_choice_keys_text(keys)}", file=sys.stderr)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, original)


def _clear_progress(stream, width: int) -> None:
    stream.write(f"\r{' ' * width}\r")
    stream.flush()


@contextlib.contextmanager
def progress(verb: str, message: str):
    stream = sys.stderr
    try:
        interactive = stream.isatty()
    except (AttributeError, OSError):
        interactive = False
    if not interactive:
        yield
        return

    line = f"tap {verb}: {message}..."
    stream.write(f"\r{line}")
    stream.flush()
    interrupted = False
    try:
        yield
    except KeyboardInterrupt:
        interrupted = True
        raise
    finally:
        _clear_progress(stream, len(line))
        if interrupted:
            print(f"tap {verb}: interrupted", file=stream)


def current_boot_id() -> str | None:
    """A stable identifier for the current system boot epoch, or None when it can't
    be determined (guard then disables — a missing boot id never marks anything gone).

    macOS prefers `kern.bootsessionuuid`, which is stable for the boot session.
    Other hosts fall back to the integer boot second as "boot:<sec>". The Bash
    helper emits the same formats. TAP_BOOT_ID exists for controlled probes.
    """
    # The env override is honoured LIVE (never cached) so a test can simulate a
    # reboot mid-process; only the real system probe is memoized (it can't change).
    override = os.environ.get("TAP_BOOT_ID")
    if override is not None:
        return override or None
    if "value" not in _BOOT_ID_PROBE_CACHE:
        _BOOT_ID_PROBE_CACHE["value"] = _probe_boot_id()
    return _BOOT_ID_PROBE_CACHE["value"]


def current_server_epoch() -> str | None:
    """The current tmux SERVER epoch ("srv:<pid>:<start_time>"), or None when
    unobservable — the guard then disables (an unknown epoch never voids
    anything). Delegates to the seat_corpse authority so the launcher, the
    register chooser, and the bash mirror all compare the same string
    (tap-24f). Unlike the boot id this is never memoized: the keeper
    LaunchAgent replaces an exited server mid-process as a routine event, and
    a stale cached epoch would void every freshly captured id."""
    return seat_corpse.server_epoch_now()


_BOOT_ID_PROBE_CACHE: dict[str, str | None] = {}
_BOOT_EPOCH_PROBE_CACHE: dict[str, str | None] = {}


def _probe_boot_id() -> str | None:
    try:
        result = verbose.run(
            ["sysctl", "-n", "kern.bootsessionuuid"], text=True,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
        uuid_value = result.stdout.strip().lower() if result.returncode == 0 else ""
        if re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", uuid_value):
            return f"bootuuid:{uuid_value}"
    except (FileNotFoundError, OSError):
        pass
    return _probe_boot_epoch_id()


def _probe_boot_epoch_id() -> str | None:
    try:
        result = verbose.run(
            ["sysctl", "-n", "kern.boottime"], text=True,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
        if result.returncode == 0:
            match = re.search(r"sec\s*=\s*(\d+)", result.stdout)
            if match:
                return f"boot:{match.group(1)}"
    except (FileNotFoundError, OSError):
        pass
    try:
        for line in pathlib.Path("/proc/stat").read_text().splitlines():
            if line.startswith("btime "):
                return f"boot:{line.split()[1]}"
    except OSError:
        pass
    return None


def current_boot_epoch_id() -> str | None:
    override = os.environ.get("TAP_BOOT_ID_LEGACY")
    if override is not None:
        return override or None
    primary_override = os.environ.get("TAP_BOOT_ID")
    if primary_override and re.fullmatch(r"boot:\d+", primary_override):
        return primary_override
    if "value" not in _BOOT_EPOCH_PROBE_CACHE:
        _BOOT_EPOCH_PROBE_CACHE["value"] = _probe_boot_epoch_id()
    return _BOOT_EPOCH_PROBE_CACHE["value"]


def boot_ids_match(stored: str, current: str, current_legacy: str | None = None) -> bool:
    if stored == current and bool(stored):
        return True
    if "TAP_BOOT_ID" in os.environ and "TAP_BOOT_ID_LEGACY" not in os.environ and current_legacy is None:
        return False
    legacy = current_legacy if current_legacy is not None else current_boot_epoch_id()
    return seat_corpse.boot_ids_match(stored, current, legacy)


class LauncherError(Exception):
    pass


class TmuxNoServerError(LauncherError):
    """tmux positively reported that no server currently exists."""


# GitProbe moved to the completion leaf (re-exported at module top).

_PRESET_PROVENANCE_KEYS = frozenset({"name", "source_path", "config_digest"})


def _string_dict(value: object) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {
        key: item
        for key, item in value.items()
        if isinstance(key, str) and isinstance(item, str)
    }


def _preset_provenance_dict(value: object) -> dict[str, str] | None:
    if not isinstance(value, dict) or set(value) != _PRESET_PROVENANCE_KEYS:
        return None
    if not all(
        isinstance(value[key], str) and value[key]
        for key in _PRESET_PROVENANCE_KEYS
    ):
        return None
    return {key: value[key] for key in ("name", "source_path", "config_digest")}


@dataclasses.dataclass
class SessionRecord:
    name: str
    harness: str
    cwd: str
    base: str
    tag: str | None = None
    index: int | None = None
    model: str | None = None
    harness_session_id: str | None = None
    transcript_path: str | None = None
    quarantined_harness_session_id: str | None = None
    quarantined_transcript_path: str | None = None
    identity_quarantine_reason: str | None = None
    # tap-8qj7 rider r2: this record was ADOPTED from a manually-created seat the
    # launcher never launched (first-contact identity backfill), not born from a
    # launch. Durable + additive so forensics and seat_corpse-adjacent reads never
    # mistake an adopted seat for a launcher-born one (classify-at-capture doctrine).
    adopted_from_manual: bool = False
    # tap-9zwt: harness config flags forwarded VERBATIM to the base harness on every
    # launch AND resume (pnpm-style implicit passthrough). Captured once at `new`,
    # persisted here, and spliced back in by inject_passthrough on every
    # invocation-building path — so a seat's harness tuning (e.g. codex
    # `-c model_reasoning_effort="high"`) survives resume/restart/relaunch instead of
    # silently reverting to the harness profile default (the effort-reversion footgun
    # this bead root-fixes). Empty for adopted (tap-8qj7) and pre-9zwt records, so
    # replay is a no-op for them.
    harness_passthrough: list[str] = dataclasses.field(default_factory=list)
    # True when harness_passthrough came from preset/config params. Those tokens
    # take the builder floor (config can only ADD). False (default, omitted from
    # the row) means operator-typed or TAP-CLI passthrough, which inserts
    # unconditionally — tap-9zwt's "ahead of tap's own flags" sentence.
    passthrough_from_config: bool = False
    # Effective preset values and their audit source persist; raw config does not.
    harness_env: dict[str, str] = dataclasses.field(default_factory=dict)
    harness_unset_env: list[str] = dataclasses.field(default_factory=list)
    harness_tail: list[str] = dataclasses.field(default_factory=list)
    preset: dict[str, str] | None = None
    permissions: str | None = None
    history: list[str] = dataclasses.field(default_factory=list)
    last_launched: str | None = None
    last_seen: str | None = None
    # Used only between `new`'s collision decision and its launch. It must never
    # enter the durable manifest.
    replaces_session: str | None = dataclasses.field(default=None, repr=False, compare=False)
    replaces_manifest_session: str | None = dataclasses.field(default=None, repr=False, compare=False)
    replacement_record: dict | None = dataclasses.field(default=None, repr=False, compare=False)
    replacement_registry_entry: dict | None = dataclasses.field(default=None, repr=False, compare=False)
    # Transient authority from the collision picker's explicit [k]/fresh arm.
    # It never enters the manifest; it only bypasses pane-identity vetoes for
    # the canonical session name the operator chose to replace.
    kill_backup_required: bool = dataclasses.field(default=False, repr=False, compare=False)
    kill_backup_has_seat_state: bool = dataclasses.field(default=False, repr=False, compare=False)
    kill_backup_path: str | None = dataclasses.field(default=None, repr=False, compare=False)
    # Opaque compare-and-swap token for the launcher-owned pre-registration
    # transaction. It travels in the pane-died failure payload, never the manifest.
    launch_id: str | None = dataclasses.field(default=None, repr=False, compare=False)
    launch_failure_argv: list[str] | None = dataclasses.field(default=None, repr=False, compare=False)
    launch_failure_reason: str | None = dataclasses.field(default=None, repr=False, compare=False)
    identity_capture_action: str | None = dataclasses.field(default=None, repr=False, compare=False)
    # Ensure-ladder decision (tap-x077): which harness action realizes this
    # launch ("new" or "resume"), the vessel being absorbed (drives the
    # revalidate-before-teardown guard), and receipts to emit once it succeeds.
    ensure_action: str = dataclasses.field(default="new", repr=False, compare=False)
    ensure_vessel: str | None = dataclasses.field(default=None, repr=False, compare=False)
    ensure_receipts: list[str] = dataclasses.field(default_factory=list, repr=False, compare=False)

    @classmethod
    def from_dict(cls, data):
        history = data.get("history", [])
        if not isinstance(history, list):
            history = []
        replacement_record = data.get("replacement_record")
        if not isinstance(replacement_record, dict):
            replacement_record = None
        replacement_registry_entry = data.get("replacement_registry_entry")
        if not isinstance(replacement_registry_entry, dict):
            replacement_registry_entry = None
        return cls(
            name=data["name"],
            harness=data["harness"],
            cwd=data["cwd"],
            base=data.get("base") or pathlib.Path(data["cwd"]).name,
            tag=data.get("tag"),
            index=data.get("index"),
            model=data.get("model"),
            harness_session_id=data.get("harness_session_id"),
            transcript_path=data.get("transcript_path"),
            quarantined_harness_session_id=data.get("quarantined_harness_session_id"),
            quarantined_transcript_path=data.get("quarantined_transcript_path"),
            identity_quarantine_reason=data.get("identity_quarantine_reason"),
            adopted_from_manual=bool(data.get("adopted_from_manual", False)),
            harness_passthrough=[
                item for item in (data.get("harness_passthrough") or []) if isinstance(item, str)
            ],
            passthrough_from_config=bool(data.get("passthrough_from_config", False)),
            permissions=data.get("permissions"),
            harness_env=_string_dict(data.get("harness_env")),
            harness_unset_env=list(data.get("harness_unset_env") or []),
            harness_tail=list(data.get("harness_tail") or []),
            preset=_preset_provenance_dict(data.get("preset")),
            history=[item for item in history if isinstance(item, str)],
            last_launched=data.get("last_launched"),
            last_seen=data.get("last_seen"),
            replacement_record=replacement_record,
            replacement_registry_entry=replacement_registry_entry,
            launch_id=data.get("launch_id"),
            launch_failure_reason=data.get("launch_failure_reason"),
        )

    def to_dict(self):
        data = {
            "name": self.name,
            "harness": self.harness,
            "cwd": self.cwd,
            "base": self.base,
            "tag": self.tag,
            "index": self.index,
            "model": self.model,
            "harness_session_id": self.harness_session_id,
        }
        if self.last_launched:
            data["last_launched"] = self.last_launched
        if self.last_seen:
            data["last_seen"] = self.last_seen
        if self.transcript_path:
            data["transcript_path"] = self.transcript_path
        if self.quarantined_harness_session_id:
            data["quarantined_harness_session_id"] = self.quarantined_harness_session_id
        if self.quarantined_transcript_path:
            data["quarantined_transcript_path"] = self.quarantined_transcript_path
        if self.identity_quarantine_reason:
            data["identity_quarantine_reason"] = self.identity_quarantine_reason
        if self.adopted_from_manual:
            data["adopted_from_manual"] = True
        if self.permissions is not None:
            data["permissions"] = self.permissions
        if self.harness_passthrough:
            data["harness_passthrough"] = list(self.harness_passthrough)
        if self.passthrough_from_config:
            data["passthrough_from_config"] = True
        if self.harness_unset_env:
            data["harness_unset_env"] = list(self.harness_unset_env)
        if self.harness_tail:
            data["harness_tail"] = list(self.harness_tail)
        if self.harness_env:
            data["harness_env"] = dict(self.harness_env)
        if self.preset:
            data["preset"] = dict(self.preset)
        if self.history:
            data["history"] = list(self.history)
        return data

    def failure_dict(self):
        data = self.to_dict()
        if self.replacement_record:
            data["replacement_record"] = self.replacement_record
        if self.replacement_registry_entry:
            data["replacement_registry_entry"] = self.replacement_registry_entry
        if self.launch_id:
            data["launch_id"] = self.launch_id
        if self.launch_failure_reason:
            data["launch_failure_reason"] = self.launch_failure_reason
        return data


@dataclasses.dataclass
class Manifest:
    sessions: list[SessionRecord]
    dir_aliases: dict[str, str] = dataclasses.field(default_factory=dict)
    # The system boot epoch under which the file was last written (tap-h3y/A-PR2).
    # Populated on load; save always re-stamps the CURRENT boot. A stored value that
    # differs from current_boot_id() means the manifest predates this boot.
    boot_id: str | None = None


# shell_command() wraps with POSIX `exec "$0" "$@"` + shlex quoting. Only these
# basenames are compatible; fish/tcsh/nu must not be selected even if SHELL names them.
_POSIX_LOGIN_SHELLS = frozenset({"zsh", "bash", "sh", "dash", "ksh", "ash"})


def _is_posix_login_shell(path: str) -> bool:
    base = os.path.basename(path)
    if base.endswith(".exe"):
        base = base[:-4]
    return base in _POSIX_LOGIN_SHELLS


def resolve_login_shell() -> str:
    """Pick a POSIX-compatible login shell that exists on PATH.

    Hosts without zsh must still launch/respawn; prefer TAP_LAUNCH_SHELL, then
    SHELL, then zsh/bash/sh — but skip non-POSIX shells (fish/tcsh/nu) because
    ``shell_command`` always emits a POSIX ``exec \"$0\" \"$@\"`` wrapper.
    Falls back to ``/bin/sh`` when nothing compatible resolves.
    """
    candidates: list[str] = []
    for raw in (
        os.environ.get("TAP_LAUNCH_SHELL"),
        os.environ.get("SHELL"),
        "zsh",
        "bash",
        "sh",
        "/bin/sh",
    ):
        if not raw:
            continue
        if raw not in candidates:
            candidates.append(raw)
    for candidate in candidates:
        if os.path.isabs(candidate) and os.access(candidate, os.X_OK):
            if _is_posix_login_shell(candidate):
                return candidate
            continue
        found = shutil.which(candidate)
        if found and _is_posix_login_shell(found):
            return found
    return "/bin/sh"


@dataclasses.dataclass
class Invocation:
    argv: list[str]
    env: dict[str, str]
    unset_env: list[str] = dataclasses.field(default_factory=list)

    def shell_command(self):
        command = list(self.argv)
        effective_env = dict(self.env)
        for key in ("TAP_INDEX_HOME", "TAP_TMUX_SOCKET_PATH", "TAP_TMUX_SOCKET"):
            if os.environ.get(key):
                effective_env[key] = os.environ[key]
        if effective_env or self.unset_env:
            # Apply launcher-owned overrides after login startup has loaded so
            # dotfiles cannot replace harness-specific settings.
            assignments = [f"{key}={value}" for key, value in sorted(effective_env.items())]
            command = ["/usr/bin/env", *[token for key in self.unset_env for token in ("-u", key)], *assignments, *command]
        shell = resolve_login_shell()
        script = 'exec "$0" "$@"'
        return shlex.join([shell, "-lic", script, *command])


@dataclasses.dataclass
class PaneFacts:
    pane: str
    pane_id: str
    command: str
    path: str
    # The server generation these ids were observed under, read out of the SAME
    # tmux record (tap-ua9l finding 7). Empty when the record could not carry
    # one, which leaves the observation unproven rather than borrowing a
    # generation from a second probe — the borrowed stamp is what turned a
    # rebirth into a false-current row. Defaulted so the callers that
    # synthesise facts from a narrower record stay honest about not having it.
    server_epoch: str = ""
    # Bound to the same tmux record as pane id, command, and server generation.
    # None means a narrower synthetic record did not observe liveness.
    dead: bool | None = None
    # Harness-process identity from the same tmux record (`#{pane_pid}`).
    # None means a narrower synthetic record did not observe it; 0 is present
    # but unusable as a replacement witness.
    pane_pid: int | None = None


# Mirrors lib.sh's TAP_ID_RE: what the registry accepts as a handle. Kept next to
# sanitize_component because the pair is the whole decision — legal already, or
# clean it.
_HANDLE_TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")


def sanitize_component(value: str) -> str:
    return completion.sanitize_component(value)


def sanitize_alias(value: str) -> str:
    return sanitize_component(value).lower()


def name_words(value: str) -> list[str]:
    parts = re.sub(r"[^A-Za-z0-9]+", " ", value).split()
    words: list[str] = []
    for part in parts:
        words.extend(re.findall(r"[A-Z]+(?=[A-Z][a-z]|$)|[A-Z]?[a-z]+|[0-9]+", part))
    return words


def default_dir_alias(value: str) -> str:
    words = name_words(value)
    if not words:
        return "dir"
    return sanitize_alias("".join(word[0] for word in words))


def validate_exact_name(name: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_/-]+", name):
        raise LauncherError("--unique names must use only letters, numbers, '_', '-' or '/'")
    return name


# run_git_probe and _resolve_git_path moved to the completion leaf (re-exported at module top).


def derive_base(cwd: str, probe: GitProbe | None = None) -> str:
    probe = probe if probe is not None else run_git_probe(cwd)
    if probe.inside and probe.root:
        return sanitize_component(pathlib.Path(probe.root).name)
    return sanitize_component(pathlib.Path(cwd).resolve().name)


# root_for_cwd moved to the completion leaf (re-exported at module top).


def resolve_base_alias(cwd: str, manifest: Manifest, probe: GitProbe | None = None) -> str:
    root = root_for_cwd(cwd, probe)
    return manifest.dir_aliases.get(root) or derive_base(cwd, probe)


# Handles that can never be claimed (tap-7af). MIRRORS lib.sh's
# TAP_RESERVED_HANDLES, and reserved-handle.test.sh pins the two in lockstep the
# same way server-epoch-guard.test.sh pins the epoch across the language seam.
#
# The launcher needs its own copy because it does NOT claim through
# tap-register.sh: claim_pending_handle writes agents[handle] directly. And the
# handle comes from `tag or harness` (see allocate_name below), so
# `tap session launch <harness> --tag help` reaches that write with the reserved
# name — a documented flag, not a contrived path.
RESERVED_HANDLES = frozenset({"help"})


def session_name_for_handle(base: str, handle: str) -> str:
    """Slash session name from an already-canonical handle.

    Registry keys, catalog preset names, and other validated spellings keep
    their dots. ``named_session_name`` still sanitizes operator-typed tags.
    """
    return f"{sanitize_component(base)}/{handle}"


def allocate_name(
    base: str,
    harness: str,
    tag: str | None,
    existing_names: set[str],
    *,
    literal_handle: bool = False,
) -> str:
    raw = tag or harness
    handle = raw if literal_handle and tag else sanitize_component(raw)
    prefix = f"{sanitize_component(base)}/{handle}"
    used = set()
    pattern = re.compile(rf"^{re.escape(prefix)}-(\d+)$")
    for name in existing_names:
        if name == prefix:
            used.add(1)
            continue
        match = pattern.match(name)
        if match:
            index = int(match.group(1))
            used.add(1 if index == 0 else index)
    index = 1
    while index in used:
        index += 1
    return prefix if index == 1 else f"{prefix}-{index}"


def named_session_name(base: str, handle: str) -> str:
    return session_name_for_handle(base, sanitize_component(handle))


SEAT_ALIVE = seat_corpse.SEAT_ALIVE
SEAT_PANE_RECYCLED = seat_corpse.SEAT_PANE_RECYCLED
SEAT_PANE_GONE = seat_corpse.SEAT_PANE_GONE
SEAT_UNOBSERVABLE = seat_corpse.SEAT_UNOBSERVABLE


def tmux_pane_raw_id(target: str) -> str | None:
    """Return one raw pane-id field.

    `""` means tmux observed the target absent; `None` means the probe failed
    or the record framing is invalid. Whitespace is data, never absence.
    """
    try:
        result = verbose.run(
            ["tmux", "display-message", "-p", "-t", target, "#{pane_id}"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return "" if "can't find" in (result.stderr or "") else None
    raw = result.stdout
    if raw in ("", "\n"):
        return ""
    lines = raw.splitlines()
    if len(lines) != 1:
        return None
    return lines[0]


def seat_pane_observation(target: str) -> str | None:
    """Return a valid pane id, `""` for observed absence, or `None` when tmux
    or its answer is unobservable."""
    facts = tmux_pane_facts(target)
    if facts is not None:
        return facts.pane_id if seat_corpse.is_pane_id(facts.pane_id) else None
    if tmux_sessions_or_none() is None:
        return None
    raw = tmux_pane_raw_id(target)
    if raw is None:
        return None
    if raw == "":
        return ""
    return raw if seat_corpse.is_pane_id(raw) else None


def seat_pane_probe(stored_id: str, pane: str) -> str:
    """Classify through the Python authority shared with the register ladder;
    the Bash mirror is pinned by `seat-corpse-lockstep.test.sh`."""
    return seat_corpse.classify_pane(stored_id, pane, seat_pane_observation)


def seat_is_reclaimable_corpse(
    entry: object,
    live_sessions=_UNSET,
    observed_server_epoch=_UNSET,
    observed_boot_id=_UNSET,
) -> bool:
    """True only for an active pane-backed row whose exact session name is
    positively absent on its current boot/server generation.

    This is the allocator's name-authority classifier. A recycled pane id in
    another session cannot keep an absent name alive. Conversely, an absent
    name stamped under a prior or unobservable boot/generation is OFFLINE or
    UNKNOWN, not GONE, and retains its recovery pointer. The register ladder
    remains the locked claim authority.
    """
    if not isinstance(entry, dict):
        return False
    if seat_corpse.is_launch_reservation(entry):
        return False
    if entry.get("delivery") == "poll":
        return False
    if entry.get("status", "active") != "active":
        return False
    stored_id = str(entry.get("pane_id") or "")
    pane = str(entry.get("pane") or "")
    if stored_id and not seat_corpse.is_pane_id(stored_id):
        return False
    if not stored_id and not pane:
        return False
    if live_sessions is _UNSET:
        live_sessions = tmux_sessions_or_none()
    if live_sessions is None:
        return False
    session = str(entry.get("session") or "")
    if not session and ":" in pane:
        session = pane.split(":", 1)[0]
    if not session:
        return False
    if session in live_sessions:
        return False

    row_epoch = str(entry.get("server_epoch") or "")
    if row_epoch:
        if observed_server_epoch is _UNSET:
            observed_server_epoch = current_server_epoch()
        if not observed_server_epoch or row_epoch != observed_server_epoch:
            return False

    row_boot = str(entry.get("boot_id") or "")
    if row_boot:
        if observed_boot_id is _UNSET:
            observed_boot_id = current_boot_id()
        if not observed_boot_id or not boot_ids_match(row_boot, observed_boot_id):
            return False

    return True


def occupied_session_names(base: str, root: str, live_sessions=_UNSET) -> set[str]:
    """Return observable live tmux names plus protected registered names, using
    one snapshot. The register ladder re-probes under lock."""
    if live_sessions is _UNSET:
        live_sessions = tmux_sessions_or_none()
    observed_epoch = current_server_epoch() if live_sessions is not None else None
    observed_boot = current_boot_id()
    return (live_sessions or set()) | {
        session_name_for_handle(base, handle)
        for handle, entry in tap_seat_entries(root, live_sessions=live_sessions).items()
        if not seat_is_reclaimable_corpse(
            entry,
            live_sessions=live_sessions,
            observed_server_epoch=observed_epoch,
            observed_boot_id=observed_boot,
        )
    }


def default_tag_for_model(model: str | None) -> str | None:
    if model and "fable" in model.lower():
        return "fable"
    return None


def current_timestamp() -> str:
    override = os.environ.get("TAP_WATCH_NOW")
    if override:
        try:
            now = datetime.datetime.fromtimestamp(int(override), datetime.timezone.utc)
        except ValueError:
            now = datetime.datetime.now(datetime.timezone.utc)
    else:
        now = datetime.datetime.now(datetime.timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


parse_timestamp = seat_corpse.parse_timestamp


def pending_reservation_expired(entry: dict, live_sessions=_UNSET, now: str | None = None) -> bool:
    """Observation wrapper over seat_corpse.launch_reservation_expired — THE
    shared expiry rule (also executed by the register chooser's launching-row
    protection). Cheap shape guards run before any tmux observation; the
    boot-epoch self-heal (A-PR2) rides the shared rule: a reservation stamped
    under a PRIOR boot expires the instant it is noticed."""
    if not seat_corpse.is_launch_reservation(entry):
        return False
    session = entry.get("session")
    if not isinstance(session, str) or not session:
        return False
    if live_sessions is _UNSET:
        live_sessions = tmux_sessions_or_none()
    return seat_corpse.launch_reservation_expired(
        entry, live_sessions, parse_timestamp(now or current_timestamp()), current_boot_id(),
        current_boot_epoch_id()
    )


def stamp_launched(record: SessionRecord, timestamp: str | None = None) -> SessionRecord:
    return dataclasses.replace(record, last_launched=timestamp or current_timestamp())


def normalize_tag(harness: str, tag: str | None) -> str | None:
    return None if tag == harness else tag


def default_codex_sessions_root() -> pathlib.Path:
    codex_home = pathlib.Path(os.environ.get("TAP_CODEX_HOME") or os.environ.get("CODEX_HOME", "~/.codex")).expanduser()
    return codex_home / "sessions"


def rollout_session_meta(path: pathlib.Path) -> dict | None:
    try:
        with path.open() as handle:
            for line in handle:
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(item, dict) and item.get("type") == "session_meta" and isinstance(item.get("payload"), dict):
                    return item["payload"]
    except OSError:
        return None
    return None


def iter_codex_rollouts(root: pathlib.Path):
    try:
        years = sorted((path for path in root.iterdir() if path.is_dir()), reverse=True)
    except OSError:
        return
    for year in years:
        try:
            months = sorted((path for path in year.iterdir() if path.is_dir()), reverse=True)
        except OSError:
            continue
        for month in months:
            try:
                days = sorted((path for path in month.iterdir() if path.is_dir()), reverse=True)
            except OSError:
                continue
            for day in days:
                try:
                    yield from sorted(day.glob("rollout-*.jsonl"), reverse=True)
                except OSError:
                    continue


def iter_codex_session_ids_for_cwd(
    cwd: str,
    sessions_root: pathlib.Path | None = None,
    started_after: str | None = None,
):
    root = sessions_root or default_codex_sessions_root()
    start_at = parse_timestamp(started_after) if started_after else None
    if started_after and start_at is None:
        return
    cwd_path = pathlib.Path(cwd).resolve()
    for rollout in iter_codex_rollouts(root):
        meta = rollout_session_meta(rollout)
        if not meta:
            continue
        meta_cwd = meta.get("cwd")
        session_id = meta.get("id")
        if isinstance(meta_cwd, str) and isinstance(session_id, str) and pathlib.Path(meta_cwd).resolve() == cwd_path:
            if start_at is not None:
                meta_at = parse_timestamp(meta.get("timestamp"))
                if meta_at is None or meta_at <= start_at:
                    continue
            yield session_id


def find_codex_session_id_for_cwd(
    cwd: str,
    sessions_root: pathlib.Path | None = None,
    started_after: str | None = None,
) -> str | None:
    matches = list(
        itertools.islice(
            iter_codex_session_ids_for_cwd(
                cwd,
                sessions_root=sessions_root,
                started_after=started_after,
            ),
            2,
        )
    )
    return matches[0] if len(matches) == 1 else None


# Harnesses whose native conversation id is discoverable from an on-disk / CLI
# store the launcher can scan (tap-xl3f). cursor is absent by design: its id is
# captured at the SessionStart hook (CURSOR_CONVERSATION_ID restamp), not by a
# filesystem scan, so it never needs a backfill twin. hermes has no id concept.
SCAN_ID_HARNESSES = ("codex", "claude", "opencode")

# Ownership anchor for a resume whose durable record never recorded a launch
# time. The conversation predates the resume, so it must bracket as the EARLIEST
# possible launcher — that lets a legitimate SINGLETON resume still claim its one
# conversation (grok: cohort-routing must not over-refuse a singleton) while
# still losing ownership to any sibling that has a real, later anchor.
EARLIEST_RESUME_ANCHOR = "1970-01-01T00:00:00Z"

# `opencode session list` shells out; bound it so a hung CLI never stalls a
# `tap session list` / census render.
OPENCODE_SESSION_LIST_TIMEOUT = 5.0

def default_claude_projects_root() -> pathlib.Path:
    claude_home = pathlib.Path(
        os.environ.get("TAP_CLAUDE_HOME") or os.environ.get("CLAUDE_HOME", "~/.claude")
    ).expanduser()
    return claude_home / "projects"


def claude_cwd_slug(cwd: str) -> str:
    """Claude's on-disk project-dir name for a cwd: every non-alphanumeric
    character maps to '-' (so '/', '.', '_', spaces all collapse). The transform
    is NOT injective, so callers MUST verify the recorded cwd inside each
    candidate transcript before trusting a slug-dir match (a pinned smoke keeps
    this in lockstep with claude's actual behaviour)."""
    return re.sub(r"[^A-Za-z0-9]", "-", cwd)


def claude_project_dirs_for_cwd(
    cwd: str,
    projects_root: pathlib.Path | None = None,
) -> list[pathlib.Path]:
    """Candidate project dirs for a cwd. Claude builds the slug from the cwd
    string the session actually ran in, which may differ from the resolved path
    by a symlink (`/var` vs `/private/var` on macOS; any symlinked checkout root),
    so we look under BOTH the literal and the resolved slug. The interior-cwd
    re-verify still gates every hit, so a spurious extra dir costs at most a few
    stats, never a wrong match."""
    root = projects_root or default_claude_projects_root()
    slugs: list[str] = []
    for candidate in (cwd, str(pathlib.Path(cwd).resolve())):
        slug = claude_cwd_slug(candidate)
        if slug not in slugs:
            slugs.append(slug)
    return [root / slug for slug in slugs]


def _claude_transcripts_for_cwd(
    cwd: str,
    projects_root: pathlib.Path | None = None,
) -> list[pathlib.Path]:
    transcripts: list[pathlib.Path] = []
    for project_dir in claude_project_dirs_for_cwd(cwd, projects_root=projects_root):
        try:
            transcripts.extend(project_dir.glob("*.jsonl"))
        except OSError:
            continue
    return sorted(transcripts, reverse=True)


def claude_session_meta(path: pathlib.Path) -> dict | None:
    """Claude twin of rollout_session_meta: {id, cwd, timestamp} for a transcript.

    The resume key claude uses is the FILE NAME (`<session-id>.jsonl`) — the same
    id `conversation_artifact_missing` probes — so `id` is the filename stem, not
    any interior field. `cwd` and the earliest event timestamp are read from the
    body. A transcript whose interior `sessionId` disagrees with its own filename
    is skipped: that is a forked/renamed/corrupt file, never a safe resume target
    (the tap-4avp discipline — infer only what the record can trust)."""
    session_id = path.stem
    cwd = None
    timestamp = None
    try:
        with path.open() as handle:
            for line in handle:
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(item, dict):
                    continue
                interior = item.get("sessionId")
                if isinstance(interior, str) and interior != session_id:
                    return None
                if cwd is None and isinstance(item.get("cwd"), str):
                    cwd = item["cwd"]
                if timestamp is None and isinstance(item.get("timestamp"), str):
                    timestamp = item["timestamp"]
                if cwd is not None and timestamp is not None:
                    break
    except OSError:
        return None
    if cwd is None:
        return None
    return {"id": session_id, "cwd": cwd, "timestamp": timestamp}


def iter_claude_session_ids_for_cwd(
    cwd: str,
    projects_root: pathlib.Path | None = None,
    started_after: str | None = None,
):
    """Claude twin of iter_codex_session_ids_for_cwd. Claude indexes transcripts
    by a cwd-slug directory, so we read only that one directory (cheap) and still
    verify each candidate's interior cwd — the slug is not injective, so the
    directory is a fast index, never proof of identity."""
    start_at = parse_timestamp(started_after) if started_after else None
    if started_after and start_at is None:
        return
    cwd_path = pathlib.Path(cwd).resolve()
    for transcript in _claude_transcripts_for_cwd(cwd, projects_root=projects_root):
        meta = claude_session_meta(transcript)
        if not meta:
            continue
        meta_cwd = meta.get("cwd")
        session_id = meta.get("id")
        if not (isinstance(meta_cwd, str) and isinstance(session_id, str)):
            continue
        try:
            resolved = pathlib.Path(meta_cwd).resolve()
        except OSError:
            continue
        if resolved != cwd_path:
            continue
        if start_at is not None:
            meta_at = parse_timestamp(meta.get("timestamp"))
            if meta_at is None or meta_at <= start_at:
                continue
        yield session_id


def find_claude_session_id_for_cwd(
    cwd: str,
    projects_root: pathlib.Path | None = None,
    started_after: str | None = None,
) -> str | None:
    matches = list(
        itertools.islice(
            iter_claude_session_ids_for_cwd(
                cwd,
                projects_root=projects_root,
                started_after=started_after,
            ),
            2,
        )
    )
    return matches[0] if len(matches) == 1 else None


def opencode_session_list(sessions_json: str | None = None) -> list | None:
    """Parsed `opencode session list --format json`, or None on any failure.

    OpenCode exposes no per-launch on-disk index the launcher can stat; its CLI
    is the only stable join surface (the SQLite store's schema/XDG path are
    private). Callers that scan several opencode records in one pass fetch once
    and thread the result through `sessions_json` to avoid re-shelling per row."""
    if sessions_json is None:
        try:
            result = verbose.run(
                ["opencode", "session", "list", "--format", "json"],
                capture_output=True,
                text=True,
                timeout=OPENCODE_SESSION_LIST_TIMEOUT,
            )
        except (OSError, subprocess.SubprocessError):
            return None
        if result.returncode != 0:
            return None
        sessions_json = result.stdout
    try:
        sessions = json.loads(sessions_json)
    except json.JSONDecodeError:
        return None
    return sessions if isinstance(sessions, list) else None


def cursor_mint_session(cwd: str) -> str | None:
    """Launch-time pre-mint for cursor (tap-e9v8): `cursor-agent create-chat`
    prints a UUID reservation and --resume <id> materializes it on first
    message. Returns the UUID or None on any failure (fail-open).

    Note: cursor's one-time workspace-trust prompt may block create-chat in a
    fresh workspace — documented in the PR body. If create-chat fails, the
    launch proceeds with no pre-mint (today's behavior).
    """
    try:
        result = verbose.run(
            ["cursor-agent", "create-chat"],
            capture_output=True,
            text=True,
            timeout=10.0,
            cwd=cwd,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    # create-chat prints the UUID to stdout (verified in research drop).
    # Match a bare UUID (cursor's format) from the output.
    match = re.search(r"\b([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\b",
                      result.stdout, re.IGNORECASE)
    return match.group(1) if match else None


def refuse_preexisting_id_on_new_mint(record: SessionRecord) -> None:
    """Fail-closed (tap-rs1q (b), opus-2 gate pin).

    ``cmd_new`` mints only when ``ensure_action == "new"`` and
    ``harness_session_id`` is empty. A new cursor record that already carries
    an id would skip that mint and, after the id-first argv pin, exact-target
    ``--resume`` at a stored id. No production constructor builds that
    combination (inherited_id is resume-only; clear wipes before mint).

    This check must run PRE-MINT. After ``mint_launch_session_id`` succeeds,
    a freshly minted id and a leaked stored id are the same shape on the
    record — indistinguishable by inspection without a freshness bit, which
    is why emission does not carry one and why relocating this check past
    the mint would make it a no-op.
    """
    if record.ensure_action != "new":
        return
    if record.harness != "cursor":
        return
    if not record.harness_session_id:
        return
    raise LauncherError(
        f"refusing new {record.harness} launch with a pre-existing "
        f"harness_session_id ({record.harness_session_id}); that combination "
        "skips the mint and would hand the process a stored id. Fresh launches "
        "mint; stored ids resume."
    )


def mint_launch_session_id(record: SessionRecord) -> SessionRecord:
    """Dispatcher (tap-e9v8): mint a native session id for the record's harness
    at launch time. Returns the record unchanged if the harness has no mint
    route (claude uses --session-id; codex/claude already have deterministic
    capture) or if minting fails (fail-open — launch proceeds with no id).

    On success, stamps `harness_session_id` and `identity_capture_action="new"`
    so the reservation carries `mode=launcher_new` with the expected id
    (composition with #xxx's capture guard — deterministic identity end-to-end).
    """
    # Never mint if the record already has an id (resume, or a prior mint).
    if record.harness_session_id:
        return record
    if record.harness == "cursor":
        minted = cursor_mint_session(record.cwd)
    else:
        # OpenCode's plugin captures the TUI-created id during `tap in`, so
        # pre-minting would pay for an `opencode serve` process the launch does
        # not need. Claude and codex already have deterministic launch-time
        # capture (claude via --session-id, codex via rollout discovery).
        return record
    if not minted:
        # Fail-open: no id, launch proceeds with today's behavior.
        return record
    updated = dataclasses.replace(record, harness_session_id=minted)
    updated.identity_capture_action = "new"
    return updated


def _opencode_session_created_ms(item: object) -> float:
    value = item.get("created") if isinstance(item, dict) else None
    return value if isinstance(value, (int, float)) else -1.0


def iter_opencode_session_ids_for_cwd(
    cwd: str,
    started_after: str | None = None,
    sessions: list | None = None,
):
    """OpenCode twin of iter_codex_session_ids_for_cwd, over the CLI's session
    list. OpenCode writes the row at FIRST MESSAGE, not launch — so a scan run
    before the seat takes a turn correctly finds nothing (the caller retries on
    the next census/list). `created` is epoch milliseconds."""
    start_at = parse_timestamp(started_after) if started_after else None
    if started_after and start_at is None:
        return
    if sessions is None:
        sessions = opencode_session_list()
    if sessions is None:
        return
    cwd_path = pathlib.Path(cwd).resolve()
    # Newest first so the exactly-one guard is stable regardless of CLI order.
    for item in sorted(sessions, key=_opencode_session_created_ms, reverse=True):
        if not isinstance(item, dict):
            continue
        directory = item.get("directory")
        session_id = item.get("id")
        if not (isinstance(directory, str) and isinstance(session_id, str)):
            continue
        try:
            resolved = pathlib.Path(directory).resolve()
        except OSError:
            continue
        if resolved != cwd_path:
            continue
        if start_at is not None:
            created = _opencode_session_created_ms(item)
            if created < 0 or (created / 1000.0) <= start_at:
                continue
        yield session_id


def find_opencode_session_id_for_cwd(
    cwd: str,
    started_after: str | None = None,
    sessions: list | None = None,
) -> str | None:
    matches = list(
        itertools.islice(
            iter_opencode_session_ids_for_cwd(
                cwd,
                started_after=started_after,
                sessions=sessions,
            ),
            2,
        )
    )
    return matches[0] if len(matches) == 1 else None


def codex_session_candidates_for_cwd(
    cwd: str,
    sessions_root: pathlib.Path | None = None,
) -> list[tuple[str, float | None]]:
    """All `(id, created_seconds)` codex rollouts for a cwd — UNFILTERED by time.
    The cohort-ownership resolver does the temporal binding, so the scanners hand
    back every candidate rather than pre-collapsing to one."""
    root = sessions_root or default_codex_sessions_root()
    cwd_path = pathlib.Path(cwd).resolve()
    out: list[tuple[str, float | None]] = []
    for rollout in iter_codex_rollouts(root):
        meta = rollout_session_meta(rollout)
        if not meta:
            continue
        meta_cwd = meta.get("cwd")
        session_id = meta.get("id")
        if not (isinstance(meta_cwd, str) and isinstance(session_id, str)):
            continue
        try:
            if pathlib.Path(meta_cwd).resolve() != cwd_path:
                continue
        except OSError:
            continue
        out.append((session_id, parse_timestamp(meta.get("timestamp"))))
    return out


def claude_session_candidates_for_cwd(
    cwd: str,
    projects_root: pathlib.Path | None = None,
) -> list[tuple[str, float | None]]:
    """All `(id, created_seconds)` claude transcripts for a cwd — interior-cwd
    re-verified (the slug is not injective), UNFILTERED by time."""
    cwd_path = pathlib.Path(cwd).resolve()
    out: list[tuple[str, float | None]] = []
    for transcript in _claude_transcripts_for_cwd(cwd, projects_root=projects_root):
        meta = claude_session_meta(transcript)
        if not meta:
            continue
        meta_cwd = meta.get("cwd")
        session_id = meta.get("id")
        if not (isinstance(meta_cwd, str) and isinstance(session_id, str)):
            continue
        try:
            if pathlib.Path(meta_cwd).resolve() != cwd_path:
                continue
        except OSError:
            continue
        out.append((session_id, parse_timestamp(meta.get("timestamp"))))
    return out


def opencode_session_candidates_for_cwd(
    cwd: str,
    sessions: list | None = None,
) -> list[tuple[str, float | None]]:
    """All `(id, created_seconds)` opencode sessions for a cwd — UNFILTERED by
    time. `sessions` threads one CLI fetch through a whole sweep."""
    if sessions is None:
        sessions = opencode_session_list()
    if sessions is None:
        return []
    cwd_path = pathlib.Path(cwd).resolve()
    out: list[tuple[str, float | None]] = []
    for item in sessions:
        if not isinstance(item, dict):
            continue
        directory = item.get("directory")
        session_id = item.get("id")
        if not (isinstance(directory, str) and isinstance(session_id, str)):
            continue
        try:
            if pathlib.Path(directory).resolve() != cwd_path:
                continue
        except OSError:
            continue
        created = _opencode_session_created_ms(item)
        out.append((session_id, (created / 1000.0) if created >= 0 else None))
    return out


def session_id_candidates_for_cwd(
    harness: str,
    cwd: str,
    opencode_sessions: list | None = None,
) -> list[tuple[str, float | None]]:
    if harness == "codex":
        return codex_session_candidates_for_cwd(cwd)
    if harness == "claude":
        return claude_session_candidates_for_cwd(cwd)
    if harness == "opencode":
        return opencode_session_candidates_for_cwd(cwd, sessions=opencode_sessions)
    return []


def resolve_owned_session_ids(
    records: list[SessionRecord],
    candidates: list[tuple[str, float | None]],
) -> dict[str, str]:
    """Assign at most one candidate id to each EMPTY record in a same-harness,
    same-cwd cohort, by **window-bracketing**: a candidate created at Tc is owned
    by the sibling with the greatest `last_launched` strictly before Tc — the most
    recent launch before that conversation appeared. This is GLOBAL exactly-one,
    not per-record (crew-wolf PR #xxx): a candidate two peers could claim — a tie
    at the owner anchor, or a singleton that belongs to a later-launched sibling —
    is assigned to NEITHER. Empty-only; returns `{record.name: id}`.

    The failure this closes: two empty co-cwd seats, A.launch < B.launch, only B's
    row minted — per-record exactly-one gives ses_B to BOTH; window-bracketing
    binds ses_B to B alone and leaves A empty (the tap-4avp no-dual-assign rule)."""
    anchors = [
        anchor
        for anchor in (parse_timestamp(record.last_launched) for record in records)
        if anchor is not None
    ]
    assignments: dict[str, str] = {}
    for record in records:
        if record.harness_session_id:
            continue  # empty-only
        anchor = parse_timestamp(record.last_launched)
        if anchor is None:
            continue
        owned: list[str] = []
        for session_id, created in candidates:
            if created is None or created <= anchor:
                continue
            eligible = [a for a in anchors if a < created]
            if not eligible:
                continue
            owner_anchor = max(eligible)
            if owner_anchor != anchor:
                continue  # a later-launched sibling owns this conversation
            if sum(1 for a in anchors if a == owner_anchor) > 1:
                continue  # simultaneous siblings — unownable, refuse
            owned.append(session_id)
        if len(owned) == 1:
            assignments[record.name] = owned[0]
    # No-dual-assign, via the shared capture-guard authority (tap-4avp/#166,
    # adopted at rebase in place of a private counter): window-bracketing already
    # gives each candidate a single owner, so `duplicate_harness_session_owner`
    # is the ASSERT — it drops an assignment whose id another record in THIS
    # cohort already holds (its reach here is exactly the `records` passed in,
    # not machine-wide — the registry-scope check `duplicate_registry_session_owner`
    # is a separate guard the resume path runs, not this resolver). That still
    # catches what a batch-local counter never could: a filled peer, including an
    # anchorless one (#xxx F1). The `taken` set guards the intra-pass collision
    # window-bracketing already precludes.
    by_name = {record.name: record for record in records}
    result: dict[str, str] = {}
    taken: set[str] = set()
    for name, cid in assignments.items():
        if cid in taken:
            continue
        if duplicate_harness_session_owner(records, by_name[name], cid) is not None:
            continue  # id already owned elsewhere — never invent a duplicate
        result[name] = cid
        taken.add(cid)
    return result


def compute_backfill_ids(records: list[SessionRecord]) -> dict[str, str]:
    """Read-only: resolve inferable native ids for a set of records via per-
    (harness, cwd) cohort ownership. One opencode CLI fetch for the whole set.
    Returns `{record.name: id}`. Shared by the write-moment sweep (persists) and
    the census inference (display only) — same resolution, different disposition."""
    if not any(
        record.harness in SCAN_ID_HARNESSES and not record.harness_session_id and record.last_launched
        for record in records
    ):
        return {}
    opencode_sessions = (
        opencode_session_list()
        if any(record.harness == "opencode" for record in records)
        else None
    )
    # Group the FULL cohort (empty AND filled siblings) by (harness, RESOLVED
    # cwd): a filled sibling must vote in the ownership ASSERT so an empty peer
    # can never claim the id that already belongs to it, and resolution collapses
    # symlink variants of one path into one cohort. Membership is NOT gated on
    # `last_launched` (crew-wolf/sol #xxx F1): an anchorless FILLED peer still
    # holds an id the assert must see; it just does not vote in the temporal
    # bracketing (which needs an anchor). Only an anchorless EMPTY record is
    # inert — unbracketable and idless — and resolve_owned skips it. The SCAN
    # uses an ORIGINAL cwd string (`record.cwd`), because the claude slug is
    # built from the cwd the session ran in — resolving it first would look under
    # the wrong slug dir.
    groups: dict[tuple[str, str], list[SessionRecord]] = {}
    for record in records:
        if record.harness not in SCAN_ID_HARNESSES:
            continue
        try:
            key = (record.harness, str(pathlib.Path(record.cwd).resolve()))
        except OSError:
            continue
        groups.setdefault(key, []).append(record)
    resolved: dict[str, str] = {}
    for (harness, _resolved_cwd), cohort in groups.items():
        if all(record.harness_session_id for record in cohort):
            continue  # nothing empty to fill in this cohort
        candidates = session_id_candidates_for_cwd(
            harness, cohort[0].cwd, opencode_sessions=opencode_sessions
        )
        if not candidates:
            continue
        resolved.update(resolve_owned_session_ids(cohort, candidates))
    return resolved


def conversation_artifact_missing(record: SessionRecord, started_after: str) -> bool:
    if record.harness == "claude":
        if record.transcript_path:
            try:
                transcript = pathlib.Path(record.transcript_path).stat()
            except FileNotFoundError:
                return True
            except OSError:
                # Exact hook-provided path is authoritative, but an unreadable
                # filesystem is still cannot-verify, never permission to prune.
                return False
            return not stat.S_ISREG(transcript.st_mode)
        if not record.harness_session_id:
            return True
        claude_home = pathlib.Path(
            os.environ.get("TAP_CLAUDE_HOME") or os.environ.get("CLAUDE_HOME", "~/.claude")
        ).expanduser()
        projects = claude_home / "projects"
        try:
            return not any(
                (project / f"{record.harness_session_id}.jsonl").is_file()
                for project in projects.iterdir()
            )
        except (FileNotFoundError, OSError):
            # Cannot verify (projects dir absent — e.g. a wrong/empty
            # TAP_CLAUDE_HOME — or an I/O error): fail CLOSED and report the
            # artifact as present. The one caller that DELETES on "missing"
            # (--verify-resumable prune) must never sweep a real transcript it
            # simply failed to see (grok8 F3, tap-h3y fix-wave).
            return False
    if record.harness == "codex":
        return next(
            iter_codex_session_ids_for_cwd(record.cwd, started_after=started_after),
            None,
        ) is None
    if record.harness == "agy":
        # agy persists each conversation as ~/.gemini/antigravity-cli/conversations/
        # <uuid>.db (tap-8qj7). A record with no id has nothing to hand back; with an
        # id, the .db must exist. Fail CLOSED (report present) on any probe error, the
        # same rule as claude — never let a transient miss condemn a live conversation.
        if not record.harness_session_id:
            return True
        gemini_home = pathlib.Path(
            os.environ.get("TAP_GEMINI_HOME") or os.environ.get("GEMINI_HOME", "~/.gemini")
        ).expanduser()
        conversation_db = gemini_home / "antigravity-cli" / "conversations" / f"{record.harness_session_id}.db"
        try:
            return not conversation_db.is_file()
        except OSError:
            return False
    return False


def record_has_resume_artifact(record: SessionRecord) -> bool:
    """True when the record points at a real, resumable conversation — a live
    harness transcript/rollout to hand back — not merely a (possibly stillborn)
    harness_session_id. A claude record whose uuid was minted but whose session
    stopped before writing a transcript has NO artifact, so it is not resumable; that
    is exactly the gone record that hard-blocked a relaunch in Ops's two repros (tap-h3y).

    Fails safe: conversation_artifact_missing returns False on an I/O error probing
    the store, so a transient failure reads as "resumable" — we never treat a
    maybe-live record as gone. Harnesses with no artifact concept (opencode, cursor,
    hermes) are always considered resumable here, preserving today's block behavior
    for them.
    """
    return not conversation_artifact_missing(record, "")


@dataclasses.dataclass(frozen=True)
class ResumeTarget:
    """Resolved exact-resume identity for a seat (tap-gc1n / Bug B).

    ``session_id`` None means the id-less harness picker (``--resume`` with no
    uuid). ``source`` names which chain step won. ``disclosure`` is operator-
    visible text for the quarantined step — never a silent unquarantine.
    """

    session_id: str | None
    source: str  # acting_hsid | transcript_path | quarantined | picker
    split_brain: bool = False
    disclosure: str | None = None


def _claude_home() -> pathlib.Path:
    return pathlib.Path(
        os.environ.get("TAP_CLAUDE_HOME") or os.environ.get("CLAUDE_HOME", "~/.claude")
    ).expanduser()


def claude_session_transcript_exists(session_id: str | None) -> bool:
    """True when ``~/.claude/projects/*/<session_id>.jsonl`` is a regular file.

    Probes the *chosen* id — not ``transcript_path`` — so a ghost
    ``harness_session_id`` cannot hide behind an older live transcript path
    (tap-gc1n). I/O errors fail closed as missing (refuse exact-target).
    """
    if not session_id or not isinstance(session_id, str):
        return False
    projects = _claude_home() / "projects"
    try:
        return any(
            (project / f"{session_id}.jsonl").is_file()
            for project in projects.iterdir()
        )
    except (FileNotFoundError, OSError):
        return False


def _transcript_path_session_id(transcript_path: str | None) -> str | None:
    if not transcript_path or not isinstance(transcript_path, str):
        return None
    name = pathlib.Path(transcript_path).name
    if name.endswith(".jsonl") and len(name) > 6:
        return name[: -len(".jsonl")]
    return None


def resolve_resume_target(record: SessionRecord) -> ResumeTarget:
    """Pick a verified resume id, falling toward durable evidence (tap-gc1n).

    Chain (claude): acting ``harness_session_id`` → id derived from
    ``transcript_path`` → ``quarantined_harness_session_id`` (disclosed) →
    id-less picker. Each exact step requires an on-disk transcript for that
    id. Launcher-manifest hsid is intentionally absent — post-flip resume
    reads acting registry only.
    """
    if record.harness != "claude":
        return ResumeTarget(record.harness_session_id, "acting_hsid")

    hsid = record.harness_session_id if isinstance(record.harness_session_id, str) else None
    tpath_id = _transcript_path_session_id(record.transcript_path)
    split = bool(hsid and tpath_id and hsid != tpath_id)

    if hsid and claude_session_transcript_exists(hsid):
        return ResumeTarget(hsid, "acting_hsid", split_brain=split)
    if tpath_id and claude_session_transcript_exists(tpath_id):
        return ResumeTarget(tpath_id, "transcript_path", split_brain=True if hsid else split)
    qid = (
        record.quarantined_harness_session_id
        if isinstance(record.quarantined_harness_session_id, str)
        else None
    )
    if qid and claude_session_transcript_exists(qid):
        return ResumeTarget(
            qid,
            "quarantined",
            split_brain=split or bool(hsid or tpath_id),
            disclosure="resuming quarantined session; attestation previously failed",
        )
    return ResumeTarget(None, "picker", split_brain=split)


def _emit_resume_target_receipts(record: SessionRecord, target: ResumeTarget) -> None:
    if target.split_brain:
        print(
            "tap session: resume_identity_split — "
            f"harness_session_id={record.harness_session_id!r} "
            f"transcript_path={record.transcript_path!r}; "
            f"using {target.source}"
            + (f" id={target.session_id}" if target.session_id else "")
            + "; next: realign harness_session_id to the durable transcript",
            file=sys.stderr,
        )
    if target.disclosure:
        print(f"tap session: {target.disclosure}", file=sys.stderr)
    if target.source == "picker":
        print(
            "tap session: no verified resume transcript; "
            "falling through to id-less harness picker",
            file=sys.stderr,
        )
    elif target.source == "transcript_path" and not target.split_brain:
        print(
            f"tap session: resume target from transcript_path id={target.session_id}",
            file=sys.stderr,
        )


def adopted_registry_identity(entry: dict | None) -> str | None:
    """The verified conversation id to adopt from a registry seat that has NO
    manifest record — the first-contact backfill for a manually-created seat
    (tap-8qj7 rider r1). Only an env capture or exact process-held session file is identity:
    session_attribution_trust must be 'env' or 'process' AND harness_session_id must be non-empty.

    r1 is MECHANICAL upstream (tap-iee8): an inferred/derived id can never reach
    harness_session_id — it rides the separate derived_harness_session_id field,
    which we never read for identity. This trust gate is the belt-and-suspenders on
    top of that structural guarantee. Absent or unverified -> None, and the resume
    rung honestly falls to --continue rather than adopting a guessed conversation
    (a wrong id mis-attributes durably — the one-way-door risk r1 exists to prevent).
    """
    if not isinstance(entry, dict):
        return None
    if entry.get("session_attribution_trust") not in ("env", "process"):
        return None
    hsid = entry.get("harness_session_id")
    return hsid if isinstance(hsid, str) and hsid else None


def agy_conversation_candidates() -> list[str]:
    """Conversation ids with a store on disk (~/.gemini/antigravity-cli/
    conversations/<uuid>.db), newest first — a cheap, bounded enumeration for the
    adopted-no-id refusal guidance (tap-8qj7 P2). Empty on any store error."""
    gemini_home = pathlib.Path(
        os.environ.get("TAP_GEMINI_HOME") or os.environ.get("GEMINI_HOME", "~/.gemini")
    ).expanduser()
    conversations = gemini_home / "antigravity-cli" / "conversations"
    try:
        dbs = [p for p in conversations.glob("*.db") if p.is_file()]
    except OSError:
        return []
    dbs.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    return [p.stem for p in dbs]


def adopted_seat_missing_identity_error(record_name: str, tag: str, harness: str) -> LauncherError:
    """Refuse to resume an ADOPTED seat that has no verified conversation id
    (tap-8qj7 P2, fable-upgraded to REQUIRED). Falling to `--continue` here would
    bind whatever the LATEST conversation is — possibly a different one — after which
    registration stamps THAT id into the trust=env tier-1 field, drifting a guessed
    identity into exactly the field r1 protects. Launcher-born seats keep --continue
    (their conversations are launcher-managed); an adopted seat must be resumed with an
    explicit verified id. Fail-closed costs one manual command.
    """
    # Carry the load-bearing yolo flag into the guidance (grok #xxx residual): an
    # operator who copies this line must not recreate the permission-prompt hang the
    # launch path avoids. agy is the harness with that flag; other latest-binding
    # harnesses keep their own bare resume form.
    resume_cmd = (
        f"{harness} --dangerously-skip-permissions --conversation <uuid>" if harness == "agy"
        else f"{harness} --conversation <uuid>"
    )
    lines = [
        f"refusing to resume adopted seat {tag!r} without a verified conversation id: "
        f"--continue could bind a different {harness} conversation and drift a wrong id into "
        f"the trust=env registry field (r1). Resume it with an explicit id instead:",
        f"  tmux new-session -s {shlex.quote(record_name)} {shlex.quote(resume_cmd)}",
    ]
    if harness == "agy":
        candidates = agy_conversation_candidates()
        if candidates:
            shown = candidates[:8]
            lines.append("candidate conversations (newest first):")
            lines.extend(f"    {cid}" for cid in shown)
            if len(candidates) > len(shown):
                lines.append(f"    … {len(candidates) - len(shown)} more")
    return LauncherError("\n".join(lines))


def backfill_codex_session_id(
    record: SessionRecord,
    sessions_root: pathlib.Path | None = None,
    started_after: str | None = None,
) -> SessionRecord:
    if record.harness != "codex" or record.harness_session_id:
        return record
    session_id = find_codex_session_id_for_cwd(record.cwd, sessions_root=sessions_root, started_after=started_after)
    if not session_id:
        return record
    return dataclasses.replace(record, harness_session_id=session_id)


def backfill_claude_session_id(
    record: SessionRecord,
    projects_root: pathlib.Path | None = None,
    started_after: str | None = None,
) -> SessionRecord:
    if record.harness != "claude" or record.harness_session_id:
        return record
    session_id = find_claude_session_id_for_cwd(record.cwd, projects_root=projects_root, started_after=started_after)
    if not session_id:
        return record
    return dataclasses.replace(record, harness_session_id=session_id)


def backfill_opencode_session_id(
    record: SessionRecord,
    started_after: str | None = None,
    sessions: list | None = None,
) -> SessionRecord:
    if record.harness != "opencode" or record.harness_session_id:
        return record
    session_id = find_opencode_session_id_for_cwd(record.cwd, started_after=started_after, sessions=sessions)
    if not session_id:
        return record
    return dataclasses.replace(record, harness_session_id=session_id)


# NOTE: the per-record `backfill_session_id` dispatcher was removed in the #xxx
# F2 fix. Per-record resolution is cohort-BLIND — it hands a singleton
# conversation to whichever empty co-cwd sibling scans first (grok+sol
# reproduced the poison on the resume path). Every write-moment now routes
# through `cohort_backfill_id` / `compute_backfill_ids`, which resolve ownership
# against the full same-cwd+harness cohort. The per-harness `find_*`/`backfill_*`
# finders survive only as unit-tested single-candidate primitives.


def same_session_record(left: SessionRecord, right: SessionRecord) -> bool:
    return (
        left.harness == right.harness
        and left.name == right.name
        and pathlib.Path(left.cwd).resolve() == pathlib.Path(right.cwd).resolve()
    )


def duplicate_harness_session_owner(
    records: list[SessionRecord],
    target: SessionRecord,
    harness_session_id: str | None = None,
) -> SessionRecord | None:
    native_id = harness_session_id or target.harness_session_id
    if not native_id:
        return None
    return next(
        (
            record
            for record in records
            if record.harness == target.harness
            and record.harness_session_id == native_id
            and not same_session_record(record, target)
        ),
        None,
    )


def duplicate_registry_session_owner(target: SessionRecord) -> str | None:
    if not target.harness_session_id:
        return None
    target_root = root_for_cwd(target.cwd)
    target_handle = session_handle(target)
    registries: list[tuple[str, pathlib.Path]] = []
    try:
        local_registry = tap_registry_path(target_root)
    except RegistryAuthorityError:
        local_registry = None
    if local_registry is not None:
        registries.append((target.base, pathlib.Path(local_registry)))

    index_home = pathlib.Path(os.environ.get("TAP_INDEX_HOME") or "~/.tap").expanduser()
    try:
        with (index_home / "teams.json").open() as index_file:
            teams = json.load(index_file).get("teams", {})
    except (OSError, ValueError, AttributeError):
        teams = {}
    if isinstance(teams, dict):
        for team, indexed in teams.items():
            if not isinstance(team, str) or not isinstance(indexed, dict):
                continue
            root = indexed.get("root")
            if not isinstance(root, str):
                continue
            try:
                registry = tap_registry_path(root)
            except RegistryAuthorityError:
                registry = None
            if registry is not None:
                registries.append((team, pathlib.Path(registry)))

    seen: set[pathlib.Path] = set()
    for fallback_team, registry in registries:
        resolved_registry = registry.resolve()
        if resolved_registry in seen:
            continue
        seen.add(resolved_registry)
        try:
            with registry.open() as registry_file:
                payload = json.load(registry_file)
        except (OSError, ValueError):
            continue
        if not isinstance(payload, dict):
            continue
        team_data = payload.get("team")
        team = team_data.get("name") if isinstance(team_data, dict) else None
        team = team or fallback_team
        agents = registry_v20._seat_map(payload)
        if not agents:
            continue
        # bus: <root>/.tap/bus/registry.json → parents[2]
        # acting: <root>/.tap/team-registry.json → parents[1] (shallower)
        if registry.name == "team-registry.json":
            registry_root = str(registry.parents[1])
        else:
            registry_root = str(registry.parents[2])
        for handle, entry in agents.items():
            if not isinstance(handle, str) or not isinstance(entry, dict):
                continue
            if entry.get("harness") != target.harness:
                continue
            if entry.get("harness_session_id") != target.harness_session_id:
                continue
            if pathlib.Path(registry_root).resolve() == pathlib.Path(target_root).resolve() and handle == target_handle:
                continue
            return f"{team}/{handle}"
    return None


def assert_unique_harness_session_identity(
    records: list[SessionRecord],
    target: SessionRecord,
    action: str,
) -> None:
    owner = duplicate_harness_session_owner(records, target)
    if owner is not None:
        owner_name = session_handle(owner)
    else:
        owner_name = duplicate_registry_session_owner(target)
    if owner_name is None:
        return
    raise LauncherError(
        f"{action}: refusing resume for expected seat {session_handle(target)}: "
        f"native {target.harness} session id {target.harness_session_id} already belongs to "
        f"expected seat {owner_name}"
    )


def resolved_resume_identity(
    record: SessionRecord, *, emit_receipts: bool = False
) -> str | None:
    """The conversation id a resume launch will ACTUALLY target, or None.

    ONE decision with two readers: `build_harness_invocation`'s resume arms call
    it to choose what to put in argv, and `tap session relaunch`'s semantic gate
    calls it to decide whether there is anything to resume. That is the whole
    point — the gate and the launch cannot disagree about the answer when there is
    only one place the answer is computed.

    The obvious cheaper check, "is the stored id somewhere in the built argv", is
    neither sound nor complete and was rejected after review. Unsound: `-m` text
    that happens to equal a ghost id makes the membership test pass while claude
    has silently resolved to its picker. Incomplete: claude may legitimately
    resume from `transcript_path` or a quarantined id rather than
    `record.harness_session_id`, which the membership test would read as no
    identity at all.

    `emit_receipts` belongs to the builder's call only; the gate must not print a
    second set of resume-target receipts for one launch.
    """
    if record.harness == "claude":
        # claude never exact-targets an unverified id (tap-gc1n): a ghost hsid
        # exits the CLI immediately, so it falls toward durable evidence and may
        # land on the picker. Only its own resolver knows which happened.
        target = resolve_resume_target(record)
        if emit_receipts:
            _emit_resume_target_receipts(record, target)
        return target.session_id or None
    return record.harness_session_id or None


_UNBOUND_RESUME_IDENTITY = object()


def permission_argv(harness: str, record: SessionRecord) -> list[str]:
    mode = presets.resolve_harness_env(harness).permissions
    record.permissions = mode
    if harness == "claude":
        return ["--permission-mode", "auto"] if mode == "auto" else ["--dangerously-skip-permissions"]
    return ["--approve-for-me"] if mode == "auto" else ["--dangerously-bypass-approvals-and-sandbox"]


def enforce_permissions(harness: str, mode: str, args: list[str]) -> None:
    """Check each source before composition can hide a conflicting option."""
    if mode != "auto" or harness not in ("claude", "codex"):
        return
    for index, token in enumerate(args):
        if token == "--":
            break
        key, separator, inline = token.partition("=")
        value = inline if separator else (args[index + 1] if index + 1 < len(args) else "")
        if harness == "codex" and re.match(r"^-[csa].+", token):
            key, value = token[:2], token[2:].removeprefix("=")
        bypass = key in ("--dangerously-skip-permissions", "--dangerously-bypass-approvals-and-sandbox", "--yolo")
        if harness == "claude":
            conflict = key == "--permission-mode" and value != "auto"
        else:
            conflict = ((key in ("--sandbox", "-s") and value != "workspace-write")
                        or key in ("--ask-for-approval", "-a")
                        or (key in ("--config", "-c") and re.match(r"^[\"']?(?:sandbox_mode|approval_policy)[\"']?\s*=", value.strip())))
        if bypass or conflict:
            raise LauncherError(f'harness_permissions_conflict: {key} contradicts [harness.{harness}] permissions = "auto"')


def build_harness_invocation(
    action: str,
    record: SessionRecord,
    initial_prompt: str | None = None,
    resume_identity: object = _UNBOUND_RESUME_IDENTITY,
) -> Invocation:
    # Builds argv and records its permission choice. Environment is composed in apply_launch_env from the
    # operator's config and the record — this function originates none of it.
    #
    # tap-eb9h: `initial_prompt` carries the first instruction as ARGV, which is what
    # lets `tap clear` restart a seat without simulating a single keystroke — no input dance,
    # no submit-verify wake, no race against a harness that is still booting. The
    # per-harness spelling is NOT uniform and the differences are load-bearing; each
    # row documents its own. A harness with no verified interactive-prompt argv
    # must not invent one (opencode: the positional is a project directory;
    # tap-0jtk delivers -m over the bus after rebind).
    #
    # Splice safety: inject_passthrough puts the seat's persisted flags right after
    # argv[0], deliberately ahead of any trailing positional, so a prompt appended
    # here stays the last word. Do not move it.
    # ONE RESOLUTION, BOUND BY THE CALLER WHEN THE CALLER ALREADY MADE THE DECISION.
    # `resolved_resume_identity` reads mutable on-disk transcript state, so calling
    # it here AND at a caller's gate is two decisions wearing one function's name:
    # with the disk changing between them, the gate can see an identity while argv
    # is built id-less, replacing the seat with a picker invocation — the exact
    # degradation the gate exists to refuse, through a narrower window (review
    # round 3, sol-tidying-sponsor). A caller that must decide first therefore
    # passes its resolved value in, and this builder consumes it verbatim.
    if resume_identity is _UNBOUND_RESUME_IDENTITY:
        resumed = (
            resolved_resume_identity(record, emit_receipts=True)
            if action == "resume"
            else None
        )
    else:
        resumed = resume_identity

    env: dict[str, str] = {}
    if record.harness == "claude":
        argv = ["claude", *permission_argv("claude", record)]
        argv.extend(presets.model_argv(record.harness, record.model))
        if record.name:
            argv.extend(["--name", record.name])
        if action == "new":
            if record.harness_session_id:
                argv.extend(["--session-id", record.harness_session_id])
        else:
            # tap-gc1n: never exact-target an unverified id (ghost hsid exits
            # the claude CLI immediately). Fall toward durable evidence.
            argv.extend(["--resume"])
            if resumed:
                argv.append(resumed)
        # `claude [options] [command] [prompt]` — measured 2026-08-14.
        if initial_prompt:
            argv.append(initial_prompt)
        return Invocation(argv, env)

    if record.harness == "codex":
        # PONYTAIL_DEFAULT_MODE is no longer decided here (tap-ey7n's fix, superseded by
        # PR #xxx's tier model). It belongs in `[harness.codex.env]` in the operator's
        # config, stated once, overridable per preset. Absent config means the plugin's
        # own default applies — louder, not quieter. Note ABSENT config is deliberately
        # silent (a machine with no config is a legitimate state); it is a config that
        # fails to parse, cannot be read, or is insecure that warns.
        argv = ["codex", *permission_argv("codex", record)]
        if action == "resume":
            argv.append("resume")
        argv.extend(presets.model_argv(record.harness, record.model))
        if action == "resume" and resumed:
            argv.append(resumed)
        # `codex [OPTIONS] [PROMPT]` — measured 2026-08-14. Bare `codex`, not the
        # `exec` subcommand: exec is the non-interactive rail and would exit.
        if initial_prompt:
            argv.append(initial_prompt)
        return Invocation(argv, env)

    if record.harness == "opencode":
        argv = ["opencode"]
        argv.extend(presets.model_argv(record.harness, record.model))
        if record.harness_session_id:
            argv.extend(["--session", record.harness_session_id])
        # tap-0jtk: opencode has no interactive initial-prompt argv. Measured
        # 2026-08-14: the interactive form is `opencode [project]` and that
        # positional is a PROJECT DIRECTORY, not a prompt — putting the
        # instruction there would silently open a wrong-cwd session. The
        # prompt-taking form, `opencode run [message..]`, is non-interactive
        # and exits, which on a seat pane leaves an empty pane. So a prompt
        # never raises and never rides argv. `tap clear -m` delivers it over
        # the bus after rebind (see deliver_clear_instruction_via_send).
        return Invocation(argv, env)

    if record.harness == "cursor":
        argv = ["cursor-agent", "--force", "--sandbox", "disabled", "--workspace", record.cwd]
        # A SELECTED workspace is a trusted one, or the seat stalls on Cursor's
        # trust dialog before it ever reads a prompt (tap-nxvht addendum). The
        # addendum authorized this and only the Bun port ever carried it, so for
        # four weeks the two builders launched cursor differently and the
        # differential that should have said so compared the port against a
        # fixture the port had written. tap-j86wd, leader's ruling (a): the
        # incumbent gets the flag, and the seats launching TODAY get the fix.
        #
        # Guarded on cwd rather than emitted unconditionally, because `--trust`
        # names the workspace that was selected: with no selected path there is
        # nothing to vouch for, and the flag would be asserting trust in whatever
        # directory cursor-agent picks for itself.
        if record.cwd:
            argv.append("--trust")
        argv.extend(presets.model_argv(record.harness, record.model))
        # ID FIRST, WHATEVER THE ACTION (tap-rs1q; tap-xsgi twin; (b) with
        # opus-2). `--resume` used to be gated on action == "resume", so
        # launch and clear (both action "new") reserved a create-chat UUID
        # and never handed it to the process. cursor-agent invented its own
        # chat; identity capture could only quarantine. tap-e9v8's mint
        # docstring already claimed `--resume <id>` materializes the
        # reservation — true of the CLI, false of this builder.
        #
        # (a) would have keyed emission on mint-freshness so a stored id on
        # new stayed inert. That arm encodes the drop this lane closes: a
        # new-path id that forgets a freshness marker is reserved-and-dropped
        # again. Stale-id silent-new-chat is already reachable on resume
        # (tap-we6b); the new-gate never protected it. Safety is the source
        # invariant (inherited_id is resume-only; clear wipes before mint)
        # plus refuse_preexisting_id_on_new_mint at the mint gate.
        #
        # Measured 2026-08-15 (cursor-agent 2026.08.11-e8db854): create-chat
        # UUID + `--resume <id>` on a new `--print` process reports that same
        # session_id and writes meta.json under it; without `--resume` the
        # process invents a different id. `--resume [chatId]` is one flag.
        # Bare `--resume` stays resume-only (the picker).
        if record.harness_session_id:
            argv.extend(["--resume", record.harness_session_id])
        elif action == "resume":
            argv.append("--resume")
        # `agent [options] [command] [prompt...]` — "Initial prompt for the agent",
        # measured 2026-08-14.
        if initial_prompt:
            argv.append(initial_prompt)
        return Invocation(argv, env)

    if record.harness == "agy":
        # Antigravity/Gemini (tap-8qj7). --dangerously-skip-permissions is LOAD-BEARING,
        # not a convenience: a launched agy seat WITHOUT it stalls on its first
        # non-persisted tool permission prompt — the dialog consumes the input band and
        # is invisible to push delivery (tap-luae field finding). Model/effort flags come
        # from TUNING_CAPABILITIES (tap-ppo7); an unknown model key still stalls at
        # runtime (cli.log "unknown model key") because the legal set is not static.
        # Resume: agy --conversation <uuid> (verified id), else --continue for the latest
        # conversation (the id-less fallback). agy runs as the pane command like every
        # harness; its clean /exit ends the pane, and the resume rung recreates the
        # conversation — the same lifecycle Ops's manual recovery used, which doubles as
        # agy's skills-refresh (no live reload).
        argv = ["agy", "--dangerously-skip-permissions"]
        argv.extend(presets.model_argv(record.harness, record.model))
        if action == "resume":
            if record.harness_session_id:
                argv.extend(["--conversation", record.harness_session_id])
            else:
                argv.append("--continue")
        # agy takes NO positional prompt, and the obvious flag is a TRAP: `--prompt`
        # (and its `-p` short form) is an ALIAS FOR --print — it runs one prompt
        # NON-interactively and exits. On a seat pane that turns `tap clear` into
        # "stop the seat", which is the opposite of a restart and would read as a
        # hung harness. `--prompt-interactive` / `-i` is the correct spelling:
        # "Run an initial prompt interactively and continue the session".
        # Measured 2026-08-14 (`agy --help`). Pinned by the argv unit tests — the
        # comment explains, the test refuses.
        if initial_prompt:
            argv.extend(["--prompt-interactive", initial_prompt])
        return Invocation(argv, env)

    if record.harness == "hermes":
        # No initial_prompt row by DECISION, not omission (tap-eb9h): hermes is
        # goalie infrastructure, not a conversational seat, so there is nothing for
        # `tap clear` to carry into it. Ruled out of scope 2026-08-14.
        argv = [HERMES_BIN, *presets.model_argv(record.harness, record.model)]
        return Invocation(argv, env)

    raise LauncherError(f"unknown harness: {record.harness}")


def build_native_resume_invocation(record: SessionRecord, native_query: str | None) -> Invocation:
    # argv and permission choice; see build_harness_invocation. Environment composition lives in
    # apply_launch_env, which both rails pass through.
    env: dict[str, str] = {}
    if record.harness == "claude":
        argv = ["claude", *permission_argv("claude", record)]
        argv.extend(presets.model_argv(record.harness, record.model))
        if record.name:
            argv.extend(["--name", record.name])
        argv.append("--resume")
        # Explicit native query wins only when its transcript exists; otherwise
        # fall through the same verified chain as build_harness_invocation.
        if native_query and claude_session_transcript_exists(native_query):
            argv.append(native_query)
        else:
            target = resolve_resume_target(record)
            _emit_resume_target_receipts(record, target)
            if target.session_id:
                argv.append(target.session_id)
        return Invocation(argv, env)

    if record.harness == "codex":
        # No ponytail decision here either — see build_harness_invocation.
        argv = ["codex", *permission_argv("codex", record), "resume"]
        argv.extend(presets.model_argv(record.harness, record.model))
        if native_query:
            argv.append(native_query)
        return Invocation(argv, env)

    if record.harness == "agy":
        # A native resume query (tap session resume agy <uuid>) is the conversation
        # id; prefer it, else the stored id, else --continue for the latest (tap-8qj7).
        argv = ["agy", "--dangerously-skip-permissions"]
        argv.extend(presets.model_argv(record.harness, record.model))
        conversation = native_query or record.harness_session_id
        if conversation:
            argv.extend(["--conversation", conversation])
        else:
            argv.append("--continue")
        return Invocation(argv, env)

    return build_harness_invocation("resume", record)


def apply_launch_env(
    invocation: Invocation, record: SessionRecord, *, notify: bool = True
) -> Invocation:
    """Compose the launch environment from its tiers. Later tiers win.

      1. code QoL defaults (claude cosmetics only — the sole env the launcher originates,
         and deliberately still parent-honoring: they carry no audit weight)
      2. `[harness.<name>.env]` from the operator config, read fresh every launch AND every
         resume. Reading rather than replaying is what makes this migration-free: a seat
         created before the policy existed picks it up on its next resume.
      3. `record.harness_env` — what the operator chose for THIS seat (preset or --env). Seat
         intent outranks machine policy.

    The invocation builders used to emit a third tier between 2 and 3 (agent-teams and ponytail
    values decided in code). They are gone: the launcher originates nothing but the tier-1
    cosmetics, and the merge below did not need editing when they went — the tier beneath simply
    became visible, which is what the ordering was designed for.

    Tier 2 is never written back into the record: policy belongs to the machine, the record
    stays portable.

    A DECLARED value always beats the launching shell (panel ruling, 2026-08-11). The shell used
    to win, which meant the same preset produced different seats from different terminals with
    nothing said. The collision is now announced instead, ONCE per key, here rather than in each
    tier's resolver: a key declared in both the harness table and the record must name the value
    that actually won, and a per-source warning would announce a value that lost — or, for the
    tier that resolves first, announce a collision the next tier then overrode.

    "Once" is a claim about the COMMAND, not about this function, and this function alone cannot
    keep it: `restart` builds the invocation twice (a discarded pre-flight, then the real one),
    which printed the identical warning twice until the pre-flight started suppressing it. This
    function's own `notify` covers everything it emits, so the name is accurate HERE; the caller
    spells it `notify_env_policy` because there the same flag governs only part of the output.
    Any future caller that builds to validate and discards owes the same.
    """
    env: dict[str, str] = {}
    if record.harness == "claude":
        env.setdefault("CLAUDE_CODE_TMUX_TRUECOLOR", os.environ.get("CLAUDE_CODE_TMUX_TRUECOLOR", "1"))
        env.setdefault("CLAUDE_CODE_SCROLL_SPEED", os.environ.get("CLAUDE_CODE_SCROLL_SPEED", "6"))
    harness_tier = presets.resolve_harness_env(record.harness)
    if notify:
        for notice in harness_tier.notices:
            presets.emit_notice(notice)
    declared: dict[str, str] = {}
    declared.update(harness_tier.env)
    declared.update(invocation.env)
    declared.update(record.harness_env)
    for key in sorted(declared) if notify else ():
        ambient = os.environ.get(key)
        if ambient is not None and ambient != declared[key]:
            # NEITHER value is echoed — not the ambient one, and (since Ops's follow-up ruling)
            # not the declared one either. The first wording printed the declared value, and
            # sol's finding was that the key fence cannot make that safe: the fence is
            # name-based and deliberately permits plural forms, so `HF_TOKENS` clears it and
            # would print a credential into pane transcripts, logs, and anything pasted out of
            # them. The key alone carries the actionable fact — your shell lost, here is which
            # variable — and the winning value is readable from the preset that declared it.
            #
            # Ruling relayed by fable-starters-boss from direct observation of Ops's
            # unsubmitted pane input (2026-08-12 ~13:10Z): "keep the key, drop the value".
            presets.emit_notice(
                f"tap session: overriding ambient ENV var {key} with the declared value"
            )
    env.update(declared)
    for key in record.harness_unset_env:
        env.pop(key, None)
    return Invocation(invocation.argv, env, list(record.harness_unset_env))


def inject_passthrough(invocation: Invocation, record: SessionRecord) -> Invocation:
    # tap-9zwt + tap-2z5r: splice the seat's persisted harness passthrough (see
    # SessionRecord.harness_passthrough) right after the harness binary, so the
    # forwarded flags act as harness-GLOBAL options — ahead of tap's own generated
    # flags, any subcommand (codex `resume`), and any trailing positional (the resume
    # id). This list is NOT config-only: it is the operator-typed pnpm-style tail
    # OR the preset's params tokens, with unrelated Codex config keys composed
    # into an explicit tail. Config-sourced tokens take the builder floor
    # (can only ADD); operator-typed tokens insert unconditionally, even when the
    # builder already emits the same flag. Applied only via compose_child_invocation.
    if not record.harness_passthrough or not invocation.argv:
        return invocation
    argv = presets.splice_tokens_if_absent(
        invocation.argv,
        record.harness_passthrough,
        floor=record.passthrough_from_config,
        config_keys=record.harness == "codex",
    )
    return Invocation(argv, invocation.env, invocation.unset_env)


def pin_opencode_session(argv: list[str], session_id: str | None) -> list[str]:
    """Strip external adoption flags, then append the record-owned exact id."""
    clean: list[str] = []
    index = 0
    while index < len(argv):
        token = argv[index]
        option = token.split("=", 1)[0]
        if option in {"--session", "-s"}:
            index += 1
            if "=" not in token and index < len(argv) and not argv[index].startswith("-"):
                index += 1
            continue
        if option in {"--continue", "-c"}:
            index += 1
            continue
        clean.append(token)
        index += 1
    if session_id:
        clean.extend(["--session", session_id])
    return clean


def compose_child_invocation(
    invocation: Invocation,
    record: SessionRecord,
    *,
    notify_env_policy: bool = True,
) -> Invocation:
    """One emission site: env, passthrough, then harness-table params.

    Operator-typed passthrough inserts unconditionally. Config-sourced
    passthrough and harness-table params take the builder floor. Launch,
    restart, dry-run, and native/adopted resume all pass through here so a
    cursor seat that launched with ``--yolo`` still has it on resume, including
    adopted rows whose passthrough is empty by construction.
    """
    invocation = inject_passthrough(
        apply_launch_env(invocation, record, notify=notify_env_policy),
        record,
    )
    harness_tier = presets.resolve_harness_env(record.harness)
    if record.permissions is None:
        record.permissions = harness_tier.permissions if record.harness in ("claude", "codex") else "bypass"
    for source in (record.harness_passthrough or [], presets.params_to_argv(harness_tier.params), invocation.argv[1:]):
        enforce_permissions(record.harness, record.permissions, source)
    argv = presets.splice_verbatim_params(
        invocation.argv, harness_tier.params, config_keys=record.harness == "codex"
    )
    enforce_permissions(record.harness, record.permissions, record.harness_tail)
    argv.extend(record.harness_tail)
    if record.harness == "opencode":
        # Persisted rows and live harness params compose after the base builder.
        # Strip their adoption flags, then restore only the record-owned id.
        argv = pin_opencode_session(argv, record.harness_session_id)
    return Invocation(
        argv,
        invocation.env,
        invocation.unset_env,
    )


def launch_invocation(
    action: str,
    record: SessionRecord,
    *,
    notify_env_policy: bool = True,
    initial_prompt: str | None = None,
    resume_identity: object = _UNBOUND_RESUME_IDENTITY,
) -> Invocation:
    """Build the full invocation.

    ``notify_env_policy=False`` suppresses exactly two things: the degraded-config notices from
    the harness environment tier, and the ambient-collision warnings. It is NOT general silence,
    and the name says so because the shorter one did not: `build_harness_invocation` runs first
    and emits claude's resume-target receipts before this flag is ever consulted, so a pre-flight
    build still prints those twice (sol's probe: picker_receipt_count=2 on restart). That
    duplication predates this parameter and is tracked on tap-2qrt for both cmd_new and restart.

    A pre-flight caller builds purely to fail fast, discards the result, and the real build
    happens later — so the env-policy lines it would print are all duplicates. Suppressing them
    there is what keeps "once per collision" a property of the COMMAND rather than of how many
    times the launcher happens to rebuild an invocation internally.

    Deliberately not solved by reusing the pre-flight's Invocation: on the real restart arm the
    launch transaction mutates the record between the two builds, so a reused object would be
    stale in a way no test would notice until it was wrong.
    """
    return compose_child_invocation(
        build_harness_invocation(action, record, initial_prompt, resume_identity),
        record,
        notify_env_policy=notify_env_policy,
    )


def tmux_sessions() -> set[str]:
    result = tmux_list_sessions_result()
    if result is not None and result.returncode == 0:
        return {line for line in result.stdout.splitlines() if line}
    stderr = result.stderr.strip() if result is not None else ""
    if re.fullmatch(
        r"(?:no server running on .+|error connecting to .+ \(No such file or directory\))",
        stderr,
    ):
        raise TmuxNoServerError(
            "tmux server is not running; the session namespace is empty"
        )
    raise LauncherError(
        "tmux session-name snapshot is unobservable; refusing to treat the "
        "session namespace as empty"
    )


def tmux_sessions_for_namespace() -> set[str]:
    """Observe the namespace for an operation that acts on session names.

    Tmux sessions are children of the tmux server process. A recognized
    no-server response is therefore positive proof of an empty namespace, not
    an unobservable snapshot. Every other observation failure stays fail-closed.
    """
    try:
        return tmux_sessions()
    except TmuxNoServerError:
        return set()


def tmux_list_sessions_result() -> subprocess.CompletedProcess[str] | None:
    try:
        return verbose.run(
            ["tmux", "list-sessions", "-F", "#S"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
    except FileNotFoundError:
        return None


def tmux_sessions_or_none() -> set[str] | None:
    result = tmux_list_sessions_result()
    if result is None or result.returncode != 0:
        return None
    return {line for line in result.stdout.splitlines() if line}


def tmux_sessions_under(root: str) -> set[str]:
    try:
        result = verbose.run(
            ["tmux", "list-panes", "-a", "-F", "#{session_name}\t#{pane_current_path}"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return set()
    if result.returncode != 0:
        return set()

    names = set()
    for line in result.stdout.splitlines():
        name, _, pane_path = line.partition("\t")
        if name and pane_path and path_is_under(pane_path, root):
            names.add(name)
    return names


def tmux_has(name: str) -> bool:
    return verbose.run(["tmux", "has-session", "-t", f"={name}"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0


def tmux_session_pane_ids(name: str) -> list[str]:
    """Pane ids currently members of the named session (name-first re-derive)."""
    try:
        result = verbose.run(
            ["tmux", "list-panes", "-t", f"={name}", "-F", "#{pane_id}"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return []
    if result.returncode != 0:
        return []
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def tmux_session_created_label(name: str) -> str | None:
    """Local clock time for a live tmux session's creation (display only).

    Ops refinement #2 (tap-9tqt): off-roster collisions must cite a tmux-level
    fact (`created HH:MM`), never registry-ghost wording. Returns None when the
    session is gone or tmux cannot report `#{session_created}`.
    """
    try:
        result = verbose.run(
            ["tmux", "display-message", "-p", "-t", f"={name}", "#{session_created}"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    raw = result.stdout.strip()
    if not raw.isdigit():
        return None
    try:
        created = datetime.datetime.fromtimestamp(int(raw))
    except (OverflowError, OSError, ValueError):
        return None
    return created.strftime("%H:%M")


# Typed refusal signal (tap-rxqb, Lane D D2): tmux_attach reports its refusal
# as a sentinel rc the tail branches on directly — never by classifying tmux's
# error text, and never conflated with a genuine attach-session failure. tmux
# attach-session exits 0 or 1; 2 is the launcher's own vocabulary and cannot
# collide with a tmux outcome.
ATTACH_REFUSED_IN_TMUX = 2
# Second typed refusal (tap-v0bg): we could not establish WHETHER the caller is
# inside a pane. Distinct from ATTACH_REFUSED_IN_TMUX because the two states are
# different facts and a reader who sees the in-tmux receipt for an unobservable
# probe learns something false. 3 is likewise outside attach-session's 0/1.
ATTACH_REFUSED_AMBIGUOUS = 3
ATTACH_REFUSED_TTY_OWNERSHIP = 4

IN_TMUX_NO = "no"
IN_TMUX_YES = "yes"
IN_TMUX_AMBIGUOUS = "ambiguous"


def tmux_pane_tty(target: str) -> str | None:
    """The tty of one pane, or `None` when tmux or its answer is unobservable.

    Deliberately shaped like `tmux_pane_raw_id`: a failed probe is `None`, never
    an empty string that a caller could read as "no tty".
    """
    try:
        result = verbose.run(
            ["tmux", "display-message", "-p", "-t", target, "#{pane_tty}"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    lines = result.stdout.splitlines()
    if len(lines) != 1 or not lines[0].strip():
        return None
    return lines[0].strip()


def tmux_server_is_gone(raw_tmux: str) -> bool:
    """Is the server named by `$TMUX` POSITIVELY gone? (tap-v0bg)

    `$TMUX` is `<socket>,<server-pid>,<session-id>`. Only a positive absence
    returns True — an unparseable value, an unreadable pid, or a process we may
    not signal all return False and leave the decision to the tty comparison,
    because the asymmetry that keeps this safe is that ambiguity must never
    unlock attaching.
    """
    parts = raw_tmux.split(",")
    if len(parts) < 2 or not parts[1].strip().isdigit():
        return False
    try:
        os.kill(int(parts[1].strip()), 0)
    except ProcessLookupError:
        return True
    except (PermissionError, OSError, OverflowError, ValueError):
        return False
    return False


def caller_in_tmux() -> str:
    """Is THIS process really inside a tmux pane? (tap-v0bg)

    `$TMUX` is inherited environment, not an observation. Every child of any
    process that once lived in a pane carries it — a Cursor window launched from
    a pane hands it to every integrated terminal it opens — and the inherited
    value stays syntactically valid and points at a live server, so a presence
    check and a does-it-parse check both pass. Ops hit exactly that: a terminal
    that was NOT in tmux was classified an in-tmux caller and silently handed a
    detached session instead of the attach it asked for.

    The discriminator is TTY IDENTITY, not variable presence. Genuinely inside a
    pane, this process's controlling tty IS that pane's `pane_tty`; inherited,
    they differ. That is a POSITIVE observation in both directions, which is what
    lets the NO arm be safe: we attach only when we have positively observed that
    our terminal is not the pane's, never merely because a probe came back empty.

    Polarity is deliberately asymmetric, same direction as tap-fuz9: refusing
    wrongly prints a command the human can run, while attaching wrongly nests a
    client (the musical-chairs class). So every unresolved case is AMBIGUOUS and
    refuses — no tty at all (an agent's tool call), an unset or unresolvable
    `$TMUX_PANE`, an unparseable server identity, a tmux we cannot reach.
    """
    raw = os.environ.get("TMUX", "")
    if not raw:
        return IN_TMUX_NO
    if tmux_server_is_gone(raw):
        # The server that MINTED this variable no longer exists, so the caller
        # cannot be inside one of its panes whatever else is true. Socket-path
        # existence is not liveness — this machine's /private/tmp/tmux-502/ holds
        # many stale sockets — so the liveness authority is the pid embedded in
        # $TMUX, checked as a process rather than by classifying tmux's error
        # text (the fragility tap-rxqb spent a day removing).
        return IN_TMUX_NO
    tty = caller_tty()
    if not tty:
        # No controlling terminal: attach could not work anyway, and this must
        # never read as "not in tmux" and unlock the attach arm.
        return IN_TMUX_AMBIGUOUS
    pane = os.environ.get("TMUX_PANE", "")
    if not pane:
        return IN_TMUX_AMBIGUOUS
    pane_tty = tmux_pane_tty(pane)
    if pane_tty is None:
        return IN_TMUX_AMBIGUOUS
    return IN_TMUX_YES if pane_tty == tty else IN_TMUX_NO


def caller_owns_foreground_tty() -> bool:
    """A viewer may attach only while its process group owns both terminal streams."""
    for stream in (sys.stdin, sys.stdout):
        try:
            if os.tcgetpgrp(stream.fileno()) != os.getpgrp():
                return False
        except (AttributeError, OSError, ValueError):
            return False
    return True


def tmux_attach(name: str) -> int:
    """Attach the CALLER's own terminal, or do nothing at all (tap-fuz9).

    panel ruling, after the musical-chairs incident: the launcher does not switch
    clients from inside tmux — it refuses. The reasoning is that the branch never
    paid for itself. `attach-session` binds to the calling terminal and is
    therefore structurally incapable of moving anyone else's; `switch-client`
    acts on a CLIENT, and with no `-c` tmux picks one for you. That pick moved a
    live operator terminal off tap/fable onto ExpireExampleTasks/fable while this
    bug was being investigated.

    Who was actually in the switch branch: a human at a plain terminal never
    (no $TMUX); an agent's tool call never reaches attach at all (no tty, so
    resolve_attach_mode sends it detached); which leaves a human already inside
    tmux, who has tmux's own switcher. One keystroke saved, against a defect that
    hijacks terminals.

    The two verbs fail in opposite directions, which is the whole argument:
    `attach-session` with nowhere to attach prints "open terminal failed" and
    does NOTHING, while `switch-client` with nothing named moves a terminal
    nobody asked about. When a tool cannot tell what to do, it should run the
    verb that does nothing.

    Refusing here is not fatal to the launch: attach is the TAIL of a launch,
    never its verdict, so the caller leaves the session created, registered and
    running, and prints the command to reach it.

    RC CONTRACT: 0 = attached; ATTACH_REFUSED_IN_TMUX = the caller is inside
    tmux; ATTACH_REFUSED_AMBIGUOUS = the caller's tmux state is unverified;
    ATTACH_REFUSED_TTY_OWNERSHIP = foreground tty ownership is not confirmed. These
    refusals are legitimate detached modes the tail narrates ONCE as a receipt,
    not failures. Any other nonzero is tmux attach-session's own exit code (a
    genuine failure). The refusal arms are deliberately silent here: the single
    narration lives in attach_after_launch, so this function cannot stack a
    failure-shaped warning under its caller's receipt (merged-A E4≡E1 finding).
    """
    target = f"={name}"
    state = caller_in_tmux()
    if state == IN_TMUX_YES:
        return ATTACH_REFUSED_IN_TMUX
    if state == IN_TMUX_AMBIGUOUS:
        return ATTACH_REFUSED_AMBIGUOUS
    if not caller_owns_foreground_tty():
        return ATTACH_REFUSED_TTY_OWNERSHIP
    raw_tmux = os.environ.get("TMUX", "")
    if not raw_tmux:
        return subprocess.call(["tmux", "attach-session", "-t", target])
    # Positively-inherited $TMUX (tap-v0bg). The strip is load-bearing, not
    # hygiene: tmux's OWN nesting guard also trusts bare $TMUX, so attaching
    # without it would trade a wrong receipt for a wrong "sessions should be
    # nested with care" error — the same caller still not attached, just failing
    # somewhere else. Only this branch strips, and only after observing that our
    # tty is not the pane's.
    socket_path = raw_tmux.partition(",")[0]
    if not socket_path:
        return ATTACH_REFUSED_AMBIGUOUS
    env = {k: v for k, v in os.environ.items() if k not in ("TMUX", "TMUX_PANE")}
    return subprocess.call(
        ["tmux", "-S", socket_path, "attach-session", "-t", target],
        env=env,
    )


def caller_tty() -> str:
    for stream in (sys.stderr, sys.stdout):
        try:
            return os.ttyname(stream.fileno())
        except (AttributeError, OSError, ValueError):
            continue
    return ""


def caller_has_tty() -> bool:
    """Can THIS caller host a tmux attach at all? (tap-ya2e)

    Decided up front on the deterministic isatty signal, never by classifying
    tmux's attach error afterwards — string classification is the exact
    fragility tap-rxqb spent a day eliminating, and a doomed attach against a
    terminal that isn't there is worth never running. Attach needs a terminal on
    both ends of the conversation, so both stdin and stdout must be one.
    """
    for stream in (sys.stdin, sys.stdout):
        try:
            if not stream.isatty():
                return False
        except (AttributeError, OSError, ValueError):
            return False
    return True


def resolve_attach_mode(args) -> bool:
    """Attach when a real TTY is present; --attach forces it anyway (tap-ya2e).

    INVARIANT: for an interactive human launch (isatty true) this returns True,
    so the human path is unchanged — only TTY-less callers (an agent's Bash
    tool, cron, a pipeline) take the detached path.
    """
    if getattr(args, "attach", False):
        return True
    return caller_has_tty()


def emit_detached_receipt(record: SessionRecord, reason: str) -> None:
    emit_receipt(
        "session",
        f"{record.name} is running detached ({reason}); next: tmux attach -t {record.name}",
    )


def attach_after_launch(record: SessionRecord) -> int:
    """Attach is the TAIL of a launch, never its verdict (tap-ya2e).

    The session is already created, respawned, harness-ready and registered by
    the time we get here. Attach can still fail for a caller-side reason (no
    controlling terminal, no client to switch), and conflating that with launch
    failure is what took down healthy, registered sessions seconds after birth.
    Leave it running with a receipt and report success.

    Narration contract (Lane D D2, one message per outcome, never a stack):
    refusal (in-tmux caller) → ONE detached receipt; genuine tmux failure → the
    warning pair. The two are told apart by tmux_attach's typed rc, never by
    classifying its output (tap-rxqb).
    """
    rc = tmux_attach(record.name)
    if rc == 0:
        return 0
    if rc == ATTACH_REFUSED_TTY_OWNERSHIP:
        emit_detached_receipt(record, "caller does not own foreground tty")
        return 0
    if rc == ATTACH_REFUSED_IN_TMUX:
        emit_detached_receipt(record, "in-tmux caller")
        return 0
    if rc == ATTACH_REFUSED_AMBIGUOUS:
        # A DIFFERENT fact from the in-tmux refusal, so it gets its own reason
        # (tap-v0bg): we could not establish where the caller is, and reporting
        # that as "in-tmux caller" is the very mislabeling this bead exists to
        # remove. It is also not the warning-pair arm below — nothing failed;
        # we declined to guess.
        emit_detached_receipt(record, "tmux caller state unverified")
        return 0
    emit_warning(
        "session",
        f"could not attach to {record.name} (tmux exit {rc}); the session is running and registered",
        f"tmux attach -t {record.name}",
    )
    emit_detached_receipt(record, "attach failed")
    return 0


def resume_attach_tail(record: SessionRecord) -> int:
    """Attach tail for the resume / relaunch / live-reattach paths (tap-ya2e, grok P1).

    Same rule as attach_after_launch: attach is the TAIL of a resume, never its
    verdict, on EVERY path. A TTY-less caller decides up front on isatty (never a
    doomed attach against a terminal that isn't there); a TTY caller whose attach
    still fails leaves the registered, running session alive with a receipt. Either
    way this returns 0 for a healthy registered session, so an attach-only miss can
    never bubble a nonzero rc into a caller's rollback_launch_transaction and orphan
    the seat — the exact defect on the adopted/native-resume path.
    """
    if caller_has_tty():
        return attach_after_launch(record)
    emit_detached_receipt(record, "no controlling terminal")
    return 0


def report_launch_failure(
    record: SessionRecord,
    launched_at: str,
    output_path: str,
    creation_identity=None,
) -> None:
    target = creation_identity[3] if creation_identity else f"={record.name}:0.0"
    result = verbose.run(
        ["tmux", "display-message", "-p", "-t", target, "#{pane_dead_status}"],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )
    try:
        status = int(result.stdout.strip()) if result.returncode == 0 else 1
    except ValueError:
        status = 1
    captured = verbose.run(
        ["tmux", "capture-pane", "-p", "-S", "-", "-t", target],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
    )
    lines = [line.rstrip() for line in captured.stdout.splitlines() if line.strip()][-20:]
    startup_trace.emit("seat_exit", session=record.name, harness=record.harness, exit_code=status or 1, launch_id=record.launch_id)
    message = "\n".join([f"launch failed: exit {status or 1}", *lines]) + "\n"
    try:
        rollback_pending_handle(
            record,
            record.launch_failure_reason or "session_replaced",
        )
    finally:
        if creation_identity:
            try:
                respawn_owned_command(creation_identity, ["kill-session", "-t", creation_identity[1]])
            except (LauncherError, OSError, subprocess.SubprocessError):
                pass  # A replacement is not this failed launch's property.
        else:
            verbose.run(
                ["tmux", "kill-session", "-t", f"={record.name}"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        written = False
        if output_path:
            try:
                pathlib.Path(output_path).write_text(message)
                written = True
            except OSError:
                pass
        if not written:
            sys.stderr.write(message)


def internal_launch_failure(argv: list[str], *, owned: bool = False) -> int:
    creation_identity = None
    if owned:
        creation_identity = parse_respawn_identity(argv[0]) if argv else None
        if creation_identity is None:
            raise LauncherError("invalid owned launch-failure identity")
        argv = argv[1:]
    if len(argv) != 3:
        print("tap session: invalid internal launch-failure invocation", file=sys.stderr)
        return 2
    launched_at, raw_record, output_path = argv
    try:
        record = SessionRecord.from_dict(json.loads(raw_record))
    except (KeyError, TypeError, ValueError):
        print("tap session: invalid internal launch-failure record", file=sys.stderr)
        return 2
    if creation_identity:
        report_launch_failure(record, launched_at, output_path, creation_identity)
    else:
        report_launch_failure(record, launched_at, output_path)
    return 0


# .70 decision table: docs/artifacts/2026-09-05-launcher-respawn-retry.md.
_RESPAWN_FORK_REFUSAL = "respawn pane failed: fork failed: Device not configured"
_RESPAWN_IDENTITY_FORMAT = "#{pid}:#{start_time}\t#{session_id}\t#{window_id}\t#{pane_id}\t#{pane_pid}"


class RespawnFailure(LauncherError):
    def __init__(self, detail, identity):
        super().__init__(detail)
        self.identity = identity


def respawn_identity(target):
    """Narrow observation: fork failure legitimately leaves pane_pid=-1."""
    try:
        result = verbose.run(["tmux", "display-message", "-p", "-t", target,
                              _RESPAWN_IDENTITY_FORMAT], capture_output=True, text=True, timeout=2)
    except (OSError, subprocess.SubprocessError):
        return None
    return parse_respawn_identity(result.stdout) if result.returncode == 0 else None


def parse_respawn_identity(raw):
    fields = raw.strip().split("\t")
    patterns = (r"[0-9]+:[0-9]+", r"\$[0-9]+", r"@[0-9]+", r"%[0-9]+", r"-?[0-9]+")
    if len(fields) != 5 or not all(re.fullmatch(p, v) for p, v in zip(patterns, fields)):
        return None
    return tuple(fields)


def respawn_owned_argv(identity, command, require_no_pid=False):
    """One guard spelling for automatic cleanup and the printed recovery."""
    formats = ("#{pid}:#{start_time}", "#{session_id}", "#{window_id}", "#{pane_id}")
    terms = ["#{==:" + fmt + "," + value + "}" for fmt, value in zip(formats, identity[:4])]
    if require_no_pid:
        terms.append("#{==:#{pane_pid},-1}")
    condition = terms[0]
    for term in terms[1:]:
        condition = "#{&&:" + condition + "," + term + "}"
    return ["tmux", "if-shell", "-F", "-t", identity[3], condition,
            shlex.join(command), "display-message -p tap-respawn-identity-changed"]


def respawn_owned_command(identity, command, require_no_pid=False):
    """Check identity in tmux's command queue, immediately before the effect."""
    result = verbose.run(respawn_owned_argv(identity, command, require_no_pid),
                         capture_output=True, text=True, timeout=5)
    if result.returncode or "tap-respawn-identity-changed" in result.stdout:
        raise RespawnFailure(result.stderr.strip() or "respawn ownership changed; no further effect", identity)
    return result


def respawn_initial_pane(record, target, shell_command, creation_identity=None):
    startup_trace.phase("respawn_pane", session=record.name, pane=target)
    before = creation_identity or respawn_identity(target)
    argv = ["tmux", "respawn-pane", "-k", "-t", target, "-c", record.cwd, shell_command]
    try:
        if creation_identity:
            result = verbose.run(respawn_owned_argv(creation_identity, argv[1:]),
                                 check=True, capture_output=True, text=True)
            if "tap-respawn-identity-changed" in result.stdout:
                raise RespawnFailure("creation identity changed before respawn", creation_identity)
        else:
            verbose.run(argv, check=True, stderr=subprocess.PIPE, text=True)
        return
    except subprocess.CalledProcessError as error:
        detail = (error.stderr or "").strip()
        after = respawn_identity(target)
        retry = (error.returncode == 1 and detail == _RESPAWN_FORK_REFUSAL
                 and before is not None and after is not None
                 and before[:4] == after[:4] and after[4] == "-1")
        if not retry:
            raise RespawnFailure(detail or str(error), before) from error
        print(f"tap session: fork refused for {record.name}; retrying once in 1s", file=sys.stderr)
        time.sleep(1)
        # No -k: even after our identity check, tmux must refuse an active pane.
        try:
            respawn_owned_command(before, ["respawn-pane", "-t", before[3], "-c", record.cwd, shell_command],
                                  require_no_pid=True)
        except (OSError, subprocess.SubprocessError) as failure:
            raise RespawnFailure(str(failure), before) from failure
    except (OSError, subprocess.SubprocessError) as failure:
        raise RespawnFailure(str(failure), before) from failure


def created_pane_facts(record, identity):
    """One frame binds pane facts to the session/window returned by creation."""
    result = verbose.run(
        ["tmux", "display-message", "-p", "-t", identity[3],
         PANE_FACTS_FORMAT + "\t#{session_id}\t#{window_id}"],
        capture_output=True, text=True, timeout=2,
    )
    parts = result.stdout.rstrip("\n").rsplit("\t", 2)
    facts = parse_pane_facts(parts[0]) if result.returncode == 0 and len(parts) == 3 else None
    if (facts is None or facts.pane_id != identity[3]
        or facts.server_epoch != seat_corpse.observed_server_epoch(identity[0])
        or parts[1:] != list(identity[1:3])
        or pane_session_name(facts.pane) != record.name):
        raise RespawnFailure("created pane identity changed", identity)
    return facts


def report_respawn_residue(record, error):
    """Best-effort diagnostics after scoped cleanup; never replace the failure."""
    cleanup = "not attempted: ownership unknown"
    if error.identity:
        try:
            respawn_owned_command(error.identity, ["kill-session", "-t", error.identity[1]])
            cleanup = "owned session removed"
        except (OSError, subprocess.SubprocessError, LauncherError) as failure:
            cleanup = "retained or unknown: " + str(failure)
    try:
        rollback_pending_handle(record, "session_replaced")
    except (OSError, LauncherError, RegistryAuthorityError) as failure:
        cleanup += "; registry rollback failed: " + str(failure)
    registry = None
    row_state = "unknown"
    try:
        registry = tap_registry_path(root_for_cwd(record.cwd))
        if registry is None or not registry.exists():
            row_state = "absent"
        else:
            _, rows = registry_v20.seat_store(json.loads(registry.read_text()))
            row_state = "present" if session_handle(record) in rows else "absent"
    except (OSError, ValueError, TypeError, LauncherError, RegistryAuthorityError):
        pass
    try:
        load = f"{os.getloadavg()[0]:.2f}"
    except OSError:
        load = "unknown"
    ptys = "unknown"
    pty_limit = "unknown"
    try:
        if sys.platform == "darwin":
            ptys = str(len(list(pathlib.Path("/dev").glob("ttys*"))))
            result = subprocess.run(["sysctl", "-n", "kern.tty.ptmx_max"], capture_output=True, text=True, timeout=2)
            if result.returncode == 0 and result.stdout.strip().isdigit():
                pty_limit = result.stdout.strip()
        elif sys.platform.startswith("linux"):
            ptys = str(len([p for p in pathlib.Path("/dev/pts").iterdir() if p.name.isdigit()]))
            pty_limit = pathlib.Path("/proc/sys/kernel/pty/max").read_text().strip()
    except (OSError, subprocess.SubprocessError):
        pass
    startup_trace.emit("respawn_failure", session=record.name, phase="respawn_pane", error_class=type(error).__name__, cleanup=cleanup, load1m=load, pty_devices=ptys, pty_limit=pty_limit)
    print(f"tap session: respawn failed: {error}; session/window={record.name}:0 ({cleanup}); "
          f"registry row {session_handle(record)}={row_state} at {registry}; "
          f"inspect: tap session list", file=sys.stderr)
    if error.identity and cleanup != "owned session removed":
        # Registry rollback may already have removed the row. Address the
        # retained session directly, preserving the same identity guard.
        try:
            result = verbose.run(["tmux", "display-message", "-p", "#{socket_path}"],
                                 capture_output=True, text=True, timeout=2)
            socket = result.stdout.strip()
            if result.returncode == 0 and socket.startswith("/"):
                argv = respawn_owned_argv(error.identity, ["kill-session", "-t", error.identity[1]])
                print("tap session: cleanup: " + shlex.join([argv[0], "-S", socket, *argv[1:]]), file=sys.stderr)
            else:
                print("tap session: cleanup unavailable: socket unobserved; run tap doctor", file=sys.stderr)
        except (OSError, subprocess.SubprocessError):
            print("tap session: cleanup unavailable: socket unobserved; run tap doctor", file=sys.stderr)
    print(f"tap session: load1m={load} cores={os.cpu_count() or 'unknown'} pty-devices={ptys} pty-limit={pty_limit}", file=sys.stderr)


def run_invocation(
    record: SessionRecord,
    invocation: Invocation,
    dry_run: bool,
    attach: bool = True,
    launch_failure_argv: list[str] | None = None,
    json_output: bool = False,
    creation_guard: bool = False,
) -> int:
    if not dry_run:
        verbose.command(invocation.argv, record.cwd, invocation.env, event="harness_configuration")
    if dry_run:
        if json_output:
            payload = {
                "name": record.name,
                "harness": record.harness,
                "cwd": record.cwd,
                "env": invocation.env,
                "argv": invocation.argv,
            }
            if record.preset:
                payload["preset"] = dict(record.preset)
            print(json.dumps(payload, separators=(",", ":"), sort_keys=True))
        else:
            emit_receipt("session", f"would launch {record.name} ({record.harness}) in {record.cwd}")
        return 0
    startup_trace.phase("create_session", session=record.name, harness=record.harness, launch_id=record.launch_id)

    try:
        tmux_bootstrap.ensure_server()
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        raise LauncherError(f"tmux bootstrap failed: {error}; next: tap doctor") from error
    if tmux_has(record.name):
        if record.launch_id:
            raise LauncherError(f"session appeared after reserving {record.name}; retry the launch")
        # attach=False is silent BY CONTRACT (Lane D audit): every caller emits
        # its own receipt downstream — cmd_new's post-lock ensure receipts +
        # detached receipt, resume --all / restart's per-seat prints, or
        # resume_attach_tail's detached receipt. Add one here and they double.
        return attach_after_launch(record) if attach else 0
    if not record.launch_id and (not attach or not launch_failure_argv):
        with progress("session", f"starting {record.name!r}"):
            verbose.run(
                ["tmux", "new-session", "-d", *DETACHED_SESSION_SIZE,
                 "-s", record.name, "-c", record.cwd, invocation.shell_command()],
                check=True,
            )
        # attach=False: silent by the same contract as the arm above.
        return attach_after_launch(record) if attach else 0

    with progress("session", f"starting {record.name!r}"):
        target = f"={record.name}:0.0"
        placeholder = f"tmux wait-for tap-launch-{uuid.uuid4()}"
        creation_identity = None
        if creation_guard:
            created = verbose.run(
                ["tmux", "new-session", "-d", *DETACHED_SESSION_SIZE,
                 "-s", record.name, "-c", record.cwd,
                 "-P", "-F", _RESPAWN_IDENTITY_FORMAT, placeholder],
                check=True, capture_output=True, text=True,
            )
            creation_identity = parse_respawn_identity(created.stdout)
            if creation_identity is None:
                raise LauncherError("cannot identify created session; retained without further effects")
            target = creation_identity[3]
            if launch_failure_argv:
                launch_failure_argv = [*launch_failure_argv[:2], "_launch-failed-owned",
                                       "\t".join(creation_identity), *launch_failure_argv[3:]]
        else:
            verbose.run(
                ["tmux", "new-session", "-d", *DETACHED_SESSION_SIZE,
                 "-s", record.name, "-c", record.cwd, placeholder],
                check=True,
            )

        def configure(argv):
            if creation_identity:
                return respawn_owned_command(creation_identity, argv[1:])
            return verbose.run(argv, check=True)

        def logged_helper(argv: list[str]) -> str:
            log = pathlib.Path(os.environ.get("TAP_INDEX_HOME") or "~/.tap").expanduser() / "session-helper.log"
            helper = _LAUNCHER_DIR.parent / "run-shell-logged.sh"
            return shlex.join(["bash", str(helper), str(log), *argv]) + " >/dev/null 2>&1 || true"

        try:
            configure(
                ["tmux", "set-option", "-p", "-t", target, "remain-on-exit", "on"],
            )
            if launch_failure_argv:
                configure(
                    [
                        "tmux",
                        "set-hook",
                        "-p",
                        "-t",
                        target,
                        "pane-died",
                        f"run-shell -b -t {shlex.quote(target)} {shlex.quote(logged_helper(launch_failure_argv))}",
                    ],
                )
            # A target may disappear during the grace window. Try both cleanup
            # operations, log their real status, and keep tmux's result view closed.
            cleanup = (
                "rc=0; "
                f"tmux set-hook -p -u -t {shlex.quote(target)} pane-died || rc=$?; "
                f"tmux set-option -p -t {shlex.quote(target)} remain-on-exit off || rc=$?; "
                'exit "$rc"'
            )
            if creation_identity:
                cleanup = (
                    shlex.join(respawn_owned_argv(creation_identity, ["set-hook", "-p", "-u", "-t", target, "pane-died"]))
                    + "; " + shlex.join(respawn_owned_argv(creation_identity, ["set-option", "-p", "-t", target, "remain-on-exit", "off"]))
                )
            configure(
                ["tmux", "run-shell", "-b", "-t", target, "-d", str(PENDING_RESERVATION_GRACE_SECONDS),
                 logged_helper(["bash", "-c", cleanup])],
            )
            if record.launch_id:
                placeholder_facts = (created_pane_facts(record, creation_identity)
                                     if creation_identity else tmux_pane_facts(target))
                if not placeholder_facts:
                    raise LauncherError(f"could not inspect placeholder pane for {record.name}")
                bind_reserved_handle(record, placeholder_facts)
            if creation_identity:
                respawn_initial_pane(record, target, invocation.shell_command(), creation_identity)
            else:
                respawn_initial_pane(record, target, invocation.shell_command())
            if record.launch_id:
                def read_harness_facts():
                    if creation_identity:
                        return created_pane_facts(record, creation_identity)
                    return matching_session_pane(record)[0]

                harness_facts, blocked = await_stable_harness(
                    read_harness_facts,
                    lambda facts: (
                        facts.dead is False and pane_harness(facts) == record.harness
                    ),
                    HARNESS_START_TIMEOUT_SECONDS,
                    blocker=(
                        (lambda facts: pane_startup_blocker(facts, record.harness))
                        if record.harness == "codex" and record.harness_session_id else None
                    ),
                )
                if harness_facts is None:
                    detail = f": {blocked}" if blocked else ""
                    raise LauncherError(f"harness did not start for {record.name}{detail}")
                mark_launch_ready(record, harness_facts)
        except RespawnFailure as error:
            report_respawn_residue(record, error)
            raise
        except BaseException:
            if creation_identity:
                try:
                    respawn_owned_command(creation_identity, ["kill-session", "-t", creation_identity[1]])
                except (LauncherError, OSError, subprocess.SubprocessError):
                    pass  # Never clean up a replacement by its reused name.
            else:
                verbose.run(
                    ["tmux", "kill-session", "-t", f"={record.name}"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            raise

    if not attach:
        # Silent by the same caller-receipts contract as the two arms above.
        return 0
    return attach_after_launch(record)


def run_record(
    action: str,
    record: SessionRecord,
    dry_run: bool,
    launch_failure_argv: list[str] | None = None,
    json_output: bool = False,
    attach: bool = True,
) -> int:
    return run_invocation(
        record,
        launch_invocation(action, record),
        dry_run,
        attach=attach,
        launch_failure_argv=launch_failure_argv,
        json_output=json_output,
    )


def run_record_detached(
    action: str, record: SessionRecord, dry_run: bool, json_output: bool = False,
    *, resume_identity: object = _UNBOUND_RESUME_IDENTITY, creation_guard: bool = False,
) -> int:
    invocation = (launch_invocation(action, record)
                  if resume_identity is _UNBOUND_RESUME_IDENTITY
                  else launch_invocation(action, record, resume_identity=resume_identity))
    return run_invocation(
        record,
        invocation,
        dry_run,
        attach=False,
        launch_failure_argv=record.launch_failure_argv,
        json_output=json_output,
        **({"creation_guard": True} if creation_guard else {}),
    )


# ONE record: pane identity, command, server generation, remain-on-exit
# liveness, and harness-process identity (tap-ua9l finding 7). tmux has no
# JSON flag for these commands; this is its existing -F machine record as one
# strict seven-field schema. Path stays last so split(..., 6) preserves tabs
# in pane_current_path. No second probe, no legacy-shape guess.
PANE_FACTS_FORMAT = (
    "#{session_name}:#{window_index}.#{pane_index}\t#{pane_id}"
    "\t#{pane_current_command}\t#{pid}:#{start_time}\t#{pane_dead}"
    "\t#{pane_pid}\t#{pane_current_path}"
)


def parse_pane_facts(line: str) -> PaneFacts | None:
    parts = line.rstrip("\n").split("\t", 6)
    if len(parts) != 7 or not parts[0] or not parts[1]:
        return None
    dead_raw = parts[4]
    pid_raw = parts[5]
    if dead_raw not in ("0", "1") or not pid_raw.isdigit():
        return None
    return PaneFacts(
        pane=parts[0],
        pane_id=parts[1],
        command=parts[2],
        path=parts[6],
        server_epoch=seat_corpse.observed_server_epoch(parts[3]) or "",
        dead=dead_raw == "1",
        pane_pid=int(pid_raw),
    )


def tmux_pane_facts(target: str) -> PaneFacts | None:
    try:
        result = verbose.run(
            [
                "tmux",
                "display-message",
                "-p",
                "-t",
                target,
                PANE_FACTS_FORMAT,
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    return parse_pane_facts(result.stdout)


def tmux_session_pane(record: SessionRecord) -> PaneFacts | None:
    return tmux_pane_facts(f"={record.name}")


def tmux_session_panes(record: SessionRecord) -> list[PaneFacts]:
    try:
        result = verbose.run(
            [
                "tmux",
                "list-panes",
                "-s",
                "-t",
                f"={record.name}",
                "-F",
                PANE_FACTS_FORMAT,
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return []
    if result.returncode != 0:
        return []
    panes = []
    for line in result.stdout.splitlines():
        facts = parse_pane_facts(line)
        if facts:
            panes.append(facts)
    return panes


def pane_session_name(pane: str) -> str:
    return pane.split(":", 1)[0]


def pane_harness(facts: PaneFacts) -> str:
    lib = pathlib.Path(__file__).resolve().parents[1] / "lib.sh"
    try:
        result = verbose.run(
            ["bash", "-c", f". {shlex.quote(str(lib))}; tap_pane_harness_command \"$1\" \"$2\"", "tap-pane-harness", facts.pane, facts.command],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return facts.command
    if result.returncode != 0:
        return facts.command
    return result.stdout.strip() or facts.command


def matching_session_pane(record: SessionRecord) -> tuple[PaneFacts | None, str | None]:
    active = tmux_session_pane(record)
    active_harness = pane_harness(active) if active else None
    if active and active_harness == record.harness:
        return active, active_harness
    for candidate in tmux_session_panes(record):
        candidate_harness = pane_harness(candidate)
        if candidate_harness == record.harness:
            return candidate, candidate_harness
    return active, active_harness


def pane_startup_blocker(facts: PaneFacts, harness: str) -> str | None:
    """Known terminal startup states that run a harness process but cannot serve mail."""
    try:
        captured = verbose.run(
            ["tmux", "capture-pane", "-p", "-J", "-t", facts.pane_id],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except (FileNotFoundError, OSError, subprocess.SubprocessError):
        return None
    if captured.returncode != 0:
        return None
    screen = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", captured.stdout)
    if harness == "codex" and "No results for your search" in screen and re.search(
        r"\b0\s*/\s*0\b", screen
    ):
        return "codex resume picker has zero results; the stored conversation id is unavailable to the active account"
    return None


def await_stable_harness(
    read_facts,
    matches,
    timeout: float,
    *,
    blocker=None,
    confirmations: int = HARNESS_READY_CONFIRMATIONS,
    monotonic=None,
    sleeper=None,
) -> tuple[PaneFacts | None, str | None]:
    """Require consecutive observations of one process before claiming readiness.

    A supplied blocker is an asynchronous startup state. Keep sampling it for
    the whole existing deadline: an early blocker-free frame is not evidence
    that a later native picker can serve mail.
    """
    clock = monotonic or time.monotonic
    pause = sleeper or time.sleep
    deadline = clock() + timeout
    prior_identity = None
    observed = 0
    while True:
        facts = read_facts()
        if facts is not None and matches(facts):
            identity = (
                facts.pane_id,
                facts.server_epoch,
                facts.pane_pid,
                facts.command,
            )
            if identity == prior_identity:
                observed += 1
            else:
                prior_identity = identity
                observed = 1
            reason = blocker(facts) if blocker else None
            if reason:
                return None, reason
        else:
            prior_identity = None
            observed = 0
        now = clock()
        if observed >= confirmations and (blocker is None or now >= deadline):
            return facts, None
        if now >= deadline:
            return None, None
        pause(0.05)


# Ladder classification (tap-x077): a session name is only a COLLISION when a
# live harness or a busy vessel occupies it. Bare login shells are absorbable.
LOGIN_SHELL_COMMANDS = {"zsh", "bash", "sh", "fish", "dash", "ksh", "tcsh", "nu", "login"}


def is_login_shell(command: str) -> bool:
    # pane_current_command is usually a bare basename, but login shells can
    # report a leading dash and some hosts report full paths (crew-wolf F).
    return pathlib.PurePath(command).name.lstrip("-").lower() in LOGIN_SHELL_COMMANDS


def shell_has_children(pane_pid: str) -> bool:
    # A bare post-restore shell has no children; anything it spawned (an
    # editor, a daemon, a harness the ps-walk missed — tap-9ow) makes the
    # vessel busy rather than absorbable. pgrep rc 1 is the one code that
    # POSITIVELY means "no children"; any other failure is unobservable
    # state and must read as busy (sol: never absorb on a failed probe).
    try:
        result = verbose.run(
            ["pgrep", "-P", pane_pid],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return True
    if result.returncode == 0:
        return bool(result.stdout.strip())
    return result.returncode != 1


def native_revive_mode(harness: str, session_id: str | None) -> tuple[str, str]:
    """How a seat's conversation comes back without an exact id: per-harness
    truth (sol): claude/codex expose interactive pickers; OpenCode starts fresh
    without an exact id; cursor has no bare picker (browse is `cursor-agent ls`);
    hermes is a daemon with nothing to resume.

    Returns (ensure_action, receipt_context)."""
    if session_id:
        return "resume", f"{harness} resume {session_id}"
    if harness in ("claude", "codex"):
        return "resume", f"{harness} native picker"
    if harness == "agy":
        # agy --continue resumes the latest conversation (tap-8qj7).
        return "resume", "agy native latest (--continue)"
    if harness == "cursor":
        return "new", "no session id on record; browse past sessions with cursor-agent ls"
    return "new", "no conversation to resume"


def classify_session(name: str) -> str:
    """Classify a tmux session for the ensure ladder.

    'live'          at least one pane resolves to a known harness
    'busy'          non-shell activity (editor, REPL, ssh, shell with children)
    'attached-shell' every pane a bare login shell, but a client is attached
    'shell'          every pane a bare login shell, unattended — absorbable
    'unknown'       observation failed — NEVER authorizes absorption (sol)

    The caller establishes that the session exists (one source of truth for
    existence — tmux_sessions()/tmux_has at the call site); a probe failure
    here is 'unknown', not 'absent'.
    """
    try:
        result = verbose.run(
            [
                "tmux",
                "list-panes",
                "-s",
                "-t",
                f"={name}",
                "-F",
                "#{session_name}:#{window_index}.#{pane_index}\t#{pane_id}\t#{pane_current_command}\t#{pane_pid}\t#{session_attached}",
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return "unknown"
    if result.returncode != 0 or not result.stdout.strip():
        return "unknown"
    attached = False
    saw_harness = False
    busy = False
    shell_pids: list[str] = []
    parsed_panes = 0
    for line in result.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) != 5:
            continue
        parsed_panes += 1
        target, pane_id, command, pane_pid, attached_flag = parts
        if attached_flag not in ("", "0"):
            attached = True
        facts = PaneFacts(pane=target, pane_id=pane_id, command=command, path="")
        if pane_harness(facts) in HARNESSES:
            saw_harness = True
        elif not is_login_shell(command):
            busy = True
        elif pane_pid.isdigit():
            shell_pids.append(pane_pid)
        else:
            # A shell pane whose pid we cannot read is unobservable state.
            busy = True
    if parsed_panes == 0:
        return "unknown"
    if saw_harness:
        return "live"
    if busy:
        return "busy"
    if any(shell_has_children(pid) for pid in shell_pids):
        return "busy"
    return "attached-shell" if attached else "shell"


def session_attached(name: str) -> bool | None:
    """Whether a client is attached to a live tmux session (tap-opw9, display only).

    Reads tmux's `session_attached` flag for the resume-picker state line — NOT a
    classification input (it never authorizes absorb/resume). Fail-open to None on
    any probe failure so the caller omits the attach fact rather than guessing.
    """
    try:
        result = verbose.run(
            ["tmux", "display-message", "-p", "-t", f"={name}", "#{session_attached}"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    flag = result.stdout.strip()
    if flag == "":
        return None
    return flag != "0"


def path_is_under(path: str, root: str) -> bool:
    return completion.path_is_under(path, root)


def compact_record_name(record: SessionRecord, base: str, index: int | None = None) -> str:
    idx = record.index if index is None else index
    if idx is None:
        raise LauncherError("cannot compact unique session without an index")
    handle = sanitize_component(record.tag or record.harness)
    if idx > 1:
        handle = f"{handle}-{idx}"
    return named_session_name(base, handle)


def parse_resume_shorthand(name: str) -> tuple[str | None, int] | None:
    if re.fullmatch(r"\d+", name):
        raw = int(name)
        return None, 1 if raw == 0 else raw
    match = re.fullmatch(r"(.+)-(\d+)", name)
    if not match:
        return None
    raw = int(match.group(2))
    return match.group(1), 1 if raw == 0 else raw


def expand_resume_shorthand(name: str, harness: str, base: str, default_tag: str | None = None) -> str | None:
    clean_base = sanitize_component(base)
    clean_harness = sanitize_component(harness)
    if name.startswith(f"{clean_base}-{clean_harness}-"):
        return None
    parsed = parse_resume_shorthand(name)
    if not parsed:
        return None
    tag, index = parsed
    tag = tag or default_tag
    return compact_record_name(SessionRecord(name="", harness=harness, cwd="", base=base, tag=tag, index=index), clean_base)


def legacy_resume_name(name: str, harness: str, base: str, default_tag: str | None = None) -> str | None:
    clean_base = sanitize_component(base)
    clean_harness = sanitize_component(harness)
    if re.fullmatch(r"\d+", name):
        if default_tag:
            return f"{clean_base}-{clean_harness}-{sanitize_component(default_tag)}-{int(name)}"
        return f"{clean_base}-{clean_harness}-{int(name)}"
    match = re.fullmatch(r"(.+)-(\d+)", name)
    if not match:
        return None
    return "-".join([clean_base, clean_harness, sanitize_component(match.group(1)), str(int(match.group(2)))])


def legacy_compact_resume_name(name: str, harness: str, base: str, default_tag: str | None = None) -> str | None:
    parsed = parse_resume_shorthand(name)
    if not parsed:
        return None
    tag, index = parsed
    tag = tag or default_tag
    parts = [sanitize_component(base), sanitize_component(harness)]
    if tag:
        parts.append(sanitize_component(tag))
    if index > 1:
        parts.append(str(index))
    return "-".join(parts)


def tag_resume_name(name: str, harness: str, base: str) -> str | None:
    clean_base = sanitize_component(base)
    clean_harness = sanitize_component(harness)
    if name.startswith(f"{clean_base}-{clean_harness}"):
        return None
    if parse_resume_shorthand(name):
        return None
    return "-".join([clean_base, clean_harness, sanitize_component(name)])


def resume_shorthand_candidates(name: str, harness: str, base: str, default_tag: str | None = None) -> list[str]:
    primary = expand_resume_shorthand(name, harness, base, default_tag)
    if not primary:
        return []
    candidates = [primary]
    legacy_compact = legacy_compact_resume_name(name, harness, base, default_tag)
    if legacy_compact and legacy_compact not in candidates:
        candidates.append(legacy_compact)
    legacy = legacy_resume_name(name, harness, base, default_tag)
    if legacy and legacy not in candidates:
        candidates.append(legacy)
    return candidates


def allocated_index(name: str, base: str, harness: str) -> int:
    parsed = parse_session_name(name, {base})
    if parsed and parsed[0] == harness:
        return parsed[2]
    return 1


def plan_dir_alias_renames(
    records: list[SessionRecord],
    cwd: str,
    alias: str,
    existing_names: set[str],
) -> dict[str, str]:
    occupied = {record.name for record in records} | set(existing_names)
    renames: dict[str, str] = {}
    for record in records:
        if record.index is None or not path_is_under(record.cwd, cwd):
            continue
        occupied.discard(record.name)
        candidate = compact_record_name(record, alias)
        if candidate in occupied:
            candidate = allocate_name(alias, record.harness, record.tag, occupied)
        if candidate != record.name:
            renames[record.name] = candidate
            occupied.add(candidate)
        else:
            occupied.add(record.name)
    return renames


def parse_session_name(name: str, bases: set[str]) -> tuple[str, str | None, int] | None:
    for base in sorted((sanitize_component(item) for item in bases if item), key=len, reverse=True):
        slash_prefix = f"{base}/"
        if name.startswith(slash_prefix):
            handle = name[len(slash_prefix) :]
            if not handle:
                continue
            match = re.fullmatch(r"(.+)-(\d+)", handle)
            stem = match.group(1) if match else handle
            index = int(match.group(2)) if match else 1
            harness = HARNESS_BY_CODE.get(stem, stem)
            if harness in HARNESSES:
                return harness, None, 1 if index == 0 else index
            return "", handle, 1
        prefix = f"{base}-"
        if not name.startswith(prefix):
            continue
        parts = name[len(prefix) :].split("-")
        if len(parts) < 1:
            continue
        harness = HARNESS_BY_CODE.get(parts[0], parts[0])
        if harness not in HARNESSES:
            continue
        if len(parts) == 1:
            return harness, None, 1
        if parts[-1].isdigit():
            index = int(parts[-1])
            tag = "-".join(parts[1:-1]) or None
            return harness, tag, 1 if index == 0 else index
        return harness, "-".join(parts[1:]) or None, 1
    return None


def plan_name_alias_renames(
    names: set[str],
    bases: set[str],
    alias: str,
    existing_names: set[str],
) -> dict[str, str]:
    occupied = set(names) | set(existing_names)
    renames: dict[str, str] = {}
    for name in sorted(names):
        parsed = parse_session_name(name, bases)
        if not parsed:
            continue
        harness, tag, index = parsed
        occupied.discard(name)
        record = SessionRecord(name=name, harness=harness, cwd="", base=alias, tag=tag, index=index)
        candidate = compact_record_name(record, alias)
        if candidate in occupied:
            candidate = allocate_name(alias, harness, tag, occupied)
        if candidate != name:
            renames[name] = candidate
            occupied.add(candidate)
        else:
            occupied.add(name)
    return renames


def apply_record_renames(records: list[SessionRecord], renames: dict[str, str], alias: str) -> None:
    for record in records:
        if record.name in renames:
            record.name = renames[record.name]
            record.base = alias


def rename_tmux_sessions(renames: dict[str, str]) -> list[str]:
    renamed = []
    for old, new in renames.items():
        if tmux_has(old):
            verbose.run(["tmux", "rename-session", "-t", f"={old}", new], check=True)
            renamed.append(old)
    return renamed


def rename_tap_registrations(root: str, renames: dict[str, str]) -> list[str]:
    try:
        registry = tap_registry_path(root)
    except RegistryAuthorityError:
        return []
    if registry is None:
        return []
    registry = pathlib.Path(registry)
    if not registry.exists():
        return []
    with registry.open() as handle:
        payload = json.load(handle)
    _, agents = registry_v20.seat_store(payload)
    changed = []
    for old, new in renames.items():
        if old in agents and new not in agents:
            agents[new] = agents.pop(old)
            changed.append(old)
    if changed:
        fd, tmp = tempfile.mkstemp(dir=registry.parent, prefix=".registry.", text=True)
        try:
            with os.fdopen(fd, "w") as handle:
                json.dump(payload, handle, indent=2, sort_keys=True)
                handle.write("\n")
            os.replace(tmp, registry)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
    return changed


# tap_registry_path moved to the completion leaf (re-exported at module top).


def writable_tap_registry_path(root: str) -> pathlib.Path:
    """Resolve a writable registry path — never bus under live/invalid.

    Raises LauncherError on invalid or live_unreachable (WAVE 6 / 3681979280).
    ``live_unenrolled`` also refuses here (WAVE 6.6 / sol 114659Z) — inventing
    an acting path without global enroll creates an unindexed store. Callers that
    permit unenrolled (launch) must ``_bootstrap_if_live_unenrolled`` first.
    """
    status, path = registry_v20.resolve_team_registry_for_root(root)
    if status == "invalid":
        raise LauncherError(
            "tap session refused — global-registry.json is present but unreadable "
            "or wrong schema (invalid_flip); next: tap doctor"
        )
    if status == "live_unreachable":
        raise LauncherError(
            "tap session refused — acting team-registry unreachable "
            "(acting_registry_unreachable); next: tap doctor"
        )
    if status == "live_unenrolled":
        raise LauncherError(
            "tap session refused — worktree is not enrolled under the live flip "
            "marker (live_unenrolled); next: tap session launch or tap in"
        )
    if path:
        return pathlib.Path(path)
    # Invent only on the correct axis (acting post-flip, bus pre-flip).
    if status == "live":
        return pathlib.Path(root) / ".tap" / "team-registry.json"
    return pathlib.Path(root) / ".tap" / "bus" / "registry.json"


def tap_seat_entries(root: str, live_sessions=_UNSET) -> dict[str, object]:
    """Registry seats keyed by handle, minus expired pending reservations.

    `occupied_session_names` needs the entry bodies to classify exact session
    names and generation/boot provenance; `tap_handles` is the name-only view
    over this same filter. Callers that already observed the live tmux sessions
    pass their snapshot in (None IS the unobservable snapshot) so reservation
    expiry and allocation share it; an omitted argument observes once here.
    """
    try:
        registry = tap_registry_path(root)
    except RegistryAuthorityError:
        return {}
    if registry is None:
        return {}
    try:
        with registry.open() as handle:
            payload = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return {}
    agents = registry_v20._seat_map(payload)
    if not agents:
        return {}
    if live_sessions is _UNSET:
        live_sessions = tmux_sessions_or_none()
    return {
        handle: entry
        for handle, entry in agents.items()
        if not (isinstance(entry, dict) and pending_reservation_expired(entry, live_sessions=live_sessions))
    }


def tap_handles(root: str) -> set[str]:
    return set(tap_seat_entries(root))


def session_attachable(name: str) -> bool:
    """Resume-attach guard (tap-x077). Attach itself is non-replacing (it does not
    stop or replace the target session), so
    only the states where attaching is WRONG divert: a shell session falls
    through to resume, and an attached shell (a human sitting in a bare shell
    — crew-wolf C's sharp edge) falls through to the resume tail's loud
    boundary refusal. Busy and unknown keep legacy attach semantics — busy
    surfaces the existing harness-mismatch error, and a transient probe
    failure must not block a non-replacing attach."""
    if not tmux_has(name):
        return False
    return classify_session(name) not in ("shell", "attached-shell")


def session_handle(record: SessionRecord) -> str:
    # Registry-backed records carry the authoritative roster handle in ``tag``.
    # The tmux session name may be noncanonical (for example a seat rebound to
    # ``repo/legacy-scout``); deriving the handle from that vessel would address
    # ``legacy-scout`` and lose the registry row that actually owns the seat.
    if record.tag:
        return f"{record.tag}-{record.index}" if record.index and record.index > 1 else record.tag
    return completion.session_handle_fields(
        record.name, record.base, record.tag, record.harness, record.index
    )


def slash_handle(name: str, base: str) -> str | None:
    return completion.slash_handle(name, base)


def records_for_root(records: list[SessionRecord], cwd: str) -> list[SessionRecord]:
    root = root_for_cwd(cwd)
    return [record for record in records if path_is_under(record.cwd, root)]


def find_record_by_key(records: list[SessionRecord], cwd: str, key: str) -> SessionRecord | None:
    scoped = records_for_root(records, cwd)
    for record in scoped:
        if record.name == key:
            return record
    for record in scoped:
        if session_handle(record) == key:
            return record
    return None


def find_record_by_session(records: list[SessionRecord], cwd: str, session_name: str) -> SessionRecord | None:
    for record in records_for_root(records, cwd):
        if record.name == session_name:
            return record
    return None


def matching_harness_records(records: list[SessionRecord], cwd: str, harness: str) -> list[SessionRecord]:
    return [record for record in records_for_root(records, cwd) if record.harness == harness]


def print_ambiguous_session_key(verb: str, key: str, matches: list[SessionRecord]) -> None:
    names = ", ".join(record.name for record in sorted(matches, key=lambda item: item.name))
    action = f"tap session list --harness {key}"
    print_session_error(f"tap session {verb}", "session_ambiguous", action, f"{key} matches: {names}")


def resolve_exact_record(records: list[SessionRecord], cwd: str, key: str, verb: str) -> SessionRecord:
    record = find_record_by_key(records, cwd, key)
    if record:
        return record
    if key in HARNESSES:
        matches = matching_harness_records(records, cwd, key)
        if matches:
            print_ambiguous_session_key(verb, key, matches)
            raise SystemExit(2)
    raise LauncherError(f"{verb} key not found: {key}")


def registry_entries(root: str) -> dict[str, dict]:
    try:
        registry = tap_registry_path(root)
    except RegistryAuthorityError:
        return {}
    if registry is None or not pathlib.Path(registry).exists():
        return {}
    try:
        with open(registry) as registry_file:
            payload = json.load(registry_file)
    except (OSError, json.JSONDecodeError):
        return {}
    agents = registry_v20._seat_map(payload)
    return {handle: entry for handle, entry in agents.items() if isinstance(handle, str) and isinstance(entry, dict)}


def session_record_from_registry_row(
    handle: str,
    entry: dict,
    team: dict,
    root: str,
) -> SessionRecord | None:
    """Adapt one current team-registry row into the launcher's value object.

    The acting registry is authoritative. In particular, only the explicit
    ``harness_session_id`` field can drive an exact native resume; inferred or
    derived candidates are deliberately ignored.
    """
    session = entry.get("session")
    harness = entry.get("harness")
    if not isinstance(session, str) or not session:
        return None
    if not isinstance(harness, str) or harness not in HARNESSES:
        return None

    team_root = team.get("worktree_root")
    cwd = entry.get("registered_from_worktree")
    if not isinstance(cwd, str) or not cwd:
        cwd = team_root if isinstance(team_root, str) and team_root else root
    base = entry.get("base")
    if not isinstance(base, str) or not base:
        team_name = team.get("name")
        base = str(team_name) if isinstance(team_name, str) and team_name else derive_base(cwd)
    if "tag" in entry:
        raw_tag = entry.get("tag")
        tag = raw_tag if isinstance(raw_tag, str) and raw_tag else None
    else:
        tag = None if handle == harness else handle
    index = entry.get("index")
    if not isinstance(index, int) or isinstance(index, bool) or index < 1:
        index = 1
    model = entry.get("model")
    if not isinstance(model, str) or not model:
        model = None
    native_id = entry.get("harness_session_id")
    if not isinstance(native_id, str) or not native_id:
        native_id = None
    transcript = entry.get("transcript_path")
    if not isinstance(transcript, str) or not transcript:
        transcript = None
    passthrough = entry.get("passthrough")
    if not isinstance(passthrough, list):
        passthrough = []
    history = entry.get("history")
    if not isinstance(history, list):
        history = []

    def optional_text(key: str) -> str | None:
        value = entry.get(key)
        return value if isinstance(value, str) and value else None

    return SessionRecord(
        name=session,
        harness=harness,
        cwd=cwd,
        base=base,
        tag=tag,
        index=index,
        model=model,
        harness_session_id=native_id,
        transcript_path=transcript,
        quarantined_harness_session_id=optional_text("quarantined_harness_session_id"),
        quarantined_transcript_path=optional_text("quarantined_transcript_path"),
        identity_quarantine_reason=optional_text("identity_quarantine_reason"),
        adopted_from_manual=bool(entry.get("adopted_from_manual", False)),
        harness_passthrough=[item for item in passthrough if isinstance(item, str)],
        passthrough_from_config=bool(entry.get("passthrough_from_config", False)),
        permissions=optional_text("permissions"),
        harness_env=_string_dict(entry.get("harness_env")),
        harness_unset_env=list(entry.get("harness_unset_env") or []),
        harness_tail=list(entry.get("harness_tail") or []),
        preset=_preset_provenance_dict(entry.get("preset")),
        history=[item for item in history if isinstance(item, str)],
        last_launched=optional_text("last_launched"),
        last_seen=optional_text("last_seen"),
    )


def _session_state_from_registry_payload(payload: dict, root: str) -> Manifest:
    team = payload.get("team") if isinstance(payload.get("team"), dict) else {}
    base = team.get("name")
    if not isinstance(base, str) or not base:
        base = derive_base(root)
    records: list[SessionRecord] = []
    for handle, entry in registry_v20._seat_map(payload).items():
        if not isinstance(handle, str) or not isinstance(entry, dict):
            continue
        if not _seat_is_relaunchable(entry):
            continue
        record = session_record_from_registry_row(handle, entry, team, root)
        if record is not None:
            records.append(record)
    return Manifest(sessions=records, dir_aliases={root: base})


def registry_session_state(cwd: str, *, allow_unenrolled: bool = False) -> Manifest:
    """Read the current root's complete launcher state from its acting registry."""
    root = root_for_cwd(cwd)
    status, raw_path = registry_v20.resolve_team_registry_for_root(root)
    if status == "invalid":
        raise LauncherError("acting registry is invalid; next: tap doctor")
    if status == "live_unreachable":
        raise LauncherError("acting team registry is unreachable; next: tap doctor")
    if status == "live_unenrolled":
        if not allow_unenrolled:
            raise LauncherError("worktree is not enrolled; next: tap session launch or tap in")
        return Manifest(sessions=[], dir_aliases={root: derive_base(root)})
    if not raw_path:
        return Manifest(sessions=[], dir_aliases={root: derive_base(root)})

    path = pathlib.Path(raw_path)
    verbose.emit("state_read", path=path)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise LauncherError(f"acting registry unreadable: {exc}; next: tap doctor") from exc
    if not isinstance(payload, dict):
        raise LauncherError("acting registry root is not an object; next: tap doctor")
    return _session_state_from_registry_payload(payload, root)


_REGISTRY_DURABLE_OPTIONAL_FIELDS = (
    "harness_session_id",
    "transcript_path",
    "quarantined_harness_session_id",
    "quarantined_transcript_path",
    "identity_quarantine_reason",
    "last_launched",
    "last_seen",
)


def store_session_record_fields(entry: dict, record: SessionRecord) -> None:
    """Round-trip all durable launcher fields onto a reserved registry row."""
    if record.permissions is None:
        record.permissions = "bypass"
    entry.update({
        "permissions": record.permissions,
        "session": record.name,
        "harness": record.harness,
        "base": record.base,
        "tag": record.tag,
        "index": record.index or 1,
        "model": record.model,
        "passthrough": list(record.harness_passthrough),
        "adopted_from_manual": bool(record.adopted_from_manual),
        "history": list(record.history),
    })
    if record.passthrough_from_config:
        entry["passthrough_from_config"] = True
    else:
        entry.pop("passthrough_from_config", None)
    for key in _REGISTRY_DURABLE_OPTIONAL_FIELDS:
        value = getattr(record, key)
        if isinstance(value, str) and value:
            entry[key] = value
        else:
            entry.pop(key, None)
    for key in ("harness_unset_env", "harness_tail"):
        if getattr(record, key):
            entry[key] = list(getattr(record, key))
        else:
            entry.pop(key, None)
    if record.harness_env:
        entry["harness_env"] = dict(record.harness_env)
    else:
        entry.pop("harness_env", None)
    if record.preset:
        entry["preset"] = dict(record.preset)
    else:
        entry.pop("preset", None)


def registry_entry(root: str, handle: str) -> dict | None:
    entry = registry_entries(root).get(handle)
    return entry if isinstance(entry, dict) else None


def save_registry(path: pathlib.Path, payload: dict) -> None:
    payload = registry_v20.supersede_forwarding_aliases(payload)
    verbose.emit("state_write", path=path)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".registry.", text=True)
    try:
        with os.fdopen(fd, "w") as handle_file:
            json.dump(payload, handle_file, indent=2, sort_keys=True)
            handle_file.write("\n")
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def mark_registry_suspended(root: str, handle: str, reason: str, require_observed_dead: bool = False) -> bool:
    try:
        registry = tap_registry_path(root)
    except RegistryAuthorityError:
        return False
    if registry is None or not registry.exists():
        return False
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with registry.open() as handle_file:
                payload = json.load(handle_file)
        except (OSError, json.JSONDecodeError):
            return False
        _, agents = registry_v20.seat_store(payload)
        entry = agents.get(handle)
        if not isinstance(entry, dict):
            return False
        if require_observed_dead and not entry_observed_dead(entry):
            # crew-wolf F2: the caller's census is a snapshot; a seat that came
            # alive since must never be parked. Probe the FRESH entry under
            # this lock, not the stale one.
            return False
        entry["status"] = "suspended"
        entry["status_reason"] = reason
        save_registry(registry, payload)
        return True


@contextlib.contextmanager
def suspend_session_registry_members(
    root: str,
    session: str,
    keep_handle: str,
    reason: str,
    expected_keep: tuple[str, str] | None = None,
):
    registry = writable_tap_registry_path(root)
    registry.parent.mkdir(parents=True, exist_ok=True)
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        payload = {}
        if registry.exists():
            try:
                with registry.open() as handle_file:
                    payload = json.load(handle_file)
            except (OSError, json.JSONDecodeError) as exc:
                raise LauncherError(f"registry unreadable: {exc}") from exc
        _, agents = registry_v20.seat_store(payload)
        if not isinstance(agents, dict):
            raise LauncherError("registry seats map is invalid")
        if expected_keep is not None:
            expected_status, expected_session = expected_keep
            keep_entry = agents.get(keep_handle)
            if not (
                isinstance(keep_entry, dict)
                and keep_entry.get("status") == expected_status
                and keep_entry.get("session") == expected_session
            ):
                raise LauncherError(
                    f"replacement reservation changed before teardown for {keep_handle}; retry the launch"
                )
        displaced: dict[str, dict] = {}
        for handle, entry in agents.items():
            if (
                handle != keep_handle
                and isinstance(entry, dict)
                and entry.get("delivery", "pane") != "poll"
                and entry_session_name(entry) == session
                and entry.get("status", "active") in {"active", "pending"}
            ):
                displaced[handle] = dict(entry)
                entry["status"] = "suspended"
                entry["status_reason"] = reason
        if displaced:
            save_registry(registry, payload)
        try:
            yield displaced
        except BaseException:
            changed = False
            for handle, original in displaced.items():
                current = agents.get(handle)
                expected = dict(original)
                expected["status"] = "suspended"
                expected["status_reason"] = reason
                if current == expected:
                    agents[handle] = dict(original)
                    changed = True
            if changed:
                try:
                    save_registry(registry, payload)
                except OSError as restore_error:
                    print(
                        f"tap session: WARNING: could not restore sibling registry rows after failed session stop: {restore_error}",
                        file=sys.stderr,
                    )
            raise


def restore_suspended_session_registry_members(root: str, displaced: dict[str, dict], reason: str) -> None:
    if not displaced:
        return
    try:
        registry = tap_registry_path(root)
    except RegistryAuthorityError:
        return
    if registry is None or not registry.exists():
        return
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with registry.open() as handle_file:
                payload = json.load(handle_file)
        except (OSError, json.JSONDecodeError):
            return
        _, agents = registry_v20.seat_store(payload)
        changed = False
        for handle, original in displaced.items():
            current = agents.get(handle)
            expected = dict(original)
            expected["status"] = "suspended"
            expected["status_reason"] = reason
            if current == expected:
                agents[handle] = dict(original)
                changed = True
        if changed:
            save_registry(registry, payload)


def entry_session_name(entry: dict) -> str | None:
    stored_pane_id = entry.get("pane_id")
    if isinstance(stored_pane_id, str) and stored_pane_id:
        pane_id, _pane = seat_corpse.epoch_voided_ids(entry, current_server_epoch())
        verified = entry_verified_session_name(entry) if pane_id else None
        if verified is not None:
            return verified
        # A gone, recycled, epoch-voided, or provenance-contradicted identity
        # must not let its mutable address override the session provenance
        # stored in the registry. The stored ADDRESS is parsed as text only —
        # dereferencing it would repeat the stale-id mistake (tap-24f).
        session = entry.get("session")
        if isinstance(session, str) and session:
            return session
        pane = entry.get("pane")
        if isinstance(pane, str) and pane:
            return pane_session_name(pane)
        return None

    # Without stable identity, stored provenance wins over the mutable pane
    # address. The address remains a legacy fallback only when none was stored.
    session = entry.get("session")
    if isinstance(session, str) and session:
        return session
    pane = entry.get("pane")
    if isinstance(pane, str) and pane:
        facts = tmux_pane_facts(pane)
        if facts:
            return pane_session_name(facts.pane)
    if isinstance(pane, str) and pane:
        return pane_session_name(pane)
    return None


def entry_verified_session_name(entry: dict, require_observed_generation: bool = False) -> str | None:
    pane_id, _pane = seat_corpse.epoch_voided_ids(entry, current_server_epoch())
    if not pane_id:
        # No stable identity on record, or the ids were captured under a PRIOR
        # server epoch (tap-24f): a stale numeric id resolving on the reborn
        # server names an unrelated pane, so it can verify nothing.
        return None
    facts = tmux_pane_facts(pane_id)
    # A session-terminating path must bind to the stable pane identity, not a
    # recycled address or a reused session name.
    if not (facts and facts.pane_id == pane_id):
        return None
    # tap-bzyz: the generation above and this identity were TWO observations, so
    # a server replacement landing between them returned the REPLACEMENT
    # server's session while still gated on the EARLIER generation — the id was
    # recycled and nothing re-checked which server answered. The fix costs
    # nothing: `facts` already carries the generation these ids were observed
    # under, on the SAME tmux record (PANE_FACTS_FORMAT asks for
    # #{pid}:#{start_time} alongside them), and this function was ignoring it.
    # Comparing against the record's own generation makes the id and the
    # generation one observation, so they cannot describe different servers.
    #
    # The EMPTY case is decided deliberately, and it splits by ROLE — this
    # function is dual-use, which is exactly the distinction that bit tap-6lai.
    # As a DETECTOR (entry_session_name, the chooser, the census) it must stay
    # fail-OPEN on an unknown generation: seat_corpse.observed_server_epoch
    # honours TAP_SERVER_EPOCH just as the standalone probe does, so a
    # force-unknown pin empties the RECORD too, and refusing here would
    # silently convert tap-24f's ratified reader semantics into fail-closed.
    # As an AUTHORIZER the opposite is right, so the strict form is opted into
    # by destructive_session_target via require_observed_generation rather than
    # imposed on every caller.
    # Unstamped rows are untouched either way: they make no generation claim,
    # and whether such a row may confer identity at all is tap-zk1w's decision.
    row_epoch = entry.get("server_epoch")
    if row_epoch:
        if facts.server_epoch and facts.server_epoch != row_epoch:
            return None
        if require_observed_generation and not facts.server_epoch:
            return None
    derived = pane_session_name(facts.pane)
    if entry.get("server_epoch"):
        # Stamped under THIS server: within one epoch a resolving id IS the
        # seat, wherever it moved — fork protection stays exact.
        return derived
    # Unstamped legacy row: the id cannot be epoch-checked, and a numeric id
    # may not OVERRIDE stored session provenance (resume resolves by NAME,
    # never a stored numeric id — tap-24f). Agreement verifies; disagreement
    # is unverifiable; absent provenance keeps legacy behavior.
    session = entry.get("session")
    if isinstance(session, str) and session and session != derived:
        return None
    return derived


def destructive_session_target(entry: dict, expected_session: str | None) -> str | None:
    """THE sanctioned derivation of a session name for a session-TERMINATING
    decision — the single verifier every terminating path routes through
    (shell twin: tap_destructive_session_target in lib.sh).

    NAME-FIRST (session-name authority, 2026-08-04). Supersedes the 2026-07-25
    id-anchored proven arm (obs 73641/73569/74434): that arm IS E2's wrong-target
    mechanism. Stored pane ids are HINTS; the stop target is always the
    caller-derived canonical session name.

    Authorize iff ALL of:
      1. `pane_id` satisfies the tmux pane-id grammar (`seat_corpse.is_pane_id`);
      2. `entry["session"]` EXACTLY equals caller-derived `expected_session`;
      3. that exact name is live (`tmux has-session -t "=<expected>"`);
      4. the stored pane_id is NOT alive in a different session.

    Ops (2026-08-04): stop by session name; refuse ONLY on stored-id/name
    disagreement (pane live elsewhere). A gone tip does not block name-keyed
    stop. An absent `expected_session` is a refusal, not a wildcard. Accepted
    tradeoff: a seat that genuinely moved/renamed is un-stoppable by stored id
    until its registry session string matches a live name.
    """
    if not isinstance(entry, dict):
        return None
    if not seat_corpse.is_pane_id(entry.get("pane_id")):
        return None
    if not (isinstance(expected_session, str) and expected_session):
        return None
    session = entry.get("session")
    if not (isinstance(session, str) and session == expected_session):
        return None
    if not tmux_has(expected_session):
        return None
    pane_id = entry["pane_id"]
    # Gone / unobservable tip → authorize by name (Ops). A tip that answers
    # under a DIFFERENT pane_id is recycled (live elsewhere) → refuse. A tip
    # whose address names another session likewise refuses.
    facts = tmux_pane_facts(pane_id)
    if facts is None:
        return expected_session
    if getattr(facts, "pane_id", None) != pane_id:
        return None
    pane_addr = getattr(facts, "pane", "") or ""
    observed = pane_addr.rsplit(":", 1)[0] if ":" in pane_addr else ""
    if observed and observed != expected_session:
        return None
    members = tmux_session_pane_ids(expected_session)
    if members and pane_id not in members:
        return None
    return expected_session


def entry_observed_dead(entry: dict) -> bool:
    """A registry row is prune-eligible (observed-gone) when nothing live backs it (tap-x077).

    Content checks AND the server-epoch guard compose here (tap-24f): a row is
    prune-eligible when its pane is gone, its pane id was recycled to a
    different identity, its ids were captured under a PRIOR server epoch and
    no live session name vouches for it, or the pane at that id is a bare
    login shell where the row's harness should be (the post-restore shell
    session squat). The earlier claim that this function needed no epoch
    awareness was falsified in the field: a recycled id running any non-shell
    command read as alive, the exact false-KEEP of the 2026-07-24 incident.
    Poll-mode rows have no pane and are never judged here.
    """
    if not isinstance(entry, dict):
        return False
    if entry.get("delivery") == "poll":
        return False

    def session_backs_row() -> bool:
        # A row whose recorded session is live in tmux and not a bare shell session is
        # still backed, even when its stored pane no longer resolves — pane
        # failure alone never condemns a row the session still vouches for.
        session_name = entry_session_name(entry)
        if not session_name or not tmux_has(session_name):
            return False
        return classify_session(session_name) != "shell"

    pane_id = entry.get("pane_id")
    if pane_id is not None and pane_id != "" and not seat_corpse.is_pane_id(pane_id):
        # A damaged stored identity is unobservable. Neither exact-name
        # absence nor an unresolved address may turn it into replacement authority.
        return False
    if not isinstance(pane_id, str) or not pane_id:
        # A row without pane_id that names a pane ADDRESS is legacy residue
        # (pre team/handle migration) — but only observably gone if nothing
        # answers at that address (sol: probe, never assume). An address that
        # resolves, or a row with neither field, stays protected.
        pane_addr = entry.get("pane")
        if not isinstance(pane_addr, str) or not pane_addr:
            return False
        return tmux_pane_facts(pane_addr) is None and not session_backs_row()
    voided_id, _voided_pane = seat_corpse.epoch_voided_ids(entry, current_server_epoch())
    if not voided_id:
        # The stamp names a PRIOR server epoch: the recorded ids are from an
        # earlier server instance, and probing them would consult an unrelated
        # pane on the current one (tap-24f). Only the session NAME can still
        # back the row.
        return not session_backs_row()
    facts = tmux_pane_facts(pane_id)
    if facts is None or facts.pane_id != pane_id:
        return not session_backs_row()
    if not entry.get("server_epoch"):
        session = entry.get("session")
        if (
            isinstance(session, str)
            and session
            and pane_session_name(facts.pane) != session
        ):
            # Unstamped row whose resolving id sits in a DIFFERENT session than
            # its stored provenance: on a reborn server that is the recycled-id
            # ghost (tap-24f). The id alone may not prove life — the row is
            # backed only if its session NAME still vouches for it.
            return not session_backs_row()
    if entry.get("harness") in HARNESSES and pane_harness(facts) not in HARNESSES:
        if not is_login_shell(facts.command):
            return False
        pid = tmux_pane_pid(pane_id)
        return pid is not None and not shell_has_children(str(pid))
    return False


def tmux_pane_pid(pane_id: str) -> int | None:
    try:
        result = verbose.run(
            ["tmux", "display-message", "-p", "-t", pane_id, "#{pane_pid}"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    out = result.stdout.strip()
    return int(out) if out.isdigit() else None


def registry_resume_record(manifest: Manifest, cwd: str, key: str) -> SessionRecord | None:
    entries = registry_entries(root_for_cwd(cwd))
    ordered = [(key, entries[key])] if key in entries else []
    ordered.extend((handle, entry) for handle, entry in entries.items() if handle != key)
    for handle, entry in ordered:
        if entry.get("status", "active") != "active":
            continue
        session_name = entry_session_name(entry)
        if handle != key and session_name != key:
            continue
        harness = entry.get("harness")
        if not session_name or harness not in HARNESSES:
            continue
        return SessionRecord(
            name=session_name,
            harness=harness,
            cwd=cwd,
            base=resolve_base_alias(cwd, manifest),
            tag=handle,
        )
    return None


def live_resume_record(manifest: Manifest, cwd: str, session_name: str) -> SessionRecord | None:
    base = resolve_base_alias(cwd, manifest)
    probe = SessionRecord(name=session_name, harness="", cwd=cwd, base=base)
    facts = tmux_session_pane(probe)
    harness = pane_harness(facts) if facts else None
    if harness not in HARNESSES:
        return None
    parsed = parse_session_name(session_name, {base})
    tag = slash_handle(session_name, base)
    index = 1
    if tag is None and parsed and parsed[0] == harness:
        tag, index = parsed[1], parsed[2]
    return SessionRecord(name=session_name, harness=harness, cwd=cwd, base=base, tag=tag, index=index)


def print_session_error(verb: str, error_class: str, action: str, detail: str) -> None:
    if os.environ.get("TAP_JSON") == "1":
        emit_error_json(error_class, action, detail)
        return
    human_detail = detail.replace("\n", " ").replace("\r", " ") or error_class.replace("_", " ")
    human_action = action if " " in action or "/" in action else action.replace("_", " ")
    print(f"{verb}: {human_detail}; next: {human_action}", file=sys.stderr)


def print_session_exists(handle: str, harness: str, detail: str, next_handle: str | None = None) -> None:
    next_handle = next_handle or "<new-name>"
    resume = f"tap session resume {handle}"
    new = f"tap session launch {harness} {next_handle}"
    fresh = f"tap session launch {harness} {handle} --fresh"
    if os.environ.get("TAP_JSON") == "1":
        emit_error_json("session_exists", resume, detail)
        return
    emit_error_human("session", detail, [resume, new, fresh])


def print_off_roster_tmux_exists(
    name: str,
    harness: str,
    handle: str,
    next_handle: str | None = None,
    created_label: str | None = None,
) -> None:
    """Non-TTY recovery for an off-roster LIVE tmux name collision (Ops #2).

    Create-intent: offer suffix / --fresh / attach pointer — never resume as the
    primary action (resume is named only as the reattach door).
    """
    next_handle = next_handle or "<new-name>"
    created = f"created {created_label}" if created_label else "creation time unknown"
    detail = (
        f"a tmux session named {name} already exists ({created}); "
        f"it is not on the team roster"
    )
    new = f"tap session launch {harness} {next_handle}"
    fresh = f"tap session launch {harness} {handle} --fresh"
    attach = f"tmux attach -t {name}"
    if os.environ.get("TAP_JSON") == "1":
        emit_error_json("session_exists", new, detail)
        return
    emit_error_human(
        "session",
        detail,
        [new, fresh, f"to reattach: {attach}  (or: tap session resume {handle})"],
    )


def claim_pending_handle(
    record: SessionRecord,
    allow_same_session: bool = False,
    live_sessions=_UNSET,
    *, expected_resume_row: dict | None = None, expected_team: str | None = None,
    expected_registry: str | None = None,
) -> dict | None:
    root = root_for_cwd(record.cwd)
    handle = session_handle(record)
    # Refuse BEFORE the lock and before any registry mutation. This is where the
    # launcher CREATES a handle entry; bind_reserved_handle and mark_launch_ready
    # further down the transaction only mutate an entry that can exist because
    # this call succeeded, so guarding here covers the whole ladder.
    if handle in RESERVED_HANDLES:
        raise LauncherError(
            f"handle '{handle}' is reserved as the CLI help keyword and cannot name a seat; "
            "choose another --tag"
        )
    registry = writable_tap_registry_path(root)
    registry.parent.mkdir(parents=True, exist_ok=True)
    lock_path = pathlib.Path(str(registry) + ".lock")
    with reset_fence_mutation_lock("session launch claim"):
        with lock_path.open("w") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            payload = {}
            if registry.exists():
                try:
                    with registry.open() as handle_file:
                        payload = json.load(handle_file)
                except json.JSONDecodeError as exc:
                    raise LauncherError(f"registry unreadable: {exc}") from exc
            team = payload.setdefault("team", {})
            team.setdefault("name", record.base)
            team.setdefault("worktree_root", root)
            _, agents = registry_v20.seat_store(payload)
            existing = agents.get(handle)
            if expected_resume_row is not None:
                # The Bun selector's snapshot is authority only while this same
                # row survives. Compare inside the claim lock, before any write.
                if (expected_registry is None
                    or str(registry.resolve()) != expected_registry
                    or str(writable_tap_registry_path(root).resolve()) != expected_registry):
                    raise LauncherError("tap up: selected registry changed before resume")
                if (team.get("name") != expected_team
                    or json.dumps(existing, sort_keys=True) != json.dumps(expected_resume_row, sort_keys=True)
                    or not _seat_is_relaunchable(existing)):
                    raise LauncherError("tap up: retained seat changed before resume")
                if record.name in tmux_sessions_for_namespace():
                    raise LauncherError("tap up: session appeared before resume; no replacement performed")
                assert_unique_harness_session_identity(
                    _session_state_from_registry_payload(payload, root).sessions,
                    record, "tap up",
                )
            displaced_entry = None
            existing_status = existing.get("status", "active") if isinstance(existing, dict) else None
            if (
                isinstance(existing, dict)
                and existing_status in {"active", "pending", "suspended"}
                and not pending_reservation_expired(existing, live_sessions=live_sessions)
            ):
                # DETECTION vs AUTHORIZATION, deliberately split (tap-24f fix wave).
                # Fork protection asks "does this pane verify as living somewhere
                # else?" — a DETECTOR, which must stay on the fail-OPEN reader so it
                # keeps seeing the elsewhere case; routing it through the
                # fail-closed verifier would make it see LESS and weaken the guard.
                # Authorizing a DISPLACEMENT is the opposite question, and must
                # derive through the same verifier the chooser used to pick
                # record.replaces_session, or a name-provenance target fails its own
                # re-check and a sanctioned replacement reads as "already claimed".
                verified_session = (
                    None
                    if record.kill_backup_required
                    else entry_verified_session_name(existing)
                )
                # Authorize displacement against the SAME incumbent session the
                # chooser set on replaces_session (may be a legacy/noncanonical
                # name — never re-derive team/handle here).
                replacing_incumbent = bool(
                    record.replaces_session
                    and (
                        record.kill_backup_required
                        or (
                            existing_status in {"active", "suspended"}
                            and destructive_session_target(
                            existing, record.replaces_session
                            ) == record.replaces_session
                        )
                    )
                )
                reclaiming_same_session = (
                    allow_same_session
                    and existing_status in {"active", "suspended", "pending"}
                    and existing.get("session") == record.name
                    and (verified_session is None or verified_session == record.name)
                    and (existing_status != "pending" or not existing.get("launch_id"))
                )
                # Ladder rung 3 (tap-x077): a row nothing live backs — pane gone,
                # recycled, shell-squatted, or legacy pane-less residue — never
                # blocks a claim. This is what turns "fable is already claimed"
                # into a silent take-over after a reboot. Guard order (sol): a row
                # whose pane VERIFIES anywhere is running and is never judged gone.
                reclaiming_dead_row = (
                    existing_status in {"active", "suspended"}
                    and verified_session is None
                    and entry_observed_dead(existing)
                )
                if not (replacing_incumbent or reclaiming_same_session or reclaiming_dead_row):
                    next_name = allocate_name(
                        record.base,
                        record.harness,
                        record.tag,
                        occupied_session_names(record.base, root),
                        literal_handle=bool(record.tag),
                    )
                    print_session_exists(
                        handle,
                        record.harness,
                        f"{handle} is already claimed",
                        slash_handle(next_name, record.base) or handle,
                    )
                    raise SystemExit(2)
                displaced_entry = dict(existing)
            if record.kill_backup_required:
                record.kill_backup_has_seat_state = isinstance(existing, dict)
                record.kill_backup_path = write_session_kill_backup(
                    record,
                    dict(existing) if isinstance(existing, dict) else None,
                    dict(team),
                )
            record.launch_id = str(uuid.uuid4())
            # Seat policy and forward-compatible metadata belong to the handle, not
            # to one pane incarnation. Preserve them across resume/restart while
            # replacing only routing and lifecycle fields for this launch.
            same_seat_metadata = (
                existing
                if allow_same_session and isinstance(existing, dict) and existing.get("session") == record.name
                else None
            )
            reservation = dict(displaced_entry or same_seat_metadata or {})
            prior_harness = reservation.get("harness")
            if prior_harness and prior_harness != record.harness:
                reservation.pop("harness_session_id", None)
                reservation.pop("transcript_path", None)
            store_session_record_fields(reservation, record)
            # INSTANTIATION, not recovery: this reservation is where the worktree
            # binding is DECIDED, so it writes unconditionally and must not grow the
            # missing-binding guard native repair carries (tap-94em).
            # Pinned by test_launch_instantiation_decides_the_worktree_binding --
            # this comment explains the exemption, that test enforces it.
            reservation.update({
                "status": "pending",
                "registered_from_worktree": record.cwd if expected_resume_row is not None else root,
                "registered_at": current_timestamp(),
                "launch_id": record.launch_id,
            })
            if record.identity_capture_action in {"new", "resume"}:
                mode = "launcher_new"
                if record.identity_capture_action == "resume" and record.harness_session_id:
                    mode = "exact_resume"
                elif record.identity_capture_action == "resume" and record.harness != "opencode":
                    mode = "untrusted_resume"
                identity_capture = {"mode": mode}
                if record.harness_session_id:
                    identity_capture["expected_harness_session_id"] = record.harness_session_id
                reservation["identity_capture"] = identity_capture
            strip_stale_bindings(reservation)
            boot_id = current_boot_id()
            if boot_id is not None:
                # Stamp the boot epoch so a reservation orphaned by a reboot self-heals
                # (pending_reservation_expired treats a prior-boot stamp as expired).
                reservation["boot_id"] = boot_id
            # WAVE 6.8: post-flip creation door must mint-if-absent (preserve on
            # resume/rebind). bind_reserved_handle / mark_launch_ready carry this
            # row and must not remint.
            if registry_v20.is_flip_live():
                registry_v20.ensure_seat_instance(reservation, handle)
            agents[handle] = reservation
            save_registry(registry, payload)
            return displaced_entry


def stamp_server_epoch(entry: dict, observed_epoch: str | None) -> None:
    """Stamp the generation the entry's pane ids were ACTUALLY observed under,
    and re-check immediately before the commit that it is still current
    (tap-24f, tightened by tap-ua9l finding 7) — call at EVERY write that
    captures pane/pane_id onto an active row, inside the lock, last.

    `observed_epoch` comes from the same tmux record as the ids (PaneFacts).
    It used to be a fresh probe taken after the capture, which is the TOCTOU:
    a rebirth landing in between stamped PRIOR-generation ids as CURRENT,
    manufacturing exactly the false-current row every downstream reader trusts,
    during exactly the event the guard was written for.

    Two rules, and both are refusals rather than repairs:
      * the generation moved since the observation -> raise, do not persist.
        The ids in hand name panes on a server that no longer exists; the
        caller re-observes and retries. Aborting is the only answer that
        cannot launder identity.
      * the observation carried NO generation -> drop the stamp. An
        observation that could not say which server it saw proves nothing, and
        borrowing a generation from a second probe is the defect itself.
    """
    now = current_server_epoch()
    if observed_epoch and now and observed_epoch != now:
        raise LauncherError(
            "tmux server generation moved between observing the pane and "
            f"recording it ({observed_epoch} -> {now}); re-observe and retry"
        )
    if observed_epoch:
        entry["server_epoch"] = observed_epoch
    else:
        entry.pop("server_epoch", None)

    socket = current_server_socket(observed_epoch)
    if socket:
        entry["server_socket"] = socket
    else:
        entry.pop("server_socket", None)


def current_server_socket(observed_epoch: str | None) -> str:
    """Socket provenance is usable only when its generation matches the pane."""
    try:
        result = verbose.run(["tmux", "display-message", "-p", "#{pid}:#{start_time}\t#{socket_path}"],
                             capture_output=True, text=True, timeout=2)
        raw_epoch, separator, socket = (result.stdout or "").strip().partition("\t")
        if (result.returncode == 0 and separator and socket.startswith("/")
                and seat_corpse.observed_server_epoch(raw_epoch) == observed_epoch):
            return socket
    except (OSError, subprocess.SubprocessError):
        pass
    return ""


def stamp_boot_id(entry: dict) -> None:
    """Stamp the machine boot that owns a newly written active binding.

    An unreadable boot observation cannot safely preserve an older stamp: the
    active write just replaced the pane identity, so retaining prior provenance
    would falsely describe the new binding as observed on that earlier boot.
    """
    boot_id = current_boot_id()
    if boot_id is not None:
        entry["boot_id"] = boot_id
    else:
        entry.pop("boot_id", None)


def require_registry_pane_facts(facts: PaneFacts) -> PaneFacts:
    """The one launcher boundary between observed pane facts and a registry write."""
    if not seat_corpse.is_pane_id(facts.pane_id):
        raise LauncherError(
            "identity_unverified: tmux returned invalid pane_id "
            f"{facts.pane_id!r}; refusing registry write; next: verify tmux and retry"
        )
    return facts


def bind_reserved_handle(record: SessionRecord, facts: PaneFacts) -> None:
    """Bind the launch token to its real pane without making it routable."""
    facts = require_registry_pane_facts(facts)
    if not record.launch_id:
        raise LauncherError(f"launch token missing for {record.name}")
    root = root_for_cwd(record.cwd)
    handle = session_handle(record)
    registry = writable_tap_registry_path(root)
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with registry.open() as handle_file:
                payload = json.load(handle_file)
        except (OSError, json.JSONDecodeError) as exc:
            raise LauncherError(f"registry unreadable: {exc}") from exc
        _, agents = registry_v20.seat_store(payload)
        entry = agents.get(handle)
        if not (
            isinstance(entry, dict)
            and entry.get("status") == "pending"
            and entry.get("session") == record.name
            and entry.get("launch_id") == record.launch_id
        ):
            raise LauncherError(f"launch reservation lost for {handle}")
        # INSTANTIATION, not recovery -- the commit half of the reservation
        # above. Same exemption, same reason, same pinning test (tap-94em).
        entry.update({
            "delivery": "pane",
            "permissions": record.permissions or "bypass",
            "status": "active",
            "status_reason": "launching",
            "harness": record.harness,
            "session": record.name,
            "pane": facts.pane,
            "pane_id": facts.pane_id,
            "pane_current_command": facts.command,
            "registered_from_worktree": root,
            "registered_at": current_timestamp(),
        })
        stamp_server_epoch(entry, facts.server_epoch)
        stamp_boot_id(entry)
        entry.pop("wake_url", None)
        save_registry(registry, payload)


def mark_launch_ready(record: SessionRecord, facts: PaneFacts) -> None:
    """Commit a verified harness launch and remove its rollback token."""
    facts = require_registry_pane_facts(facts)
    if not record.launch_id:
        raise LauncherError(f"launch token missing for {record.name}")
    root = root_for_cwd(record.cwd)
    handle = session_handle(record)
    registry = writable_tap_registry_path(root)
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with registry.open() as handle_file:
                payload = json.load(handle_file)
        except (OSError, json.JSONDecodeError) as exc:
            raise LauncherError(f"registry unreadable: {exc}") from exc
        _, agents = registry_v20.seat_store(payload)
        entry = agents.get(handle)
        already_ready = (
            isinstance(entry, dict)
            and entry.get("status") == "active"
            and entry.get("status_reason", "") == ""
            and entry.get("session") == record.name
            and entry.get("harness") == record.harness
            and entry.get("pane") == facts.pane
            and entry.get("pane_id") == facts.pane_id
            and not entry.get("launch_id")
        )
        if already_ready:
            return
        if not (
            isinstance(entry, dict)
            and entry.get("status") == "active"
            and entry.get("status_reason") == "launching"
            and entry.get("session") == record.name
            and entry.get("pane_id") == facts.pane_id
            and entry.get("launch_id") == record.launch_id
        ):
            raise LauncherError(f"bound launch lost for {handle}")
        entry.update({
            "status_reason": "",
            "pane": facts.pane,
            "pane_id": facts.pane_id,
            "pane_current_command": facts.command,
            "registered_at": current_timestamp(),
        })
        stamp_server_epoch(entry, facts.server_epoch)
        stamp_boot_id(entry)
        entry.pop("launch_id", None)
        save_registry(registry, payload)


def launch_claim_matches(entry: dict, record: SessionRecord) -> bool:
    if record.launch_id:
        return entry.get("launch_id") == record.launch_id
    return entry.get("status") == "pending" and entry.get("session") == record.name


def release_pending_handle(record: SessionRecord) -> bool:
    root = root_for_cwd(record.cwd)
    handle = session_handle(record)
    registry = writable_tap_registry_path(root)
    if not registry.exists():
        return False
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with registry.open() as handle_file:
                payload = json.load(handle_file)
        except (OSError, json.JSONDecodeError):
            return False
        _, agents = registry_v20.seat_store(payload)
        existing = agents.get(handle)
        if not (isinstance(existing, dict) and launch_claim_matches(existing, record)):
            return False
        del agents[handle]
        save_registry(registry, payload)
        startup_trace.transition(registry, handle, existing, None, False)
        return True


def restore_replaced_pending_handle(
    record: SessionRecord,
    displaced_entry: dict | None,
    status_reason: str | None = None,
) -> bool:
    if not displaced_entry:
        return False
    root = root_for_cwd(record.cwd)
    handle = session_handle(record)
    registry = writable_tap_registry_path(root)
    if not registry.exists():
        return False
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with registry.open() as handle_file:
                payload = json.load(handle_file)
        except (OSError, json.JSONDecodeError):
            return False
        _, agents = registry_v20.seat_store(payload)
        current = agents.get(handle)
        if not (isinstance(current, dict) and launch_claim_matches(current, record)):
            return False
        restored = dict(displaced_entry)
        if status_reason:
            restored["status"] = "suspended"
            restored["status_reason"] = status_reason
        agents[handle] = restored
        save_registry(registry, payload)
        startup_trace.transition(registry, handle, current, restored, registry_v20.seat_is_relaunchable(restored))
        return True


def rollback_pending_handle(record: SessionRecord, status_reason: str | None = None) -> bool:
    if record.replacement_registry_entry:
        return restore_replaced_pending_handle(
            record,
            record.replacement_registry_entry,
            status_reason,
        )
    return release_pending_handle(record)


def prepare_launch_transaction(
    record: SessionRecord,
    launched_at: str,
    allow_same_session: bool = False,
    failure_reason: str = "repair_failed",
    live_sessions=_UNSET,
    *, expected_resume_row: dict | None = None, expected_team: str | None = None,
    expected_registry: str | None = None,
) -> None:
    record.identity_capture_action = "resume"
    claim_kw = ({} if expected_resume_row is None else {
        "expected_resume_row": expected_resume_row, "expected_team": expected_team,
        "expected_registry": expected_registry,
    })
    displaced = claim_pending_handle(
        record,
        allow_same_session=allow_same_session,
        live_sessions=live_sessions,
        **claim_kw,
    )
    record.replacement_registry_entry = dict(displaced) if displaced else None
    record.launch_failure_reason = failure_reason
    record.launch_failure_argv = [
        sys.executable,
        str(pathlib.Path(__file__).resolve()),
        "_launch-failed",
        launched_at,
        json.dumps(record.failure_dict(), separators=(",", ":")),
        caller_tty(),
    ]


def rollback_launch_transaction(
    record: SessionRecord,
    status_reason: str,
) -> bool:
    return rollback_pending_handle(record, status_reason)


def in_scope(record: SessionRecord, cwd: str, machine: bool) -> bool:
    if machine:
        return True
    return path_is_under(record.cwd, root_for_cwd(cwd))


def frontmatter(path: pathlib.Path) -> dict[str, str]:
    fields: dict[str, str] = {}
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return fields
    if not lines or lines[0] != "---":
        return fields
    for line in lines[1:]:
        if line == "---":
            break
        if ":" in line:
            key, value = line.split(":", 1)
            fields[key] = value.strip()
    return fields


def _inbox_local_team(root: str) -> str:
    """Local bus team for inbox isolation — enrolled key, never invented basename.

    Alias≠basename and relocated acting registries are the live cases: a
    canonical ``<root>/.tap/team-registry.json`` read, or ``basename(root)``
    fallback, both miss valid ``to_team: <enrolled-key>`` and can false-match
    a foreign stamp that happens to equal the directory name (tap-w66z).
    """
    st, name = registry_v20.enrolled_team_name_for_root(root)
    if st == "ok" and name:
        return name
    rst, path = registry_v20.resolve_team_registry_for_root(root)
    if rst == "live_unenrolled":
        return pathlib.Path(os.path.realpath(root)).name
    if rst == "absent":
        for candidate in (
            pathlib.Path(root) / ".tap" / "team-registry.json",
            pathlib.Path(root) / ".tap" / "bus" / "registry.json",
            pathlib.Path(path) if path else None,
        ):
            if candidate is None or not candidate.is_file():
                continue
            try:
                team = (
                    ((json.loads(candidate.read_text()).get("team") or {}).get("name") or "")
                    .strip()
                )
            except Exception:
                team = ""
            if team:
                return team
        return pathlib.Path(root).name
    return ""


def inbox_ids(root: str, handle: str) -> list[str]:
    # WAVE 6.5 / C8: transport home is the BUS home, never registry-path.parent.
    # Post-flip acting registry lives at <root>/.tap/team-registry.json — using
    # .parent made inbox look in .tap/payloads and silently return [].
    from tap_frontmatter import addressed_to_local

    home = pathlib.Path(registry_v20.bus_home(root))
    payloads = home / "payloads"
    receipts = home / "receipts"
    if not payloads.exists():
        return []
    local_team = _inbox_local_team(root)
    ids: list[str] = []
    for path in sorted(payloads.glob("*.md")):
        if path.name.startswith("_"):
            continue
        ident = path.stem
        if (receipts / f"{ident}.done").exists():
            continue
        fields = frontmatter(path)
        if addressed_to_local(fields, handle, local_team):
            ids.append(fields.get("id") or ident)
    return ids


def emit_inbox_digest(record: SessionRecord) -> None:
    handle = session_handle(record)
    ids = inbox_ids(root_for_cwd(record.cwd), handle)
    if not ids:
        return
    shown = ", ".join(ids[:3])
    remaining = len(ids) - 3
    suffix = f" +{remaining}" if remaining > 0 else ""
    print(
        f"tap session inbox: {len(ids)} pending for {handle}: {shown}{suffix}; next: tap poll {handle}",
        file=sys.stderr,
    )


def seat_state(record: SessionRecord) -> str:
    lib = pathlib.Path(__file__).resolve().parents[1] / "lib.sh"
    handle = session_handle(record)
    return seat_state_for_handle(record.cwd, handle)


def seat_state_for_handle(cwd: str, handle: str) -> str:
    lib = pathlib.Path(__file__).resolve().parents[1] / "lib.sh"
    try:
        result = verbose.run(
            ["bash", "-c", f". {shlex.quote(str(lib))}; TAP_SEAT_STATE_READONLY=1 tap_seat_state {shlex.quote(handle)}"],
            cwd=cwd,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return "unknown"
    if result.returncode != 0:
        return "unknown"
    return result.stdout.strip() or "unknown"


def _registry_payload_for_root(root: str) -> dict:
    """The raw team-registry payload for a root, or {} when unreadable.

    Read-only and fail-soft on purpose: its one caller is a refusal message's
    suggestion list, and an unreadable registry there should narrow the advice,
    never raise over the refusal the operator actually needs to see.
    """
    try:
        registry = tap_registry_path(root)
    except RegistryAuthorityError:
        return {}
    if registry is None or not registry.exists():
        return {}
    try:
        with registry.open() as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError):
        return {}


def session_seat_states(record: SessionRecord) -> dict[str, str]:
    root = root_for_cwd(record.cwd)
    try:
        registry = tap_registry_path(root)
    except RegistryAuthorityError:
        return {session_handle(record): seat_state(record)}
    if registry is None or not registry.exists():
        return {session_handle(record): seat_state(record)}
    try:
        with registry.open() as handle_file:
            payload = json.load(handle_file)
    except (OSError, json.JSONDecodeError):
        return {session_handle(record): seat_state(record)}
    agents = registry_v20._seat_map(payload)
    if not agents:
        return {session_handle(record): seat_state(record)}
    handles = [
        handle
        for handle, entry in agents.items()
        if isinstance(entry, dict)
        and entry_session_name(entry) == record.name
        and entry.get("status", "active") == "active"
    ]
    if not handles:
        handles = [session_handle(record)]
    return {handle: seat_state_for_handle(record.cwd, handle) for handle in handles}


def register_resumed_session(record: SessionRecord) -> bool:
    facts, harness = matching_session_pane(record)
    if not facts:
        print(f"tap session resume: session {record.name} is not live")
        return False
    if harness != record.harness:
        print(f"tap session resume: session {record.name} active pane is {harness}, not {record.harness}")
        return False
    root = root_for_cwd(record.cwd)
    handle = session_handle(record)
    existing = registry_entry(root, handle)
    command = [
        "bash",
        str(pathlib.Path(__file__).resolve().parents[1] / "tap.sh"),
        "register",
        handle,
        "--pane",
        facts.pane,
        "--json",
    ]
    if existing and existing.get("cost_mode") in {"subscription", "api"}:
        command.extend(["--mode", existing["cost_mode"]])
    if existing and existing.get("include_policy") in {"always", "on_request"}:
        command.extend(["--include", existing["include_policy"]])
    env = os.environ.copy()
    env.pop("TAP_HOME", None)
    env["TAP_SKIP_VERSION_BRIEFING"] = "1"
    result = verbose.run(command, cwd=root, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip() or "tap register failed"
        print(detail, file=sys.stderr)
        return False
    try:
        receipt = json.loads(result.stdout)["receipt"]
    except (json.JSONDecodeError, KeyError, TypeError):
        print("tap session resume: tap register returned an invalid receipt", file=sys.stderr)
        return False
    registered_handle = receipt.get("handle") if isinstance(receipt, dict) else None
    if not isinstance(registered_handle, str) or not registered_handle:
        print("tap session resume: tap register returned an invalid receipt", file=sys.stderr)
        return False
    if existing is None:
        print(f"tap session resume: registered {registered_handle} (new seat via resume)")
    return True


def finish_resume(record: SessionRecord) -> int:
    return resume_attach_tail(record) if register_resumed_session(record) else 2


def reattach_live_session(session_name: str, record: SessionRecord | None) -> int:
    if not record:
        print(f"tap session resume: cannot identify a TAP seat for live session {session_name}; refusing to attach", file=sys.stderr)
        return 2
    entry = registry_entry(root_for_cwd(record.cwd), session_handle(record))
    if _seat_is_relaunchable(entry, explicit_resume=True) and not _seat_is_relaunchable(entry):
        state = f"suspended/{entry.get('status_reason')}"
        raise LauncherError(
            f"resume refused — {record.name} is live while its retained row is {state}; "
            f"the occupant's native identity is unverified; inspect with "
            f"tmux attach -t {shlex.quote(record.name)} (no registration changed)"
        )
    row = registry_entry(root_for_cwd(record.cwd), session_handle(record))
    if stale_seat_generation(row):
        raise LauncherError(f"resume refused — {record.name} is live but the retained row belongs to a prior boot/server; "
                            f"inspect with tmux attach -t {shlex.quote(record.name)} (no registration changed)")
    return finish_resume(record)


def confirm_rename(root: str, renames: dict[str, str]) -> bool:
    print(f"Rename {len(renames)} existing session/TAP registration(s) under {root}?")
    for old, new in renames.items():
        print(f"  {old} -> {new}")
    if not sys.stdin.isatty():
        print("Non-interactive shell: leaving existing sessions unchanged. Pass --yes to rename.")
        return False
    return prompt_yes_no(
        "session",
        "also rename matching tmux sessions and TAP registrations?",
        default=False,
    )


def warn_adopted_resume(record: SessionRecord, native_query: str | None) -> None:
    if record.harness == "opencode" and native_query is None:
        suffix = "; starting a fresh conversation"
    elif native_query:
        suffix = f" using native resume target {native_query!r}"
    else:
        suffix = " using the native resume picker"
    print(
        f"tap session: no known {record.harness} session found; creating tmux session {record.name!r}{suffix}",
        file=sys.stderr,
    )


def warn_native_resume_fallback(record: SessionRecord) -> None:
    if record.harness_session_id or record.harness == "hermes":
        return
    if record.harness == "opencode":
        print(
            f"tap session: WARNING: {record.name} has no native OpenCode session id; "
            "starting a fresh conversation",
            file=sys.stderr,
        )
        return
    print(
        f"tap session: WARNING: {record.name} has no native {record.harness} "
        "session id; falling back to the native picker",
        file=sys.stderr,
    )


def state_expected_revive_identity(record: SessionRecord) -> None:
    print(
        f"tap session: resuming {record.name}; expected seat {session_handle(record)}",
        file=sys.stderr,
    )


def prompt_session_exists(name: str, harness: str, state_desc: str | None = None,
                          revive_tier_word: str | None = None) -> str:
    # tap-opw9: a LIVE incumbent -> the verb is RESUME (attach), never relaunch; the
    # optional state_desc (composed by describe_session_state at the call site)
    # discloses attached/detached + roster so the found session is legible.
    # tap-7r3fn.24: when no record backs [r], the gloss must say what r will
    # actually DO ("no conversation to resume — start a fresh session under
    # this name") BEFORE the key is pressed, not after it lands in the loop.
    question = f"'{name}' ({harness}): {state_desc}" if state_desc else f"'{name}' already exists ({harness})"
    return prompt_choice(
        "session",
        question,
        (
            ("r", "resume", describe_revive_tier(revive_tier_word) if revive_tier_word
             else "Reattach to the existing session"),
            ("n", "new", "Start another session with a suffix"),
            ("k", "fresh", "Stop the session and start over"),
            ("q", "quit", "Leave everything unchanged"),
        ),
        "r",
    )


def describe_revive_tier(tier: str) -> str:
    """One-line gloss for what [r] would actually do, by resume tier (tap-u3bl)."""
    return {
        "exact": "resume the recorded conversation by its native id",
        "picker": "no live id — resume opens the harness native picker",
        "latest": "no live id — resume continues the latest conversation",
        "fresh": "no conversation to resume — start a fresh session under this name",
    }.get(tier, "resume this seat")


def relative_age(timestamp: str | None) -> str | None:
    """Cheap human age for a stored ISO timestamp (tap-opw9, display only).

    Returns None on a missing/unparseable/future timestamp so the caller omits
    the age fact — "include age if cheap", never a wall or a wrong guess.
    """
    if not timestamp:
        return None
    try:
        then = datetime.datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if then.tzinfo is None:
        then = then.replace(tzinfo=datetime.timezone.utc)
    secs = (datetime.datetime.now(datetime.timezone.utc) - then).total_seconds()
    if secs < 0:
        return None
    if secs < 90:
        return "just now"
    if secs < 90 * 60:
        return f"{round(secs / 60)}m ago"
    if secs < 36 * 3600:
        return f"{round(secs / 3600)}h ago"
    return f"{round(secs / 86400)}d ago"


def describe_session_state(nature: str, seated_handle: str | None, age: str | None) -> str:
    """One scannable line for the found incumbent (tap-opw9): nature · roster · age.

    PURE presentation over predicates the caller already holds — no new
    classification. `nature` is the caller's state phrase (live/shell/gone-row/
    stopped/gone); `seated_handle` the roster handle if enrolled (else None ->
    "not on roster"); `age` a cheap relative age (else None -> omitted). Kept as
    data the verb can never disagree with: the caller pairs it with the verb the
    ladder will actually take (resume reattaches a live seat and recreates a stopped
    or GONE row).
    """
    parts = [nature, f"registered as {seated_handle}" if seated_handle else "not on roster"]
    if age:
        parts.append(age)
    return " · ".join(parts)


def prompt_new_collision(name: str, harness: str, found_state: str, revive_tier_word: str) -> str:
    """Ensure-ladder chooser for a NEW command that landed on a GONE seat
    (tap-u3bl). The v0.8 ladder over-rotated: it removed the chooser entirely
    for gone/shell incumbents and silently routed the operator into resume
    (often the native picker, with no disclosure). panel ruling: a TTY new
    command that finds ANY existing seat under the name must ALWAYS clarify —
    state WHAT was found (live/shell/gone row; native id present or not; resume
    tier exact vs picker) and offer resume / suffix / fresh / quit, every option
    working on a GONE seat.
    """
    return prompt_choice(
        "session",
        f"'{name}' ({harness}): {found_state}",
        (
            # tap-opw9: a GONE incumbent -> the [r] path ALWAYS recreates (every
            # resume tier — exact/picker/latest/fresh — reseats a gone seat, never
            # attaches a live pane), so the verb remains RESUME.
            # Verb-action agreement is the invariant: a RESUME label here must sit on
            # the relaunch path, pinned per state tier in the tests.
            ("r", "resume", describe_revive_tier(revive_tier_word)),
            ("n", "new", "Start a sibling seat under a suffixed name"),
            ("k", "fresh", "Replace it — start a fresh session under this name"),
            ("q", "quit", "Leave everything unchanged"),
        ),
        "r",
    )


def prompt_off_roster_tmux_collision(
    name: str, harness: str, created_label: str | None,
) -> str:
    """TTY chooser for LIVE tmux holding a name with no roster row (Ops #2).

    Launch is create-intent: suffix / replace-under-name / quit only — never
    resume in the create flow. A pointer line names the reattach door separately.
    """
    created = f"created {created_label}" if created_label else "creation time unknown"
    question = (
        f"a tmux session named {name} already exists ({created}); "
        f"it is not on the team roster"
    )
    print(
        f"tap session: to reattach: tmux attach -t {name}  "
        f"(or: tap session resume <handle>)",
        file=sys.stderr,
    )
    return prompt_choice(
        "session",
        question,
        (
            ("n", "new", "Start another session with a suffix"),
            ("k", "fresh", "Stop the session and start over under this name"),
            ("q", "quit", "Leave everything unchanged"),
        ),
        "n",
    )


def resolve_new_record_tuning(
    args,
    existing_record: SessionRecord | None,
    resurrect: bool,
) -> tuple[str | None, list[str], dict[str, str], dict[str, str] | None, bool]:
    """Apply built-in/inherited, preset, then explicit-CLI launch precedence."""
    resolved = getattr(args, "preset_resolution", None)
    tuning = resolve_adhoc_tuning(args) if resolved is None else None
    values = _preset_bridge.call("launch.tuning",
        preset=dataclasses.asdict(resolved) if resolved is not None else None,
        inherited=dataclasses.asdict(existing_record) if resurrect and existing_record else None,
        tuning=dataclasses.asdict(tuning) if tuning is not None else None,
        model=getattr(args, "model", None), harness=getattr(args, "harness", None))
    return tuple(values)


def parse_env_assignments(raw: list[str] | None) -> dict[str, str]:
    return _preset_bridge.call("launch.env_assignments", values=raw or [])


def resolve_adhoc_tuning(args) -> presets.ResolvedTuning:
    """Validate argv-supplied tuning through the same fence preset tables face.

    Tuning flags translate through ``presets.TUNING_CAPABILITIES``: a supported axis
    becomes the harness's real flag spelling, an unsupported axis or a value outside a
    published domain refuses before the pane spawns. OQ4's refuse-always on agy ``--model``
    was the stopgap while the builder had no plumbing; the table is the replacement.
    """
    model = getattr(args, "model", None)
    effort = getattr(args, "effort", None)
    raw_env = parse_env_assignments(getattr(args, "env", None))
    # Suppliedness, not truthiness: `--model ""` is supplied and invalid. Treating it as absent
    # would hand an empty string to the record instead of refusing it, and would let it slip
    # past preset exclusivity as though nothing had been passed.
    if model is None and effort is None and not raw_env:
        return presets.ResolvedTuning(model=None, harness_passthrough=(), env={})
    harness = getattr(args, "harness", None)
    if harness is None:
        # Per-harness support cannot be judged without a harness. Rather than invent one, judge
        # only what is harness-independent — the env fence. Reaching here means a caller built a
        # partial Namespace; the launch doors that delegate to resume now refuse tuning outright
        # (refuse_tuning_on_resume_delegation) rather than arriving here with flags to drop.
        model = None
        effort = None
    explicit_passthrough = list(getattr(args, "harness_passthrough", None) or [])
    if effort and explicit_passthrough:
        raise presets.PresetError(
            "launch_arg_invalid",
            "pass effort one way: --effort, or the harness passthrough flag, not both",
            "--effort conflicts with an explicit harness passthrough vector",
        )
    return presets.resolve_tuning(
        harness=harness,
        model=model,
        effort=effort,
        raw_env=raw_env or None,
        context=presets.cli_tuning_context(),
    )


def fresh_launch_session_id(harness: str) -> str | None:
    """Mint the launcher-attested identity required by a fresh Claude seat."""
    return str(uuid.uuid4()) if harness == "claude" else None


def make_new_record(args, manifest: Manifest) -> SessionRecord:
    if args.unique and getattr(args, "fresh", False):
        raise LauncherError("--fresh is not supported with --unique exact session names")
    cwd = str(pathlib.Path.cwd().resolve())
    base = resolve_base_alias(cwd, manifest)
    root = root_for_cwd(cwd)
    # Allocation is a namespace mutation. One snapshot supplies the whole
    # decision; only tmux's recognized no-server answer is empty for this
    # create-capable path. Every other observation failure stays UNKNOWN.
    live_sessions = tmux_sessions_for_namespace()
    history: list[str] = []
    replaces_session: str | None = None
    replaces_manifest_session: str | None = None
    replacement_record: dict | None = None
    kill_backup_required = False
    existing_record: SessionRecord | None = None
    record_resumable = False
    resurrect = False
    resurrect_action = "resume"
    resurrect_vessel: str | None = None
    # tap-8qj7: identity ADOPTED from a manual seat's registry row (no manifest
    # record) on first-contact resume, and whether the resulting record is so marked.
    adopted_id: str | None = None
    adopt_from_manual = False
    reclaim_receipts: list[str] = []
    if args.unique:
        name = validate_exact_name(args.unique)
        tag = slash_handle(name, base)
        index = None
    else:
        tag = args.tag or args.label
        preset_derived = False
        if not tag:
            # Ops's rider (2026-08-14): a preset-launched seat defaults to the
            # preset name so seat-calibration entries match mechanically.
            # Direct harness launches still default to the harness via allocate_name.
            resolution = getattr(args, "preset_resolution", None)
            if resolution is not None:
                tag = resolution.provenance.name
                preset_derived = True
        if preset_derived and tag in RESERVED_HANDLES:
            # Refuse before registry/tmux: a catalog name of `help` would otherwise
            # proceed into collision/claim and only fail at claim_pending_handle.
            raise LauncherError(
                f"handle '{tag}' is reserved as the CLI help keyword and cannot name a seat; "
                "pass an explicit seat name, or rename the preset"
            )
        if tag:
            # SANITIZE ONLY WHAT IS NOT ALREADY LEGAL. This decides cleaning, and
            # nothing else — deliberately NOT folded into `preset_derived`, which
            # also selects the session-name construction and the collision-suffix
            # arm (opus-door: that flag is wider than its name).
            #
            # sanitize_component maps the dot in `review.er` onto `review-er`, so
            # `launch zzp review.er` seated a different handle than
            # `crew add zzp review.er` — the two doors this PR standardized
            # disagreeing on identical input, and a silent collision with any real
            # `review-er`. Handles permit dots (TAP_ID_RE), so a name that already
            # satisfies that charset needs no cleaning; anything else still does.
            tag_is_literal = bool(
                preset_derived or _HANDLE_TOKEN_RE.fullmatch(tag)
            )
            if tag_is_literal:
                tag = normalize_tag(args.harness, tag)
            else:
                tag = normalize_tag(args.harness, sanitize_component(tag))
        if tag:
            # named_session_name sanitizes AGAIN, independently of the decision
            # above — so a dotted handle survived the first branch and lost its
            # dot here. Both spellings have to agree, or the tag and the session
            # name disagree about the same seat.
            requested_name = (
                session_name_for_handle(base, tag)
                if tag_is_literal
                else named_session_name(base, tag)
            )
            name = requested_name
            index = 1
            existing_record = find_record_by_key(manifest.sessions, cwd, tag)
            existing_entry = registry_entry(root, tag)
            # U5 / Ops 2026-07-30 intent-verb rule: launch collision consults the
            # ROSTER and live tmux only. A departed handle (no roster row) with a
            # leftover manifest/history artifact is create-intent — never a
            # history-restore suggestion. Manifest-only STOPPED records (post-flip
            # the manifest is retired state, not seat state) must not feed the
            # collision picker. GONE (row present, session not live) still
            # occupies the name; launch reseats it — history restore is resume only.
            record_resumable = existing_record is not None and record_has_resume_artifact(existing_record)
            seated = tag in tap_handles(root)
            live = name in live_sessions
            live_or_seated = live or seated
            if live_or_seated:
                # Recovery launch commands must retain the preset selection.
                launch_target = tag if preset_derived else args.harness
                scoped_records = records_for_root(manifest.sessions, cwd)
                occupied = (
                    occupied_session_names(base, root, live_sessions)
                    # This block exists because the requested handle is seated
                    # or its exact tmux name is live. Even when the allocator
                    # treats an inactive row's name as available for replacement, the
                    # picker's explicit "different handle" door must not offer
                    # the incumbent name again.
                    | {name}
                    | {record.name for record in scoped_records}
                    | {session_name_for_handle(base, session_handle(record)) for record in scoped_records}
                )
                next_name = allocate_name(
                    base, args.harness, tag, occupied, literal_handle=preset_derived
                )
                next_handle = slash_handle(next_name, base) or tag
                incumbent_harness = existing_record.harness if existing_record else (existing_entry or {}).get("harness") or args.harness
                # Ensure ladder (tap-x077): a name is only a COLLISION when
                # something live or unobservable holds it. Gone seats — shell session
                # sessions, gone registry rows, bare resumable records — are
                # absorbed without a prompt; the receipt narrates what
                # happened. The chooser survives for live seats, busy
                # vessels, attached shell sessions, and unverifiable state.
                classification = classify_session(name) if name in live_sessions else "absent"
                entry_alive_elsewhere = None
                if isinstance(existing_entry, dict):
                    verified_elsewhere = entry_verified_session_name(existing_entry)
                    if verified_elsewhere is not None and verified_elsewhere != name:
                        entry_alive_elsewhere = verified_elsewhere
                entry_dead = isinstance(existing_entry, dict) and entry_observed_dead(existing_entry)
                # tap-u3bl disclosure inputs: the true resume tier the [r] option
                # would take, computed from the SAME resumability gate the launch
                # uses. A stale native id whose conversation artifact is gone
                # (record_resumable False) correctly reports "picker" — so the
                # chooser never promises an exact resume it can't deliver, and the
                # exit-1 stale-id specimen is disclosed instead of silently
                # teleporting into the picker.
                disclosed_revive_id = (
                    existing_record.harness_session_id
                    if record_resumable and existing_record
                    else None
                )
                revive_tier_word = revive_tier(args.harness, disclosed_revive_id)

                def undead_found_state() -> str:
                    if classification == "shell":
                        return "an unattended shell session is holding the name"
                    if entry_dead:
                        addr = existing_entry.get("pane") or existing_entry.get("pane_id") or "no pane on record"
                        return f"a gone seat row ({addr})"
                    if existing_record is not None:
                        return "a stopped session record, no live pane"
                    return "the name is registered but its session is gone"

                # tap-opw9: predicates the state line composes from — all already
                # computed here, no new classification. Roster handle from `seated`;
                # age from the cheapest stored stamp on the record or the gone row.
                roster_handle = tag if seated else None

                def incumbent_age() -> str | None:
                    if existing_record is not None:
                        return relative_age(existing_record.last_seen or existing_record.last_launched)
                    if isinstance(existing_entry, dict):
                        return relative_age(existing_entry.get("exited_at") or existing_entry.get("last_seen"))
                    return None

                if getattr(args, "new", False):
                    choice = "n"
                elif getattr(args, "fresh", False):
                    # Explicit stop authority keeps its pre-ladder semantics;
                    # the k-branch guards still refuse a conflicting live
                    # target with the specific reconcile error.
                    choice = "k"
                elif preset_derived and entry_dead:
                    # Only observed-gone preset rows keep automatic suffixing.
                    # A live or unobservable incumbent needs the ordinary
                    # chooser (tap-7r3fn.131); --new remains explicit above.
                    choice = "n"
                elif entry_alive_elsewhere is not None:
                    # Fork protection preflight (sol): the handle verifiably
                    # lives in another session — never absorbed silently.
                    # grok P2: gate the chooser on caller_has_tty() (BOTH streams),
                    # the SAME predicate resolve_attach_mode uses — never stdin-only.
                    # A stdin-PTY/stdout-piped agent runner would take the detached
                    # launch path yet still hit a stdin-only chooser and STALL on the
                    # prompt; aligning both decisions on one predicate closes that gap
                    # (a partial-TTY caller falls to the non-interactive exit-2 path).
                    if caller_has_tty() and not args.dry_run:
                        choice = prompt_session_exists(
                            name, incumbent_harness,
                            describe_session_state(f"live in {entry_alive_elsewhere}", roster_handle, None),
                        )
                    else:
                        print_session_exists(tag, launch_target, f"{tag} is live in {entry_alive_elsewhere}", next_handle)
                        raise SystemExit(2)
                elif (
                    classification == "shell"
                    and not preset_derived
                    and (existing_record is None or existing_record.harness == args.harness)
                ):
                    # A live shell is holding the session name. TTY: clarify.
                    # Non-TTY: reseat fresh under the name (create-intent, no
                    # history restore). Never default to continuing a past chat.
                    if caller_has_tty() and not args.dry_run:
                        choice = prompt_new_collision(
                            name, incumbent_harness,
                            describe_session_state(undead_found_state(), roster_handle, incumbent_age()),
                            "fresh",
                        )
                        if choice == "r":
                            # [r] under U5 on a shell vessel means reseat fresh
                            # under this name, not history restore.
                            choice = "k"
                    else:
                        choice = "k"
                elif classification == "live" and not seated:
                    # Ops refinement #2: LIVE tmux, no roster row — tmux-namespace
                    # collision stated as tmux fact. Create flow never offers resume.
                    created_label = tmux_session_created_label(name)
                    if caller_has_tty() and not args.dry_run:
                        choice = prompt_off_roster_tmux_collision(
                            name, incumbent_harness, created_label,
                        )
                    else:
                        print_off_roster_tmux_exists(
                            name, launch_target, tag, next_handle, created_label,
                        )
                        raise SystemExit(2)
                elif entry_dead and caller_has_tty() and not args.dry_run:
                    # A GONE seat row still occupies the name, and under the U5
                    # intent-verb rule above launch RESEATS it — history restore is
                    # `tap session resume` only. So the door is the reseat chooser,
                    # whose [r] sits on the relaunch path, not the attach chooser,
                    # whose [r] reattaches to a session that is not there.
                    #
                    # The verdict routing this arm is not new work: entry_dead is
                    # entry_observed_dead()'s epoch-aware answer, computed above and
                    # until now spent only on the prose in undead_found_state() while
                    # routing happened on `name in live_sessions` alone. That gap is
                    # what let a roster-seated, tmux-absent, manifest-recordless
                    # incumbent reach the attach chooser, whose [r] forwarded into a
                    # cold cmd_resume, whose create-fallback re-entered cmd_new and
                    # arrived back here with nothing changed — a dialog cycle the
                    # operator could not escape through [r] (tap-jcma).
                    choice = prompt_new_collision(
                        name, incumbent_harness,
                        describe_session_state(undead_found_state(), roster_handle, incumbent_age()),
                        # The gloss must describe what [r] will DO here, and that
                        # depends on whether a record survives to resume FROM. With
                        # no record there is no conversation, so the honest word is
                        # "fresh" -- the same literal the shell-vessel arm passes.
                        # Passing revive_tier_word unconditionally advertised a
                        # picker or an exact id that the mapping below then replaced.
                        revive_tier_word if existing_record is not None else "fresh",
                    )
                    if choice == "r" and existing_record is None:
                        # Only the RECORDLESS gone row reseats. With nothing to
                        # resume from, [r] under U5 means reseat fresh under this
                        # name; [k] already handles a gone row and its receipt.
                        #
                        # A gone row that still HAS a record keeps [r] on the resume
                        # delegation below. Mapping it to fresh would discard a
                        # recorded conversation while the gloss promised to restore
                        # it -- the same verb-action disagreement this arm exists to
                        # end, committed on the door that replaced it.
                        #
                        # (tap-7r3fn.24) This comment used to claim "the loop cannot
                        # return through that path: cmd_resume only reaches its
                        # create-fallback when no record is found." It is refuted:
                        # a live session with no record takes the generic chooser
                        # below, whose [r] DID reach the create-fallback and re-enter
                        # cmd_new — the unescapable dialog. The create-fallback no
                        # longer re-enters; it launches fresh through the extracted
                        # launcher and states the miss in one line.
                        choice = "k"
                elif caller_has_tty() and not args.dry_run:  # grok P2: both-streams predicate
                    # On-roster (or busy/unobservable) resume=attach chooser.
                    # tap-opw9: only claim "live, attached/detached" when the
                    # session is GENUINELY live in tmux (classification=="live").
                    if classification == "live":
                        attached = session_attached(name)
                        live_nature = (
                            "live" if attached is None
                            else "live, attached" if attached
                            else "live, running detached"
                        )
                        live_desc = describe_session_state(live_nature, roster_handle, None)
                    else:
                        live_desc = None
                    # tap-7r3fn.24: with no record, [r] cannot reattach — it
                    # can only start fresh. Advertise THAT before the press.
                    choice = prompt_session_exists(
                        name, incumbent_harness, live_desc,
                        revive_tier_word if existing_record is not None else "fresh",
                    )
                else:
                    print_session_exists(tag, launch_target, f"{name} already exists", next_handle)
                    raise SystemExit(2)

                if choice == "r":
                    refuse_tuning_on_resume_delegation(args, "the collision chooser's resume arm")
                    raise SystemExit(cmd_resume(argparse.Namespace(
                        key=incumbent_harness,
                        legacy_name=tag,
                        harness=incumbent_harness,
                        all=False,
                        model=args.model,
                        teams=args.teams,
                        dry_run=args.dry_run,
                    )))
                if choice == "n":
                    name = next_name
                    suffix = name.removeprefix(f"{requested_name}-")
                    index = int(suffix) if suffix.isdigit() else 1
                # A branch handling choice == "resurrect" stood here and had never
                # executed: no code path has ever assigned that value to `choice`
                # (confirmed by grep and by `git log -S` over the whole file history),
                # and a raise planted at its head left all 475 launcher tests
                # byte-identically green. It was removed rather than wired up by
                # tap-jcma, whose loop it superficially appeared to handle -- a reader
                # tracing the ladder found an [r]-handling arm and concluded the gone
                # incumbent was covered. Reseating a gone row goes through [k], which
                # is live and exercised. `resurrect` is consequently always False, so
                # the machinery it still gates downstream is unreachable too; removing
                # it changes a tuning-precedence signature and is tracked separately.
                elif choice == "k":
                    kill_backup_required = True
                    if existing_record:
                        history = list(existing_record.history)
                        if existing_record.harness_session_id and existing_record.harness_session_id not in history:
                            history.append(existing_record.harness_session_id)
                        replacement_record = existing_record.to_dict()
                        if record_resumable and existing_record.harness_session_id:
                            reclaim_receipts.append(
                                f"reseated {name} fresh (previous {existing_record.harness} conversation "
                                f"{existing_record.harness_session_id} kept in history)"
                            )
                    # [k] is explicit replacement authority (Ops 2026-08-06):
                    # the picker scoped the target by canonical session name and
                    # the operator chose fresh. A stale, absent, or recycled pane
                    # hint is the reason to stop, never a veto or an alternate
                    # target. Backup-before-stop supplies the recovery boundary.
                    expected_session = requested_name
                    if entry_dead:
                        reclaim_receipts.append(f"reclaimed dead seat row '{tag}' ({existing_entry.get('pane') or existing_entry.get('pane_id') or 'no pane on record'})")
                    # Stop-by-name: the authorized incumbent session.
                    replaces_session = expected_session
                    replaces_manifest_session = existing_record.name if existing_record else None
                else:
                    raise SystemExit(2)
            if existing_record is not None and not live_or_seated:
                # Departed / manifest-only residue — launch creates fresh (U5
                # intent-verb). Surface the ignore so an operator is never
                # surprised; history restore is `tap session resume` only.
                print(
                    f"tap session: ignoring leftover record {name} — not on roster; "
                    f"launch creates a new seat (tap session resume {tag} to restore history)",
                    file=sys.stderr,
                )
        else:
            name = allocate_name(base, args.harness, None, occupied_session_names(base, root, live_sessions))
            index = allocated_index(name, base, args.harness)
    inherited_id: str | None = None
    inherited_transcript: str | None = None
    if resurrect and resurrect_action == "resume" and record_resumable and existing_record:
        inherited_id = existing_record.harness_session_id
        inherited_transcript = existing_record.transcript_path
    elif resurrect and resurrect_action == "resume" and adopt_from_manual and adopted_id:
        # Adopted a verified conversation id from the manual seat's registry row
        # (tap-8qj7 rider r1) — carry it onto the backfilled record so resume uses
        # --conversation, not --continue.
        inherited_id = adopted_id
    if resurrect and resurrect_action == "resume":
        session_id = inherited_id
    else:
        session_id = fresh_launch_session_id(args.harness)
    model, harness_passthrough, harness_env, preset, passthrough_from_config = (
        resolve_new_record_tuning(args, existing_record, resurrect)
    )
    record = SessionRecord(
        name=name,
        harness=args.harness,
        cwd=cwd,
        base=base,
        tag=tag,
        index=index,
        model=model,
        harness_passthrough=harness_passthrough,
        passthrough_from_config=passthrough_from_config,
        harness_env=harness_env,
        preset=preset,
        harness_session_id=session_id,
        transcript_path=inherited_transcript,
        adopted_from_manual=adopt_from_manual,
        history=history,
        replaces_session=replaces_session,
        replaces_manifest_session=replaces_manifest_session,
        replacement_record=replacement_record,
        kill_backup_required=kill_backup_required,
        ensure_action=resurrect_action if resurrect else "new",
        ensure_vessel=resurrect_vessel,
        ensure_receipts=reclaim_receipts,
    )

    if resurrect and existing_record and getattr(args, "preset_resolution", None) is None:
        record.harness_tail = list(existing_record.harness_tail)
        record.harness_unset_env = list(existing_record.harness_unset_env)
    return apply_session_overrides(record, {
        "env": getattr(args, "env", None) or [],
        "unset_env": getattr(args, "unset_env", None) or [],
        "argv": getattr(args, "harness_passthrough", None) or [],
    })


def apply_session_overrides(record: SessionRecord, overrides: dict) -> SessionRecord:
    values = _preset_bridge.call("launch.overrides", recipe={
        "harness_env": record.harness_env,
        "harness_unset_env": record.harness_unset_env,
        "harness_tail": record.harness_tail,
    }, overrides=overrides)
    return dataclasses.replace(record, **values)


def make_adopted_resume_record(
    args,
    manifest: Manifest,
    cwd: str,
    occupied_names: set[str],
) -> tuple[SessionRecord, str | None]:
    base = resolve_base_alias(cwd, manifest)
    resume_name = getattr(args, "resume_query", None)
    if resume_name is None:
        resume_name = getattr(args, "name", None)
    if resume_name == args.harness:
        resume_name = None
    native_query = resume_name
    default_tag = default_tag_for_model(args.model)
    tag = normalize_tag(args.harness, resume_name or default_tag)
    record_name: str
    index: int

    if not resume_name:
        native_query = None
        record_name = allocate_name(base, args.harness, tag, occupied_names)
        index = allocated_index(record_name, base, args.harness)
    else:
        expanded_name = expand_resume_shorthand(resume_name, args.harness, base, default_tag)
        parsed_name = expanded_name or resume_name
        parsed = parse_session_name(parsed_name, {base})
        if parsed and parsed[0] == args.harness:
            tag = normalize_tag(args.harness, parsed[1])
            index = parsed[2]
            record_name = parsed_name
            if re.fullmatch(r"\d+", resume_name):
                native_query = None
            if record_name in occupied_names:
                record_name = allocate_name(base, args.harness, tag, occupied_names)
                index = allocated_index(record_name, base, args.harness)
        else:
            record_name = allocate_name(base, args.harness, tag, occupied_names)
            index = allocated_index(record_name, base, args.harness)

    return (
        SessionRecord(
            name=record_name,
            harness=args.harness,
            cwd=cwd,
            base=base,
            tag=tag,
            index=index,
            model=args.model,
        ),
        native_query,
    )


def upsert_record(records: list[SessionRecord], record: SessionRecord) -> list[SessionRecord]:
    return [
        existing
        for existing in records
        if not (existing.harness == record.harness and existing.name == record.name)
    ] + [record]


def new_label_requests_resume(args) -> bool:
    return bool(args.label and not args.tag and not args.unique and re.fullmatch(r"\d+", args.label))


def run_native_resume(
    record: SessionRecord,
    native_query: str | None,
    dry_run: bool,
    json_output: bool = False,
    attach: bool = True,
) -> int:
    invocation = compose_child_invocation(
        build_native_resume_invocation(record, native_query),
        record,
    )
    rc = run_invocation(
        record,
        invocation,
        dry_run,
        attach=False,
        launch_failure_argv=record.launch_failure_argv,
        json_output=json_output,
    )
    if rc != 0 or dry_run:
        return rc
    if attach:
        return resume_attach_tail(record)
    return rc


def run_adopted_resume(args, state: Manifest, cwd: str) -> int:
    if not getattr(args, "harness", None):
        raise LauncherError("resume key not found; pass a known handle or harness family")
    refuse_if_team_reset_fenced("session resume")
    _reset_fence_entry_barrier()
    record, native_query = make_adopted_resume_record(
        args,
        state,
        cwd=cwd,
        occupied_names=occupied_session_names(resolve_base_alias(cwd, state), root_for_cwd(cwd)),
    )
    launched_at = current_timestamp()
    record = stamp_launched(record, launched_at)
    warn_adopted_resume(record, native_query)
    state_expected_revive_identity(record)
    json_kw = {"json_output": True} if getattr(args, "json", False) else {}
    if args.dry_run:
        return run_native_resume(record, native_query, True, attach=False, **json_kw)

    # fable 084245: outer sidecar claim → run → ready/rollback; attach stays outside.
    with reset_fence_mutation_lock("session resume"):
        try:
            prepare_launch_transaction(record, launched_at)
            mark_reset_generation_reused("session-resume")
            rc = run_native_resume(record, native_query, False, attach=False, **json_kw)
        except BaseException:
            if record.launch_id:
                rollback_launch_transaction(record, "repair_failed")
            raise
        if rc != 0:
            rollback_launch_transaction(record, "repair_failed")
            return rc
    return resume_attach_tail(record)


def _acting_team_registry_path(cwd: str) -> pathlib.Path | None:
    """Resolve the team registry that owns membership for team up (U4 bridge).

    WHO comes from this file; the launcher manifest supplies lineage only.
    Delegates to ``registry_v20.resolve_team_registry_for_root`` (WAVE 6) —
    never returns the bus decoy under live or invalid.
    """
    try:
        root = root_for_cwd(cwd)
    except Exception:
        root = str(pathlib.Path(cwd).resolve())
    status, path = registry_v20.resolve_team_registry_for_root(root)
    if status in ("invalid", "live_unreachable") or not path:
        return None
    return pathlib.Path(path)



# ONE shared relaunch predicate — owned by registry_v20 (migrate session-assert
# and resume-all membership/synthesize must not drift; opus 101428).
_seat_is_relaunchable = registry_v20.seat_is_relaunchable


def _require_relaunchable_resume_member(cwd: str, record: SessionRecord, *, explicit_resume: bool = False) -> None:
    """WAVE 6.9 / 3682625620: refuse single-seat resume without relaunchable membership.

    Covers early ``reattach_live_session`` returns and the later launch
    transaction — an archived-only / ``user_removed`` session must not recreate
    membership via tap-register. Pre-flip (``None``) stays ungated.
    """
    current = _current_registry_handles(cwd)
    if current is None:
        return
    handle = session_handle(record)
    if handle not in current:
        if explicit_resume and _seat_is_relaunchable(registry_entry(root_for_cwd(cwd), handle), explicit_resume=True):
            return
        raise LauncherError(
            f"resume refused — '{handle}' is not a relaunchable current "
            f"seat in the acting registry (archived-only or non-relaunchable); "
            f"use tap session launch for a new seat, or restore membership first"
        )


def _current_registry_handles(cwd: str) -> set[str] | None:
    """Relaunchable current handles (R6/R11 + 3681754856 shared predicate).

    None = pre-flip and no registry found (legacy: no membership gate).
    Empty set = flip-live miss / unreadable / no seats — refuse registry relaunch
    (codex 5542; manifest loses authority). Membership = relaunchable row in the
    acting registry (``_seat_is_relaunchable``). Manifest-only records are never
    members.
    """
    path = _acting_team_registry_path(cwd)
    if path is None:
        # live / invalid / live_unreachable → empty set (fail-closed membership).
        # Only genuine pre-flip (marker absent) leaves the gate ungated (None).
        state = registry_v20.flip_marker_state()
        if state in ("live", "invalid"):
            return set()
        return None
    try:
        registry = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return set()
    if not isinstance(registry, dict):
        return set()
    handles: set[str] = set()
    for handle, entry in registry_v20._seat_map(registry).items():
        if not _seat_is_relaunchable(entry):
            continue
        handles.add(handle)
    return handles


def team_except_handles() -> set[str]:
    """The `tap team up --except` set, already parsed and roster-gated in bash.

    tap-team.sh owns the ONE parse/validate path for every lifecycle verb
    (lib.sh ``tap_except_*``); by the time the value reaches here it is a
    deduped, charset-checked, roster-checked newline blob. This is verb-internal
    wiring, not a public flag: `session resume --all` has no `--except` of its
    own, so there is no second door that skips the gate. Popped rather than read
    so a resumed seat does not inherit a stale exclusion in its environment.
    """
    return {h for h in os.environ.pop("TAP_TEAM_EXCEPT_HANDLES", "").splitlines() if h}


def team_only_handles() -> set[str]:
    """The `tap team up --only` set, already parsed and roster-gated in bash.

    Same wiring and same guarantees as ``team_except_handles`` — deduped,
    charset-checked, roster-checked, and popped so a resumed seat inherits
    nothing. It arrives UNRESOLVED, and so does every other verb's: no lifecycle
    verb precomputes a complement in bash any more (tap-sttl). Each asks the
    spared question per row against the snapshot it is about to act on, because
    a complement resolved from an earlier registry read goes stale — a seat
    registering in that window was absent from it and so was acted on though the
    operator never named it.

    Resume is the verb whose snapshot lives here in Python, so its resolution
    does too. It is also the one where the handle mapping can differ:
    ``session_handle`` derives a handle from the record itself when
    ``SessionRecord.tag`` is unset, so a candidate need not have a registry row
    at all. Resolving against ``in_scope_records`` — the list the caller holds
    and the only description of what resume would actually touch — covers such a
    record; resolving against the registry would not.
    """
    return {h for h in os.environ.pop("TAP_TEAM_ONLY_HANDLES", "").splitlines() if h}


def only_to_excepted(records, only: set[str]) -> set[str]:
    """Resolve an ``--only`` selection to the exclusion set it implies.

    Complements against the CANDIDATE RECORDS rather than the registry roster:
    a record whose ``tag`` is unset still yields a handle through
    ``session_handle``, and that handle may have no registry row. Complementing
    against the registry would omit it from the spared set and resume a seat the
    operator never named.

    A pure function on purpose — the resolution is the part worth pinning, and
    inline in ``cmd_resume_all`` it could only be reached through a full resume.
    """
    return {
        handle
        for handle in (session_handle(record) for record in records)
        if handle not in only
    }


def stale_seat_generation(entry: dict, observation=None) -> bool:
    """Only a readable, same-socket observation can prove a stored stamp stale."""
    if not isinstance(entry, dict):
        return False
    if observation is None:
        epoch = current_server_epoch()
        observation = (current_boot_id(), epoch, current_server_socket(epoch))
    boot, epoch, socket = observation
    if not epoch or not socket or entry.get("server_socket") != socket:
        return False
    old_boot, old_epoch = entry.get("boot_id"), entry.get("server_epoch")
    def boot_kind(value):
        if not isinstance(value, str):
            return None
        if re.fullmatch(r"boot:[0-9]+", value):
            return "seconds"
        if re.fullmatch(r"bootuuid:[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", value):
            return "uuid"
        return None
    def valid_epoch(value):
        return isinstance(value, str) and re.fullmatch(r"srv:[0-9]+:[0-9]+", value)
    if old_boot and (not boot_kind(old_boot) or boot_kind(old_boot) != boot_kind(boot)):
        return False
    if old_epoch and (not valid_epoch(old_epoch) or not valid_epoch(epoch)):
        return False
    return bool((old_boot and boot and not boot_ids_match(old_boot, boot))
                or (old_epoch and epoch and old_epoch != epoch))


def reboot_resume_records(cwd: str, observation) -> list[SessionRecord]:
    root = root_for_cwd(cwd)
    records = []
    for handle, row in registry_entries(root).items():
        if (row.get("crew") or row.get("delivery") != "pane"
            or row.get("status") != "suspended"
            or row.get("status_reason") not in ("pane_gone", "session_replaced", "repair_failed", "restart_failed")
            or not stale_seat_generation(row, observation)):
            continue
        record = session_record_from_registry_row(handle, row, {"worktree_root": root}, root)
        if record:
            records.append(record)
    return records


def cmd_resume_all(args, state: Manifest, cwd: str) -> int:
    if getattr(args, "key", None) or getattr(args, "legacy_name", None):
        raise LauncherError("usage: tap session resume --all [--dry-run]")
    # Honor fence independently when entered via tap team up / resume --all
    # without going through cmd_resume's entry barrier (fable 084245).
    refuse_if_team_reset_fenced("session resume")
    _reset_fence_entry_barrier()
    _refuse_if_flip_authority("tap session resume", cwd=cwd)
    live_names = tmux_sessions_for_namespace()
    epoch = current_server_epoch()
    observation = (current_boot_id(), epoch, current_server_socket(epoch))
    prior_names = {record.name for record in state.sessions}
    recovered = [record for record in reboot_resume_records(cwd, observation) if record.name not in prior_names]
    state = dataclasses.replace(state, sessions=[*state.sessions, *recovered])
    excepted = team_except_handles()
    only = team_only_handles()
    in_scope_records = [record for record in state.sessions if in_scope(record, cwd, machine=False)]
    if only:
        # bash already refused the two flags together, so this cannot overwrite a
        # caller-supplied exception set.
        excepted = only_to_excepted(in_scope_records, only)
    # session_handle() is the canonical name -> roster-handle mapping (registry
    # tag first), so the handle matched here is the same key `tap team` prints
    # and the same one the roster gate validated against.
    occupied = [session_handle(record) for record in in_scope_records
                if record.name in live_names and session_handle(record) not in excepted
                and stale_seat_generation(registry_entry(root_for_cwd(cwd), session_handle(record)), observation)]
    if occupied:
        print("tap team up: skipped unverified live occupants after restart: " + ", ".join(sorted(occupied))
              + "; inspect those sessions before named resume", file=sys.stderr)
    spared = [record for record in in_scope_records if session_handle(record) in excepted]
    spared_names = ", ".join(sorted(session_handle(record) for record in spared))
    records = [
        # Replay the row. Resume takes no tuning, so there is nothing to merge in.
        record
        for record in in_scope_records
        if record.name not in live_names
        and session_handle(record) not in excepted
    ]
    # Design call 4: sparing every relaunchable seat is a legal no-op — exit 0 —
    # but it says so, naming the set that emptied the plan. Gated on at least one
    # seat actually being spared, so an empty team still gets its own message.
    # Human text renders from the TYPED selector; machine fields keep the
    # EFFECTIVE set (tap-sttl / sol-prepull review of #xxx). Under --only the
    # spared set is the complement, so naming it in prose would report seats the
    # operator never typed — while a --json consumer reconciling against real
    # sessions needs exactly that resolved set.
    if only:
        typed = ", ".join(sorted(only))
        empty_clause = f"selection (--only: {typed})"
        spared_clause = f"by --only {typed} — every other seat"
    else:
        empty_clause = f"exclusions (excluded: {spared_names})"
        spared_clause = f"by --except: {spared_names}"
    if spared and not [r for r in in_scope_records if session_handle(r) not in excepted]:
        line = f"tap team up: no seats matched after {empty_clause}"
        if getattr(args, "json", False):
            print(json.dumps(
                {"ok": True, "sessions": [], "count": 0, "scope": "cwd",
                 "excluded": sorted(session_handle(r) for r in spared)},
                separators=(",", ":"),
            ))
            # The JSON companion line is a machine reconciliation surface, so it
            # reports the EFFECTIVE spared set even under --only, matching the
            # excluded[] field beside it (CONTRACT; sol-prepull P2). The text
            # path above keeps the typed clause.
            print(
                f"tap team up: no seats matched after exclusions (excluded: {spared_names})",
                file=sys.stderr,
            )
        else:
            print(line)
        return 0
    if spared:
        # `resume --all --json` is a per-record stream, not one aggregate object,
        # so the exclusion receipt rides stderr there — same rule team refresh
        # uses to keep JSON stdout byte-stable for parsers.
        receipt = f"tap team up: spared {len(spared)} seat(s) {spared_clause}"
        print(receipt, file=sys.stderr if getattr(args, "json", False) else sys.stdout)
    elif only:
        # Whole-roster --only spares nobody. Gating the selector receipt on a
        # nonempty spared set would erase every trace of the flag and make this
        # look like an unselected whole-team resume (sol-prepull P2).
        typed = ", ".join(sorted(only))
        print(
            f"tap team up: --only {typed} matched every seat — none spared",
            file=sys.stderr if getattr(args, "json", False) else sys.stdout,
        )
    if not records:
        if getattr(args, "json", False):
            print(json.dumps({"ok": True, "sessions": [], "count": 0, "scope": "cwd"}, separators=(",", ":")))
        else:
            print("tap session resume --all: no stopped sessions")
        return 0
    cohort = state.sessions or records
    for record in records:
        assert_unique_harness_session_identity(
            cohort,
            record,
            "tap session resume --all",
        )
    json_kw = {"json_output": True} if getattr(args, "json", False) else {}
    json_mode = getattr(args, "json", False)
    total = len(records)
    # tap-7r3fn.23: a cohort verb warns and continues. Each entry is
    # (record, reason); the terminal summary after the stream names every
    # failed seat WITH its reason instead of aborting on the first one.
    failures: list[tuple[SessionRecord, str]] = []
    for index, record in enumerate(records, start=1):
        launched_at = current_timestamp()
        launched = stamp_launched(record, launched_at)
        if launched.harness == "opencode":
            warn_native_resume_fallback(launched)
        if args.dry_run:
            state_expected_revive_identity(launched)
            rc = run_record_detached("resume", launched, True, **json_kw)
            if rc != 0:
                failures.append((launched, f"resume failed (exit {rc})"))
                continue
            if not json_mode:
                print(f"tap session resume --all: [{index}/{total}] would resume {launched.name}")
            continue

        # fable 084245: each resume-all seat is one outer fence transaction
        # (tap team up → resume --all). Detached — no attach to pin the lock.
        with reset_fence_mutation_lock("session resume"):
            try:
                prepare_launch_transaction(
                    launched,
                    launched_at,
                    allow_same_session=True,
                    # Reuse the one namespace snapshot that selected the
                    # cohort. A second liveness probe would turn canonical
                    # no-server back into UNKNOWN and protect an orphaned
                    # pending launch from the same reboot recovery.
                    live_sessions=live_names,
                )
                mark_reset_generation_reused("session-resume")
                state_expected_revive_identity(launched)
                rc = run_record_detached("resume", launched, False, **json_kw)
            except subprocess.CalledProcessError as exc:
                # One seat's tmux error (e.g. respawn-pane ENXIO) is not the
                # cohort's: roll the seat back and move on (tap-7r3fn.23).
                if launched.launch_id:
                    rollback_launch_transaction(launched, "repair_failed")
                failures.append((launched, f"tmux error: {_command_summary(exc.cmd)}"))
                continue
            except LauncherError as exc:
                # e.g. "harness did not start for <name>" — a per-seat
                # LauncherError carries its own reason.
                if launched.launch_id:
                    rollback_launch_transaction(launched, "repair_failed")
                failures.append((launched, str(exc)))
                continue
            except BaseException:
                # Interrupts (KeyboardInterrupt, SystemExit) still abort the run.
                if launched.launch_id:
                    rollback_launch_transaction(launched, "repair_failed")
                raise
            if rc != 0:
                rollback_launch_transaction(launched, "repair_failed")
                failures.append((launched, f"resume failed (exit {rc})"))
                continue
        if not json_mode:
            print(f"tap session resume --all: [{index}/{total}] resumed {launched.name}")
    if failures:
        return _resume_all_failure_summary(failures, total, args)
    if not json_mode:
        print(f"tap session resume --all: {'would resume' if args.dry_run else 'resumed'} {total} session{'s' if total != 1 else ''}")
    return 0


def _command_summary(cmd) -> str:
    """One-line argv summary for failure text, mirroring main's handler.

    List-only on purpose: every reachable call site passes an argv list
    (`verbose.run([...], check=True)`), and `shlex.join` raises TypeError
    on a str `cmd` (a `shell=True` call). Unreachable today by construction,
    not by luck — guard this before any shell-string call site exists.
    """
    cmd_summary = shlex.join(cmd)
    if len(cmd_summary) > 80:
        cmd_summary = cmd[0] + " ..."
    return cmd_summary


def _resume_all_failure_summary(failures: list[tuple[SessionRecord, str]], total: int, args) -> int:
    """Terminal summary for resume --all's failed seats (tap-7r3fn.23).

    Names each failed seat WITH its reason, then — tty, non-dry-run callers
    only — offers one fresh start across the listed seats: Y relaunches each
    through the [k] fresh path (resume_failed_seats_fresh), N leaves the
    manual commands on record. Non-tty and --json never prompt; --json ends
    the per-record stream with one terminal summary object.
    """
    json_mode = getattr(args, "json", False)
    resumed = total - len(failures)
    if json_mode:
        print(json.dumps({
            "ok": False,
            "resumed": resumed,
            "total": total,
            "failed": [
                {"handle": session_handle(record), "session": record.name, "reason": reason}
                for record, reason in failures
            ],
        }, separators=(",", ":")))
        return 1
    if args.dry_run:
        print(f"tap team up: {len(failures)} of {total} seat(s) would not resume:")
    else:
        print(f"tap team up: {len(failures)} of {total} seat(s) failed to resume:")
    for record, reason in failures:
        print(f"  - {record.name}: {reason}")
        print(f"    resume manually with: tap session resume {record.harness} {session_handle(record)}")
    if args.dry_run or not caller_has_tty():
        return 1
    if prompt_yes_no("team up", "start a new session and resume manually?", default=True):
        fresh_rc = resume_failed_seats_fresh([record for record, _ in failures], args)
        if fresh_rc != 0:
            print("tap team up: fresh start failed for at least one listed seat", file=sys.stderr)
            return fresh_rc
        return 0
    print("tap team up: left unresumed; use the commands above to resume manually")
    return 1


def find_record(records: list[SessionRecord], harness: str, name: str) -> SessionRecord | None:
    for record in records:
        if record.harness == harness and record.name == name:
            return record
    return None


def _fsync_path(path: pathlib.Path) -> None:
    with path.open("rb") as handle:
        os.fsync(handle.fileno())


def _fsync_directory(path: pathlib.Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_session_kill_backup(
    record: SessionRecord,
    registry_row: dict | None,
    team: dict,
) -> str:
    """Write a COMPLETE-last picker-[k] checkpoint before registry mutation.

    The layout intentionally reuses the per-handle teardown filenames so
    ``tap restore <handle> --archive <path>`` has one restoration shape. The
    launcher record is the one additive file teardown did not previously need.
    """
    root = pathlib.Path(root_for_cwd(record.cwd))
    handle = session_handle(record)
    backup_root = root / ".tap" / "backup" / "session-kill"
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    bundle_name = f"{stamp}-{handle}-{uuid.uuid4().hex[:12]}"
    incomplete = backup_root / f".{bundle_name}.incomplete"
    bundle = backup_root / bundle_name
    locked_launcher_record = (
        session_record_from_registry_row(handle, registry_row, team, str(root))
        if isinstance(registry_row, dict)
        else None
    )
    launcher_record = (
        locked_launcher_record.to_dict()
        if locked_launcher_record is not None
        else dict(record.replacement_record or {})
    )
    try:
        backup_root.mkdir(parents=True, exist_ok=True)
        # Persist each newly introduced directory entry before building the
        # checkpoint beneath it. In the ordinary layout `.tap` already exists,
        # but both `backup` and `session-kill` may be first-use directories.
        _fsync_directory(backup_root)
        _fsync_directory(backup_root.parent)
        _fsync_directory(backup_root.parent.parent)
        incomplete.mkdir()
        has_registry_row = isinstance(registry_row, dict)
        has_launcher_record = bool(launcher_record)
        documents = {
            "registry-row.json": {
                "team": dict(team),
                "agent": dict(registry_row) if isinstance(registry_row, dict) else None,
            },
            # v0.20 keeps lifecycle authority in the acting registry.  Preserve
            # the normalized launcher view as a second, independently readable
            # recovery artifact without reviving the retired manifest store.
            "launcher-session-record.json": {"record": launcher_record or None},
            "meta.json": {
                "kind": "session_kill_backup",
                "schema": 1,
                "handle": handle,
                "team": team.get("name") or record.base,
                "session": record.replaces_session,
                "created_at": current_timestamp(),
                "state": {
                    "registry_row": "present" if has_registry_row else "absent",
                    "launcher_record": "present" if has_launcher_record else "absent",
                    "restore_as_seat": has_registry_row,
                },
            },
            "tmux-forensics.json": {
                "session": record.replaces_session,
                "captured_at": current_timestamp(),
                "created_label": tmux_session_created_label(record.replaces_session or ""),
                "pane_ids": tmux_session_pane_ids(record.replaces_session or ""),
            },
        }
        for filename, document in documents.items():
            target = incomplete / filename
            registry_v20.save_state_doc(str(target), document)
            _fsync_path(target)
        complete = incomplete / "COMPLETE"
        complete.write_text("complete\n")
        _fsync_path(complete)
        _fsync_directory(incomplete)
        os.replace(incomplete, bundle)
        _fsync_directory(backup_root)
    except Exception as exc:
        shutil.rmtree(incomplete, ignore_errors=True)
        raise LauncherError(
            f"backup failed for {record.replaces_session}; session was not killed: {exc}"
        ) from exc
    return str(bundle)


def prepare_new_launch(record: SessionRecord) -> None:
    # Claim before stopping an incumbent so collision validation happens while it
    # is still recoverable. The caller owns the outer token rollback guard.
    record.identity_capture_action = record.ensure_action
    displaced_entry = claim_pending_handle(record)
    record.replacement_registry_entry = dict(displaced_entry) if displaced_entry else None
    if not record.replaces_session:
        return

    root = root_for_cwd(record.cwd)
    incumbent_killed = False
    suspended_siblings: dict[str, dict] = {}
    try:
        with suspend_session_registry_members(
            root,
            record.replaces_session,
            session_handle(record),
            "session_replaced",
            expected_keep=("pending", record.name),
        ) as suspended_siblings:
            if (
                not record.kill_backup_required
                and displaced_entry
                and isinstance(displaced_entry.get("pane_id"), str)
                and displaced_entry["pane_id"]
            ):
                # Revalidation before the replacement must use the SAME
                # derivation the decision used (tap-24f fix wave) — reading it
                # back through the reader would make a name-provenance target
                # fail its own re-check and defeat the path that keeps named
                # seats terminable. This IS the ratified pre-action re-check:
                # the name-fallback arm re-tests liveness of the exact name, so
                # a canonical session that vanished between the chooser and
                # here refuses instead of stopping whatever took its place.
                # Re-check against the SAME name the chooser authorized
                # (incumbent session), not a re-derived team/handle that can
                # disagree with a legacy/noncanonical row.session.
                current_session = destructive_session_target(
                    displaced_entry, record.replaces_session
                )
                if current_session != record.replaces_session:
                    # E2 / tip drift: if the expected name is still live, a
                    # verifier refuse means disagreement — never fall through
                    # via entry_observed_dead (a recycled id can look gone to
                    # that helper while naming a foreign pane).
                    if tmux_has(record.replaces_session) or not entry_observed_dead(displaced_entry):
                        raise LauncherError(
                            f"cannot verify registered pane identity for {session_handle(record)}: cannot prove it "
                            "belongs to the current tmux server; re-register the seat or run tap team refresh, "
                            "then retry"
                        )
            if record.ensure_vessel == "shell" and tmux_has(record.replaces_session):
                # The shell session classification happened before the claim was taken;
                # the claim is a reservation, not a lock (sol). Revalidate at
                # the replacement boundary: if a harness started (or a client
                # attached) in the window, refuse and roll back.
                revalidated = classify_session(record.replaces_session)
                if revalidated != "shell":
                    raise LauncherError(
                        f"refusing to absorb {record.replaces_session}: state changed mid-ensure "
                        f"(now {revalidated}); re-run to re-evaluate"
                    )
            if tmux_has(record.replaces_session):
                verbose.run(["tmux", "kill-session", "-t", f"={record.replaces_session}"], check=True)
                incumbent_killed = True
                # Un-blind registry-events for [k]/replacement stops (opus E2
                # sweep: silence was not negative evidence a session survived).
                append_registry_session_stop_event(
                    actor="session-launch",
                    handle=session_handle(record),
                    session=record.replaces_session,
                    detail="replaces_session",
                )
            if record.kill_backup_path:
                handle = session_handle(record)
                outcome = (
                    f"killed {record.replaces_session}"
                    if incumbent_killed
                    else f"{record.replaces_session} was already absent"
                )
                if record.kill_backup_has_seat_state:
                    emit_receipt(
                        "session",
                        f"{outcome}; backup: {record.kill_backup_path}; "
                        f"restore: tap restore {handle} --archive {record.kill_backup_path}",
                    )
                else:
                    emit_receipt(
                        "session",
                        f"{outcome}; "
                        f"no seat state existed, so restore as a seat is unavailable; "
                        f"forensic backup: {record.kill_backup_path}",
                    )
    except BaseException:
        if not incumbent_killed and displaced_entry:
            restore_replaced_pending_handle(record, displaced_entry)
        elif displaced_entry:
            restore_replaced_pending_handle(record, displaced_entry, "session_replaced")
        else:
            release_pending_handle(record)
        if not incumbent_killed:
            try:
                restore_suspended_session_registry_members(root, suspended_siblings, "session_replaced")
            except OSError as restore_error:
                print(
                    f"tap session: WARNING: could not restore sibling registry rows after failed replacement: {restore_error}",
                    file=sys.stderr,
                )
        raise


def _ambiguous_harness_or_preset(
    requested: str,
    *,
    catalog: presets.PresetCatalog | None = None,
    missing: presets.PresetError | None = None,
    usage: str = "tap session launch <preset|harness> [name]",
) -> presets.PresetError:
    """`usage` names the CALLER'S verb.

    The resolver is shared by launch and crew, so a hardcoded action told a
    `tap crew add` operator to fix their typo by running `tap session launch` —
    a remedy that does not perform the operation they asked for.
    """
    harnesses = ", ".join(sorted(HARNESSES))
    if catalog is not None:
        available = ", ".join(catalog.names) or "none"
        preset_detail = (
            f"configured presets in {catalog.source_path}: {available}"
        )
    else:
        preset_detail = f"no preset config was loaded ({missing.detail})"
    return presets.PresetError(
        "harness_or_preset_not_found",
        usage,
        f"'{requested}' is neither a known harness nor a known preset; "
        f"canonical harnesses: {harnesses}; {preset_detail}",
    )


def resolve_new_preset_args(args, usage: str | None = None) -> None:
    """Resolve the launch seat spec once, before any registry/tmux effects."""
    usage = usage or "tap session launch <preset|harness> [name]"
    # Label notices with the verb the OPERATOR typed. `tap crew add` shares this
    # resolver and replays its notices verbatim, so a hard-coded "tap session:"
    # made a successful crew command report under a different verb's name. The
    # refusal path already carried `--verb`; this reuses that same signal rather
    # than inventing a second one, so the two can never disagree (codex, #xxx).
    notice_verb = getattr(args, "verb", None) or "tap session"
    requested = getattr(args, "preset", None)
    first = getattr(args, "harness", None)
    second = getattr(args, "label", None)
    args.preset_resolution = None

    if requested is None and first in HARNESSES:
        return
    if requested is None and not first:
        raise LauncherError(f"usage: {usage}")

    explicit = requested is not None
    if not explicit:
        requested = first
        label = second
        compatibility_harness = None
    elif second is not None:
        compatibility_harness = first
        label = second
    elif first in HARNESSES:
        compatibility_harness = first
        label = None
    else:
        compatibility_harness = None
        label = first

    try:
        catalog = presets.load_preset_catalog()
    except presets.PresetError as exc:
        if not explicit and exc.error_class == "preset_config_missing":
            raise _ambiguous_harness_or_preset(requested, missing=exc, usage=usage) from exc
        raise

    resolved = catalog.get(requested)
    if resolved is None:
        if explicit:
            catalog.require(requested)
        raise _ambiguous_harness_or_preset(requested, catalog=catalog, usage=usage)

    # Model/effort stay preset-owned. Explicit env changes and harness tails
    # compose after the preset; the harness position remains a compatibility check.
    #
    # Raised only once `requested` is known to name a REAL preset. Raised any earlier, a plain
    # harness typo produced a fictitious refusal: `launch claud --model opus` reported
    # "preset 'claud' is complete" and advised dropping a --preset the operator never typed.
    # An unknown name's first problem is that it is unknown, so it keeps
    # harness_or_preset_not_found. Suppliedness is `is not None`, never truthiness — `--model ""`
    # is supplied and invalid, not absent.
    combined = [
        flag
        for flag, value in (
            ("--model", getattr(args, "model", None)),
            ("--effort", getattr(args, "effort", None)),
        )
        if value is not None
    ]
    if combined:
        raise presets.PresetError(
            "preset_not_composable",
            f"drop {' and '.join(combined)}, or launch without --preset and pass tuning by flag",
            f"preset '{requested}' is complete; {' and '.join(combined)} cannot override it",
        )
    if compatibility_harness is not None and compatibility_harness != resolved.harness:
        raise presets.PresetError(
            "preset_harness_mismatch",
            f"omit '{compatibility_harness}' or use harness '{resolved.harness}'",
            f"preset '{requested}' uses harness '{resolved.harness}', not "
            f"compatibility harness '{compatibility_harness}'",
        )

    args.harness = resolved.harness
    args.label = label
    args.preset_resolution = resolved
    if resolved.note:
        # The faucet for `family`. Ops's ask was "indicate a family so that it can load the
        # proper notes", and until this line the key validated, bound a note, and loaded
        # nothing — plumbing with a documented faucet that did not exist (mechanical gate).
        #
        # It prints HERE, at resolution, and nowhere else. That is not a shortcut: the note
        # cannot follow the seat. `resume`/`restart` replay the stored row and are contractually
        # forbidden from reopening the catalog, and the row deliberately carries only
        # {name, source_path, config_digest} — persisting the prose instead would go stale the
        # moment the operator edits [notes], silently, on every later resume. So launch is the
        # only moment the note is both in hand and current.
        presets.emit_notice(f"{notice_verb}: {resolved.provenance.name} — {resolved.note}")
    meta_line = presets.metadata_notice(
        resolved.provenance.name, resolved.metadata, notice_verb
    )
    if meta_line:
        # Same faucet, same stale-prose reason: launch is the only moment the
        # catalog is both in hand and current. Resume must not reopen it.
        presets.emit_notice(meta_line)


# Keyed by (flag, verb), because the same retired flag needs a DIFFERENT remediation depending
# on where it was typed. `launch` accepts --env, so it can be told to use it; `resume` and
# `restart` do not, and telling them to "pass --env" hands the operator an instruction that
# fails at argparse — a remediation has to be runnable from the state its refusal leaves.
_RETIRED_FLAG_REPLACEMENTS = {
    ("--teams", "launch"): (
        "agent teams is environment now: pass "
        "--env CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=true, or put it in a preset's [env] table "
        "or in [harness.claude.env]"
    ),
    ("--teams", "resume"): (
        "agent teams is environment now, and it belongs to the seat: put "
        "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=true in [harness.claude.env] to apply it to every "
        "claude seat, or relaunch this one with --env / a preset that carries it"
    ),
    ("--model", "resume"): (
        "resume replays the seat's stored record; set the model when the seat is LAUNCHED "
        "(--model, or a preset) and every later resume replays it"
    ),
}
_RETIRED_FLAG_REPLACEMENTS[("--teams", "restart")] = _RETIRED_FLAG_REPLACEMENTS[
    ("--teams", "resume")
]
_RETIRED_FLAG_REPLACEMENTS[("--model", "restart")] = _RETIRED_FLAG_REPLACEMENTS[
    ("--model", "resume")
]


def refuse_retired_flag(args, flag: str, verb: str) -> None:
    """Refuse a removed spelling by name, one release before it stops parsing at all.

    A flag that silently stops working is the failure this whole lane exists to remove, so the
    removal does not get to commit it: the flag still parses, and answers with what to do
    instead.

    The entries stay in the parser rather than being deleted, for two different reasons.
    `new`/`launch` argv traverses `split_new_passthrough`, which forwards anything it does not
    recognise to the harness — deleting `--teams` there would send it into claude's own CLI.
    `resume` and `restart` do NOT traverse that splitter, so deleting theirs would merely
    produce a generic argparse rejection; they keep their entries so the operator gets the
    named replacement instead of "unrecognized arguments".
    """
    attr = flag.lstrip("-").replace("-", "_")
    if getattr(args, attr, None) in (None, False):
        return
    raise presets.PresetError(
        "retired_flag",
        _RETIRED_FLAG_REPLACEMENTS[(flag, verb)],
        f"{flag} was removed from `tap session {verb}`",
    )


def refuse_tuning_on_resume_delegation(args, door: str) -> None:
    """Refuse launch-tuning flags on a launch that is about to become a resume.

    Two doors inside `launch` end in `cmd_resume`: the numeric-label spelling
    (`launch claude 3`) and the collision chooser's `[r]` arm. Both used to accept `--model` and
    quietly apply it to the RESUMED record, while `--effort` and `--env` were dropped without a
    word — the collision arm forwards a hand-built Namespace and never returns to `cmd_new`.

    Silently applying one flag and silently discarding two is the worst of both: the operator
    who typed all three has no way to learn that only one took effect. Tuning describes a NEW
    seat; resume replays what the record already holds. Suppliedness is `is not None`, so
    `--model ""` refuses here rather than reading as absent.
    """
    supplied = [
        flag
        for flag, value in (
            ("--model", getattr(args, "model", None)),
            ("--effort", getattr(args, "effort", None)),
            ("--unset-env", getattr(args, "unset_env", None)),
            ("--env", getattr(args, "env", None)),
        )
        if value is not None
    ]
    # Raw harness passthrough is tuning too, and it was the hole in the first version of this
    # guard: `launch codex 3 -c model_reasoning_effort="high"` carries exactly what `--effort`
    # carries, by a different spelling, and resume neither consumes nor replays a request
    # vector — so it vanished silently past a guard written to catch the named flags. The class
    # is "tuning the operator typed for a NEW seat", not "the three flags I happened to add".
    passthrough = getattr(args, "harness_passthrough", None)
    if passthrough:
        # Name what the caller actually wrote, not the category. Every other tuning refusal
        # names its flag; "harness passthrough" would send an operator who typed
        # `-c model_reasoning_effort="high"` looking for a flag by that name.
        leading = next((token for token in passthrough if str(token).startswith("-")), None)
        supplied.append(
            f"harness passthrough ({leading})" if leading else "harness passthrough"
        )
    if not supplied:
        return
    joined = " and ".join(supplied)
    raise presets.PresetError(
        "launch_tuning_not_resumable",
        f"drop {joined}, or pass --fresh to launch a new seat that can carry it",
        f"{joined} cannot apply to {door}: a resume replays the stored record",
    )


def require_launch_commands(harness: str) -> None:
    """Report absent prerequisites before enrollment or session reservation."""
    if shutil.which("tmux") is None:
        raise presets.PresetError(
            "missing_prerequisite",
            "Install tmux, check `tmux -V` in this terminal, then retry",
            "tmux was not found on PATH",
        )
    executable = {"cursor": "cursor-agent", "hermes": HERMES_BIN}.get(harness, harness)
    if shutil.which(executable) is None:
        raise presets.PresetError(
            "missing_prerequisite",
            f"Install the {harness} CLI, put {executable} on PATH, and start it "
            "in this terminal to complete authentication, then retry",
            f"{executable} was not found on PATH",
        )

    startup_trace.activate()


def cmd_new(args, resume: bool = False) -> int:
    # Before ANY effect and before preset resolution: a retired spelling should not have to
    # survive a catalog read to be told it is retired.
    refuse_retired_flag(args, "--teams", "launch")
    resolve_new_preset_args(args)
    if (
        args.preset_resolution is None
        and new_label_requests_resume(args)
        and not getattr(args, "fresh", False)
    ):
        refuse_tuning_on_resume_delegation(args, "a numeric-label resume")
        resume_args = argparse.Namespace(**vars(args))
        resume_args.key = args.harness
        resume_args.legacy_name = args.label
        resume_args.resume_query = args.label
        return cmd_resume(resume_args)

    # Everything argv alone can decide is decided HERE, before the first effect. The same
    # validation runs again inside make_new_record, which is where the result is used; running
    # it twice is free (it is pure) and the alternative is not: reached only there, a forbidden
    # --env key was refused AFTER live-unenrolled bootstrap and enrollment had already run, and
    # sometimes after the operator had answered a collision prompt. A refusal the caller could
    # have been given before anything happened should not arrive after several things have.
    # Ordering is deliberate: the delegation refusal above still outranks this one.
    resolve_adhoc_tuning(args)
    _preset_bridge.call("launch.overrides", recipe={}, overrides={
        "env": getattr(args, "env", None) or [],
        "unset_env": getattr(args, "unset_env", None) or [],
        "argv": getattr(args, "harness_passthrough", None) or [],
    })
    if not getattr(args, "dry_run", False):
        require_launch_commands(args.harness)

    refuse_if_team_reset_fenced("session launch")
    _reset_fence_entry_barrier()
    cwd = str(pathlib.Path.cwd().resolve())
    _refuse_if_flip_authority("tap session launch", cwd=cwd, allow_unenrolled=True)
    # Refuse implicit linked-worktree teams before mutation, including in dry-run.
    _boot_root = root_for_cwd(cwd)
    _bootstrap_if_live_unenrolled(_boot_root, dry_run=getattr(args, "dry_run", False))
    # Generation touch waits for the first successful durable mutation — a typo
    # or failed resolve must leave pristine (sol 052921 / design 328-334).
    data = registry_session_state(cwd, allow_unenrolled=True)
    record = stamp_launched(make_new_record(args, data), current_timestamp())
    return execute_fresh_launch(record, args, resume=resume)


def execute_fresh_launch(record: SessionRecord, args, resume: bool = False, attach: bool | None = None) -> int:
    """Execute a built, stamped launch record: mint → invocation → reservation → run.

    Extracted verbatim from cmd_new's tail (tap-7r3fn.23) so the fresh path has
    ONE callable: cmd_new's chooser, resume --all's fresh-start arm, and
    cmd_resume's create-fallback (tap-7r3fn.24) all land here. ``attach=False``
    forces the detached path for callers that must not attach (a cohort verb
    never attaches to the seats it starts); the default resolves the mode from
    args/TTY exactly as cmd_new always did.
    """
    # Both callers stamp_launched(record, ...) before calling (cmd_new,
    # resume_failed_seats_fresh), so last_launched is always set and this is
    # byte-equivalent to the old bare current_timestamp(). The `or` branch is
    # a silent-divergence seam: a future caller that forgets to stamp gets a
    # failure payload timestamped independently of the stamp.
    launched_at = record.last_launched or current_timestamp()
    # tap-e9v8: launch-time session pre-mint for cursor. Mint a
    # native session id BEFORE launching so capture is deterministic-at-launch
    # (not post-hoc sweep). Fail-open: mint_launch_session_id returns None on any
    # error and the launch proceeds with today's no-id behavior. OpenCode does
    # not pre-mint: its plugin captures the TUI's session id during `tap in`.
    # Only mints for NEW launches (ensure_action == "new"), not resumes.
    #
    # dry-run skips the mint (no create-chat / opencode-serve side effect).
    # `tap session launch cursor --dry-run` skips the mint and therefore shows
    # no `--resume`; `tap clear <cursor-seat> --dry-run` does mint and shows the
    # adopted id. A new OpenCode row starts id-less and the plugin captures it.
    refuse_preexisting_id_on_new_mint(record)
    if record.ensure_action == "new" and not record.harness_session_id and not args.dry_run:
        record = mint_launch_session_id(record)
    # The result is discarded on purpose; the call is not. It still raises `unknown harness`
    # BEFORE any launch effect, which is the last argv-decidable validation left in this path
    # now that the teams guard it also carried is gone. Deleting it as unused — the obvious
    # reading, since nothing consumes the return — would move that refusal downstream of the
    # registry write.
    #
    # It is not side-effect free, and that is a known wart rather than a design: on the
    # resurrect path `ensure_action` is "resume" (see `resurrect_action`), and for claude the
    # builder emits resume-target receipts, so a split-brain, disclosure, or picker-fallback
    # line can print once here and again from the real build downstream. Cosmetic, conditional,
    # pre-existing, and tracked on tap-2qrt — recorded here because the next reader to notice
    # the duplicate will land on this line first.
    build_harness_invocation(record.ensure_action, record)
    launch_failure_argv = [
        sys.executable,
        str(pathlib.Path(__file__).resolve()),
        "_launch-failed",
        launched_at,
        json.dumps(record.failure_dict(), separators=(",", ":")),
        caller_tty(),
    ]
    record.launch_failure_argv = launch_failure_argv

    json_kw = {"json_output": True} if getattr(args, "json", False) else {}
    # tap-ya2e: attach-vs-detached decided here, before the session is built.
    attach_mode = resolve_attach_mode(args) if attach is None else attach

    def _launch_tx() -> int:
        """Reservation → run → ready/rollback under one reset sidecar (sol 075040)."""
        try:
            prepare_new_launch(record)
        except BaseException:
            if record.launch_id:
                rollback_pending_handle(record, "session_replaced")
            raise
        mark_reset_generation_reused("session-launch")
        try:
            if record.ensure_action == "resume":
                state_expected_revive_identity(record)
            if resume:
                return run_record_detached(record.ensure_action, record, False, **json_kw)
            # sol 091513: never attach under the outer sidecar — blocking
            # attach-session would pin reset.fence.json.lock. Fresh launch
            # matches resume: detached in-lock, attach tail outside.
            return run_record(
                record.ensure_action,
                record,
                False,
                launch_failure_argv=launch_failure_argv,
                attach=False,
                **json_kw,
            )
        except BaseException:
            rollback_pending_handle(record, "session_replaced")
            raise

    if args.dry_run:
        # Preview of the argv that would launch. A fresh cursor has no
        # `--resume` because dry-run skips its mint; a fresh OpenCode row is
        # likewise id-less until its plugin registers the running TUI.
        if record.ensure_action == "resume":
            state_expected_revive_identity(record)
        if resume:
            return run_record_detached(record.ensure_action, record, True, **json_kw)
        # fable 092252: same attach=False shape as the in-lock fresh call —
        # dry-run never attaches anyway; keep the two sites visually identical
        # so the next editor cannot reintroduce in-lock attach by imitation.
        return run_record(
            record.ensure_action,
            record,
            True,
            launch_failure_argv=launch_failure_argv,
            attach=False,
            **json_kw,
        )

    # sol 075040 / fable 075157: hold the reset fence sidecar across the whole
    # launch transaction so reset cannot interleave between reservation and
    # bind/ready (or rollback). Nested claim/mutate/bind locks re-enter.
    # Attach stays outside — a long-lived attach must not pin the fence.
    with reset_fence_mutation_lock("session launch"):
        rc = _launch_tx()
        if rc != 0:
            rollback_pending_handle(record, "session_replaced")
        else:
            for receipt in record.ensure_receipts:
                emit_receipt("session", receipt)
            if not attach_mode:
                emit_detached_receipt(record, "no controlling terminal")
    if rc == 0 and attach_mode:
        return attach_after_launch(record)
    return rc


def resume_failed_seats_fresh(failed_records: list[SessionRecord], args) -> int:
    """Fresh-start arm of resume --all's terminal summary (tap-7r3fn.23).

    Relaunch each listed seat fresh under its own canonical name, stopping the
    incumbent — the collision chooser's [k] behavior (backup-before-stop with
    replacement authority for the exact session name),
    never the chooser itself. Goes through the ONE extracted fresh path
    (execute_fresh_launch) that cmd_new uses, so cmd_resume's create-fallback
    reuses the same primitive (tap-7r3fn.24). Always detached: a cohort verb
    never attaches to the seats it starts.
    """
    worst = 0
    for record in failed_records:
        history = list(record.history)
        if record.harness_session_id and record.harness_session_id not in history:
            history.append(record.harness_session_id)
        fresh = dataclasses.replace(
            record,
            history=history,
            harness_session_id=fresh_launch_session_id(record.harness),
            transcript_path=None,
            replacement_record=record.to_dict(),
            replaces_session=record.name,
            replaces_manifest_session=record.name,
            kill_backup_required=True,
            ensure_action="new",
        )
        fresh = stamp_launched(fresh, current_timestamp())
        rc = execute_fresh_launch(fresh, args, resume=False, attach=False)
        if rc != 0:
            print(
                f"tap team up: warning: fresh start failed for {record.name} (exit {rc})",
                file=sys.stderr,
            )
            worst = worst or rc
    return worst


def _bare_resume_handle(key: str) -> str | None:
    """Handle form for departed-history lookup; None when key is a harness family."""
    if not key or key in HARNESSES:
        return None
    return key.rsplit("/", 1)[-1]


def _departed_history_for_handle(root: str, handle: str) -> list[dict]:
    """Tombstones for a handle with no current roster row (U5 departed state)."""
    hist_dir = registry_v20.team_history_dir(root)
    return registry_v20.list_handle_history(hist_dir, handle)


def offer_departed_restore(handle: str, rows: list[dict], *, interactive: bool) -> int:
    """U5 / Ops 2026-07-30: the ONE sanctioned history-restore suggestion point.

    Resume with no active/gone roster row may offer restore from team-history.
    Launch never does. Restore itself is `tap in --restore <instance>`.
    """
    n = len(rows)
    latest = rows[0]
    instance = latest.get("instance") or ""
    list_cmd = f"tap in {handle} --list-history --json"
    restore_cmd = f"tap in {handle} --restore {instance}" if instance else list_cmd
    msg = (
        f"no active seat named {handle}; found {n} departed in team-history — restore?"
    )
    if not interactive:
        raise LauncherError(
            f"{msg} next: {list_cmd} then {restore_cmd} (or tap in {handle} --fresh)"
        )
    print(f"tap session resume: {msg}", file=sys.stderr)
    if instance:
        print(f"  most recent instance: {instance}", file=sys.stderr)
    choice = prompt_choice(
        "session",
        msg,
        (
            ("r", "restore", f"restore most recent — next: {restore_cmd}"),
            ("l", "list", f"list departed instances — next: {list_cmd}"),
            ("q", "quit", "leave everything unchanged"),
        ),
        "q",
    )
    if choice == "r" and instance:
        print(f"tap session resume: restore with:\n  {restore_cmd}", file=sys.stderr)
        return 2
    if choice == "l":
        print(f"tap session resume: list with:\n  {list_cmd}", file=sys.stderr)
        return 2
    return 2


def internal_seat_up(argv: list[str]) -> int:
    """Execute Bun's exact retained-seat selection; never select or attach here."""
    if len(argv) != 5:
        raise LauncherError("invalid internal seat-up invocation")
    root, team_name, handle, raw_expected, expected_registry = argv
    try:
        expected = json.loads(raw_expected)
    except (ValueError, TypeError) as exc:
        raise LauncherError("invalid expected retained row") from exc
    if not isinstance(expected, dict) or not _seat_is_relaunchable(expected):
        raise LauncherError("tap up: seat is not retained for resume")
    if (str(pathlib.Path.cwd().resolve()) != root
        or root_for_cwd(root) != root):
        raise LauncherError("tap up: selected worktree changed")
    _refuse_if_flip_authority("tap up", cwd=root)
    status, enrolled_team = registry_v20.enrolled_team_name_for_root(root)
    if status != "ok" or enrolled_team != team_name:
        raise LauncherError("tap up: selected team changed")
    record = session_record_from_registry_row(
        handle, expected, {"name": team_name, "worktree_root": root}, root,
    )
    if record is None or root_for_cwd(record.cwd) != root:
        raise LauncherError("tap up: retained launch record is invalid")
    # The roster key owns the seat even when its vessel or old tag differs.
    record.tag, record.index = handle, 1
    if not record.harness_session_id or record.harness == "hermes":
        raise LauncherError("tap up: exact native resume identity is unavailable")
    launched_at = current_timestamp()
    record = stamp_launched(record, launched_at)
    refuse_if_team_reset_fenced("tap up")
    with reset_fence_mutation_lock("tap up"):
        try:
            prepare_launch_transaction(
                record, launched_at, allow_same_session=True,
                expected_resume_row=expected, expected_team=team_name,
                expected_registry=expected_registry,
            )
            mark_reset_generation_reused("seat-up")
            # Bind the stored identity: the ordinary builder may otherwise
            # replace a missing Claude artifact with a picker or another id.
            rc = run_record_detached(
                "resume", record, False, resume_identity=record.harness_session_id, creation_guard=True,
            )
        except BaseException:
            if record.launch_id:
                rollback_launch_transaction(record, "repair_failed")
            raise
        if rc != 0:
            rollback_launch_transaction(record, "repair_failed")
            return rc
    print(json.dumps({"ok": True, "handle": handle, "session": record.name,
                      "outcome": "resumed"}, separators=(",", ":")))
    return 0


def _failed_resume_record(manifest: Manifest, cwd: str, key: str) -> SessionRecord | None:
    """Exact-key recovery only; never contribute failed rows to an iterator."""
    root = root_for_cwd(cwd)
    matches = [(handle, row) for handle, row in registry_entries(root).items()
               if (handle == key or entry_session_name(row) == key)
               and not _seat_is_relaunchable(row)
               and _seat_is_relaunchable(row, explicit_resume=True)]
    if len(matches) > 1:
        raise LauncherError(f"resume key is ambiguous: {key}; use an exact handle")
    if not matches:
        return None
    handle, row = matches[0]
    return session_record_from_registry_row(handle, row,
        {"name": resolve_base_alias(cwd, manifest), "worktree_root": root}, root)


def cmd_resume(args) -> int:
    for _flag in ("--model", "--teams"):
        refuse_retired_flag(args, _flag, "resume")
    refuse_if_team_reset_fenced("session resume")
    _reset_fence_entry_barrier()
    cwd = str(pathlib.Path.cwd().resolve())
    _refuse_if_flip_authority("tap session resume", cwd=cwd)
    # Generation touch after first successful durable resume mutation (sol 052921).
    if getattr(args, "all", False) and not args.dry_run:
        try:
            tmux_bootstrap.ensure_server()
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
            raise LauncherError(f"tmux bootstrap failed: {error}; next: tap doctor") from error
    data = registry_session_state(cwd)
    records = data.sessions
    if getattr(args, "all", False):
        return cmd_resume_all(args, data, cwd)
    key = getattr(args, "key", None)
    legacy_name = getattr(args, "legacy_name", None)
    if legacy_name and key not in HARNESSES:
        raise LauncherError("two-argument resume form is tap session resume <harness> <name>")
    harness_hint = key if key in HARNESSES and legacy_name else None
    if harness_hint:
        args.harness = harness_hint
        key = legacy_name
        args.resume_query = key
    elif key in HARNESSES:
        args.harness = key
        args.resume_query = None
    else:
        args.harness = None
        args.resume_query = None

    if not key:
        raise LauncherError("usage: tap session resume <handle|session|harness>")

    target_name = key
    record = find_record_by_key(records, cwd, target_name)
    if record is None and key not in HARNESSES:
        record = _failed_resume_record(data, cwd, key)
    registry_record = record
    if not args.dry_run:
        if record and session_attachable(record.name):
            _require_relaunchable_resume_member(cwd, record, explicit_resume=True)
            return reattach_live_session(record.name, record)
        if session_attachable(target_name):
            direct_record = record or find_record_by_session(records, cwd, target_name)
            if not direct_record and registry_record and registry_record.name == target_name:
                direct_record = registry_record
            if not direct_record:
                direct_record = live_resume_record(data, cwd, target_name)
            if not direct_record:
                raise LauncherError(
                    f"resume refused — live session '{target_name}' has no "
                    f"relaunchable acting-registry seat"
                )
            _require_relaunchable_resume_member(cwd, direct_record, explicit_resume=True)
            return reattach_live_session(target_name, direct_record)
        if registry_record and session_attachable(registry_record.name):
            _require_relaunchable_resume_member(cwd, registry_record, explicit_resume=True)
            return reattach_live_session(registry_record.name, registry_record)
    if not record and registry_record:
        record = registry_record
    if not record and key in HARNESSES and not legacy_name:
        matches = matching_harness_records(records, cwd, key)
        if len(matches) == 1:
            record = matches[0]
        else:
            return run_adopted_resume(args, data, cwd)
    if not record and harness_hint:
        record = find_record(records, harness_hint, target_name)
    if not record and harness_hint:
        base = resolve_base_alias(cwd, data)
        candidate_names = []
        tag_name = tag_resume_name(key, args.harness, base)
        if tag_name:
            candidate_names.append(tag_name)
        # No default_tag: it was derived from `args.model`, which `resume` no longer accepts,
        # so the argument could only ever compute None here. A call that reads a provably-None
        # field looks like live model-aware naming and is not.
        candidate_names.extend(resume_shorthand_candidates(key, args.harness, base))
        for expanded_name in candidate_names:
            target_name = expanded_name
            record = find_record(records, args.harness, target_name)
            if not record and not args.dry_run and session_attachable(target_name):
                _early = (
                    registry_resume_record(data, cwd, target_name)
                    or live_resume_record(data, cwd, target_name)
                )
                if not _early:
                    raise LauncherError(
                        f"resume refused — live session '{target_name}' has no "
                        f"relaunchable acting-registry seat"
                    )
                _require_relaunchable_resume_member(cwd, _early, explicit_resume=True)
                return reattach_live_session(target_name, _early)
            if record:
                break
    if record and not args.dry_run and session_attachable(record.name):
        _require_relaunchable_resume_member(cwd, record, explicit_resume=True)
        return reattach_live_session(record.name, record)
    if not record:
        # U5: no launcher/registry record — if the handle is also absent from
        # the roster (departed), resume is the sole door that may offer
        # team-history restore. Launch never suggests history.
        bare = _bare_resume_handle(key)
        root = root_for_cwd(cwd)
        roster = tap_seat_entries(root)
        handles = set(roster)
        current_entry = roster.get(bare) if bare is not None else None
        if (
            bare is not None
            and bare not in handles
            and current_entry is None
        ):
            hist_rows = _departed_history_for_handle(root, bare)
            if hist_rows:
                return offer_departed_restore(
                    bare,
                    hist_rows,
                    interactive=caller_has_tty() and not args.dry_run,
                )
        if bare is not None and (bare in handles or current_entry is not None):
            occupied_harness = (
                current_entry.get("harness")
                if isinstance(current_entry, dict)
                and current_entry.get("harness") in HARNESSES
                else getattr(args, "harness", None)
            )
            launch = shlex.join(
                ["tap", "session", "launch", occupied_harness, bare]
                if occupied_harness
                else ["tap", "session", "launch"]
            )
            raise LauncherError(
                f"resume refused — handle '{bare}' is occupied on the roster but has no "
                f"launcher record to resume. Run {launch} and choose [k] fresh replacement "
                "or [n] suffixed sibling; no create fallback was attempted"
            )
        if not getattr(args, "harness", None):
            raise LauncherError(f"resume key not found: {key}")
        create_command = shlex.join(["tap", "session", "launch", args.harness, key])
        # tap-7r3fn.24: the door uses the SAME both-streams predicate the
        # prompts themselves use (_require_prompt_tty → caller_has_tty), not a
        # bare stdin-only isatty — a stdin-PTY/stdout-piped caller cannot see
        # a question and must get the refusal instead.
        if args.dry_run or not caller_has_tty():
            raise LauncherError(f"no {args.harness} session found for {key}; create it with {create_command}")
        # tap-7r3fn.24: no resumable record exists — [r] lands here only when
        # nothing backs the seat. Re-entering cmd_new re-ran the collision
        # check and offered the same menu whose [r] led here (the loop).
        # State the miss in one line, then act: the [k] fresh path — start
        # over under this name, stopping the incumbent — through the ONE
        # extracted launcher (execute_fresh_launch), never the chooser.
        fresh_name = named_session_name(resolve_base_alias(cwd, data), key)
        print(
            f"tap session: no {args.harness} record for {key} — starting a fresh "
            f"session under this name (replaces the live session)",
            file=sys.stderr,
        )
        record = stamp_launched(
            SessionRecord(
                name=fresh_name,
                harness=args.harness,
                cwd=cwd,
                base=resolve_base_alias(cwd, data),
                tag=key,
                index=1,
                harness_session_id=fresh_launch_session_id(args.harness),
                replaces_session=fresh_name,
                kill_backup_required=True,
                ensure_action="new",
            ),
            current_timestamp(),
        )
        return execute_fresh_launch(record, args, resume=True)
    # tap-h40s's harness/model mismatch guard stood here. It existed because `resume` accepted
    # `--model`: a resume alias like `csr` (claude sonnet resume) could match an existing seat
    # of a DIFFERENT harness, and the requested model leaked into it. It inferred a harness
    # family from the requested model name and offered a three-way chooser.
    #
    # `resume --model` is retired (refuse_retired_flag), so `args.model` is None on every path
    # that reaches here — the guard's own trigger could no longer fire, and a chooser that
    # cannot appear is worse than no chooser: it reads as live protection. The condition it
    # protected against is now unreachable by construction rather than detected at runtime,
    # which is the stronger form. Resume replays the seat's stored record; the model is chosen
    # once, at launch.
    launched_at = current_timestamp()
    record = stamp_launched(record, launched_at)
    # The acting registry row is the identity claim. An id-less row deliberately
    # reaches the harness picker/latest path; runtime inference must never turn a
    # derived candidate into exact-resume authority.
    invocation_record = record
    assert_unique_harness_session_identity(
        data.sessions,
        invocation_record,
        "tap session resume",
    )
    json_kw = {"json_output": True} if getattr(args, "json", False) else {}
    adopted_shell = False
    # WAVE 6.9 / sol 125035Z: membership BEFORE dry-run success arm — parity
    # with resume --all. Early reattach returns remain gated at each call site.
    _require_relaunchable_resume_member(cwd, invocation_record, explicit_resume=True)
    if invocation_record.harness == "opencode":
        warn_native_resume_fallback(invocation_record)
    source_row = registry_entry(root_for_cwd(cwd), session_handle(invocation_record)) or {}
    recovery_reason = source_row.get("status_reason") if (
        source_row.get("status") == "suspended"
        and not _seat_is_relaunchable(source_row)
        and _seat_is_relaunchable(source_row, explicit_resume=True)
    ) else None
    if args.dry_run:
        if recovery_reason:
            print(f"tap session: would resume {record.name} from suspended/{recovery_reason}", file=sys.stderr)
        state_expected_revive_identity(invocation_record)
        return run_record_detached("resume", invocation_record, True, **json_kw)

    # sol 075040 / fable 075157: outer sidecar through claim → run → ready/rollback.
    # Attach stays outside — must not pin the fence for a long-lived attach.
    with reset_fence_mutation_lock("session resume"):
        try:
            if invocation_record.harness != "opencode":
                warn_native_resume_fallback(invocation_record)
            # Claim BEFORE any replacement, mirroring prepare_new_launch's
            # order (crew-wolf B): the reservation bounds the takeover, and the
            # classification happens at the replacement boundary.
            prepare_launch_transaction(
                invocation_record,
                launched_at,
                allow_same_session=True,
            )
            mark_reset_generation_reused("session-resume")
            if tmux_has(record.name):
                boundary_state = classify_session(record.name)
                if boundary_state == "shell":
                    # Resume shares the ensure ladder (tap-x077): a shell
                    # session squatting the name is absorbed, and the recorded
                    # conversation resumes under it.
                    verbose.run(["tmux", "kill-session", "-t", f"={record.name}"], check=True)
                    adopted_shell = True
                else:
                    raise LauncherError(
                        f"refusing to adopt {record.name}: it is {boundary_state}, not a bare shell session; "
                        "attach once it is live, or replace it with tap session restart --force"
                    )
            state_expected_revive_identity(invocation_record)
            rc = run_record_detached("resume", invocation_record, False, **json_kw)
        except BaseException:
            if invocation_record.launch_id:
                rollback_launch_transaction(invocation_record, "repair_failed")
            raise
        if rc != 0:
            rollback_launch_transaction(invocation_record, "repair_failed")
            return rc
        if adopted_shell:
            _, revive_context = native_revive_mode(record.harness, invocation_record.harness_session_id)
            emit_receipt(
                "session",
                f"resumed {record.name} (adopted shell session, {revive_context}; "
                f"expected seat {session_handle(record)})",
            )
    if recovery_reason:
        print(f"tap session: resumed {record.name} from suspended/{recovery_reason}", file=sys.stderr)
    return resume_attach_tail(record)


def cmd_restart(args) -> int:
    for _flag in ("--model", "--teams"):
        refuse_retired_flag(args, _flag, "restart")
    # Design test strategy §Reset and fence: launch/resume/restart each honor the
    # fence independently — do not rely on restart eventually calling launch.
    refuse_if_team_reset_fenced("session restart")
    _reset_fence_entry_barrier()
    cwd = str(pathlib.Path.cwd().resolve())
    _refuse_if_flip_authority("tap session restart", cwd=cwd)
    # Generation touch after prepare_launch_transaction succeeds (sol 052921).
    state = registry_session_state(cwd)
    key = getattr(args, "key", None)
    if not key:
        raise LauncherError("usage: tap session restart <handle|session> [--force]")
    record = resolve_exact_record(state.sessions, cwd, key, "restart")
    # restart replays the stored row verbatim; tuning flags are refused at the parser.
    live = tmux_has(record.name)
    if live and not args.force:
        busy = {
            handle: state
            for handle, state in session_seat_states(record).items()
            if state in {"working", "blocked-on-approval", "rate-limited-error", "alert"}
        }
    else:
        busy = {}
    if busy:
        # A rate-limited seat is the one busy state where --force is almost never what
        # the operator wants: restart is session-scoped and ends every sibling seat in
        # that session, and the
        # thing they are actually trying to fix (credentials read only at startup) is
        # what `tap session relaunch` does per seat, in place, keeping the conversation.
        # The other busy states are genuine in-flight work, where relaunch would discard
        # the turn — so only the capped seats get the alternative named.
        # FILTERED THROUGH THE SAME PREDICATE relaunch itself uses, because
        # session_seat_states has no crew exclusion: it returns every ACTIVE row
        # whose entry_session_name equals this session, which for a driver session
        # includes all of its crew. A capped crew handle would otherwise be
        # suggested to `tap session relaunch`, which refuses it — sending the
        # operator in a circle at the moment they are already blocked. (My first
        # pass argued this could not happen; the live registry refuted it.)
        seats = registry_v20._seat_map(_registry_payload_for_root(root_for_cwd(record.cwd)))
        capped = sorted(
            h for h, st in busy.items()
            if st == "rate-limited-error"
            and registry_v20.seat_is_relaunchable(seats.get(h))
        )
        action = f"tap session restart {key} --force"
        # relaunch is machine-scoped and accepts ONLY team/handle, so the alternative can
        # be named only when the team resolves. An unenrolled root would otherwise produce
        # a bare handle here — a suggestion relaunch itself refuses, which is worse than
        # not suggesting anything.
        team_status, team = registry_v20.enrolled_team_name_for_root(
            root_for_cwd(record.cwd)
        )
        if capped and team_status == "ok" and team:
            action = (
                "tap session relaunch "
                + " ; tap session relaunch ".join(f"{team}/{h}" for h in capped)
                + f"   # per seat, in place, keeps the conversation (or: {action})"
            )
        detail = f"session {record.name} has busy seats: " + ", ".join(f"{handle}={state}" for handle, state in sorted(busy.items()))
        print_session_error("tap session restart", "session_busy", action, detail)
        raise SystemExit(2)
    root = root_for_cwd(record.cwd)
    launched_at = current_timestamp()
    launched = stamp_launched(record, launched_at)
    assert_unique_harness_session_identity(
        state.sessions,
        launched,
        "tap session restart",
    )
    # Pre-flight only: the result is discarded and the real build happens in
    # run_record_detached below, on both the dry-run and the live arm. The flag suppresses the
    # env-policy and collision notices — NOT all output; claude's resume-target receipts still
    # print from the builder here and again below (tap-2qrt) — while the validation this call
    # exists for stays live: a fenced [harness.*] key raises before the launch transaction.
    launch_invocation("resume", launched, notify_env_policy=False)
    json_kw = {"json_output": True} if getattr(args, "json", False) else {}
    # WAVE 6.11 / sol: membership BEFORE dry-run success and before the
    # launch transaction — parity with single-seat resume (manifest-only /
    # user_removed must not dry-run-succeed or promote a pending row).
    _require_relaunchable_resume_member(cwd, launched)
    if launched.harness == "opencode":
        warn_native_resume_fallback(launched)
    if args.dry_run:
        state_expected_revive_identity(launched)
        return run_record_detached("resume", launched, True, **json_kw)

    # fable 084245: one outer sidecar across reservation → incumbent stop → run → ready/rollback.
    with reset_fence_mutation_lock("session restart"):
        incumbent_killed = False
        try:
            if live:
                launched.replaces_session = record.name
            prepare_launch_transaction(
                launched,
                launched_at,
                allow_same_session=not live,
                failure_reason="restart_failed",
            )
            mark_reset_generation_reused("session-restart")
            with suspend_session_registry_members(
                root,
                record.name,
                session_handle(record),
                "session_restarted",
                expected_keep=("pending", launched.name),
            ):
                if live:
                    verbose.run(["tmux", "kill-session", "-t", f"={record.name}"], check=True)
                    incumbent_killed = True
            state_expected_revive_identity(launched)
            rc = run_record_detached("resume", launched, False, **json_kw)
        except BaseException:
            if launched.launch_id:
                if incumbent_killed:
                    rollback_launch_transaction(launched, "restart_failed")
                else:
                    rollback_pending_handle(launched, None)
            raise
        if rc != 0:
            rollback_launch_transaction(launched, "restart_failed")
            return rc
    if not getattr(args, "json", False):
        emit_inbox_digest(launched)
        print(f"tap session restart: restarted {launched.name}")
    return rc


# --- tap clear (tap-eb9h) ---------------------------------------------------
#
# `tap clear <seat>` hard-restarts ONE seat's harness process in the pane it
# already occupies. It is deliberately NOT `tap session restart`, which ends the
# whole tmux session, creates a new one, and RESUMES the conversation. Clear is
# seat-scoped, pane-preserving, and starts a FRESH conversation.
#
# Why respawn-pane rather than a new window: registration is pane-bound, so a new
# pane id means the SessionStart hook finds no binding for the seat and its
# collision-avoidance mints a suffixed handle before any rebind can run. That is
# not a race we can win by ordering — it is decided by construction. The
# 2026-08-14 principle test against tap/opus forked `opus` into `opus-3` exactly
# this way. `tmux respawn-pane -k` replaces the PROCESS inside the SAME pane
# object, so the pane id survives, the registry binding stays valid, and the hook
# re-registers the same handle — the same path a user-typed /clear takes.
#
# It is also the hung-harness recovery verb: on a stuck harness this is the same
# operation with a more abrupt stop, so there is no discriminator flag.


def resolve_caller_pane_id() -> str:
    """The tmux pane that owns THIS process's controlling tty, or "" if unknown.

    Delegates to lib.sh's tap_calling_pane_id rather than reading TMUX_PANE: the
    env var is inherited and can be stale, and this walks the process ancestry to
    the first controlling terminal and re-asserts the tty->pane binding, so a
    recycled pane id cannot masquerade as the caller. "" means unobservable, which
    every caller here must treat as "cannot prove", never as "somewhere else".
    """
    lib = pathlib.Path(__file__).resolve().parents[1] / "lib.sh"
    try:
        result = verbose.run(
            ["bash", "-c", f". {shlex.quote(str(lib))}; tap_calling_pane_id"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
    except (OSError, FileNotFoundError):
        return ""
    if result.returncode != 0:
        return ""
    return result.stdout.strip()


def clear_target_pane(
    root: str,
    handle: str,
    verb: str = "tap clear",
    restart_hint: str | None = None,
    roster_hint: str | None = None,
) -> tuple[str, dict]:
    """Resolve a seat handle to the LIVE pane id an in-pane respawn will replace.

    Every refusal here names a recovery path, because the states this rejects are
    exactly the ones an operator hits when something is already wrong.

    `verb` only labels those messages. Two verbs share this resolver — `tap clear`
    and `tap session relaunch` — and a refusal that names the wrong one sends the
    operator to the wrong recovery.

    `restart_hint` / `roster_hint` exist because the default recoveries are
    CALLER-team-scoped. `tap session relaunch` is machine-scoped, so a bare
    `tap session restart <handle>` copied out of its refusal would act on a
    same-named seat in whatever team the operator is standing in — a real hazard
    when half the fleet is called `sol`.
    """
    restart_hint = restart_hint or f"tap session restart {handle}"
    roster_hint = roster_hint or "tap team"
    entry = registry_entry(root, handle)
    if not entry:
        raise LauncherError(
            f"no seat '{handle}' on this bus; run `{roster_hint}` to see who is registered"
        )
    # epoch_voided_ids, not entry["pane_id"]: ids captured under a PRIOR tmux
    # server generation resolve to unrelated panes on the reborn server, and
    # respawning one would replace a stranger's process (tap-24f).
    pane_id, _pane = seat_corpse.epoch_voided_ids(entry, current_server_epoch())
    if not pane_id:
        raise LauncherError(
            f"seat '{handle}' has no usable pane identity on record (stale row, or ids "
            "captured under a previous tmux server). Its process is not there to "
            f"replace — recreate the seat instead: {restart_hint}"
        )
    facts = tmux_pane_facts(pane_id)
    if not (facts and facts.pane_id == pane_id):
        raise LauncherError(
            f"seat '{handle}' is registered at pane {pane_id}, but that pane is gone. "
            f"{verb} replaces a live process in place; there is nothing to replace — "
            f"recreate the seat instead: {restart_hint}"
        )
    # TWO GUARDS FOLLOW, AND THEIR POLARITIES ARE DELIBERATELY OPPOSITE. Do not
    # "fix" one to match the other; the costs are not symmetric.
    #
    #   occupancy  fails OPEN  — an unreadable session name refuses nothing, it
    #                            only warns. Refusing every clear whose session
    #                            probe hiccups would break the verb for the
    #                            operator with a working seat, and the state it
    #                            guards (a recycled id) is rare.
    #   self-clear fails CLOSED — an unprovable caller pane refuses. The state it
    #                            guards is the command ending its own process
    #                            mid-transaction, which is unrecoverable in a way
    #                            "try again" cannot fix.
    #
    # OCCUPANCY, not mere existence. Everything above proves a pane is THERE; this
    # is the first verb that replaces the process inside one, and a registry row
    # can outlive the seat it describes — pointing at an id tmux has since handed
    # to somebody else's pane. Existence would then authorize replacing a
    # stranger's process. The session name the pane actually lives in is the
    # cheap binding check, and it must match the session this seat is on record as
    # occupying.
    expected_session = entry_session_name(entry)
    observed_session = pane_session_name(facts.pane) if facts.pane else ""
    if not (expected_session and observed_session):
        # Fail-open, but never silently: the operator should know the ownership
        # check did not actually run rather than read its absence as a pass.
        print(
            f"{verb}: WARNING: cannot confirm pane {pane_id} belongs to '{handle}' "
            f"(expected session {expected_session or 'unknown'}, observed "
            f"{observed_session or 'unknown'}); proceeding on the registry binding alone",
            file=sys.stderr,
        )
    elif observed_session != expected_session:
        raise LauncherError(
            f"seat '{handle}' is on record in session '{expected_session}', but pane "
            f"{pane_id} now lives in '{observed_session}' — the id has been recycled and "
            "that pane belongs to something else. Refusing to replace a process this seat "
            f"does not own; re-register the seat, or recreate it: {restart_hint}"
        )
    # Self-clear would end the process issuing the command mid-transaction: the
    # respawn never returns to write its verification, so the seat comes back with
    # the registry mid-update and nobody watching. A seat clears itself by asking
    # someone else to, which is also what makes the result observable.
    #
    # FAIL CLOSED, because the obvious form of this check fails OPEN: reading
    # TMUX_PANE alone lets any caller whose environment lost or inherited the
    # variable — a child process, `env -i`, an in-pane helper — walk straight past
    # the refusal and end its own transaction. So the rule is not "TMUX_PANE
    # differs", it is "the caller is PROVABLY somewhere else". Inside tmux with no
    # provable pane, that cannot be established, so the answer is no. A caller
    # outside tmux entirely (no TMUX) is provably not the target pane, which is a
    # positive discriminator rather than an absence of evidence — cron and daemon
    # callers stay allowed.
    # ONE SOURCE, AND IT IS THE TTY WALK. TMUX_PANE is deliberately not consulted,
    # not even as a fallback: falling back to it hands the decision to the
    # untrusted value the walk exists to replace, in precisely the case the walk
    # could not answer. A stale TMUX_PANE is truthy, so it both fails the equality
    # below AND suppresses the unprovable-caller refusal — the guard would then
    # read "somewhere else" from evidence its own docstring says means nothing.
    # An empty answer here means UNPROVABLE, and unprovable inside tmux is a
    # refusal.
    caller_pane = resolve_caller_pane_id()
    if caller_pane and caller_pane == pane_id:
        raise LauncherError(
            f"refusing to run {verb} on '{handle}' from inside its own pane — it would "
            "end its own process before it could verify the rebind. Ask a teammate to run it, "
            "or run it from another pane."
        )
    if os.environ.get("TMUX") and not caller_pane:
        raise LauncherError(
            f"refusing to run {verb} on '{handle}': this command is running inside tmux but cannot "
            "identify its own pane, so it cannot prove it is not the target. Re-run from a "
            "pane whose controlling tty resolves, or from outside tmux."
        )
    return pane_id, entry


# Distinguishes "no resume expectation was supplied" from "the expectation is
# None" — and None is meaningful: a seat whose effective conversation resolves to
# nothing is a valid enumerated member, and it must still resolve to nothing.
_UNSET_RESUME_EXPECTATION = object()


@contextlib.contextmanager
def authorized_clear_stamp(
    root: str,
    handle: str,
    nonce: str,
    *,
    tag: str,
    expect: dict | None = None,
    expect_resume: object = _UNSET_RESUME_EXPECTATION,
    permissions: str | None = None,
    recipe: dict | None = None,
):
    """Validate, stamp, and hold the registry lock ACROSS the caller's effect.

    THE WINDOW THIS CLOSES. `relaunch_one` runs three identity guards, and then
    the nonce stamp opened the registry AGAIN — by handle, 38 lines before
    `tmux respawn-pane` — and wrote `expected_clear_nonce` onto whatever row held
    that handle. On drift that is a seat the batch deliberately refused to touch:
    its expectation was overwritten and its `clear_nonce` popped, and
    `consume_expected_clear_nonce` then matched OUR nonce and popped that too, so
    the stranger's concurrent clear was left with neither expectation nor witness
    and reported unverified. Measured on the production path; the classified pane
    was still replaced correctly, which is why the run looked like a success.

    A fourth ordinary guard would not have closed it: validating and then
    releasing the lock before the respawn reopens the same race a few lines
    later. So the lock is held from the fresh read THROUGH the caller's effect —
    the shape `suspend_session_registry_members` already uses for a yielded tmux
    effect, reused rather than invented twice.

    THE RESUME EXPECTATION IS THE EFFECTIVE TARGET, NOT ITS INPUT.
    `resolved_resume_identity` walks a chain (acting id -> an id derived from
    `transcript_path` -> a quarantined id), so for claude the conversation the
    harness would actually resume can change while the row's own bytes do not — a
    transcript file appearing on disk suffices. Comparing the raw stored field
    cannot see that; the resolver has to run.

    INERT WITHOUT AN EXPECTATION. `tap clear` has no enumeration to drift from,
    so with `expect=None` this stamps exactly as before, releases its lock, and
    only then yields — clear's lock duration does not grow by a line.
    """
    if not expect:
        if recipe is not None:
            stamp_expected_clear_nonce(root, handle, nonce, permissions=permissions, recipe=recipe)
        elif permissions is None:
            stamp_expected_clear_nonce(root, handle, nonce)
        else:
            stamp_expected_clear_nonce(root, handle, nonce, permissions=permissions)
        yield
        return

    registry = writable_tap_registry_path(root)
    if not registry.exists():
        raise LauncherError(f"no TAP registry at {registry}")
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with registry.open() as handle_file:
                payload = json.load(handle_file)
        except (OSError, json.JSONDecodeError) as exc:
            raise LauncherError(f"registry unreadable: {exc}") from exc
        team_doc, agents = registry_v20.seat_store(payload)
        entry = agents.get(handle) if isinstance(agents, dict) else None
        if not isinstance(entry, dict):
            raise LauncherError(f"no seat '{handle}' on this bus")

        # THE FINAL AUTHORIZATION, on the freshest possible read, inside the lock
        # that is about to write. Nothing can interleave between this check and
        # the effect — which is the property a guard further upstream cannot have
        # however many times it is repeated.
        refuse_on_identity_drift(tag, expect, entry)
        if expect_resume is not _UNSET_RESUME_EXPECTATION:
            fresh_record = session_record_from_registry_row(
                handle, entry, team_doc if isinstance(team_doc, dict) else {}, root
            )
            fresh_id = (
                resolved_resume_identity(fresh_record, emit_receipts=False)
                if fresh_record is not None
                else None
            )
            if fresh_id != expect_resume:
                raise LauncherError(
                    f"seat '{tag}' now resolves to a different conversation than the one "
                    f"enumerated ({expect_resume!r} -> {fresh_id!r}); refusing rather than "
                    "resuming a conversation this batch never classified"
                )

        if recipe is not None:
            entry.update(recipe)
        entry["expected_clear_nonce"] = nonce
        if permissions is not None:
            entry["permissions"] = permissions
        entry.pop("clear_nonce", None)
        save_registry(registry, payload)
        # Still holding the lock: the caller's respawn happens here, and the lock
        # drops on the way out — before the awaited registration needs it.
        yield


def stamp_expected_clear_nonce(root: str, handle: str, nonce: str, *, permissions: str | None = None, recipe: dict | None = None) -> None:
    """Write the nonce `tap clear` expects the NEXT registration to carry.

    Written BEFORE the respawn so the expected value is on record no matter how
    the respawn goes: a clear that fails halfway leaves a row whose expectation is
    unmet, which reads as "not rebound" — the safe direction.

    It is also the row's claim on the clear, which is what makes two concurrent
    clears of one seat resolve deterministically instead of by poll order:
    whichever stamps last owns the expectation, and the other sees its own nonce
    displaced and reports unverified rather than accepting a rebind it did not
    cause. `clear_rebind_verified` is the reader.

    Under the registry lock, and read-modify-write rather than blind: the seat's
    own registration writes this same row from inside the harness, so a clobbering
    write here could drop a field that arrived between the read and the write.
    """
    registry = writable_tap_registry_path(root)
    if not registry.exists():
        raise LauncherError(f"no TAP registry at {registry}")
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with registry.open() as handle_file:
                payload = json.load(handle_file)
        except (OSError, json.JSONDecodeError) as exc:
            raise LauncherError(f"registry unreadable: {exc}") from exc
        _, agents = registry_v20.seat_store(payload)
        entry = agents.get(handle)
        if not isinstance(entry, dict):
            raise LauncherError(f"no seat '{handle}' on this bus")
        if recipe is not None:
            entry.update(recipe)
        entry["expected_clear_nonce"] = nonce
        if permissions is not None:
            entry["permissions"] = permissions
        # The witness this clear is about to look for must not still be sitting
        # on the row from a PREVIOUS clear: leaving it would let a respawn that
        # never registers verify against stale evidence.
        entry.pop("clear_nonce", None)
        save_registry(registry, payload)


def consume_expected_clear_nonce(root: str, handle: str, nonce: str) -> None:
    """The clearer retires the pending question after observing an answer.

    Registration never pops expected_clear_nonce — a nonce-less or non-matching
    pass must leave the question standing so a later match can still answer.
    Only this command, after it has observed verification or declared
    timeout/abandon, may consume it. Same rule as identity_capture: the party
    that ASKS is the only party that may retire the question.
    """
    registry = writable_tap_registry_path(root)
    if not registry.exists():
        return
    lock_path = pathlib.Path(str(registry) + ".lock")
    with lock_path.open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with registry.open() as handle_file:
                payload = json.load(handle_file)
        except (OSError, json.JSONDecodeError):
            return
        _, agents = registry_v20.seat_store(payload)
        entry = agents.get(handle)
        if not isinstance(entry, dict):
            return
        if entry.get("expected_clear_nonce") == nonce:
            entry.pop("expected_clear_nonce", None)
            save_registry(registry, payload)


def clear_rebind_verified(root: str, handle: str, pane_id: str, nonce: str) -> bool:
    """The rebind predicate: same handle, same pane, NEW process.

    The pane leg alone cannot verify anything here. respawn-pane preserves the
    pane id on purpose, so `handle -> pane_id` is equally true before the clear,
    after it, and if the respawn silently did nothing — a predicate satisfied by
    its own failure case. The nonce breaks that tie for an ordinary reason, not a
    clever one: it is minted per clear, so a row carrying it was written by a
    registration that ran AFTER this command started. Nothing here rests on the
    value being secret — it sits in plain sight on the row, and a deliberate
    re-register can present it. It is a freshness-and-claim tag, not a
    credential, and reading it as authentication would be a category error.
    """
    entry = registry_entry(root, handle)
    if not entry:
        return False
    if entry.get("status") != "active":
        return False
    observed_pane_id, _pane = seat_corpse.epoch_voided_ids(entry, current_server_epoch())
    if observed_pane_id != pane_id:
        return False
    if not nonce:
        return False
    # TWO equalities, and they answer different questions. `clear_nonce` is what
    # the fresh process registered with — the freshness half. The row's
    # `expected_clear_nonce` is whose clear this is: if another clear of the same
    # seat stamped after ours, the expectation is theirs, and their respawn's
    # rebind is not evidence for our command. Checking only the first would let
    # the loser of a concurrent clear report success for work it did not cause.
    #
    # Both must be PRESENT and equal to our nonce: registration removes
    # `clear_nonce` when a process carries no TAP_CLEAR_ID, so an absent value
    # fails here rather than inheriting a previous clear's witness.
    if entry.get("expected_clear_nonce") != nonce:
        return False
    return entry.get("clear_nonce") == nonce


CLEAR_REBIND_TIMEOUT_SECONDS = 45.0

# How long a family takes to come up is a HARNESS property, like every other
# per-family fact in this codebase, and one global constant asserted otherwise.
# The 45s ceiling was set from claude's boot and held for claude, codex, and
# cursor; on the 2026-08-14 six-seat fleet clear, agy and opencode both blew
# through it and then registered successfully seconds later — a clear reported
# as unverified while the pipeline was merely slower than the guess.
#
# THESE NUMBERS ARE PROVISIONAL. They are one night's observation plus margin,
# not a measurement: the fleet run recorded which seats missed the window, not
# how long each actually took. That is why every clear now appends its own
# latency to `<root>/.tap/clear-latency.jsonl` (see record_clear_latency) —
# the next person to touch this table should read that file rather than guess
# again, and the load hint on each line is there because a number measured on a
# contested box is a different number.
CLEAR_REBIND_TIMEOUT_BY_FAMILY = {
    "claude": 45.0,
    "codex": 45.0,
    "cursor": 45.0,
    # Observed past 45s on 2026-08-14, both registering fine afterwards.
    "agy": 90.0,
    "opencode": 90.0,
}


def clear_rebind_timeout(harness: str | None) -> float:
    """The await ceiling for one harness family, defaulting to the historical
    global value for anything unlisted — a family nobody has measured gets
    today's behavior rather than a number invented for it."""
    return CLEAR_REBIND_TIMEOUT_BY_FAMILY.get(
        (harness or "").strip().lower(), CLEAR_REBIND_TIMEOUT_SECONDS
    )


def _loadavg_hint() -> float | None:
    """One-minute load average, or None where the platform will not say.

    Recorded with every latency line because a rebind measured on a box running
    a parallel suite is not the same measurement as one taken on an idle box,
    and a table calibrated from the two mixed together is calibrated from
    nothing."""
    try:
        return round(os.getloadavg()[0], 2)
    except (OSError, AttributeError):
        return None


def record_clear_latency(
    root: str,
    handle: str,
    harness: str | None,
    pane_id: str,
    verified: bool,
    seconds: float,
    timeout: float,
) -> None:
    """Append one clear's observed rebind latency to `<root>/.tap/clear-latency.jsonl`.

    Best-effort by construction: this is calibration data, and failing to write
    it must never turn a completed clear into an error. It is deliberately
    recorded for BOTH outcomes — an unverified clear that rebinds at 61s is the
    single most useful line in the file, and dropping it would leave the table
    calibrated only by the runs that already fit it.
    """
    # COVERAGE GAP, named because the #xxx gate named it: the unit test calls this
    # function directly, so wrapping the CALL SITE in `if verified:` would red
    # nothing here. What protects the both-outcomes property is this function
    # having no verified-conditional of its own plus the single call site being
    # unconditional; an integration-shaped arm (drive a clear to timeout, assert
    # a line lands) needs a real respawn and belongs in regress, not the gate.
    line = {
        "at": current_timestamp(),
        "handle": handle,
        "harness": harness or "",
        "pane_id": pane_id,
        "verified": bool(verified),
        "seconds": round(seconds, 2),
        "timeout": timeout,
        "loadavg1": _loadavg_hint(),
    }
    try:
        path = pathlib.Path(root) / ".tap" / "clear-latency.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as handle_file:
            handle_file.write(json.dumps(line, separators=(",", ":")) + "\n")
    except OSError:
        return


def await_clear_rebind(
    root: str, handle: str, pane_id: str, nonce: str, timeout: float | None = None
) -> bool:
    ceiling = CLEAR_REBIND_TIMEOUT_SECONDS if timeout is None else timeout
    deadline = time.monotonic() + ceiling
    while True:
        if clear_rebind_verified(root, handle, pane_id, nonce):
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(0.25)


def await_harness_start(
    pane_id: str,
    harness: str,
    timeout: float | None = None,
    *,
    expected_server_epoch: str,
    previous_pane_pid: int,
    detect_resume_picker: bool = False,
) -> bool:
    """Wait until the respawned pane is observably running the intended harness.

    Relaunch preserves the existing seat registration, so it needs process
    readiness rather than `tap clear`'s stronger fresh-registration witness.
    Readiness is causal: the harness-process identity on the same tmux record
    must differ from the process that was replaced. Same pane, same server
    generation, alive, and intended command are all true of the old process.
    """
    ceiling = CLEAR_REBIND_TIMEOUT_SECONDS if timeout is None else timeout
    facts, _blocked = await_stable_harness(
        lambda: tmux_pane_facts(pane_id),
        lambda observed: (
            observed.pane_id == pane_id
            and observed.server_epoch == expected_server_epoch
            and observed.dead is False
            and bool(observed.pane_pid)
            and observed.pane_pid != previous_pane_pid
            and pane_harness(observed) == harness
        ),
        ceiling,
        blocker=(
            (lambda observed: pane_startup_blocker(observed, harness))
            if harness == "codex" and detect_resume_picker else None
        ),
    )
    return facts is not None


def clear_unverified_diagnosis(post, harness: str | None = None) -> tuple[str, str]:
    """Classify what the pane looks like after an unverified clear (tap-36kb).

    THE PROSE WAS ALREADY RIGHT; ONLY AUTOMATION COULD NOT READ IT. These three
    states have different remediations, and `tap refresh` has to branch on them
    with no human in the loop. The class travels BESIDE the exit code rather than
    as more exit codes: 7 means THE PROCESS IS ALREADY REPLACED, full stop, and
    that is the one bit a caller must never get wrong. Splitting it into 7-and-8
    would hand every future caller a three-way enumeration to be careless with.

    Pure and taking the observed pane facts as an argument so it can be tested on
    all three inputs — the previous inline form could only be exercised by
    driving a real respawn to timeout, which is why it never was.
    """
    if not post:
        return (
            "rebind_unverified_pane_gone",
            "the pane is GONE — the harness did not survive its start and the pane "
            "went with it despite remain-on-exit",
        )
    if harness:
        blocker = pane_startup_blocker(post, harness)
        if blocker:
            return "harness_start_unverified_picker", blocker
    if pane_harness(post) not in HARNESSES:
        return (
            "rebind_unverified_not_a_harness",
            f"the pane is alive but is running {post.command!r}, not a harness — the "
            "process most likely exited immediately (check the pane for its error)",
        )
    # The only one of the three that may still resolve itself, and the one the
    # 2026-08-14 fleet run produced twice: automation should look again before it
    # decides anything, not re-clear a seat that is seconds from registering.
    return (
        "rebind_unverified_starting",
        "the pane is alive and running a harness, so it is most likely still "
        "starting up and simply had not registered yet",
    )


def _clear_instruction_from_handle() -> str:
    """Sender for the opencode clear -m bus send: TAP_SELF, else empty.

    Empty means omit --from and let tap send resolve a pane identity. A
    pane-less caller with no TAP_SELF has no honest sender; the send then
    refuses unregistered and cmd_clear maps that to exit 6 rather than
    reporting a delivery that did not happen.
    """
    return (os.environ.get("TAP_SELF") or "").strip()


def deliver_clear_instruction_via_send(
    handle: str, instruction: str, team: str | None = None
) -> int:
    """Place the opencode clear -m text as a settle-only bus payload.

    Called while the clear fence is still held, so the courier parks this send
    (reason=clearing) and drain delivers it BEFORE any send parked later in the
    window. That ordering is the pin: a future fence that delivers during the
    await would silently break it. Mail parked earlier in the clearing window
    may drain first; the pin is later-parked mail, not "first work".

    A file, not -m: the instruction is caller prose and may quote commands.
    Passes --from $TAP_SELF when set so a pane-less poll identity can deliver.

    tap-74h2l: with a target team the recipient is `<team>/<handle>`, which
    selects the target team's registry and pane and makes the send consult the
    target clearing fence; the canonical payload stays on the sender's bus.
    Without a team the bare handle keeps the caller-team-scoped clear behaviour.
    """
    send_sh = pathlib.Path(__file__).resolve().parents[1] / "tap-send.sh"
    bus = _team_bus_home()
    tmp_dir = (bus / "tmp") if bus is not None else pathlib.Path(tempfile.gettempdir())
    tmp_dir.mkdir(parents=True, exist_ok=True)
    body = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        delete=False,
        dir=str(tmp_dir),
        prefix=".tap-clear-instruction.",
        suffix=".md",
    )
    try:
        body.write(
            "This instruction arrived over the TAP bus, not as process argv "
            "(opencode has no interactive initial-prompt form; the positional "
            "is a project directory).\n\n"
            f"{instruction.rstrip()}\n"
        )
        body.close()
        # tap-31it --wake: a clear instruction must stay OWED by the seat that
        # reads it — courier pre-settlement would write the `.done` on its behalf
        # and the instruction would look handled without anyone having acted on it.
        # The happy path is safe only by accident (the clear fence parks it before
        # the pre-settlement gate is reached); the degraded retry runs after
        # held.release(), with no fence, where --fyi alone would make it eligible.
        # --wake is a no-op under the fence and load-bearing once the fence is down.
        #
        # tap-7r3fn.20: this comment used to call the instruction "prompt-arrival
        # traffic". --wake is inert on the delivery axis since ruling 51, so it buys
        # the settlement half and nothing about WHEN the body lands; arrival is the
        # recipient's delivery window, and --delivery interrupt is the only override.
        recipient = f"{team}/{handle}" if team else handle
        cmd = ["bash", str(send_sh), recipient, "-f", body.name, "--fyi", "--wake"]
        sender = _clear_instruction_from_handle()
        if sender:
            cmd.extend(["--from", sender])
        result = verbose.run(cmd, check=False)
        return result.returncode
    finally:
        try:
            os.unlink(body.name)
        except OSError:
            pass


def _clear_yield_if_reset_fenced(
    held, bus: pathlib.Path | None = None, action: str = "clear"
) -> None:
    """Store-then-load close of the clear-vs-reset race (tap-dgdn round 4).

    cmd_clear's one-time refuse_if_team_reset_fenced ran before our clear
    fence existed, so a reset that acquired reset.fence.json inside that
    interval revalidated against an EMPTY clear-fence dir and is now
    checkpointing — nothing would stop our later respawn-pane -k from
    taking that reset down mid-cut. Recheck after our own fence is durably visible:
    whichever side claims second sees the other's claim — reset's
    revalidation sees our fence (clear_in_flight), or we see reset's fence
    here and yield, releasing so the courier never parks on a clear that
    refused. No lock is held across the respawn in either arm.
    `bus` and `action` carry the same cross-team obligation as the one-time check
    this closes the race for. Left ambient, THIS recheck reopens the very window
    it exists to shut for any caller acting on another team: the precheck fences
    the target, the target's reset then publishes its fence, and this call
    inspects the CALLER's bus, passes, and lets stamp+respawn run beside a live
    checkpoint. A source-order guard cannot see that — it proves only that some
    recheck happens, not which bus it read.
    """
    try:
        refuse_if_team_reset_fenced(action, bus=bus)
    except LauncherError:
        held.release()
        raise


def relaunch_target(key: str) -> tuple[str, str, str, pathlib.Path]:
    """Resolve `<team>/<handle>` to (team, handle, root, bus) for a cross-team relaunch.

    Deliberately resolves ONE team through the global registry rather than reading
    every enrolled team the way `machine_registry_session_state` does: that walk
    raises on the first unreadable registry on the machine, so an unrelated team's
    corruption would veto a valid relaunch of a healthy seat. A verb the cap
    watcher runs over six teams cannot have that failure mode.

    The bus comes from the TARGET's registry location, not the caller's cwd. Every
    fence this verb takes is the target team's — see refuse_if_team_reset_fenced.
    """
    if "/" not in key:
        raise LauncherError(
            f"usage: tap session relaunch <team/handle> (got {key!r}); "
            "relaunch is machine-scoped and needs the team, e.g. tap/luna-cleanup-researcher"
        )
    team, _, handle = key.partition("/")
    team = team.strip()
    handle = handle.strip()
    if not team or not handle or "/" in handle:
        raise LauncherError(
            f"usage: tap session relaunch <team/handle> (got {key!r})"
        )
    status, root, location = registry_v20.resolve_team_from_global(
        registry_v20.global_registry_path(), team
    )
    if status == "ok":
        # THE BUS COMES FROM THE ROOT AUTHORITY, NOT FROM THE REGISTRY'S PATH.
        #
        # `busForRegistry` (runtime/bun/src/clear-fence.ts) special-cases exactly
        # one shape — a
        # parent directory named `.tap` containing a `bus/` child — and otherwise
        # returns the registry file's own parent. That is correct for the callers
        # that hold nothing but a path, and it is wrong here, because a RELOCATED
        # acting registry (`<root>/.tap/elsewhere/registry.json`) then yields
        # `<root>/.tap/elsewhere` while the courier and the reset both observe
        # `registry_v20.bus_home(root)` — measured divergence, not a hypothesis.
        #
        # Everything this verb does with that value is a fence: the clearing
        # fence, the reset-fence precheck, and the post-acquire recheck that
        # closes the clear-vs-reset race. All three would publish and read where
        # nothing looks, which is the target-bus class this verb was built
        # around, one layer below where it was fixed. We hold the root here, so
        # ask the authority that owns the question — including its legacy
        # `tmp/tap` fallback, which a hard-coded `.tap/bus` would silently drop.
        #
        # `bus_for_registry`'s shared contract is deliberately left alone: it
        # serves `tap clear`, whose blast radius is outside this PR.
        return team, handle, root, pathlib.Path(registry_v20.bus_home(root))
    detail = {
        "missing": f"team {team!r} is not enrolled on this machine",
        "historical": f"team {team!r} is historical and not addressable",
        "unreachable": f"team {team!r} is enrolled but its registry is missing ({location})",
        "invalid": f"the global registry is unreadable ({root})",
    }.get(status, f"team {team!r} could not be resolved ({status})")
    raise LauncherError(f"{detail}; next: tap doctor")


def replace_harness_in_pane(
    *,
    verb: str,
    root: str,
    handle: str,
    pane_id: str,
    record: SessionRecord,
    invocation: Invocation,
    instruction: str | None,
    bus: pathlib.Path,
    clear_history: bool,
    verify_fresh_registration: bool = True,
    # The batch's authorization, threaded to the last moment before the effect.
    # Absent for `tap clear`, which has no enumeration to drift from and whose
    # lock duration must not move.
    expect: dict | None = None,
    expect_resume: object = _UNSET_RESUME_EXPECTATION,
    # tap-74h2l: the team that owns the TARGET seat, threaded from
    # relaunch_target so the post-rebind instruction is addressed to that
    # team's bus. Absent for `tap clear`, which stays caller-team-scoped.
    team: str | None = None,
    success: "collections.abc.Callable[[str], str]",
) -> int:
    """Replace the harness process inside an OCCUPIED pane and verify readiness.

    Shared by `tap clear` (fresh context) and `tap session relaunch` (same context).
    Clear requires a fresh registration witness; relaunch preserves the existing
    row and requires the intended harness to be observable in the pane. The fence,
    nonce, remain-on-exit window, and effect boundary stay shared. Keeping one copy
    is the point: the alternative was a second pane lifecycle implementation that
    drifts silently.
    """
    ceiling = clear_rebind_timeout(record.harness)
    nonce = str(uuid.uuid4())
    invocation = Invocation(
        invocation.argv,
        {**invocation.env, "TAP_CLEAR_ID": nonce},
        invocation.unset_env,
    )

    held = clear_fence.try_acquire(
        bus, handle, nonce, os.getpid(), record.harness, ceiling,
    )
    if held is None:
        # DIAGNOSTIC ONLY, and deliberately a plain read with no subprocess.
        # The reader moved to runtime/bun/src/clear-fence.ts, but none of its
        # work is wanted here: try_acquire has already failed, so liveness is
        # decided and only the holder's name is missing. A losing clear must
        # change nothing, which is why this does not shell out to anything.
        # Both fields fall back to "unknown", exactly as they already did when
        # the contending marker was torn.
        holder, since = _contending_clearer(bus, handle)
        print_session_error(
            verb,
            "clear_in_progress",
            "wait for the in-flight replacement to finish, then retry",
            f"another in-place replacement of '{handle}' is in progress "
            f"(pid {holder} since {since}); nothing was changed",
        )
        return 2
    _clear_yield_if_reset_fenced(held, bus=bus, action=verb)
    # REMAIN-ON-EXIT IS ARMED BEFORE ANYTHING IS REPLACED, and this is the single
    # most important line in the verb. Production seats run with it OFF, so a
    # harness that fails on the way up — bad argv, a missing binary, the agy
    # --print class — takes the PANE with it, and a single-window seat loses its
    # session too. That is the identity fork this whole verb exists to prevent,
    # arriving through the safe-looking door: the operator asked for a restart and
    # got a seat torn down. Armed, a stillborn harness leaves the pane PRESENT but
    # exited — readable by the operator, still nameable by the registry.
    remain_armed = False
    verified = False
    before_respawn: PaneFacts | None = None
    try:
        remain_armed = verbose.run(
            ["tmux", "set-option", "-p", "-t", pane_id, "remain-on-exit", "on"],
            check=False,
        ).returncode == 0
        if not remain_armed:
            # NEVER SILENT. CONTRACT.md promises this protection, and a best-effort
            # call that quietly fails would leave the promise written down and unkept
            # while the respawn proceeds unprotected.
            print(
                f"{verb}: WARNING: could not arm remain-on-exit on pane {pane_id}; "
                "if the harness fails to start, the pane (and a single-window "
                "seat's session) will be lost rather than kept for inspection",
                file=sys.stderr,
            )
        try:
            # -k because this is also the hung-harness recovery path: a harness that
            # stopped reading input will not exit politely, and there is no second verb
            # for that. It is equally the CAPPED-harness path: a codex process that has
            # had its turn refused is not reliably able to process `/exit` either, which
            # is why relaunch has no soft path to fall back from.
            #
            # -c is not decoration: the pane's working directory follows whatever the
            # OLD process cd'd to, and SessionStart resolves the bus from cwd — so
            # without this a seat that wandered rebinds against a stranger worktree.
            # THE STAMP AND THE EFFECT SHARE ONE AUTHORIZATION WINDOW. The
            # standalone stamp used to run ~38 lines above, outside the
            # try/finally that releases the fence and with no identity check of
            # its own. It is now inside this context, which validates the fresh
            # row and the effective resume target, stamps, and holds the registry
            # lock across the respawn below — so no registry write can interleave
            # between the authorization and the pane replacement.
            #
            # Only this call is indented; the fence and remain-on-exit nesting are
            # untouched, so every new refusal lands inside the finally blocks that
            # already disarm and release. Reindenting the surrounding 110 lines
            # was tried first and produced a SyntaxError — the smaller shape is
            # not a compromise, it is the one that keeps those guarantees provable.
            if not verify_fresh_registration:
                before_respawn = tmux_pane_facts(pane_id)
                if before_respawn is None or before_respawn.pane_id != pane_id:
                    raise LauncherError(
                        f"pane {pane_id} disappeared before its harness could be replaced"
                    )
                if not before_respawn.server_epoch:
                    raise LauncherError(
                        f"pane {pane_id} has no observable tmux server generation; "
                        "refusing before replacement"
                    )
                if not before_respawn.pane_pid:
                    raise LauncherError(
                        f"pane {pane_id} has no observable harness process identity; "
                        "refusing before replacement"
                    )
            with authorized_clear_stamp(
                root, handle, nonce,
                tag=handle, expect=expect, expect_resume=expect_resume,
                recipe={"harness_env": record.harness_env,
                        "harness_unset_env": record.harness_unset_env,
                        "harness_tail": record.harness_tail},
                **({"permissions": record.permissions} if record.permissions is not None else {}),
            ):
                verbose.run(
                    [
                        "tmux", "respawn-pane", "-k", "-t", pane_id,
                        "-c", record.cwd,
                        invocation.shell_command(),
                    ],
                    check=True,
                )
            if not verify_fresh_registration:
                print(
                    f"{verb}: respawned {record.name} at {pane_id}; "
                    f"waiting for {record.harness} to start",
                    flush=True,
                )
            if clear_history:
                # The fresh-buffer half of a /clear. Relaunch deliberately does NOT do
                # this: it promises the conversation survives, and discarding the
                # operator's scrollback in the same motion would discard the only
                # local record of what the seat was doing when it was replaced.
                verbose.run(["tmux", "clear-history", "-t", pane_id], check=False)

            await_started = time.monotonic()
            if verify_fresh_registration:
                verified = await_clear_rebind(root, handle, pane_id, nonce, ceiling)
                record_clear_latency(
                    root, handle, record.harness, pane_id, verified,
                    time.monotonic() - await_started, ceiling,
                )
            else:
                assert before_respawn is not None and before_respawn.pane_pid
                verified = await_harness_start(
                    pane_id,
                    record.harness,
                    ceiling,
                    expected_server_epoch=before_respawn.server_epoch,
                    previous_pane_pid=before_respawn.pane_pid,
                    detect_resume_picker=bool(record.harness_session_id),
                )
        finally:
            # Disarm only after the wait: the window this protects is respawn ->
            # rebound, and holding it open longer would change how the seat behaves
            # for the rest of its life.
            if remain_armed:
                verbose.run(
                    ["tmux", "set-option", "-p", "-t", pane_id, "remain-on-exit", "off"],
                    check=False,
                )
        consume_expected_clear_nonce(root, handle, nonce)
        if not verified:
            post = tmux_pane_facts(pane_id)
            error_class, state = clear_unverified_diagnosis(post, record.harness)
            if verify_fresh_registration:
                detail = (
                    f"respawned {handle} at {pane_id}, but it did not re-register with "
                    f"this witness within {ceiling:.0f}s: {state}."
                )
            else:
                if post and post.dead is True:
                    error_class = "harness_start_unverified_dead"
                    state = (
                        "the pane is present but the resumed harness process "
                        "exited before readiness was observed"
                    )
                else:
                    error_class = error_class.replace(
                        "rebind_unverified", "harness_start_unverified"
                    )
                detail = (
                    f"respawned {handle} at {pane_id}, but {record.harness} did not "
                    f"become observable there within {ceiling:.0f}s: {state}."
                )
            print_session_error(
                verb,
                error_class,
                f"tmux attach -t {pane_id}   # the pane is the authority",
                detail,
            )
            # 7, not 2, and the distinction is the whole point: every REFUSAL from this
            # verb exits 2 having changed nothing, while this state has already replaced
            # the process. A caller that cannot tell "nothing happened" from "the
            # process is gone and readiness is unconfirmed" will retry the second as if
            # it were the first.
            return 7
        if instruction and record.harness == "opencode":
            # Fence is still held. The send parks (reason=clearing); drain
            # delivers it first, before any send parked later in the window.
            send_rc = deliver_clear_instruction_via_send(handle, instruction, team=team)
            if send_rc != 0:
                recipient = f"{team}/{handle}" if team else handle
                sender = _clear_instruction_from_handle()
                from_flag = f"--from {sender}" if sender else "--from <your-handle>"
                print_session_error(
                    verb,
                    "instruction_undelivered",
                    f"tap send {recipient} -f <file> --fyi --wake {from_flag}",
                    f"replaced {handle} ({record.harness}) in place at {pane_id}, "
                    f"but the -m instruction did not land (send exit {send_rc})",
                )
                return 6
        print(success(pane_id))
        return 0
    finally:
        held.release()


def cmd_clear(args) -> int:
    refuse_if_team_reset_fenced("clear")
    cwd = str(pathlib.Path.cwd().resolve())
    root = root_for_cwd(cwd)
    handle = getattr(args, "seat", None)
    if not handle:
        raise LauncherError("usage: tap clear <seat> [-m <instruction>]")
    pane_id, entry = clear_target_pane(root, handle, "tap clear")

    # The target row is the recipe. Crew share a parent's tmux session, so a
    # session-name lookup selects the parent's harness and tuning.
    record = session_record_from_registry_row(handle, entry, {}, root)
    if record is None:
        raise LauncherError(
            f"seat '{handle}' has no valid harness/session launch recipe on its row; "
            "re-register it from its live pane before clearing"
        )

    # A FRESH conversation, which is the whole point: /clear mints a new native
    # session anyway, so nothing is preserved by reusing the old id — and reusing
    # it would point the new process at an already-populated session.
    cleared = dataclasses.replace(record, harness_session_id=None)
    cleared = mint_launch_session_id(cleared)
    if cleared.harness == "claude" and not cleared.harness_session_id:
        cleared = dataclasses.replace(cleared, harness_session_id=str(uuid.uuid4()))
        cleared.identity_capture_action = "new"

    instruction = getattr(args, "message", None)
    # Builds before anything is mutated or replaced. opencode used to refuse
    # here when -m was set; it now builds a no-prompt argv and the instruction
    # rides the bus after rebind.
    invocation = launch_invocation("new", cleared, initial_prompt=instruction)

    if getattr(args, "dry_run", False):
        print(invocation.shell_command())
        if instruction and cleared.harness == "opencode":
            print(
                "tap clear: opencode instruction rides tap send after rebind "
                "(no argv channel; fence holds the send so drain delivers it first)"
            )
        return 0

    bus = _team_bus_home()
    if bus is None:
        bus = pathlib.Path(root) / ".tap" / "bus"
        bus.mkdir(parents=True, exist_ok=True)

    return replace_harness_in_pane(
        verb="tap clear",
        root=root,
        handle=handle,
        pane_id=pane_id,
        record=cleared,
        invocation=invocation,
        instruction=instruction,
        bus=bus,
        clear_history=True,
        success=lambda pane: (
            f"tap clear: cleared {handle} ({cleared.harness}) in place at {pane}"
        ),
    )


# Fields that make a seat THE SAME SEAT holding THE SAME CONVERSATION. Deliberately
# not the whole row: `last_seen` and `status` churn on their own, and refusing on
# those would refuse healthy seats mid-outage.
RELAUNCH_IDENTITY_FIELDS = ("harness", "pane_id", "harness_session_id")


def relaunch_identity(row: dict | None) -> dict:
    """The identity a batch turn must still find when its turn arrives."""
    row = row if isinstance(row, dict) else {}
    return {f: row.get(f) for f in RELAUNCH_IDENTITY_FIELDS}


def refuse_on_identity_drift(tag: str, expect: dict | None, found: dict | None) -> None:
    """Refuse a seat that is no longer the seat enumeration classified.

    THE WINDOW THIS CLOSES. Enumeration classifies a ROW — harness, pane,
    conversation — but the batch is SERIALIZED, so minutes can pass between that
    classification and one member's turn, and the turn re-resolves from the
    registry. A seat that re-registers as claude in between would be respawned by
    a `--harness codex` batch, using its now-claude record: the same wrong-record
    class the crew-row guards exist for, arriving through the time gap rather
    than the resolution path.

    Harness alone is not enough. A seat replaced by a DIFFERENT seat on the same
    harness has a different pane and a different conversation, and this verb's
    whole promise is the same conversation — so the pane and the stored session
    id are part of the identity.

    Inert without an expectation, which is what keeps the single-seat form
    (`tap session relaunch <team/handle>`, no enumeration, nothing to drift from)
    exactly as it was.
    """
    if not expect:
        return
    # COMPARED OVER THE FIELDS THE EXPECTATION CARRIES, not over the full triple.
    # `relaunch_identity` normalizes a row to all three fields with None for the
    # absent ones, so comparing a two-field expectation against that normalized
    # dict reported a difference with an EMPTY field list — a refusal that could
    # not say what moved, which is a refusal nobody can act on. Callers that hold
    # only part of the identity (the launch record owns harness and session id
    # but no pane) must be able to check the part they hold.
    fields = [f for f in RELAUNCH_IDENTITY_FIELDS if f in expect]
    now = relaunch_identity(found)
    moved = [f for f in fields if expect.get(f) != now.get(f)]
    if not moved:
        return
    detail = ", ".join(f"{f} {expect.get(f)!r} -> {now.get(f)!r}" for f in moved)
    raise LauncherError(
        f"seat '{tag}' changed since enumeration ({detail}); refusing rather than "
        "replacing a process this batch never classified"
    )


def relaunch_one(key: str, message: str | None, dry_run: bool,
                 expect: dict | None = None,
                 expect_resume: object = _UNSET_RESUME_EXPECTATION,
                 overrides: dict | None = None) -> int:
    """Restart ONE seat's harness in its own pane, KEEPING its conversation.

    The sibling of `tap clear`, and the difference is the contract rather than the
    mechanism: clear promises the same seat with a fresh context; relaunch promises
    the same seat with the SAME context — the harness process is replaced and its
    stored conversation is resumed. It exists because a credential swap only takes
    effect at harness startup, so the fleet has to be restarted without losing
    what any seat was in the middle of.
    """
    team, handle, root, bus = relaunch_target(key)
    tag = f"{team}/{handle}"

    # The TARGET team's fence, not the caller's. A cross-team verb that fenced its
    # own bus would mutate one team's registry under another team's guarantee.
    refuse_if_team_reset_fenced("session relaunch", bus=bus)

    # Recovery text is the TARGET's, not the caller's. `tap session restart` and
    # `tap team` are caller-team-scoped, so copying a bare hint out of a
    # machine-scoped refusal would act on a same-named seat in whatever team the
    # operator happens to be standing in.
    where = f"cd {root} && "

    # CLASSIFY THE ROW BEFORE RESOLVING A PANE. Pane resolution's refusals speak
    # the language of launcher-managed seats ("recreate it: tap session restart"),
    # which is inapplicable to a crew or poll row and would hand the operator a
    # command for a seat that does not work that way. Classification first means
    # such a row always leaves through seat_not_relaunchable.
    entry = registry_entry(root, handle)
    if not entry:
        raise LauncherError(
            f"no seat '{tag}'; run `{where}tap team` to see who is registered"
        )

    # CREW ROWS ARE NOT RELAUNCHABLE, AND THE FAILURE IS NOT A WRONG ERROR MESSAGE.
    # A crew seat shares its DRIVER's tmux session, and the launcher manifest holds
    # a record for the driver, not the crew. Resolving by session name therefore
    # returned the driver's record — a different harness and a different
    # conversation — and the verb would have replaced the crew's process and started
    # the driver's conversation in its pane. Observed at fd0a3c9b..598519ac:
    # `relaunch tap/sol-pinnacle-design` (codex crew) rendered a claude --resume of
    # the driver's own session id. Two independent guards now stand between that:
    # the shared relaunchable predicate, and an identity cross-check below.
    # IMMEDIATELY AFTER THE RE-READ, BEFORE ANY CLASSIFICATION OR EFFECT: the row
    # this turn is about to act on must still be the row the batch selected.
    refuse_on_identity_drift(tag, expect, entry)

    if not registry_v20.seat_is_relaunchable(entry):
        # DO NOT NAME `tap clear` HERE. It resolves its record by session name, so
        # on a crew handle it renders the DRIVER's invocation — verified live:
        # `tap clear sol-pinnacle-design --dry-run` from the team root produced a
        # claude launch for tap/opus-tidying-creator. Recommending it would
        # recreate, as the sanctioned recovery, the exact wrong-record class this
        # refusal exists to stop. (The clear-on-crew defect predates this verb and
        # is filed separately; naming it as recovery would be new.)
        owner = entry_session_name(entry) or "its driver's session"
        print_session_error(
            "tap session relaunch",
            "seat_not_relaunchable",
            f"{where}tap crew list   # crew live and die with their driver's pane",
            f"seat '{tag}' is not a launcher-managed, pane-backed seat (crew, poll, or a "
            f"suspended row), so it has no launch recipe of its own to replay — it lives in "
            f"'{owner}'. A crew seat is replaced by its driver, not by this verb.",
        )
        return 2

    pane_id, entry = clear_target_pane(
        root, handle, "tap session relaunch",
        restart_hint=f"{where}tap session restart {handle}",
        roster_hint=f"{where}tap team",
    )

    # THE ACTING ROW IS RE-CHECKED, because it is a SECOND registry read.
    # `clear_target_pane` re-reads the registry and returns a fresh row that
    # rebinds `entry`, and everything below — the session name, the resume
    # identity, the rendered invocation, the fence, the respawn — uses that row
    # rather than the one compared above. Checking only the first read left the
    # drift window open one mutable read later: verified on the production path,
    # a matching first row plus a drifted `clear_target_pane` row rendered
    # `claude ... --resume <new id>` and returned 0.
    #
    # The earlier comparison is kept deliberately: it refuses before
    # classification and before this call, so an already-drifted seat costs
    # nothing further. This one is the load-bearing check, because this is the
    # row that acts.
    refuse_on_identity_drift(tag, expect, entry)

    state = registry_session_state(root)
    session_name = entry_session_name(entry)
    if not session_name:
        raise LauncherError(
            f"seat '{tag}' has no session on record, so there is no launch recipe to "
            f"replay; recreate it with {where}tap session launch instead"
        )
    # BY HANDLE, never by the shared session name. This is the second guard: a row
    # whose session belongs to another seat resolves to no record here rather than
    # to that seat's record.
    record = None
    for candidate in state.sessions:
        if session_handle(candidate) == handle:
            record = candidate
            break
    # THE LAUNCH RECIPE IS BOUND TO THE GUARDED IDENTITY TOO.
    #
    # `registry_session_state` above is a THIRD independent read of the acting
    # registry, and the `SessionRecord` selected from it supplies `record.harness`,
    # the resume identity, and the rendered invocation. The two guards before this
    # point both compare `entry`; the object that becomes the command line is
    # `record`, from a later snapshot. The only cross-check here is handle plus
    # session name — neither of which moves when a seat re-registers under a
    # different harness with a new conversation.
    #
    # Measured on the production path: both guarded reads returned the enumerated
    # codex row while the third snapshot returned the same handle and name as a
    # claude record with a new id, and a `--harness codex` batch rendered
    # `claude ... --resume <new id>` and returned 0. Guarding two reads and
    # letting a third build the argv is the same defect the first two guards were
    # added for, one snapshot further along.
    #
    # Compared BEFORE the ownership refusal below, because a drifted record is a
    # more specific answer than "another seat owns this session" and the operator
    # should be told which fact stopped the run.
    # COMPARED FIELD-BY-FIELD AGAINST WHAT THE EXPECTATION ACTUALLY CARRIES, not
    # as a whole-dict equality. A registry ROW and a SessionRecord do not describe
    # a seat with the same fields: rows frequently carry no `harness` at all (the
    # launcher record owns it), so a whole-dict compare read `None -> 'codex'` as
    # drift and refused a seat that had not moved — caught by the unchanged-row
    # polarity arm, which is exactly what it is for. Only fields the enumerated
    # row actually supplied can be evidence of a change; a field it never had is
    # a shape difference, not drift.
    if record is not None and expect:
        # KEY PRESENCE, NOT NON-NONE VALUE. `is not None` conflates two different
        # facts: "the expectation does not carry this field" and "the expectation
        # carries it, and its value is None". `relaunch_identity` always carries
        # `harness_session_id`, and None is a MEANINGFUL value there — a codex row
        # with no stored conversation id is a valid enumerated member
        # (`seat_is_relaunchable` does not require one, and batch enumeration
        # requires only a readable harness). Dropping the field on a None value
        # therefore let absent -> 'new-id' through: the third snapshot supplied a
        # conversation the batch never classified, and `codex ... resume new-id`
        # rendered at exit 0.
        #
        # The helper already has key-presence semantics, so handing it the keys
        # is enough; `pane_id` stays out because a SessionRecord has no pane.
        checkable = {f: expect[f] for f in ("harness", "harness_session_id")
                     if f in expect}
        if checkable:
            refuse_on_identity_drift(tag, checkable, {
                "harness": record.harness,
                "harness_session_id": record.harness_session_id,
            })

    if record is None or record.name != session_name:
        owner = record.name if record is not None else "another seat"
        print_session_error(
            "tap session relaunch",
            "seat_session_mismatch",
            f"{where}tap session list --json   # see which seat owns {session_name}",
            f"seat '{tag}' is registered in session '{session_name}', but the launcher "
            f"record for that session belongs to {owner}. Refusing to replay a launch "
            "recipe this seat does not own.",
        )
        return 2

    # THE SEMANTIC GATE RUNS FIRST, AND ITS ANSWER IS THEN BOUND TO THE LAUNCH.
    # Resolving here and again inside the builder would be two decisions over
    # mutable on-disk transcript state: the gate could see an identity while argv
    # was built id-less, and the seat would be replaced by a picker invocation —
    # the degradation this gate exists to refuse. So exactly ONE resolve reaches
    # the builder, passed in rather than recomputed. Which one depends on the
    # form: a single seat launches this turn's resolve, while a batch replaces it
    # with the enumerated value a few lines below — see the block that follows.
    #
    # It refuses rather than falling back on purpose: a relaunch that silently
    # produced a fresh context or a picker would be `tap clear` wearing this
    # verb's name, on a working seat, at the exact moment nobody is watching.
    resumed_id = resolved_resume_identity(record, emit_receipts=True)

    # THE VALUE THAT AUTHORIZES IS THE VALUE THAT RUNS — enforced HERE, before
    # argv exists, not only at the locked boundary.
    #
    # `resumed_id` is this turn's resolve of mutable disk state. The boundary
    # compares its own fresh read against the enumerated value, which stops a
    # drift that PERSISTS — but not a flip-back: disk resolves `new-id` here, argv
    # is built as `--resume new-id`, disk returns to `ghost-id` before the locked
    # read, and the boundary then approves the enumerated id while the already
    # built invocation carries the other one. Two agreeing resolves at different
    # instants are not the same fact.
    #
    # So a batch refuses on mismatch before anything is rendered, and then builds
    # from the ENUMERATED value rather than the turn's. The single-seat form keeps
    # its turn-resolved id: it authorized "this seat", and the resolver is the
    # conversation.
    if expect_resume is not _UNSET_RESUME_EXPECTATION:
        if resumed_id != expect_resume:
            raise LauncherError(
                f"seat '{tag}' now resolves to a different conversation than the one "
                f"enumerated ({expect_resume!r} -> {resumed_id!r}); refusing rather than "
                "resuming a conversation this batch never classified"
            )
        resumed_id = expect_resume

    instruction = message
    if resumed_id is None:
        print_session_error(
            "tap session relaunch",
            "no_exact_resume_identity",
            f"run tap in from the live seat pane to capture its open session file; "
            f"otherwise use the harness picker to select the conversation. "
            f"{where}tap clear {handle} starts FRESH context and loses the conversation",
            f"seat '{tag}' ({record.harness}) has no resumable conversation id: the launch "
            f"it would run carries no session id (revive tier "
            f"'{revive_tier(record.harness, record.harness_session_id)}'), so the harness "
            "would return at its picker or in a new conversation. Relaunch promises the "
            "same conversation and will not silently start a different one.",
        )
        return 2

    if overrides:
        record = apply_session_overrides(record, overrides)

    invocation = launch_invocation(
        "resume", record, initial_prompt=instruction, resume_identity=resumed_id
    )

    if dry_run:
        print(invocation.shell_command())
        return 0

    started = time.monotonic()
    return replace_harness_in_pane(
        # The batch's authorization, carried to the final pre-effect boundary.
        # `expect_resume` is the effective target ENUMERATION resolved — never
        # `resumed_id`, which this turn resolved for itself and would therefore
        # be comparing against its own adoption. A claude transcript appearing
        # between the census and this worker's turn changes `resumed_id` while
        # the row's raw fields stay identical; only the enumerated value can
        # refuse that.
        expect=expect,
        expect_resume=expect_resume,
        verb="tap session relaunch",
        root=root,
        handle=handle,
        pane_id=pane_id,
        record=record,
        invocation=invocation,
        instruction=instruction,
        bus=bus,
        # tap-74h2l: the instruction is addressed to the TARGET team's bus,
        # the same team relaunch_target resolved this seat from.
        team=team,
        clear_history=False,
        verify_fresh_registration=False,
        success=lambda pane: (
            f"tap session relaunch: {tag} ({record.harness}) resumed in place at {pane} "
            f"· id={resumed_id} · {time.monotonic() - started:.1f}s"
        ),
    )


# Ruling 36 named claude and codex. Cursor was added after verified auth, and
# Ops ruled on opencode on 2026-09-17 — the fleet form still respawns a whole
# cohort, so it stays an allowlist rather than HARNESSES. The single-seat verb
# stays generic.
RELAUNCH_BATCH_HARNESSES = ("claude", "codex", "cursor", "opencode")


def relaunch_batch_members(
    harness: str, team_filter: str | None
) -> tuple[list[tuple[str, str, dict, str | None]], list[tuple[str, str]], str | None]:
    """Relaunchable seats of one harness, plus the teams that could NOT be read.

    Returns (members, skipped, team_status). `team_status` is the requested
    team's verdict resolved FROM THIS SAME SNAPSHOT — `None` for machine-wide
    enumeration, else `ok` / `missing` / `historical` / `unreachable` (the last meaning
    the team is enrolled but its acting registry file is absent). Resolving it here rather than in
    the caller is the whole point: the caller used to resolve the team from one
    read of the global registry and then enumerate from a second, so a team
    removed or made historical between the two reads produced an empty selection
    and a clean exit 0 — the ruled typed refusal silently downgraded to "no
    relaunchable seats". One snapshot answers both questions.

    `skipped` is [(team, reason)]. The skipped list
    is the load-bearing half: an earlier version only PRINTED the skip, so a team
    the enumerator could not open vanished from the aggregate and a fleet the
    caller never examined still exited 0. A watcher branching on that exit would
    have read "all resumed" for seats nobody looked at.

    Walking team by team, rather than through the machine-wide session state, is
    deliberate: that walk raises on the first unreadable registry anywhere on the
    machine, which would let one unrelated team's corruption veto the fleet
    relaunch this verb exists for. Skipping is right; skipping SILENTLY is not.
    """
    members: list[tuple[str, str, dict, str | None]] = []
    skipped: list[tuple[str, str]] = []
    try:
        doc = registry_v20.load_state_doc(registry_v20.global_registry_path())
    except Exception as exc:
        raise LauncherError(f"global registry unreadable: {exc}; next: tap doctor") from exc

    # AUTHORITY IS VALIDATED, NOT ASSUMED. This document decides which teams exist
    # and therefore which cohort gets respawned; an unsanctioned schema reaching
    # relaunch_one means an invalid authority authorized the action.
    if not isinstance(doc, dict) or str(doc.get("schema") or "") != registry_v20.SCHEMA:
        raise LauncherError(
            f"global registry schema is not {registry_v20.SCHEMA}; next: tap doctor"
        )
    # PRESENCE-SENSITIVE, per registry_v20.flip_marker_state and CONTRACT: an
    # OMITTED `teams` key is valid and means empty; a PRESENT non-dict value is
    # invalid. An earlier version of this refused both, which contradicted the
    # documented rule for a legitimately empty machine.
    if "teams" in doc and not isinstance(doc["teams"], dict):
        raise LauncherError(
            "global registry's teams map is not an object; next: tap doctor"
        )
    teams = doc.get("teams") if isinstance(doc.get("teams"), dict) else {}

    team_status: str | None = None
    if team_filter:
        requested = teams.get(team_filter)
        if not isinstance(requested, dict):
            team_status = "missing"
        elif requested.get("state", "registered") == "historical":
            team_status = "historical"
        else:
            team_status = "ok"
        if team_status != "ok":
            return members, skipped, team_status
        # `ok` here is PROVISIONAL. The location checks below can still downgrade
        # it — see the two assignments inside the loop. An earlier version fixed
        # the verdict at this point and lost `unreachable` entirely, so a scoped
        # run whose team could not be resolved degraded to 6 ("processed, but
        # degraded") instead of refusing with 2 ("nothing was processed").

    for team_name, enrollment in sorted(teams.items()):
        # THE KEY FILTER RUNS FIRST. Validating rows before filtering let an
        # unrelated team's corruption degrade a scoped `--team` run — the exact
        # thing walking team by team exists to prevent.
        if team_filter and team_name != team_filter:
            continue
        # EVERY NON-HISTORICAL ENROLLED TEAM THAT CANNOT YIELD A READABLE REGISTRY
        # BECOMES A RECORDED SKIP. A bare `continue` here is the same defect as
        # printing without returning: the team silently leaves the fleet and the
        # aggregate says 0 for scope nobody examined. Historical teams are the one
        # exception — they are deliberately not addressable, so their absence is
        # the answer rather than a gap.
        if not isinstance(enrollment, dict):
            skipped.append((str(team_name), "enrollment row is not an object"))
            continue
        if enrollment.get("state", "registered") == "historical":
            continue
        location = enrollment.get("registry_location")
        if not isinstance(location, str) or not location:
            skipped.append((team_name, "no registry_location recorded"))
            if team_name == team_filter:
                # resolve_team_from_global classified this `missing`; the explicit
                # form must keep refusing rather than reporting a degraded fleet.
                team_status = "missing"
            continue
        try:
            payload = registry_v20.load_state_doc(location)
        except Exception as exc:
            skipped.append((team_name, f"registry unreadable ({exc})"))
            continue
        # load_state_doc returns {} for a MISSING FILE — and also for a file that
        # exists and contains {}. The two are indistinguishable from the parsed
        # value alone, so the existence bit is recovered separately rather than
        # inferred: ABSENT is `unreachable` (the team cannot be located, an
        # explicit --team refuses), while PRESENT-but-empty is located and parsed
        # yet structurally invalid, which is a degraded run, not a missing team.
        # Labelling a present registry "missing" would be a false statement in the
        # operator's error text as well as the wrong exit code.
        if not isinstance(payload, dict) or not payload:
            located = os.path.isfile(location)
            if located:
                skipped.append(
                    (team_name, f"registry at {location} is empty or structurally invalid")
                )
            else:
                skipped.append((team_name, f"registry missing at {location}"))
                if team_name == team_filter:
                    # Absent: the team cannot be located at all.
                    # A present-but-UNPARSEABLE registry raises above and stays a
                    # skip (aggregate 6); so does a present-but-empty one here.
                    # Those distinctions predate this refactor and are preserved
                    # deliberately rather than collapsed.
                    team_status = "unreachable"
            continue
        # NO SCHEMA REQUIREMENT ON A *TEAM* REGISTRY, DELIBERATELY, AND THIS WAS
        # MEASURED. `SCHEMA` is enforced on the GLOBAL registry by
        # flip_marker_state (registry_v20.py:50) and nowhere else; the team
        # constructor emits one, but nothing validates it. On this machine 21 of
        # 48 enrolled team registries carry no `schema` key at all and are
        # perfectly live. Requiring it turned all 21 into skips — dropping real
        # teams out of the fleet and degrading every machine-wide run, which is
        # the exact erasure this validation exists to prevent, caused by the
        # validation itself. The structural check that actually discriminates is
        # the seat axis below.
        #
        # THE SEAT AXIS IS A TRI-STATE, and the missing case is what mattered:
        # `_seat_map` maps a document with neither `seats` nor `agents` to {},
        # so a structurally invalid registry read as a team with no seats and
        # left the fleet silently. seat_axis distinguishes valid-empty (the key
        # is a dict) from missing entirely.
        axis = registry_v20.seat_axis(payload)
        if axis is None:
            skipped.append((team_name, "registry has no seats/agents map"))
            continue
        # A READABLE AXIS IS NOT ENOUGH TO SAY THE COHORT WAS EXAMINED. A row that
        # cannot be classified — a non-string handle, a non-object row, or a
        # missing/non-string `harness` — means this team's answer is unknown, not
        # empty. Bare-continuing on it produced a clean `rc=0` for a team holding
        # an authoritative row nobody could read. The whole team becomes a skip and
        # its other rows are NOT partially relaunched: a partial cohort presented
        # as a complete one is the same defect one level down.
        #
        # A row that classifies cleanly to a DIFFERENT harness is an ordinary
        # exclusion, not a skip — that is the answer, not a gap.
        team_members: list[tuple[str, str, dict, str | None]] = []
        unclassifiable: str | None = None
        for handle, row in sorted(axis.items(), key=lambda kv: str(kv[0])):
            if not isinstance(handle, str) or not isinstance(row, dict):
                unclassifiable = f"row {str(handle)!r} is not a seat object"
                break
            row_harness = row.get("harness")
            if not isinstance(row_harness, str) or not row_harness:
                unclassifiable = f"seat {handle!r} has no readable harness"
                break
            if row_harness != harness:
                continue
            if not registry_v20.seat_is_relaunchable(row):
                continue
            # THE EFFECTIVE TARGET IS RESOLVED HERE, WITH THE ROW IT CLASSIFIES.
            # Resolving it inside the member's turn and comparing it to itself
            # authorizes nothing: a claude transcript
            # can appear between this moment and that turn — minutes later —
            # while the row's raw fields stay identical. The turn would then
            # adopt the new conversation and the boundary would confirm its own
            # adoption. What must be carried is the conversation THIS census saw.
            # The helper's contract wants the registry's TEAM document, not the
            # whole payload. It changes no field this resolver reads today, but a
            # future team-metadata read would silently take the wrong object.
            member_team_doc, _member_agents = registry_v20.seat_store(payload)
            if not isinstance(member_team_doc, dict):
                member_team_doc = {}
            member_root = enrollment.get("root")
            record = (
                session_record_from_registry_row(
                    handle, row, member_team_doc,
                    member_root,
                )
                if isinstance(member_root, str) and member_root
                else None
            )
            team_members.append((
                team_name,
                handle,
                row,
                resolved_resume_identity(record, emit_receipts=False)
                if record is not None
                else None,
            ))
        if unclassifiable:
            skipped.append((team_name, unclassifiable))
            continue
        members.extend(team_members)
    for team_name, reason in skipped:
        print(
            f"tap session relaunch: skipping team {team_name!r} — {reason}",
            file=sys.stderr,
        )
    return members, skipped, team_status


def cmd_relaunch(args) -> int:
    """`tap session relaunch` — one seat, or every seat of one harness.

    The batch form is what an operator runs when a harness binary changed under a
    running fleet, and what the cap watcher calls.
    """
    key = getattr(args, "seat", None)
    harness = getattr(args, "harness", None)
    if key and harness:
        raise LauncherError(
            "tap session relaunch takes a seat OR --harness, not both"
        )
    if not key and not harness:
        raise LauncherError(
            "usage: tap session relaunch <team/handle> | --harness <h> "
            "[--team <t>|--team='*'] [-m <instruction>]"
        )
    message = getattr(args, "message", None)
    dry_run = bool(getattr(args, "dry_run", False))
    if key:
        return relaunch_one(key, message, dry_run)

    requested_team = getattr(args, "team", None)
    # AN EXPLICIT --team THAT NAMES NO TEAM IS A REFUSAL, NOT AN ABSENT FILTER.
    #
    # argparse preserves `--team ""` as an explicit empty string, and every scope
    # check downstream is a truthiness test — so the empty string read as "no
    # --team at all" and the run widened to the whole machine. Measured before
    # the fix: `--harness codex --team "" --dry-run` returned 6 having enumerated
    # 59 rows across every enrolled team. A scoped request became an unscoped
    # respawn of the entire fleet, silently, from a shell variable that happened
    # to be empty.
    #
    # Omission now resolves to the current team; only an explicit `*` widens to
    # the machine fleet. This distinguishes "current scope", "all scopes", and
    # "scoped to nothing" without relying on truthiness.
    if requested_team is not None and not requested_team.strip():
        print_session_error(
            "tap session relaunch",
            "empty_team_filter",
            "pass a team name, omit --team for the current team, or pass --team='*' for every team",
            f"--team was given as {requested_team!r} and names no team; refusing rather "
            f"than widening to every {harness} seat on the machine",
        )
        return 2
    if requested_team is None:
        cwd = str(pathlib.Path.cwd().resolve())
        status, current_team = registry_v20.enrolled_team_name_for_root(root_for_cwd(cwd))
        if status != "ok" or not current_team:
            print_session_error(
                "tap session relaunch",
                "current_team_unresolved",
                "pass --team <name>, or --team='*' for every enrolled team",
                "the current working tree does not resolve to an enrolled TAP team; "
                "refusing rather than widening to the whole machine",
            )
            return 2
        team_filter = current_team
    elif requested_team.strip() == "*":
        team_filter = None
    else:
        team_filter = requested_team.strip()
    # ONE SNAPSHOT ANSWERS BOTH QUESTIONS. Resolving the requested team here and
    # enumerating from a second read let a team removed or made historical between
    # the two produce an empty selection and a clean 0 — the ruled typed refusal
    # downgraded to "no relaunchable seats" by a race.
    members, skipped_teams, team_status = relaunch_batch_members(harness, team_filter)
    if team_filter and team_status != "ok":
        detail = {
            "missing": f"team {team_filter!r} is not enrolled on this machine",
            "historical": f"team {team_filter!r} is historical and not addressable",
            "unreachable": f"team {team_filter!r} is enrolled but its registry is missing",
        }.get(team_status, f"team {team_filter!r} could not be resolved ({team_status})")
        print_session_error(
            "tap session relaunch",
            "unresolvable_team",
            "tap session list --machine --json   # see which teams are enrolled",
            f"{detail}; refusing rather than reporting an empty fleet",
        )
        return 2

    # THE CALLER'S OWN SEAT IS EXCLUDED BY CONSTRUCTION, not by the per-seat
    # guard. A verb that replaces the process it is running in cannot survive to
    # finish the run, and the seats after it in the list are the ones that pay.
    # `tap compact --all` states the same rule for the same reason. The per-seat
    # resolve_caller_pane_id() refusal remains as the SECOND line, never the
    # first: it refuses an unprovable caller only when it can see it is inside
    # tmux, so a caller that is provably elsewhere sails past it — which is
    # exactly the shape a --harness batch takes when it reaches its own pane.
    caller_pane = resolve_caller_pane_id()
    # THE ROW TRAVELS WITH THE KEY. Keeping only `(team, handle)` discarded the
    # very object enumeration classified, so the turn re-resolved from scratch
    # and could act on a seat that had since become something else.
    selected: list[tuple[str, str, dict, str | None]] = []
    excluded: list[str] = []
    for team_name, handle, row, resume in members:
        observed, _pane = seat_corpse.epoch_voided_ids(row, current_server_epoch())
        if caller_pane and observed == caller_pane:
            excluded.append(f"{team_name}/{handle}")
            continue
        selected.append((team_name, handle, relaunch_identity(row), resume))

    for tag in excluded:
        print(f"{tag} · excluded · caller-pane")
    for team_name, reason in skipped_teams:
        print(f"{team_name}/* · skipped · {reason}")

    if not selected:
        scope = f" in team {team_filter!r}" if team_filter else ""
        print(f"tap session relaunch: no relaunchable {harness} seats{scope}")
        # An empty fleet is only a clean 0 when nothing was skipped. If a team
        # could not be read, the caller has NOT been told about every seat of this
        # harness, and 0 would claim otherwise.
        return 6 if skipped_teams else 0

    refused = 0
    hard = 0

    def run_member(member):
        team_name, handle, expect, expect_resume = member
        tag = f"{team_name}/{handle}"
        started = time.monotonic()
        try:
            rc = relaunch_one(tag, message, dry_run, expect=expect,
                              expect_resume=expect_resume)
        except LauncherError as exc:
            return tag, "refused", str(exc), time.monotonic() - started
        except SystemExit as exc:
            return tag, "refused", f"exit {exc.code}", time.monotonic() - started
        except Exception as exc:  # noqa: BLE001 - see below
            # NO EXCEPTION MAY END THE RUN FOR THE SEATS THAT FOLLOW. The
            # transaction shells out to tmux with check=True (:8190), so a pane
            # that disappears between the liveness check and the respawn raises
            # CalledProcessError — and this loop used to catch only LauncherError
            # and SystemExit, so it escaped to main and every later seat went
            # unprocessed. That is the cap scenario precisely: the credential has
            # already moved, and one lost pane strands the rest of the fleet.
            #
            # DELIBERATELY BROAD. A narrower `except CalledProcessError` would
            # make the batch's completeness depend on which bug fires, and the
            # class this guards is "anything the transaction can raise", not one
            # shape we happen to have seen.
            #
            # HARD, NOT A REFUSAL. A refusal means nothing changed; an unexpected
            # failure here may have landed after the respawn, so it carries the
            # same look-at-the-pane text exit 7 does and drives the aggregate to
            # 1. The watcher branches on that: 6 is "as recovered as it can be",
            # and this is not that.
            return (
                tag,
                "hard-exception",
                f"{type(exc).__name__}: {exc}",
                time.monotonic() - started,
            )
        return tag, "rc", rc, time.monotonic() - started

    # Each member has its own per-seat clearing fence. Submit the complete cohort
    # before waiting so a slow harness cannot serialize every seat behind it;
    # the standard executor keeps a machine-wide cohort from minting one polling
    # thread per seat.
    with concurrent.futures.ThreadPoolExecutor() as pool:
        futures = [pool.submit(run_member, member) for member in selected]
        results = [future.result() for future in futures]

    for tag, kind, value, elapsed in results:
        if kind == "refused":
            print(f"{tag} · refused · {value}")
            refused += 1
        elif kind == "hard-exception":
            print(f"{tag} · FAILED · {value} — look at the pane")
            hard += 1
        elif value == 0:
            # A dry run resumed nothing; saying "resumed" would be a receipt for
            # work that did not happen.
            verb_word = "would-resume" if dry_run else "resumed"
            print(f"{tag} · {verb_word} · {elapsed:.1f}s")
        elif value == 2:
            print(f"{tag} · refused · nothing changed")
            refused += 1
        else:
            print(f"{tag} · FAILED · exit {value} — look at the pane")
            hard += 1

    # tap compact's convention rather than a new one: 0 all resumed, 6 degraded
    # (every failure was a per-seat refusal, so the fleet is as recovered as it
    # can be and the named seats need a human), 1 any hard failure (stop and
    # look). The distinction is what the cap watcher branches on.
    if hard:
        return 1
    if refused or skipped_teams:
        # A skipped team degrades the run for the same reason a per-seat refusal
        # does: the fleet is as recovered as it can be, and something named needs
        # a human. Exit 0 would tell the watcher the whole harness was examined.
        return 6
    return 0


def revive_tier(harness: str | None, native_id: str | None) -> str:
    """Short tier word for listings: how a seat's conversation would come back."""
    if harness not in HARNESSES:
        return "-"
    if native_id:
        return "exact"
    if harness in ("claude", "codex"):
        return "picker"
    if harness == "agy":
        return "latest"
    return "fresh"


def _refuse_if_flip_authority(
    verb: str, cwd: str | None = None, *, allow_unenrolled: bool = False,
) -> None:
    """Refuse launch/resume/restart mutation under invalid or live_unreachable.

    WAVE 6 / 3681979280 — these verbs run post-flip and MUST still refuse when
    authority is indeterminate or the
    acting store cannot be selected. Raises SystemExit(1) via print_session_error.

    WAVE 6.6 / 3682338114 + sol 114659Z: ``live_unenrolled`` is permitted only
    when ``allow_unenrolled=True`` (session launch, which bootstraps+enrolls).
    Resume/restart refuse it — writable must not invent an unindexed acting store.
    """
    root_cwd = cwd or str(pathlib.Path.cwd().resolve())
    try:
        root = root_for_cwd(root_cwd)
    except Exception:
        root = root_cwd
    status, _path = registry_v20.resolve_team_registry_for_root(root)
    if status == "invalid":
        print_session_error(
            verb,
            "invalid_flip",
            "tap doctor",
            f"{verb} refused — global-registry.json is present but unreadable or wrong schema",
        )
        raise SystemExit(1)
    if status == "live_unreachable":
        print_session_error(
            verb,
            "acting_registry_unreachable",
            "tap doctor",
            f"{verb} refused — acting team-registry unreachable under live flip marker",
        )
        raise SystemExit(1)
    if status == "live_unenrolled" and not allow_unenrolled:
        print_session_error(
            verb,
            "live_unenrolled",
            "tap session launch / tap in",
            f"{verb} refused — worktree is not enrolled under the live flip marker",
        )
        raise SystemExit(1)


def _bootstrap_if_live_unenrolled(root: str, *, dry_run: bool = False) -> None:
    """Bootstrap a primary repository, but never implicitly enroll a linked worktree.

    WAVE 6.6 / 3682338114 — mirrors ``tap_bootstrap_postflip_enroll`` for the
    launcher path (register already calls the shell helper). No-op unless
    resolve returns ``live_unenrolled``.
    """
    status, _path = registry_v20.resolve_team_registry_for_root(root)
    if status != "live_unenrolled":
        return
    probe = run_git_probe(root)
    if probe.inside and probe.git_dir != probe.common_dir:
        team = pathlib.Path(root).resolve().name
        raise LauncherError(
            f"launch would create team {team!r} for linked worktree {root}; "
            "refusing implicit enrollment. Launch from your enrolled team's root, "
            "or explicitly enroll this worktree with tap register before launching."
        )
    if dry_run:
        return
    scripts = pathlib.Path(__file__).resolve().parent.parent
    result = verbose.run(
        [
            "bash", "-c",
            'DIR="$1"; . "$DIR/lib.sh"; tap_bootstrap_postflip_enroll "$2"',
            "_", str(scripts), root,
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip() or "bootstrap enroll failed"
        raise LauncherError(
            f"tap session refused — could not bootstrap post-flip enrollment for {root}: {detail}"
        )


def cmd_completion(args) -> int:
    if args.shell != "zsh":
        raise LauncherError("only zsh completion is bundled")
    # Interpolate the canonical harness set at generation time so the
    # `tap session launch <TAB>` list cannot drift from HARNESSES (a hardcoded
    # copy in the template would rot; this substitution makes drift impossible).
    sys.stdout.write(ZSH_COMPLETION.replace("@HARNESSES@", " ".join(sorted(HARNESSES))))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="tap session")
    sub = parser.add_subparsers(dest="command", required=True)

    new = sub.add_parser("new")
    new.add_argument("harness", nargs="?")
    new.add_argument("label", nargs="?")
    new.add_argument("--preset")
    new.add_argument("--tag")
    new.add_argument("--unique")
    new.add_argument("--model")
    new.add_argument("--effort")
    new.add_argument("--env", action="append", metavar="KEY=VALUE",
                     help="harness process environment; repeatable. Same fence as preset env.")
    # Retired flags stay PARSEABLE on purpose. Removing them outright would make the
    # pre-argparse splitter treat them as harness passthrough and forward them to the child,
    # turning a helpful refusal into a confusing failure inside someone else's CLI.
    new.add_argument("--unset-env", action="append", metavar="KEY")
    new.add_argument("--teams", action="store_true", help=argparse.SUPPRESS)
    new.add_argument("--fresh", action="store_true")
    new.add_argument("--new", action="store_true", dest="new",
                     help="always start a suffixed sibling seat, never absorb or prompt")
    new.add_argument("--attach", action="store_true",
                     help="force a tmux attach even from a non-TTY caller (default: attach only when a real terminal is present)")
    new.add_argument("--dry-run", action="store_true")
    new.add_argument("--json", action="store_true")
    new.set_defaults(func=cmd_new)

    resume = sub.add_parser("resume")
    resume.add_argument("key", nargs="?")
    resume.add_argument("legacy_name", nargs="?")
    resume.add_argument("--model", help=argparse.SUPPRESS)
    resume.add_argument("--teams", action="store_true", help=argparse.SUPPRESS)
    resume.add_argument("--dry-run", action="store_true")
    resume.add_argument("--json", action="store_true")
    resume.add_argument("--all", action="store_true")
    resume.set_defaults(func=cmd_resume)

    restart = sub.add_parser("restart")
    restart.add_argument("key", nargs="?")
    restart.add_argument("--model", help=argparse.SUPPRESS)
    restart.add_argument("--teams", action="store_true", help=argparse.SUPPRESS)
    restart.add_argument("--force", action="store_true")
    restart.add_argument("--dry-run", action="store_true")
    restart.add_argument("--json", action="store_true")
    restart.set_defaults(func=cmd_restart)

    # tap-eb9h. No --force and no stuck-harness flag by design: clear already replaces the
    # process unconditionally, so a hung harness is the same command.
    clear = sub.add_parser("clear")
    clear.add_argument("seat", nargs="?")
    clear.add_argument("-m", "--message", help="instruction the fresh process starts with")
    clear.add_argument("--dry-run", action="store_true")
    clear.set_defaults(func=cmd_clear)

    relaunch = sub.add_parser("relaunch")
    relaunch.add_argument("seat", nargs="?", metavar="team/handle")
    relaunch.add_argument(
        "-m", "--message",
        help="instruction the resumed process starts with (rides the harness's resume prompt)",
    )
    # The batch form SELECTS AND RESPAWNS AN ENTIRE COHORT, so an over-wide
    # `choices` is not help-text drift — it is a process-replacing surface over
    # families nobody ruled on. The single-seat form stays generic; only the
    # fleet form is constrained. Cursor joined claude and codex after verified
    # auth; opencode was added by Ops's 2026-09-17 ruling.
    relaunch.add_argument("--harness", choices=sorted(RELAUNCH_BATCH_HARNESSES),
                          help="relaunch every relaunchable seat of this harness (claude|codex|cursor|opencode; mutually exclusive with a seat)")
    relaunch.add_argument("--team", help="narrow --harness to one enrolled team")
    relaunch.add_argument("--dry-run", action="store_true")
    relaunch.set_defaults(func=cmd_relaunch)

    completion = sub.add_parser("completion")
    completion.add_argument("shell", choices=["zsh"])
    completion.set_defaults(func=cmd_completion)

    return parser


ZSH_COMPLETION = r'''#compdef launcher he c co cs cf ct cto ctf cst cr cor csr cfr ctr ctor ctsr cx cxr ca caf cag cac car cafr cagr

_tap_session_bin() {
  if (( $+functions[launcher] )); then
    echo launcher
  else
    echo "$HOME/bin/launcher"
  fi
}

_tap_session_sessions() {
  local harness="$1"
  local -a sessions
  sessions=("${(@f)$(tap session list --names-only --include-tmux --harness "$harness" --cwd "$PWD" 2>/dev/null)}")
  _describe 'agent sessions' sessions
}

_tap_session_sessions_claude() {
  _tap_session_sessions claude
}

_tap_session_sessions_codex() {
  _tap_session_sessions codex
}

_tap_session_sessions_cursor() {
  _tap_session_sessions cursor
}

_tap_session_sessions_hermes() {
  _tap_session_sessions hermes
}

_tap_session_resume_claude() {
  _arguments \
    '1:session:_tap_session_sessions_claude'
}

_tap_session_resume_codex() {
  _arguments \
    '1:session:_tap_session_sessions_codex'
}

_tap_session_resume_cursor() {
  _arguments \
    '1:session:_tap_session_sessions_cursor'
}

_tap_session_new_claude() {
  _arguments \
    '--unique[use exact session name]:name:' \
    '1:tag:'
}

_tap_session_new_codex() {
  _arguments \
    '--unique[use exact session name]:name:' \
    '1:tag:'
}

_tap_session_new_cursor() {
  _arguments \
    '--unique[use exact session name]:name:' \
    '1:tag:'
}

_tap_session_new_hermes() {
  _arguments \
    '--unique[use exact session name]:name:' \
    '1:tag:'
}

_tap_session() {
  local -a commands
  commands=(
    'new:create a named tmux-backed agent'
    'resume:resume a named agent'
    'list:list known agent sessions'
    'completion:print shell completion'
  )
  _arguments '1:command:->cmd' '*::arg:->args'
  case "$state" in
    cmd) _describe 'command' commands ;;
    args)
      case "$words[2]" in
        new|resume) _values 'harness' @HARNESSES@ ;;
      esac
      ;;
  esac
}

# --- `tap session` completions (tap-kicy) ------------------------------------
# zsh-only. The handles helper shells out to the read-only producer, which writes
# nothing and imports only the completion leaf, so a TAB press is fast and
# side-effect-free. launch offers the harness set (interpolated below, so it
# never drifts from launcher.HARNESSES); resume/restart offer team-scoped session
# handles. `repair` is intentionally NOT completed — it is live-only and would
# suggest stopped handles it rejects (a live-only producer for a rare admin verb
# is not worth a third predicate variant). Bare-harness resume is also NOT offered
# — it is the native-picker adoption path, kept in the CLI but out of completion.
# Only the immediate operand slot completes (position-aware): later positions
# (launch's optional name, anything after the first handle) offer nothing, so a
# handle/harness is never re-offered once one has been chosen.
_tap_session_handles() {
  local -a handles
  handles=(${(f)"$(tap session complete handles 2>/dev/null)"})
  (( ${#handles} )) && _describe -t sessions 'team session handle' handles
}

_tap() {
  local curcontext="$curcontext" state line
  _arguments -C \
    '1: :->verb' \
    '2: :->sub' \
    '3: :->operand'
  case "$state" in
    verb)
      _values 'tap command' session up down
      ;;
    sub)
      case "$words[2]" in
        session) _values 'session subcommand' launch resume restart repair list ;;
        up|down) _tap_session_handles ;;
      esac
      ;;
    operand)
      # Position 3 only — the first operand after the subcommand. Positions 4+
      # have no spec, so nothing is re-offered.
      if [[ "$words[2]" == session ]]; then
        case "$words[3]" in
          launch) _values 'harness' @HARNESSES@ ;;
          resume|restart) _tap_session_handles ;;
        esac
      fi
      ;;
  esac
}

compdef _tap tap
compdef _tap_session launcher
compdef _tap_session_new_hermes he
compdef _tap_session_new_claude c co cs cf ct cto ctf cst
compdef _tap_session_resume_claude cr cor csr cfr ctr ctor ctsr
compdef _tap_session_new_codex cx
compdef _tap_session_resume_codex cxr
compdef _tap_session_new_cursor ca caf cag cac
compdef _tap_session_resume_cursor car cafr cagr
'''


def split_new_passthrough(argv: list[str]) -> tuple[list[str], list[str]]:
    return tuple(_preset_bridge.call("launch.split", argv=argv))


def _main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    json_requested = os.environ.get("TAP_JSON") == "1" or "--json" in argv
    # A structured caller gets one object and nothing else. Config notices are prose on stderr,
    # which is precisely the contamination --json promises not to produce, so the decision is
    # made once here — from the argv actually being executed, which is not always sys.argv —
    # and every notice site downstream inherits it.
    # Most of this CLI is reached as `tap session <sub>`, but `tap clear` is a
    # TOP-LEVEL verb, and a refusal is the main thing that verb says out loud
    # (pane gone, self-clear, unsupported harness). Labelling those "tap session"
    # would point the reader at a command they did not run and a help page that
    # does not document the verb — the error text is the door out of the failure,
    # so it has to name the right one.
    verb = "tap clear" if argv[:1] == ["clear"] else "tap session"
    help_action = "tap help clear" if verb == "tap clear" else "tap help session"
    try:
        # Notice initialization is a BRIDGE conversation now -- suppression and
        # the fresh command history ride the carried lifetime through the
        # native door (suppress before reset, both before dispatch/parsing).
        # A transport fault (missing bun, failed child, an unparsable packet) is
        # therefore a startup transport fault like any other and must render
        # through the handlers BELOW -- the concise command-failed line and
        # its exit status -- rather than raise a traceback out of `_main`.
        presets.suppress_notices(json_requested)
        # One command, one notice history. Without this a long-lived process — or a test
        # suite, which is one — would carry the previous command's dedup set forward and
        # swallow a legitimately identical notice from the next.
        presets.reset_notices()
        if argv and argv[0] == "_launch-failed":
            return internal_launch_failure(argv[1:])
        if argv and argv[0] == "_launch-failed-owned":
            return internal_launch_failure(argv[1:], owned=True)
        if argv and argv[0] == "_seat-up":
            return internal_seat_up(argv[1:])
        # tap-9zwt: peel pnpm-style harness passthrough off a `new` invocation before
        # argparse (see split_new_passthrough). No-op for every other subcommand.
        argv, harness_passthrough = split_new_passthrough(argv)
        parser = build_parser()
        args = parser.parse_args(argv)
        args.harness_passthrough = harness_passthrough
        return args.func(args)
    except presets.PresetError as exc:
        if json_requested:
            emit_error_json(exc.error_class, exc.action, exc.detail)
        else:
            print(f"{verb}: {exc.detail}; next: {exc.action}", file=sys.stderr)
        return 2
    except LauncherError as exc:
        if os.environ.get("TAP_JSON") == "1":
            emit_error_json("session_error", help_action, str(exc))
        else:
            print(f"{verb}: {exc}", file=sys.stderr)
        return 2
    except FileNotFoundError as exc:
        print(f"{verb}: missing command: {exc.filename}", file=sys.stderr)
        return 127
    except subprocess.CalledProcessError as exc:
        print(f"{verb}: command failed (exit {exc.returncode}): {_command_summary(exc.cmd)}", file=sys.stderr)
        return exc.returncode


def main(argv=None) -> int:
    tokens = list(sys.argv[1:] if argv is None else argv)
    if tokens[:1] == ["repair"]:
        # Direct CLI compatibility is argv transport; Bun owns all repair policy.
        native = _LAUNCHER_DIR.parents[3] / "runtime/bun/src/launcher/repair.ts"
        try:
            os.execvp("bun", ["bun", str(native), *tokens[1:]])
        except FileNotFoundError:
            print("tap session: missing command: bun", file=sys.stderr)
            return 127
    launcher_tokens = tokens[:tokens.index("--")] if "--" in tokens else tokens
    traced = bool(tokens and tokens[0] in ("new", "launch", "resume", "restart", "relaunch", "repair", "stop")
                  and not any(x in launcher_tokens for x in ("--dry-run", "--help", "-h")))
    if traced:
        lifecycle_diagnostics.begin()
        try:
            startup_trace.begin(tokens[0], os.getcwd(), tokens[1] if tokens[0] in ("resume", "restart", "relaunch", "stop", "repair") and len(tokens) > 1 and not tokens[1].startswith("-") else None, current_boot_id(), deferred=tokens[0] in ("new", "launch"))
        except Exception:
            pass
    try:
        code = _main(tokens)
    except BaseException:
        if traced:
            startup_trace.finish(1)
            lifecycle_diagnostics.finish()
        raise
    if traced:
        startup_trace.finish(code)
        lifecycle_diagnostics.finish()
    return code


if __name__ == "__main__":
    raise SystemExit(main())
