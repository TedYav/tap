"""Enforce that the tmux driver's rc6 row stays CONSERVATIVE.

An earlier version of this file asserted the opposite: that rc6 is pre-effect,
because the fresh-inject call into `tap_submit_existing_verify` passes
identity_rc=5. That premise was reasoned from the code, it was wrong, and this
check greened on it — because it asserted the premise rather than the behavior.

Two facts break it, and sol-pinnacle reproduced their composition live
(`rc=6 effects=1 guard_calls=2`) instead of arguing it:

  1. `tap_submit_existing_verify` re-runs the identity guard INSIDE its Enter
     retry loop. From the second iteration onward, a guard failure happens after
     an Enter has already been sent.
  2. The two STUCK-SENTINEL call sites pass identity_rc=6, not 5.

Compose them and rc6 returns with one Enter already delivered — so rc6 must map
to `stop-ambiguous` / `possible`. `retry-next-rung` would let a router retry an
attempt that already pressed Enter.

What this file now checks is the inverse of what it used to: that nothing has
quietly relaxed rc6 back to a retry-safe row, and that the structural situation
which forces the conservative reading still holds. If someone makes rc6 genuinely
pre-effect — one identity_rc everywhere, and the guard hoisted out of the Enter
loop — this check fails and tells them to re-derive the row deliberately rather
than letting the mapping drift under it.
"""

import re
import sys


def logical_lines(src: str) -> list[str]:
    """Join backslash-continued shell lines so a call reads as one string."""
    out, buf = [], ""
    for line in src.splitlines():
        buf += line
        if buf.rstrip().endswith("\\"):
            buf = buf.rstrip()[:-1] + " "
            continue
        out.append(buf)
        buf = ""
    if buf:
        out.append(buf)
    return out


def check_mapping_is_conservative(src: str) -> None:
    """rc6 must emit stop-ambiguous/possible. This is the row the probe forced."""
    match = re.search(
        r"tapdrv_tmux_outcome\(\)\s*\{.*?\n\}", src, re.S
    )
    if not match:
        raise AssertionError("tapdrv_tmux_outcome not found; the rc mapping moved")
    body = match.group(0)
    row = re.search(r"^\s*6\)\s*printf\s*'([^']*)'", body, re.M)
    if not row:
        raise AssertionError("no rc6 row in tapdrv_tmux_outcome")
    fields = row.group(1).split("\\x1f")
    if fields[:2] != ["stop-ambiguous", "possible"]:
        raise AssertionError(
            "rc6 maps to %s/%s, but an identity failure can follow a sent Enter "
            "(the guard re-runs inside tap_submit_existing_verify's retry loop, and "
            "the stuck-sentinel call sites pass identity_rc=6). A retry-safe row "
            "here lets a router retry an attempt that already pressed Enter."
            % (fields[0], fields[1] if len(fields) > 1 else "?")
        )


def check_premise_still_forces_it(src: str) -> None:
    """The conservative row is not arbitrary caution — these are its causes.

    Post-Enter rc6 needs BOTH to compose, so losing EITHER one already makes rc6
    pre-effect again and the mapping should be re-derived by a person rather than
    left as a stale caution. Failing here is that prompt.
    """
    # A GUARD AT THE TOP OF THE LOOP CARRIES THE PREMISE, VIA THE LOOP-BACK.
    #
    # This was challenged as accepting a pre-Enter guard, and the challenge does
    # not hold on the actual control flow. The loop is:
    #
    #     for _ in 1 2 3 4 5; do
    #       tap_submit_identity_guard ... || return "$identity_rc"   # <- here
    #       tmux send-keys ... Enter
    #       ... second-Enter block, its own guard, its own return ...
    #     done
    #
    # On iteration 1 the top guard is pre-Enter. On iterations 2 through 5 it runs
    # AFTER the previous iteration's Enter, so a failure there returns
    # identity_rc with a keystroke already delivered. The loop-back is the
    # mechanism, not the textual order.
    #
    # A structural check that demanded a guard TEXTUALLY after a send-keys would
    # therefore be a false positive on correct code — I wrote that version, ran
    # it against the real tree, and it red. It is recorded here because the
    # tempting fix is wrong in a way that looks more rigorous than the right one.
    #
    # So the test is: the loop body contains BOTH a guard that returns
    # identity_rc AND a send-keys Enter. Order within the body is irrelevant
    # because it is a loop; what matters is that both are in the same body, so
    # some iteration reaches the guard with an effect behind it. Removing ONE of
    # the two guards does not lapse the premise while the other remains in the
    # loop — which is the correct answer, and why this accepts that mutant.
    guard_in_loop = False
    inside = False
    in_loop = False
    loop_has_enter = False
    loop_has_guard = False
    for line in logical_lines(src):
        if re.match(r"\s*tap_submit_existing_verify\(\)\s*\{", line):
            inside = True
            continue
        if inside:
            if re.match(r"^\}", line):
                break
            if "for _ in" in line:
                in_loop = True
                continue
            if in_loop:
                if "send-keys" in line and "Enter" in line:
                    loop_has_enter = True
                if "tap_submit_identity_guard" in line and "identity_rc" in line:
                    loop_has_guard = True
    guard_in_loop = loop_has_enter and loop_has_guard

    # POSITIONAL, not "a 6 somewhere on the line". The first version of this
    # check grepped for any whitespace-delimited `6` in the call's argument text,
    # so a decoy — a 6 in ANY other slot, or in a nearby word — kept it green
    # after both identity arguments had been changed to 5 (sol-pinnacle, #xxx).
    # That is the same defect this file was written to fix, in the leg that was
    # supposed to be the careful one: a check that matches the SHAPE of the
    # evidence instead of reading the evidence.
    #
    # identity_rc is argv[9] of tap_submit_existing_verify (1-indexed), which the
    # helper's own documented signature pins; `signature_ok` above fails first if
    # that signature moves, so this index cannot silently drift.
    passes_six = []
    for line in logical_lines(src):
        if "tap_submit_existing_verify " not in line:
            continue
        call = line[line.index("tap_submit_existing_verify ") :]
        call = re.split(r"\|\||&&|;", call)[0]
        argv = call.split()[1:]
        if len(argv) >= 9 and argv[8] == "6":
            passes_six.append(line)

    # EITHER cause vanishing is enough, and an earlier version of this check said
    # AND (sol-pinnacle, #xxx gate). Post-Enter rc6 needs BOTH conditions to
    # compose: the guard must run inside the Enter loop, AND a call site must ask
    # for 6 rather than 5. So losing either one alone already makes rc6
    # pre-effect again, and an `and` here would keep asserting a stale caution
    # while one of its two legs was gone. Proven by changing both stuck-sentinel
    # arguments to 5: the guard stayed in the loop and the checker still exited 0.
    #
    # This is the same defect as the file's ORIGINAL version, one layer in: a
    # check reasoning about the premise instead of testing it.
    missing = []
    if guard_in_loop is not True:
        missing.append(
            "the retry loop no longer contains both an identity guard returning "
            "identity_rc and a send-keys Enter, so no iteration can reach the guard "
            "with an effect behind it"
        )
    if not passes_six:
        missing.append("no call site passes identity_rc=6")
    if missing:
        raise AssertionError(
            "rc6's post-effect risk needs BOTH causes to compose, and "
            + " and ".join(missing)
            + ". rc6 may now be genuinely pre-effect — re-derive the mapping row "
            "deliberately instead of leaving this caution in place."
        )


def main(path: str) -> None:
    src = open(path).read()
    check_mapping_is_conservative(src)
    check_premise_still_forces_it(src)


if __name__ == "__main__":
    main(sys.argv[1])
