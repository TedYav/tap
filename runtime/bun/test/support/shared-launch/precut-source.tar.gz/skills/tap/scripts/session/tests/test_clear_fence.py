"""Clearing fence: content is the signal, flock serializes writers (tap-36kb)."""
from __future__ import annotations

import json
import os
import pathlib
import sys
import tempfile
import time
import unittest

_SCRIPTS = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_SCRIPTS))
import clear_fence  # noqa: E402


# The seven arms that drove `clear_fence.inspect` and `notice_expired_once`
# directly moved to `runtime/bun/test/clear-fence.test.ts` with the body they
# tested. They are not reproduced as Bash-door tests: the door only sees a
# four-line stdout, so a door test could not tell "dead holder, FRESH stamp" —
# the falsifying arm that separates content-as-signal from lock-as-signal —
# from any other live answer. The Bun replay checks every one of them against a
# frozen capture of this file's own output, taken before the delete.


class ClearFenceAcquireTest(unittest.TestCase):
    def test_second_acquire_fails_immediately(self):
        with tempfile.TemporaryDirectory() as bus:
            held = clear_fence.try_acquire(bus, "opus", "n1", os.getpid(), "claude", 45.0)
            self.assertIsNotNone(held)
            try:
                second = clear_fence.try_acquire(bus, "opus", "n2", os.getpid(), "claude", 45.0)
                self.assertIsNone(
                    second,
                    "LOCK_NB must fail immediately while the first clearer holds the flock",
                )
            finally:
                held.release()
            third = clear_fence.try_acquire(bus, "opus", "n3", os.getpid(), "claude", 45.0)
            self.assertIsNotNone(third, "after release a new clear must acquire")
            third.release()

    def test_release_truncates_in_place(self):
        # Asserts the MECHANISM rather than a reader's verdict: the marker must
        # still exist (same inode, so a second clearer cannot acquire a fresh
        # one) and must be empty. `inspect` used to stand in for this, and read
        # "absent" for a file that was missing, torn OR truncated.
        with tempfile.TemporaryDirectory() as bus:
            held = clear_fence.try_acquire(bus, "opus", "n1", os.getpid(), "claude", 45.0)
            path = clear_fence.fence_path(bus, "opus")
            self.assertEqual(json.loads(path.read_text())["nonce"], "n1")
            inode = path.stat().st_ino
            held.release()
            self.assertTrue(path.is_file(), "release must NOT unlink the marker")
            self.assertEqual(path.stat().st_ino, inode, "the inode IS the lock")
            self.assertEqual(path.read_text().strip(), "", "release truncates in place")


if __name__ == "__main__":
    unittest.main()
