#!/usr/bin/env python3
"""Red-fixture boundary corpus for benign_vocab_lint.py (sol r4/r5, PR #xxx).

A completeness lint that cannot be SHOWN to FAIL on known-bad inputs is a
placebo detector. This corpus pins, as executable inside/outside pairs:

  - term morphology: every TERMS family has a positive fixture, and the
    look-alikes it must NOT match (seat_corpse / undead / deadline / injective);
  - Python extraction (3.12+ floor): f-string literal text is seen via
    FSTRING_MIDDLE with true source columns, while f-string EXPRESSION and
    format-spec identifiers, and ordinary code identifiers, are excluded;
  - Shell whole-line RAW scan: there is no extraction of any kind (not even
    interpolation masking, which r6 showed was itself a bypass — a
    `$(printf 'prose')` or `${x:-default prose}` hid text), so shell-valid forms
    that defeated the old hand-rolled lexer are caught by construction:
    hyphenated heredoc delimiters, multiline quotes, `PYTHON=python3 cat`
    heredocs, and command-substitution / parameter-default OUTPUT. A genuine
    shell-CODE survivor is classified narrowly, never re-masked (r6/r7 #1);
  - hit-scoped exemption: a legitimate token must NOT mask an adjacent forbidden
    hit; the grep-stable receipt exemption is scoped to its launcher source (r5
    #4) and does not exempt the phrase in another file;
  - end-to-end FAIL on an unclassified hit, a stale allowlist entry, and a
    mixed-line masking attempt — and PASS on a clean file.

Run: python3 benign_vocab_lint_corpus.py   (exit 0 = all pass, 1 = any failure)
"""

import contextlib
import importlib.util
import io
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("bvl", os.path.join(HERE, "benign_vocab_lint.py"))
bvl = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(bvl)

FAILURES = []


def check(name, cond):
    print(("  ok   " if cond else "  FAIL ") + name)
    if not cond:
        FAILURES.append(name)


def run_on(files, allowlist=None):
    """Write `files` (rel->content) into a temp ROOT, run the whole lint, return
    its exit code (0 pass / 1 fail). Restores module globals."""
    with tempfile.TemporaryDirectory() as d:
        rels = []
        for rel, content in files.items():
            full = os.path.join(d, rel)
            os.makedirs(os.path.dirname(full) or d, exist_ok=True)
            with open(full, "w") as fh:
                fh.write(content)
            rels.append(rel)
        saved = (bvl.ROOT, bvl.FILES, bvl.ALLOWLIST)
        bvl.ROOT, bvl.FILES = d, rels
        if allowlist is not None:
            bvl.ALLOWLIST = allowlist
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                return bvl.main()
        finally:
            bvl.ROOT, bvl.FILES, bvl.ALLOWLIST = saved


print("# term morphology — a positive fixture for every family")
for s in [
    "a dead pane", "the corpse", "corpses pile up", "steal the id", "it stole",
    "the mint wedges", "wedging the launch", "a wedged pane", "a malformed value",
    "reclaimed the name", "an injection", "injected text", "kill the seat",
    "destructive op", "destroyed it", "an attack case", "adversarial input",
    "%beefcake", "a zombie session", "the victim", "a dead-end path",
    "the process dies", "it died",
]:
    check(f"match {s!r}", bvl.TERMS.search(s) is not None)

print("# term morphology — look-alikes that must NOT match")
for s in [
    "seat_corpse module", "the undead census", "past the deadline",
    "not injective", "a deadlock avoided", "the resurrect verb", "is_seat_dead",
]:
    check(f"exclude {s!r}", bvl.TERMS.search(s) is None)

print("# python extraction — prose seen, identifiers & f-string exprs excluded")
py = (
    'x = f"a dead seat row ({addr})"\n'
    'def g():\n'
    '    """reclaim the corpse."""\n'
    '    is_seat_dead = seat_corpse_helper()\n'
    '    return is_seat_dead\n'
)
_txt = " ".join(t for _, _, t, _ in bvl._py_prose_spans(py))
check("f-string literal prose seen", "dead seat row" in _txt)
check("docstring prose seen", "reclaim the corpse" in _txt)
check("code identifier is_seat_dead not scanned as prose", "is_seat_dead" not in _txt)
# f-strings via FSTRING_MIDDLE (Python 3.12+, the test floor) — end-to-end, so
# these exercise the REAL tokenizer path with true source columns (r7 #1/#4: the
# pre-3.12 STRING-token path is retired; the 3.12 floor makes f-strings one
# regime, so literal content and columns are correct by construction).
check("end2end: f-string literal flavor FAILS", run_on({"a.py": 'r = f"a dead seat {x}"\n'}, allowlist=[]) == 1)
check("end2end: f-string EXPRESSION identifier excluded PASSES", run_on({"a.py": 'r = f"{attack_fn()}"\n'}, allowlist=[]) == 0)
check("end2end: doubled-brace literal seen FAILS", run_on({"a.py": 'r = f"{{dead}} {x}"\n'}, allowlist=[]) == 1)
check("end2end: format-spec expr identifier excluded PASSES", run_on({"a.py": 'r = f"{attack:{width}}"\n'}, allowlist=[]) == 0)
check("end2end: bare f-string literal flavor FAILS", run_on({"a.py": 'r = f"a dead seat"\n'}, allowlist=[]) == 1)
check("end2end: identifier-only file PASSES", run_on({"a.py": "is_seat_dead = seat_corpse_helper()\n"}, allowlist=[]) == 0)

print("# shell whole-line scan — the forms that defeated the old lexer (r5 #1/#2/#3)")
check("r5#1 hyphenated-delimiter heredoc body FAILS",
      run_on({"a.sh": "cat <<'END-TXT'\nattack the seat\nEND-TXT\n"}, allowlist=[]) == 1)
check("r5#2 multiline single-quoted prose FAILS",
      run_on({"a.sh": "msg='first line\nattack the seat'\n"}, allowlist=[]) == 1)
check("r5#2 multiline double-quoted prose FAILS",
      run_on({"a.sh": 'msg="first line\nreclaim the seat"\n'}, allowlist=[]) == 1)
check("r5#3 'PYTHON=python3 cat' heredoc body FAILS",
      run_on({"a.sh": "PYTHON=python3 cat <<'TXT'\nattack the seat\nTXT\n"}, allowlist=[]) == 1)
check("embedded-Python heredoc docstring FAILS",
      run_on({"a.sh": "python3 - <<'PY'\ndef f():\n    \"\"\"attack the seat.\"\"\"\nPY\n"}, allowlist=[]) == 1)

print("# raw shell scan — interpolation SPANS are scanned too (r6 #1: no masking bypass)")
check("r6#1 command-substitution OUTPUT prose FAILS",
      run_on({"a.sh": "msg=\"$(printf '%s' 'attack the seat')\"\n"}, allowlist=[]) == 1)
check("r6#1 parameter-default prose FAILS",
      run_on({"a.sh": "msg=\"${status:-the dead seat}\"\n"}, allowlist=[]) == 1)
check("bare prose word still caught", run_on({"a.sh": "# a dead pane\n"}, allowlist=[]) == 1)
# A genuine shell-CODE survivor is classified NARROWLY, not masked (sol's guidance)
check("unclassified code-in-interpolation FAILS (no blanket mask)",
      run_on({"a.sh": "n=${seat#dead}\n"}, allowlist=[]) == 1)
check("narrow allowlist entry classifies that concrete span PASSES",
      run_on({"a.sh": "n=${seat#dead}\n"}, allowlist=[(".sh", r"seat#dead", "narrow code exemption")]) == 0)
# Word boundaries still exclude identifier substrings even in the raw scan
check("word boundary excludes 'deadline' in raw code", run_on({"a.sh": "x=$deadline_ok\n"}, allowlist=[]) == 0)

print("# hit-scoped exemption + receipt path-scoping (r5 #4)")
check("mixed allowed/forbidden line FAILS",
      run_on({"a.py": 'STATUS = "dead"  # attack the seat\n'}, allowlist=[(".py", r'"dead"', "value")]) == 1)
check("quoted-value-only line PASSES",
      run_on({"a.py": 'STATUS = "dead"\n'}, allowlist=[(".py", r'"dead"', "value")]) == 0)
RECEIPT = [("session/launcher.py", r'f"reclaimed dead seat row', "receipt")]
check("receipt exemption classifies the launcher source",
      run_on({"session/launcher.py": 'r = f"reclaimed dead seat row {t}"\n'}, allowlist=RECEIPT) == 0)
check("receipt exemption does NOT reach another file",
      run_on({"session/seat_corpse.py": "# reclaimed dead seat row\n"}, allowlist=RECEIPT) == 1)
print("# BOUNDARY — contiguous raw source spelling (threat model, r8 #5/#6):")
print("#   escapes/reconstruction are OUT OF SCOPE ON PURPOSE — a GPT reviewer and its")
print("#   classifier read the RAW SPELLING (atta\\x63k), never the runtime value, so")
print("#   obfuscated source is already benign on the only surface that matters.")
check("py \\x escape is out of scope (reviewer reads the escape, not the word)",
      run_on({"a.py": 'msg = "atta\\x63k the seat"\n'}, allowlist=[]) == 0)
check("py backslash-newline split is out of scope (no contiguous source word)",
      run_on({"a.py": 'msg = "atta\\\nck the seat"\n'}, allowlist=[]) == 0)
check("sh adjacent-string concat is out of scope (no contiguous source word)",
      run_on({"a.sh": 'msg="att""ack the seat"\n'}, allowlist=[]) == 0)
check("sh ANSI-C $'\\x..' escape is out of scope (reviewer reads the escape)",
      run_on({"a.sh": "msg=$'atta\\x63k the seat'\n"}, allowlist=[]) == 0)
check("CONTRAST: heredoc prose IS read as the word -> IN scope, FAILS",
      run_on({"a.sh": "cat <<'T'\nattack the seat\nT\n"}, allowlist=[]) == 1)

print("# two-way anti-masking — unclassified fails, stale fails, clean passes")
check("unclassified hit FAILS", run_on({"a.py": "# a dead pane\n"}, allowlist=[]) == 1)
check("stale allowlist entry FAILS",
      run_on({"a.py": "# a gone pane\n"}, allowlist=[(".py", r"never-matches", "x")]) == 1)
check("fully-neutralized file PASSES", run_on({"a.py": "# a gone pane\n"}, allowlist=[]) == 0)

print()
if FAILURES:
    print(f"CORPUS FAIL: {len(FAILURES)} case(s) failed:")
    for f in FAILURES:
        print("  - " + f)
    sys.exit(1)
print("CORPUS PASS: every boundary fixture held.")
sys.exit(0)
