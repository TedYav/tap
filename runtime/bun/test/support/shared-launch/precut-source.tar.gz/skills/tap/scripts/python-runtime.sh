#!/usr/bin/env bash
# Shared by the entry point and direct Bash verbs; the shim also covers Bun children.
_tap_python_shim="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/python-bin"
# The shim is shipped with the bootstrap; its absence is a broken checkout.
if [ ! -x "$_tap_python_shim/python3" ]; then
  printf 'tap: missing Python runtime shim %s; restore the TAP checkout\n' "$_tap_python_shim/python3" >&2
  exit 127
fi
_tap_python_file="${TAP_INDEX_HOME:-$HOME/.tap}/python3"
_tap_python_pin=""
if [ -f "$_tap_python_file" ]; then IFS= read -r _tap_python_pin < "$_tap_python_file" || true; fi
_tap_python_selected="${TAP_PYTHON3:-$_tap_python_pin}"
case "$_tap_python_selected" in
  /*) [ -x "$_tap_python_selected" ] && [ ! -d "$_tap_python_selected" ] || _tap_python_selected="" ;;
  *) _tap_python_selected="" ;;
esac
if [ -z "$_tap_python_selected" ] && [ -n "$_tap_python_pin" ]; then
  case "$_tap_python_pin" in /*) [ ! -x "$_tap_python_pin" ] || _tap_python_selected="$_tap_python_pin" ;; esac
fi
# Remove our own shim before PATH fallback, so a stale pin cannot recurse.
_tap_python_path=""
_tap_python_sep=""
_tap_python_rest="${PATH:-}:"
while [ -n "$_tap_python_rest" ]; do
  _tap_python_part="${_tap_python_rest%%:*}"; _tap_python_rest="${_tap_python_rest#*:}"
  if [ "$_tap_python_part" != "$_tap_python_shim" ]; then
    _tap_python_path="$_tap_python_path$_tap_python_sep$_tap_python_part"
    _tap_python_sep=":"
  fi
done
if [ -z "$_tap_python_selected" ]; then
  _tap_python_selected="$(PATH="$_tap_python_path" command -v python3 2>/dev/null || true)"
fi
case "$_tap_python_selected" in
  /*) ;;
  */*) _tap_python_selected="$(cd "$(dirname "$_tap_python_selected")" && pwd)/${_tap_python_selected##*/}" ;;
  *) _tap_python_selected="" ;;
esac
if [ -n "$_tap_python_selected" ]; then
  # An uninstalled checkout has no certified identity to diverge from.
  if [ -f "$_tap_python_file" ] && { [ ! -x "$_tap_python_pin" ] || [ -d "$_tap_python_pin" ]; } && [ "${_TAP_PYTHON_REPORTED:-}" != "$_tap_python_selected|$_tap_python_file" ]; then
    printf 'tap: using python3 %s (installed pin unavailable)\n' "$_tap_python_selected" >&2
    export _TAP_PYTHON_REPORTED="$_tap_python_selected|$_tap_python_file"
  fi
  export _TAP_PYTHON_REPORTED="$_tap_python_selected|$_tap_python_file"
  export TAP_PYTHON3="$_tap_python_selected"
  export PATH="$_tap_python_shim:$_tap_python_path"
else
  export PATH="$_tap_python_path"
  unset TAP_PYTHON3
fi
unset _tap_python_shim _tap_python_file _tap_python_pin _tap_python_selected _tap_python_path _tap_python_rest _tap_python_part _tap_python_sep
