#!/usr/bin/env bash
# tap-o4ae: fixture env must stay in this process. Refuse `source` so an
# interactive shell cannot inherit top-level exports.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# pane-submit-lock-physics.test.sh — tap-9ivr lane B, PHYSICS tier (regress).
#
# REGRESS NEVER BLOCKS A MERGE. This pin is DOCUMENTED, NOT ENFORCED, and that is
# a real limitation rather than a formality: the defect below cannot be caught by
# the gate at all, because the smoke suite's tmux is mocked and returns
# instantly, so the interleaving window never exists and a race fixture there is
# green no matter what the code does. The gate's share of this is
# smoke/pane-submit-lock.test.sh, which pins the STRUCTURE deterministically.
# Run this one by hand — `bash scripts/regress-all.sh` — when touching the
# submit path.
#
# THE DEFECT, observed on a real pane before the lock existed: two senders
# submitting concurrently to ONE pane produce a FUSED LINE carrying both
# sentinels, and BOTH senders exit 0.
#
#   probe-AAA rc=0 / probe-BBB rc=0
#   harness received: [[TAP … id=probe-AAA …]][[TAP … id=probe-BBB …]]
#
# The band-clear read-back cannot see it: the id DID leave the band — glued to
# someone else's — so one Enter submitted both and the band was honestly empty.
# The recipient then sees one turn carrying two sentinels, and whichever it acts
# on, the other's canonical sits on the bus with no push wake.
#
# The instrument is a real tmux pane running a FAKE harness band (a read loop
# with a ❯ prompt that logs each submitted line). Real tmux, real send-keys, real
# concurrency — without injecting into any agent's pane.
set -uo pipefail

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
REAL_TMUX=""
SOCK=""
cleanup() {
  if [ -n "$REAL_TMUX" ] && [ -n "$SOCK" ]; then
    "$REAL_TMUX" -L "$SOCK" kill-server 2>/dev/null || true
  fi
  wait 2>/dev/null || true
  [ ! -d "$WORK" ] \
    || find "$WORK" -mindepth 1 -maxdepth 1 ! -path "$WORK/locks" -exec rm -rf {} +
}
# Arm cleanup as soon as WORK exists so early exits do not leak fixture state.
# The lock directory is deliberately left for OS cleanup. (tap-724k4, PR #xxx)
trap cleanup EXIT
SESS="tapsublock$$"
LOG="$WORK/submitted.log"
# tap-wzx7t: the PATH wrapper supplies -L so bare tmux calls from sourced lib.sh
# stay on this fixture's private server. Scrub ambient selectors so they cannot
# override that pin. Teardown uses REAL_TMUX -L directly because the destructive
# call must not depend on PATH.
#
# lib.sh keys pane-submit locks by server-scoped pane id. Keep TAP_LOCK_DIR under
# WORK so fixture pane ids cannot contend with identically numbered live panes.
export TAP_LOCK_DIR="$WORK/locks"
mkdir -p "$TAP_LOCK_DIR"

REAL_TMUX="$(command -v tmux)" || { echo "pane-submit-lock-physics: skip (no tmux)"; exit 0; }
unset TMUX TMUX_PANE
SOCK="tapsublock$$"
BIN="$WORK/bin"
mkdir -p "$BIN"
printf '#!/usr/bin/env bash\nexec %s -L %s "$@"\n' "$(printf '%q' "$REAL_TMUX")" "$(printf '%q' "$SOCK")" > "$BIN/tmux"
chmod +x "$BIN/tmux"
export PATH="$BIN:$PATH"
TMUX_PIN=("$REAL_TMUX" -L "$SOCK")
fail() { echo "pane-submit-lock-physics: $*" >&2; exit 1; }


: > "$LOG"
cat > "$WORK/band.sh" <<BAND
#!/usr/bin/env bash
while IFS= read -r -p '❯ ' line; do
  printf '%s\n' "\$line" >> "$LOG"
done
BAND
chmod +x "$WORK/band.sh"

"${TMUX_PIN[@]}" new-session -d -s "$SESS" -x 200 -y 50 "bash $WORK/band.sh" 2>/dev/null \
  || { echo "pane-submit-lock-physics: skip (cannot start tmux session)"; exit 0; }
sleep 1
PANE="$("${TMUX_PIN[@]}" list-panes -t "$SESS" -F '#{pane_id}' 2>/dev/null | head -1)"
[ -n "$PANE" ] || { echo "pane-submit-lock-physics: skip (no pane)"; exit 0; }

# shellcheck source=skills/tap/scripts/lib.sh
. "$ROOT/skills/tap/scripts/lib.sh"

send_one() { # <id>
  tap_submit_verify "$PANE" "codex" "[[TAP v=0.20 id=$1 from=probe to=band]]" "$1" \
    band 0 id "" "" "$PANE" >/dev/null 2>"$WORK/$1.err"
}

send_one probe-AAA &
send_one probe-BBB &
wait
sleep 1

# `grep -c` PRINTS 0 and EXITS 1 on no match, so `|| echo 0` appends a SECOND
# zero and the variable becomes "0\n0" — which compares unequal to 0 and reports
# a fused line that never happened. A false RED is a broken instrument too.
# `|| true` keeps grep's own count as the only output.
got="$(grep -c 'probe-' "$LOG" 2>/dev/null || true)"
fused="$(grep -cE 'probe-AAA.*probe-BBB|probe-BBB.*probe-AAA' "$LOG" 2>/dev/null || true)"
got="${got:-0}"; fused="${fused:-0}"

echo "--- lines the harness received:"; cat -n "$LOG"

[ "$fused" = 0 ] \
  || fail "FUSED LINE: two sentinels arrived in one submitted turn — the lock did not serialize. $(cat "$LOG")"
[ "$got" = 2 ] \
  || fail "expected 2 separate submitted lines, got $got — each sender's sentinel must arrive whole and alone"
grep -q 'probe-AAA' "$LOG" || fail "probe-AAA never arrived"
grep -q 'probe-BBB' "$LOG" || fail "probe-BBB never arrived"

echo "pane-submit-lock-physics: ok"
