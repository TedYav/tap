#!/usr/bin/env bash
# tap-o4ae: fixture env (TMUX=/fake/socket, …) must stay in this process.
# Refuse `source` so an interactive shell cannot inherit top-level exports.
# Must run BEFORE any `set -o` so a refusal does not mutate caller options.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# authorizer-single-observation.test.sh — tap-6lai.
#
# Two AUTHORIZERS read the server generation and a pane identity as SEPARATE
# observations, and both inherit the same fall-through when the generation is
# unobservable: the check that is supposed to reject a prior-generation row
# simply does not run, and the row is then judged on pane agreement alone. A
# recycled pane id makes that agreement a coincidence rather than an identity.
#
# The generation is forced unobservable here with a set-but-empty
# TAP_SERVER_EPOCH, which is not a contrived lever: tap_server_epoch_from_raw
# checks that pin FIRST and returns failure on an empty value even when the
# tmux record was perfect, so "identity present, generation empty" is a state
# the design GUARANTEES for every force-unknown caller rather than an edge case.
#
# WHAT EACH CASE PROVES
#   A  tap_bound_pane_identity_state — the delivery gate every `tap send` rides
#      through tap_submit_identity_guard. Its header states "Every other result
#      is fail-closed"; this arm does not, so a prior-generation row can reach
#      'match' and authorize an injection into whatever pane now holds that id.
#   B  tap_resolve_self_handle — the ONE lookup whoami/send/reply/done/unregister
#      share, so it decides `from=` on the bus. With no row skipped, a stale row
#      whose id coincides with the caller's wins on sorted() order and is
#      returned as SELF: a forged author, invisible to every downstream reader.
#      Case B is the only artifact that will ever demonstrate this path existed.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
LIB="$ROOT/skills/tap/scripts/lib.sh"
WORK="$(mktemp -d)"; FAKE_BIN="$(mktemp -d)"
trap 'rm -rf "$WORK" "$FAKE_BIN"' EXIT
export PATH="$FAKE_BIN:$PATH" TMUX="/fake/socket"

# Fake tmux: the seat's pane address and its id both resolve to %9. The
# generation field is answered too, so the ONLY thing making the generation
# unknown in these cases is the explicit pin — never a gap in the fixture.
cat > "$FAKE_BIN/tmux" <<'TMUX'
#!/usr/bin/env bash
set -euo pipefail
cmd="${1:-}"; shift || true
[ "$cmd" = "display-message" ] || exit 0
target=""; fmt=""
while [ "$#" -gt 0 ]; do
  case "$1" in -p) shift ;; -t) target="$2"; shift 2 ;; *) fmt="$1"; shift ;; esac
done
if [ -z "$target" ]; then
  case "$fmt" in *pid*start_time*) printf '%s\n' "${FAKE_EPOCH_RAW-4242:99}" ;; *) printf '\n' ;; esac
  exit 0
fi
case "$target" in
  "%9"|"T/seat:0.0") ;;
  *) printf '\n'; exit 0 ;;
esac
out="$fmt"
out="${out//'#{pane_id}'/${FAKE_PANE_ID-%9}}"
out="${out//'#{session_name}'/T/seat}"
out="${out//'#{pid}:#{start_time}'/${FAKE_EPOCH_RAW-4242:99}}"
printf '%s\n' "$out"
TMUX
chmod +x "$FAKE_BIN/tmux"

STALE='srv:1:1'
mk_registry() { # $1=path, $2=json agents body
  mkdir -p "$(dirname "$1")"
  printf '{"team":{"name":"T","worktree_root":"/tmp/T"},"agents":%s}\n' "$2" > "$1"
}

fails=0

# ── A. delivery gate: prior-generation row must not reach 'match' ────────────
REG_A="$WORK/a/registry.json"
mk_registry "$REG_A" '{"seat":{"status":"active","delivery":"pane","pane":"T/seat:0.0","pane_id":"%9","server_epoch":"'"$STALE"'"}}'
state="$(TAP_SERVER_EPOCH="" bash -c '. "$1" >/dev/null 2>&1; tap_bound_pane_identity_state "$2" seat "T/seat:0.0" "%9"' _ "$LIB" "$REG_A")"
if [ "$state" = "match" ]; then
  echo "authorizer-single-observation: FAIL [A] delivery gate returned 'match' for a row stamped under a PRIOR generation while the current one was unobservable — the staleness check did not run and pane agreement alone authorized the injection" >&2
  fails=$((fails + 1))
else
  echo "authorizer-single-observation: ok [A] delivery gate refuses an unverifiable generation (got '$state')"
fi

# ── B. self-identity: a stale row must never be returned as SELF ─────────────
# Both rows carry the caller's live id. 'aaa' is stamped under a retired
# generation and 'zzz' under a current one; sorted() reaches 'aaa' first, so a
# skip that does not fire is the whole distance between the two.
REG_B="$WORK/b/registry.json"
mk_registry "$REG_B" '{"aaa":{"status":"active","delivery":"pane","pane":"T/seat:0.0","pane_id":"%9","server_epoch":"'"$STALE"'"},"zzz":{"status":"active","delivery":"pane","pane":"T/seat:0.0","pane_id":"%9","server_epoch":"srv:4242:99"}}'
who="$(TAP_SERVER_EPOCH="" bash -c '. "$1" >/dev/null 2>&1; TAP_REGISTRY="$2" tap_resolve_self_handle "T/seat:0.0"' _ "$LIB" "$REG_B" || true)"
if [ "$who" = "aaa" ]; then
  echo "authorizer-single-observation: FAIL [B] self-identity resolved to 'aaa', a row stamped under a RETIRED generation, because no row was skipped when the current generation was unobservable — every send from this pane would carry a forged from=" >&2
  fails=$((fails + 1))
else
  echo "authorizer-single-observation: ok [B] self-identity never resolves to an unverifiable-generation row (got '${who:-<refused>}')"
fi

# ── C. GREEN GUARD: a healthy generation must still resolve normally ─────────
# Pins the fix to the dangerous arm only — if this ever goes red, the change
# stopped being fail-closed and started being broken.
who_ok="$(bash -c '. "$1" >/dev/null 2>&1; TAP_REGISTRY="$2" tap_resolve_self_handle "T/seat:0.0"' _ "$LIB" "$REG_B" || true)"
if [ "$who_ok" = "zzz" ]; then
  echo "authorizer-single-observation: ok [C] an observable generation still resolves the current-generation row"
else
  echo "authorizer-single-observation: FAIL [C] observable generation should resolve 'zzz', got '${who_ok:-<refused>}'" >&2
  fails=$((fails + 1))
fi

# ── D. CARVE-OUT GUARD: unstamped rows resolve when the generation IS known ──
# This lane refuses everything inside the unknown-generation window, stamped and
# unstamped alike — skipping only STAMPED rows was tried and is WRONG, because
# with the generation unknown you cannot tell a current stamp from a stale one,
# so skipping them drops the CORRECT row and hands the match to any unstamped
# row colliding on the pane id, making that forge RELIABLE.
#
# What must NOT change is normal operation: whether an unstamped row may confer
# identity at all is tap-zk1w's decision, not this lane's. So the invariant
# worth guarding is that an OBSERVABLE generation still resolves an unstamped
# row exactly as today. A future simplifier who tightens this would change
# un-migrated fleet behavior, and this case is what stops them.
REG_D="$WORK/d/registry.json"
mk_registry "$REG_D" '{"legacy":{"status":"active","delivery":"pane","pane":"T/seat:0.0","pane_id":"%9"}}'
who_legacy="$(bash -c '. "$1" >/dev/null 2>&1; TAP_REGISTRY="$2" tap_resolve_self_handle "T/seat:0.0"' _ "$LIB" "$REG_D" || true)"
if [ "$who_legacy" = "legacy" ]; then
  echo "authorizer-single-observation: ok [D] an unstamped row still resolves when the generation is observable (tap-zk1w carve-out intact)"
else
  echo "authorizer-single-observation: FAIL [D] unstamped row should still resolve under an observable generation — got '${who_legacy:-<refused>}'; this lane has started deciding the unstamped-row policy, which belongs to tap-zk1w" >&2
  fails=$((fails + 1))
fi

# ── E. the unknown-generation window refuses EVERYTHING, with the right class ─
# B proves a stamped row cannot forge; this proves an unstamped one cannot
# either, and that the refusal names a condition an operator can act on rather
# than the misleading 'not registered'.
REG_E="$WORK/e/registry.json"
mk_registry "$REG_E" '{"legacy":{"status":"active","delivery":"pane","pane":"T/seat:0.0","pane_id":"%9"}}'
refusal="$(TAP_SERVER_EPOCH="" bash -c '. "$1" >/dev/null 2>&1; TAP_REGISTRY="$2" tap_resolve_self_handle "T/seat:0.0" >/dev/null 2>&1; printf "%s" "${TAP_SELF_REFUSAL:-}"' _ "$LIB" "$REG_E")"
if [ "$refusal" = "generation_unverifiable" ]; then
  echo "authorizer-single-observation: ok [E] unknown generation refuses every row and names the condition"
else
  echo "authorizer-single-observation: FAIL [E] expected refusal class generation_unverifiable, got '${refusal:-<none>}' — an operator told 'not registered' would re-register, which silently UN-MIGRATES the seat" >&2
  fails=$((fails + 1))
fi

# ── F. output-variable form preserves refusal state in the caller process ────
# Command substitution erases TAP_SELF_REFUSAL with its subshell. Stateful
# consumers need both the optional handle and the refusal class in one process.
into_refusal="$(TAP_SERVER_EPOCH="" bash -c '
  . "$1" >/dev/null 2>&1
  TAP_REGISTRY="$2"
  got=""; rc=0
  tap_resolve_self_handle_into got "T/seat:0.0" || rc=$?
  printf "%s\t%s\t%s" "$rc" "${TAP_SELF_REFUSAL:-}" "$got"
' _ "$LIB" "$REG_E")"
if [ "$into_refusal" = $'2\tgeneration_unverifiable\t' ]; then
  echo "authorizer-single-observation: ok [F] output-variable resolve preserves refusal class"
else
  echo "authorizer-single-observation: FAIL [F] output-variable resolve lost refusal state (got '$into_refusal')" >&2
  fails=$((fails + 1))
fi

into_ok="$(bash -c '
  . "$1" >/dev/null 2>&1
  TAP_REGISTRY="$2"
  got=""; tap_resolve_self_handle_into got "T/seat:0.0"
  printf "%s" "$got"
' _ "$LIB" "$REG_B")"
if [ "$into_ok" = zzz ]; then
  echo "authorizer-single-observation: ok [G] output-variable resolve returns the verified handle"
else
  echo "authorizer-single-observation: FAIL [G] output-variable resolve returned '${into_ok:-<empty>}'" >&2
  fails=$((fails + 1))
fi

# ── H. malformed pane observation remains distinguishable from pane gone ────
# Preserve rc 2 through the resolver and name the refusal so in-process caller
# gates refuse before fallback.
malformed_result="$(FAKE_PANE_ID="%tap-codex" bash -c '
  . "$1" >/dev/null 2>&1
  TAP_REGISTRY="$2"
  rc=0
  tap_resolve_self_handle "T/seat:0.0" >/dev/null 2>&1 || rc=$?
  printf "%s|%s" "$rc" "${TAP_SELF_REFUSAL:-}"
' _ "$LIB" "$REG_E")"
if [ "$malformed_result" = "2|generation_unverifiable" ]; then
  echo "authorizer-single-observation: ok [H] malformed observation stays unobservable through resolver"
else
  echo "authorizer-single-observation: FAIL [H] expected rc/refusal 2|generation_unverifiable, got '$malformed_result'" >&2
  fails=$((fails + 1))
fi

[ "$fails" -eq 0 ] || { echo "authorizer-single-observation: FAILED ($fails)" >&2; exit 1; }
echo "authorizer-single-observation: PASS"
