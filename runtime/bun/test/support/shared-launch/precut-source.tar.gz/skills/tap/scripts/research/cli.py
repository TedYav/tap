"""CLI entry point for research-run receipts & clean-pair registry (tap-b80p)."""

import argparse
import json
import os
import sys
from pathlib import Path

try:
    from .receipt import (
        ResearchRunReceipt,
        ReceiptStore,
        ReplayHarness,
        VerifierVerdict,
    )
    from .clean_pair import CleanPairRegistry
except ImportError:
    _repo_root = Path(__file__).resolve().parents[4]
    if str(_repo_root) not in sys.path:
        sys.path.insert(0, str(_repo_root))
    from skills.tap.scripts.research.receipt import (
        ResearchRunReceipt,
        ReceiptStore,
        ReplayHarness,
        VerifierVerdict,
    )
    from skills.tap.scripts.research.clean_pair import CleanPairRegistry


def main():
    parser = argparse.ArgumentParser(
        description="TAP Research Receipts and Clean-Pair Registry CLI"
    )
    parser.add_argument(
        "--store-dir",
        default=None,
        help="Directory for receipts and registry (default: CWD/.tap/research; "
             "tests MUST set this or TAP_RESEARCH_STORE_DIR to a tmp dir)",
    )
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # --- receipt subcommands ---
    receipt_parser = subparsers.add_parser("receipt", help="Research receipt management")
    receipt_sub = receipt_parser.add_subparsers(dest="action", required=True)

    # create
    create_p = receipt_sub.add_parser("create", help="Create a research receipt")
    create_p.add_argument("--prompt", required=True, help="Prompt string")
    create_p.add_argument("--frozen-sources", nargs="*", default=[], help="Frozen source IDs")
    create_p.add_argument("--live-sources", nargs="*", default=[], help="Live source IDs")
    create_p.add_argument("--required-items", type=int, required=True, help="Required item count")
    create_p.add_argument("--observed-items", type=int, required=True, help="Observed item count")
    create_p.add_argument("--declared-model", required=True, help="Declared model name")
    create_p.add_argument("--observed-model", required=True, help="Observed model name")
    create_p.add_argument("--declared-effort", required=True, help="Declared reasoning effort")
    create_p.add_argument("--observed-effort", required=True, help="Observed reasoning effort")
    create_p.add_argument("--harness", required=True, help="Harness name")
    create_p.add_argument("--task-class", default="default", help="Task class")
    create_p.add_argument("--seat", default="unknown", help="Seat handle")
    create_p.add_argument("--tier", default="unknown", help="Model tier")
    create_p.add_argument("--verdict-pass", action="store_true", help="Attach a passing verifier verdict")

    # validate
    val_p = receipt_sub.add_parser("validate", help="Validate a receipt")
    val_p.add_argument("receipt_id", help="Receipt ID or JSON file path")

    # replay
    rep_p = receipt_sub.add_parser("replay", help="Replay-check a receipt")
    rep_p.add_argument("receipt_id", help="Receipt ID")
    rep_p.add_argument("--prompt", help="Target prompt to match")

    # --- registry subcommands ---
    reg_parser = subparsers.add_parser("registry", help="Clean-pair registry management")
    reg_sub = reg_parser.add_subparsers(dest="action", required=True)

    # check
    chk_p = reg_sub.add_parser("check", help="Check cell requirement")
    chk_p.add_argument("--task-class", required=True, help="Task class")
    chk_p.add_argument("--seat", required=True, help="Seat handle")
    chk_p.add_argument("--tier", required=True, help="Model tier")
    chk_p.add_argument("--min-n", type=int, default=3, help="Minimum verified runs")
    chk_p.add_argument("--max-age", type=int, default=86400 * 7, help="Max age seconds")

    # consume
    con_p = reg_sub.add_parser("consume", help="Consume a receipt into the registry")
    con_p.add_argument("receipt_id", help="Receipt ID")

    args = parser.parse_args()

    # Store dir: --store-dir flag, then TAP_RESEARCH_STORE_DIR env, then CWD default.
    # Tests MUST pass --store-dir or set TAP_RESEARCH_STORE_DIR to a tmp dir so
    # pytest-from-repo-root never deposits receipts in the working tree (tap-u1cq).
    store_dir = args.store_dir or os.environ.get("TAP_RESEARCH_STORE_DIR")
    if store_dir:
        store = ReceiptStore(base_dir=Path(store_dir) / "receipts")
        registry = CleanPairRegistry(storage_path=Path(store_dir) / "clean_pair_registry.json")
    else:
        store = ReceiptStore()
        registry = CleanPairRegistry()

    if args.subcommand == "receipt":
        if args.action == "create":
            verdicts = []
            if args.verdict_pass:
                verdicts.append(
                    VerifierVerdict(
                        verifier_id="cli-verifier",
                        verifier_model=args.observed_model,
                        verifier_family="system",
                        verdict="pass",
                    )
                )
            receipt = ResearchRunReceipt.create(
                prompt=args.prompt,
                frozen_source_ids=args.frozen_sources,
                live_source_ids=args.live_sources,
                required_item_count=args.required_items,
                observed_item_count=args.observed_items,
                declared_model=args.declared_model,
                observed_model=args.observed_model,
                declared_effort=args.declared_effort,
                observed_effort=args.observed_effort,
                harness=args.harness,
                verifier_verdicts=verdicts,
                task_class=args.task_class,
                seat=args.seat,
                tier=args.tier,
            )
            saved_path = store.save(receipt)
            print(json.dumps({"status": "created", "receipt_id": receipt.receipt_id, "path": str(saved_path)}, indent=2))

        elif args.action == "validate":
            receipt = store.load(args.receipt_id)
            if not receipt and Path(args.receipt_id).exists():
                with open(args.receipt_id, "r", encoding="utf-8") as f:
                    receipt = ResearchRunReceipt.from_dict(json.load(f))
            if not receipt:
                print(json.dumps({"ok": False, "error": f"Receipt '{args.receipt_id}' not found"}, indent=2))
                sys.exit(1)
            valid, errors = receipt.validate()
            print(json.dumps({"ok": valid, "is_clean": receipt.is_clean(), "errors": errors}, indent=2))
            if not valid:
                sys.exit(2)

        elif args.action == "replay":
            harness = ReplayHarness(store)
            ok, errors = harness.replay_check(args.receipt_id, target_prompt=args.prompt)
            print(json.dumps({"ok": ok, "errors": errors}, indent=2))
            if not ok:
                sys.exit(2)

    elif args.subcommand == "registry":
        if args.action == "check":
            req = registry.check_requirement(
                task_class=args.task_class,
                seat=args.seat,
                tier=args.tier,
                min_n=args.min_n,
                max_age_seconds=args.max_age,
            )
            res = {
                "requires_verification": req.requires_verification,
                "reason": req.reason,
                "cell_state": req.cell_state.to_dict() if req.cell_state else None,
            }
            print(json.dumps(res, indent=2))
            if req.requires_verification:
                sys.exit(2)

        elif args.action == "consume":
            receipt = store.load(args.receipt_id)
            if not receipt:
                print(json.dumps({"ok": False, "error": f"Receipt '{args.receipt_id}' not found"}, indent=2))
                sys.exit(1)
            cell, updated, reason = registry.consume_receipt(receipt)
            print(json.dumps({"ok": updated, "reason": reason, "cell": cell.to_dict()}, indent=2))
            if not updated:
                sys.exit(2)


if __name__ == "__main__":
    main()
