"""Strict, resolve-once configuration for durable TAP session launches.

The catalog reader, selection rule, notice policy and harness-policy resolver
live in the native engine (`runtime/bun/src/launcher/catalog-listing.ts` and
neighbors), reached through `_preset_bridge`. This module holds the Python
DTOs, the tuning fence the CLI shares, and the hydrated lookups the launcher
consumes.
"""

from __future__ import annotations

import dataclasses
import os
import pathlib
import re
import stat
from collections.abc import Callable, Mapping

from completion import HARNESSES  # noqa: F401

# The enumerating pin: tests iterate `presets.HARNESSES` so a seventh harness
# joins by existing. Harness reads moved to the native engine, but the pin
# consumes this name, so the re-export stays.


# Display-only. Known string keys are published on roster surfaces; unknown
# metadata keys are legal and carried verbatim by the native reader (briefing
# text, never parsed — except the four role lists). Values stay free strings
# (operator taste, not enums).
_PROVIDER_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*\Z")


# Shared config also carries tables owned by other readers: recovery-policy.ts
# reads [recovery], and digest_window.py::configured_window reads [delivery].
# They are known here, but their owners validate and apply their contents.
_ENV_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")

# Closed effort domains published by the harness CLI. None on an axis means
# pass-through: the legal key set is not knowable statically (agy model keys
# stall at runtime on an unknown key; codex effort tiers grow). Never clamp.
_EFFORT_AGY = frozenset({"low", "medium", "high"})
_EFFORT_CLAUDE = frozenset({"low", "medium", "high", "xhigh", "max"})
_EFFORT_HERMES = frozenset(
    {"none", "minimal", "low", "medium", "high", "xhigh", "max", "ultra"}
)


@dataclasses.dataclass(frozen=True)
class TuningAxis:
    """How one TAP tuning axis is spelled on one harness CLI.

    ``argv`` is the flag tokens before the value. ``value_template`` if set is the
    value token (codex ``-c`` takes ``model_reasoning_effort="{value}"`` rather
    than a bare level). ``domain`` is the closed value set when the harness
    publishes one; None means pass through.
    """

    argv: tuple[str, ...]
    value_template: str | None = None
    domain: frozenset[str] | None = None

    def tokens(self, value: str) -> tuple[str, ...]:
        rendered = (
            self.value_template.format(value=value) if self.value_template else value
        )
        return (*self.argv, rendered)


@dataclasses.dataclass(frozen=True)
class HarnessTuning:
    """Per-harness tuning surface. A missing axis is unsupported, not inherited."""

    model: TuningAxis | None = None
    effort: TuningAxis | None = None
    provider: bool = False  # opencode: fuses into model as provider/model


# Single source of truth. Every name in completion.HARNESSES must have a row —
# a harness in the constant with no row is itself a red (enumerating pin).
# Builders and resolve_tuning both read this; preset cards compose with it.
TUNING_CAPABILITIES: dict[str, HarnessTuning] = {
    "claude": HarnessTuning(
        model=TuningAxis(argv=("--model",)),
        effort=TuningAxis(argv=("--effort",), domain=_EFFORT_CLAUDE),
    ),
    "codex": HarnessTuning(
        model=TuningAxis(argv=("--model",)),
        effort=TuningAxis(
            argv=("-c",),
            value_template='model_reasoning_effort="{value}"',
        ),
    ),
    "opencode": HarnessTuning(
        model=TuningAxis(argv=("--model",)),
        provider=True,
    ),
    "cursor": HarnessTuning(
        model=TuningAxis(argv=("--model",)),
    ),
    "agy": HarnessTuning(
        model=TuningAxis(argv=("--model",)),
        effort=TuningAxis(argv=("--effort",), domain=_EFFORT_AGY),
    ),
    "hermes": HarnessTuning(
        model=TuningAxis(argv=("--model",)),
        effort=TuningAxis(argv=("--reasoning",), domain=_EFFORT_HERMES),
    ),
}


def _capabilities(harness: str) -> HarnessTuning:
    """Fail closed: a harness missing from the table supports no axis."""
    return TUNING_CAPABILITIES.get(harness, HarnessTuning())


def _format_domain(domain: frozenset[str]) -> str:
    rank = {name: i for i, name in enumerate(
        ("none", "minimal", "low", "medium", "high", "xhigh", "max", "ultra")
    )}
    return ", ".join(sorted(domain, key=lambda value: (rank.get(value, len(rank)), value)))


def axis_support_list(field: str) -> str:
    """Harnesses whose table row has a truthy ``field`` (model/effort/provider)."""
    names = [
        name
        for name, row in sorted(TUNING_CAPABILITIES.items())
        if getattr(row, field, None)
    ]
    return ", ".join(names) if names else "none"


def model_argv(harness: str, model: str | None) -> list[str]:
    """Flag tokens for a resolved model, or empty when none was supplied.

    Builders emit this rather than hardcoding ``--model``. resolve_tuning already
    refused a model on a harness with no model axis.
    """
    if not model:
        return []
    axis = _capabilities(harness).model
    if axis is None:
        return []
    return list(axis.tokens(model))


def _check_domain(
    harness: str,
    field: str,
    value: str,
    axis: TuningAxis,
    context: "TuningContext",
) -> None:
    if axis.domain is not None and value not in axis.domain:
        raise context.domain_error(harness, field, value, axis.domain)
_EXACT_FORBIDDEN_ENV = frozenset(
    {
        "HOME",
        "USER",
        "LOGNAME",
        "SHELL",
        "PATH",
        "PWD",
        "OLDPWD",
        "CDPATH",
        "TMUX",
        "TMUX_PANE",
        "TERM_SESSION_ID",
        "SESSION",
        "SESSION_ID",
        "AGENT_ID",
        "AGENT_NAME",
        "TEAM",
        "TEAM_NAME",
        "CWD",
        "BUS",
        "BUS_PATH",
        "BASH_ENV",
        "ENV",
        "NODE_OPTIONS",
        "PYTHONHOME",
        "PYTHONPATH",
        "PYTHONSTARTUP",
        "LD_PRELOAD",
        "LD_LIBRARY_PATH",
        "DYLD_INSERT_LIBRARIES",
        "DYLD_LIBRARY_PATH",
        "RUBYOPT",
        "PERL5OPT",
    }
)
_FORBIDDEN_ENV_TOKENS = frozenset(
    {
        "IDENTITY",
        "HANDLE",
        "TEAM",
        "CWD",
        "BUS",
        "SANDBOX",
        "APPROVAL",
        "APPROVALS",
        "PERMISSION",
        "PERMISSIONS",
        "BYPASS",
    }
)
_CREDENTIAL_ENV_TOKENS = frozenset({"PASSWORD", "PASSWD", "SECRET"})
_CREDENTIAL_ENV_SEQUENCES = ("API_KEY", "ACCESS_KEY", "PRIVATE_KEY")


import _preset_bridge as _bridge

class PresetError(Exception):
    def __init__(self, error_class: str, action: str, detail: str):
        super().__init__(detail)
        self.error_class = error_class
        self.action = action
        self.detail = detail


@dataclasses.dataclass(frozen=True)
class PresetProvenance:
    name: str
    source_path: str
    config_digest: str


@dataclasses.dataclass(frozen=True)
class PresetMetadata:
    """Display-only routing profile. Never reaches argv, env, or the session row.

    `avoid_roles` is a soft preference (can do it, prefer not to). `banned_roles`
    is a hard exclusion (must not be assigned). A role in more than one bucket
    is an authoring error, not a ranking.
    """

    pronouns: str | None = None
    intelligence: str | None = None
    cost_basis: str | None = None
    cost_level: str | None = None
    budget_capacity: str | None = None
    speed: str | None = None
    summary: str | None = None
    primary_roles: tuple[str, ...] = ()
    secondary_roles: tuple[str, ...] = ()
    avoid_roles: tuple[str, ...] = ()
    banned_roles: tuple[str, ...] = ()
    # Keys this release has never heard of, carried VERBATIM (Ops, 2026-08-18).
    #
    # The config is its owner's to extend, so he can add a field and expect the
    # reading models to work out what it means with no code change. That only
    # holds if the parser stops dropping what it does not recognize — this used
    # to be a whitelist, and "legal and ignored" meant the value reached nothing.
    #
    # Kept SEPARATE from the typed fields rather than merged into one bag, so a
    # reader can still tell "the schema knows this" from "the schema is passing
    # this along" — the same record-versus-guess distinction the roster draws
    # with its `?` marker.
    extra: tuple[tuple[str, object], ...] = ()

    def referenced_roles(self) -> frozenset[str]:
        return frozenset(
            self.primary_roles + self.secondary_roles + self.avoid_roles + self.banned_roles
        )

    def to_json(self) -> dict[str, object]:
        return {
            "pronouns": self.pronouns,
            "intelligence": self.intelligence,
            "cost_basis": self.cost_basis,
            "cost_level": self.cost_level,
            "budget_capacity": self.budget_capacity,
            "speed": self.speed,
            "summary": self.summary,
            "primary_roles": list(self.primary_roles),
            "secondary_roles": list(self.secondary_roles),
            "avoid_roles": list(self.avoid_roles),
            "banned_roles": list(self.banned_roles),
            # Unknown keys ride at the top level beside the known ones: a consumer
            # asking "what does the operator say about this preset" should not
            # have to know which release learned which field. A known key can
            # never be shadowed, because a malformed KNOWN key is dropped with a
            # notice rather than demoted into here wearing a different hat.
            **{key: value for key, value in self.extra},
        }


@dataclasses.dataclass(frozen=True)
class ResolvedPreset:
    harness: str
    model: str | None
    harness_passthrough: tuple[str, ...]
    env: dict[str, str]
    provenance: PresetProvenance
    # Display only. `family` names a `[notes]` key so an operator annotation can follow a
    # preset-launched seat; preset names (sol-max, fable, glm) do not match notes keys, so
    # without this bridge the notes cannot travel. It MUST never reach argv or env — a display
    # key that can act as a switch is the trap, and a test forecloses it.
    family: str | None = None
    note: str | None = None
    metadata: PresetMetadata | None = None
    # Display only, and carried for the same reason `family` is: the field was
    # VALIDATED here and then dropped, so `tap presets` had no source for the
    # one-line column the catalog already authors (all 15 live presets set it).
    # It is the short label; metadata.summary is the long prose, and they are not
    # interchangeable. Like family and note, it must never reach argv or env.
    description: str | None = None
    # The param KEYS, carried alongside the rendered argv because the rendering is
    # lossy in the one way a consumer needs to undo. params_to_argv emits `True`
    # as a bare `--flag` and everything else as `[--flag, value]`, so
    # `('--foo', '--mode')` is either two bare flags or one key with a
    # flag-shaped VALUE, and argv alone cannot say which. `tap ask` needs the keys
    # to refuse a preset that restates a flag its adapter owns, and inferring them
    # from argv made `params.foo = "--mode"` look like `params.mode`.
    param_keys: tuple[str, ...] = ()


@dataclasses.dataclass(frozen=True)
class PresetCatalog:
    source_path: str
    _presets: dict[str, ResolvedPreset]
    # None means the file has no `[roles]` table.
    roles: dict[str, str] | None = None
    # Presets that ARE in the file but could not be made sense of, with the
    # reason. Asking for one by name must not answer "not found": the operator
    # would go re-add a preset that is already there instead of fixing what is
    # wrong with it — and the case that matters most is a fence-crossing `env`,
    # where the misdirection points away from a security-relevant key.
    dropped: dict[str, str] = dataclasses.field(default_factory=dict)

    @property
    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._presets))

    def get(self, name: str) -> ResolvedPreset | None:
        return self._presets.get(name)

    def require(self, name: str) -> ResolvedPreset:
        resolved = self.get(name)
        if resolved is not None:
            return resolved
        # STILL FAIL-CLOSED, and now honest about which failure it is. Tolerant
        # reading drops an unusable preset instead of refusing the file, so an
        # explicit request for that preset must say it was dropped and why —
        # "not found" is true of the catalog and false about the file.
        if name in self.dropped:
            raise PresetError(
                "preset_not_usable",
                f"fix preset '{name}' in {self.source_path}",
                f"preset '{name}' is defined in {self.source_path} but was not "
                f"usable: {self.dropped[name]}",
            )
        available = ", ".join(self.names) or "none"
        raise PresetError(
            "preset_not_found",
            f"choose an available preset ({available}) or edit {self.source_path}",
            f"preset '{name}' was not found in {self.source_path}",
        )

    def for_handle(self, handle: str) -> ResolvedPreset | None:
        """Map a roster handle onto a catalog preset without inventing one.

        Exact name wins. Otherwise the longest catalog name such that the handle
        is ``<name>-…`` (launcher ``sol.max-2``, Ops's ``sol-pinnacle-debugger``).
        Longest match so ``opus-med`` is not swallowed by ``opus``.
        """
        if not handle:
            return None
        exact = self.get(handle)
        if exact is not None:
            return exact
        matches = [name for name in self._presets if handle.startswith(f"{name}-")]
        if not matches:
            return None
        return self.get(max(matches, key=len))


def _invalid(path: pathlib.Path | str, detail: str) -> PresetError:
    return PresetError(
        "preset_config_invalid",
        f"fix {path}",
        f"invalid preset config {path}: {detail}",
    )


def read_secure_preset_bytes(path: pathlib.Path) -> tuple[bytes, str]:
    flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0)
    try:
        descriptor = os.open(path, flags)
    except FileNotFoundError:
        raise PresetError(
            "preset_config_missing",
            f"create {path}",
            f"requested preset config does not exist: {path}",
        ) from None
    except OSError as exc:
        raise _invalid(path, f"could not open file: {exc}") from exc

    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode):
            raise PresetError(
                "preset_config_insecure",
                f"replace {path} with an operator-owned regular file",
                f"preset config is not a regular file: {path}",
            )
        if metadata.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
            raise PresetError(
                "preset_config_insecure",
                f"chmod 600 {path}",
                f"preset config is group/world writable: {path}",
            )

        resolved = os.path.realpath(path)
        try:
            resolved_metadata = os.stat(resolved)
        except OSError as exc:
            raise _invalid(path, f"could not resolve opened file: {exc}") from exc
        if not os.path.samestat(metadata, resolved_metadata):
            raise _invalid(path, "source changed while it was being opened; retry")

        chunks: list[bytes] = []
        while chunk := os.read(descriptor, 1024 * 1024):
            chunks.append(chunk)
        return b"".join(chunks), resolved
    except OSError as exc:
        raise _invalid(path, f"could not read file: {exc}") from exc
    finally:
        os.close(descriptor)


def _has_control(value: str) -> bool:
    return any(ord(char) < 32 or ord(char) == 127 for char in value)


@dataclasses.dataclass(frozen=True)
class TuningContext:
    """Names the surface a tuning value came from, so a refusal points at what the caller wrote.

    One fence and one per-harness translation serve preset tables, ad-hoc CLI flags, and the
    harness-level config table. Only the wording of a refusal differs between them, so the
    wording is the parameter: without it, reusing the fence would make an ad-hoc `--env`
    violation tell the operator to edit a preset file they never opened.
    """

    field_error: Callable[[str, str], PresetError]
    env_forbidden: Callable[[str], PresetError]
    unsupported: Callable[[str, str, str], PresetError]
    domain_error: Callable[[str, str, str, frozenset[str]], PresetError]
    env_not_table: Callable[[], PresetError]
    env_key_invalid: Callable[[str], PresetError]


def _behavioral_string(value: object, *, field: str, context: TuningContext) -> str:
    if not isinstance(value, str) or not value.strip():
        raise context.field_error(field, "must be a non-empty string")
    if _has_control(value):
        raise context.field_error(field, "contains a control character")
    return value


def _env_key_forbidden(key: str) -> bool:
    upper = key.upper()
    if upper == "TAP" or upper.startswith("TAP_"):
        return True
    if upper in _EXACT_FORBIDDEN_ENV:
        return True
    tokens = upper.split("_")
    if set(tokens) & (_FORBIDDEN_ENV_TOKENS | _CREDENTIAL_ENV_TOKENS):
        return True
    if tokens[-1] == "TOKEN":
        return True
    delimited = f"_{upper}_"
    return any(f"_{sequence}_" in delimited for sequence in _CREDENTIAL_ENV_SEQUENCES)


def _effective_env(raw_env: object, *, context: TuningContext) -> dict[str, str]:
    """Validate a declared env table. The DECLARED value is the value — always.

    This used to let the launching shell's value win whenever the key was already exported,
    which made a preset's meaning depend on which terminal ran it: the same `tap session launch
    sol` produced two different seats, and nothing said so. panel ruling (2026-08-11) banned the
    ambient override and asked for a warning instead. The warning is NOT emitted here — it is
    emitted once at the merge point in `apply_launch_env`, over the final merged declared
    environment, because a key declared in two tiers must warn once naming the value that
    actually won, not once per source naming values that lost.
    """
    if raw_env is None:
        return {}
    if not isinstance(raw_env, dict):
        raise context.env_not_table()

    effective: dict[str, str] = {}
    for key, raw_value in raw_env.items():
        if not isinstance(key, str) or not _ENV_RE.fullmatch(key):
            raise context.env_key_invalid(key)
        if _env_key_forbidden(key):
            raise context.env_forbidden(key)
        effective[key] = _behavioral_string(raw_value, field=f"env.{key}", context=context)
    return effective


def _cli_flag(field: str) -> str:
    """Render a resolver field name as the flag the operator actually typed."""
    if field.startswith("env."):
        return f"--env {field[len('env.'):]}"
    return f"--{field}"


def cli_tuning_context() -> TuningContext:
    """Refusals for tuning that came from argv.

    Every message names a flag. The fence is shared with presets, so without this the operator
    who typed `--env` would be told to edit a preset file they never opened — a remediation that
    is well-formed, passes every test, and cannot be followed.
    """
    return TuningContext(
        field_error=lambda field, problem: PresetError(
            "launch_arg_invalid",
            f"fix the {_cli_flag(field)} value",
            f"{_cli_flag(field)} {problem}",
        ),
        env_forbidden=lambda key: PresetError(
            "launch_env_forbidden",
            f"remove --env {key}=... from the command",
            f"--env key '{key}' crosses the identity, transport, process, credential, or policy fence",
        ),
        unsupported=lambda harness, field, detail: PresetError(
            f"launch_{field}_unsupported",
            f"remove --{field} or launch a harness that supports it ({axis_support_list(field)})",
            f"harness '{harness}' does not support --{field}"
            + (f"; {detail}" if detail else "")
            + f" (supported by: {axis_support_list(field)})",
        ),
        domain_error=lambda harness, field, offered, domain: PresetError(
            "launch_arg_invalid",
            f"pass --{field} as one of: {_format_domain(domain)}",
            f"harness '{harness}' does not accept --{field} {offered} "
            f"(legal: {_format_domain(domain)})",
        ),
        env_not_table=lambda: PresetError(
            "launch_arg_invalid",
            "pass environment as --env KEY=VALUE",
            "--env values must be supplied as KEY=VALUE pairs",
        ),
        env_key_invalid=lambda key: PresetError(
            "launch_arg_invalid",
            f"fix the --env key '{key}'",
            f"--env key '{key}' is not a valid environment variable name",
        ),
    )


@dataclasses.dataclass(frozen=True)
class ResolvedTuning:
    model: str | None
    harness_passthrough: tuple[str, ...]
    env: dict[str, str]


def params_to_argv(params):
    """Forwarder. The engine is `runtime/bun/src/launcher/argv-splice.ts`."""
    return tuple(_bridge.call("argv.render", params=dict(params)))


def config_only(argv):
    """Forwarder. The engine is `runtime/bun/src/launcher/config-args.ts`.

    Codex's repeatable `-c`/`--config` option is keyed by its ASSIGNMENT rather
    than its flag, and the rules that follow from that -- stop at `--`, ignore a
    value whose `=` is leading or whose text starts with a dash, trim the key,
    let the last spelling of a key win -- lived here in Python and now live
    there. A differential over 15,582 constructed argv pairs agrees on every one,
    and four mutants of the native rules are each caught by it.
    """
    return _bridge.call("config.only", argv=list(argv))


def config_defaults(defaults, higher):
    """Forwarder. Keeps winning assignments in original order and spelling."""
    return _bridge.call("config.defaults", defaults=list(defaults), higher=list(higher))


def compose_config(defaults, explicit):
    """Forwarder."""
    return _bridge.call("config.compose", defaults=list(defaults), explicit=list(explicit))


def splice_tokens_if_absent(argv, tokens, *, floor=True, config_keys=False):
    """Forwarder. Insert tokens at index 1; `floor` is for CONFIG-SOURCED tokens.

    The rules it carries -- builder argv is the floor for config tokens while
    operator-typed passthrough inserts unconditionally, presence is exact OPTION
    equality so `--model` never matches `--model-reasoning`, a valued token is
    skipped together with its value, and insertion is after argv[0] because four
    builders append a trailing positional -- all live in the engine now. A
    differential over 21,648 constructed cases agrees on every one, and six
    mutants of those rules are each caught by it.
    """
    return _bridge.call("argv.splice", argv=list(argv), tokens=list(tokens),
                        floor=floor, config_keys=config_keys)


def splice_verbatim_params(argv, params, *, config_keys=False):
    """Forwarder. Insert config params at index 1 through the shared splice."""
    return _bridge.call("argv.splice_params", argv=list(argv), params=dict(params),
                        config_keys=config_keys)


def resolve_tuning(
    *,
    harness: str,
    model: object = None,
    effort: object = None,
    provider: object = None,
    raw_env: object = None,
    context: TuningContext,
    before_env: Callable[[], None] | None = None,
) -> ResolvedTuning:
    """Validate and translate tuning values for one harness, whatever surface supplied them.

    The single home for the env fence, per-harness translation (TUNING_CAPABILITIES),
    and opencode provider fusion. Callers differ only in their ``context`` — the wording
    of a refusal — so a fence tightening lands once and every surface inherits it.

    Contract for Python callers: ``None`` means NOT SUPPLIED, and there is no way to spell
    "supplied but empty" — an empty string is a refusal, not an erasure. TOML cannot express a
    null, so preset resolution cannot reach this distinction; argv callers can, which is why it
    is stated rather than left to the signature.

    ``before_env`` runs after the model/effort/provider checks and before the env fence. It
    exists so a caller can keep a check of its own INSIDE this refusal order rather than around
    it: the preset path validates `description` there, which is where it validated before this
    function existed. Without the hook, extracting the resolver would silently re-rank which
    refusal a doubly-invalid preset reports first.
    """
    caps = _capabilities(harness)

    resolved_model = None
    if model is not None:
        resolved_model = _behavioral_string(model, field="model", context=context)
        if caps.model is None:
            raise context.unsupported(harness, "model", "")
        _check_domain(harness, "model", resolved_model, caps.model, context)

    resolved_effort = None
    if effort is not None:
        resolved_effort = _behavioral_string(effort, field="effort", context=context)
        if caps.effort is None:
            raise context.unsupported(harness, "effort", "")
        _check_domain(harness, "effort", resolved_effort, caps.effort, context)

    if provider is not None:
        resolved_provider = _behavioral_string(provider, field="provider", context=context)
        if not _PROVIDER_RE.fullmatch(resolved_provider):
            raise context.field_error("provider", "is not a provider token")
        if not caps.provider:
            raise context.unsupported(harness, "provider", "")
        if resolved_model is None:
            raise context.unsupported(harness, "provider", "provider requires model")
        resolved_model = f"{resolved_provider}/{resolved_model}"

    if before_env is not None:
        before_env()

    passthrough = (
        caps.effort.tokens(resolved_effort)
        if resolved_effort is not None and caps.effort is not None
        else ()
    )
    env = _effective_env(raw_env, context=context)
    return ResolvedTuning(model=resolved_model, harness_passthrough=passthrough, env=env)


def suppress_notices(suppressed: bool) -> None:
    """Set by the launcher once it knows whether the caller asked for machine-readable output.

    The decision lives in the carried notice lifetime, and the NATIVE notice
    operation is its only writer: this forwards through `notice.suppress`, so
    the engine that obeys suppression is also the only thing that records it.
    The bridge carries the response state opaquely — no adapter-side flag to
    disagree with the engine's.
    """
    _bridge.call("notice.suppress", on=bool(suppressed))


def _carry_json_silence() -> None:
    """Carry TAP_JSON silence into the engine, monotonically, before a read.

    `TAP_JSON=1` promises ONE object and no stderr prose. A caller that bypasses
    `main` never had `suppress_notices` run for it, so each read deepens the
    carried suppression through the native operation — never lifting whatever
    the command already established.
    """
    if os.environ.get("TAP_JSON") == "1":
        _bridge.call("notice.suppress", on=True)


def reset_notices() -> None:
    """Start a fresh command's notice history.

    Called once per CLI invocation. It is a real part of the dedup rather than hygiene: the
    de-duplication is scoped to a COMMAND, and a long-lived process (or a test suite,
    which is one) that never reset would suppress the second command's legitimately identical
    notice. An earlier draft used process-scoped dedup and would have blanked three cells of
    the ambient-warning matrix for exactly that reason. The native `notice.reset`
    operation clears the history and PRESERVES suppression — a `--json` command
    that suppresses first stays quiet after its reset.
    """
    _bridge.call("notice.reset")


def try_load_catalog_for_display(
    environ: Mapping[str, str] | None = None,
) -> PresetCatalog | None:
    """Load the catalog for roster/display join. Never raises, never notices.

    A missing, unreadable, or invalid file omits display facts — roster liveness
    outranks a broken config.toml. Launch notices (legacy-shadow, vacant
    ``[presets]``) stay off this path; they belong to an explicit preset resolve.

    Forwarder. The engine is `runtime/bun/src/launcher/catalog-listing.ts`
    (`tryLoadCatalogForDisplay`), which is silent-by-design INSIDE the engine —
    the roster read emits nothing on any channel, so there is nothing for this
    side to borrow quiet about, and no Python suppress/restore runs here to
    disturb the command's carried suppression. Transport failures are absorbed
    like every other failure: a roster read without bun answers "no catalog",
    never a crash.
    """
    try:
        dto = _bridge.call("catalog.display", env=_environ_payload(environ))
        return None if dto is None else _catalog_from_dto(dto)
    except Exception:
        return None


def roster_display_facts(
    handles: list[str],
    environ: Mapping[str, str] | None = None,
    recorded: Mapping[str, str] | None = None,
) -> dict[str, dict[str, object]]:
    """Per-handle catalog facts for ``tap team``. Unjoined handles are absent.

    RECORD FIRST, NAME-GUESS SECOND, and the guess is marked as such.

    `recorded` maps handle -> the preset name persisted on the seat's record at
    launch (tap-4ulb's resolve-once provenance). That is durable truth about what
    a seat was launched with. `for_handle` is an INFERENCE from the handle text,
    and it was the only source here — so a seat launched with preset `cursor-grok`
    but handled `grok` reported `grok`, because a catalog entry of that name
    exists. That was live on this machine's roster, not a hypothetical.

    An inferred value carries ``preset_inferred: True`` so no surface prints a
    guess with the same authority as a record. The fallback stays because rows
    predating the provenance field, and manually registered seats, have no record
    to read — dropping it would blank facts that are usually right.
    """
    catalog = try_load_catalog_for_display(environ)
    recorded = recorded or {}
    if catalog is None:
        # A RECORDED PRESET SURVIVES A BROKEN CATALOG. The early return discarded
        # `recorded` before consulting it, so removing or breaking config.toml
        # erased provenance the seat records durably — the resolve-once contract
        # says the record is the truth, and a catalog that will not parse is
        # exactly when that matters. Roles/metadata are genuinely unavailable
        # (they live in the catalog), so they are omitted rather than guessed.
        # ...but do NOT claim the preset was REMOVED. `preset_absent_from_catalog`
        # means one specific thing — the catalog is readable and this recorded
        # name is not in it — and a consumer acts on it by telling the operator
        # the entry is gone. An unreadable catalog is a different fact with a
        # different repair (fix the file, not the preset), and collapsing the two
        # into one flag makes them indistinguishable in `--json` (CodeRabbit,
        # #xxx). Separate signal, so each says only what it knows.
        return {
            handle: {
                "preset": name,
                "roles": "",
                "preset_catalog_unavailable": True,
            }
            for handle, name in recorded.items()
            if name
        }
    facts: dict[str, dict[str, object]] = {}
    for handle in handles:
        inferred = False
        preset = None
        recorded_name = recorded.get(handle)
        if recorded_name:
            preset = catalog.get(recorded_name)
            if preset is None:
                # The seat names a preset the catalog no longer defines. The
                # RECORD still outranks a guess: report what it was launched with
                # rather than silently substituting a different entry that merely
                # matches the handle.
                facts[handle] = {
                    "preset": recorded_name,
                    "roles": "",
                    "preset_absent_from_catalog": True,
                }
                continue
        if preset is None:
            preset = catalog.for_handle(handle)
            inferred = preset is not None
        if preset is None:
            continue
        item: dict[str, object] = {"preset": preset.provenance.name}
        if inferred:
            item["preset_inferred"] = True
        if preset.metadata is not None:
            item["metadata"] = preset.metadata.to_json()
            item["roles"] = ", ".join(preset.metadata.primary_roles)
        else:
            item["roles"] = ""
        facts[handle] = item
    return facts


def catalog_display_rows(
    environ: Mapping[str, str] | None = None,
) -> tuple[str | None, tuple[dict[str, str], ...]]:
    """Rows for ``tap presets``: (source_path, rows). No catalog -> (None, ()).

    The discovery verb's whole job is answering "who can I launch?", so it must
    survive the states where a launch would refuse: a missing, unreadable, or
    malformed config degrades to a notice at the caller, never an error — the
    same policy ``tap session launch`` applies to ``[harness.*]``. That is why
    this composes ``try_load_catalog_for_display`` rather than
    ``load_preset_catalog``: identical reader, notices suppressed, exceptions
    absorbed. Returning the source path lets the caller say WHICH file it read,
    which is the difference between "you have no presets" and "I read a file you
    did not mean".

    ``description`` is the short label the catalog authors; ``metadata.summary``
    is long prose and is deliberately NOT substituted for it — a table column
    that sometimes holds a sentence and sometimes holds a paragraph is not a
    column. Roles come from ``metadata.primary_roles``, the same field
    ``tap team`` already publishes, so one preset reads identically on both
    surfaces.
    """
    catalog = try_load_catalog_for_display(environ)
    if catalog is None:
        return (None, ())
    rows: list[dict[str, str]] = []
    for name in catalog.names:
        preset = catalog.get(name)
        if preset is None:  # pragma: no cover - names() is derived from the same dict
            continue
        metadata = preset.metadata
        rows.append(
            {
                "name": name,
                "harness": preset.harness,
                "model": preset.model or "",
                "description": (preset.description or "").strip(),
                "roles": ", ".join(metadata.primary_roles) if metadata else "",
            }
        )
    return (catalog.source_path, tuple(rows))


def metadata_notice(
    name: str, metadata: PresetMetadata | None, verb: str = "tap session"
) -> str | None:
    """Launch-time sibling of the family-note faucet. None means stay quiet.

    `verb` labels the line with the command the operator actually typed. This
    resolver is shared with `tap crew add`, which replays these notices verbatim,
    so a hard-coded prefix made a successful crew command report its own output
    under a different verb's name (codex, #xxx) — the refusals were already
    caller-aware and the notices were not.
    """
    if metadata is None:
        return None
    roles = ", ".join(metadata.primary_roles)
    summary = (metadata.summary or "").strip()
    if not roles and not summary:
        return None
    extra = f"{roles} — {summary}" if roles and summary else (roles or summary)
    return f"{verb}: {name} — {extra}"


def emit_notice(message: str) -> None:
    """One place for operator-facing config notices, so tests can capture them.

    Identical text is said ONCE per command. `resume --all` walks a cohort and re-reads harness
    policy per seat, so N seats sharing one collision or one broken config produced N identical
    lines — the operator reads that as N problems, and the docstring on apply_launch_env already
    promised once-per-command (kimi NIT-2, grok's cohort probe). Dedup is on the exact rendered
    string, which is the right key precisely BECAUSE these notices carry no seat identity: two
    identical lines are indistinguishable to the reader, so the second one only adds noise. A
    notice that ever names its seat must not be deduped this way.

    The whole lifetime — suppression gate, said-history, and the stderr line
    itself — is the ENGINE's, through the native `notice.emit` operation: the
    door writes the line, the carried state records it, and the bridge relays
    the child's stderr to the caller. One command, one history, one printer;
    this adapter carries state opaquely and implements nothing. `TAP_JSON=1`
    deepens the carried suppression here too, so a structured caller that
    reaches this function without going through `main` still honours the
    no-stderr promise.
    """
    _carry_json_silence()
    _bridge.call("notice.emit", message=message)


def _environ_payload(environ: Mapping[str, str] | None = None) -> dict[str, str]:
    """The env the engine locates the config file from, and nothing else.

    ``environ`` locates the config file (XDG) and nothing else — a declared env value is never
    read from it. That narrowing is the ambient inversion, not an oversight. Passing the
    caller's mapping VERBATIM (not merged into `os.environ`) keeps a test or embedder's
    two-key environ authoritative, exactly as the local reader honored it.
    """
    return dict(os.environ if environ is None else environ)


def _catalog_from_dto(dto: dict) -> PresetCatalog:
    """Rehydrate the native engine's catalog DTO into the local dataclasses.

    Tuple/list boundaries are RESTORED here, not merely tolerated: `names` stays
    a derived sorted tuple, role buckets and passthrough vectors come back
    tuples, and metadata `extra` is a tuple of pairs again — the shapes every
    Python consumer (and the launcher's `{...}` renders) already pattern-match.
    The engine's `version` and per-preset `params` are native-internal and
    deliberately dropped: the Python facade never carried them.
    """
    resolved: dict[str, ResolvedPreset] = {}
    for name, raw in dto["presets"].items():
        metadata = raw["metadata"]
        resolved[name] = ResolvedPreset(
            harness=raw["harness"],
            model=raw["model"],
            harness_passthrough=tuple(raw["harness_passthrough"]),
            env=dict(raw["env"]),
            provenance=PresetProvenance(
                name=raw["provenance"]["name"],
                source_path=raw["provenance"]["source_path"],
                config_digest=raw["provenance"]["config_digest"],
            ),
            family=raw["family"],
            note=raw["note"],
            description=raw["description"],
            metadata=None if metadata is None else PresetMetadata(
                pronouns=metadata["pronouns"],
                intelligence=metadata["intelligence"],
                cost_basis=metadata["cost_basis"],
                cost_level=metadata["cost_level"],
                budget_capacity=metadata["budget_capacity"],
                speed=metadata["speed"],
                summary=metadata["summary"],
                primary_roles=tuple(metadata["primary_roles"]),
                secondary_roles=tuple(metadata["secondary_roles"]),
                avoid_roles=tuple(metadata["avoid_roles"]),
                banned_roles=tuple(metadata["banned_roles"]),
                extra=tuple((key, value) for key, value in metadata["extra"]),
            ),
            param_keys=tuple(raw["param_keys"]),
        )
    roles = dto["roles"]
    return PresetCatalog(
        dto["source_path"],
        resolved,
        None if roles is None else dict(roles),
        dict(dto["dropped"]),
    )


def load_preset_catalog(
    environ: Mapping[str, str] | None = None,
) -> PresetCatalog:
    """Resolve presets from `config.toml` when it defines them, else `presets.toml`.

    Forwarder. The engine is `runtime/bun/src/launcher/catalog-listing.ts`
    (`loadPresetCatalog`), which owns the per-section fallback, the secure
    read, tolerant parsing, dropped-vs-missing, and every notice this side
    used to emit — byte-identical, pinned by the pre-cutover oracle
    (`tests/test_presets_r4_cutover.py`).

    Fallback is PER SECTION, never per file. The sanctioned rollout has the operator create a
    `config.toml` carrying only `[harness.*]` while their presets still live in `presets.toml`;
    whole-file precedence would load an empty catalog at exactly that moment and break every
    preset-spelled launch until they migrated. This path stays fully fail-closed — an explicit
    preset request that cannot be honoured refuses, never silently downgrades to no preset. That
    is the half of the original fast-path guarantee this PR preserved; the other half (a direct
    harness never opening the file at all) is superseded, and both halves are stated in
    CONTRACT.md §Session launch presets, which is the canonical surface rather than a line range
    in a design doc that has since moved.
    """
    _carry_json_silence()
    return _catalog_from_dto(_bridge.call("catalog.load", env=_environ_payload(environ)))


@dataclasses.dataclass(frozen=True)
class HarnessEnv:
    env: dict[str, str]
    notices: tuple[str, ...]
    params: dict[str, bool | str | list[str]] = dataclasses.field(default_factory=dict)
    permissions: str = "bypass"


def resolve_harness_env(
    harness: str, environ: Mapping[str, str] | None = None
) -> HarnessEnv:
    """Tier 2: machine policy for a harness, read fresh on every launch and resume.

    Forwarder. The engine is `resolveHarnessPolicy`
    (`runtime/bun/src/launcher/catalog.ts`), which owns the degradation split
    this docstring states: absent silent; unreadable/malformed/insecure empty
    plus one recoverable notice; well-formed but fenced key refusing, scoped to
    THIS harness's table. Policy-tier notices come back RETURNED data — the
    launcher's notify gate owns whether they print.

    ``environ`` locates the config file (XDG) and nothing else; a declared value is never taken
    from it. Machine policy that a shell export could silently rewrite would not be policy.

    Degradation splits by failure class deliberately, because this file now serves consumers
    with very different costs of refusing, and RESUME IS THE RECOVERY VERB — it has to run in
    the failure state or the operator cannot get back the seats they would use to fix the file.

      absent                      -> empty, silent. A machine with no config is a legitimate
                                     state, not an error.
      unreadable/malformed/insecure -> empty, launch proceeds, ONE notice naming the file and
                                     the fault, and saying plainly that policy is not held.
      well-formed but fenced key  -> refuse, scoped to THIS harness's table. A bad key in
                                     [harness.claude.env] must not strand codex seats.
      explicit --preset request   -> unaffected; that path stays fail-closed elsewhere.
    """
    _carry_json_silence()
    dto = _bridge.call("policy.resolve", harness=harness, env=_environ_payload(environ))
    return HarnessEnv(
        dict(dto["env"]),
        tuple(dto["notices"]),
        dict(dto["params"]),
        dto["permissions"],
    )
