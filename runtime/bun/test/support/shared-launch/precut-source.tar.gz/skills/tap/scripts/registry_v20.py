"""v0.20 registry schema helpers — dormant until the migration flip.

These helpers define the post-flip store shapes (global-registry.json as a
state document, team-registry.json with seats + instance ids, team-history/
tombstones and per-handle lineage logs). Live verbs do NOT call the mutating
paths until U3+ and `tap admin migrate-registry` (U7) write the flip marker.

The flip marker IS `~/.tap/global-registry.json` with `schema: "0.20"` (no
separate marker file). History is NEVER registry state — it lives only under
team-history/ / global-history/.
"""
from __future__ import annotations

import json
import os
import pathlib
import secrets
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from typing import Any, Mapping, MutableMapping, Optional

SCHEMA = "0.20"


def _verbose_state(event: str, path: str) -> None:
    # Standalone registry consumers need no diagnostics dependency when disabled.
    if os.environ.get("TAP_VERBOSE") == "1":
        from verbose import emit
        emit(event, path=path)


def global_registry_path(index_home: Optional[str] = None) -> str:
    home = index_home or os.environ.get("TAP_INDEX_HOME") or os.path.expanduser("~/.tap")
    return os.path.join(home, "global-registry.json")


def flip_marker_state(index_home: Optional[str] = None) -> str:
    """Return absent | live | invalid for the global-registry flip marker.

    absent  — NOTHING at global-registry.json (genuine pre-flip; legacy routing
              allowed). Absence of an ENTRY, not absence of a readable file.
    live    — present and schema == 0.20 with a dict ``teams`` map (or absent key)
    invalid — an entry exists but is not a usable marker: a directory, a
              symlink to a directory, a broken symlink, or a regular file that
              is unreadable / wrong schema / non-dict ``teams``
              (fail closed; never legacy). WAVE 6.6 / 3682338121: a list or
              other non-object ``teams`` value must not classify live — enroll
              must not normalize it to ``{}`` and replace prior enrollments.
    """
    path = global_registry_path(index_home)
    _verbose_state("state_read", path)
    if not os.path.isfile(path):
        # RULE 38 / RULE 19 (sol-pinnacle-3, P1 on #xxxx). `isfile` alone
        # collapsed "nothing is here" with "something is here that is not a
        # regular file". A DIRECTORY, a SYMLINK TO A DIRECTORY, or a BROKEN
        # SYMLINK at the marker path is a BROKEN marker, not the absence of one
        # -- and `absent` is the one verdict that LICENSES legacy routing. The
        # measured consequence: `tap in` returned 0 against a directory here
        # while writing the retired bus registry, and replaced a
        # symlink-to-directory with the marker. Infrastructure failure became
        # predicate-false and then success.
        #
        # `isfile` follows symlinks, so symlink-to-regular still parses below.
        if os.path.lexists(path):
            return "invalid"
        return "absent"
    try:
        with open(path) as fh:
            data = json.load(fh)
    except Exception:
        return "invalid"
    if not isinstance(data, dict):
        return "invalid"
    if str(data.get("schema") or "") != SCHEMA:
        return "invalid"
    # Presence-sensitive (WAVE 6.6 / 3682338121 + sol 114826Z): an omitted
    # ``teams`` key is valid (treated as empty); a PRESENT non-dict value
    # (null/list/scalar) is invalid — never classify live then normalize away.
    if "teams" in data and not isinstance(data["teams"], dict):
        return "invalid"
    return "live"


def is_flip_live(index_home: Optional[str] = None) -> bool:
    """True iff the one cutover has completed (global-registry.json present + schema)."""
    return flip_marker_state(index_home) == "live"


# Dedicated exit codes for in-lock authority validation (WAVE 6.12 ITEM 7 /
# sol 134032Z). Callers map these after flock, before read/mutate.
AUTHORITY_REFUSE_EXIT = 4   # invalid/unknown marker, or live acting unreachable
AUTHORITY_RETRY_EXIT = 17   # live but locked path ≠ current acting (rebind+retry)


def validate_locked_registry_authority(
    locked_path: str,
    root: str,
    *,
    team: Optional[str] = None,
    index_home: Optional[str] = None,
    allow_unenrolled_canonical: bool = False,
) -> None:
    """After acquiring ``locked_path``'s sidecar, prove it is still authority.

    Exhaustive marker sample under the lock (WAVE 6.12 ITEM 7):
      absent  — pre-flip; mutation of ``locked_path`` remains sanctioned
      live    — resolve current acting for ``root``/``team``; realpath must
                match ``locked_path`` or exit AUTHORITY_RETRY_EXIT (17)
      invalid / unknown — exit AUTHORITY_REFUSE_EXIT (4)

    ``allow_unenrolled_canonical`` (tap-yn2y): when the root is flip-live but
    not yet enrolled, permit mutation of the canonical
    ``<root>/.tap/team-registry.json`` only — the bootstrap ensure path. Never
    permits the retired bus mirror under live.

    Never mutates. Call immediately after ``fcntl.flock`` and before any
    registry read/write so a writer that blocked through migrate publication
    cannot land membership only on the retired bus mirror.
    """
    state = flip_marker_state(index_home)
    if state == "absent":
        return
    if state != "live":
        print(
            "tap: registry flip marker is present but unreadable or wrong schema "
            "— refusing membership mutation",
            file=sys.stderr,
        )
        raise SystemExit(AUTHORITY_REFUSE_EXIT)
    # Prefer root-only match (alias≠basename). An explicit team key is only a
    # hint — if it misses, fall back to root so relocated custom acting under
    # an alias global key still validates.
    st, acting = resolve_team_registry_for_root(
        root, index_home=index_home, team=team or None,
    )
    if st != "live" or not acting:
        if team:
            st, acting = resolve_team_registry_for_root(
                root, index_home=index_home, team=None,
            )
    if st == "live_unenrolled" and allow_unenrolled_canonical:
        try:
            locked_real = os.path.realpath(locked_path)
            canon_real = os.path.realpath(team_registry_path(root))
        except OSError as exc:
            print(
                f"tap: cannot realpath registry paths for authority check ({exc})",
                file=sys.stderr,
            )
            raise SystemExit(AUTHORITY_REFUSE_EXIT) from exc
        if locked_real == canon_real:
            return
    if st != "live" or not acting:
        print(
            f"tap: acting registry unreachable for root '{root}' "
            f"(status={st}) — refusing membership mutation on '{locked_path}'",
            file=sys.stderr,
        )
        raise SystemExit(AUTHORITY_REFUSE_EXIT)
    try:
        locked_real = os.path.realpath(locked_path)
        acting_real = os.path.realpath(acting)
    except OSError as exc:
        print(
            f"tap: cannot realpath registry paths for authority check ({exc})",
            file=sys.stderr,
        )
        raise SystemExit(AUTHORITY_REFUSE_EXIT) from exc
    if locked_real != acting_real:
        print(
            f"tap: registry authority moved to '{acting}' during flip "
            f"(locked '{locked_path}'); retry",
            file=sys.stderr,
        )
        raise SystemExit(AUTHORITY_RETRY_EXIT)


def seat_has_pane_coords(entry: Mapping[str, Any]) -> bool:
    """True when a seat row still carries pane identity (legacy pane-only proof)."""
    pane = entry.get("pane")
    pane_id = entry.get("pane_id")
    return (isinstance(pane, str) and bool(pane)) or (
        isinstance(pane_id, str) and bool(pane_id)
    )


def seat_is_relaunchable(entry: object, *, explicit_resume: bool = False) -> bool:
    """Shared relaunch predicate for resume membership, synthesize, and migrate
    session-assert (3681754856 / opus 101637). ONE helper — never hand-roll a twin.

    Excluded: crew, explicit poll, and user_removed. Bulk callers also exclude
    operational failures; exact named resume may explicitly retry those retained
    pane seats (pane_gone, session_replaced, repair_failed, restart_failed). ``session_stopped`` and ``restored_from_archive`` (with explicit
    non-poll delivery) remain relaunchable.

    Absent ``delivery`` is NOT a blanket unknown (opus 101637 — stop strips
    delivery from every pane seat it suspends; poll seats never enter stop):
    - absent + ``session_stopped`` → pane (relaunchable; mainline team-up)
    - absent + ``restored_from_archive`` → unknown (excluded; restore once
      stripped poll too — the real poll hazard)
    - absent + pane coordinates + NON-EMPTY ``session`` → pane (WAVE 6.2 /
      sol RED A narrowed: coords prove delivery/pane-ness; session proves
      resumability — both required for relaunch)
    - absent + anything else → unknown (excluded)

    Deliberate: a delivery-less ``pending`` reservation (first-ever launch
    mid-flight — bind never stamped delivery) is excluded by the absent+else
    arm. Coords without ``session`` are delivery-compatible corpses, not
    relaunch members (fable WAVE 6.2 — option b).
    """
    if not isinstance(entry, dict):
        return False
    if entry.get("crew") is True or entry.get("crew") == 1:
        return False
    delivery = entry.get("delivery")
    status = entry.get("status")
    reason = entry.get("status_reason") or ""
    if not isinstance(delivery, str) or not delivery:
        if status == "suspended" and reason == "session_stopped":
            delivery = "pane"  # stop skips poll — stripped row was pane-backed
        elif status == "suspended" and reason == "restored_from_archive":
            return False  # restore-stripped poll hazard
        elif (
            seat_has_pane_coords(entry)
            and isinstance(entry.get("session"), str)
            and entry.get("session")
        ):
            delivery = "pane"  # legacy pane-only WITH session (sol's case)
        else:
            return False  # unknown / coords-only corpse / pending
    if delivery == "poll":
        return False
    if status == "suspended":
        # Named resume is an explicit retry of retained operational failures.
        # Bulk startup keeps its existing exclusions; removal is never a retry.
        if explicit_resume and reason in ("pane_gone", "session_replaced", "repair_failed", "restart_failed"):
            return True
        # Allowlist of suspended reasons that remain relaunchable. Mint site for
        # "resurrectable": launcher cmd_team_resurrect (prime). TWO reason-
        # consulting sites exist in this function — (1) the delivery-inference
        # block above (only when delivery is absent/unusable) and (2) this
        # status gate. A primed husk today carries delivery (or coords+session
        # so inference sets pane) and reaches (2); if prime ever wrote a
        # delivery-less row without coords/session, (1)'s else would refuse
        # before this tuple was consulted.
        if reason in (
            "session_stopped",
            "restored_from_archive",
            "resurrectable",
            "server_restarted",
        ):
            return True
        return False  # pane_gone, user_removed, and other corpses
    return True


def _enrolled_entry_for_root(
    root_real: str,
    index_home: Optional[str] = None,
) -> tuple[str, Optional[str], Optional[dict[str, Any]]]:
    """Find exactly one nonhistorical global entry whose root realpaths to root.

    Returns ``(status, team_name, entry)``:
      ok          — exactly one match; team_name is the global key
      missing     — zero matches
      ambiguous   — more than one match
      invalid     — global registry unreadable
    """
    gpath = global_registry_path(index_home)
    try:
        data = load_state_doc(gpath)
    except Exception:
        return ("invalid", None, None)
    teams = data.get("teams")
    if not isinstance(teams, dict):
        return ("missing", None, None)
    matches: list[tuple[str, dict[str, Any]]] = []
    for name, ent in teams.items():
        if not isinstance(ent, dict):
            continue
        if str(ent.get("state") or "registered") == "historical":
            continue
        ent_root = ent.get("root") or ""
        if not ent_root:
            continue
        try:
            if os.path.realpath(str(ent_root)) == root_real:
                matches.append((str(name), ent))
        except OSError:
            continue
    if len(matches) == 1:
        return ("ok", matches[0][0], matches[0][1])
    if len(matches) > 1:
        return ("ambiguous", None, None)
    return ("missing", None, None)


def enrolled_team_name_for_root(
    root: str,
    *,
    index_home: Optional[str] = None,
) -> tuple[str, str]:
    """Return ``(status, team_name)`` for the global enrollment matching *root*.

    status: ``ok`` (name set) | ``missing`` | ``ambiguous`` | ``invalid``.
    WAVE 6.9 / sol cwd-relocated: cwd identity must use this global key, not
    sibling/bus ``team.name`` content.
    """
    try:
        root_real = os.path.realpath(root)
    except OSError:
        root_real = os.path.abspath(root)
    st, name, _ent = _enrolled_entry_for_root(root_real, index_home)
    if st == "ok" and name:
        return ("ok", name)
    return (st, "")


def resolve_team_registry_for_root(
    root: str,
    *,
    index_home: Optional[str] = None,
    team: Optional[str] = None,
) -> tuple[str, Optional[str]]:
    """Central absent/live/invalid (+ live_unreachable / live_unenrolled) resolution.

    WAVE 6 / 3681979280 — ONE helper for launcher + admin + routing. Never
    select the bus decoy under ``live`` or ``invalid``.

    Live (WAVE 6.2 / sol):
      - explicit ``team`` → ``resolve_team_from_global`` then honor stored
        ``registry_location``
      - no ``team`` → exactly one nonhistorical global entry whose ``root``
        realpaths to the caller root (alias≠basename safe); honor its
        stored location — NEVER basename(root)
      - canonical ``root/.tap/team-registry.json`` alone does NOT authorize
        an unenrolled root and must not override a stored path

    Returns ``(status, path)``:
      absent           — pre-flip; path is bus registry if present else None
      live             — flip live and acting path exists; path set
      live_unreachable — flip live, root IS enrolled, acting missing/unreachable;
                         path is the stored ``registry_location`` when known
                         (tap-w3op / sol #xxx: recovery writers must honor it,
                         never invent a canonical sibling)
      live_unenrolled  — flip live, root has NO global entry (WAVE 6.6 /
                         3682338114); bootstrap+enroll eligible — NOT the same
                         as enrolled-but-missing (fail-closed)
      invalid          — marker present but wrong schema; path None
    """
    state = flip_marker_state(index_home)
    if state == "invalid":
        return ("invalid", None)
    try:
        root_real = os.path.realpath(root)
    except OSError:
        root_real = os.path.abspath(root)
    if state == "live":
        loc = ""
        if team:
            st, _r, loc = resolve_team_from_global(
                global_registry_path(index_home), team,
            )
            if st == "invalid":
                return ("invalid", None)
            if st == "ok" and loc and os.path.isfile(loc):
                return ("live", loc)
            if st in ("ok", "unreachable") and loc:
                return ("live_unreachable", loc)
            # explicit team missing/historical — not inventable from sibling
            return ("live_unreachable", None)
        # Root-only: match enrolled root, not basename (alias≠basename).
        match_st, _name, ent = _enrolled_entry_for_root(root_real, index_home)
        if match_st == "invalid":
            return ("invalid", None)
        if match_st == "ok" and ent is not None:
            loc = str(ent.get("registry_location") or "")
            if loc and os.path.isfile(loc):
                return ("live", loc)
            return ("live_unreachable", loc or None)
        if match_st == "missing":
            # WAVE 6.6 / 3682338114: unenrolled ≠ enrolled-unreachable
            return ("live_unenrolled", None)
        # ambiguous — refuse (not bootstrap-eligible)
        return ("live_unreachable", None)
    for cand in (
        os.path.join(root_real, ".tap", "bus", "registry.json"),
        os.path.join(root_real, "tmp", "tap", "registry.json"),
    ):
        if os.path.isfile(cand):
            return ("absent", cand)
    return ("absent", None)


def team_registry_path(team_dir: str) -> str:
    return os.path.join(team_dir, ".tap", "team-registry.json")


def bus_home(root_path: str) -> str:
    """Bus directory under a team ROOT — byte-identical to lib.sh TAP_HOME order.

    Existing ``<root>/.tap/bus`` (dotdir), else existing ``<root>/tmp/tap``
    (legacy), else default ``<root>/.tap/bus``. Mere ``.tap/`` or
    ``team-registry.json`` must not claim the bus: flip-live migration can
    create ``.tap/`` while leaving a legacy ``tmp/tap`` bus in place.
    Callers that cannot source lib.sh (SessionStart hook) import this instead
    of re-implementing the rule inline.
    """
    dot = os.path.join(root_path, ".tap", "bus")
    legacy = os.path.join(root_path, "tmp", "tap")
    if os.path.isdir(dot):
        return dot
    if os.path.isdir(legacy):
        return legacy
    return dot


def is_session_root(candidate: str, index_home: Optional[str] = None) -> bool:
    """True if *candidate* is a TAP checkout ROOT SessionStart adapters may bind.

    Pre-flip (marker absent): ``.tap/bus/registry.json`` or ``tmp/tap/registry.json``
    exists under the candidate. Flip-live: exactly one live, non-historical
    enrolled team whose ``root`` realpaths to the candidate AND whose stored
    ``registry_location`` is a readable file. Invalid marker → False.

    Mere ``.tap/`` (or ``team-registry.json`` alone) never establishes authority
    — adapters must share this rule so post-flip teams without a bus
    ``registry.json`` still reach ``tap-session-context.sh``.
    """
    if not candidate:
        return False
    try:
        cand_real = os.path.realpath(candidate)
    except Exception:
        return False
    state = flip_marker_state(index_home)
    if state == "invalid":
        return False
    if state == "live":
        try:
            with open(global_registry_path(index_home)) as fh:
                data = json.load(fh)
        except Exception:
            return False
        teams = data.get("teams") or {}
        if not isinstance(teams, dict):
            return False
        matches = 0
        for ent in teams.values():
            if not isinstance(ent, dict):
                continue
            if str(ent.get("state") or "registered") == "historical":
                continue
            ent_root = ent.get("root") or ""
            if not ent_root:
                continue
            try:
                if os.path.realpath(ent_root) != cand_real:
                    continue
            except Exception:
                continue
            loc = ent.get("registry_location") or ""
            if not (isinstance(loc, str) and loc and os.path.isfile(loc)):
                # Enrolled at this ROOT but unreadable — fail closed.
                return False
            matches += 1
        return matches == 1
    # Pre-flip (absent): legacy bus registry file required.
    return (
        os.path.isfile(os.path.join(cand_real, ".tap", "bus", "registry.json"))
        or os.path.isfile(os.path.join(cand_real, "tmp", "tap", "registry.json"))
    )


def walk_up_session_root(start: str, index_home: Optional[str] = None) -> str:
    """Walk up from *start*; return the first ``is_session_root`` hit, or ``\"\"``."""
    if not start:
        return ""
    try:
        d = os.path.realpath(start)
    except Exception:
        return ""
    while d and d != "/":
        if is_session_root(d, index_home):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return ""


def team_history_dir(team_dir: str) -> str:
    return os.path.join(team_dir, ".tap", "team-history")


def mint_instance_id(handle: str) -> str:
    """Hidden per-handle instance id — never a handle encoding (KTD-11)."""
    # Bookkeeping only; display always uses the bare handle.
    return f"{handle}|{secrets.token_hex(8)}"


def ensure_seat_instance(seat: MutableMapping[str, Any], handle: str) -> str:
    """Mint an instance id on a seat row if absent; return the id. Same id on rebind."""
    existing = seat.get("instance")
    if isinstance(existing, str) and existing:
        return existing
    minted = mint_instance_id(handle)
    seat["instance"] = minted
    return minted


def load_state_doc(path: str) -> dict[str, Any]:
    """Load a registry state document; missing file → empty dict."""
    if not os.path.isfile(path):
        return {}
    with open(path) as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"registry state doc is not an object: {path}")
    return data


def supersede_forwarding_aliases(data: Mapping[str, Any]) -> dict[str, Any]:
    """Run the Bun alias policy before saving a seat mutation under its registry lock."""
    payload = data if isinstance(data, dict) else dict(data)
    if not isinstance(payload.get("seat_forwardings"), list) or not payload["seat_forwardings"]:
        return payload
    # Send only the fields the policy needs. Python owns the original document
    # so unrelated metadata (including large integers) never round-trips via JS.
    projection = {
        "seats": {handle: {"instance": row.get("instance")} if isinstance(row, dict) else {}
                  for handle, row in _seat_map(payload).items()},
        "seat_forwardings": payload["seat_forwardings"],
    }
    helper = pathlib.Path(__file__).resolve().parents[3] / "runtime/bun/src/forwarding.ts"
    result = subprocess.run(
        ["bun", str(helper), "supersede"], input=json.dumps(projection),
        text=True, capture_output=True, check=True,
    )
    payload["seat_forwardings"] = json.loads(result.stdout)["seat_forwardings"]
    return payload


def save_state_doc(path: str, data: Mapping[str, Any]) -> None:
    """Atomic write; unknown top-level sections round-trip (Windows-registry framing)."""
    data = supersede_forwarding_aliases(data)
    _verbose_state("state_write", path)
    d = os.path.dirname(path) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tap.")
    try:
        with os.fdopen(fd, "w") as fh:
            json.dump(dict(data), fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def write_tombstone(
    history_dir: str,
    handle: str,
    row: Mapping[str, Any],
    retired_by: str,
) -> str:
    """Append a tombstone under team-history/. Returns the tombstone path.

    Tombstone = full last row + instance id + retired_by. History is never
    written into the registry state document.
    """
    os.makedirs(history_dir, exist_ok=True)
    instance = row.get("instance")
    if not isinstance(instance, str) or not instance:
        raise ValueError("tombstone requires row['instance']")
    ts = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    # One file per retirement event; handle+event keeps restores addressable.
    safe_event = retired_by.replace("/", "_").replace(" ", "_")
    path = os.path.join(history_dir, f"{handle}.{safe_event}.{ts}.json")
    payload = {
        "handle": handle,
        "instance": instance,
        "retired_by": retired_by,
        "retired_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "row": dict(row),
    }
    save_state_doc(path, payload)
    return path


def append_pane_session_log(
    history_dir: str,
    handle: str,
    instance: str,
    *,
    pane: str = "",
    pane_id: str = "",
    harness_session_id: str = "",
    note: str = "",
    timestamp: str = "",
) -> str:
    """Append one lineage line to the per-handle pane/session log (append-only)."""
    os.makedirs(history_dir, exist_ok=True)
    log_path = os.path.join(history_dir, f"{handle}.lineage.jsonl")
    entry = {
        "ts": timestamp or datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z"),
        "instance": instance,
        "pane": pane,
        "pane_id": pane_id,
        "harness_session_id": harness_session_id,
        "note": note,
    }
    with open(log_path, "a") as fh:
        fh.write(json.dumps(entry, sort_keys=True) + "\n")
    return log_path


def resolve_team_from_global(
    global_path: str,
    team: str,
) -> tuple[str, str, str]:
    """Return (status, root_or_detail, registry_location).

    status:
      ok            — registered, location present (may be unreachable — caller checks)
      historical    — team in global history / state=historical
      missing       — no such team
      unreachable   — registered but registry_location path missing (NOT pruned)
      invalid       — unreadable global registry
    """
    try:
        data = load_state_doc(global_path)
    except Exception as exc:
        return ("invalid", str(exc), "")
    teams = data.get("teams")
    if not isinstance(teams, dict):
        return ("missing", "", "")
    ent = teams.get(team)
    if not isinstance(ent, dict):
        return ("missing", "", "")
    state = str(ent.get("state") or "registered")
    root = str(ent.get("root") or "")
    loc = str(ent.get("registry_location") or "")
    if state == "historical":
        return ("historical", root, loc)
    if not loc:
        return ("missing", root, "")
    if not os.path.exists(loc):
        return ("unreachable", root, loc)
    return ("ok", root, loc)


def empty_global_registry(*, migrated_at: str = "", backups: Optional[dict] = None) -> dict[str, Any]:
    return {
        "schema": SCHEMA,
        "migrated": {
            "at": migrated_at or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "backups": backups or {},
        },
        "teams": {},
    }


def empty_team_registry(*, name: str = "", worktree_root: str = "") -> dict[str, Any]:
    return {
        "schema": SCHEMA,
        "team": {
            "schema_version": "1",
            "name": name,
            "worktree_root": worktree_root,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
        "seats": {},
    }


def _seat_map(data: Mapping[str, Any]) -> dict[str, Any]:
    seats = data.get("seats")
    if isinstance(seats, dict):
        return seats
    agents = data.get("agents")
    if isinstance(agents, dict):
        return agents
    return {}


def seat_axis(data: Mapping[str, Any]) -> Optional[dict[str, Any]]:
    """Return the seats|agents map when that axis is present; else None.

    Distinguishes valid-empty ``{}`` (axis key is a dict) from missing axis
    (neither seats nor agents is a dict). Completion uses this tri-state so a
    resolved-empty registry does not fall through to the cwd-all handle list.
    """
    seats = data.get("seats")
    if isinstance(seats, dict):
        return seats
    agents = data.get("agents")
    if isinstance(agents, dict):
        return agents
    return None


def seat_store(data: MutableMapping[str, Any]) -> tuple[str, dict[str, Any]]:
    """Return (storage_key, mutable map) for the live seats|agents axis.

    Prefer seats when present (post-flip team-registry). Otherwise ensure an
    agents map exists for pre-flip bus registries. Never invent agents beside
    a seats-only document.
    """
    seats = data.get("seats")
    if isinstance(seats, dict):
        return "seats", seats
    agents = data.get("agents")
    if not isinstance(agents, dict):
        agents = {}
        data["agents"] = agents
    return "agents", agents


def current_instance(registry_path: str, handle: str) -> str:
    """Return the current seat's instance id, or '' if absent/unbound."""
    try:
        data = load_state_doc(registry_path)
    except Exception:
        return ""
    ent = _seat_map(data).get(handle)
    if not isinstance(ent, dict):
        return ""
    inst = ent.get("instance")
    return inst if isinstance(inst, str) else ""


def list_handle_history(history_dir: str, handle: str) -> list[dict[str, Any]]:
    """Return tombstones for <handle>, most-recent first (by retired_at / mtime)."""
    if not os.path.isdir(history_dir):
        return []
    rows: list[dict[str, Any]] = []
    prefix = f"{handle}."
    for name in os.listdir(history_dir):
        if not name.startswith(prefix) or not name.endswith(".json"):
            continue
        if ".lineage." in name:
            continue
        path = os.path.join(history_dir, name)
        try:
            data = load_state_doc(path)
        except Exception:
            continue
        if data.get("handle") != handle:
            continue
        data["_path"] = path
        rows.append(data)
    rows.sort(key=lambda r: str(r.get("retired_at") or ""), reverse=True)
    return rows


def mint_event_id(prefix: str = "evt") -> str:
    return f"{prefix}-{secrets.token_hex(6)}"
