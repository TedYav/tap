#!/usr/bin/env bash
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
python3 - "$ROOT" <<'PYTEST'
import json, os, subprocess, sys, tempfile
from pathlib import Path
root=Path(sys.argv[1])
script=r'''
set -euo pipefail
. "$1/skills/tap/scripts/lib.sh"
shift
tap_spool_home_authorized_or_warn() { return 0; }
tap_spool_pane_ready() { printf ready; }
tap_bound_pane_identity_state() { printf match; }
tap_acting_registry() { printf "%s/registry.json" "$TAP_HOME"; }
tap_spool_team_name() { printf fixture; }
tap_pane_harness_command() { printf codex; }
tmux() { printf codex; }
tap_debug_spool_submit() { echo digest >> "$TAP_HOME/recipient-effects"; return 5; }
# The sender-group claim (`<digest>-<sender>-delivery-unconfirmed`) is taken after
# grouping and before the notice decision (which runs natively, spool-deadline.ts):
# a receipt planted there lands in that window. Every other claim — the members'
# own, taken before the attempt — is left alone.
eval "$(declare -f tap_spool_claim_acquire | sed '1s/tap_spool_claim_acquire/real_claim_acquire/')"
tap_spool_claim_acquire() {
  case "$1" in *-delivery-unconfirmed)
    # A read observed after grouping must not hide an unread sibling.
    if [ "$SCENARIO" = read-racing ]; then
      printf '{"id":"member-00","by":"peer"}' > "$TAP_RECEIPTS/member-00.read"
    fi
    # Settlement after grouping must not suppress another member's notice.
    [ "$SCENARIO" != racing ] || printf '{}' > "$TAP_RECEIPTS/member-00.done"
    ;;
  esac
  real_claim_acquire "$@"
}
if [ "$REENTER" = 1 ]; then
  digest="$1"; shift
  tap_spool_notify_digest_senders "$digest" peer "$TAP_HOME/registry.json" "$@"
else
  rc=0
  tap_spool_digest_inject "$TAP_HOME/registry.json" fixture peer sess:0.0 '%401' "$@" || rc=$?
  [ "$rc" = 5 ] || { echo "unexpected digest result $rc"; exit 1; }
fi
'''
with tempfile.TemporaryDirectory() as temp:
    for scenario,count,want in [('one',20,1),('two',20,2),('absent',2,1),('ordinary',2,0),('racing',2,1),('all-read',2,0),('part-read',2,1),('read-racing',2,1)]:
        bus=Path(temp)/scenario
        for folder in ['spool','payloads','receipts']: (bus/folder).mkdir(parents=True)
        # The sender notice runs natively end to end (spool-deadline.ts → notice-submit.ts):
        # each registered sender's pane does not exist on the runner's private tmux
        # server, so every wake is honestly unconfirmed and leaves its attempt
        # evidence (`payloads/<notice>.attempts`, exclusive-create) — the pane attempt
        # count read below. An unregistered sender ('absent') gets a durable notice
        # and no attempt.
        seats={'peer':{'status':'active','pane':'sess:0.0','pane_id':'%401','harness':'codex'}}
        if scenario!='absent':
            seats['alice']={'status':'active','pane':'sess:0.1','pane_id':'%402','harness':'codex'}
            seats['bob']={'status':'active','pane':'sess:0.2','pane_id':'%403','harness':'codex'}
        reg=bus/'registry.json'; reg.write_text(json.dumps({'team':{'name':'fixture'},'agents':seats}))
        ids=[f'member-{i:02}' for i in range(count)]
        senders={ident:('bob' if scenario=='two' and i>=10 else 'alice') for i,ident in enumerate(ids)}
        originals={}
        for ident in ids:
            raw=f'---\nid: {ident}\nfrom: {senders[ident]}\nto: peer\nkind: discuss\nreply: settle-only\npath: {bus}/payloads/{ident}.md\n---\noriginal {ident}\n'
            originals[ident]=raw
            (bus/'spool'/f'{ident}.md').write_text(raw)
            (bus/'spool'/f'{ident}.meta.json').write_text(json.dumps({'id':ident,'target':'peer','target_registry':str(reg),'to_team':'fixture','policy':'standard' if scenario=='ordinary' else 'autosettle','first_spooled_epoch':1,'deadline_epoch':1}))
        if scenario in ('all-read','part-read'):
            for ident in (ids if scenario=='all-read' else ids[:1]):
                (bus/'receipts'/f'{ident}.read').write_text(json.dumps({'id':ident,'by':'peer'}))
        env={**os.environ,'TAP_HOME':str(bus),'TAP_INDEX_HOME':str(bus/'index'),'TAP_SPOOL_DISABLE_DELIVERER':'1','SCENARIO':scenario,'REENTER':'0'}
        def run(args):
            result=subprocess.run(['bash','-c',script,'_',str(root),*args],env=env,text=True,capture_output=True)
            assert result.returncode==0,(scenario,result.stdout,result.stderr)
        run(ids)
        notices=[p for p in (bus/'payloads').glob('*.md') if '\nkind: delivery-failed\n' in p.read_text()]
        assert len(notices)==want,(scenario,'notice count',len(notices),want)
        def attempts(): return {p.name:(p.read_bytes(),p.stat().st_mtime_ns) for p in (bus/'payloads').glob('*.attempts')}
        assert set(attempts())==(set() if scenario=='absent' else {n.name[:-3]+'.attempts' for n in notices}),(scenario,'pane attempts',sorted(attempts()))
        assert (bus/'recipient-effects').read_text().splitlines()==['digest']
        for ident in ids:
            assert (bus/'payloads'/f'{ident}.md').read_text()==originals[ident]
            assert (bus/'receipts'/f'{ident}.done').exists()==(scenario=='racing' and ident=='member-00')
            assert not (bus/'receipts'/f'{ident}.sent').exists()
        for notice in notices:
            body=notice.read_text()
            sender=next(line[4:] for line in body.splitlines() if line.startswith('to: '))
            for ident in ids:
                if scenario=='part-read' and ident==ids[0]:
                    assert str(bus/'payloads'/f'{ident}.md') not in body
                elif senders[ident]==sender: assert str(bus/'payloads'/f'{ident}.md') in body,(scenario,'missing member',ident)
            assert 'DELIVERY UNCONFIRMED:' in body and 'automatic retry' in body.lower()
        if scenario!='ordinary':
            index=next((bus/'spool'/'digests').glob('*.json'))
            snapshot={p.name:(p.read_bytes(),p.stat().st_mtime_ns) for p in notices}
            before=attempts()
            # A settled first member changes the representative, not notice identity.
            (bus/'receipts'/f'{ids[0]}.done').write_text('{}')
            env['REENTER']='1'; run([index.stem,*ids])
            assert {p.name for p in (bus/'payloads').glob('*.md') if '\nkind: delivery-failed\n' in p.read_text()}==set(snapshot)
            # Once every member is known delivered/settled, no notice is recreated.
            for ident in ids: (bus/'receipts'/f'{ident}.sent').write_text('{}')
            run([index.stem,*ids])
            assert {p.name:(p.read_bytes(),p.stat().st_mtime_ns) for p in notices}==snapshot
            assert attempts()==before,(scenario,'repeated possible effect')
print('digest sender notices: 20->1, two senders->2, unavailable sender durable, restart no repeat, ordinary eligibility unchanged: ok')
PYTEST
