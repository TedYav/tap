#!/usr/bin/env bash
# boot-session-oracle.test.sh — the boot identity must not move with wall-clock slew.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
mkdir -p "$WORK/bin"

cat > "$WORK/bin/sysctl" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
case "${2:-}" in
  kern.bootsessionuuid)
    printf '7D669766-8A0C-4A4D-9B80-A2476810F46C\n'
    ;;
  kern.boottime)
    count=0
    [ ! -f "$BOOT_PROBE_COUNT" ] || count="$(cat "$BOOT_PROBE_COUNT")"
    count=$((count + 1))
    printf '%s\n' "$count" > "$BOOT_PROBE_COUNT"
    if [ "$BOOT_PROBE_MODE" = stable ] || [ "$count" -eq 1 ]; then
      printf '{ sec = 1785910737, usec = 900000 } Tue Aug  5 00:00:00 2026\n'
    else
      printf '{ sec = 1785910738, usec = 100000 } Tue Aug  5 00:00:00 2026\n'
    fi
    ;;
  *) exit 1 ;;
esac
SH
chmod +x "$WORK/bin/sysctl"

export PATH="$WORK/bin:$PATH" BOOT_PROBE_COUNT="$WORK/probe-count"
unset TAP_BOOT_ID TAP_BOOT_ID_LEGACY
# shellcheck source=skills/tap/scripts/lib.sh
. "$ROOT/skills/tap/scripts/lib.sh"

derive_twice() {
  local first second
  rm -f "$BOOT_PROBE_COUNT"
  first="$(bash -c '. "$1"; tap_boot_id' _ "$ROOT/skills/tap/scripts/lib.sh")"
  second="$(bash -c '. "$1"; tap_boot_id' _ "$ROOT/skills/tap/scripts/lib.sh")"
  [ "$first" = "$second" ] || {
    echo "boot-session-oracle: derivation moved: $first -> $second" >&2
    return 1
  }
  printf '%s' "$first"
}

export BOOT_PROBE_MODE=stable
stable="$(derive_twice)"
[ -n "$stable" ] || { echo "boot-session-oracle: stable arm returned empty" >&2; exit 1; }

# This is the regression arm: the pre-hotfix kern.boottime oracle returns two
# different identities here. A boot-session UUID remains identical because the
# one-second wall-clock correction is not part of its identity.
export BOOT_PROBE_MODE=slew
slewed="$(derive_twice)"
[[ "$slewed" == bootuuid:* ]] || {
  echo "boot-session-oracle: preferred macOS oracle was not bootsessionuuid: $slewed" >&2
  exit 1
}

export TAP_BOOT_ID_LEGACY=boot:1785910738
tap_boot_ids_match boot:1785910737 "$slewed" \
  || { echo "boot-session-oracle: legacy one-second slew was not accepted" >&2; exit 1; }
if tap_boot_ids_match boot:1785910700 "$slewed"; then
  echo "boot-session-oracle: real legacy mismatch was accepted" >&2
  exit 1
fi
if tap_boot_ids_match bootuuid:11111111-1111-4111-8111-111111111111 "$slewed"; then
  echo "boot-session-oracle: different boot-session UUID was accepted" >&2
  exit 1
fi

echo "boot-session-oracle: stable + slew + migration boundaries: ok"
