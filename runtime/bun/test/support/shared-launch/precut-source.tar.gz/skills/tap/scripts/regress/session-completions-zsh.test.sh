#!/usr/bin/env bash
# session-completions-zsh.test.sh — REAL zsh completion behavior for `tap session`
# (tap-kicy, sol merge-gate F2+F3). Drives an interactive zsh through zpty and
# asserts, via true completion state (not a mocked _arguments), that:
#   F3 — only the immediate operand slot completes; a harness/handle is never
#        re-offered at a later position;
#   F2 — `repair` offers no session handles (it is live-only, dropped from
#        completion).
# Requires zsh + the zsh/zpty module and an interactive-capable environment. It
# SKIPS cleanly (exit 0) if any of those are unavailable or the pty won't sync —
# it must never flake the gate — and FAILS only on a genuine re-offer / repair
# handle. sol re-verifies the same properties with her own harness.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
SESSION="$ROOT/skills/tap/scripts/session"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

command -v zsh >/dev/null 2>&1 || { echo "SMOKE-SKIP: session-completions-zsh: zsh absent; real completion proof not run"; exit 0; }

${TAP_PYTHON:-python3} -B "$SESSION/launcher.py" completion zsh > "$WORK/tc.zsh"
mkdir -p "$WORK/bin"
printf '#!/usr/bin/env bash\n[ "$1" = session ] && [ "$2" = complete ] && [ "$3" = handles ] && { printf "alice\\nbob\\n"; exit 0; }\nexit 0\n' > "$WORK/bin/tap"
chmod +x "$WORK/bin/tap"

RZ="$WORK/rz.zsh"
cat > "$RZ" <<ZEOF
emulate -L zsh
zmodload zsh/zpty 2>/dev/null || { print "SKIP-ENV"; exit 0 }
cat > "$WORK/rinit.zsh" <<'INIT'
export PATH="$WORK/bin:$PATH"
export COLUMNS=250 LINES=60
autoload -Uz compinit; compinit -u
zstyle ':completion:*' menu no
unset zle_bracketed_paste
setopt nolistbeep nomenucomplete noautomenu
PROMPT='RDY>'
source "$WORK/tc.zsh"
INIT
zpty zt 'zsh -df -i' || { print "SKIP-ENV"; exit 0 }
sync() { local o='' c; integer deadline=\$((SECONDS + 300)); while (( SECONDS < deadline )); do if zpty -r -t zt c 2>/dev/null; then o+=\$c; [[ \$o == *"RDY>"* ]] && return 0; else sleep 0.02; fi; done; return 1 }
zpty -w zt "source $WORK/rinit.zsh"; sync || { print "SKIP-ENV"; zpty -d zt; exit 0 }
netcands() {
  local buf="\$1"
  zpty -n -w zt "\$buf"\$'\t\t'
  # Printable input is processed only after both completion keystrokes. Seeing
  # it echoed therefore proves the candidate list has rendered.
  zpty -n -w zt '__TAP_COMPLETION_DONE__'
  local out='' c; integer deadline=\$((SECONDS + 300))
  while (( SECONDS < deadline )); do
    if zpty -r -t zt c 2>/dev/null; then
      out+=\$c
      [[ \$out == *"__TAP_COMPLETION_DONE__"* ]] && break
    else
      sleep 0.02
    fi
  done
  [[ \$out == *"__TAP_COMPLETION_DONE__"* ]] || { print "FAIL: completion exceeded the 300s render deadman"; return 1 }
  zpty -n -w zt \$'\C-c'; sync
  local -a grepped bufwords net
  grepped=(\${(f)"\$(print -r -- "\$out" | tr -d '\r' | sed 's/\x1b\[[0-9;?]*[a-zA-Z]//g;s/\x1b[=>M]//g' | grep -aoE 'claude|codex|cursor|hermes|opencode|alice|bob|launch|resume|restart|repair|list|prune' | sort -u)"})
  bufwords=(\${=buf})
  for t in \$grepped; do (( \${bufwords[(I)\$t]} )) || net+=\$t; done
  print -r -- "\${(j: :)\${(o)net}}"
}
fail=0
has() { [[ " \$1 " == *" \$2 "* ]] || { print "FAIL: \$3 — expected '\$2', net=[\$1]"; fail=1 } }
absent() { [[ " \$1 " != *" \$2 "* ]] || { print "FAIL: \$3 — must NOT offer '\$2', net=[\$1]"; fail=1 } }
n="\$(netcands 'tap up ')";                    has "\$n" alice "up pos2"; has "\$n" bob "up pos2"
n="\$(netcands 'tap down ')";                  has "\$n" alice "down pos2"
n="\$(netcands 'tap up alice ')";              absent "\$n" bob "up pos3"
n="\$(netcands 'tap down alice ')";            absent "\$n" bob "down pos3"
n="\$(netcands 'tap session launch ')";        has "\$n" claude "launch pos3"; has "\$n" opencode "launch pos3"
n="\$(netcands 'tap session launch claude ')";  absent "\$n" codex "launch pos4 F3"; absent "\$n" cursor "launch pos4 F3"
n="\$(netcands 'tap session resume ')";         has "\$n" alice "resume pos3"; has "\$n" bob "resume pos3"
n="\$(netcands 'tap session resume alice ')";   absent "\$n" bob "resume pos4 F3"
n="\$(netcands 'tap session restart ')";        has "\$n" alice "restart pos3"
n="\$(netcands 'tap session repair ')";         absent "\$n" alice "repair F2"; absent "\$n" bob "repair F2"
zpty -d zt
(( fail )) && exit 1 || print "REAL-ZSH-OK"
ZEOF

out="$(zsh "$RZ" 2>&1 || true)"
if grep -q 'SKIP-ENV' <<<"$out"; then
  echo "SMOKE-SKIP: session-completions-zsh: interactive zpty unavailable; real completion proof not run"
  exit 0
fi
if grep -q 'REAL-ZSH-OK' <<<"$out"; then
  echo "session-completions-zsh: real zsh — operand position-guard (F3) + repair-not-completed (F2): ok"
  exit 0
fi
echo "session-completions-zsh: real-zsh assertion failed:" >&2
printf '%s\n' "$out" | grep -E 'FAIL:' >&2 || printf '%s\n' "$out" >&2
exit 1
