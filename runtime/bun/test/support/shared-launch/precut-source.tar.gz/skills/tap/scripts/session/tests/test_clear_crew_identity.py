"""A shared tmux session must never substitute the parent's harness recipe."""
from types import SimpleNamespace
import pytest
import launcher


@pytest.fixture
def crew(tmp_path, monkeypatch):
    monkeypatch.setenv('TAP_INDEX_HOME', str(tmp_path / 'index'))
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(launcher, 'root_for_cwd', lambda cwd: str(tmp_path))
    monkeypatch.setattr(launcher, 'refuse_if_team_reset_fenced', lambda verb: None)
    row = {'session': 'team/parent', 'harness': 'claude', 'pane_id': '%2',
           'crew': True, 'model': 'sonnet', 'registered_from_worktree': str(tmp_path)}
    parent = launcher.SessionRecord(name='team/parent', harness='codex',
                                    cwd=str(tmp_path), base='team', tag='parent')
    monkeypatch.setattr(launcher, 'clear_target_pane', lambda *args: ('%2', row))
    monkeypatch.setattr(launcher, 'registry_session_state', lambda cwd: launcher.Manifest(sessions=[parent]))
    calls = []
    monkeypatch.setattr(launcher, 'replace_harness_in_pane', lambda **kw: calls.append(kw) or 0)
    monkeypatch.setattr(launcher, '_team_bus_home', lambda: tmp_path / 'bus')
    return row, calls


def test_clear_uses_crew_row_not_parent(crew):
    row, calls = crew
    assert launcher.cmd_clear(SimpleNamespace(seat='review', message=None, dry_run=False)) == 0
    call = calls[0]
    assert call['record'].harness == 'claude'
    assert call['invocation'].argv[0] == 'claude'
    assert 'sonnet' in call['invocation'].argv
    assert call['pane_id'] == '%2'
    assert '(claude)' in call['success']('%2')


@pytest.mark.parametrize('harness', [None, '', 'unknown'])
def test_clear_unknown_harness_refuses_before_effect(crew, harness):
    row, calls = crew
    row['harness'] = harness
    with pytest.raises(launcher.LauncherError, match='harness'):
        launcher.cmd_clear(SimpleNamespace(seat='review', message=None, dry_run=False))
    assert calls == []
