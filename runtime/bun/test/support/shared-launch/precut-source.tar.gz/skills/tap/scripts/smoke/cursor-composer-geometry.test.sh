#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
. "$ROOT/skills/tap/scripts/smoke/sandbox-pins.sh"
. "$ROOT/skills/tap/scripts/lib.sh"
fixture="$ROOT/skills/tap/scripts/smoke/fixtures/submit-verify/cursor-red-box.ansi"
[ -z "$(tap_composer_input cursor < "$fixture")" ] || { echo 'cursor-geometry: tinted placeholder was not empty'; exit 1; }
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
expected='[[TAP v0.23 note geometry-owned]]'
python3 - "$fixture" "$WORK" "$expected" <<'PY'
import re,sys
from pathlib import Path
source=Path(sys.argv[1]).read_text(); work=Path(sys.argv[2]); expected=sys.argv[3]
ansi=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
lines=source.splitlines()
for i,line in enumerate(lines):
    if re.match(r'^\s*→',ansi.sub('',line)):
        lines[i]=' \x1b[48;2;119;15;15m → '+expected+'\x1b[0m'
        break
frame='\n'.join(lines)+'\n'
(work/'sentinel').write_text(frame)
(work/'dark').write_text(frame.replace('48;2;119;15;15','48;2;32;32;32'))
(work/'mixed').write_text(frame.replace(expected,expected+' human draft'))
(work/'unbounded').write_text('\n'.join(line for line in lines if '▀▀▀▀▀▀▀▀▀▀' not in line))
PY
if tap_composer_input cursor < "$WORK/unbounded"; then echo 'cursor-geometry: missing border accepted'; exit 1; fi
echo 'cursor-geometry: strict pre-inject geometry and post-inject visible-wire containment: ok'
