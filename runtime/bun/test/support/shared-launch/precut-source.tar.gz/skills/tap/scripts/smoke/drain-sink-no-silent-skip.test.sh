#!/usr/bin/env bash
# tap-6vwz: NO STATE MAY EXIST THAT EVERY DRAIN SKIPS WHILE NOBODY HAS BEEN TOLD.
#
# A spool entry marked with a terminal reason string is excluded at BOTH drain
# gates — Phase A never groups it into a digest, Phase B's `continue` lands
# BEFORE the escalation branch — so it never delivers, never escalates, and
# never ages out. Three live instances were found this way, one of them 35 days
# old; the only surface that named any of them was a human running `tap
# outstanding` for an unrelated reason.
#
# This asserts the PROPERTY, not one string's route to it: whatever excludes an
# entry from every delivery path must carry an expiry that ends in a disposition.
# The mark is written from FOUR sites (lib.sh:1590 direct in the park path,
# :2007 and :2019 inside tap_spool_redeliver, :3130 in the drain), which is why
# the escape route is asserted at the READ site — a per-writer fix is one fix
# per writer plus one bug per writer nobody enumerated.
#
# The substrate is SYNTHETIC on purpose. The historical specimens are one-shot:
# verifying end-to-end delivery consumes them. This manufactures the state, so
# it is repeatable and reaches no live pane.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

export TAP_SPOOL_DISABLE_DELIVERER=1 TAP_TUI_SETTLE_SCALE=0.1

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
export TAP_HOME="$WORK/bus"
export TAP_SERVER_EPOCH="srv:900:100" TAP_BOOT_ID="boot:1"
mkdir -p "$TAP_HOME/payloads" "$TAP_HOME/receipts" "$TAP_HOME/spool"
# Source AFTER TAP_HOME so TAP_SPOOL binds the fixture bus (lib.sh freezes it).
# shellcheck source=../lib.sh
. "$ROOT/skills/tap/scripts/lib.sh"
# tap-ncd4: this fixture drives tap_spool_drain_once directly (never through
# the real `tap` CLI), so nothing stamps this TAP_HOME as authorized the way a
# real send would. Bootstrap it the same way production does; this fixture's
# own pane effects only ever reach the fake tmux stub below, never a live pane.
tap_ensure_dirs
FAKE_BIN="$WORK/bin"
mkdir -p "$FAKE_BIN" "$WORK/tmux"
fail() { echo "drain-sink-no-silent-skip: $*" >&2; exit 1; }

cat >"$FAKE_BIN/tmux" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
state="${FAKE_TMUX_STATE:?}"; mkdir -p "$state"
cmd="${1:-}"; shift || true
case "$cmd" in
  list-sessions)
    printf 'taptest\t900:100\n'
    ;;
  list-panes)
    printf 'taptest\ttaptest:0.0\t%%811\tcodex\t5811\t900:100\n'
    printf 'taptest\ttaptest:0.1\t%%812\tcodex\t5812\t900:100\n'
    ;;
  display-message)
    target=""; fmt=""
    while [ "$#" -gt 0 ]; do
      case "$1" in -p) shift ;; -t) target="${2:-}"; shift 2 ;; *) fmt="$1"; shift ;; esac
    done
    case "$fmt" in
      *pane_id*)              [ "$target" = "taptest:0.0" ] && echo '%811' || echo '%812' ;;
      *pane_pid*)             echo "2147483646" ;;
      *pane_in_mode*)         echo "0" ;;
      *pane_current_command*) echo "codex" ;;
      *)                      echo "" ;;
    esac ;;
  capture-pane)
    if [ -f "$state/input" ]; then printf '› %s\n' "$(cat "$state/input")"
    else printf '› \n'; fi ;;
  send-keys)
    if [ "${1:-}" = "-t" ]; then shift 2; fi
    if [ "${1:-}" = "-l" ]; then
      shift; [ "${1:-}" = "--" ] && shift
      printf '%s' "${1:-}" >"$state/input"; exit 0
    fi
    if [ "${1:-}" = "Enter" ]; then rm -f "$state/input"; exit 0; fi ;;
esac
EOF
chmod +x "$FAKE_BIN/tmux"
export PATH="$FAKE_BIN:$PATH" FAKE_TMUX_STATE="$WORK/tmux" TMUX="/fake/socket"

cat >"$TAP_HOME/registry.json" <<'JSON'
{
  "team": {"name": "testteam"},
  "agents": {
    "sender": {"session": "taptest", "pane": "taptest:0.0", "pane_id": "%811", "status": "active", "harness": "codex", "server_epoch": "srv:900:100", "boot_id": "boot:1"},
    "peer": {"session": "taptest", "pane": "taptest:0.1", "pane_id": "%812", "status": "active", "harness": "codex", "server_epoch": "srv:900:100", "boot_id": "boot:1"}
  }
}
JSON

plant() { # <id> <first_epoch> <escalated:0|1> [<reason>] [<reason_class>]
  local id="$1" epoch="$2" esc="$3" reason="${4:-pending-input}" rclass="${5:-busy}" reg="$TAP_HOME/registry.json"
  cat >"$TAP_HOME/spool/${id}.md" <<EOF
---
id: $id
from: sender
to: peer
kind: discuss
path: $TAP_HOME/spool/${id}.md
reply: settle-only
---
body $id
EOF
  python3 -B - "$TAP_HOME/spool/${id}.meta.json" "$id" "$epoch" "$esc" "$reg" "$reason" "$rclass" <<'PY'
import json, sys
path, ident, epoch, esc, reg, reason, rclass = sys.argv[1:8]
meta = {
  "id": ident,
  "target": "peer",
  "team": "testteam",
  "reason": reason,
  "reason_class": rclass,
  "attempts": 0,
  "first_spooled": "t",
  "first_spooled_epoch": int(epoch),
  "pane": "taptest:0.1",
  "pane_id": "%812",
  "to_team": "",
  "target_registry": reg,
  "policy": "standard",
  "deadline_epoch": int(epoch) + 60,
}
if esc == "1":
  meta["escalated_at"] = "2026-01-01T00:00:00Z"
json.dump(meta, open(path, "w"), indent=2, sort_keys=True)
open(path, "a").write("\n")
PY
}


now=2000000
old=$((now - 100000))   # ~28h in the spool: far past any expiry a fix would set

# ── 1. THE INVARIANT: a terminally-marked entry must not sit forever ──────────
# Not "must deliver" and not "must escalate" — either is a disposition. What is
# forbidden is the third outcome: still spooled, still unmarked-for-anyone,
# nobody told. Asserting the property this way keeps the test honest about a
# fix shape it does not get to choose.
plant sunk-entry "$old" 0 legacy_meta_no_binding safety_gate
tap_spool_drain_once "$now" 8 >/dev/null 2>&1 || true

meta="$TAP_HOME/spool/sunk-entry.meta.json"
if [ -f "$meta" ]; then
  disposition="$(python3 -B -c '
import json,sys
m=json.load(open(sys.argv[1]))
# Any of these means SOMEONE was told / the entry reached a terminal state.
for k in ("escalated_at","unrouted_at","disposition","notified_at"):
    if m.get(k): print(k); break
else: print("")
' "$meta")"
  [ -n "$disposition" ] || fail \
    "SINK: sunk-entry is still spooled 28h past its deadline with no disposition — every drain skipped it and nobody was told (this is tap-6vwz)"
fi
echo "drain-sink-no-silent-skip: 1/8 — a terminally-marked entry reaches a disposition: ok"

# ── 2. The property is not keyed to one string — via a DIFFERENT real route ──
# FIRST VERSION OF THIS ARM WAS A PLACEBO, and mutation testing caught it: it
# planted a made-up reason on an entry with complete binding, so NONE of the
# branch's disjuncts fired, the entry took the ordinary delivery path, and the
# arm passed no matter what the fix did. Keying the escape route to the one
# string did not red it. An arm that cannot fail is worse than no arm — it
# reports coverage of the exact property it does not test.
#
# This drives the entry in through a different disjunct instead: a registry that
# was readable at park and is GONE now (`tap_registry_matches_team` fails its -f
# test, so :2007 and this gate both read it as a binding violation). That is a
# real, live route into the sink — an entry with nothing wrong with it, sunk by a
# file that moved — and it reaches the branch without the terminal string, which
# is exactly what "not keyed to one string" has to mean.
plant sunk-future "$old" 0 pending-input busy
python3 -B - "$TAP_HOME/spool/sunk-future.meta.json" <<'PYMETA'
import json, sys
p = sys.argv[1]; m = json.load(open(p))
m["to_team"] = "testteam"                      # non-empty: no short-circuit
m["target_registry"] = "/nonexistent/registry-that-moved.json"
json.dump(m, open(p, "w"), indent=2, sort_keys=True)
PYMETA
tap_spool_drain_once "$now" 8 >/dev/null 2>&1 || true
meta2="$TAP_HOME/spool/sunk-future.meta.json"
if [ -f "$meta2" ]; then
  d2="$(python3 -B -c '
import json,sys
m=json.load(open(sys.argv[1]))
for k in ("escalated_at","unrouted_at","disposition","notified_at"):
    if m.get(k): print(k); break
else: print("")
' "$meta2")"
  [ -n "$d2" ] || fail \
    "SINK: a DIFFERENT terminal reason sat undisposed — the fix special-cased one string instead of asserting the property"
fi
echo "drain-sink-no-silent-skip: 2/8 — the escape route is not keyed to one reason string: ok"

# ── 3. The disposition must not claim an observation nobody made ─────────────
# A sunk entry was never ATTEMPTED — it was excluded before any delivery path.
# Reporting it as a failed delivery asserts the courier tried and failed, which
# it did not, and sends the sender to debug a transport that is working. The
# recipient here is reachable in this fixture, which is exactly the live case:
# specimen 1's recipient answered three sends the same night it was found.
if [ -f "$meta" ]; then
  attempts="$(python3 -B -c 'import json,sys; print(json.load(open(sys.argv[1])).get("attempts") or 0)' "$meta")"
  [ "$attempts" = 0 ] || fail \
    "a sunk entry reports attempts=$attempts — it was excluded before any delivery path, so a nonzero count claims an attempt nobody made"
fi
echo "drain-sink-no-silent-skip: 3/8 — the disposition claims no attempt that never happened: ok"


# ── 4. A SETTLED sunk entry is reconciled, not disposed (fable's bar) ─────────
# The sharpest fact from the incident: gemini received AND settled specimen 1,
# and the entry's meta was UNCHANGED — reason still terminal, attempts 0, mtime
# untouched. A sunk entry is causally disconnected from whether delivery
# happened, because both drain phases check `tap_is_done` BELOW their
# terminal-reason skip. So the entry can be settled by any route and no drain
# ever reaps it.
#
# That makes "did it deliver?" the wrong question for this bug. A fix that
# delivers without reconciling leaves the same sink with a delivered message
# inside it — and would then tell the sender it was never routed, which is now
# false. This asserts the ENTRY's post-settlement state, not the injection.
plant sunk-settled "$old" 0 legacy_meta_no_binding safety_gate
: > "$TAP_HOME/receipts/sunk-settled.done"
tap_spool_drain_once "$now" 8 >/dev/null 2>&1 || true
[ ! -f "$TAP_HOME/spool/sunk-settled.meta.json" ] || fail \
  "a SETTLED sunk entry is still in the spool — settlement never reconciles it, so the sink outlives the delivery"
[ ! -f "$TAP_HOME/spool/sunk-settled.md" ] || fail \
  "a settled sunk entry's payload is still spooled after reconciliation"
echo "drain-sink-no-silent-skip: 4/8 — a settled sunk entry is reaped, not left in the sink: ok"


# ── 5. The mark preserves the diagnosis it displaces (tap-6vwz half ii) ───────
# The live specimen is UNEXPLAINED: four writers were tested against its stored
# fields and none of them should have marked it — and the evidence that would
# have named the fifth path was overwritten by the mark itself, which rewrote
# `reason`/`reason_class` in place. `registry-events.log` held zero lines for
# the id or the string machine-wide, because the vocabulary had no action for
# the transition. Neither the entry nor the log could answer the question.
#
# This arm does not help that specimen — that evidence is already gone. It is
# what makes the NEXT one answerable, which is the whole reason half (ii) is
# load-bearing rather than supporting.
plant sunk-audit "$old" 0 pending-input busy
tap_spool_mark_legacy_no_binding sunk-audit
am="$TAP_HOME/spool/sunk-audit.meta.json"
orig="$(python3 -B -c 'import json,sys; print(json.load(open(sys.argv[1])).get("original_reason") or "")' "$am")"
[ "$orig" = pending-input ] || fail \
  "the mark destroyed its own diagnosis: original_reason='$orig', expected 'pending-input'"
hist="$(python3 -B -c 'import json,sys; h=json.load(open(sys.argv[1])).get("reason_history") or []; print(h[0].get("reason") if h else "")' "$am")"
[ "$hist" = pending-input ] || fail \
  "reason_history did not record the displaced reason (got '$hist')"
# A re-mark must not erase the origin. STATED HONESTLY, because mutation testing
# showed what this does and does not prove: making the preservation
# unconditional (`if prior:` instead of `if "original_reason" not in meta:`)
# does NOT red this, because the early-exit above returns before reaching
# either line when the entry is already marked. So this pins the EARLY EXIT,
# which is the property that actually protects the origin today; the
# not-in-meta guard is defense-in-depth for a future second terminal string and
# is unreachable while only one exists.
#
# Left in and relabelled rather than deleted or dressed up as coverage it does
# not have: the early-exit IS load-bearing here, and an arm that names the wrong
# mechanism is how the placebo in arm 2 got written.
tap_spool_mark_legacy_no_binding sunk-audit
orig2="$(python3 -B -c 'import json,sys; print(json.load(open(sys.argv[1])).get("original_reason") or "")' "$am")"
[ "$orig2" = pending-input ] || fail \
  "a re-mark overwrote original_reason (now '$orig2') — the early-exit no longer protects the origin"
echo "drain-sink-no-silent-skip: 5/8 — the mark preserves the reason it displaced; a re-mark cannot erase it: ok"


# ── 6. A legitimately-escalated entry: settled reaps, UNSETTLED still parks ───
# The reconcile above the escalated gate changes behavior for a LIVE path, not a
# hypothetical: entries that escalate normally (tap-zeng's "stay for human
# disposition") and are then settled. That shift is DELIBERATE — settlement
# discharges the obligation, so there is nothing left for a human to dispose of,
# and keeping it parked is how a resolved item becomes permanent clutter.
#
# But the same edit must not reap an escalated entry that is still UNSETTLED:
# that one genuinely awaits a human, and reaping it would delete the record
# tap-zeng exists to preserve. Both halves are asserted here because only
# stating the intended half would leave the destructive half untested.
plant esc-settled "$old" 1 pending-input busy
: > "$TAP_HOME/receipts/esc-settled.done"
plant esc-unsettled "$old" 1 pending-input busy
tap_spool_drain_once "$now" 8 >/dev/null 2>&1 || true
[ ! -f "$TAP_HOME/spool/esc-settled.meta.json" ] || fail \
  "an escalated-AND-settled entry stayed parked — a discharged obligation still awaiting human disposition"
[ -f "$TAP_HOME/spool/esc-unsettled.meta.json" ] || fail \
  "an escalated UNSETTLED entry was reaped — that record awaits a human and must survive (tap-zeng)"
echo "drain-sink-no-silent-skip: 6/8 — escalated: settled reaps, unsettled still parks: ok"

# ── 7. NO DEADLINE is the oldest shape, and it must still age out ────────────
# Found by opus-door on #xxx (§3) as a question about the guard rather than the
# constant, and it was not hypothetical: BOTH 35-day specimens — the two this
# bead was filed about — carry `deadline_epoch: null`. The first spelling of the
# escape route was `[ -n "$deadline_epoch" ] && ...`, which would have reported
# the one entry that had a deadline and silently skipped the two that had waited
# a month. A sink one subclass narrower is still a sink.
#
# Modeled on the real specimen shape: no deadline, no timeout, absent binding.
# With no deadline the age comes from first_spooled_epoch, the only clock such an
# entry has.
plant sunk-nodeadline "$old" 0 legacy_meta_no_binding safety_gate
python3 -B - "$TAP_HOME/spool/sunk-nodeadline.meta.json" <<'PYMETA'
import json, sys
p = sys.argv[1]; m = json.load(open(p))
m["deadline_epoch"] = None          # the 2026-07-15 specimens' actual shape
m["timeout_seconds"] = None
json.dump(m, open(p, "w"), indent=2, sort_keys=True)
PYMETA
tap_spool_drain_once "$now" 8 >/dev/null 2>&1 || true
nd="$TAP_HOME/spool/sunk-nodeadline.meta.json"
if [ -f "$nd" ]; then
  ndd="$(python3 -B -c '
import json,sys
m=json.load(open(sys.argv[1]))
for k in ("escalated_at","unrouted_at","disposition","notified_at"):
    if m.get(k): print(k); break
else: print("")
' "$nd")"
  [ -n "$ndd" ] || fail     "SINK: an entry with NO deadline never ages out — the two oldest real specimens have exactly this shape"
fi
echo "drain-sink-no-silent-skip: 7/8 — a deadline-less entry ages from its park time, not never: ok"

# ── 8. THE EVENT VOCABULARY IS PINNED, NOT JUST THE META FIELDS ──────────────
# opus-door #xxx F2: `spool_marked_unroutable`, `spool_terminal_unrouted` and
# `spool_terminal_settled` appeared in NO fixture — only in a comment. So a
# mutation renaming any of them, or dropping the append call, stayed green.
#
# That gap is the bug's own shape: the machine-wide grep for this transition
# returned zero lines precisely because the vocabulary had no action for it, and
# an unpinned action name is one rename away from returning zero again. The meta
# fields were covered (arm 5); the log was not.
EV="$TAP_HOME/registry-events.log"

# (a) the MARK transition — emitted on a real displacement, once
: > "$EV"
plant ev-mark "$old" 0 pending-input busy
tap_spool_mark_legacy_no_binding ev-mark
grep -q "action=spool_marked_unroutable" "$EV" 2>/dev/null || fail \
  "no spool_marked_unroutable event for the mark transition — the log is silent on the state that hid a specimen for 12 hours"
grep -q "from_reason=pending-input" "$EV" 2>/dev/null || fail \
  "the mark event does not name the reason it displaced"
_n1=$(grep -c "action=spool_marked_unroutable" "$EV")
tap_spool_mark_legacy_no_binding ev-mark          # re-mark is a no-op
_n2=$(grep -c "action=spool_marked_unroutable" "$EV")
[ "$_n1" = "$_n2" ] || fail \
  "a re-mark appended a second event — the drain re-marks every pass, so this is log spam by design"

# (b) the SETTLED disposal — both sites, same action name
: > "$EV"
plant ev-settled "$old" 0 legacy_meta_no_binding safety_gate
: > "$TAP_HOME/receipts/ev-settled.done"
tap_spool_drain_once "$now" 8 >/dev/null 2>&1 || true
grep -q "action=spool_terminal_settled" "$EV" 2>/dev/null || fail \
  "a settled sunk entry was reaped with no spool_terminal_settled event"

# (c) the UNROUTED disposition — and it must NOT log as a delivery failure
: > "$EV"
plant ev-unrouted "$old" 0 legacy_meta_no_binding safety_gate
tap_spool_drain_once "$now" 8 >/dev/null 2>&1 || true
grep -q "action=spool_terminal_unrouted" "$EV" 2>/dev/null || fail \
  "the unrouted disposition emitted no spool_terminal_unrouted event"
grep -q "action=spool_terminal_delivery_failed" "$EV" 2>/dev/null && fail \
  "an entry that was NEVER ATTEMPTED logged spool_terminal_delivery_failed — the log asserts the failure the notice beside it declines to claim"
echo "drain-sink-no-silent-skip: 8/8 — all three event actions are pinned, and unrouted never logs as failed: ok"

echo "drain-sink-no-silent-skip: ok"
