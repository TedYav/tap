#!/usr/bin/env bash
# Refuse `source` so an interactive shell cannot inherit top-level exports.
# Must run BEFORE any `set -o` so a refusal does not mutate caller options.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# embedded-python-heredoc-compile.test.sh — py_compile quoted stdin heredocs
# in BOTH suite buckets (tap-52ys / #xxx).
#
# SEES: stdin-program-mode invocations of python3, $PY, $TAP_PYTHON,
# ${TAP_PYTHON:-python3}, or $REAL_PYTHON3 (quoted or not). Quoted delimiters
# only: <<'DELIM', <<"DELIM", <<-'DELIM', <<-"DELIM". DELIM is any quoted run,
# not only [A-Za-z0-9_]. Line-continuation is joined before the body starts
# (`|| fail` is still shell). Comment lines are not commands.
#
# STDIN-PROGRAM MODE (T10). Compile a heredoc only when it is python3's
# program: the first positional argument is absent or the token `-`. A
# short cluster naming `c` or `m` (`-c`, `-m`, `-Sc`, `-Bm`, attached
# forms) means the program is elsewhere; long options are left alone
# (`--check-hash-based-pycs` contains `c` and is unaffected). Other
# dashed tokens are treated as no-operand flags — that is the
# proposition, not python3's option grammar. Not claimed: operand-taking
# options (`-W`, `-X`) — those look like a script path and we skip. A
# non-program heredoc is still consumed through its closer so its body
# is not re-lexed as shell.
#
# `<<-` SEMANTICS (bash): leading tabs — not spaces — are stripped from every
# body line and from the closer before the interpreter sees the bytes. This
# sweeper strips leading tabs the same way; compiling the file's raw indent is a
# false red on valid code. Spaces-only indent is left intact.
#
# Other quoted-heredoc behaviour between delimiter and interpreter, enumerated:
# no parameter/command/arithmetic expansion (stored bytes ARE the body — we
# compile them); backslash is literal; closer is the first exact delimiter line
# (tab-prefixed only under `<<-`); delimiter line is not part of the body.
# Not claimed, not reproduced: unquoted <<DELIM (expands); backslash-quoted
# <<\\DELIM; CRLF/CR stripping; here-strings (<<<).
#
# DOES NOT SEE: unquoted <<DELIM; python3 -c / -m / -Sc / -Bm / script-file
# (stdin is data, not source); cat-written interpreter stubs; any other
# $VAR that happens to hold python.
#
# DISCLOSURE — `echo python3 - <<'DATA'` (also cat/printf) false-REDs.
# The left boundary is `[\s;|&({]`, so whitespace is a command separator
# and argument-position python3 extracts DATA as source. Tightening to
# `;|&({` traded that class for quoted-separator false-REDs (`printf '%s\n'
# "; python3 - <<'DATA'"`). Quote-masking then lost 29 real invocations.
# Both character-class candidates measured indistinguishable in-tree
# (479=479 on main, 474=474 on the then-head), so this PR reverts and
# discloses. A corpus scan proves the change breaks nothing that exists;
# it says nothing about what the rule means — the echo shape is not in
# the corpus. Three boundaries have now passed one. The axis is closed
# to character classes.
#
# BYTECODE. py_compile gets cfile beside the temp source so the .pyc does
# not land in TMPDIR/__pycache__ (on a gate run that is /tmp/__pycache__,
# shared machine state the post-wave guard notices). Both files go in the
# same finally.
#
# THE DEFECT THIS PREVENTS. A fixture glob sweep stripped three quote-escapes
# inside a quoted python stdin heredoc in smoke/server-epoch-guard.test.sh.
# `bash -n` parsed the shell; ci-sanity's py_compile sweep only sees *.py
# files; smoke-all.sh does not run regress/. The file could not execute, and
# the merge gate stayed green by construction. AGENTS.md's own warning is the
# trap: several sweepers keyed exemptions on the literal string /smoke/, so
# moving a fixture silently unsanctioned it. Walk both buckets.
#
# A later hole: the matcher saw only python3 / $PY, so ${TAP_PYTHON:-python3}
# and $REAL_PYTHON3 produced ok 0 — "found nothing," not "compiled clean."
# Vacuous 0 is a fail; silent files are counted on the ok line.
#
# CONSUME THE BODY. After an opener, resume at the closer — body lines are not
# shell and must not be re-lexed for a nested `python3 … <<`. A closer is the
# first exact delimiter line (tab-prefixed only under `<<-`); `# PY` and a
# delimiter substring on a longer line are not closers. `# python3 <<` is not
# an opener (comment skip). Nothing else in that class: we do not parse Python
# string/comment state because we do not scan the body for openers.
#
# Six rounds, one conflation — proximity of a heredoc to `python3` was
# standing in for "this heredoc is python3's program," a proposition nobody
# checked: T7 aliases omitted (false green); T8a empty session_name (not
# this file); T8b <<- tabs (false red); T9 nested opener re-lexed (false
# red); T10 data heredoc compiled as source (false red). T10 stated the
# proposition; the clustered-short clause states it more precisely (still
# a false red, not a new cause). T11 (command position) is the disclosure
# above, not a seventh precondition: a character-class left boundary
# cannot name command position. A finding that needs python3's argument
# grammar is a rewrite, not another precondition patch.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
PY="${TAP_PYTHON:-python3}"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
fail() { echo "embedded-python-heredoc-compile: $*" >&2; exit 1; }

scan() { # <root> [min-heredocs]
  "$PY" -B - "$1" "${2:-0}" <<'PY'
from pathlib import Path
import os
import py_compile
import re
import shlex
import sys
import tempfile

CMD = (
    r"(?P<cmd>python3|"
    r'"\$\{?PY\}?"|\$\{?PY\}?|'
    r'"\$REAL_PYTHON3"|\$REAL_PYTHON3|'
    r'"\$\{TAP_PYTHON:-python3\}"|\$\{TAP_PYTHON:-python3\}|'
    r'"\$TAP_PYTHON"|\$TAP_PYTHON)'
)
# Named quote group — a numeric backref shifts when argv is captured,
# and <<- then fails to match (the hyphen is group-3, not the closer).
# Left boundary `[\s;|&({]` — see DISCLOSURE in the file header.
INVOKE = re.compile(
    r"(?:^|[\s;|&({])\s*"
    + CMD
    + r"(?P<argv>\s+[^<]*)<<(?P<dash>-?)\s*(?P<q>['\"])(?P<delim>[^'\"]+)(?P=q)"
)
PLAIN = {"python3", "$PY", '"$PY"', "${PY}", '"${PY}"'}
PROGRAM_OPT = {"-c", "--command", "-m", "--module"}


def stdin_program_mode(argv):
    """True when stdin is python3's program, not its input.

    First positional argument is absent or the token `-`. A short cluster
    naming `c` or `m` means the program is elsewhere (covers `-c`, `-m`,
    `-Sc`, `-Bm`, attached forms). Long options are left alone. Other
    dashed tokens are treated as no-operand flags — not python3's option
    grammar. Not claimed: operand-taking options (`-W`, `-X`).
    """
    try:
        tokens = shlex.split(argv, posix=True)
    except ValueError:
        return False
    for t in tokens:
        if t in PROGRAM_OPT:
            return False
        if t.startswith("--"):
            continue
        if t.startswith("-") and t != "-":
            if "c" in t[1:] or "m" in t[1:]:
                return False
            continue
        return t == "-"
    return True


def heredoc_span(lines, start, delim, strip_tabs):
    body = []
    j = start
    while j < len(lines):
        raw = lines[j]
        closer = raw.lstrip("\t") if strip_tabs else raw
        if closer == delim:
            return j, body
        body.append(raw.lstrip("\t") if strip_tabs else raw)
        j += 1
    return j, body

root = Path(sys.argv[1])
floor = int(sys.argv[2])
files = sorted(root.glob("skills/*/scripts/smoke/*.test.sh")) + sorted(
    root.glob("skills/*/scripts/regress/*.test.sh")
)
if not files:
    print(
        "embedded-python-heredoc-compile: no skills/*/scripts/{smoke,regress}/*.test.sh",
        file=sys.stderr,
    )
    raise SystemExit(1)

fails = []
n = 0
alias_n = 0
silent = []
for path in files:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    found = 0
    rel = path.as_posix()
    try:
        rel = str(path.relative_to(root))
    except ValueError:
        pass
    i = 0
    while i < len(lines):
        chunk = [lines[i]]
        while i < len(lines) and lines[i].endswith("\\"):
            i += 1
            if i < len(lines):
                chunk.append(lines[i])
        logical = " ".join(
            s[:-1].rstrip() if s.endswith("\\") else s for s in chunk
        )
        stripped = logical.lstrip()
        if stripped.startswith("#"):
            i += 1
            continue
        logical = re.split(r"\s#", logical, maxsplit=1)[0]
        m = INVOKE.search(logical)
        if m:
            delim = m.group("delim")
            strip_tabs = m.group("dash") == "-"
            body_start = i + 1
            j, body = heredoc_span(lines, body_start, delim, strip_tabs)
            if j >= len(lines):
                fails.append(f"{rel}:{body_start}: unclosed heredoc {delim}")
                break
            # Resume at the closer either way. Body is not shell (T9); a
            # data heredoc is not source (T10) but still consumed.
            i = j
            if not stdin_program_mode(m.group("argv")):
                i += 1
                continue
            if m.group("cmd") not in PLAIN:
                alias_n += 1
            n += 1
            found += 1
            fd, tmp = tempfile.mkstemp(suffix=".py")
            os.close(fd)
            cfile = tmp + "c"
            try:
                open(tmp, "w", encoding="utf-8").write("\n".join(body) + "\n")
                # cfile beside the source — default cache is TMPDIR/__pycache__.
                py_compile.compile(tmp, cfile=cfile, doraise=True)
            except py_compile.PyCompileError as e:
                last = str(e).strip().splitlines()[-1]
                fails.append(f"{rel}:{body_start}: {last}")
            finally:
                os.unlink(tmp)
                if os.path.exists(cfile):
                    os.unlink(cfile)
        i += 1
    if found == 0:
        silent.append(rel)

if n == 0:
    print(
        f"embedded-python-heredoc-compile: vacuous: {len(files)} file(s) matched "
        "the bucket globs, 0 python-stdin heredocs — ok 0 is not compiled-clean",
        file=sys.stderr,
    )
    for s in silent:
        print(f"  silent: {s}", file=sys.stderr)
    raise SystemExit(1)
if floor and n < floor:
    print(
        f"embedded-python-heredoc-compile: only {n} python-stdin heredoc(s) "
        f"(floor {floor}) — extractor drifted or the corpus moved",
        file=sys.stderr,
    )
    raise SystemExit(1)
if fails:
    print(
        "embedded-python-heredoc-compile: python-stdin heredoc failed py_compile:",
        file=sys.stderr,
    )
    for f in fails:
        print(f"  {f}", file=sys.stderr)
    raise SystemExit(1)
print(f"ok {n} files={len(files)} silent={len(silent)} alias={alias_n}")
PY
}

# (1) Live suite — both buckets. Floor is a vacuous-pass guard, not a census.
live_out="$(scan "$ROOT" 100)" || fail "(1) a python-stdin heredoc in smoke/ or regress/ failed py_compile"
case "$live_out" in
  ok\ [0-9]*\ files=*\ silent=*\ alias=*) ;;
  *) fail "(1) unexpected scanner output: $live_out" ;;
esac
alias_n="${live_out##*alias=}"
[ "$alias_n" -ge 5 ] || fail "(1) expected >=5 alias heredocs (TAP_PYTHON / REAL_PYTHON3), got: $live_out"
echo "embedded-python-heredoc-compile: (1) live suite python-stdin heredocs compile ($live_out): ok"

# (2) MUTATION BAR — the exact T5 unescaping. Assembled so this file is not a hit.
FIXTURE="$WORK/fixture"
mkdir -p "$FIXTURE/skills/tap/scripts/regress"
{
  printf '%s\n' "python3 - <<'PY'"
  printf '%s\n' "body = body.replace("
  printf '%s\n' '    "placeholder",'
  printf '%s\n' "    '  *pid*start_time*)       printf '%s\\\\n' \"\${FAKE_SERVER_EPOCH_RAW:-900:100}\" ;;'"
  printf '%s\n' ")"
  printf '%s\n' "PY"
} > "$FIXTURE/skills/tap/scripts/regress/offender.test.sh"
grep -q "printf '%s" "$FIXTURE/skills/tap/scripts/regress/offender.test.sh" \
  || fail "(2) fixture assembly failed — the stripped-quote line was not written"
mutation_out=""
if mutation_out="$(scan "$FIXTURE" 0 2>&1)"; then
  fail "(2) the check accepted the T5 unescaping that made server-epoch-guard unexecutable"
fi
case "$mutation_out" in
  *offender.test.sh*) ;;
  *) fail "(2) the check fired but did not name the offender: $mutation_out" ;;
esac
echo "embedded-python-heredoc-compile: (2) fires on the T5 stripped-quote heredoc: ok"

# (3) NEGATIVE — a python3 stub written with cat is bash, not stdin-to-python.
mkdir -p "$FIXTURE/skills/tap/scripts/smoke"
cat > "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" <<'STUB'
cat > "$SHIM/python3" <<'SH'
#!/usr/bin/env bash
exec "$REAL_PYTHON3" "$@"
SH
python3 - <<'PY'
print(1)
PY
STUB
rm -f "$FIXTURE/skills/tap/scripts/regress/offender.test.sh"
neg_out="$(scan "$FIXTURE" 0)" || fail "(3) flagged a cat-written python3 stub or a valid print(1) heredoc: $neg_out"
[ "$neg_out" = "ok 1 files=1 silent=0 alias=0" ] || fail "(3) expected one python-stdin heredoc, got: $neg_out"
echo "embedded-python-heredoc-compile: (3) cat-written python3 stubs are not compiled; valid stdin compiles: ok"

# (4) CONTROL — the real ${TAP_PYTHON:-python3} shape must red, not ok 0.
{
  printf '%s\n' '"${TAP_PYTHON:-python3}" -B - <<'"'"'PY'"'"
  printf '%s\n' 'def broken(:'
  printf '%s\n' 'PY'
} > "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh"
grep -q 'TAP_PYTHON:-python3' "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(4) fixture assembly failed — the TAP_PYTHON alias was not written"
alias_out=""
if alias_out="$(scan "$FIXTURE" 0 2>&1)"; then
  fail "(4) the TAP_PYTHON alias shape was invisible (ok 0 / compiled-clean): $alias_out"
fi
case "$alias_out" in
  *stub.test.sh*) ;;
  *) fail "(4) the check fired but did not name the TAP_PYTHON offender: $alias_out" ;;
esac
echo "embedded-python-heredoc-compile: (4) reds on the real TAP_PYTHON alias shape: ok"

# (5) VACUOUS — a bucket file with no python-stdin heredoc must not print ok 0.
printf '%s\n' 'echo hi' > "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh"
vacuous_out=""
if vacuous_out="$(scan "$FIXTURE" 0 2>&1)"; then
  fail "(5) a silent bucket file printed success: $vacuous_out"
fi
case "$vacuous_out" in
  *vacuous*) ;;
  *) fail "(5) silent file did not fail vacuous: $vacuous_out" ;;
esac
case "$vacuous_out" in
  *stub.test.sh*) ;;
  *) fail "(5) vacuous fail did not name the silent file: $vacuous_out" ;;
esac
echo "embedded-python-heredoc-compile: (5) vacuous 0 is loud and names the silent file: ok"

# (6) `<<-` BODY TABS — bash strips them; compiling verbatim is a false red.
# At 8d6f0aad this fixture redded (tab-indented print is IndentationError).
# Assembled so this file is not itself a python-stdin hit.
{
  printf '%s\n' "python3 - <<-'PY'"
  printf '\t%s\n' 'print(1)'
  printf '%s\n' "PY"
} > "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh"
grep -q $'\tprint(1)' "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(6) fixture assembly failed — the tab-indented body was not written"
tab_out="$(scan "$FIXTURE" 0)" || fail "(6) tab-indented <<- body failed py_compile (tabs were not stripped): $tab_out"
[ "$tab_out" = "ok 1 files=1 silent=0 alias=0" ] || fail "(6) unexpected scanner output: $tab_out"
echo "embedded-python-heredoc-compile: (6) <<- tab-indented body compiles after strip: ok"

# (7) BODY IS NOT SHELL — a heredoc-shaped line inside a triple-quoted string
# must not start a second extract. At 6b6732d7 this redded (inner `def broken(:`
# compiled as Python). Assembled so this file is not itself a hit.
{
  printf '%s\n' "python3 - <<'PY'"
  printf '%s\n' 's = """'
  printf '%s\n' "python3 - <<'PY'"
  printf '%s\n' 'def broken(:'
  printf '%s\n' '"""'
  printf '%s\n' 'print(1)'
  printf '%s\n' "PY"
} > "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh"
grep -q "def broken(:" "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(7) fixture assembly failed — the nested opener-shaped string was not written"
nested_out="$(scan "$FIXTURE" 0)" \
  || fail "(7) valid outer heredoc with a nested-opener-shaped string failed py_compile: $nested_out"
[ "$nested_out" = "ok 1 files=1 silent=0 alias=0" ] \
  || fail "(7) expected one heredoc (the outer), got: $nested_out"
echo "embedded-python-heredoc-compile: (7) nested-opener-shaped string in a Python body is not re-lexed: ok"

# (8) STDIN-PROGRAM MODE — -c / -m / script-file heredocs are input, not
# source. At d1613552 this redded (DATA compiled as Python). Assembled so
# this file is not itself a python-stdin hit. Bare `python3` and `python3 -`
# still extract. DATA must be a SyntaxError — `this is not python` compiles
# (it is a comparison).
{
  printf '%s\n' "python3 -c 'import sys; print(sys.stdin.read())' <<'DATA'"
  printf '%s\n' "not python data !!!"
  printf '%s\n' "DATA"
  printf '%s\n' "python3 -m json.tool <<'DATA'"
  printf '%s\n' "not python data !!!"
  printf '%s\n' "DATA"
  printf '%s\n' "python3 ./script.py <<'DATA'"
  printf '%s\n' "not python data !!!"
  printf '%s\n' "DATA"
  printf '%s\n' "python3 <<'PY'"
  printf '%s\n' "print(1)"
  printf '%s\n' "PY"
  printf '%s\n' "python3 - <<'PY'"
  printf '%s\n' "print(1)"
  printf '%s\n' "PY"
} > "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh"
grep -q "python3 -c " "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(8) fixture assembly failed — the -c data heredoc was not written"
grep -q "python3 -m " "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(8) fixture assembly failed — the -m data heredoc was not written"
grep -q "python3 ./script.py " "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(8) fixture assembly failed — the script-file data heredoc was not written"
grep -q "not python data !!!" "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(8) fixture assembly failed — the non-Python DATA body was not written"
mode_out="$(scan "$FIXTURE" 0)" \
  || fail "(8) -c/-m/script-file data compiled as Python, or a valid stdin heredoc failed: $mode_out"
[ "$mode_out" = "ok 2 files=1 silent=0 alias=0" ] \
  || fail "(8) expected two stdin-program heredocs (bare and dash), got: $mode_out"
echo "embedded-python-heredoc-compile: (8) -c/-m/script-file data is not extracted; bare python3 and python3 - still are: ok"

# (9) BYTECODE STAYS WITH THE SOURCE. Default py_compile writes
# TMPDIR/__pycache__/ (on a gate run, /tmp/__pycache__). At 48366c46 a
# compile under an isolated TMPDIR left a .pyc there after the source
# was unlinked. Assembled so this file is not itself a hit.
{
  printf '%s\n' "python3 - <<'PY'"
  printf '%s\n' "print(1)"
  printf '%s\n' "PY"
} > "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh"
WATCH="$WORK/pycwatch"
mkdir -p "$WATCH"
pyc_out="$(TMPDIR="$WATCH" scan "$FIXTURE" 0)" \
  || fail "(9) valid stdin heredoc failed py_compile under isolated TMPDIR: $pyc_out"
[ "$pyc_out" = "ok 1 files=1 silent=0 alias=0" ] \
  || fail "(9) unexpected scanner output: $pyc_out"
leftover="$(find "$WATCH" -type f -print)"
[ -z "$leftover" ] \
  || fail "(9) compile left files under TMPDIR (bytecode cache?): $leftover"
echo "embedded-python-heredoc-compile: (9) bytecode does not land in TMPDIR/__pycache__: ok"

# (10) CLUSTERED SHORT -c/-m. A short cluster naming c or m means the
# program is elsewhere. The spaced `-Sc 'code'` form already skipped at
# 4332e6be (the code string is a positional). The hole is attached /
# operand-less clusters. At 4332e6be those extracted DATA. `-B -` still
# extracts. Assembled so this file is not a hit.
{
  printf '%s\n' "python3 -Sc'import sys; print(sys.stdin.read())' <<'DATA'"
  printf '%s\n' "not python data !!!"
  printf '%s\n' "DATA"
  printf '%s\n' "python3 -Bmjson.tool <<'DATA'"
  printf '%s\n' "not python data !!!"
  printf '%s\n' "DATA"
  printf '%s\n' "python3 -Sc <<'DATA'"
  printf '%s\n' "not python data !!!"
  printf '%s\n' "DATA"
  printf '%s\n' "python3 -B - <<'PY'"
  printf '%s\n' "print(1)"
  printf '%s\n' "PY"
} > "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh"
grep -q "python3 -Sc'" "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(10) fixture assembly failed — the attached -Sc data heredoc was not written"
grep -q "python3 -Bmjson.tool " "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(10) fixture assembly failed — the attached -Bm data heredoc was not written"
grep -q "python3 -Sc <<" "$FIXTURE/skills/tap/scripts/smoke/stub.test.sh" \
  || fail "(10) fixture assembly failed — the operand-less -Sc data heredoc was not written"
cluster_out="$(scan "$FIXTURE" 0)" \
  || fail "(10) clustered -Sc/-Bm data compiled as Python, or -B - stdin failed: $cluster_out"
[ "$cluster_out" = "ok 1 files=1 silent=0 alias=0" ] \
  || fail "(10) expected one stdin-program heredoc (-B -), got: $cluster_out"
echo "embedded-python-heredoc-compile: (10) clustered -Sc/-Bm data is not extracted; -B - still is: ok"

echo "embedded-python-heredoc-compile: ok"
