#!/usr/bin/env bash
# claude-shell-body-hook-install.test.sh — tap-liero production wiring
# A scratch install must place the shell-body guard in Claude's real user-level
# settings builder. hooks/hooks.json alone is inert when TAP is not a plugin.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

CLAUDE_HOME="$WORK/claude"
mkdir -p "$CLAUDE_HOME"
cat >"$CLAUDE_HOME/settings.json" <<'JSON'
{
  "theme": "dark",
  "hooks": {
    "PreToolUse": [
      {"matcher": "Read", "hooks": [{"type": "command", "command": "/other/read-hook"}]}
    ],
    "SessionStart": [
      {"hooks": [{"type": "command", "command": "/other/session-hook"}]}
    ]
  }
}
JSON

python3 - "$CLAUDE_HOME/settings.json" "$ROOT" <<'PY'
import json
import pathlib
import sys

path, root = map(pathlib.Path, sys.argv[1:])
settings = json.loads(path.read_text())
guard = str(root / "hooks/tap-shell-body-guard.py")
settings["hooks"]["PreToolUse"].append(
    {"matcher": "Bash", "hooks": [{"type": "prompt", "command": guard}]}
)
path.write_text(json.dumps(settings, indent=2) + "\n")
PY

run_install() {
  PATH="$WORK/bin:$PATH" TAP_INSTALL_BIN="$WORK/bin" \
  TAP_CLAUDE_HOME="$CLAUDE_HOME" \
  TAP_CODEX_HOME="$WORK/no-codex" \
  TAP_HERMES_HOME="$WORK/no-hermes" \
  TAP_CURSOR_HOME="$WORK/no-cursor" \
  TAP_OPENCODE_HOME="$WORK/no-opencode" \
  TAP_GEMINI_HOME="$WORK/no-gemini" \
  TAP_CURSOR_AGENT_HOME="$WORK/no-cursor-agent" \
  TAP_AGENTS_HOME="$WORK/no-agents" \
  TAP_INDEX_HOME="$WORK/tap-index" \
  TAP_INSTALL_HOOK=1 \
    bash "$ROOT/install.sh" >"$WORK/install.out"
}

run_install

python3 - "$CLAUDE_HOME/settings.json" "$ROOT" <<'PY'
import json
import pathlib
import sys

path, root = sys.argv[1:]
settings = json.loads(pathlib.Path(path).read_text())
assert settings.get("theme") == "dark", "install rewrote unrelated Claude settings"

hooks = settings.get("hooks", {})
pre = hooks.get("PreToolUse", [])
guard = str(pathlib.Path(root) / "hooks/tap-shell-body-guard.py")
guard_entries = [
    entry
    for entry in pre
    if entry.get("matcher") == "Bash"
    and any(h.get("type") == "command" and h.get("command") == guard for h in entry.get("hooks", []))
]
assert len(guard_entries) == 1, f"PreToolUse Bash guard registrations: {guard_entries!r}"
assert any(entry.get("matcher") == "Read" for entry in pre), "install removed another PreToolUse hook"
assert any(
    h.get("type") == "prompt" and h.get("command") == guard
    for entry in pre
    for h in entry.get("hooks", [])
), "install removed the same-path non-command hook"

session = hooks.get("SessionStart", [])
commands = [h.get("command") for entry in session for h in entry.get("hooks", [])]
assert "/other/session-hook" in commands, "install removed another SessionStart hook"
assert str(pathlib.Path(root) / "hooks/tap-advisory.sh") in commands, "SessionStart advisory missing"
PY

cp "$CLAUDE_HOME/settings.json" "$WORK/settings.before-second-install.json"
run_install
cmp -s "$WORK/settings.before-second-install.json" "$CLAUDE_HOME/settings.json" \
  || { echo "claude-shell-body-hook-install: second install changed settings.json" >&2; exit 1; }

guard="$ROOT/hooks/tap-shell-body-guard.py"
denial="$(printf '%s\n' '{"tool_name":"Bash","tool_input":{"command":"tap send peer -m \"literal `date`\""}}' | "$guard")"
python3 - "$denial" <<'PY'
import json
import sys

result = json.loads(sys.argv[1])
decision = result.get("hookSpecificOutput", {})
assert decision.get("hookEventName") == "PreToolUse"
assert decision.get("permissionDecision") == "deny"
PY

echo "claude-shell-body-hook-install: scratch settings wire one live PreToolUse guard: ok"
