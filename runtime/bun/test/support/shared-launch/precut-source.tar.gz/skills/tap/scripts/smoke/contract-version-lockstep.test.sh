#!/usr/bin/env bash
# contract-version-lockstep.test.sh — the CONTRACT's grammar examples drift
# behind TAP_SENTINEL_VERSION on every bump (opus gate: flagged on #xxx,
# recurred on #xxx). One assertion, forever: title, version line, and every
# v=X.Y occurrence in the spec match the constant implementers copy from.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
LIB="$ROOT/skills/tap/scripts/lib.sh"
CONTRACT="$ROOT/skills/tap/scripts/CONTRACT.md"

ver="$(grep -o 'TAP_SENTINEL_VERSION="[0-9.]*"' "$LIB" | cut -d'"' -f2)"
[ -n "$ver" ] || { echo "lockstep: TAP_SENTINEL_VERSION not found in lib.sh" >&2; exit 1; }

grep -q "^# TAP Contract (v$ver)" "$CONTRACT" \
  || { echo "lockstep: CONTRACT title is not v$ver" >&2; head -1 "$CONTRACT" >&2; exit 1; }
echo "lockstep: (1) title matches v$ver: ok"

# Matched loosely on the parenthetical so a reworded gloss does not red, and
# strictly on the NUMBER, which is the thing this check exists to pin.
grep -qE "Protocol version [^:]*: $ver\." "$CONTRACT" \
  || { echo "lockstep: CONTRACT version line is not $ver" >&2; exit 1; }
echo "lockstep: (2) version line matches $ver: ok"

# (3) THE GRAMMAR BLOCK'S OWN VERSION TOKEN, which is what check (3) used to reach
# by accident. It swept `v=[0-9]` outside the changelog — and v0.23 dropped the `=`
# from the wire, so that sweep now matches nothing and would report clean forever
# while the grammar block drifted. A check that cannot fail is worse than no check:
# it reads as coverage. The replacement asks the question the sweep was standing in
# for — does the ONE place implementers copy the wire shape from carry the
# constant's version? — and it can still fail, which the mutation below proves.
grep -qE '^\[\[TAP v'"$ver"' <ask\|note>' "$CONTRACT" \
  || { echo "lockstep: the §Sentinel grammar block does not carry v$ver" >&2; grep -n '^\[\[TAP' "$CONTRACT" >&2; exit 1; }
echo "lockstep: (3) the grammar block's version token matches $ver: ok"

# (4) No stale v= anywhere outside the changelog. The `=` form is retired, so the
# living spec must carry NONE of it — a different assertion from the old check (3),
# which permitted the current version in that form.
stale="$(grep -v '^\*\*Changes since' "$CONTRACT" | grep -o 'v=[0-9][0-9.]*' | sort -u || true)"
[ -z "$stale" ] || { echo "lockstep: the retired \`v=\` wire form survives outside the changelog: $stale" >&2; exit 1; }
echo "lockstep: (4) no retired v= form outside the changelog: ok"

echo "contract-version-lockstep: ok"
