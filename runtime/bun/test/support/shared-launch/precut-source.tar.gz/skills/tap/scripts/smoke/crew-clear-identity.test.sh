#!/usr/bin/env bash
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/smoke-preflight.sh"
PY="${TAP_PYTHON:-$(smoke_resolve_python)}"
smoke_assert_python "$PY"
exec "$PY" -m pytest skills/tap/scripts/session/tests/test_clear_crew_identity.py -q --tb=short
