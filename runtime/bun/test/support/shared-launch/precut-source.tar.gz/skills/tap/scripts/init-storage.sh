#!/usr/bin/env bash
# tap-init.sh - initialize this repo's .tap bus and migrate legacy tmp/tap state.
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ROOT="$(git rev-parse --show-toplevel 2>/dev/null)"; then
  IN_GIT=1
else
  ROOT="$PWD"
  IN_GIT=0
fi
BRANCH="$(git -C "$ROOT" symbolic-ref --quiet --short HEAD 2>/dev/null || echo "unknown")"

# init owns the sanctioned R23 migration path: it always targets the repo-local
# .tap/bus, bypassing the split-brain guard only for its own directory creation.
export TAP_HOME="$ROOT/.tap/bus"
export TAP_MIGRATING=1
# shellcheck source=skills/tap/scripts/lib.sh
. "$DIR/lib.sh"
TAP_VERB="tap init"

TAP_JSON=0
while [ "$#" -gt 0 ]; do
  case "$1" in
    --json) TAP_JSON=1; shift ;;
    --*)    tap_fail 1 unknown_option "tap help init" "unknown option '$1'" ;;
    *)      tap_fail 1 usage_error "tap help init" "unexpected arg '$1'" ;;
  esac
done

[ "$IN_GIT" = 1 ] || echo "tap init: warning: not inside a git worktree; anchoring TAP at $ROOT" >&2

# Keep repository ignore policy at the same Git root that init enrolls.
if [ "$IN_GIT" = 1 ]; then
  tap_bun_call init-ignore "$ROOT" init-ignore.ts "$ROOT" || \
    tap_fail 1 gitignore_failed "fix the repository .gitignore, then rerun tap init" "could not add .tap/ to the repository ignore rules"
fi

legacy="$ROOT/tmp/tap"

legacy_has_any_state() {
  [ -d "$legacy" ] && [ -n "$(ls -A "$legacy" 2>/dev/null)" ]
}

migrate_once() {
  python3 -B - "$legacy" "$TAP_HOME" <<'PY'
import json, os, shutil, sys, tempfile

legacy, bus = sys.argv[1:3]

def replace_move(src, dst):
    if os.path.lexists(dst):
        if os.path.isdir(dst) and not os.path.islink(dst):
            shutil.rmtree(dst)
        else:
            os.remove(dst)
    shutil.move(src, dst)

def move_children(name):
    src = os.path.join(legacy, name)
    dst = os.path.join(bus, name)
    count = 0
    if os.path.isdir(src):
        os.makedirs(dst, exist_ok=True)
        for child in sorted(os.listdir(src)):
            replace_move(os.path.join(src, child), os.path.join(dst, child))
            count += 1
    return count

def rewrite_migrated_payload_paths():
    payload_dir = os.path.join(bus, "payloads")
    if not os.path.isdir(payload_dir):
        return
    for name in sorted(os.listdir(payload_dir)):
        if not name.endswith(".md"):
            continue
        path = os.path.join(payload_dir, name)
        if not os.path.isfile(path):
            continue
        with open(path) as fh:
            lines = fh.readlines()
        if not lines or lines[0].strip() != "---":
            continue
        end = None
        for i, line in enumerate(lines[1:], 1):
            if line.strip() == "---":
                end = i
                break
        if end is None:
            continue
        for i in range(1, end):
            if lines[i].startswith("path:"):
                # Migration moves the canonical bus home; rewrite bus-owned path
                # metadata so doctor reserves EXTERNAL-PATH for true external payloads.
                newline = "\r\n" if lines[i].endswith("\r\n") else "\n"
                new_line = f"path: {path}{newline}"
                if lines[i] != new_line:
                    lines[i] = new_line
                    with open(path, "w") as fh:
                        fh.writelines(lines)
                break

# Migration moves the bus home, so bus-owned directories come along. Reset is
# different by design: it keeps the same home and preserves input-backups live.
payloads = move_children("payloads")
rewrite_migrated_payload_paths()
receipts = move_children("receipts")
drafts = move_children("drafts")
input_backups = move_children("input-backups")
staging = move_children("tmp")
registry = 0
legacy_registry = os.path.join(legacy, "registry.json")
target_registry = os.path.join(bus, "registry.json")
if os.path.exists(legacy_registry):
    if os.path.exists(target_registry):
        with open(target_registry) as fh:
            target = json.load(fh)
        with open(legacy_registry) as fh:
            old = json.load(fh)
        merged = dict(old)
        merged.update(target)
        merged["agents"] = {**(old.get("agents") or {}), **(target.get("agents") or {})}
        if "team" not in target and "team" in old:
            merged["team"] = old["team"]
        d = os.path.dirname(target_registry)
        fd, tmp = tempfile.mkstemp(dir=d, prefix=".tap.")
        with os.fdopen(fd, "w") as fh:
            json.dump(merged, fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.replace(tmp, target_registry)
        os.remove(legacy_registry)
    else:
        replace_move(legacy_registry, target_registry)
    registry = 1
lock_dropped = 0
legacy_lock = os.path.join(legacy, "registry.json.lock")
if os.path.exists(legacy_lock):
    os.remove(legacy_lock)
    lock_dropped = 1
# tap-ncd4 (sol-pinnacle, round 4): the authority marker is a top-level bus
# file, not a named child move_children() knows about — left in place, it
# strands legacy_has_any_state() forever, since nothing else in this script
# ever clears it and a stamped legacy bus can never finish migrating. It is
# DISCARDED, never moved: the destination bus was already freshly stamped by
# tap_ensure_dirs before migrate_once ever runs, so migrating an old marker
# byte-for-byte would only overwrite a newer, correct one with an older one.
authority_discarded = 0
legacy_authority = os.path.join(legacy, ".tap-bus-authority")
if os.path.lexists(legacy_authority):
    os.remove(legacy_authority)
    authority_discarded = 1
print(
    f"payloads={payloads} receipts={receipts} drafts={drafts} "
    f"input-backups={input_backups} tmp={staging} "
    f"registry={registry} registry_lock_dropped={lock_dropped} "
    f"authority_discarded={authority_discarded}"
)
PY
  rmdir "$legacy/payloads" "$legacy/receipts" "$legacy/drafts" "$legacy/input-backups" "$legacy/tmp" "$legacy" "$ROOT/tmp" 2>/dev/null || true
}

# WAVE 6.11 / sol: ONE exhaustive marker sample BEFORE any authority
# migration/write. Only exact `absent` licenses pre-cutover registry migrate/
# ensure; `live` uses resolve_team_registry_for_root; `invalid`/unknown refuse
# with zero registry.json creation.
_init_marker="$(tap_registry_v20_state 2>/dev/null)" || _init_marker=""
case "$_init_marker" in
  absent|live) ;;
  invalid)
    tap_fail 1 invalid_flip "tap doctor" \
      "tap init refused — global-registry.json is present but unreadable or wrong schema"
    ;;
  *)
    tap_fail 1 invalid_flip "tap doctor" \
      "tap init refused — could not read flip marker; refusing authority writes"
    ;;
esac

migrated=0
late=0
primary_counts="payloads=0 receipts=0 drafts=0 input-backups=0 tmp=0 registry=0 registry_lock_dropped=0"
late_counts="payloads=0 receipts=0 drafts=0 input-backups=0 tmp=0 registry=0 registry_lock_dropped=0"

# Post-flip authority path shared by the live arm and by absent→live races
# (WAVE 6.12 ITEM 5). Never writes the retired bus registry.
init_apply_postflip_authority() {
  # POST-FLIP AUTHORITY IS INDEX AUTHORITY, so a root the index cannot hold has
  # none to apply. The gate stays AHEAD of the helper even though the helper is
  # self-gated and live_unenrolled now delegates every write to it (U1): the
  # helper REFUSES a non-indexable root, and surfacing that through
  # live_unenrolled would turn a legitimate local-bus init into an init
  # failure. The incident that added this gate was the cross-boundary write
  # from the then-inline writer, caught by this PR's own already-live non-git
  # control (sol-pinnacle-3 P1; the fix for it was incomplete until here).
  #
  # Returning 0 rather than failing: a non-indexable root is not an error, it is
  # a root that keeps its LOCAL bus and never appears in the machine index,
  # exactly as CONTRACT:454/:565 describe. init's own bus creation already ran.
  tap_index_root_indexable "$ROOT" || return 0
  _init_resolve="$(
    python3 -B - "$ROOT" "$DIR" <<'PY'
import sys
sys.path.insert(0, sys.argv[2])
from registry_v20 import resolve_team_registry_for_root
st, path = resolve_team_registry_for_root(sys.argv[1])
sys.stdout.write(f"{st}\t{path or ''}")
PY
  )"
  _init_status="$(printf '%s' "$_init_resolve" | cut -f1)"
  _init_loc="$(printf '%s' "$_init_resolve" | cut -f2)"
  case "$_init_status" in
    live)
      # Already-enrolled: acting authority is final. Ensure metadata only —
      # never re-import seats from the retired bus mirror (WAVE 6.12 / sol
      # 133035Z: repeat init must not recreate unregistered seats).
      [ -n "$_init_loc" ] && [ -f "$_init_loc" ] \
        || tap_fail 1 registry_unreachable "tap doctor" \
          "post-flip tap init: enrolled root resolved live but location missing"
      tap_registry_ensure_team "$_init_loc" "$ROOT" "$BRANCH"
      ;;
    live_unreachable)
      # tap-w3op / sol #xxx: recreate at STORED registry_location with the
      # enrolled global key (not basename(root) — alias≠basename). Pane-less
      # / TMUX-unset safe; does not require tap in.
      _init_canon="$(cd "$ROOT" 2>/dev/null && pwd -P || printf '%s' "$ROOT")"
      _init_acting="${_init_loc:-}"
      [ -n "$_init_acting" ] \
        || tap_fail 1 registry_unreachable "tap doctor" \
          "post-flip tap init: live_unreachable but no stored registry_location for '$ROOT'"
      _init_name="$(
        python3 -B - "$_init_canon" "$DIR" <<'PY'
import sys
sys.path.insert(0, sys.argv[2])
from registry_v20 import enrolled_team_name_for_root
st, name = enrolled_team_name_for_root(sys.argv[1])
print(name if st == "ok" and name else "")
PY
      )"
      [ -n "$_init_name" ] || _init_name="$(basename "$_init_canon")"
      tap_valid_token "$_init_name" \
        || tap_fail 1 registry_unreachable "tap doctor" \
          "post-flip tap init: cannot mint blank registry — invalid team token '$_init_name'"
      tap_ensure_empty_team_registry "$_init_acting" "$_init_name" "$_init_canon" \
        || tap_fail 1 registry_unreachable "tap doctor" \
          "post-flip tap init failed to recreate blank acting team-registry at '$_init_acting'"
      tap_registry_ensure_team "$_init_acting" "$ROOT" "$BRANCH"
      unset _init_canon _init_acting _init_name
      ;;
    live_unenrolled)
      # The helper owns the complete first-entry sequence -- eligibility,
      # canonical bus dirs, empty acting store, bus fold, enrollment (U1,
      # tap-q4fw5/tap-moa6x). The former inline writer
      # (tap_registry_ensure_team + mkdir + explicit fold) is gone: it created
      # the legacy `agents` axis before the schema-0.20 creator could run,
      # which is exactly the divergence this unit removes.
      tap_bootstrap_postflip_enroll "$ROOT" \
        || tap_fail 1 registry_unreachable "tap doctor" \
          "post-flip tap init failed to bootstrap/enroll acting team-registry for '$ROOT'"
      ;;
    *)
      tap_fail 1 registry_unreachable "tap doctor" \
        "post-flip tap init refused (status=$_init_status) — not creating or repointing authority"
      ;;
  esac
  unset _init_resolve _init_status _init_loc
}

# WAVE 6.12 ITEM 5 / sol 133327Z: fence absent bus-authority ensure under
# teams.json.lock with in-lock marker re-sample. Still-absent → ensure bus
# WHILE LOCKED, then enroll outside the lock (enroll acquires the same sidecar).
# Live at the in-lock sample → post-flip path, never write bus authority.
init_fence_absent_bus_ensure() {
  local _idx _err _rc=0
  _idx="$(tap_index_file)"
  mkdir -p "$(dirname "$_idx")"
  _err="$(mktemp "${TMPDIR:-/tmp}/tap-init-fence.XXXXXX")"
  TAP_INIT_FENCE_LIB="$DIR/lib.sh" \
  TAP_INIT_FENCE_SCRIPTS="$DIR" \
  TAP_INIT_FENCE_REGISTRY="$TAP_REGISTRY" \
  TAP_INIT_FENCE_ROOT="$ROOT" \
  TAP_INIT_FENCE_INDEXABLE="$(tap_index_root_indexable "$ROOT" && echo 1 || echo 0)" \
  TAP_INIT_FENCE_BRANCH="$BRANCH" \
  TAP_HOME="$TAP_HOME" \
  TAP_INDEX_HOME="${TAP_INDEX_HOME:-}" \
  python3 -B - "$_idx" 2>"$_err" <<'PY' || _rc=$?
import fcntl, json, os, subprocess, sys

sys.path.insert(0, os.environ["TAP_INIT_FENCE_SCRIPTS"])
from registry_v20 import flip_marker_state

idx = sys.argv[1]
index_home = os.environ.get("TAP_INDEX_HOME") or os.path.dirname(idx) or "."
os.makedirs(os.path.dirname(idx) or ".", exist_ok=True)
lock_path = idx + ".lock"
with open(lock_path, "a+") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    state = flip_marker_state(index_home)
    if state == "invalid":
        print("invalid_flip", file=sys.stderr)
        sys.exit(4)
    # BORN LIVE, decided at the FENCE rather than later at enrollment.
    #
    # This fence picks which acting store `tap init` creates. A machine holding
    # NEITHER store is new, not pre-flip -- see CONTRACT's global-registry
    # bullet. Deciding that only at enroll time is too late: init would already
    # have created the RETIRED bus registry below, and the live enrollment would
    # then name it as registry_location, which lib.sh:5792 forbids outright
    # ("post-flip must never enroll the retired bus file"). sol-pinnacle-3 found
    # exactly that on the first cut of this unit.
    #
    # Publishing the marker here instead routes init into its existing
    # `live_unenrolled` branch, which already creates the canonical acting
    # store, folds any bus/legacy seats into it, and enrolls. No new transition
    # logic -- this only puts a fresh machine on the path that already exists.
    # RULE 38, by OPERATOR: a legacy STORE is a regular file. `exists` would
    # treat a directory at teams.json as one and keep a fresh machine pre-flip.
    # The SAME eligibility the enroller uses: a root the index cannot hold has
    # no post-flip existence, so flipping it manufactures a state
    # tap_index_enroll_team would refuse to record. Outside the predicate this
    # fence keeps its established pre-flip behaviour, exactly as on main.
    # RULE 19: the predicate answers 0 on any failure to resolve, so an
    # unreadable root stays pre-flip rather than flipping on a guess.
    indexable = os.environ.get("TAP_INIT_FENCE_INDEXABLE") == "1"
    if indexable and state == "absent" and not os.path.isfile(idx):
        from registry_v20 import empty_global_registry, global_registry_path
        gpath = global_registry_path(index_home)
        os.makedirs(os.path.dirname(gpath) or ".", exist_ok=True)
        tmp = gpath + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(empty_global_registry(), fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.replace(tmp, gpath)
        # Re-ask the instrument rather than assuming the write landed live.
        state = flip_marker_state(index_home)
        if state != "live":
            print("invalid_flip", file=sys.stderr)
            sys.exit(4)
    if state == "live":
        print("flip_live", file=sys.stderr)
        sys.exit(17)
    # still absent — ensure bus registry WHILE holding teams.json.lock
    cmd = (
        "set -euo pipefail; "
        ". \"$TAP_INIT_FENCE_LIB\"; "
        "tap_registry_ensure_team "
        "\"$TAP_INIT_FENCE_REGISTRY\" \"$TAP_INIT_FENCE_ROOT\" \"$TAP_INIT_FENCE_BRANCH\""
    )
    proc = subprocess.run(["bash", "-c", cmd], env=os.environ.copy())
    sys.exit(proc.returncode if proc.returncode != 0 else 0)
PY
  _detail="$(cat "$_err" 2>/dev/null || true)"
  rm -f "$_err"
  case "$_rc" in
    0) return 0 ;;   # bus ensured under lock; caller enrolls outside
    17) return 17 ;; # live — caller takes post-flip path (no bus write)
    4) tap_fail 1 invalid_flip "tap doctor" \
         "global-registry.json is present but unreadable or wrong schema${_detail:+ ($_detail)}" ;;
    *) die "tap init: absent authority fence failed${_detail:+ ($_detail)}" ;;
  esac
}

case "$_init_marker" in
  live)
    # Bus dirs + legacy migrate for payloads/receipts; registry seats fold into
    # acting authority (WAVE 6.11 / 3682836481) — never enroll an empty acting
    # while alice remains only on the retired bus copy.
    tap_ensure_dirs
    if legacy_has_any_state; then
      primary_counts="$(migrate_once)"
      migrated=1
    fi
    if [ -n "${TAP_INIT_LATE_WRITE_HOOK:-}" ]; then
      "$TAP_INIT_LATE_WRITE_HOOK" "$ROOT"
    fi
    if legacy_has_any_state; then
      late_counts="$(migrate_once)"
      migrated=1
      late=1
    fi
    init_apply_postflip_authority
    [ "$migrated" = 0 ] || rm -f "$TAP_REGISTRY.lock"
    ;;
  absent)
    tap_ensure_dirs
    if legacy_has_any_state; then
      primary_counts="$(migrate_once)"
      migrated=1
    fi
    if [ -n "${TAP_INIT_LATE_WRITE_HOOK:-}" ]; then
      "$TAP_INIT_LATE_WRITE_HOOK" "$ROOT"
    fi
    if legacy_has_any_state; then
      late_counts="$(migrate_once)"
      migrated=1
      late=1
    fi
    _init_fence_rc=0
    init_fence_absent_bus_ensure || _init_fence_rc=$?
    case "$_init_fence_rc" in
      0)
        # Still absent at the locked sample — bus registry is durable; enroll
        # OUTSIDE teams.json.lock (tap_index_enroll_team acquires it itself).
        tap_index_enroll_team "$ROOT"
        ;;
      17)
        # Marker published mid-command — never write bus authority; bootstrap
        # acting via the live/live_unenrolled path.
        init_apply_postflip_authority
        ;;
      *)
        # init_fence_absent_bus_ensure already tap_fail/die'd for other codes
        tap_fail 1 registry_unreachable "tap doctor" \
          "tap init absent authority fence returned unexpected status $_init_fence_rc"
        ;;
    esac
    unset _init_fence_rc
    [ "$migrated" = 0 ] || rm -f "$TAP_REGISTRY.lock"
    ;;
esac
unset _init_marker

if [ "$late" != 1 ] && ! legacy_has_any_state && [ "${TAP_SETUP_REPO_PENDING:-}" != 1 ]; then
  tap_bun_call first-run "$ROOT" first-run.ts "$ROOT" --ensure "$IN_GIT" || true
fi

# --json: one object on stdout. A late-write / remaining-state failure must NOT also
# emit a success object, so the success path only fires when both checks pass; the
# tap_fail calls below render their own error JSON under TAP_JSON=1.
if [ "$TAP_JSON" = 1 ]; then
  if [ "$late" != 1 ] && ! legacy_has_any_state; then
    python3 -B - "$ROOT" "$TAP_HOME" "$IN_GIT" "$migrated" "$late" "$primary_counts" "$late_counts" <<'PY'
import json, os, sys
root, bus, in_git, migrated, late, primary_counts, late_counts = sys.argv[1:8]
def parse_counts(s):
    out = {}
    for tok in (s or "").split():
        if "=" in tok:
            k, v = tok.split("=", 1)
            try:
                out[k] = int(v)
            except ValueError:
                out[k] = v
    return out or None
# team.name is authoritative from the registry; fall back to the root basename.
team_name = ""
try:
    reg = json.load(open(os.path.join(bus, "registry.json")))
    team_name = (reg.get("team") or {}).get("name", "") or ""
except Exception:
    pass
if not team_name:
    team_name = root.rstrip("/").split("/")[-1]
obj = {
    "ok": True,
    "team": {"name": team_name, "root": root},
    "bus": bus,
    "in_git": in_git == "1",
    "migrated": migrated == "1",
    "primary_counts": parse_counts(primary_counts) if migrated == "1" else None,
    "late": late == "1",
    "late_counts": parse_counts(late_counts) if late == "1" else None,
}
print(json.dumps(obj, separators=(",", ":")))
PY
    exit 0
  fi
else
  echo "tap init: initialized team '$(basename "$ROOT")' at $ROOT"
  echo "tap init: bus=$TAP_HOME"
  if [ "$migrated" = 1 ]; then
    echo "tap init: migrated legacy bus from $legacy ($primary_counts)"
  fi
fi
# U7 detect-only: never auto-flip. Name the sole operator migrator when pre-flip
# stores are still the authority (teams.json present, global-registry absent/not-live).
if ! tap_registry_v20_live 2>/dev/null; then
  if [ -f "$(tap_index_file)" ]; then
    echo "tap init: pre-v0.20 registry stores detected — cut over with: tap admin migrate-registry --yes" >&2
  fi
fi
if [ "$late" = 1 ]; then
  tap_fail 1 late_legacy_writes "rerun tap init" "late legacy writes detected and moved ($late_counts); rerun after old clients stop writing tmp/tap"
fi
if legacy_has_any_state; then
  tap_fail 1 legacy_state_remaining "rerun tap init" "legacy bus still has unmigrated state at $legacy"
fi
