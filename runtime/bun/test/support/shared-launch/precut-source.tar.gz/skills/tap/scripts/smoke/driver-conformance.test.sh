#!/usr/bin/env bash
# driver-conformance.test.sh — the per-driver conformance suite (TAP 1.0, tap-49kp6).
#
# Parameterized by driver name. It runs against SIMULATORS, never live harnesses:
# each fixture driver implements the record shapes a real door DECLARES, so the
# gate proves the dispatcher's contract rather than a vendor's uptime.
#
# The fixture that matters most is `silentdrop`: a driver that returns success
# from a door that delivered nothing, with an evidence ceiling of api-accepted.
# It is the shape every native driver will have, and it is the shape that would
# quietly turn a lost message into a settled one. This file was written RED
# against it first — with the ceiling cap removed, arm (c) fails — and the red
# output is cited in the PR body. The conformance suite's job is to make that
# failure mechanical instead of a review catch.
#
# Arms:
#   (a) the tmux driver's rc -> (disposition, effect, tier) table, byte-exact
#   (b) `delivered` requires a positive tier of the driver's ceiling class:
#       a driver declaring an honest ceiling but emitting tier `none` is capped
#   (c) CEILING CAP: a silent-drop driver with an api-accepted ceiling cannot
#       record `delivered` however loudly it claims success
#   (d) no settlement side effect: a driver never writes .done/.sent/.cancelled
#   (e) the attempt record is written even when the attempt FAILED — §3.6's
#       discharge has to cite this log, and its red case is an unattempted rung
#   (f) tier vocabulary: tmux emits only its own three words
#   (g) rc6 stays CONSERVATIVE — an identity failure can follow a sent Enter
#   (h) the result channel annotates, never decides: a driver may refine its own
#       tier/detail/native_ref, and may NOT set its own disposition or effect
#   (i) a NATIVE driver with no outcome table fails closed — it never borrows
#       tmux's evidence, because a typo must not manufacture a delivery claim,
#       and since the driver already RAN the attempt is recorded, not erased
#   (j) a native driver that calls `exit` kills the ATTEMPT, not the courier,
#       and the attempt record is still written
#   (m2) the SIBLING path: a bare `exit` and `exit 0` reach the same outcome as
#        `exit 3` but pass a status-only canary
#   (m3) SUCCESSFUL load-time mutations (set +e, cd) replay on the live source —
#        the canary must compare STATE, not just survive; with a mirror proving a
#        well-behaved module still loads
#   (n) the outcome tuple is validated, never trusted — retry-next-rung REQUIRES
#       effect:none — with a mirror proving legal tuples survive
#   (m) the same, for an `exit` at LOAD time — the deliver() subshell does not
#       cover sourcing, so a canary source in a throwaway subshell does
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
LIB="$ROOT/skills/tap/scripts/lib.sh"
TAP_HOME="$(mktemp -d)"
DRIVER_DIR="$(mktemp -d)"
trap 'rm -rf "$TAP_HOME" "$DRIVER_DIR"' EXIT
export TAP_HOME TAP_DRIVER_DIR="$DRIVER_DIR"

mkdir -p "$TAP_HOME/payloads" "$TAP_HOME/receipts"

# The driver preference is read from the operator config at DELIVERY time, so the
# fixture supplies a real one rather than reaching past the reader. Pointing
# XDG_CONFIG_HOME at a sandbox is also what keeps a suite run from reading the
# operator's own machine file.
XDG_CONFIG_HOME="$TAP_HOME/config"; export XDG_CONFIG_HOME
mkdir -p "$XDG_CONFIG_HOME/tap"
config_write() { cat > "$XDG_CONFIG_HOME/tap/config.toml"; }

# shellcheck disable=SC1090
. "$LIB"

# WIRING OVERRIDE. `tap_driver_wired_list` is a code fact with no environment
# seam (sol-pinnacle showed an env-settable set reopened the wrong-transport
# failure the gate closes), so a suite that needs fixture drivers selectable
# redefines the FUNCTION after sourcing. That ships nothing: the override
# lives in this file, not in lib.sh.
# This suite tests the DISPATCHER; every name below is a fixture whose argv tail it supplies itself.
tap_driver_wired_list() { printf %s 'alwaysfail badtuple delivnone disarm exiter liar loadbomb loudload overreach overreacher understater polite silentdrop tableless tierless wander zerobomb tmux'; }

fail() { echo "driver-conformance: $*" >&2; exit 1; }

# --- fixture: the silent-drop driver ------------------------------------------
# Its door is unreachable. It returns 0 anyway and declares `delivered`, because that is
# what an API that accepted a call and dropped the message looks like from the
# inside. Its ceiling is api-accepted — the honest one — and the ceiling is what
# has to stop it.
cat > "$DRIVER_DIR/silentdrop.sh" <<'ENDDRV'
tapdrv_silentdrop_deliver() { return 0; }
tapdrv_silentdrop_ceiling() { printf 'api-accepted'; }
tapdrv_silentdrop_outcome() { printf 'delivered\x1fpossible\x1fapi-accepted'; }
ENDDRV

# A driver whose ceiling is honest but whose record observed nothing.
# THE MISMATCHED PAIR: two drivers whose ceiling and tier are BOTH in the
# verified-submission class, but are not each other. Class membership alone would
# let both through; only an identity check catches them (sol-pinnacle, #xxx).
#   overreacher — declares left-input-band, records transcript-match: claims an
#                 observation over an API it never opens.
#   understater — declares transcript-match, records left-input-band: claims to
#                 have watched a pane it never reads.
# Both are the attempt log stating the driver saw what it structurally cannot.
cat > "$DRIVER_DIR/overreacher.sh" <<'ENDDRV'
tapdrv_overreacher_deliver() { return 0; }
tapdrv_overreacher_ceiling() { printf 'left-input-band'; }
tapdrv_overreacher_outcome() { printf 'delivered\x1fpossible\x1ftranscript-match'; }
ENDDRV
cat > "$DRIVER_DIR/understater.sh" <<'ENDDRV'
tapdrv_understater_deliver() { return 0; }
tapdrv_understater_ceiling() { printf 'transcript-match'; }
tapdrv_understater_outcome() { printf 'delivered\x1fpossible\x1fleft-input-band'; }
ENDDRV

# The LIAR: an api-accepted door claiming a tmux observation it structurally
# cannot make. This fixture exists because of a mutation result, not a hunch —
# removing the CEILING half of the cap left the whole suite green, since every
# other fixture is also caught by the tier half. Two independent gates need two
# independent reds, or one of them is decoration.
cat > "$DRIVER_DIR/liar.sh" <<'ENDDRV'
tapdrv_liar_deliver() { return 0; }
tapdrv_liar_ceiling() { printf 'api-accepted'; }
tapdrv_liar_outcome() { printf 'delivered\x1fpossible\x1fleft-input-band'; }
ENDDRV

cat > "$DRIVER_DIR/tierless.sh" <<'ENDDRV'
tapdrv_tierless_deliver() { return 0; }
tapdrv_tierless_ceiling() { printf 'left-input-band'; }
tapdrv_tierless_outcome() { printf 'delivered\x1fpossible\x1fnone'; }
ENDDRV

payload="$TAP_HOME/payloads/conf-1.md"
printf 'body\n' > "$payload"

# --- (a) the tmux mapping table, byte-exact -----------------------------------
# Pinned as data, not as behavior: if anyone reorders tap_submit_verify's guards
# and an rc changes meaning, this table has to be edited deliberately.
expect_map() { # <rc> <disposition> <effect> <tier>
  local got want="$2"$'\x1f'"$3"$'\x1f'"$4"
  got="$(tapdrv_tmux_outcome "$1")"
  [ "$got" = "$want" ] || fail "(a) rc=$1 mapped to '$(printf '%s' "$got" | tr '\037' '/')', expected '$(printf '%s' "$want" | tr '\037' '/')'"
}
expect_map 0 delivered       possible left-input-band
expect_map 3 stop-ambiguous  possible none
expect_map 4 retry-next-rung none     none
expect_map 5 stop-ambiguous  possible none
expect_map 6 stop-ambiguous  possible none
echo "driver-conformance: (a) tmux rc -> (disposition, effect, tier) table pinned: ok"

# --- (b) delivered requires a positive tier -----------------------------------
capped="$(tap_driver_cap_disposition left-input-band none delivered)"
[ "$capped" = stop-ambiguous ] || fail "(b) delivered/none was not capped; got '$capped'"
kept="$(tap_driver_cap_disposition left-input-band left-input-band delivered)"
[ "$kept" = delivered ] || fail "(b) an honest verified submission was wrongly capped; got '$kept'"
echo "driver-conformance: (b) delivered requires a positive ceiling-class tier: ok"

# --- (c) THE CEILING CAP — the silent-drop arm --------------------------------
config_write <<'ENDCFG'
[harness.claude]
driver = "silentdrop"
ENDCFG
rc=0
tap_driver_deliver "$payload" conf-1 queue claude >/dev/null 2>&1 || rc="$?"
[ "$rc" = 0 ] || fail "(c) the silent-drop driver did not return its own rc; got $rc"
[ "$TAP_DRIVER_LAST_DRIVER" = silentdrop ] || fail "(c) dispatcher routed to '$TAP_DRIVER_LAST_DRIVER'"
[ "$TAP_DRIVER_LAST_DISPOSITION" = stop-ambiguous ] || \
  fail "(c) a ceiling of api-accepted recorded '$TAP_DRIVER_LAST_DISPOSITION' — a dropped message would read as delivered"
[ "$TAP_DRIVER_LAST_TIER" = api-accepted ] || fail "(c) tier was rewritten to '$TAP_DRIVER_LAST_TIER'; the cap is on the DISPOSITION, never the observation"
echo "driver-conformance: (c) an api-accepted ceiling cannot record delivered: ok"

config_write <<'ENDCFG'
[harness.claude]
driver = "tierless"
ENDCFG
rc=0
tap_driver_deliver "$payload" conf-1 queue claude >/dev/null 2>&1 || rc="$?"
[ "$TAP_DRIVER_LAST_DISPOSITION" = stop-ambiguous ] || \
  fail "(c) an honest ceiling with tier none recorded '$TAP_DRIVER_LAST_DISPOSITION'"
echo "driver-conformance: (c) an honest ceiling with no observation is capped too: ok"

# The ceiling gate on its own. A driver that declares api-accepted and then
# reports a verified-submission observation is not a weaker claim than its
# ceiling — it is a claim its door cannot support, which is the shape of every
# silent drop that ever got read as a delivery. Only the CEILING check catches
# this one; the tier check passes it.
config_write <<'ENDCFG'
[harness.claude]
driver = "liar"
ENDCFG
rc=0
tap_driver_deliver "$payload" conf-1 queue claude >/dev/null 2>&1 || rc="$?"
[ "$TAP_DRIVER_LAST_DISPOSITION" = stop-ambiguous ] || \
  fail "(c) a driver claiming an observation above its declared ceiling recorded '$TAP_DRIVER_LAST_DISPOSITION'"
echo "driver-conformance: (c) a tier above the declared ceiling is capped: ok"

# Both directions of the mismatch. Neither driver is claiming evidence ABOVE the
# class — both tiers are verified-submission members — so a membership test lets
# them through. Only tier == ceiling catches them.
for drv in overreacher understater; do
  cat > "$XDG_CONFIG_HOME/tap/config.toml" <<ENDCFG
[harness.claude]
driver = "$drv"
ENDCFG
  # ASSERT THE DISPATCH HAPPENED BEFORE READING ITS RESULT. sol-pinnacle, #xxx:
  # neither name was in the wired override above, so BOTH dispatches refused
  # before load -- and because the failure was swallowed by `|| true`, the arm
  # then read the PREVIOUS case's `stop-ambiguous` global and passed. The most
  # load-bearing arm in this file was asserting a leftover variable.
  #
  # A disposition read after an ignored failure is not a result, it is whatever
  # was left over. So the driver must be confirmed selected and loaded first.
  TAP_DRIVER_LAST_DISPOSITION=""
  TAP_DRIVER_LAST_DRIVER=""
  tap_driver_deliver "$payload" conf-1 queue claude >/dev/null 2>&1 || true
  [ "$TAP_DRIVER_LAST_DRIVER" = "$drv" ] || \
    fail "(c) driver '$drv' was never dispatched (selected: '${TAP_DRIVER_LAST_DRIVER:-none}'); the cap was not exercised at all"
  [ -n "$TAP_DRIVER_LAST_DISPOSITION" ] || \
    fail "(c) driver '$drv' produced no disposition; the arm would be reading a stale global"
  [ "$TAP_DRIVER_LAST_DISPOSITION" = stop-ambiguous ] || \
    fail "(c) driver '$drv' recorded '$TAP_DRIVER_LAST_DISPOSITION' with a tier that is not its declared ceiling"
  # AND THE TIER SURVIVES. grok, #xxx: the identity pair asserted the disposition
  # and not the evidence, while the silent-drop sibling in this same block does
  # assert it. A cap that quietly rewrote the recorded tier to match the ceiling
  # would green the disposition check and destroy the very record the cap exists
  # to keep honest -- correcting the evidence to fit the routing decision, which
  # is the inversion this whole layer forbids.
  case "$drv" in
    overreacher) _want_tier=transcript-match ;;
    understater) _want_tier=left-input-band ;;
  esac
  # READ THIS DISPATCH'S ROW, NOT THE WHOLE FILE. grok, #xxx: `(c)` reuses one
  # payload and attempts APPEND, so an earlier fixture in this same block (`liar`)
  # has already written a `left-input-band` row. A whole-file `grep -q` for
  # understater's tier therefore matched a leftover and could not fail -- the
  # identical leftover-evidence bug as the wired-name false green, one file over,
  # and it was in the assertion I had just added to close a coverage gap.
  #
  # The last line is this dispatch. A grep over an append-only log is how a
  # leftover survives a check written to catch exactly that.
  _got_tier="$(tail -1 "${payload%.md}.attempts" | sed -n 's/.*"tier":"\([^"]*\)".*/\1/p')"
  [ "$_got_tier" = "$_want_tier" ] || \
    fail "(c) driver '$drv' recorded tier '$_got_tier', expected '$_want_tier'; the cap must correct the DISPOSITION and never the evidence"
done
echo "driver-conformance: (c) a verified tier that is not the driver's OWN ceiling is capped, both directions: ok"

# --- (d) no settlement side effect --------------------------------------------
for suffix in done sent cancelled; do
  found="$(find "$TAP_HOME/receipts" -maxdepth 1 -name "*.$suffix" | wc -l | tr -d ' ')"
  [ "$found" = 0 ] || fail "(d) a driver wrote $found .$suffix receipt(s); settlement is not a driver's to write (I-1)"
done
echo "driver-conformance: (d) no driver wrote a settlement receipt: ok"

# --- (e) a failed attempt is still recorded -----------------------------------
cat > "$DRIVER_DIR/alwaysfail.sh" <<'ENDDRV'
tapdrv_alwaysfail_deliver() { return 4; }
tapdrv_alwaysfail_ceiling() { printf 'api-accepted'; }
tapdrv_alwaysfail_outcome() { printf 'retry-next-rung\x1fnone\x1fnone'; }
ENDDRV
failed="$TAP_HOME/payloads/conf-2.md"
printf 'body\n' > "$failed"
config_write <<'ENDCFG'
[harness.claude]
driver = "alwaysfail"
ENDCFG
rc=0
tap_driver_deliver "$failed" conf-2 queue claude >/dev/null 2>&1 || rc="$?"
[ "$rc" = 4 ] || fail "(e) the dispatcher rewrote the driver's rc: got $rc, expected 4"
log="${failed%.md}.attempts"
[ -f "$log" ] || fail "(e) a failed attempt wrote no record — an exhaustion audit cannot tell it from an unattempted rung (§3.6)"
python3 - "$log" <<'PY' || exit 1
import json, sys
rows = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
assert len(rows) == 1, rows
r = rows[0]
for k in ("payload_id","seq","rung","op","driver","class","disposition","effect","tier","detail","ts_start","ts_end"):
    assert k in r, f"attempt record is missing '{k}': {r}"
assert r["disposition"] == "retry-next-rung", r
assert r["effect"] == "none", r
assert r["op"] == "deliver", r
assert r["seq"] == "1", r
PY
echo "driver-conformance: (e) a failed attempt is recorded with the full field set: ok"

# The seq is per-payload monotonic — it is the record key, so a second attempt
# must not overwrite the first.
tap_driver_deliver "$failed" conf-2 queue claude >/dev/null 2>&1 || true
[ "$(wc -l < "$log" | tr -d ' ')" = 2 ] || fail "(e) a second attempt did not append"
python3 - "$log" <<'PY' || exit 1
import json, sys
rows = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
assert [r["seq"] for r in rows] == ["1", "2"], rows
PY
echo "driver-conformance: (e) attempt seq is per-payload monotonic and append-only: ok"

# --- (f) tier vocabulary -------------------------------------------------------
# tmux may emit only its own observation names. `rendered-in-pane`, `socket-acked`
# and `api-accepted` are native-driver words; a tmux driver emitting one would be
# claiming an observation it structurally cannot make.
for rc in 0 3 4 5 6 99; do
  tier="$(tapdrv_tmux_outcome "$rc" | cut -d$'\x1f' -f3)"
  case "$tier" in
    left-input-band|in-input-band|none) ;;
    *) fail "(f) the tmux driver emitted tier '$tier' on rc=$rc, outside its declared vocabulary" ;;
  esac
done
echo "driver-conformance: (f) tmux tier vocabulary is closed: ok"

# --- (g) rc6 is pre-effect by construction ------------------------------------
# rc6 maps to stop-ambiguous/possible. An earlier draft mapped it to
# retry-next-rung/none on the premise that every rc6 site is a pre-inject guard;
# sol-pinnacle REPRODUCED the counterexample (rc=6 effects=1 guard_calls=2). The
# identity guard re-runs inside tap_submit_existing_verify's Enter retry loop, and
# the stuck-sentinel call sites pass identity_rc=6 — so a `6` can carry a sent
# Enter behind it, and a retry-safe row would let a router retry it.
# The argument is POSITIONAL (9th of tap_submit_existing_verify's argv), so the
# check reads that position rather than grepping for a `5` anywhere on the line —
# a `5` in some other slot would satisfy a loose grep while the premise is broken.
python3 -B "$(dirname "${BASH_SOURCE[0]}")/driver_rc6_premise.py" "$LIB" || \
  fail "(g) the rc6 row is no longer conservative, or its cause vanished (see above)"
# --- (h) the result channel annotates, never decides --------------------------
# A driver that could write its own disposition could write `delivered`, and the
# whole ceiling apparatus above would be advisory. This fixture tries: it writes
# every field, including the two that are not its to write.
cat > "$DRIVER_DIR/overreach.sh" <<'ENDDRV'
tapdrv_overreach_deliver() {
  {
    printf 'disposition=delivered\n'
    printf 'effect=none\n'
    printf 'tier=socket-acked\n'
    printf 'detail=door returned 200\n'
    printf 'native_ref=msg_abc123\n'
  } > "$TAP_DRIVER_RESULT_FILE"
  return 0
}
tapdrv_overreach_ceiling() { printf 'api-accepted'; }
tapdrv_overreach_outcome() { printf 'stop-ambiguous\x1fpossible\x1fapi-accepted'; }
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "overreach"
ENDCFG
over="$TAP_HOME/payloads/conf-3.md"
printf 'body\n' > "$over"
tap_driver_deliver "$over" conf-3 queue claude >/dev/null 2>&1 || true
[ "$TAP_DRIVER_LAST_DISPOSITION" = stop-ambiguous ] || \
  fail "(h) a driver set its own disposition to '$TAP_DRIVER_LAST_DISPOSITION' through the result file"
[ "$TAP_DRIVER_LAST_EFFECT" = possible ] || \
  fail "(h) a driver set its own effect to '$TAP_DRIVER_LAST_EFFECT' through the result file"
[ "$TAP_DRIVER_LAST_TIER" = socket-acked ] || \
  fail "(h) the driver's own tier refinement was dropped; got '$TAP_DRIVER_LAST_TIER'"
[ "$TAP_DRIVER_LAST_NATIVE_REF" = msg_abc123 ] || \
  fail "(h) native_ref did not survive; got '$TAP_DRIVER_LAST_NATIVE_REF'"
python3 - "${over%.md}.attempts" <<'ENDPYH'
import json, sys
r = [json.loads(l) for l in open(sys.argv[1]) if l.strip()][-1]
assert r["payload_id"] == "conf-3", r
assert r["native_ref"] == "msg_abc123", r
assert r["detail"] == "door returned 200", r
# I-5: the native id ANNOTATES. It is never the record's key.
assert r["payload_id"] != r["native_ref"], r
ENDPYH
echo "driver-conformance: (h) the result channel refines tier/detail/native_ref and cannot set disposition or effect: ok"

# --- (i) a native driver without an outcome table fails closed ----------------
# The dangerous version of this is not a crash. A driver defining deliver() and a
# verified-submission ceiling, but whose outcome function is MISNAMED, would fall
# back to tmux's table: rc 0 becomes `delivered` on the tmux-only tier
# `left-input-band` — a delivery claim, on evidence that driver never produced,
# manufactured by a typo. Fail closed instead: rc 2, the dispatcher's refusal.
cat > "$DRIVER_DIR/tableless.sh" <<'ENDDRV'
tapdrv_tableless_deliver() { return 0; }
tapdrv_tableless_ceiling() { printf 'transcript-match'; }
# NOTE: no tapdrv_tableless_outcome — this is the typo, spelled deliberately.
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "tableless"
ENDCFG
tableless="$TAP_HOME/payloads/conf-4.md"
printf 'body\n' > "$tableless"
rc=0
tap_driver_deliver "$tableless" conf-4 queue claude >/dev/null 2>&1 || rc="$?"
[ "$rc" = 2 ] || fail "(i) a native driver with no outcome table returned $rc, expected the dispatcher's refusal (2)"
[ "${TAP_DRIVER_UNAVAILABLE:-0}" = 0 ] || \
  fail "(i) a POST-RUN refusal set the pre-attempt unavailable flag; the caller would delete a canonical for a message that may have been delivered"
# The driver DID run — the missing table is discovered afterwards — so this is not
# a pre-attempt failure and it must leave the audit trail a post-effect attempt
# leaves. What we cannot do is CLASSIFY it, which is exactly `stop-ambiguous`.
[ -f "${tableless%.md}.attempts" ] || \
  fail "(i) a driver that RAN left no attempt record merely because its table was missing"
python3 - "${tableless%.md}.attempts" <<'ENDPYI'
import json, sys
r = [json.loads(l) for l in open(sys.argv[1]) if l.strip()][-1]
assert r["disposition"] == "stop-ambiguous", r
assert r["effect"] == "possible", r
assert r["tier"] == "none", r
ENDPYI
echo "driver-conformance: (i) a native driver with no outcome table fails closed, never borrowing tmux evidence: ok"

# --- (j) a native driver's `exit` kills the attempt, not the courier ----------
# Design §3.9: the plugin boundary fails as ONE ROUTE, never as routing itself.
# The failure this arm exists for is subtle — if the driver's exit propagated,
# the courier would die BEFORE the attempt record was written, leaving a payload
# with no audit line and an exhaustion check unable to distinguish it from a rung
# nobody tried. So this asserts both halves: we survive, AND the record exists.
cat > "$DRIVER_DIR/exiter.sh" <<'ENDDRV'
tapdrv_exiter_deliver() { exit 9; }
tapdrv_exiter_ceiling() { printf 'api-accepted'; }
tapdrv_exiter_outcome() { printf 'stop-ambiguous\x1fpossible\x1fnone'; }
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "exiter"
ENDCFG
exiter="$TAP_HOME/payloads/conf-5.md"
printf 'body\n' > "$exiter"
rc=0
tap_driver_deliver "$exiter" conf-5 queue claude >/dev/null 2>&1 || rc="$?"
echo "driver-conformance: (j) the courier survived a driver that called exit: ok"
[ "$rc" = 9 ] || fail "(j) the driver's exit status did not become the attempt's rc; got $rc"
[ -f "${exiter%.md}.attempts" ] || \
  fail "(j) a driver that exited left NO attempt record — an exhaustion audit cannot tell that from an unattempted rung"
python3 - "${exiter%.md}.attempts" <<'ENDPYJ'
import json, sys
r = [json.loads(l) for l in open(sys.argv[1]) if l.strip()][-1]
assert r["disposition"] == "stop-ambiguous", r
assert r["effect"] == "possible", r
ENDPYJ
echo "driver-conformance: (j) the attempt record survives the driver's exit: ok"

# --- (m) a top-level `exit` while SOURCING must not kill the courier ----------
# The subshell around deliver() does not cover the LOAD. A top-level exit in a
# module — or a syntax error, or a stray failing command — kills the courier
# while the file is being sourced, long before any delivery subshell exists.
# Design §3.9's answer is the canary source in a fresh subshell.
cat > "$DRIVER_DIR/loadbomb.sh" <<'ENDDRV'
tapdrv_loadbomb_ceiling() { printf 'api-accepted'; }
exit 3
tapdrv_loadbomb_deliver() { return 0; }
tapdrv_loadbomb_outcome() { printf 'delivered\x1fpossible\x1fapi-accepted'; }
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "loadbomb"
ENDCFG
bomb="$TAP_HOME/payloads/conf-6.md"
printf 'body\n' > "$bomb"
rc=0
tap_driver_deliver "$bomb" conf-6 queue claude >/dev/null 2>&1 || rc="$?"
# Reaching this line at all is half the assertion: if the load were not
# contained, this shell died at the `exit 3` above.
echo "driver-conformance: (m) the courier survived sourcing a module that exits: ok"
[ "$rc" = 2 ] || fail "(m) a module that exits mid-load returned $rc, expected the dispatcher's refusal (2)"
# The partial-definition case is why a canary beats `bash -n`: the file is
# syntactically valid, and its exit runs AFTER one function is defined and
# before the others. A syntax check says nothing about how far execution got.
declare -F tapdrv_loadbomb_deliver >/dev/null 2>&1 && \
  fail "(m) a refused module leaked its definitions into the courier's shell"
echo "driver-conformance: (m) a partially-defined module is refused and leaks nothing: ok"
# "Refused" and "never tried" are different facts. The canonical is correctly
# discarded (nothing reached the recipient), which takes the <id>.attempts file
# with it — so the durable record of the refusal lives in the registry event log,
# where supervision can still see that a rung was selected and refused.
grep -q "action=driver_load_refused.*driver=loadbomb" "$TAP_HOME/registry-events.log" 2>/dev/null || {
  echo "driver-conformance: (m) a load refusal left no durable record; supervision cannot tell it from an unattempted route" >&2
  cat "$TAP_HOME/registry-events.log" 2>&1 >&2 || true
  exit 1
}
echo "driver-conformance: (m) the refusal is durably recorded despite the canonical being discarded: ok"

# THE SIBLING PATH. `exit 3` and `exit 0` reach the same outcome — a module that
# defined nothing and will kill the courier — but only one of them fails a
# STATUS-based canary. The first version of arm (m) covered `exit 3` alone, so
# the guard looked proven while a bare `exit` walked straight past it.
for _bomb in 0 ""; do
  cat > "$DRIVER_DIR/zerobomb.sh" <<ENDDRV
tapdrv_zerobomb_ceiling() { printf 'api-accepted'; }
exit $_bomb
tapdrv_zerobomb_deliver() { return 0; }
tapdrv_zerobomb_outcome() { printf 'delivered\x1fpossible\x1fapi-accepted'; }
ENDDRV
  config_write <<'ENDCFG'
[harness.claude]
driver = "zerobomb"
ENDCFG
  zb="$TAP_HOME/payloads/conf-7.md"
  printf 'body\n' > "$zb"
  # THE PROBE RUNS IN A SUBSHELL, and that is not defensive style — it is what
  # makes this arm capable of failing. Without the guard under test, the module's
  # top-level `exit 0` propagates all the way out and terminates THIS SUITE with
  # status 0: every later arm is skipped and smoke-all records a pass. A test
  # that cannot survive the defect it hunts does not report it; it disappears
  # and takes the rest of the file with it. Measured, not assumed — that is
  # exactly what the mutant did before this line existed.
  rc=0
  ( tap_driver_deliver "$zb" conf-7 queue claude >/dev/null 2>&1 ) || rc="$?"
  [ "$rc" = 2 ] || fail "(m2) a module exiting with status '${_bomb:-<bare>}' was ACCEPTED by the canary (rc=$rc) — a status-only check cannot see a zero-status exit"
  declare -F tapdrv_zerobomb_deliver >/dev/null 2>&1 && \
    fail "(m2) a zero-status exit leaked definitions into the courier's shell"
  rm -f "${zb%.md}.attempts"
done
echo "driver-conformance: (m2) a bare exit and exit 0 are refused too, not just a nonzero one: ok"

# --- (m3) SUCCESSFUL mutations replay on the live source ----------------------
# grok's finding, and the sibling of (m2) one step out. (m2) covers modules that
# FAIL — an exit aborts the canary and leaves no marker. This covers modules that
# SUCCEED while changing the courier's state: the throwaway source discards the
# mutation, the canary sees a clean marker, and the LIVE source then applies it
# for real. Measured before the fix: `$-` went ehuB -> huB and pwd went the
# worktree -> /tmp, canary returning 0 both times.
#
# Each arm asserts the refusal AND that the courier's own state is intact
# afterwards, because "we refused it" and "it did not happen to us" are separate
# claims and only the second is the one that matters.
_opts_before="$-"
_pwd_before="$PWD"

cat > "$DRIVER_DIR/disarm.sh" <<'ENDDRV'
set +e
tapdrv_disarm_deliver() { return 0; }
tapdrv_disarm_ceiling() { printf 'api-accepted'; }
tapdrv_disarm_outcome() { printf 'delivered\x1fpossible\x1fapi-accepted'; }
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "disarm"
ENDCFG
dm="$TAP_HOME/payloads/conf-10.md"
printf 'body\n' > "$dm"
rc=0
( tap_driver_deliver "$dm" conf-10 queue claude >/dev/null 2>&1 ) || rc="$?"
[ "$rc" = 2 ] || fail "(m3) a module doing 'set +e' at top level loaded anyway (rc=$rc) — the canary discards its own copy of the mutation and the live source applies it"
echo "driver-conformance: (m3) a module that disarms errexit at load time is refused: ok"

cat > "$DRIVER_DIR/wander.sh" <<'ENDDRV'
cd /tmp
tapdrv_wander_deliver() { return 0; }
tapdrv_wander_ceiling() { printf 'api-accepted'; }
tapdrv_wander_outcome() { printf 'delivered\x1fpossible\x1fapi-accepted'; }
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "wander"
ENDCFG
wd="$TAP_HOME/payloads/conf-11.md"
printf 'body\n' > "$wd"
rc=0
( tap_driver_deliver "$wd" conf-11 queue claude >/dev/null 2>&1 ) || rc="$?"
[ "$rc" = 2 ] || fail "(m3) a module doing 'cd /tmp' at top level loaded anyway (rc=$rc)"
[ "$PWD" = "$_pwd_before" ] || fail "(m3) the courier's working directory MOVED ($_pwd_before -> $PWD)"
case "$-" in
  *e*) ;;
  *) [ "$_opts_before" = "$-" ] || fail "(m3) the courier's shell options changed ($_opts_before -> $-)" ;;
esac
echo "driver-conformance: (m3) a module that changes the working directory is refused, and the courier's own state is intact: ok"

# The mirror: a WELL-BEHAVED module must still load. A canary that refused
# everything would be indistinguishable from one that works, and would make the
# whole driver directory unusable rather than safe.
cat > "$DRIVER_DIR/polite.sh" <<'ENDDRV'
tapdrv_polite_deliver() { return 0; }
tapdrv_polite_ceiling() { printf 'api-accepted'; }
tapdrv_polite_outcome() { printf 'stop-ambiguous\x1fpossible\x1fapi-accepted'; }
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "polite"
ENDCFG
pl="$TAP_HOME/payloads/conf-12.md"
printf 'body\n' > "$pl"
rc=0
tap_driver_deliver "$pl" conf-12 queue claude >/dev/null 2>&1 || rc="$?"
[ "$rc" = 0 ] || fail "(m3) a well-behaved module was refused (rc=$rc); the canary has become a blanket denial"
[ "$TAP_DRIVER_LAST_DRIVER" = polite ] || fail "(m3) a well-behaved module did not become the acting driver"
# The NEXT FLAG. grok drove `set +u` against the first version of the option
# check, which looked only for `e`: same mutation shape, one flag over, in the
# predicate written to catch the shape. Enumerating flags is the losing move —
# the courier runs `set -euo pipefail` and the next one disarmed is whichever was
# not on the list — so the canary compares the WHOLE option set it armed.
for _flag in u e "o pipefail"; do
  _slug="$(printf '%s' "$_flag" | tr -d ' ')"
  cat > "$DRIVER_DIR/opt$_slug.sh" <<ENDDRV
set +$_flag
tapdrv_opt${_slug}_deliver() { return 0; }
tapdrv_opt${_slug}_ceiling() { printf 'api-accepted'; }
tapdrv_opt${_slug}_outcome() { printf 'delivered\x1fpossible\x1fapi-accepted'; }
ENDDRV
  cat > "$XDG_CONFIG_HOME/tap/config.toml" <<ENDCFG
[harness.claude]
driver = "opt$_slug"
ENDCFG
  op="$TAP_HOME/payloads/conf-13.md"
  printf 'body\n' > "$op"
  rc=0
  ( tap_driver_deliver "$op" conf-13 queue claude >/dev/null 2>&1 ) || rc="$?"
  [ "$rc" = 2 ] || fail "(m3) a module doing 'set +$_flag' loaded anyway (rc=$rc) — the option check is looking for specific flags instead of comparing the set"
  rm -f "${op%.md}.attempts"
done
echo "driver-conformance: (m3) disarming ANY of the courier's shell options is refused, not just errexit: ok"

echo "driver-conformance: (m3) a well-behaved module still loads: ok"

# --- (n) the outcome tuple is validated, never trusted -----------------------
# `retry-next-rung` REQUIRES `effect: none` — that pairing is the entire reason
# `effect` exists, because a retry after a possible effect is a duplicate
# delivery. The dispatcher quoted that rule everywhere and enforced it nowhere.
cat > "$DRIVER_DIR/badtuple.sh" <<'ENDDRV'
tapdrv_badtuple_deliver() { return 0; }
tapdrv_badtuple_ceiling() { printf 'api-accepted'; }
tapdrv_badtuple_outcome() { printf 'retry-next-rung\x1fpossible\x1fapi-accepted'; }
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "badtuple"
ENDCFG
bt="$TAP_HOME/payloads/conf-8.md"
printf 'body\n' > "$bt"
tap_driver_deliver "$bt" conf-8 queue claude >/dev/null 2>&1 || true
[ "$TAP_DRIVER_LAST_DISPOSITION" = stop-ambiguous ] || \
  fail "(n) an illegal retry-next-rung/possible tuple was trusted: recorded '$TAP_DRIVER_LAST_DISPOSITION' — the payload would be respooled after a possible delivery"
[ "$TAP_DRIVER_LAST_EFFECT" = possible ] || \
  fail "(n) the illegal tuple's effect was downgraded to '$TAP_DRIVER_LAST_EFFECT'; a possible effect must survive"
# It failed CLOSED, not silent: the driver already ran, so the attempt must still
# be recorded — we decline to believe its self-description, not its existence.
[ -f "${bt%.md}.attempts" ] || fail "(n) a malformed tuple erased the attempt record"
echo "driver-conformance: (n) an illegal disposition/effect pair fails closed to the conservative row: ok"

# The mirror: every LEGAL tuple must survive untouched, or the validator has
# become a blanket downgrade that makes the disposition table decorative.
_legal_n=0
for _legal in "delivered|possible|transcript-match|delivered" "retry-next-rung|none|none|retry-next-rung" "stop-ambiguous|possible|api-accepted|stop-ambiguous"; do
  IFS='|' read -r _d _e _t _want <<< "$_legal"
  _legal_n=$((_legal_n + 1))
  # A UNIQUE NAME PER ITERATION. `tap_driver_load` short-circuits when
  # tapdrv_<name>_deliver is already defined — correct, since a module must not
  # be re-sourced on every send — so reusing one driver name silently reuses the
  # FIRST iteration's outcome table and the loop tests one case three times.
  # This mirror arm caught that in its own fixture before it could vouch for
  # anything.
  cat > "$DRIVER_DIR/legal$_legal_n.sh" <<ENDDRV
tapdrv_legal${_legal_n}_deliver() { return 0; }
tapdrv_legal${_legal_n}_ceiling() { printf 'transcript-match'; }
tapdrv_legal${_legal_n}_outcome() { printf '$_d\x1f$_e\x1f$_t'; }
ENDDRV
  cat > "$XDG_CONFIG_HOME/tap/config.toml" <<ENDCFG
[harness.claude]
driver = "legal$_legal_n"
ENDCFG
  # The names in this loop are generated, so they cannot appear in the static
  # wired list at the top of the file. Declare each one as it is written --
  # beside the fixture it wires, not in a header that would have to be kept in
  # step with a loop bound.
  eval "tap_driver_wired_list() { printf %s 'tmux legal$_legal_n'; }"
  lg="$TAP_HOME/payloads/conf-9.md"
  printf 'body\n' > "$lg"
  tap_driver_deliver "$lg" conf-9 queue claude >/dev/null 2>&1 || true
  [ "$TAP_DRIVER_LAST_DISPOSITION" = "$_want" ] || \
    fail "(n) the LEGAL tuple $_d/$_e was rewritten to '$TAP_DRIVER_LAST_DISPOSITION'; the validator has become a blanket downgrade"
  rm -f "${lg%.md}.attempts"
done
echo "driver-conformance: (n) every legal tuple survives the validator untouched: ok"

# `delivered|none` is the missing red. It is self-contradicting: this file's own
# rc0 rationale says a successful delivery is effect-NOT-none and defers a third
# `performed` value as a design amendment. Left legal, it emits a `.sent` receipt
# beside an attempt record reading effect:none — the two-surfaces-disagreeing
# shape this whole layer exists to end.
cat > "$DRIVER_DIR/delivnone.sh" <<'ENDDRV'
tapdrv_delivnone_deliver() { return 0; }
tapdrv_delivnone_ceiling() { printf 'transcript-match'; }
tapdrv_delivnone_outcome() { printf 'delivered\x1fnone\x1ftranscript-match'; }
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "delivnone"
ENDCFG
dn="$TAP_HOME/payloads/conf-14.md"
printf 'body\n' > "$dn"
tap_driver_deliver "$dn" conf-14 queue claude >/dev/null 2>&1 || true
[ "$TAP_DRIVER_LAST_DISPOSITION" = stop-ambiguous ] || \
  fail "(n) 'delivered' with effect:none was accepted (recorded '$TAP_DRIVER_LAST_DISPOSITION') — a delivery claim its own effect field denies"
echo "driver-conformance: (n) 'delivered' with effect:none is rejected, not just retry-next-rung/possible: ok"

# --- (o) a top-level printf must not reach the receipt channel ---------------
# The redirect around deliver() does not cover the LIVE SOURCE. A module with a
# top-level printf writes to `tap send`'s stdout during the load, and a
# well-formed JSON line there could forge a receipt before any audited attempt
# exists to blame.
cat > "$DRIVER_DIR/loudload.sh" <<'ENDDRV'
printf '{"status":"injected","id":"forged-at-load"}\n'
tapdrv_loudload_deliver() { return 0; }
tapdrv_loudload_ceiling() { printf 'api-accepted'; }
tapdrv_loudload_outcome() { printf 'stop-ambiguous\x1fpossible\x1fapi-accepted'; }
ENDDRV
config_write <<'ENDCFG'
[harness.claude]
driver = "loudload"
ENDCFG
ll="$TAP_HOME/payloads/conf-15.md"
printf 'body\n' > "$ll"
_loud="$(tap_driver_deliver "$ll" conf-15 queue claude 2>/dev/null)" || true
case "$_loud" in
  *forged-at-load*) fail "(o) a module's top-level printf reached the caller's stdout during the LIVE source: $_loud" ;;
esac
echo "driver-conformance: (o) a module's top-level output never reaches the receipt channel: ok"

echo "driver-conformance: (g) rc6 stays stop-ambiguous/possible; a post-Enter identity failure cannot be retried: ok"


# --- (p) a capped native rc 0 keeps its diagnosis --------------------------
# sol-pinnacle, #xxx. `tap_driver_detail` returned empty for EVERY rc 0 before it
# reached the stderr reader. For tmux that is right -- rc 0 is verified
# submission. For a native it is wrong twice over: the driver's own table may map
# 0 to stop-ambiguous, and the evidence cap can demote a delivered claim. Both
# leave a durable, PENDING attempt whose only diagnosis is what the driver said
# on stderr, and the shortcut threw it away.
cat > "$DRIVER_DIR/quietzero.sh" <<'ENDDRV'
tapdrv_quietzero_deliver() { echo 'native accepted but not verified' >&2; return 0; }
tapdrv_quietzero_ceiling() { printf 'api-accepted'; }
tapdrv_quietzero_outcome() { printf 'stop-ambiguous\x1fpossible\x1fapi-accepted'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.claude]
driver = "quietzero"
ENDCFG
eval "tap_driver_wired_list() { printf %s 'tmux quietzero'; }"
WORK_ERR_QZ="$TAP_HOME/qz.err"
_qz="$TAP_HOME/payloads/conf-qz.md"
printf 'body\n' > "$_qz"
# The courier captures the driver's stderr to a file and points
# TAP_DRIVER_DETAIL_FILE at it; reproduce that here rather than assuming the
# detail arrives by magic -- a fixture that does not supply what the dispatcher
# supplies is testing its own calling convention.
TAP_DRIVER_DETAIL_FILE="$WORK_ERR_QZ"
export TAP_DRIVER_DETAIL_FILE
tap_driver_deliver "$_qz" conf-qz queue claude >/dev/null 2>"$WORK_ERR_QZ" || true
_qz_detail="$(grep -o '"detail":"[^"]*"' "${_qz%.md}.attempts" | tail -1)"
case "$_qz_detail" in
  *"native accepted but not verified"*) : ;;
  *) fail "(p) a capped native rc 0 recorded detail $_qz_detail; the pending attempt lost its only diagnosis" ;;
esac
# MIRROR: a SILENT native rc 0 must not gain an invented detail. Bounds the fix
# so it cannot overshoot into stamping "rc=0" on drivers that said nothing.
cat > "$DRIVER_DIR/mutezero.sh" <<'ENDDRV'
tapdrv_mutezero_deliver() { return 0; }
tapdrv_mutezero_ceiling() { printf 'left-input-band'; }
tapdrv_mutezero_outcome() { printf 'delivered\x1fpossible\x1fleft-input-band'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.claude]
driver = "mutezero"
ENDCFG
eval "tap_driver_wired_list() { printf %s 'tmux mutezero'; }"
WORK_ERR_MZ="$TAP_HOME/mz.err"
_mz="$TAP_HOME/payloads/conf-mz.md"
printf 'body\n' > "$_mz"
: > "$WORK_ERR_MZ"
TAP_DRIVER_DETAIL_FILE="$WORK_ERR_MZ"
export TAP_DRIVER_DETAIL_FILE
tap_driver_deliver "$_mz" conf-mz queue claude >/dev/null 2>"$WORK_ERR_MZ" || true
case "$(grep -o '"detail":"[^"]*"' "${_mz%.md}.attempts" | tail -1)" in
  *'"detail":"rc=0"'*) fail "(p-mirror) a silent native rc 0 was stamped with an invented rc=0 detail" ;;
esac
echo "driver-conformance: (p) a capped native rc 0 keeps its stderr diagnosis, a silent one invents none: ok"


# --- (q) a retry cannot carry verified-submission evidence -------------------
# sol-pinnacle, P1 at e8fd3adf. The result file refines `tier` AFTER the static
# tuple is validated, and the cap only ever demotes `delivered`. So a static
# `retry-next-rung/none` outcome plus a result-file tier of `transcript-match`
# stayed RETRYABLE: the courier spooled the payload for another attempt while the
# attempt record asserted verified-submission evidence for the attempt it had just
# made. That is a duplicate delivery.
#
# Retry means "nothing happened, try the next rung". A verified-submission tier
# means "something was observed to land". The pair must fail CLOSED.
cat > "$DRIVER_DIR/retryliar.sh" <<'ENDDRV'
tapdrv_retryliar_deliver() {
  printf 'tier=transcript-match\n' > "$TAP_DRIVER_RESULT_FILE"
  return 9
}
tapdrv_retryliar_ceiling() { printf 'transcript-match'; }
tapdrv_retryliar_outcome() { printf 'retry-next-rung\x1fnone\x1fnone'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.claude]
driver = "retryliar"
ENDCFG
eval "tap_driver_wired_list() { printf %s 'tmux retryliar'; }"
_rl="$TAP_HOME/payloads/conf-rl.md"
printf 'body\n' > "$_rl"
tap_driver_deliver "$_rl" conf-rl queue claude >/dev/null 2>&1 || true
[ "$TAP_DRIVER_LAST_DISPOSITION" = stop-ambiguous ] || \
  fail "(q) a retry carrying a verified-submission tier stayed '$TAP_DRIVER_LAST_DISPOSITION'; the courier would spool a payload whose own record says it landed"
[ "$TAP_DRIVER_LAST_EFFECT" = possible ] || \
  fail "(q) the failed-closed row recorded effect '$TAP_DRIVER_LAST_EFFECT', expected possible; an ambiguous attempt with effect none is still retryable downstream"
grep -q '"tier":"transcript-match"' "${_rl%.md}.attempts" || \
  fail "(q) the recorded tier was rewritten; the evidence must be preserved and the DISPOSITION corrected, not the other way round"
echo "driver-conformance: (q) a retry carrying verified-submission evidence fails closed to stop-ambiguous/possible: ok"

# MIRROR: a retry whose result file refines the tier to something OUTSIDE the
# verified-submission class stays retryable. `api-accepted` is deliberate rather
# than `none`: a tier of `none` is also produced by drivers that never write a
# result file, so an overshoot caught with `none` is caught by the older rc4 arms
# before this one runs, and this arm's bound would be untested. With
# `api-accepted` the only mutant that reds here is one that demotes a legal
# result-file refinement -- which is exactly what this arm claims to prevent.
cat > "$DRIVER_DIR/retryhonest.sh" <<'ENDDRV'
tapdrv_retryhonest_deliver() {
  printf 'tier=api-accepted\ndetail=rung busy\n' > "$TAP_DRIVER_RESULT_FILE"
  return 9
}
tapdrv_retryhonest_ceiling() { printf 'transcript-match'; }
tapdrv_retryhonest_outcome() { printf 'retry-next-rung\x1fnone\x1fnone'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.claude]
driver = "retryhonest"
ENDCFG
eval "tap_driver_wired_list() { printf %s 'tmux retryhonest'; }"
_rh="$TAP_HOME/payloads/conf-rh.md"
printf 'body\n' > "$_rh"
tap_driver_deliver "$_rh" conf-rh queue claude >/dev/null 2>&1 || true
[ "$TAP_DRIVER_LAST_DISPOSITION" = retry-next-rung ] || \
  fail "(q-mirror) an honest retry was demoted to '$TAP_DRIVER_LAST_DISPOSITION'; the fix overshot and forfeits every legal retry"
echo "driver-conformance: (q-mirror) an honest retry still retries: ok"


# (q-band) THE OTHER VERIFIED-SUBMISSION TIER. `left-input-band` is in
# TAP_DRIVER_VERIFIED_SUBMISSION_TIERS alongside `transcript-match`, and (q)
# names only the latter -- so a mutant special-casing `transcript-match` would
# green it while leaving the other half of the class retryable. grok, #xxx: the
# same "the predicate covers both" gap the cap itself was fixed for.
cat > "$DRIVER_DIR/retryband.sh" <<'ENDDRV'
tapdrv_retryband_deliver() {
  printf 'tier=left-input-band\n' > "$TAP_DRIVER_RESULT_FILE"
  return 9
}
tapdrv_retryband_ceiling() { printf 'left-input-band'; }
tapdrv_retryband_outcome() { printf 'retry-next-rung\x1fnone\x1fnone'; }
ENDDRV
cat > "$XDG_CONFIG_HOME/tap/config.toml" <<'ENDCFG'
[harness.claude]
driver = "retryband"
ENDCFG
eval "tap_driver_wired_list() { printf %s 'tmux retryband'; }"
_rb="$TAP_HOME/payloads/conf-rb.md"
printf 'body\n' > "$_rb"
tap_driver_deliver "$_rb" conf-rb queue claude >/dev/null 2>&1 || true
[ "$TAP_DRIVER_LAST_DISPOSITION" = stop-ambiguous ] || \
  fail "(q-band) a retry carrying left-input-band stayed '$TAP_DRIVER_LAST_DISPOSITION'; the fail-closed rule must cover the whole verified-submission class, not one member of it"
echo "driver-conformance: (q-band) the fail-closed rule covers every verified-submission tier: ok"

echo "driver-conformance: ok"
