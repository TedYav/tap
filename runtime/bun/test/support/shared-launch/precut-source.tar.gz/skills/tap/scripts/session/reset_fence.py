"""Shared reset-fence mutation serialization (sol 063932 / tap-9tqt).

Hold $TAP_HOME/reset.fence.json.lock, recheck fence presence, then allow a
durable bus mutation. Same sidecar lock as tap_reset_fence_acquire.
"""
from __future__ import annotations

import contextlib
import fcntl
import json
import os
import pathlib
import time


class ResetFenceError(RuntimeError):
    """Raised when a mutation is refused because the bus is mid-reset."""


def _test_barrier(stage: str) -> None:
    raw = os.environ.get("TAP_RESET_FENCE_TEST_BARRIER") or ""
    if not raw or not (os.environ.get("TAP_SCRATCH_ONLY") or ""):
        return
    base = pathlib.Path(raw)
    reached = base.parent / f"{base.name}.{stage}.reached"
    release = base.parent / f"{base.name}.{stage}.release"
    reached.write_text("1\n")
    deadline = time.monotonic() + 60.0
    while not release.is_file():
        if time.monotonic() >= deadline:
            raise ResetFenceError(f"reset fence test barrier timed out at {stage}")
        time.sleep(0.05)


def _fence_allows_caller(fence: pathlib.Path) -> bool:
    """Reset/restore may mutate under their own fence (manifest cut / merge).

    Ownership is the fence pid (same process) OR TAP_RESET_FENCE_TOKEN matching
    the stamped token (child python helpers spawned by the owner).
    """
    try:
        rec = json.loads(fence.read_text())
    except Exception:
        return False
    try:
        if int(rec.get("pid") or -1) == os.getpid():
            return True
    except (TypeError, ValueError):
        pass
    token = os.environ.get("TAP_RESET_FENCE_TOKEN") or ""
    return bool(token) and rec.get("token") == token


@contextlib.contextmanager
def mutation_lock(bus_dir: str | os.PathLike[str], action: str):
    """Serialize durable mutation against reset fence acquisition."""
    _test_barrier("pre-mutation")
    bus = pathlib.Path(bus_dir)
    fence = bus / "reset.fence.json"
    lock_path = bus / "reset.fence.json.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with open(lock_path, "a+", encoding="utf-8") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if fence.is_file() and not _fence_allows_caller(fence):
            raise ResetFenceError(
                f"refusing {action} — team bus is mid-reset (fence at {fence}); "
                "next: tap team reset"
            )
        _test_barrier("holding-mutation-lock")
        yield
