#!/usr/bin/env bash
# Baseline-relative CI outcomes still require a complete full-suite receipt.
set -euo pipefail
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
python3 - "$ROOT/scripts/ci-gate-verdict.py" "$ROOT/scripts/ci-gate-baseline.sh" "$ROOT/.github/workflows/full-gate.yml" <<'PY'
from pathlib import Path
import subprocess
import os
import sys
import tempfile
import importlib.util
import re

script = sys.argv[1]
spec = importlib.util.spec_from_file_location('ci_gate_verdict', script)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
shipped = Path(script).parent.parent/'docs/artifacts/ci-gate-baseline.md'
gate.baseline_assertions(shipped.read_text())
print('ci-gate-verdict: shipped baseline document parses: ok')
capture_script = sys.argv[2]
workflow = Path(sys.argv[3]).read_text()
head = 'a' * 40
prefix = f'smoke-all: tested-tree={"b" * 40} head={head} worktree=clean; known-defect: 0; declared-skips=0 skip-files=0'
a = 'skills/tap/scripts/smoke/a.test.sh'
b = 'skills/tap/scripts/smoke/b.test.sh'
new = 'skills/tap/scripts/smoke/new.test.sh'
def assertion(path):
    return Path(path).name.removesuffix('.test.sh') + ': (1) original assertion'

baseline = f'## Current: 2 files\n\n| File | Bead | First failing assertion |\n|---|---|---|\n| {a} | tap-a | {assertion(a)} |\n| {b} | tap-b | {assertion(b)} |\n'

def red(files):
    return ''.join(f'=== FAIL {f} (exit 1) ===\n{assertion(f)}\n' for f in files) + f'{prefix} — {len(files)}/3 FAILED, {3-len(files)} passed (1s, -j 8)\n'

def framed_red(files, nested_path, receipt_count=None):
    receipt_id = 'd' * 32
    blocks = []
    for index, path in enumerate(files):
        block = (f'=== SMOKE-FAIL-BEGIN receipt-id={receipt_id} path={path} ===\n'
                 f'=== FAIL {path} (exit 1) ===\n{assertion(path)}\n')
        if index == len(files) - 1:
            nested_id = 'e' * 32
            block += (f'=== SMOKE-FAIL-BEGIN receipt-id={nested_id} path={nested_path} ===\n'
                      f'=== FAIL {nested_path} (exit 1) ===\nnested fixture assertion\n'
                      f'=== SMOKE-FAIL-END receipt-id={nested_id} path={nested_path} ===\n')
        block += f'=== SMOKE-FAIL-END receipt-id={receipt_id} path={path} ===\n'
        blocks.append(block)
    count = len(files) if receipt_count is None else receipt_count
    total = max(6, count + 1)
    framed_prefix = prefix.replace('; known-defect:', f'; failure-receipt-id={receipt_id}; known-defect:')
    return ''.join(blocks) + f'{framed_prefix} — {count}/{total} FAILED, {total-count} passed (1s, -j 8)\n'

green = f'{prefix} — ok — all 3 files passed (1s, -j 8)\n'
with tempfile.TemporaryDirectory(prefix='ci-gate-verdict.') as root:
    root = Path(root)
    def check(name, log, raw, expected, base=baseline, capture=0, pin=head):
        (root/'baseline.md').write_text(base)
        (root/'log').write_text(log)
        result = subprocess.run([sys.executable, script, '--baseline', str(root/'baseline.md'),
            '--log', str(root/'log'), '--raw-exit', str(raw), '--capture-exit', str(capture), '--head', pin],
            text=True, capture_output=True)
        assert result.returncode == expected, (name, result.stdout, result.stderr)
        assert f'Gate verdict: {"PASS" if expected == 0 else "FAIL"}' in result.stdout, (name, result.stdout)
        if expected == 0:
            assert 'Baseline red set' in result.stdout and 'Current red set' in result.stdout and 'Regressions (0)' in result.stdout
        print(f'ci-gate-verdict: {name}: ok')
        return result.stdout

    check('changed assertion inside baseline file blocks', red([a]).replace(assertion(a), 'a: (2) changed assertion'), 1, 1)
    additional = check('new assertion after baseline assertion blocks',
        red([a]).replace(assertion(a), assertion(a) + '\na: (2) new assertion'), 1, 1)
    assert 'REGRESSION inside baseline-red file' in additional and 'a: (2) new assertion' in additional
    check('repeated baseline assertion remains the same waiver',
        red([a]).replace(assertion(a), assertion(a) + '\n' + assertion(a)), 1, 0)
    for extra in ('FAIL b2: new assertion: expected 0, got 1',
                  'FAIL: new-scenario: command returned 1'):
        check('additional named FAIL shape blocks: ' + extra,
            red([a]).replace(assertion(a), assertion(a) + '\n' + extra), 1, 1)
    same = check('known subset', red([a]), 1, 0)
    assert f'baseline (same assertion: {assertion(a)})' in same
    changed = check('changed assertion reports both identities', red([a]).replace(assertion(a), 'a: (2) changed assertion'), 1, 1)
    assert f'REGRESSION inside baseline-red file: was {assertion(a)}, now a: (2) changed assertion' in changed
    check('progress does not become an assertion', red([a]).replace(assertion(a), 'a: starting test\na: (0) progress: ok\n' + assertion(a)), 1, 0)
    check('unidentified failure refuses', red([a]).replace(assertion(a), 'unexpected exit'), 1, 1)
    check('old file-only baseline refuses', red([a]), 1, 1, base=baseline.replace(' | ' + assertion(a), ''))
    bun = 'skills/tap/scripts/smoke/bun-router.test.sh'
    bun_id = '(fail) native router > poll parity @ runtime/bun/test/native-router.test.ts:1419:42'
    bun_base = f'## Current: 1 files\n| {bun} | tap-bun | {bun_id} |\n'
    bun_body = 'error: expect(received).toBe(expected)\n      at <anonymous> (/checkout/runtime/bun/test/native-router.test.ts:1419:42)\n(fail) native router > poll parity [123.45ms]'
    bun_log = red([bun]).replace(assertion(bun), bun_body)
    check('Bun same assertion', bun_log, 1, 0, base=bun_base)
    check('Bun timing is not identity', bun_log.replace('123.45ms', '90.1ms'), 1, 0, base=bun_base)
    check('additional Bun assertion after waived failure blocks',
        bun_log.replace(bun_body, bun_body + '\n' + bun_body.replace('1419:42', '1420:42')),
        1, 1, base=bun_base)
    check('unlocated second Bun failure cannot borrow waived frame',
        bun_log.replace(bun_body, bun_body + '\n(fail) native router > second failure'),
        1, 1, base=bun_base)
    check('different assertion in same Bun test blocks', bun_log.replace('1419:42', '1420:42'), 1, 1, base=bun_base)
    check('different Bun test blocks', bun_log.replace('poll parity [', 'new parity ['), 1, 1, base=bun_base)
    check('Bun missing position refuses', bun_log.replace('      at <anonymous> (/checkout/runtime/bun/test/native-router.test.ts:1419:42)\n', ''), 1, 1, base=bun_base)

    # Run 35435768092 directly measured the mechanism: a located failure
    # echoed under Bun's "N tests failed:" heading without a source frame.
    # The three-name detailed-plus-summary specimen below is constructed:
    # the names are retained incident evidence from run 35190165377 and the
    # 101:11/202:22/303:33 frames are synthetic. The echo must not change any
    # located identity nor refuse the whole receipt.
    summary_names = (
        'accepted rows come from accepting cases > every accepted command, subcommand, and help topic is a catalog row',
        'page text parity with Bash > every tap_verb_help spelling plus the overview matches Bash, except the declared crew delta',
        'causal fixtures: dropped subcommand, wrong-scoped help, routing gap > JSON catalog index is frozen and agrees with lookupHelp text',
    )
    summary_frames = ('101:11', '202:22', '303:33')
    def bun_specimen(names, frames, summary, tail=''):
        detailed = ''.join(
            'error: expect(received).toBe(expected)\n'
            f'      at <anonymous> (/checkout/runtime/bun/test/help.test.ts:{frame})\n'
            f'(fail) {name} [{11 * (position + 1)}.11ms]\n'
            for position, (name, frame) in enumerate(zip(names, frames)))
        echoed = '' if summary is None else (
            f'\n{len(summary)} tests failed:\n' + ''.join(f'(fail) {name}\n' for name in summary))
        return red([bun]).replace(assertion(bun), detailed + echoed + tail)
    summary_ids = [f'(fail) {name} @ runtime/bun/test/help.test.ts:{frame}'
                   for name, frame in zip(summary_names, summary_frames)]
    check('Bun summary duplicate keeps a precise baseline waiver',
        bun_specimen(summary_names[:1], summary_frames[:1], summary_names[:1]), 1, 0,
        base=f'## Current: 1 files\n| {bun} | tap-bun | {summary_ids[0]} |\n')
    output = check('Bun summary duplicates keep located identities',
        bun_specimen(summary_names, summary_frames, summary_names), 1, 1, base='## Current: 0 files\n')
    assert 'Current red set (1):' in output and 'Regressions (1):' in output, output
    for identity in summary_ids:
        assert output.count(identity) == 1, output
    assert 'invalid evidence:' not in output, output
    output = check('unmatched Bun summary name still refuses',
        bun_specimen(summary_names[:1], summary_frames[:1], summary_names[1:2]), 1, 1,
        base='## Current: 0 files\n')
    assert 'missing assertion evidence: Bun failure has no assertion source position' in output, output
    output = check('same-name repeat without a summary heading cannot borrow',
        bun_specimen(summary_names[:1], summary_frames[:1], None,
                     tail=f'(fail) {summary_names[0]}\n'), 1, 1, base='## Current: 0 files\n')
    assert 'missing assertion evidence: Bun failure has no assertion source position' in output, output
    output = check('summary handling ends before later execution output',
        bun_specimen(summary_names[:1], summary_frames[:1], summary_names[:1],
                     tail=f'Ran 1 test across 1 file. [40.00ms]\n(fail) {summary_names[0]}\n'),
        1, 1, base='## Current: 0 files\n')
    assert 'missing assertion evidence: Bun failure has no assertion source position' in output, output

    for component in ('runtime/bun/test/native-router.test.ts', 'runtime/bun/src/submit-phase.test.ts'):
        component_id = bun_id.replace('runtime/bun/test/native-router.test.ts', component)
        component_body = bun_body.replace('runtime/bun/test/native-router.test.ts', component)
        component_base = f'## Current: 1 files\n| {component} | tap-bun | {component_id} |\n'
        for sample in (red([component]), framed_red([component], a)):
            sample = sample.replace(assertion(component), component_body)
            check('direct Bun component keeps exact assertion: ' + component, sample, 1, 0, base=component_base)
            check('direct Bun changed assertion refuses: ' + component,
                  sample.replace('1419:42', '1420:42'), 1, 1, base=component_base)

    check('equal baseline', red([a,b]), 1, 0)
    output = check('new failing file blocks', red([a,new]), 1, 1)
    assert f'Regressions (1):\n- `{new}`' in output
    check('all green', green, 0, 0)
    check('empty baseline all green', green, 0, 0, base='## Current: 0 files\n')
    check('missing baseline declaration', green, 0, 1, base='')
    check('baseline count mismatch', green, 0, 1, base=baseline.replace('2 files','3 files'))
    check('duplicate baseline rows', green, 0, 1, base=baseline.replace(b,a))
    check('no terminal receipt', 'preflight refused\n', 1, 1)
    check('raw failure without red files', green, 1, 1)
    check('raw success contradicts reds', red([a]), 0, 1)
    check('interrupted run', red([a]), 143, 1)
    check('capture error', red([a]), 1, 1, capture=1)
    check('wrong head', red([a]), 1, 1, pin='c'*40)
    check('straddled run', red([a]) + prefix + ' — STRADDLED\n', 1, 1)
    check('census mismatch', red([a]).replace('1/3 FAILED', '2/3 FAILED'), 1, 1)
    check('duplicate failure rows', red([a,a]), 1, 1)
    check('post-wave failure', '=== FAIL post-wave operator-state ===\n' + red([a]), 1, 1)
    check('truncated summary', red([a]).replace(' (1s, -j 8)', ''), 1, 1)

    # tap-12pzm: four real runs carried one nested runner header beyond the
    # outer receipt's count. The run-unique frames are the authoritative
    # namespace; the nested human-readable header remains visible but cannot
    # enter the outer census.
    specimens = [
        ('34418191419', [
            'skills/tap/scripts/smoke/session-pytest.test.sh',
            'skills/tap/scripts/smoke/bun-launcher.test.sh',
            'skills/tap/scripts/smoke/launcher-fork-retry.test.sh',
            'skills/tap/scripts/smoke/launcher-pre-registration.test.sh',
            'skills/tap/scripts/smoke/suite-env-hermeticity.test.sh'],
         'skills/tap/scripts/smoke/hermetic-worker.test.sh'),
        ('34417873501', [
            'skills/tap/scripts/smoke/launch-prerequisites.test.sh',
            'skills/tap/scripts/smoke/python-seats-axis-enum.test.sh',
            'skills/tap/scripts/smoke/suite-env-hermeticity.test.sh',
            'skills/tap/scripts/smoke/bun-router.test.sh'],
         'skills/tap/scripts/smoke/hermetic-worker.test.sh'),
        ('34417564483', [
            'skills/tap/scripts/smoke/launch-prerequisites.test.sh',
            'skills/tap/scripts/smoke/python-seats-axis-enum.test.sh',
            'skills/tap/scripts/smoke/suite-env-hermeticity.test.sh',
            'skills/tap/scripts/smoke/bun-router.test.sh'],
         'skills/tap/scripts/smoke/hermetic-worker.test.sh'),
        ('34330494473', [
            'skills/tap/scripts/smoke/postflip-enroll.test.sh',
            'skills/tap/scripts/smoke/standalone-smoke-sandbox.test.sh',
            'skills/tap/scripts/smoke/suite-index-hermeticity.test.sh'],
         'skills/tap/scripts/smoke/index-isolated-worker.test.sh'),
    ]
    for run_id, outer_files, nested_path in specimens:
        sample = framed_red(outer_files, nested_path, receipt_count=len(outer_files))
        if run_id == '34330494473':
            sample = sample.replace(assertion('skills/tap/scripts/smoke/suite-index-hermeticity.test.sh'),
                'suite-index-hermeticity: (a) inner suite failed')
            sample = sample.replace('nested fixture assertion', 'index-isolated-worker: tap in failed')
        elif run_id in {'34417873501', '34417564483'}:
            sample = sample.replace(assertion('skills/tap/scripts/smoke/bun-router.test.sh'),
                '(fail) native router > retained specimen without a source frame')
        receipt = [line for line in sample.splitlines() if line.startswith('smoke-all: tested-tree=')][-1]
        records = gate.failure_records(sample, receipt)
        assert [path for path, _ in records] == outer_files, (run_id, records)
        output = check(f'nested specimen {run_id} uses bound outer census', sample, 1, 1,
                       base='## Current: 0 files\n')
        assert f'Current red set ({len(outer_files)}):' in output, output
        assert 'failed-file census and raw exit do not match' not in output, output
        assert nested_path not in output, output
        if run_id in {'34417873501', '34417564483'}:
            assert 'missing assertion evidence for: skills/tap/scripts/smoke/bun-router.test.sh' in output, output
        else:
            assert 'invalid evidence:' not in output, output
        if run_id == '34330494473':
            assert 'suite-index-hermeticity: (a) inner suite failed' in output, output
            assert 'index-isolated-worker: tap in failed' not in output, output
    mismatch = check('bound census mismatch still refuses',
        framed_red([a], 'skills/tap/scripts/smoke/nested.test.sh', receipt_count=2),
        1, 1, base='## Current: 0 files\n')
    assert 'invalid evidence: failed-file census' in mismatch, mismatch
    duplicate_binding = framed_red([a], 'skills/tap/scripts/smoke/nested.test.sh')
    duplicate_binding = duplicate_binding.replace(
        '; failure-receipt-id=' + 'd' * 32 + ';',
        '; failure-receipt-id=' + 'd' * 32 + '; failure-receipt-id=' + 'd' * 32 + ';')
    duplicate = check('duplicate failure binding refuses', duplicate_binding, 1, 1,
                      base='## Current: 0 files\n')
    assert 'invalid evidence: terminal failure receipt id is malformed' in duplicate, duplicate
    legacy_collision = check('unbound nested census remains ambiguous',
        red([a]).replace(assertion(a), assertion(a) +
            '\n=== FAIL skills/tap/scripts/smoke/nested.test.sh (exit 1) ===\nnested assertion'),
        1, 1, base='## Current: 0 files\n')
    assert 'invalid evidence: failed-file census' in legacy_collision, legacy_collision

    # tap-spg9i: three actual shell/Python shapes must share one complete census.
    self_file = 'skills/self/scripts/smoke/self.test.sh'
    disposition = 'skills/tap/scripts/smoke/delivery-disposition.test.sh'
    install = 'skills/tap/scripts/smoke/install-rebase-hooks.test.sh'
    diagnostics = {
        self_file: "FAIL a13: 'registry to' not false-positived as 'try to': expected exit 0, got 4",
        disposition: 'FAIL: optimized-invalid-action: grep -q invalid decision output',
        install: "AssertionError: ('sync failed during hook export', 1)",
    }
    combined = ''.join(f'=== FAIL {path} (exit 1) ===\n{text}\n' for path,text in diagnostics.items()) + f'{prefix} — 3/3 FAILED, 0 passed (1s, -j 8)\n'
    current = gate.failing_files(combined, 1, head)
    assert current == {
        self_file: ["FAIL a13: 'registry to' not false-positived as 'try to'"],
        disposition: ['FAIL: optimized-invalid-action'],
        install: [diagnostics[install]],
    }, current
    output = check('all three shipped assertion formats attributed', combined, 1, 1, base='## Current: 0 files\n')
    assert 'Current red set (3)' in output and 'Regressions (3)' in output, output
    for path in diagnostics: assert f'{path}: new failing file' in output, output

    # Run 34347305496 is the last class-1 refusal before 8b36a477e added the
    # diagnostic fallback. Pin its real log shape so that fix cannot disappear.
    bare = 'startup discriminator failed: 1::485889'
    unknown = red([a]).replace(assertion(a), bare + '\nsmoke-all: suite-load load1m=2.0\nsmoke-all: per-file wall time (ms, descending)\n' + a + '\t123')
    identity = 'unrecognized-shape: ' + bare
    assert gate.failing_files(unknown, 1, head)[a] == [identity]
    unknown_base = f'## Current: 1 files\n| {a} | tap-a | {identity} |\n'
    output = check('unknown-shape evidence is retained but never waived', unknown, 1, 1, base=unknown_base)
    assert identity in output and 'Regressions (1)' in output, output

    # rc-only helpers have no scenario identity: the command distinguishes assertions.
    rc_file = 'skills/tap/scripts/smoke/digest-outcome.test.sh'
    rc_assertion = 'FAIL: rc=4: test -f first-receipt'
    rc_baseline = f'## Current: 1 files\n| {rc_file} | tap-rc | {rc_assertion} |\n'
    rc_log = red([rc_file]).replace(assertion(rc_file), rc_assertion)
    check('rc-only collapsed baseline cannot waive a command', rc_log, 1, 1, base=rc_baseline.replace(': test -f first-receipt', ''))
    check('rc-only same command retains baseline', rc_log, 1, 0, base=rc_baseline)
    output = check('rc-only different command cannot share waiver', rc_log.replace('first-receipt', 'second-receipt'), 1, 1, base=rc_baseline)
    assert 'REGRESSION inside baseline-red file' in output, output

    # Empty output and a Bun failure without a frame cannot hide later good evidence.
    for unusable in ('', '(fail) no diagnostic frame'):
        mixed = red([a,b]).replace(assertion(a), unusable)
        output = check('unusable first block retains later parsed failure', mixed, 1, 1, base='## Current: 0 files\n')
        assert 'Current red set (2)' in output and 'Regressions (2)' in output, output
        assert f'{b}: new failing file (assertion: {assertion(b)})' in output, output
        assert f'{a}: missing assertion evidence:' in output, output
        assert 'invalid evidence' in output, output

# A PR may alter its own table, but that table cannot authorize new failures.
with tempfile.TemporaryDirectory(prefix='ci-gate-authority.') as root:
    root = Path(root)
    repo = root/'repo'
    repo.mkdir()
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
    git('init', '-q', '-b', 'main')
    git('config', 'user.email', 'dev1@example.invalid')
    git('config', 'user.name', 'CI fixture')
    (repo/'README').write_text('old checkout has no gate helpers\n')
    git('add', '.')
    git('commit', '-qm', 'old checkout')
    old_head = git('rev-parse', 'HEAD')
    (repo/'scripts').mkdir()
    (repo/'scripts/ci-gate-baseline.sh').write_text(Path(capture_script).read_text())
    (repo/'scripts/ci-gate-verdict.py').write_text(Path(script).read_text())
    table = repo/'docs/artifacts/ci-gate-baseline.md'
    table.parent.mkdir(parents=True)
    table.write_text(baseline)
    git('add', '.')
    git('commit', '-qm', 'measured main baseline')
    main_head = git('rev-parse', 'HEAD')
    main_blob = git('rev-parse', 'HEAD:docs/artifacts/ci-gate-baseline.md')
    git('update-ref', 'refs/remotes/origin/main', main_head)
    git('checkout', '-qb', 'proposed')
    table.write_text(baseline.replace('2 files', '3 files') + f'| {new} | tap-new | {assertion(new)} |\n')
    git('add', '.')
    git('commit', '-qm', 'PR expands its own baseline')
    evidence = root/'evidence'
    captured = subprocess.run(['bash', capture_script, str(evidence)], cwd=repo, capture_output=True, text=True)
    assert captured.returncode == 0, captured.stderr
    assert (evidence/'baseline.md').read_text() == baseline
    revision = (evidence/'baseline-revision.txt').read_text()
    assert f'baseline-head={main_head}\n' in revision
    assert f'baseline-blob={main_blob}\n' in revision
    log_path = root/'smoke.log'
    log_path.write_text(red([new]))
    def verdict(baseline_path):
        return subprocess.run([sys.executable, script, '--baseline', str(baseline_path),
            '--log', str(log_path), '--raw-exit', '1', '--capture-exit', '0', '--head', head],
            text=True, capture_output=True)
    # Positive falsifier: the old workflow input would have accepted this red.
    assert verdict(table).returncode == 0
    trusted = verdict(evidence/'baseline.md')
    assert trusted.returncode == 1 and f'Regressions (1):\n- `{new}`' in trusted.stdout
    print('ci-gate-verdict: PR baseline expansion cannot waive a new failure: ok')
    # A PR cannot replace an existing row's assertion either.
    changed_id = 'a: (2) a newly failing assertion'
    table.write_text(baseline.replace(assertion(a), changed_id))
    log_path.write_text(red([a]).replace(assertion(a), changed_id))
    assert verdict(table).returncode == 0
    trusted = verdict(evidence/'baseline.md')
    assert trusted.returncode == 1 and 'REGRESSION inside baseline-red file' in trusted.stdout
    print('ci-gate-verdict: PR assertion replacement cannot authorize itself: ok')
    git('add', '.')
    git('commit', '-qm', 'PR changes its own assertion')
    # The captured bytes and identity stay pinned even if the remote ref moves.
    git('update-ref', 'refs/remotes/origin/main', git('rev-parse', 'HEAD'))
    assert (evidence/'baseline.md').read_text() == baseline
    assert (evidence/'baseline-revision.txt').read_text() == revision
    print('ci-gate-verdict: captured baseline remains pinned: ok')
    git('update-ref', '-d', 'refs/remotes/origin/main')
    absent = subprocess.run(['bash', capture_script, str(root/'missing-ref')], cwd=repo, capture_output=True)
    assert absent.returncode != 0 and not (root/'missing-ref/baseline.md').exists()
    print('ci-gate-verdict: missing origin/main refuses capture: ok')
    git('rm', '--', 'docs/artifacts/ci-gate-baseline.md')
    git('commit', '-qm', 'main has no baseline')
    git('update-ref', 'refs/remotes/origin/main', git('rev-parse', 'HEAD'))
    absent = subprocess.run(['bash', capture_script, str(root/'missing-file')], cwd=repo, capture_output=True)
    assert absent.returncode != 0 and not (root/'missing-file/baseline.md').exists()
    print('ci-gate-verdict: missing main baseline refuses capture: ok')


    # Execute the actual workflow bodies against a checkout predating both helpers.
    def step_body(name):
        step = workflow.split(f'      - name: {name}\n', 1)[1].split('\n      - ', 1)[0]
        body = step.split('        run: ', 1)[1]
        if not body.startswith('|\n'):
            return body.splitlines()[0]
        return '\n'.join(line[10:] for line in body.splitlines()[1:])
    git('update-ref', 'refs/remotes/origin/main', main_head)
    git('checkout', '-q', '--detach', old_head)
    assert not (repo/'scripts/ci-gate-baseline.sh').exists()
    assert not (repo/'scripts/ci-gate-verdict.py').exists()
    run_temp = root/'workflow-run'
    artifact = run_temp/'full-gate-evidence'
    artifact.mkdir(parents=True)
    env = {**os.environ, 'RUNNER_TEMP': str(run_temp), 'RAW_EXIT': '1', 'CAPTURE_EXIT': '0',
           'REQUESTED_REF': old_head, 'TESTED_REF': old_head,
           'GITHUB_EVENT_NAME': 'workflow_dispatch', 'DISPATCH_REF': old_head}
    def run_step(name):
        return subprocess.run(['bash', '-e', '-o', 'pipefail', '-c', step_body(name)],
            cwd=repo, env=env, capture_output=True, text=True)
    dispatch = workflow.split('  workflow_dispatch:', 1)[1].split('\npermissions:', 1)[0]
    assert 'required: true' in dispatch and 'default:' not in dispatch
    assert "github.event_name == 'workflow_dispatch' ||" in workflow
    assert 'REQUESTED_REF: ${{ inputs.ref || github.sha }}' in workflow
    # panel ruling 2026-09-12: the gate runs on the PR, not again on main. A
    # squash onto an unchanged base yields the tree the PR head already
    # certified, so a push run re-tested passed bytes.
    #
    # Asserting literal spellings is not enough and an earlier revision of this
    # arm did exactly that. YAML accepts a quoted key (`"push":`) and the job
    # condition can be written `'push' == github.event_name`; both restore push
    # runs while a `'\n  push:' not in ...` check stays green. So parse the
    # trigger KEY SET, and reject `push` anywhere in the condition rather than
    # in one spelling of it. No YAML dependency: the runner image is not
    # guaranteed to carry PyYAML, and a control that errors when an import is
    # missing is a hole, not a check.
    def trigger_keys(text):
        block = text.split('\non:\n', 1)[1].split('\npermissions:', 1)[0]
        keys = set()
        for line in block.splitlines():
            match = re.match(r"""^  (?:"([^"]+)"|'([^']+)'|([A-Za-z_][\w.-]*))\s*:""", line)
            if match:
                keys.add(next(g for g in match.groups() if g is not None))
        return keys

    def job_condition(text):
        body = text.split('\n  full-gate:\n', 1)[1]
        match = re.search(r'^    if: >-\n((?:      .*\n)+)', body, re.M)
        assert match, body[:400]
        return match.group(1)

    def check_keys(text):
        keys = trigger_keys(text)
        # panel ruling 2026-09-15: dispatch-only. The pull_request trigger is
        # gone too -- every push to a `gate:full`-labeled PR started a run and
        # cancelled the one in flight (34 of the 100 most recent runs that day).
        assert keys == {'workflow_call', 'workflow_dispatch'}, ('trigger-keys', keys)

    def check_condition(text):
        condition = job_condition(text)
        assert 'push' not in condition.lower(), ('job-condition', condition)
        assert 'pull_request' not in condition and 'labeled' not in condition and 'gate:full' not in condition, ('job-condition', condition)

    check_keys(workflow)
    check_condition(workflow)

    # Each mutation restores push-run behavior; each must red, and on the arm
    # that is supposed to catch it rather than incidentally on the other one.
    quoted = workflow.replace('\n  workflow_call:',
                              '\n  "push":\n    branches: [main]\n  workflow_call:', 1)
    plain = workflow.replace('\n  workflow_call:',
                             '\n  push:\n    branches: [main]\n  workflow_call:', 1)
    reversed_equality = workflow.replace(
        "      github.event_name == 'workflow_dispatch' ||",
        "      'push' == github.event_name ||\n      github.event_name == 'workflow_dispatch' ||", 1)
    pr_key = workflow.replace('\n  workflow_call:',
                              '\n  pull_request:\n    types: [synchronize, labeled]\n  workflow_call:', 1)
    pr_condition = workflow.replace(
        "      github.event_name == 'workflow_dispatch' ||",
        "      github.event.action == 'labeled' ||\n      github.event_name == 'workflow_dispatch' ||", 1)
    for label, mutant, arm in (('plain push key', plain, check_keys),
                               ('quoted push key', quoted, check_keys),
                               ('reversed equality in the condition', reversed_equality, check_condition),
                               ('restored pull_request key', pr_key, check_keys),
                               ('label arm back in the condition', pr_condition, check_condition)):
        assert mutant != workflow, label
        try:
            arm(mutant)
        except AssertionError:
            pass
        else:
            raise AssertionError(f'push-trigger control missed the {label} mutation')
    print('ci-gate-verdict: push and PR triggers absent by key set and condition; 5 restoration mutants red: ok')
    concurrency = workflow.split('concurrency:\n', 1)[1].split('\njobs:', 1)[0]
    # Dispatch-only means every run is a deliberate receipt: each run is its
    # own concurrency group and nothing cancels anything. A per-PR group with
    # cancel-in-progress is the shape that threw away 34 runs on 2026-09-15.
    assert re.search(r'^  group: full-gate-\$\{\{ github\.run_id \}\}$', concurrency, re.M), concurrency
    assert re.search(r'^  cancel-in-progress: false$', concurrency, re.M), concurrency
    assert 'pull_request' not in concurrency and 'format(' not in concurrency, concurrency
    print('ci-gate-verdict: every run is its own concurrency group and never cancels another: ok')
    for event, ref, expected in [('workflow_dispatch', '', 1),
                                 ('workflow_dispatch', old_head, 0),
                                 ('pull_request', '', 0), ('push', '', 0)]:
        env.update(GITHUB_EVENT_NAME=event, DISPATCH_REF=ref)
        result = run_step('Require dispatch ref')
        assert result.returncode == expected, (event, result.stdout, result.stderr)
        if expected:
            assert 'Gate verdict: FAIL — workflow_dispatch requires an explicit ref' in result.stdout
            print(result.stdout.strip())
    print('ci-gate-verdict: dispatch requires ref; other events pass the step untouched: ok')
    captured = run_step('Capture main baseline authority')
    assert captured.returncode == 0, (captured.stdout, captured.stderr)
    assert f'gate-helper-head={main_head}' in (artifact/'revisions.txt').read_text()
    assert (artifact/'ci-gate-baseline.sh').read_text() == Path(capture_script).read_text()
    assert (artifact/'ci-gate-verdict.py').read_text() == Path(script).read_text()
    (artifact/'smoke-all.log').write_text(red([a]).replace(head, old_head))
    compared = run_step('Compare complete receipt with main baseline')
    assert compared.returncode == 0 and 'Gate verdict: PASS' in compared.stdout, (compared.stdout, compared.stderr)
    print('ci-gate-verdict: workflow produces differential on a checkout without helpers: ok')
    for requested, tested, message in [
        ('', old_head, 'requested ref is missing'),
        (main_head, old_head, 'requested ref differs from TESTED_REF'),
        (main_head, main_head, 'checkout HEAD differs from requested ref'),
    ]:
        env.update(REQUESTED_REF=requested, TESTED_REF=tested)
        refused = run_step('Compare complete receipt with main baseline')
        assert refused.returncode == 1 and 'Gate verdict: PASS' not in refused.stdout
        assert f'Gate verdict: FAIL — {message}' in refused.stdout, refused.stdout
        assert refused.stdout in (artifact/'differential.md').read_text()
        print(refused.stdout.strip())
    env.update(REQUESTED_REF=old_head, TESTED_REF=old_head)

    # Present-but-poisoned PR helpers must not approve their own new regression.
    (repo/'scripts').mkdir(exist_ok=True)
    table.parent.mkdir(parents=True, exist_ok=True)
    table.write_text(baseline.replace('2 files', '3 files') + f'| {new} | tap-new | {assertion(new)} |\n')
    pr_capture = repo/'scripts/ci-gate-baseline.sh'
    pr_verdict = repo/'scripts/ci-gate-verdict.py'
    pr_capture.write_text('cp docs/artifacts/ci-gate-baseline.md "$1/baseline.md"\n')
    pr_verdict.write_text('print("Gate verdict: PASS")\n')
    git('add', '.')
    git('commit', '-qm', 'PR helpers approve their own regression')
    pr_head = git('rev-parse', 'HEAD')
    env.update(REQUESTED_REF=pr_head, TESTED_REF=pr_head)
    (artifact/'smoke-all.log').write_text(red([new]).replace(head, pr_head))
    args = ['--baseline', str(artifact/'baseline.md'), '--log', str(artifact/'smoke-all.log'),
            '--raw-exit', '1', '--capture-exit', '0', '--head', pr_head]
    # Positive falsifiers: either tested-head helper can turn this red into PASS.
    poisoned = subprocess.run(['bash', str(pr_capture), str(artifact)], cwd=repo, capture_output=True, text=True)
    assert poisoned.returncode == 0, poisoned.stderr
    trusted_with_pr_table = subprocess.run([sys.executable, script, *args], capture_output=True, text=True)
    assert trusted_with_pr_table.returncode == 0 and 'Gate verdict: PASS' in trusted_with_pr_table.stdout
    (artifact/'baseline.md').write_text(baseline)
    poisoned = subprocess.run([sys.executable, str(pr_verdict), *args], capture_output=True, text=True)
    assert poisoned.returncode == 0 and 'Gate verdict: PASS' in poisoned.stdout

    captured = run_step('Capture main baseline authority')
    assert captured.returncode == 0, (captured.stdout, captured.stderr)
    compared = run_step('Compare complete receipt with main baseline')
    assert compared.returncode == 1 and f'Regressions (1):\n- `{new}`' in compared.stdout, (
        'PR-controlled helper must not approve regression', compared.stdout, compared.stderr)
    assert (artifact/'baseline.md').read_text() == baseline
    assert (artifact/'ci-gate-baseline.sh').read_text() == Path(capture_script).read_text()
    assert (artifact/'ci-gate-verdict.py').read_text() == Path(script).read_text()
    print('ci-gate-verdict: workflow rejects regression despite poisoned PR helpers: ok')

    # A failed Git read must not become a successful empty helper invocation.
    git('update-ref', 'refs/remotes/origin/main', old_head)
    refused = run_step('Capture main baseline authority')
    assert refused.returncode != 0
    print('ci-gate-verdict: missing helper in main refuses workflow capture: ok')

# Retained incident receipts: same filenames, different actual failures.
fixtures = Path(script).parent.parent/'skills/tap/scripts/smoke/fixtures/ci-gate-assertions'
table = fixtures/'baseline.md'
for name, pin, expected in [('main-33959221462.log', '220900df13876e2948705d8531915dd6ad6ecb80', 0),
                            ('pr-33960673463.log', 'b5f0cda2b413b7f4c7a19b17ab0b8365a62893db', 1)]:
    result = subprocess.run([sys.executable, script, '--baseline', str(table),
        '--log', str(fixtures/name), '--raw-exit', '1', '--capture-exit', '0', '--head', pin],
        text=True, capture_output=True)
    assert result.returncode == expected, (str(table), name, result.stdout, result.stderr)
    if expected:
        assert result.stdout.count('REGRESSION inside baseline-red file:') == 2, result.stdout
    else:
        assert result.stdout.count('baseline (same assertion:') == 2, result.stdout
    print(f'ci-gate-verdict: retained {name} against historical baseline: ok')

# The shipped zero table accepts its measured main and removes both old waivers.
for name, pin, raw in [('main-33963329920.log', '33cbe730be31a9e25c37b075f3fe5ca98f1a2170', 0),
                       ('main-33959221462.log', '220900df13876e2948705d8531915dd6ad6ecb80', 1),
                       ('pr-33960673463.log', 'b5f0cda2b413b7f4c7a19b17ab0b8365a62893db', 1)]:
    result = subprocess.run([sys.executable, script, '--baseline', str(shipped),
        '--log', str(fixtures/name), '--raw-exit', str(raw), '--capture-exit', '0', '--head', pin],
        text=True, capture_output=True)
    assert result.returncode == raw, (name, result.stdout, result.stderr)
    assert 'Baseline red set (0):' in result.stdout, result.stdout
    if raw:
        assert result.stdout.count('new failing file (assertion:') == 2, result.stdout
    else:
        assert 'Current red set (0):' in result.stdout, result.stdout
    print(f'ci-gate-verdict: retained {name} against shipped zero baseline: ok')
PY
