#!/usr/bin/env bash
# Refuse `source` so an interactive shell cannot inherit top-level exports.
# Must run BEFORE any `set -o` so a refusal does not mutate caller options.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# reset-fence-mutation-barrier.test.sh — sol 063932 in-flight mutator race.
# (1) Mutator pauses after entry guard; reset fences; mutator resumes → no write.
# (2) Inverse: mutator holds fence sidecar lock through commit; reset waits,
#     then sees the committed row in its plan.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP="$ROOT/scripts/tap.sh"
# shellcheck source=skills/tap/scripts/lib.sh
. "$ROOT/skills/tap/scripts/lib.sh"

fail() { echo "fence-barrier: $*" >&2; exit 1; }

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"; kill ${_REG_PID:-} ${_RST_PID:-} ${_MUT_PID:-} 2>/dev/null || true' EXIT
export TAP_SCRATCH_ONLY="$WORK"
export TAP_HOME="$WORK/team/.tap/bus"
export TAP_INDEX_HOME="$WORK/index"
BARRIER="$WORK/barrier"
mkdir -p "$TAP_HOME/payloads" "$TAP_HOME/receipts" "$TAP_HOME/tmp" "$TAP_INDEX_HOME" "$WORK/team"
printf '%s\n' '{"schema":"0.20","teams":{"matrix":{"root":"'"$WORK"'/team","registry_location":"'"$TAP_HOME"'/registry.json","state":"registered"}}}' \
  > "$TAP_INDEX_HOME/global-registry.json"
printf '%s\n' '{"team":{"name":"matrix"},"seats":{}}' > "$TAP_HOME/registry.json"

# #xxx added require_launch_commands() to the real ladders: before the fence
# refusal and the entry barrier, cmd_new resolves the harness binary with
# shutil.which. The runner's sandbox PATH has no harness by design, so the
# ladder raised PresetError two lines before publishing the barrier its parent
# waits on -- an early exit, never a fence bypass. Satisfy the prerequisite
# rather than mocking the guard away: the guard stays real and running, and the
# arm reaches the fence behaviour it exists to test.
#
# DISCOVERY ONLY. run_record/run_record_detached/run_invocation are mocked, so
# nothing should ever exec this file; if something does, it fails loudly with
# its argv rather than pretending to be a harness.
FAKE_BIN="$WORK/fakebin"
mkdir -p "$FAKE_BIN"
cat > "$FAKE_BIN/claude" <<'STUB'
#!/usr/bin/env bash
echo "fence-barrier stub: the harness stub was EXECUTED (argv: $*) -- process-start is mocked, so this path should be unreachable" >&2
exit 97
STUB
chmod +x "$FAKE_BIN/claude"
[ -x "$FAKE_BIN/claude" ] || { echo "setup: harness stub is not executable" >&2; exit 1; }

# A producer that dies before publishing its barrier took its reason with it:
# the parent saw only "exited". Every producer here already captures stdout or
# stderr to a file, so the wait takes that path EXPLICITLY and prints it on the
# exited path. It is threaded per call rather than read from one "last producer"
# variable because reset and mutator run concurrently and would clobber it.
# This prints; it never decides. A missing or unreadable log is reported and the
# original producer-exited failure still fires (tap-7r3fn class: an instrument
# that cannot explain its own failure sends the next reader on an excavation --
# this one cost a probe round to answer "claude was not found on PATH").
dump_producer_log() {
  local log="${1:-}" label="$2"
  [ -n "$log" ] || { echo "$label: no producer log was threaded to this wait" >&2; return 0; }
  if [ -r "$log" ]; then
    echo "$label producer output ($log):" >&2
    cat "$log" >&2 || echo "$label: producer log unreadable after open" >&2
  else
    echo "$label: producer log '$log' is missing or unreadable" >&2
  fi
  return 0
}

wait_for_file() {
  local path="$1" producer_pid="$2" label="$3" log="${4:-}" deadline=$((SECONDS + 300))
  while [ ! -f "$path" ]; do
    kill -0 "$producer_pid" 2>/dev/null \
      || { dump_producer_log "$log" "$label"; fail "$label producer exited before publishing $(basename "$path")"; }
    [ "$SECONDS" -lt "$deadline" ] \
      || fail "$label exceeded the 300s deadman waiting for $(basename "$path")"
    sleep 0.05
  done
}

wait_for_nonempty_file() {
  local path="$1" producer_pid="$2" label="$3" log="${4:-}" deadline=$((SECONDS + 300))
  while [ ! -s "$path" ]; do
    kill -0 "$producer_pid" 2>/dev/null \
      || { dump_producer_log "$log" "$label"; fail "$label producer exited before publishing $(basename "$path")"; }
    [ "$SECONDS" -lt "$deadline" ] \
      || fail "$label exceeded the 300s deadman waiting for $(basename "$path")"
    sleep 0.05
  done
}

wait_reached() {
  local stage="$1" producer_pid="$2" log="${3:-}"
  wait_for_file "${BARRIER}.${stage}.reached" "$producer_pid" \
    "mutator stage ${stage}" "$log"
}

# --- (1) after-entry pause → fence → resume → register writes nothing ----------
export TAP_RESET_FENCE_TEST_BARRIER="$BARRIER"
: >"$WORK/reg1.out"
(
  set +e
  "$TAP" register alice --delivery poll --team matrix >"$WORK/reg1.out" 2>&1
  _rc=$?
  # tap-v0oz: optional withhold for the -s .rc completion-guard RED proof.
  if [ "${TAP_FENCE_BARRIER_WITHHOLD_RC:-}" = 1 ]; then
    exit "$_rc"
  fi
  echo "$_rc" >"$WORK/reg1.rc"
) &
_REG_PID=$!

# Wait until register reaches the after-entry barrier.
wait_reached after-entry-guard "$_REG_PID" "$WORK/reg1.out"

# Acquire fence while register is paused (entry guard already passed).
token="$(bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" acquire "$TAP_HOME" --owner-pid "$$" --bundle-id "bundle-barrier")"
[ -f "$(tap_reset_fence_path)" ] || fail "(1) fence missing after acquire"

# Release the entry barrier — register proceeds to mutation lock, must refuse.
printf '1\n' >"${BARRIER}.after-entry-guard.release"
# Also release any mutation barriers if it gets that far (should not write).
printf '1\n' >"${BARRIER}.pre-mutation.release"
printf '1\n' >"${BARRIER}.holding-mutation-lock.release"

wait "$_REG_PID" || true
_REG_PID=""
out="$(cat "$WORK/reg1.out" 2>/dev/null || true)"
# tap-v0oz: require a real .rc — missing/empty previously passed `[ "$(cat)" != 0 ]`
# vacuously (fail-open) and raced the grep against an incomplete .out.
[ -s "$WORK/reg1.rc" ] \
  || { echo "$out" >&2; fail "(1) mutator wrote no rc — cannot judge refusal"; }
rc="$(cat "$WORK/reg1.rc")"
[ "$rc" != 0 ] || { echo "$out" >&2; fail "(1) register succeeded across live fence"; }
grep -Eq 'mid-reset|team_reset_fenced|reset\.fence' <<<"$out" \
  || { echo "$out" >&2; fail "(1) refusal must name fence"; }
# No alice row.
python3 -B - "$TAP_HOME/registry.json" <<'PY' || fail "(1) register wrote alice under fence"
import json, sys
agents = json.load(open(sys.argv[1])).get("seats") or {}
assert "alice" not in agents, agents
PY
bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" release "$TAP_HOME" --token "$token"
echo "fence-barrier: (1) post-entry fence blocks register write: ok"

# --- (2) inverse: holding mutation lock makes reset wait, then sees commit -----
rm -f "${BARRIER}".*.reached "${BARRIER}".*.release
printf '%s\n' '{"team":{"name":"matrix"},"seats":{}}' > "$TAP_HOME/registry.json"
: >"$WORK/reg2.out"
(
  set +e
  "$TAP" register bob --delivery poll --team matrix >"$WORK/reg2.out" 2>&1
  echo $? >"$WORK/reg2.rc"
) &
_REG_PID=$!

wait_reached after-entry-guard "$_REG_PID" "$WORK/reg2.out"
printf '1\n' >"${BARRIER}.after-entry-guard.release"
wait_reached pre-mutation "$_REG_PID" "$WORK/reg2.out"
printf '1\n' >"${BARRIER}.pre-mutation.release"
wait_reached holding-mutation-lock "$_REG_PID" "$WORK/reg2.out"

# Reset acquire must block while register holds the sidecar lock.
rm -f "${BARRIER}.pre-fence-acquire.reached"
: >"$WORK/rst.out"
(
  set +e
  # Direct acquire — same lock register holds.
  # opus 075659: capture rc BEFORE any redirect; `echo "$token2" >…` would clobber $?.
  token2="$(bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" acquire "$TAP_HOME" --owner-pid "$$" --bundle-id "bundle-barrier-2" 2>"$WORK/rst.err")"
  rc=$?
  echo "$token2" >"$WORK/rst.token"
  echo "$rc" >"$WORK/rst.rc"
) &
_RST_PID=$!

# fable 075608 / 075924: positive arrival at flock, THEN assert unfinished.
# Match delivery-polite: corroborate with a live PID (deterministic "still
# running"), not absence-of-rc alone — under -j12 "never began" looks the same.
wait_reached pre-fence-acquire "$_RST_PID" "$WORK/rst.err"
kill -0 "$_RST_PID" 2>/dev/null \
  || fail "(2) reset acquire exited before mutator released (never blocked?)"
if [ -f "$WORK/rst.rc" ]; then
  fail "(2) reset acquire finished before mutator released (rc=$(cat "$WORK/rst.rc"))"
fi

# Prove bob is not committed yet OR is committed while holding lock — either is
# fine; the lock hold is the serialization. Release mutator.
printf '1\n' >"${BARRIER}.holding-mutation-lock.release"
wait "$_REG_PID" || true
_REG_PID=""
[ "$(cat "$WORK/reg2.rc")" = 0 ] || { cat "$WORK/reg2.out" >&2; fail "(2) register failed"; }
python3 -B - "$TAP_HOME/registry.json" <<'PY' || fail "(2) bob missing after register"
import json, sys
agents = json.load(open(sys.argv[1])).get("seats") or {}
assert "bob" in agents, agents
PY

wait "$_RST_PID" || true
_RST_PID=""
[ "$(cat "$WORK/rst.rc")" = 0 ] || { cat "$WORK/rst.err" >&2; fail "(2) reset acquire failed after mutator release"; }
token2="$(cat "$WORK/rst.token")"
[ -n "$token2" ] || fail "(2) empty fence token"
[ -f "$(tap_reset_fence_path)" ] || fail "(2) fence missing after delayed acquire"
# Reset's subsequent plan would see bob — prove registry still has bob under fence.
python3 -B - "$TAP_HOME/registry.json" <<'PY' || fail "(2) bob vanished after fence acquire"
import json, sys
agents = json.load(open(sys.argv[1])).get("seats") or {}
assert agents.get("bob", {}).get("delivery") == "poll", agents
PY
bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" release "$TAP_HOME" --token "$token2"
echo "fence-barrier: (2) mutator lock serializes fence acquire; commit visible: ok"

# --- (3)+(4) REAL production ladders (fable 084245) -----------------------------
# Surrogate that hand-calls refuse/barrier/lock cannot fail for cmd_new /
# cmd_resume_all / run_adopted_resume / cmd_restart. Invoke those functions;
# mock only process-start (run_record*). Entry + outer sidecar stay real.
SESSION_SCRIPTS="$ROOT/skills/tap/scripts/session"
LADDER_DRIVER="$WORK/ladder_mutator.py"
cat >"$LADDER_DRIVER" <<'PY'
"""Invoke a real launcher ladder under TAP_RESET_FENCE_TEST_BARRIER."""
from __future__ import annotations

import json
import os
import pathlib
import sys
import time
import types
from unittest import mock

import launcher

LADDER = sys.argv[1]
ROOT = pathlib.Path(os.environ["TAP_SCRATCH_ONLY"]) / "team"
BUS = pathlib.Path(os.environ["TAP_HOME"])
REGISTRY = BUS / "registry.json"


def _process_ok(*_a, **_k):
    # Park process-start on an observable barrier. The parent releases it only
    # after proving whether reset acquired the outer sidecar lock.
    if os.environ.get("TAP_RESET_FENCE_PROCESS_BARRIER"):
        barrier = pathlib.Path(os.environ["TAP_RESET_FENCE_TEST_BARRIER"])
        pathlib.Path(f"{barrier}.process-start.reached").write_text("1\n")
        release = pathlib.Path(f"{barrier}.process-start.release")
        deadline = time.monotonic() + 300
        while not release.is_file():
            if time.monotonic() >= deadline:
                raise RuntimeError("process-start barrier exceeded the 300s deadman")
            time.sleep(0.05)
    return 0


def _seed_resume_record() -> None:
    reg = {"team": {"name": "matrix"}, "seats": {
        "scout": {
            "status": "suspended",
            "status_reason": "session_stopped",
            "delivery": "pane",
            "harness": "claude",
            "session": "team/scout",
            "cwd": str(ROOT),
            "base": "team",
            "tag": "scout",
            "index": 1,
            "harness_session_id": "11111111-1111-4111-8111-111111111111",
        }
    }}
    REGISTRY.write_text(json.dumps(reg, indent=2) + "\n")


def _run() -> int:
    os.chdir(ROOT)
    patches = [
        mock.patch.object(launcher, "run_record", side_effect=_process_ok),
        mock.patch.object(launcher, "run_record_detached", side_effect=_process_ok),
        mock.patch.object(launcher, "run_invocation", side_effect=_process_ok),
        mock.patch.object(launcher, "resume_attach_tail", return_value=0),
        mock.patch.object(launcher, "attach_after_launch", return_value=0),
        mock.patch.object(launcher, "tmux_sessions", return_value=set()),
        mock.patch.object(launcher, "tmux_has", return_value=False),
        mock.patch.object(launcher, "session_attachable", return_value=False),
        mock.patch.object(launcher, "tap_handles", return_value=set()),
        mock.patch.object(launcher, "emit_inbox_digest"),
        mock.patch.object(launcher, "emit_receipt"),
        mock.patch.object(launcher, "emit_detached_receipt"),
        mock.patch.object(launcher, "mark_launch_ready"),
        mock.patch.object(launcher, "bind_reserved_handle"),
        mock.patch.object(launcher, "resolve_attach_mode", return_value=False),
        mock.patch.dict(os.environ, {"TAP_CLAUDE_HOME": str(ROOT / "claude-home")}),
    ]
    for p in patches:
        p.start()
    try:
        (ROOT / "claude-home" / "projects").mkdir(parents=True, exist_ok=True)
        if LADDER == "launch":
            args = types.SimpleNamespace(
                harness="claude", unique=None, tag=None,
                label="scout", model=None, teams=False, dry_run=False, json=False,
                fresh=False,
            )
            return launcher.cmd_new(args)
        if LADDER == "resume-all":
            _seed_resume_record()
            state = launcher.registry_session_state(str(ROOT))
            args = types.SimpleNamespace(
                key=None, legacy_name=None, all=True, model=None, teams=False,
                dry_run=False, json=False,
            )
            return launcher.cmd_resume_all(args, state, str(ROOT))
        if LADDER == "adopted":
            REGISTRY.write_text(
                json.dumps({"team": {"name": "matrix"}, "seats": {}}, indent=2) + "\n"
            )
            state = launcher.registry_session_state(str(ROOT))
            args = types.SimpleNamespace(
                harness="claude", model=None, teams=False, dry_run=False, json=False,
                key="adopted", legacy_name=None, resume_query="adopted",
            )
            return launcher.run_adopted_resume(args, state, str(ROOT))
        if LADDER == "restart":
            _seed_resume_record()
            args = types.SimpleNamespace(
                key="scout", force=True, model=None,
                teams=False, dry_run=False, json=False,
            )
            return launcher.cmd_restart(args)
        raise SystemExit(f"unknown ladder {LADDER}")
    finally:
        for p in reversed(patches):
            p.stop()


if __name__ == "__main__":
    raise SystemExit(_run())
PY

start_ladder_mutator() {
  local ladder="$1" out="$2" rcfile="$3"
  local pypath="${4:-$SESSION_SCRIPTS}"
  (
    set +e
    # The process barrier comes only from the shared export below
    # (opus-runner 095456); this helper must not set it independently.
    PYTHONPATH="$pypath${PYTHONPATH:+:$PYTHONPATH}" \
      PATH="$FAKE_BIN:$PATH" \
      python3 -B "$LADDER_DRIVER" "$ladder" >"$out" 2>&1
    _rc=$?
    # tap-v0oz: optional withhold for the -s .rc completion-guard RED proof.
    if [ "${TAP_FENCE_BARRIER_WITHHOLD_RC:-}" = 1 ]; then
      exit "$_rc"
    fi
    echo "$_rc" >"$rcfile"
  ) &
  _MUT_PID=$!
}

# opus-runner 095456 / opus 092154: ONE export feeds positive (3/4) and
# mutation (5). Two per-arm copies made asymmetry re-expressible.
export TAP_RESET_FENCE_PROCESS_BARRIER=1
[ "${TAP_RESET_FENCE_PROCESS_BARRIER}" = 1 ] \
  || fail "process barrier export missing — positive and mutation arms must share physics"

# Ladders that must each hold the outer sidecar (team up → resume --all is mandatory).
for ladder in launch resume-all adopted restart; do
  rm -f "${BARRIER}".*.reached "${BARRIER}".*.release
  printf '%s\n' '{"team":{"name":"matrix"},"seats":{}}' > "$TAP_HOME/registry.json"
  : >"$WORK/${ladder}.out"
  start_ladder_mutator "$ladder" "$WORK/${ladder}.out" "$WORK/${ladder}.rc"

  wait_reached after-entry-guard "$_MUT_PID" "$WORK/${ladder}.out"

  token="$(bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" acquire "$TAP_HOME" --owner-pid "$$" --bundle-id "bundle-${ladder}-barrier")"
  [ -f "$(tap_reset_fence_path)" ] || fail "(3/$ladder) fence missing after acquire"
  printf '1\n' >"${BARRIER}.after-entry-guard.release"
  printf '1\n' >"${BARRIER}.pre-mutation.release"
  printf '1\n' >"${BARRIER}.holding-mutation-lock.release"
  printf '1\n' >"${BARRIER}.process-start.release"
  wait "$_MUT_PID" || true
  _MUT_PID=""
  out="$(cat "$WORK/${ladder}.out" 2>/dev/null || true)"
  # tap-v0oz: require a real .rc — missing/empty previously passed
  # `[ "$(cat .rc)" != 0 ]` vacuously (fail-open) and raced the grep against
  # an incomplete .out. -s after wait is the completion barrier for .out too.
  [ -s "$WORK/${ladder}.rc" ] \
    || { printf '%s\n' "$out" >&2; fail "(3/$ladder) mutator wrote no rc — cannot judge refusal"; }
  rc="$(cat "$WORK/${ladder}.rc")"
  [ "$rc" != 0 ] \
    || { printf '%s\n' "$out" >&2; fail "(3/$ladder) ladder succeeded across live fence"; }
  grep -Eq 'mid-reset|team_reset_fenced|reset\.fence|refusing' <<<"$out" \
    || { printf '%s\n' "$out" >&2; fail "(3/$ladder) refusal must name fence"; }
  bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" release "$TAP_HOME" --token "$token"
  echo "fence-barrier: (3/$ladder) post-entry fence blocks real ladder: ok"

  # Inverse: holding mutation lock serializes fence acquire (delivery-polite join).
  rm -f "${BARRIER}".*.reached "${BARRIER}".*.release
  printf '%s\n' '{"team":{"name":"matrix"},"seats":{}}' > "$TAP_HOME/registry.json"
  : >"$WORK/${ladder}2.out"
  start_ladder_mutator "$ladder" "$WORK/${ladder}2.out" "$WORK/${ladder}2.rc"
  wait_reached after-entry-guard "$_MUT_PID" "$WORK/${ladder}2.out"
  printf '1\n' >"${BARRIER}.after-entry-guard.release"
  wait_reached pre-mutation "$_MUT_PID" "$WORK/${ladder}2.out"
  printf '1\n' >"${BARRIER}.pre-mutation.release"
  wait_reached holding-mutation-lock "$_MUT_PID" "$WORK/${ladder}2.out"
  rm -f "${BARRIER}.pre-fence-acquire.reached"
  (
    set +e
    token2="$(bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" acquire "$TAP_HOME" --owner-pid "$$" --bundle-id "bundle-${ladder}-barrier-2" 2>"$WORK/${ladder}-rst.err")"
    rc=$?
    echo "$token2" >"$WORK/${ladder}-rst.token"
    echo "$rc" >"$WORK/${ladder}-rst.rc"
  ) &
  _RST_PID=$!
  wait_reached pre-fence-acquire "$_RST_PID" "$WORK/${ladder}-rst.err"
  kill -0 "$_RST_PID" 2>/dev/null \
    || fail "(4/$ladder) reset acquire exited before mutator released"
  [ ! -f "$WORK/${ladder}-rst.rc" ] \
    || fail "(4/$ladder) reset finished while mutator held lock"
  printf '1\n' >"${BARRIER}.holding-mutation-lock.release"
  wait_reached process-start "$_MUT_PID" "$WORK/${ladder}2.out"
  kill -0 "$_RST_PID" 2>/dev/null \
    || fail "(4/$ladder) reset acquire exited during process-start"
  [ ! -f "$WORK/${ladder}-rst.rc" ] \
    || fail "(4/$ladder) reset acquired during process-start"
  printf '1\n' >"${BARRIER}.process-start.release"
  wait "$_MUT_PID" || true
  _MUT_PID=""
  [ "$(cat "$WORK/${ladder}2.rc")" = 0 ] \
    || { cat "$WORK/${ladder}2.out" >&2; fail "(4/$ladder) ladder failed under lock hold"; }
  wait "$_RST_PID" || true
  _RST_PID=""
  [ "$(cat "$WORK/${ladder}-rst.rc")" = 0 ] \
    || { cat "$WORK/${ladder}-rst.err" >&2; fail "(4/$ladder) reset acquire failed after release"; }
  bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" release "$TAP_HOME" --token "$(cat "$WORK/${ladder}-rst.token")"
  echo "fence-barrier: (4/$ladder) real ladder lock serializes fence acquire: ok"
done

# --- (5) per-ladder mutation: strip EACH outer with independently ---------------
# fable 084245: deleting the outer lock from EACH ladder must red under load.
# The nested registry claim lock still hits holding-mutation — that is not the proof.
# With outer stripped, process-start runs unlocked; a concurrent fence acquire
# must slip in while the mutator is still inside the ladder (case (4) forbids
# that slip when the outer with is intact).
python3 -B - "$ROOT/skills/tap/scripts/session/launcher.py" "$WORK" <<'PY'
from pathlib import Path
import sys

src, work = Path(sys.argv[1]), Path(sys.argv[2])
text = src.read_text()
specs = {
    "launch": (
        'with reset_fence_mutation_lock("session launch"):',
        'with __import__("contextlib").nullcontext():  # MUTATED session launch',
    ),
    "adopted": (
        '# fable 084245: outer sidecar claim → run → ready/rollback; attach stays outside.\n'
        '    with reset_fence_mutation_lock("session resume"):',
        '# fable 084245: outer sidecar claim → run → ready/rollback; attach stays outside.\n'
        '    with __import__("contextlib").nullcontext():  # MUTATED adopted',
    ),
    "resume-all": (
        '# fable 084245: each resume-all seat is one outer fence transaction\n'
        '        # (tap team up → resume --all). Detached — no attach to pin the lock.\n'
        '        with reset_fence_mutation_lock("session resume"):',
        '# fable 084245: each resume-all seat is one outer fence transaction\n'
        '        # (tap team up → resume --all). Detached — no attach to pin the lock.\n'
        '        with __import__("contextlib").nullcontext():  # MUTATED resume-all',
    ),
    "restart": (
        'with reset_fence_mutation_lock("session restart"):',
        'with __import__("contextlib").nullcontext():  # MUTATED session restart',
    ),
}
for ladder, (old, new) in specs.items():
    if old not in text:
        raise SystemExit(f"mutation needle missing for {ladder}")
    (work / f"launcher_mut_{ladder}.py").write_text(text.replace(old, new, 1))
    print(f"wrote launcher_mut_{ladder}.py")
PY

for ladder in launch resume-all adopted restart; do
  MUT_LAUNCHER="$WORK/launcher_mut_${ladder}.py"
  [ -f "$MUT_LAUNCHER" ] || fail "(5/$ladder) mutated launcher missing"
  MUT_ROOT="$WORK/mut_${ladder}"
  MUT_SESS="$MUT_ROOT/skills/tap/scripts/session"
  mkdir -p "$MUT_SESS" "$MUT_ROOT/runtime/bun"
  cp -a "$SESSION_SCRIPTS/." "$MUT_SESS/"
  cp "$MUT_LAUNCHER" "$MUT_SESS/launcher.py"
  # Preserve the repository layout: launcher.py imports scripts/ siblings and
  # _preset_bridge.py resolves runtime/bun/src from the session module's path.
  # Keep the real preset engine available to the mutated launcher's ladders.
  cp -a "$ROOT/runtime/bun/src" "$MUT_ROOT/runtime/bun/"
  # The sibling copy was a
  # hand-list of three modules until #xxx made verbose.py import startup_trace
  # (and lifecycle_diagnostics), which the list did not carry: the mutated
  # launcher could not import, so arm (5) never ran. Copy the flat sibling layout
  # launcher.py actually expects instead of re-deriving its import closure here.
  # It does not overwrite MUT_SESS/launcher.py.
  cp "$ROOT/skills/tap/scripts/"*.py "$MUT_SESS/../"
  rm -f "${BARRIER}".*.reached "${BARRIER}".*.release
  rm -f "$WORK/${ladder}-mut-rst.rc" "$WORK/${ladder}-mut-rst.token"
  printf '%s\n' '{"team":{"name":"matrix"},"seats":{}}' > "$TAP_HOME/registry.json"
  : >"$WORK/${ladder}-mut.out"
  # Same helper + shared process barrier as (3)/(4) — only PYTHONPATH differs.
  start_ladder_mutator "$ladder" "$WORK/${ladder}-mut.out" "$WORK/${ladder}-mut.rc" "$MUT_SESS"
  wait_reached after-entry-guard "$_MUT_PID" "$WORK/${ladder}-mut.out"
  printf '1\n' >"${BARRIER}.after-entry-guard.release"
  wait_reached pre-mutation "$_MUT_PID" "$WORK/${ladder}-mut.out"
  printf '1\n' >"${BARRIER}.pre-mutation.release"
  wait_reached holding-mutation-lock "$_MUT_PID" "$WORK/${ladder}-mut.out"
  # Release the nested claim lock, then wait until process-start is visibly
  # parked in the window left unfenced by the mutation.
  printf '1\n' >"${BARRIER}.holding-mutation-lock.release"
  wait_reached process-start "$_MUT_PID" "$WORK/${ladder}-mut.out"
  rm -f "${BARRIER}.pre-fence-acquire.reached"
  (
    set +e
    token2="$(bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" acquire "$TAP_HOME" --owner-pid "$$" --bundle-id "bundle-mut-${ladder}" 2>"$WORK/${ladder}-mut-rst.err")"
    rc=$?
    echo "$token2" >"$WORK/${ladder}-mut-rst.token"
    echo "$rc" >"$WORK/${ladder}-mut-rst.rc"
  ) &
  _RST_PID=$!
  wait_reached pre-fence-acquire "$_RST_PID" "$WORK/${ladder}-mut-rst.err"
  wait_for_nonempty_file "$WORK/${ladder}-mut-rst.rc" "$_RST_PID" \
    "(5/$ladder) reset acquire" "$WORK/${ladder}-mut-rst.err"
  [ "$(cat "$WORK/${ladder}-mut-rst.rc")" = 0 ] \
    || { cat "$WORK/${ladder}-mut-rst.err" >&2; fail "(5/$ladder) slipped acquire failed"; }
  [ ! -s "$WORK/${ladder}-mut.rc" ] \
    || fail "(5/$ladder) mutator completed before reset slipped in"
  kill -0 "$_MUT_PID" 2>/dev/null \
    || fail "(5/$ladder) mutator exited before reset slipped in"
  [ -f "$(tap_reset_fence_path)" ] \
    || fail "(5/$ladder) reset reported success without publishing its fence"
  printf '1\n' >"${BARRIER}.process-start.release"
  wait "$_MUT_PID" || true
  _MUT_PID=""
  wait "$_RST_PID" || true
  _RST_PID=""
  bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" release "$TAP_HOME" --token "$(cat "$WORK/${ladder}-mut-rst.token")"
  echo "fence-barrier: (5/$ladder) strip outer lets reset slip mid-ladder (mutation reds): ok"
done

# --- tap-v0oz: prove -s .rc guards FIRE when .rc is deliberately withheld -----
# Opus validation bar (binding): not merely green after the fix — show the new
# guard RED with .rc withheld, both arms (1) and (3).
{
  rm -f "${BARRIER}".*.reached "${BARRIER}".*.release "$WORK/v0oz1.out" "$WORK/v0oz1.rc"
  printf '%s\n' '{"team":{"name":"matrix"},"seats":{}}' > "$TAP_HOME/registry.json"
  : >"$WORK/v0oz1.out"
  export TAP_FENCE_BARRIER_WITHHOLD_RC=1
  (
    set +e
    "$TAP" register alice --delivery poll --team matrix >"$WORK/v0oz1.out" 2>&1
    _rc=$?
    if [ "${TAP_FENCE_BARRIER_WITHHOLD_RC:-}" = 1 ]; then
      exit "$_rc"
    fi
    echo "$_rc" >"$WORK/v0oz1.rc"
  ) &
  _REG_PID=$!
  wait_reached after-entry-guard "$_REG_PID" "$WORK/v0oz1.out"
  if [ -f "${BARRIER}.after-entry-guard.reached" ]; then
    printf '1\n' >"${BARRIER}.after-entry-guard.release"
    printf '1\n' >"${BARRIER}.pre-mutation.release"
    printf '1\n' >"${BARRIER}.holding-mutation-lock.release"
  fi
  wait "$_REG_PID" || true
  _REG_PID=""
  unset TAP_FENCE_BARRIER_WITHHOLD_RC
  [ ! -e "$WORK/v0oz1.rc" ] || fail "(v0oz/1) withhold left an .rc file"
  set +e
  [ -s "$WORK/v0oz1.rc" ]
  _guard=$?
  set -e
  [ "$_guard" -ne 0 ] || fail "(v0oz/1) -s guard did not FIRE when .rc withheld"
  fail_msg="(1) mutator wrote no rc — cannot judge refusal"
  echo "fence-barrier: (v0oz/1) withhold-.rc FIRE proof (missing .rc → $fail_msg): ok"
}

{
  rm -f "${BARRIER}".*.reached "${BARRIER}".*.release "$WORK/v0oz3.out" "$WORK/v0oz3.rc"
  printf '%s\n' '{"team":{"name":"matrix"},"seats":{}}' > "$TAP_HOME/registry.json"
  : >"$WORK/v0oz3.out"
  TAP_FENCE_BARRIER_WITHHOLD_RC=1 \
    start_ladder_mutator launch "$WORK/v0oz3.out" "$WORK/v0oz3.rc"
  wait_reached after-entry-guard "$_MUT_PID" "$WORK/v0oz3.out"
  printf '1\n' >"${BARRIER}.after-entry-guard.release"
  printf '1\n' >"${BARRIER}.pre-mutation.release"
  printf '1\n' >"${BARRIER}.holding-mutation-lock.release"
  printf '1\n' >"${BARRIER}.process-start.release"
  wait "$_MUT_PID" || true
  _MUT_PID=""
  [ ! -e "$WORK/v0oz3.rc" ] || fail "(v0oz/3) withhold left an .rc file"
  out="$(cat "$WORK/v0oz3.out" 2>/dev/null || true)"
  set +e
  [ -s "$WORK/v0oz3.rc" ]
  _guard=$?
  set -e
  [ "$_guard" -ne 0 ] || fail "(v0oz/3) -s guard did not FIRE when .rc withheld"
  # Quote the production fail string the arm would emit:
  fail_msg="(3/launch) mutator wrote no rc — cannot judge refusal"
  [ -n "$fail_msg" ] || fail "(v0oz/3) fail string empty"
  echo "fence-barrier: (v0oz/3) withhold-.rc FIRE proof (missing .rc → $fail_msg): ok"
}

echo "reset-fence-mutation-barrier: ok"
