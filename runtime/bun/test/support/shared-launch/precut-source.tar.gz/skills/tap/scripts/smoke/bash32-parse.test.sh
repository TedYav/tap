#!/usr/bin/env bash
# bash32-parse.test.sh — every TAP script must PARSE under /bin/bash.
#
# On macOS /bin/bash is 3.2 forever, and a seat with a minimal PATH resolves
# `env bash` to it — Hermes could not register because tap-register.sh used a
# heredoc-inside-$()-inside-double-quotes pattern that bash 3.2 cannot parse
# ("unexpected EOF looking for matching quote"). A script that does not parse
# fails at exec, before any of our error handling exists. This gate covers the
# WHOLE script surface, not just the file that broke.
#
# (On Linux CI /bin/bash is newer, so there the check is a plain parse gate;
# the 3.2 regression is caught on macOS dev machines, where the suite also runs.)
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

shopt -s nullglob

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"

list="$(mktemp)"
trap 'rm -f "$list"' EXIT

# Materialize the existing tracked/untracked shell surface first so a legitimate
# staged-or-unstaged file deletion does not leave a vanished path in the parse set.
# The pipeline status is covered by pipefail.
git -C "$ROOT" ls-files --cached --others --exclude-standard '*.sh' \
  | while IFS= read -r path; do
      [ -f "$ROOT/$path" ] && printf '%s\n' "$path"
    done >"$list" \
  || { echo "bash32-parse: git ls-files failed" >&2; exit 1; }

count=$(wc -l <"$list" | tr -d ' ')

# Floor assertion (150) guards against truncated file lists from partial reads or git errors.
if [ "$count" -lt 150 ]; then
  echo "bash32-parse: error: file count ($count) below minimum floor threshold (150)" >&2
  exit 1
fi

fail=0
while IFS= read -r f; do
  /bin/bash -n "$ROOT/$f" || { echo "bash32-parse: $f does not parse under /bin/bash" >&2; fail=1; }
done <"$list"

[ "$fail" = 0 ] || exit 1

echo "bash32-parse: ok ($count files checked)"
