"""R4 presets cutover: the pre-cutover oracle and the notice-lifetime control.

Two kinds of witness live here.

ORACLE arms pin the Python facade's observable behavior on a small sanitized
fixture, recorded from the incumbent implementation BEFORE the three policy
bodies (`load_preset_catalog`, `try_load_catalog_for_display`,
`resolve_harness_env`) were replaced by bridge forwarders. They pass on both
sides of the cutover — that is the parity proof. The fixture invents every
name and value; nothing here is copied from live operator state.

DELEGATION arms fail while the bodies are still local Python (they do not go
near the bridge) and pass only once the forwarders delegate. They are the RED
observation for this unit.
"""

import contextlib
import io
import math
import pathlib
import sys
import unittest
from unittest import mock

SESSION_DIR = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SESSION_DIR))

import _preset_bridge  # noqa: E402
import presets  # noqa: E402


def capture_stderr(call):
    """Run `call`, returning (value, stderr lines).

    Both notice channels land on stderr after the cutover: Python's
    `emit_notice` prints there, and the bridge relays the engine child's stderr
    verbatim. Capturing the stream is the one observation point that survives
    the cutover unchanged.
    """
    buffer = io.StringIO()
    with contextlib.redirect_stderr(buffer):
        value = call()
    lines = [line for line in buffer.getvalue().splitlines() if line.strip()]
    return value, lines


class CutoverFixture(unittest.TestCase):
    """Sanitized tmp config/presets tree, addressed through `environ` only."""

    def setUp(self):
        import tempfile

        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = pathlib.Path(tmp.name)
        self.config_home = self.root / "config"
        self.home = self.root / "home"
        self.home.mkdir()
        self.config = self.config_home / "tap" / "config.toml"
        self.legacy = self.config_home / "tap" / "presets.toml"
        self.environ = {
            "HOME": str(self.home),
            "XDG_CONFIG_HOME": str(self.config_home),
        }

    def write(self, path: pathlib.Path, body: str, *, mode: int = 0o600) -> pathlib.Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body, encoding="utf-8")
        path.chmod(mode)
        return path

    def write_config(self, body: str, **kwargs) -> pathlib.Path:
        return self.write(self.config, body, **kwargs)

    def load(self, environ=None):
        return capture_stderr(lambda: presets.load_preset_catalog(environ or self.environ))

    def policy(self, harness, environ=None):
        return capture_stderr(lambda: presets.resolve_harness_env(harness, environ or self.environ))


FULL_CONFIG = """\
version = 3

[wormhole]
x = 1

[presets.keeper]
harness = "claude"
params.model = "probe-model"
params.effort = "high"
description = "keeper preset"
family = "keeper-note"

[presets.keeper.env]
PROBE_VAR = "declared"

[presets.keeper.metadata]
pronouns = "they/them"
summary = "keeper summary"
primary_roles = ["reviewer"]
mood = "calm"

[notes]
keeper-note = "the note text"

[roles]
reviewer = "reviews things"

[presets.badlet]
harness = "nope"
"""


class OracleCatalogTests(CutoverFixture):
    """Catalog parity: shapes, fallback arms, notices, lookups."""

    def test_full_fixture_shapes_and_values(self):
        self.write_config(FULL_CONFIG)
        catalog, stderr = self.load()
        # Sorted names, tuple boundary. Dropped presets are NOT names — the
        # incumbent's `names` property is the usable table's sorted keys, and a
        # dropped preset answers through `dropped`/`require`, not `names`.
        self.assertEqual(catalog.names, ("keeper",))
        self.assertIsInstance(catalog.names, tuple)
        # The unknown top-level table degraded out loud, on the emitted channel,
        # beside the dropped-preset notice: two lines, nothing else.
        self.assertEqual(len(stderr), 2, stderr)
        self.assertIn("unknown top-level table 'wormhole'", "\n".join(stderr))
        self.assertIn("preset 'badlet' is not usable", "\n".join(stderr))
        self.assertIn(str(self.config.resolve()), "\n".join(stderr))
        # Dropped preset: present in the file, absent from the catalog, reason kept.
        self.assertIsNone(catalog.get("badlet"))
        self.assertIn("harness must be one of", catalog.dropped["badlet"])
        self.assertIsInstance(catalog.dropped, dict)
        # roles table bound.
        self.assertEqual(catalog.roles, {"reviewer": "reviews things"})

        resolved = catalog.require("keeper")
        self.assertEqual(resolved.harness, "claude")
        self.assertEqual(resolved.model, "probe-model")
        self.assertEqual(resolved.harness_passthrough, ("--effort", "high"))
        self.assertIsInstance(resolved.harness_passthrough, tuple)
        self.assertEqual(resolved.env, {"PROBE_VAR": "declared"})
        self.assertEqual(resolved.param_keys, ("effort",))
        self.assertIsInstance(resolved.param_keys, tuple)
        self.assertEqual(resolved.family, "keeper-note")
        self.assertEqual(resolved.note, "the note text")
        self.assertEqual(resolved.description, "keeper preset")
        self.assertEqual(
            resolved.provenance,
            presets.PresetProvenance(
                name="keeper",
                source_path=str(self.config.resolve()),
                config_digest=resolved.provenance.config_digest,
            ),
        )
        self.assertTrue(resolved.provenance.config_digest.startswith("sha256:"))

        metadata = resolved.metadata
        self.assertEqual(metadata.pronouns, "they/them")
        self.assertEqual(metadata.summary, "keeper summary")
        self.assertEqual(metadata.primary_roles, ("reviewer",))
        for bucket in (
            metadata.primary_roles,
            metadata.secondary_roles,
            metadata.avoid_roles,
            metadata.banned_roles,
        ):
            self.assertIsInstance(bucket, tuple)
        # Unknown metadata keys ride VERBATIM, as tuple-of-pairs, JSON-safe.
        self.assertIsInstance(metadata.extra, tuple)
        self.assertEqual(dict(metadata.extra), {"mood": "calm"})

    def test_longest_prefix_handle_lookup(self):
        self.write_config("version = 3\n" + FULL_CONFIG.split("version = 3\n", 1)[1])
        catalog, _ = self.load()
        self.assertIs(catalog.for_handle("keeper"), catalog.get("keeper"))
        self.assertIs(catalog.for_handle("keeper-2"), catalog.get("keeper"))
        self.assertIsNone(catalog.for_handle("keeperish"))
        self.assertIsNone(catalog.for_handle(""))

    def test_legacy_fallback_is_per_section_and_loud(self):
        self.write_config('version = 3\n[harness.claude.env]\nPOLICY = "on"\n')
        self.write(
            self.legacy,
            'version = 3\n[presets.old]\nharness = "codex"\n',
        )
        catalog, stderr = self.load()
        self.assertEqual(catalog.names, ("old",))
        self.assertEqual(len(stderr), 1, stderr)
        self.assertIn("presets read from", stderr[0])
        self.assertIn(str(self.legacy.resolve()), stderr[0])
        self.assertIn("move them under [presets]", stderr[0])
        # Policy still comes from config.toml in the same read.
        env, stderr = self.policy("claude")
        self.assertEqual(env.env, {"POLICY": "on"})

    def test_config_authority_shadowing_legacy_is_announced(self):
        self.write_config('version = 3\n[presets.new]\nharness = "codex"\n')
        self.write(self.legacy, 'version = 3\n[presets.old]\nharness = "codex"\n')
        catalog, stderr = self.load()
        self.assertEqual(catalog.names, ("new",))
        self.assertEqual(len(stderr), 1, stderr)
        self.assertIn("no longer read and can be deleted", stderr[0])

    def test_vacant_presets_table_falls_back_and_says_so(self):
        self.write_config("version = 3\n[presets]\n")
        self.write(self.legacy, 'version = 3\n[presets.old]\nharness = "codex"\n')
        catalog, stderr = self.load()
        self.assertEqual(catalog.names, ("old",))
        self.assertEqual(len(stderr), 1, stderr)
        self.assertIn("is empty", stderr[0])

    def test_absent_config_refuses_load_and_is_silent_for_policy(self):
        with self.assertRaises(presets.PresetError) as ctx:
            presets.load_preset_catalog(self.environ)
        self.assertEqual(ctx.exception.error_class, "preset_config_missing")
        self.assertTrue(ctx.exception.action.startswith("create "))
        env, stderr = self.policy("codex")
        self.assertEqual(env, presets.HarnessEnv({}, ()))

    def test_wrong_shaped_presets_keeps_authority_without_fallback(self):
        self.write(self.legacy, 'version = 3\n[presets.old]\nharness = "codex"\n')
        self.write_config('version = 3\npresets = ["oops"]\n')
        catalog, stderr = self.load()
        self.assertEqual(catalog.names, ())
        self.assertIn("[presets] is not a table", "\n".join(stderr))

    def test_unreadable_config_refuses_load_and_degrades_policy(self):
        self.write_config('version = 3\n[presets.p]\nharness = "codex"\n', mode=0o666)
        with self.assertRaises(presets.PresetError) as ctx:
            presets.load_preset_catalog(self.environ)
        self.assertEqual(ctx.exception.error_class, "preset_config_insecure")
        self.assertEqual(ctx.exception.action, f"chmod 600 {self.config}")

        env, stderr = self.policy("codex")
        self.assertEqual(env.env, {})
        self.assertEqual(len(env.notices), 1)
        self.assertIn("could not read harness environment policy", env.notices[0])
        self.assertIn("chmod 600", env.notices[0])
        # Returned, not emitted: the launcher's notify gate owns this line.
        self.assertEqual(stderr, [])

    def test_malformed_toml_refuses_load_and_degrades_policy(self):
        self.write_config("version = 3\n[presets.p\nharness =\n")
        with self.assertRaises(presets.PresetError) as ctx:
            presets.load_preset_catalog(self.environ)
        self.assertEqual(ctx.exception.error_class, "preset_config_invalid")
        self.assertIn("TOML parse failed", ctx.exception.detail)
        env, _ = self.policy("codex")
        self.assertEqual(env.env, {})
        self.assertEqual(len(env.notices), 1)
        self.assertIn("not being applied", env.notices[0])

    def test_relative_xdg_follows_the_facade(self):
        environ = dict(self.environ, XDG_CONFIG_HOME="relative/config")
        with self.assertRaises(presets.PresetError) as ctx:
            presets.load_preset_catalog(environ)
        self.assertEqual(ctx.exception.error_class, "preset_config_invalid")
        self.assertIn("XDG_CONFIG_HOME must be absolute", ctx.exception.detail)
        env, _ = self.policy("codex", environ)
        self.assertEqual(len(env.notices), 1)
        self.assertIn("config.toml", env.notices[0])
        self.assertIn("XDG_CONFIG_HOME must be absolute", env.notices[0])

    def test_display_load_is_silent_and_absorbs_everything(self):
        catalog = presets.try_load_catalog_for_display(self.environ)
        self.assertIsNone(catalog)  # nothing written yet
        self.write_config("version = 3\n" + FULL_CONFIG.split("version = 3\n", 1)[1])
        catalog, stderr = capture_stderr(
            lambda: presets.try_load_catalog_for_display(self.environ)
        )
        # Usable names only, exactly like the incumbent's `names` property.
        self.assertEqual(catalog.names, ("keeper",))
        self.assertEqual(stderr, [], "a display read printed prose")

    def test_nonfinite_metadata_values_survive_the_bridge_as_floats(self):
        # Legal TOML `inf` / `-inf` / `nan` under unknown metadata keys are
        # operator DATA. JSON has no spelling for them and `JSON.stringify`
        # collapses them to `null`; the door writes Python-compatible JSON
        # (`json.loads` accepts the literals), so the values reach the facade
        # as real floats -- scalar AND nested -- instead of silently nulling.
        self.write_config(
            'version = 3\n'
            '[presets.nummy]\nharness = "claude"\n'
            'metadata.tolerance = inf\n'
            'metadata.floor = -inf\n'
            'metadata.void = nan\n'
            'metadata.deep = { ring = [inf, -inf, nan] }\n'
        )
        catalog, _ = self.load()
        meta = catalog.get("nummy").metadata
        extra = dict(meta.extra)
        self.assertTrue(math.isinf(extra["tolerance"]) and extra["tolerance"] > 0)
        self.assertTrue(math.isinf(extra["floor"]) and extra["floor"] < 0)
        self.assertTrue(math.isnan(extra["void"]))
        ring = extra["deep"]["ring"]
        self.assertEqual(len(ring), 3)
        self.assertTrue(math.isinf(ring[0]) and ring[0] > 0)
        self.assertTrue(math.isinf(ring[1]) and ring[1] < 0)
        self.assertTrue(math.isnan(ring[2]))


class OraclePolicyTests(CutoverFixture):
    """`resolve_harness_env` parity: degradation arms and refusal texts."""

    def test_policy_table_reaches_the_caller(self):
        self.write_config(
            'version = 3\n'
            '[harness.claude]\npermissions = "auto"\n'
            '[harness.claude.env]\nPOLICY = "on"\n'
            '[harness.claude.params]\nmodel = "policy-model"\n'
        )
        env, stderr = self.policy("claude")
        self.assertEqual(env.env, {"POLICY": "on"})
        self.assertEqual(env.params, {"model": "policy-model"})
        self.assertEqual(env.permissions, "auto")
        self.assertEqual(env.notices, ())
        self.assertEqual(stderr, [])
        # Another harness reads its own table, not this one.
        other, _ = self.policy("codex")
        self.assertEqual(other.env, {})

    def test_only_the_requested_harness_is_fence_checked(self):
        self.write_config(
            'version = 3\n'
            '[harness.codex.env]\nPATH = "/evil"\n'
            '[harness.claude.env]\nSAFE = "yes"\n'
        )
        with self.assertRaises(presets.PresetError) as ctx:
            presets.resolve_harness_env("codex", self.environ)
        self.assertEqual(ctx.exception.error_class, "harness_env_forbidden")
        self.assertIn("[harness.codex.env]", ctx.exception.action)
        self.assertIn("PATH", ctx.exception.detail)
        self.assertIn("fence", ctx.exception.detail)
        env, _ = self.policy("claude")
        self.assertEqual(env.env, {"SAFE": "yes"})

    def test_refusal_order_is_env_then_params_then_permissions(self):
        self.write_config(
            'version = 3\n'
            '[harness.claude]\npermissions = "yolo"\n'
            '[harness.claude.env]\nPATH = "/evil"\n'
            '[harness.claude.params]\nbad = 4\n'
        )
        with self.assertRaises(presets.PresetError) as ctx:
            presets.resolve_harness_env("claude", self.environ)
        self.assertEqual(ctx.exception.error_class, "harness_env_forbidden")

        self.write_config(
            'version = 3\n'
            '[harness.claude]\npermissions = "yolo"\n'
            '[harness.claude.params]\nbad = 4\n'
        )
        with self.assertRaises(presets.PresetError) as ctx:
            presets.resolve_harness_env("claude", self.environ)
        self.assertEqual(ctx.exception.error_class, "preset_config_invalid")
        self.assertIn(
            f'[harness.claude] params.bad must be a boolean, a string, or an array '
            f"of strings",
            ctx.exception.detail,
        )
        self.assertEqual(ctx.exception.action, f"fix {self.config.resolve()}")

        self.write_config(
            'version = 3\n[harness.claude]\npermissions = "yolo"\n'
        )
        with self.assertRaises(presets.PresetError) as ctx:
            presets.resolve_harness_env("claude", self.environ)
        self.assertIn(
            '[harness.claude] permissions must be "bypass" or "auto"',
            ctx.exception.detail,
        )

    def test_unrecognized_tables_and_keys_are_returned_not_emitted(self):
        self.write_config(
            'version = 3\n'
            '[harness.weird]\nenv = { X = "1" }\n'
            '[harness.claude]\nfrobnicate = true\n'
            '[harness.claude.env]\nSAFE = "yes"\n'
        )
        env, stderr = self.policy("claude")
        self.assertEqual(env.env, {"SAFE": "yes"})
        self.assertEqual(len(env.notices), 2, env.notices)
        # Sorted harness order: claude's own unrecognized key, then the weird table.
        self.assertIn("'frobnicate'", env.notices[0])
        self.assertIn("unrecognized key", env.notices[0])
        self.assertIn("[harness.weird]", env.notices[1])
        self.assertIn("unrecognized harness table", env.notices[1])
        # RETURNED data: nothing printed on the emitted channel.
        self.assertEqual(stderr, [])


class NoticeLifetimeControlTests(CutoverFixture):
    """The mixed notice sequence control, across one command and a reset.

    Sequence: catalog load (parser notice, emitted) -> policy resolution
    (policy notices, returned) -> Python notice emission, then the whole thing
    again, then after reset. Suppressed and notify-false arms close it out.
    The control must distinguish emitted parser notices from returned policy
    notices at every step.
    """

    BODY = (
        'version = 3\n'
        '[wormhole]\nx = 1\n'
        '[harness.weird]\nenv = { X = "1" }\n'
        '[harness.claude.env]\nSAFE = "yes"\n'
        '[presets.keeper]\nharness = "claude"\n'
    )

    def setUp(self):
        super().setUp()
        presets.suppress_notices(False)
        self.addCleanup(presets.suppress_notices, False)
        presets.reset_notices()
        self.addCleanup(presets.reset_notices)

    def parser_notice(self, stderr):
        self.assertEqual(len(stderr), 1, stderr)
        self.assertIn("unknown top-level table 'wormhole'", stderr[0])
        return stderr[0]

    def test_one_command_then_reset(self):
        self.write_config(self.BODY)

        # 1. catalog load: parser notice emitted exactly once.
        catalog, stderr = self.load()
        first = self.parser_notice(stderr)

        # 2. policy resolution: policy notices returned, nothing emitted, and
        #    the parser notice does not reprint.
        env, stderr = self.policy("claude")
        self.assertEqual(stderr, [], "policy resolution emitted prose")
        self.assertEqual(len(env.notices), 1)
        self.assertIn("[harness.weird]", env.notices[0])

        # 3. Python emission of the SAME text is deduped against the command
        #    lifetime, whichever channel said it first.
        _, stderr = capture_stderr(lambda: presets.emit_notice(first))
        self.assertEqual(stderr, [], "an already-said notice printed again")

        # 4. Repeat the load in the SAME command: still deduped.
        _, stderr = self.load()
        self.assertEqual(stderr, [])

        # 5. Reset clears the history; suppression is untouched.
        presets.reset_notices()
        _, stderr = self.load()
        self.parser_notice(stderr)

        # 6. The returned policy notice survives independent of the emitted
        #    channel (notify-false arm): the caller chooses, the engine never
        #    prints it on its own.
        env, stderr = self.policy("claude")
        self.assertEqual(stderr, [])
        self.assertEqual(len(env.notices), 1)

    def test_suppressed_command_prints_nothing_and_still_returns(self):
        presets.suppress_notices(True)
        self.write_config(self.BODY)
        catalog, stderr = self.load()
        self.assertEqual(catalog.names, ("keeper",))
        self.assertEqual(stderr, [], "suppression did not reach the parser channel")
        env, stderr = self.policy("claude")
        self.assertEqual(stderr, [])
        self.assertEqual(len(env.notices), 1, "suppression ate returned data")

    def test_native_suppression_survives_facade_reads_until_explicit_unsuppression(self):
        # The suppression starts through the NATIVE door operation, exactly as a
        # native notice.suppress in this command would: the response STATE (not
        # an injected postcondition) is what the facade reads must survive.
        _preset_bridge.call("notice.suppress", on=True)
        self.write_config(self.BODY)

        # Facade reads obey the carried authority and never lift it.
        catalog, stderr = self.load()
        self.assertEqual(catalog.names, ("keeper",))
        self.assertEqual(stderr, [], "facade load lifted a native suppression")
        env, stderr = self.policy("claude")
        self.assertEqual(stderr, [], "policy resolve lifted a native suppression")
        self.assertEqual(len(env.notices), 1, "suppression ate returned data")
        _, stderr = capture_stderr(
            lambda: presets.try_load_catalog_for_display(self.environ))
        self.assertEqual(stderr, [], "display lifted a native suppression")

        # Python emit sites read the SAME carried value, so they are silent too.
        _, stderr = capture_stderr(lambda: presets.emit_notice("any prose at all"))
        self.assertEqual(stderr, [], "emit_notice ignored the carried suppression")

        # A command reset clears the history and PRESERVES suppression.
        presets.reset_notices()
        _, stderr = self.load()
        self.assertEqual(stderr, [], "reset lifted the suppression")

        # Explicit unsuppression is the only way it lifts.
        presets.suppress_notices(False)
        _, stderr = self.load()
        self.parser_notice(stderr)


class DelegationTests(CutoverFixture):
    """The RED arms: they fail until the three bodies delegate."""

    def setUp(self):
        super().setUp()
        self.write_config(
            'version = 3\n'
            '[harness.claude.env]\nSAFE = "yes"\n'
            '[presets.keeper]\nharness = "claude"\n'
        )

    def test_load_preset_catalog_delegates_through_the_bridge(self):
        with mock.patch.object(
            _preset_bridge, "call", side_effect=AssertionError("must delegate")
        ):
            with self.assertRaises(AssertionError):
                presets.load_preset_catalog(self.environ)

    def test_try_load_catalog_for_display_delegates_through_the_bridge(self):
        # The display forwarder ABSORBS engine failures (any Exception -> None)
        # by contract, so delegation is witnessed with a returning mock, not a
        # raising one: the DTO must flow through the bridge AND hydrate.
        payload = {
            "source_path": "/display/oracle.toml",
            "names": ["keeper"],
            "presets": {
                "keeper": {
                    "harness": "codex", "model": None, "harness_passthrough": [],
                    "env": {}, "family": None, "note": None, "description": None,
                    "metadata": None, "param_keys": [],
                    "provenance": {
                        "name": "keeper",
                        "source_path": "/display/oracle.toml",
                        "config_digest": "sha256:delegation-oracle",
                    },
                },
            },
            "dropped": {},
            "roles": None,
        }
        with mock.patch.object(_preset_bridge, "call", return_value=payload) as mocked:
            catalog = presets.try_load_catalog_for_display(self.environ)
        mocked.assert_called_once()
        self.assertEqual(catalog.names, ("keeper",))

    def test_resolve_harness_env_delegates_through_the_bridge(self):
        with mock.patch.object(
            _preset_bridge, "call", side_effect=AssertionError("must delegate")
        ):
            with self.assertRaises(AssertionError):
                presets.resolve_harness_env("claude", self.environ)

    def test_policy_resolve_op_answers_the_real_door(self):
        result = _preset_bridge.call(
            "policy.resolve", harness="claude", env=dict(self.environ)
        )
        self.assertEqual(result["env"], {"SAFE": "yes"})
        self.assertEqual(result["notices"], [])
        self.assertEqual(result["permissions"], "bypass")
        self.assertEqual(result["params"], {})


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
