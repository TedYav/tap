#!/usr/bin/env bash
# ledger-port.test.sh — tap-5h9 vendored ledger: sol §4 B-semantics regressions
# + grok's F2 attack + V1/V2/V3 fixes.
#
# The full collab convergence-ledger smoke (the upstream collaboration-skill smoke/)
# also covers fold.sh, is-converged.sh, and round-count.sh — those three scripts are
# DEFERRED BY NAME on tap-5h9 (P2-LC9 adjudication, tmp/design/overnight-forks.md:223-229):
# collab-loop machinery with no tap consumer tonight. This test covers ONLY the
# carried pieces: ledger.sh + thread-lib.sh + payload_meta.py + lib.sh.
#
# Run: bash skills/tap/scripts/regress/ledger-port.test.sh
# Exit: 0 on all-pass, 1 on any failure.
set -uo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || { echo "ledger-port: not in a git repo" >&2; exit 1; })"
LEDGER_DIR="$REPO_ROOT/skills/tap/scripts/ledger"
LEDGER="$LEDGER_DIR/ledger.sh"

pass=0
fail=0
ok()  { pass=$((pass + 1)); printf '  ok   %s\n' "$1"; }
bad() { fail=$((fail + 1)); printf '  FAIL %s\n' "$1"; }

echo "tap-5h9/ledger-port test  (sol §4 B-semantics + grok F2 attack + V1/V2/V3 fixes)"

[ -f "$LEDGER" ] || { echo "FAIL: $LEDGER not found" >&2; exit 1; }

SMOKE_DIR="$(mktemp -d "${TMPDIR:-/tmp}/tap-ledger-port.XXXXXX")"
SMOKE_DIR="$(cd "$SMOKE_DIR" && pwd)"  # normalize (macOS TMPDIR has trailing /)
trap 'rm -rf "$SMOKE_DIR"' EXIT
export COLLAB_DIR="$SMOKE_DIR/collab"
PAYLOADS_DIR="$SMOKE_DIR/payloads"
mkdir -p "$COLLAB_DIR" "$PAYLOADS_DIR"
echo "  (COLLAB_DIR=$COLLAB_DIR)"

DRIVER=driver
SIDE=peer

create_thread() {
  local tid="$1" opened_by="${2:-$DRIVER}"
  local tdir="$COLLAB_DIR/threads/$tid"
  mkdir -p "$tdir"
  printf '{"opened_by": "%s"}\n' "$opened_by" > "$tdir/metadata.json"
}

# write_payload <pid> <from> [body] — writes a TAP-style .md payload to the payloads dir.
write_payload() {
  local pid="$1" from="${2:-$SIDE}" body="${3:-}"
  local path="$PAYLOADS_DIR/$pid.md"
  {
    printf '%s\n' "---"
    printf 'id: %s\n' "$pid"
    printf 'from: %s\n' "$from"
    printf 'to: %s\n' "$DRIVER"
    printf 'kind: %s\n' "reply"
    printf 'path: %s\n' "$path"
    printf '%s\n' "---"
    printf '%s\n' "$body"
  } >"$path"
}

ledger_status() {
  local tid="$1" item_id="$2" driver="${3:-$DRIVER}"
  bash "$LEDGER" list "$tid" --by "$driver" 2>/dev/null |
    python3 -c 'import json, sys
want = sys.argv[1]
for line in sys.stdin:
    if not line.strip():
        continue
    item = json.loads(line)
    if item.get("id") == want:
        print(item.get("status"))
        break' "$item_id"
}

expect_status() {
  local desc="$1" tid="$2" item_id="$3" want="$4" driver="${5:-$DRIVER}"
  local got
  got="$(ledger_status "$tid" "$item_id" "$driver")"
  [ "$got" = "$want" ] && ok "$desc" || bad "$desc (wanted $want, got ${got:-<missing>})"
}

expect_fail_text() {
  local desc="$1" needle="$2"
  shift 2
  local out
  out="$("$@" 2>&1)"
  local got=$?
  if [ "$got" -ne 0 ] && grep -qiE "$needle" <<<"$out"; then
    ok "$desc"
  else
    bad "$desc (rc=$got output=$out)"
  fi
}

# -- (a) driver-gate rejections at every mutator -------------------------------
TID=t-gate
create_thread "$TID"

echo "-- (a) driver-gate rejections at every mutator --"
bash "$LEDGER" add "$TID" f1 proposed evidence_bearing "driver-note" "missing guard" --by "$DRIVER" >/dev/null 2>&1 \
  && ok "driver can seed the ledger" || bad "driver add rejected"

# Carried from the retired lane suite: readers need no writer identity.
events_out="$(bash "$LEDGER" events "$TID" 2>&1)"
events_rc=$?
if [ "$events_rc" = 0 ] && grep -q '"id": "f1"' <<<"$events_out"; then
  ok "ledger events reads the seeded event without --by"
else
  bad "ledger events failed without --by (rc=$events_rc output=$events_out)"
fi

expect_fail_text "peer direct ledger add is rejected" "REJECT|not the driver|driver" \
  bash "$LEDGER" add "$TID" illegal proposed judgment "x" "y" --by "$SIDE"
expect_fail_text "peer direct ledger transition is rejected" "REJECT|not the driver|driver" \
  bash "$LEDGER" transition "$TID" f1 accepted "" "peer forces accept" --by "$SIDE"
expect_fail_text "peer ledger list is rejected" "REJECT|not the driver|driver" \
  bash "$LEDGER" list "$TID" --by "$SIDE"
expect_fail_text "peer ledger source-ids is rejected" "REJECT|not the driver|driver" \
  bash "$LEDGER" source-ids "$TID" --by "$SIDE"

before_status="$(ledger_status "$TID" f1)"
expect_status "rejected peer transition does not change the ledger" "$TID" f1 "$before_status"

# -- (b) sol §4 regression #1: grok's F2 attack (old never-cited payload) -----
TID=t-grok-attack
create_thread "$TID"

echo "-- (b) sol §4 regression #1: grok's F2 attack (old never-cited payload) --"
# Seed evidence_bearing item citing peer-claim.
bash "$LEDGER" add "$TID" e1 proposed evidence_bearing "peer-claim@src/a.ts:1" "needs evidence" --by "$DRIVER" >/dev/null 2>&1
# Reject it.
bash "$LEDGER" transition "$TID" e1 rejected_with_reason "" "not enough" --by "$DRIVER" >/dev/null 2>&1
# Pre-place an OLD evidence payload on the bus — never cited in any ledger event.
write_payload "old-evidence-20260701T000000Z-deadbeef" "$SIDE" "stale evidence predating rejection"

# Direct accept citing the old payload — MUST FAIL (no prior introduction event).
expect_fail_text "grok attack: old never-cited payload + direct accept FAILS" "no qualifying prior evidence-introduction|PROTOCOL ERROR" \
  bash "$LEDGER" transition "$TID" e1 accepted "old-evidence-20260701T000000Z-deadbeef@stale:1" "trust me" --by "$DRIVER"
expect_status "grok attack: item remains rejected" "$TID" e1 rejected_with_reason

# -- (c) sol §4 regression #2: @ref-suffix alias evasion ----------------------
TID=t-alias
create_thread "$TID"

echo "-- (c) sol §4 regression #2: @ref-suffix alias cannot evade seen-set --"
# Seed citing peer-X@src/a.ts:1.
bash "$LEDGER" add "$TID" a1 proposed evidence_bearing "peer-X@src/a.ts:1" "initial evidence" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" a1 rejected_with_reason "" "not enough" --by "$DRIVER" >/dev/null 2>&1
# Now try to introduce the SAME payload via a different @ref suffix.
write_payload "peer-X-20260718T100000Z-abc" "$SIDE" "evidence"
# Direct accept citing peer-X@src/b.ts:2 — must FAIL as seen (same payload id, alias evasion).
expect_fail_text "same payload different @ref suffix cannot evade seen-set" "already on the table|visible NEW evidence" \
  bash "$LEDGER" transition "$TID" a1 accepted "peer-X@src/b.ts:2" "trust me" --by "$DRIVER"

# -- (d) sol §4 regression #3: introduction BEFORE latest rejection fails --------
TID=t-before-rej
create_thread "$TID"

echo "-- (d) sol §4 regression #3: introduction before latest rejection fails --"
# Seed e1 citing peer-A; reject it (seq 2).
bash "$LEDGER" add "$TID" e1 proposed evidence_bearing "peer-A-20260718T100000Z-aaa" "initial" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" e1 rejected_with_reason "" "not enough" --by "$DRIVER" >/dev/null 2>&1
# Write peer-B and introduce it via a reopen transition BEFORE the rejection — impossible
# by construction (seq is monotonic), but we simulate the "introduction before rejection"
# case by introducing evidence, THEN rejecting, THEN trying to accept citing the pre-rejection intro.
write_payload "peer-B-20260718T100100Z-bbb" "$SIDE" "new evidence"
# Introduce peer-B (seq 3, AFTER rejection at seq 2 — so this is a valid introduction).
bash "$LEDGER" transition "$TID" e1 proposed "peer-B-20260718T100100Z-bbb@src/b.ts:1" "reopening with new evidence" --by "$DRIVER" --source-msg-id "peer-B-20260718T100100Z-bbb" >/dev/null 2>&1
# Reject AGAIN (seq 4) — now the introduction at seq 3 is BEFORE the latest rejection at seq 4.
bash "$LEDGER" transition "$TID" e1 rejected_with_reason "" "still not enough" --by "$DRIVER" >/dev/null 2>&1
# Try to accept citing peer-B — the only introduction (seq 3) is now BEFORE the latest rejection (seq 4).
expect_fail_text "introduction before latest rejection fails" "no qualifying prior evidence-introduction|PROTOCOL ERROR" \
  bash "$LEDGER" transition "$TID" e1 accepted "peer-B-20260718T100100Z-bbb@src/b.ts:1" "evidence resolves it" --by "$DRIVER"

# -- (e) sol §4 regression #4: introduction on another item fails --------------
TID=t-other-item
create_thread "$TID"

echo "-- (e) sol §4 regression #4: introduction on another item fails --"
# Two evidence_bearing items, e1 and e2.
bash "$LEDGER" add "$TID" e1 proposed evidence_bearing "peer-A-20260718T100000Z-aaa" "e1 evidence" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" add "$TID" e2 proposed evidence_bearing "peer-A-20260718T100000Z-aaa" "e2 evidence" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" e1 rejected_with_reason "" "not enough" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" e2 rejected_with_reason "" "not enough" --by "$DRIVER" >/dev/null 2>&1
# Introduce peer-B on e2 (seq 5), NOT e1.
write_payload "peer-B-20260718T100100Z-bbb" "$SIDE" "new evidence"
bash "$LEDGER" transition "$TID" e2 proposed "peer-B-20260718T100100Z-bbb@src/b.ts:1" "reopening e2" --by "$DRIVER" --source-msg-id "peer-B-20260718T100100Z-bbb" >/dev/null 2>&1
# Try to accept e1 citing peer-B — the introduction is on e2, not e1.
expect_fail_text "introduction on another item fails" "no qualifying prior evidence-introduction|PROTOCOL ERROR" \
  bash "$LEDGER" transition "$TID" e1 accepted "peer-B-20260718T100100Z-bbb@src/b.ts:1" "evidence from e2" --by "$DRIVER"

# -- (f) sol §4 regression #5: post-rejection introduction + accept SUCCEEDS -----
TID=t-success
create_thread "$TID"

echo "-- (f) sol §4 regression #5: post-rejection introduction + accept SUCCEEDS --"
bash "$LEDGER" add "$TID" s1 proposed evidence_bearing "peer-A-20260718T100000Z-aaa" "initial" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" s1 rejected_with_reason "" "not enough" --by "$DRIVER" >/dev/null 2>&1
# Write the evidence payload.
EVIDENCE_ID="peer-B-20260718T100100Z-bbb"
write_payload "$EVIDENCE_ID" "$SIDE" "new evidence"
# Two-step: reopen-with-evidence (introduction), then accept citing it.
bash "$LEDGER" transition "$TID" s1 proposed "${EVIDENCE_ID}@src/b.ts:1" "reopening with new evidence" --by "$DRIVER" --source-msg-id "$EVIDENCE_ID" >/dev/null 2>&1 \
  && ok "two-step: reopen-with-evidence (introduction) succeeds" || bad "two-step: introduction failed"
bash "$LEDGER" transition "$TID" s1 accepted "${EVIDENCE_ID}@src/b.ts:1" "evidence resolves the rejection" --by "$DRIVER" >/dev/null 2>&1 \
  && ok "two-step: accept citing introduced evidence SUCCEEDS" || bad "two-step: accept failed"
expect_status "post-rejection introduction + accept SUCCEEDS" "$TID" s1 accepted

# Verify the accept stamped the INTRODUCTION's seq (not its own).
ACCEPT_SEQ="$(python3 -c '
import json, sys
with open(sys.argv[1]) as fh:
    for line in fh:
        line = line.strip()
        if not line: continue
        ev = json.loads(line)
        if ev.get("event") == "transition" and ev.get("id") == "s1" and ev.get("status") == "accepted":
            print(ev.get("seq"))
' "$COLLAB_DIR/threads/$TID/ledger.ndjson")"
INTRO_SEQ="$(python3 -c '
import json, sys
with open(sys.argv[1]) as fh:
    for line in fh:
        line = line.strip()
        if not line: continue
        ev = json.loads(line)
        if ev.get("event") == "transition" and ev.get("id") == "s1" and ev.get("status") == "proposed" and ev.get("source_msg_id") == sys.argv[2]:
            print(ev.get("seq"))
' "$COLLAB_DIR/threads/$TID/ledger.ndjson" "$EVIDENCE_ID")"
STAMPED_SEQ="$(python3 -c '
import json, sys
with open(sys.argv[1]) as fh:
    for line in fh:
        line = line.strip()
        if not line: continue
        ev = json.loads(line)
        if ev.get("event") == "transition" and ev.get("id") == "s1" and ev.get("status") == "accepted":
            print(ev.get("evidence_seq"))
' "$COLLAB_DIR/threads/$TID/ledger.ndjson")"
if [ "$STAMPED_SEQ" = "$INTRO_SEQ" ] && [ "$STAMPED_SEQ" != "$ACCEPT_SEQ" ] && [ -n "$STAMPED_SEQ" ]; then
  ok "accept stamped introduction seq ($STAMPED_SEQ), not its own ($ACCEPT_SEQ)"
else
  bad "accept stamped wrong seq: stamped=$STAMPED_SEQ intro=$INTRO_SEQ accept=$ACCEPT_SEQ"
fi

# Read-time replay passes on the legitimate stamp.
bash "$LEDGER" list "$TID" --by "$DRIVER" >/dev/null 2>&1 && ok "read-time replay passes on legitimate stamp" \
  || bad "read-time replay failed on legitimate stamp"

# -- (g) sol §4 regression #6: forged self-referential evidence_seq=accept_seq FAILS replay --
TID=t-forge-self
create_thread "$TID"

echo "-- (g) sol §4 regression #6: forged self-referential evidence_seq=accept_seq FAILS replay --"
bash "$LEDGER" add "$TID" f1 proposed evidence_bearing "peer-A-20260718T100000Z-aaa" "initial" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" f1 rejected_with_reason "" "not enough" --by "$DRIVER" >/dev/null 2>&1
# Write evidence + introduce it properly (so the introduction exists).
write_payload "peer-B-20260718T100100Z-bbb" "$SIDE" "new evidence"
bash "$LEDGER" transition "$TID" f1 proposed "peer-B-20260718T100100Z-bbb@src/b.ts:1" "reopening" --by "$DRIVER" --source-msg-id "peer-B-20260718T100100Z-bbb" >/dev/null 2>&1
# Now FORGE an accept line directly with evidence_seq == the accept's own seq (self-referential).
python3 - "$COLLAB_DIR" "$TID" <<'PY'
import datetime, json, os, sys
collab_dir, tid = sys.argv[1], sys.argv[2]
ledger_path = os.path.join(collab_dir, "threads", tid, "ledger.ndjson")
last_seq = 0
with open(ledger_path) as fh:
    for line in fh:
        line = line.strip()
        if not line: continue
        ev = json.loads(line)
        last_seq = max(last_seq, ev.get("seq", 0))
forged_seq = last_seq + 1
event = {
    "seq": forged_seq,
    "event": "transition",
    "at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
    "thread_id": tid,
    "id": "f1",
    "status": "accepted",
    "evidence_class": "evidence_bearing",
    "evidence_ref": "peer-B-20260718T100100Z-bbb@src/b.ts:1",
    "rationale": "forged self-referential evidence_seq",
    "from": "rejected_with_reason",
    "evidence_msg_id": "peer-B-20260718T100100Z-bbb",
    "evidence_seq": forged_seq,  # self-referential: == the accept's own seq
}
with open(ledger_path, "a") as fh:
    fh.write(json.dumps(event) + "\n")
PY
expect_fail_text "forged self-referential evidence_seq=accept_seq FAILS replay" "self-referential|forged|stamps the INTRODUCTION" \
  bash "$LEDGER" list "$TID" --by "$DRIVER"

# -- (h) sol §4 regression #7: judgment/assertion exemptions unchanged ---------
TID=t-judg
create_thread "$TID"

echo "-- (h) sol §4 regression #7: judgment/assertion exemptions unchanged (F5) --"
bash "$LEDGER" add "$TID" j1 proposed judgment "naming taste" "rename for clarity" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" j1 rejected_with_reason "" "keep current name" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" j1 accepted "" "better argument wins" --by "$DRIVER" >/dev/null 2>&1 \
  && ok "judgment reversal without evidence is allowed (F5 exemption)" \
  || bad "judgment reversal without evidence failed"
expect_status "judgment reversal without evidence is accepted" "$TID" j1 accepted

# Also: assertion_only exemption.
bash "$LEDGER" add "$TID" a1 proposed assertion_only "claim" "unbacked" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" a1 rejected_with_reason "" "no" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" a1 accepted "" "ok" --by "$DRIVER" >/dev/null 2>&1 \
  && ok "assertion_only reversal without evidence is allowed (F5 exemption)" \
  || bad "assertion_only reversal without evidence failed"
expect_status "assertion_only reversal without evidence is accepted" "$TID" a1 accepted

# -- (i) monotonic seq + torn-file fail-loud -----------------------------------
echo "-- (i) monotonic seq + torn-file fail-loud --"

TID=t-malformed
create_thread "$TID"
bash "$LEDGER" add "$TID" m1 proposed judgment "x" "y" --by "$DRIVER" >/dev/null 2>&1
printf '%s\n' 'this is not valid json {{{' >> "$COLLAB_DIR/threads/$TID/ledger.ndjson"
expect_fail_text "malformed JSON line in ledger fails loud" "malformed ledger line|fail loud" \
  bash "$LEDGER" list "$TID" --by "$DRIVER"

TID=t-seqgap
create_thread "$TID"
bash "$LEDGER" add "$TID" s1 proposed judgment "x" "y" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" s1 accepted "" "ok" --by "$DRIVER" >/dev/null 2>&1
# Append a line with seq=5 (gap from expected seq=3).
python3 - "$COLLAB_DIR" "$TID" <<'PY'
import datetime, json, os, sys
collab_dir, tid = sys.argv[1], sys.argv[2]
ledger_path = os.path.join(collab_dir, "threads", tid, "ledger.ndjson")
event = {
    "seq": 5,
    "event": "transition",
    "at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
    "thread_id": tid,
    "id": "gap_item",
    "status": "accepted",
    "evidence_class": "judgment",
    "evidence_ref": None,
    "rationale": "seq gap test",
    "from": "proposed",
}
with open(ledger_path, "a") as fh:
    fh.write(json.dumps(event) + "\n")
PY
expect_fail_text "seq gap fails loud (monotonic +1 invariant)" "corrupt ledger|expected seq|monotonic" \
  bash "$LEDGER" list "$TID" --by "$DRIVER"

# -- (j) V1: lib.sh non-git fallback walks 4-up to repo root --------------------
echo "-- (j) V1: lib.sh non-git fallback walks 4-up to repo root --"
# Create a fake non-git directory mimicking the TAP depth: <fake>/skills/tap/scripts/ledger/
FAKE_ROOT="$SMOKE_DIR/fake-root"
FAKE_LEDGER_DIR="$FAKE_ROOT/skills/tap/scripts/ledger"
mkdir -p "$FAKE_LEDGER_DIR"
# Copy only the .sh and .py files (not __pycache__).
for f in lib.sh thread-lib.sh ledger.sh payload_meta.py; do
  cp "$LEDGER_DIR/$f" "$FAKE_LEDGER_DIR/$f"
done
# Run lib.sh from the fake non-git location and verify it resolves to <fake-root>/.tap/bus/collab.
# We unset COLLAB_DIR and run outside any git repo so the fallback fires.
RESOLVED="$(cd "$FAKE_LEDGER_DIR" && env -u COLLAB_DIR bash -c '. ./lib.sh; printf "%s" "$COLLAB_DIR"' 2>&1)"
EXPECTED_FAKE_HOME="$FAKE_ROOT/.tap/bus/collab"
if [ "$RESOLVED" = "$EXPECTED_FAKE_HOME" ]; then
  ok "V1: lib.sh non-git fallback resolves to repo root (4-up): $RESOLVED"
else
  bad "V1: lib.sh non-git fallback resolved to '$RESOLVED' (expected '$EXPECTED_FAKE_HOME')"
fi

# -- (k) V2: refuse at first ledger use on a legacy tmp/tap bus -----------------
echo "-- (k) V2: refuse at first ledger use on a legacy tmp/tap bus --"
# Create a fake repo with a non-empty tmp/tap (legacy layout).
LEGACY_ROOT="$SMOKE_DIR/legacy-root"
mkdir -p "$LEGACY_ROOT/tmp/tap/payloads"
printf 'legacy\n' > "$LEGACY_ROOT/tmp/tap/payloads/old.md"
# Place a copy of the ledger scripts at the right depth inside the fake repo.
LEGACY_LEDGER_DIR="$LEGACY_ROOT/skills/tap/scripts/ledger"
mkdir -p "$LEGACY_LEDGER_DIR"
for f in lib.sh thread-lib.sh ledger.sh payload_meta.py; do
  cp "$LEDGER_DIR/$f" "$LEGACY_LEDGER_DIR/$f"
done
# Initialize as a git repo so git rev-parse resolves the root.
git init -q "$LEGACY_ROOT"
# Run lib.sh from the legacy-repo ledger dir — the legacy-bus refuse MUST fire.
LEGACY_OUT="$(cd "$LEGACY_LEDGER_DIR" && env -u COLLAB_DIR bash -c '. ./lib.sh' 2>&1)"
LEGACY_RC=$?
if [ "$LEGACY_RC" -ne 0 ] && grep -qiE "legacy tmp/tap|split-brain|tap init" <<<"$LEGACY_OUT"; then
  ok "V2: legacy tmp/tap bus refuse fires (names 'tap init')"
else
  bad "V2: legacy refuse did not fire (rc=$LEGACY_RC output=$LEGACY_OUT)"
fi

# -- (l) V3 revised: _scan_payloads skips torn payload (fail-closed), specific error --
echo "-- (l) V3 revised: _scan_payloads skips torn payload (fail-closed), specific error --"
TID=t-torn-payload
create_thread "$TID"
bash "$LEDGER" add "$TID" tp1 proposed evidence_bearing "peer-A-20260718T100000Z-aaa" "initial" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" tp1 rejected_with_reason "" "not enough" --by "$DRIVER" >/dev/null 2>&1
# Write a TORN payload to the bus (unterminated frontmatter).
printf '%s\n' '---' 'id: torn-20260718T100100Z-ccc' 'from: peer' > "$PAYLOADS_DIR/torn-20260718T100100Z-ccc.md"
# Citing the torn evidence must FAIL with a specific "exists but unreadable/torn" error
# (not the generic "not on bus" text). The accept is refused (fail-closed).
expect_fail_text "V3: cited torn evidence refused with specific error" "exists on the bus but is unreadable|torn|cannot parse" \
  bash "$LEDGER" transition "$TID" tp1 accepted "torn-20260718T100100Z-ccc@src/c.ts:1" "trust me" --by "$DRIVER"

# A SEPARATE accept citing a VALID evidence payload must still succeed even though
# the torn payload is on the same bus (availability-safe: one torn payload does not
# block every evidence-validated accept).
TID=t-torn-bus-ok
create_thread "$TID"
bash "$LEDGER" add "$TID" tp2 proposed evidence_bearing "peer-A-20260718T100000Z-aaa" "initial" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" tp2 rejected_with_reason "" "not enough" --by "$DRIVER" >/dev/null 2>&1
VALID_EV="peer-valid-20260718T100200Z-ddd"
write_payload "$VALID_EV" "$SIDE" "valid evidence alongside a torn payload"
bash "$LEDGER" transition "$TID" tp2 proposed "${VALID_EV}@src/d.ts:1" "reopening" --by "$DRIVER" --source-msg-id "$VALID_EV" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" tp2 accepted "${VALID_EV}@src/d.ts:1" "evidence resolves it" --by "$DRIVER" >/dev/null 2>&1 \
  && ok "V3: valid evidence accepted alongside torn payload (availability-safe)" \
  || bad "V3: torn payload blocked a valid evidence accept (bus-wide DoS)"

# -- (m) HANDLE_RE widening (adaptation #1) -------------------------------------
echo "-- (m) HANDLE_RE widening (adaptation #1: TAP_ID_RE ^[A-Za-z0-9][A-Za-z0-9._-]*\$) --"

TID=t-wide
create_thread "$TID" "Driver.2"

bash "$LEDGER" add "$TID" w1 proposed evidence_bearing "peer-A-20260718T100000Z-aaa" "initial" --by "Driver.2" >/dev/null 2>&1 \
  && ok "uppercase+dotted driver handle accepted (widened HANDLE_RE)" \
  || bad "uppercase+dotted driver handle rejected"
bash "$LEDGER" transition "$TID" w1 rejected_with_reason "" "not enough" --by "Driver.2" >/dev/null 2>&1
# Write an evidence payload with an uppercase+dotted from handle.
WIDE_EVREF="Peer.1-20260718T101000Z-wde00000"
write_payload "$WIDE_EVREF" "Peer.1" "evidence from uppercase+dotted handle"
# Two-step: introduce + accept.
bash "$LEDGER" transition "$TID" w1 proposed "${WIDE_EVREF}@src/b.ts:5" "reopening" --by "Driver.2" --source-msg-id "$WIDE_EVREF" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" w1 accepted "${WIDE_EVREF}@src/b.ts:5" "new evidence" --by "Driver.2" >/dev/null 2>&1 \
  && ok "evidence from uppercase+dotted from-handle accepted" \
  || bad "evidence from uppercase+dotted from-handle rejected"
expect_status "widened HANDLE_RE evidence round-trips" "$TID" w1 accepted "Driver.2"

# -- (n) monotonic seq allocation (sol §9) ---------------------------------------
echo "-- (n) monotonic seq allocation (sol §9) --"

TID=t-seq
create_thread "$TID"
bash "$LEDGER" add "$TID" q1 proposed judgment "x" "y" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" transition "$TID" q1 accepted "" "ok" --by "$DRIVER" >/dev/null 2>&1
bash "$LEDGER" add "$TID" q2 proposed judgment "x" "y" --by "$DRIVER" >/dev/null 2>&1

SEQS="$(python3 -c '
import json, sys
with open(sys.argv[1]) as fh:
    for line in fh:
        line = line.strip()
        if not line: continue
        ev = json.loads(line)
        print(ev.get("seq"))
' "$COLLAB_DIR/threads/$TID/ledger.ndjson")"
EXPECTED_SEQS=$'1\n2\n3'
if [ "$SEQS" = "$EXPECTED_SEQS" ]; then
  ok "monotonic seq allocation: 1, 2, 3"
else
  bad "monotonic seq allocation: expected 1/2/3, got: $(echo "$SEQS" | tr '\n' '/')"
fi

echo "tap-5h9/ledger-port test: $pass passed, $fail failed"
[ "$fail" -eq 0 ]
