#!/usr/bin/env bash
# tap-de02 — `tap team attach` plans ordered tab viewers for unattached seats,
# snapshots every live seat, and never crosses into session lifecycle behavior.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP="$ROOT/scripts/tap.sh"
CONTRACT="$ROOT/skills/tap/scripts/CONTRACT.md"
WORK="$(mktemp -d)"
FAKE_BIN="$(mktemp -d)"
TEAM_ROOT="$WORK/demo"
export TAP_HOME="$TEAM_ROOT/.tap/bus"
export PATH="$FAKE_BIN:$PATH"
export LIVE_SESSIONS="$WORK/live-sessions"
export TMUX_LOG="$WORK/tmux.log"
export OSASCRIPT_LOG="$WORK/osascript.log"
export OSASCRIPT_INPUT="$WORK/osascript-input"
trap 'rm -rf "$WORK" "$FAKE_BIN"' EXIT

mkdir -p "$TAP_HOME/payloads" "$TAP_HOME/receipts" "$WORK/elsewhere"
printf '%s\n' demo/a demo/b demo/c demo/d demo/e demo/f demo/g >"$LIVE_SESSIONS"

${TAP_PYTHON:-python3} -B - "$TAP_HOME/registry.json" "$TEAM_ROOT" <<'PY'
import json
import sys

registry, cwd = sys.argv[1:]
rows = {}
for handle in "abcdefg":
    rows[handle] = {
        "status": "active",
        "delivery": "pane",
        "session": f"demo/{handle}",
        "harness": "codex",
        "registered_from_worktree": cwd,
        "base": "demo",
        "tag": handle,
        "index": 1,
    }
rows.update({
    "h": {
        "status": "active",
        "delivery": "pane",
        "session": "demo/h",
        "harness": "opencode",
        "registered_from_worktree": cwd,
        "base": "demo",
        "tag": "h",
        "index": 1,
        "harness_session_id": "native-h",
    },
    "i": {
        "status": "active",
        "delivery": "pane",
        "session": "demo/i",
        "harness": "cursor",
        "registered_from_worktree": cwd,
        "base": "demo",
        "tag": "i",
        "index": 1,
    },
})
with open(registry, "w", encoding="utf-8") as fh:
    json.dump({"team": {"name": "demo", "worktree_root": cwd}, "agents": rows}, fh)
    fh.write("\n")
PY

cat >"$FAKE_BIN/tmux" <<'TMUX'
#!/usr/bin/env bash
set -euo pipefail
cmd="${1:-}"
shift || true
{
  printf '%s' "$cmd"
  for arg in "$@"; do printf ' %s' "$arg"; done
  printf '\n'
} >>"$TMUX_LOG"

case "$cmd" in
  list-sessions)
    cat "$LIVE_SESSIONS"
    ;;
  list-clients)
    target=""
    while [ "$#" -gt 0 ]; do
      case "$1" in
        -t) target="${2:-}"; shift 2 ;;
        -F) shift 2 ;;
        *) shift ;;
      esac
    done
    [ "${FAIL_CLIENT_TARGET:-}" != "$target" ] || exit 1
    [ "$target" != "=demo/b" ] || printf '%s\n' /dev/ttys010
    if [ -e "$OSASCRIPT_INPUT" ] \
      && grep -Fq "exec tmux attach -t '$target'" "$OSASCRIPT_INPUT" \
      && [ "${NO_NEW_CLIENT_TARGET:-}" != "$target" ]; then
      if [ "${DELAY_NEW_CLIENT_TARGET:-}" = "$target" ]; then
        probe_count="$(grep -Fxc "list-clients -t $target -F #{client_tty}" "$TMUX_LOG" || true)"
        [ "$probe_count" -ge 3 ] || exit 0
      fi
      printf '/dev/tap-%s\n' "${target#=demo/}"
    fi
    ;;
  *)
    exit 0
    ;;
esac
TMUX
chmod +x "$FAKE_BIN/tmux"

cat >"$FAKE_BIN/osascript" <<'OSASCRIPT'
#!/usr/bin/env bash
set -euo pipefail
{
  printf 'osascript'
  for arg in "$@"; do printf ' %s' "$arg"; done
  printf '\n'
} >>"$OSASCRIPT_LOG"

case "${1:-}" in
  -e)
    [ "${ITERM_CAPABLE:-1}" = 1 ] || exit 1
    printf '%s\n' com.googlecode.iterm2
    ;;
  -)
    cat >"$OSASCRIPT_INPUT"
    exit "${OSASCRIPT_EXEC_RC:-0}"
    ;;
  *)
    exit 1
    ;;
esac
OSASCRIPT
chmod +x "$FAKE_BIN/osascript"

reset_logs() {
  : >"$TMUX_LOG"
  : >"$OSASCRIPT_LOG"
  rm -f "$OSASCRIPT_INPUT"
}

assert_contains() {
  local haystack="$1" needle="$2" label="$3"
  [[ "$haystack" == *"$needle"* ]] || {
    echo "team-attach: missing $label: $needle" >&2
    printf '%s\n' "$haystack" >&2
    exit 1
  }
}

quoted_root="$(${TAP_PYTHON:-python3} -c 'import shlex,sys; print(shlex.quote(sys.argv[1]))' "$TEAM_ROOT")"
attach_text() {
  printf 'cd %s && exec tmux attach -t %s' "$quoted_root" "$1"
}

# (0) Session scope follows the explicit bus team, not an unrelated shell cwd.
reset_logs
rc=0
scoped="$(cd "$WORK/elsewhere" && "$TAP" team attach --dry-run 2>&1)" || rc=$?
[ "$rc" = 0 ] || {
  echo "team-attach: bus-root dry-run exited $rc" >&2
  printf '%s\n' "$scoped" >&2
  exit 1
}
assert_contains "$scoped" "plan for team 'demo' (6 new viewer(s))" "bus-root session scope"
assert_contains "$scoped" "$(attach_text "'=demo/a'")" "bus-root live session starts in team worktree"
[[ "$scoped" != *"cd '$WORK/elsewhere'"* ]] || {
  echo "team-attach: bus-root plan used the caller cwd instead of the team worktree" >&2
  printf '%s\n' "$scoped" >&2
  exit 1
}
[[ "$scoped" != *"exec tmux attach -t '=demo/b'"* ]] || {
  echo "team-attach: bus-root plan included already-attached demo/b" >&2
  printf '%s\n' "$scoped" >&2
  exit 1
}
echo "team-attach: (0) explicit TAP_HOME anchors session scope outside the team cwd: ok"

# (1) Capable iTerm path: six unattached live sessions produce one ordered tab
# each, while the attached seat's immutable pre-image is disclosed and skipped.
reset_logs
export ITERM_CAPABLE=1
rc=0
out="$(cd "$TEAM_ROOT" && TERM_PROGRAM=tmux "$TAP" team attach 2>&1)" || rc=$?
[ "$rc" = 0 ] || {
  echo "team-attach: capable path exited $rc" >&2
  printf '%s\n' "$out" >&2
  exit 1
}
[ -s "$OSASCRIPT_INPUT" ] || {
  echo "team-attach: capable path did not execute generated AppleScript" >&2
  exit 1
}
if ! grep -Fq 'split vertically' "$OSASCRIPT_INPUT" \
  && ! grep -Fq 'split horizontally' "$OSASCRIPT_INPUT"; then
  echo "team-attach: default pane layout must split the window into viewer sessions" >&2
  cat "$OSASCRIPT_INPUT" >&2
  exit 1
fi
pre_write_delay_line="$(grep -n '^  delay 0\.4$' "$OSASCRIPT_INPUT" | cut -d: -f1 || true)"
first_write_line="$(grep -n 'write text' "$OSASCRIPT_INPUT" | head -1 | cut -d: -f1 || true)"
last_write_line="$(grep -n 'write text' "$OSASCRIPT_INPUT" | tail -1 | cut -d: -f1 || true)"
post_write_delay_line="$(grep -n '^  delay 0\.6$' "$OSASCRIPT_INPUT" | cut -d: -f1 || true)"
first_title_line="$(grep -n 'set name of item' "$OSASCRIPT_INPUT" | head -1 | cut -d: -f1 || true)"
[ -n "$pre_write_delay_line" ] \
  && [ -n "$post_write_delay_line" ] \
  && [ -n "$first_title_line" ] \
  && [ "$pre_write_delay_line" -lt "$first_write_line" ] \
  && [ "$last_write_line" -lt "$post_write_delay_line" ] \
  && [ "$post_write_delay_line" -lt "$first_title_line" ] || {
  echo "team-attach: settle delay must precede the first write text" >&2
  cat "$OSASCRIPT_INPUT" >&2
  exit 1
}

pane_index=0
for handle in a c d e f g; do
  pane_index=$((pane_index + 1))
  [ "$(grep -Fc "$(attach_text "'=demo/$handle'")" "$OSASCRIPT_INPUT")" = 1 ] || {
    echo "team-attach: demo/$handle should appear in exactly one attach command" >&2
    cat "$OSASCRIPT_INPUT" >&2
    exit 1
  }
  grep -Fqx "  tell item $pane_index of viewerSessions to write text \"$(attach_text "'=demo/$handle'")\"" "$OSASCRIPT_INPUT" || {
    echo "team-attach: demo/$handle should map to ordered pane session $pane_index" >&2
    cat "$OSASCRIPT_INPUT" >&2
    exit 1
  }
  grep -Fqx "  set name of item $pane_index of viewerSessions to \"$handle\"" "$OSASCRIPT_INPUT" || {
    echo "team-attach: demo/$handle title should map to ordered pane session $pane_index" >&2
    cat "$OSASCRIPT_INPUT" >&2
    exit 1
  }
  grep -Fqx "list-clients -t =demo/$handle -F #{client_tty}" "$TMUX_LOG" || {
    echo "team-attach: missing exact client probe for demo/$handle" >&2
    cat "$TMUX_LOG" >&2
    exit 1
  }
done

grep -Fq "exec tmux attach -t '=demo/b'" "$OSASCRIPT_INPUT" && {
  echo "team-attach: already-attached demo/b must not receive another viewer" >&2
  cat "$OSASCRIPT_INPUT" >&2
  exit 1
}
grep -Eq '^  set name of current session of item [0-9]+ of viewerTabs to "b"$' "$OSASCRIPT_INPUT" && {
  echo "team-attach: skipped demo/b must not receive a tab title" >&2
  cat "$OSASCRIPT_INPUT" >&2
  exit 1
}
[ "$(grep -Fc 'list-clients -t =demo/b -F #{client_tty}' "$TMUX_LOG")" = 1 ] || {
  echo "team-attach: skipped demo/b should only receive its immutable pre-image probe" >&2
  cat "$TMUX_LOG" >&2
  exit 1
}
assert_contains "$out" "skipped because already attached: b (/dev/ttys010)" "pre-existing client receipt"
assert_contains "$out" "h (resume tier exact" "exact unavailable tier"
assert_contains "$out" "i (resume tier fresh" "fresh unavailable tier"
assert_contains "$out" "verified 6 new iTerm viewer(s) for team 'demo'" "verified viewer receipt"
[[ "$out" != *"opened 6 iTerm viewer"* ]] || {
  echo "team-attach: capable path printed an unverified opened-count" >&2
  printf '%s\n' "$out" >&2
  exit 1
}
grep -Eq 'team up|session (resume|restart)|session launch' "$OSASCRIPT_INPUT" && {
  echo "team-attach: generated viewer script crossed into lifecycle behavior" >&2
  cat "$OSASCRIPT_INPUT" >&2
  exit 1
}
echo "team-attach: (1) ordered tab planner, exact pre-image, and partial receipt: ok"

# (1a) Re-running after the first attach observes every live session as already
# attached and does not send another command or execute another AppleScript.
automation_runs="$(grep -Fxc 'osascript -' "$OSASCRIPT_LOG")"
rc=0
repeat="$(cd "$TEAM_ROOT" && "$TAP" team attach 2>&1)" || rc=$?
[ "$rc" = 0 ] || {
  echo "team-attach: idempotent rerun exited $rc" >&2
  printf '%s\n' "$repeat" >&2
  exit 1
}
[ "$(grep -Fxc 'osascript -' "$OSASCRIPT_LOG")" = "$automation_runs" ] || {
  echo "team-attach: idempotent rerun executed another AppleScript" >&2
  cat "$OSASCRIPT_LOG" >&2
  exit 1
}
[[ "$repeat" != *"tmux attach -t"* ]] || {
  echo "team-attach: idempotent rerun printed an attach command" >&2
  printf '%s\n' "$repeat" >&2
  exit 1
}
assert_contains "$repeat" "all 7 live seat(s) were already attached" "idempotent rerun receipt"
assert_contains "$repeat" "skipped because already attached: a (/dev/tap-a), b (/dev/ttys010)" "idempotent skipped receipt"
echo "team-attach: (1a) repeated attach opens no duplicate viewers: ok"

# (1b) AppleScript success is not attachment proof. Every planned session must
# gain a client relative to the immutable pre-image or the named seat stays loud.
reset_logs
export NO_NEW_CLIENT_TARGET='=demo/c'
rc=0
unverified="$(cd "$TEAM_ROOT" && "$TAP" team attach 2>&1)" || rc=$?
unset NO_NEW_CLIENT_TARGET
[ "$rc" = 1 ] || {
  echo "team-attach: missing-client verification exited $rc, want 1" >&2
  printf '%s\n' "$unverified" >&2
  exit 1
}
assert_contains "$unverified" "no new tmux client observed after 10 bounded probe(s) for: c" "named verification failure"
assert_contains "$unverified" "tmux attach -t '=demo/c'" "verification-failure manual command"
assert_contains "$unverified" "skipped because already attached: b (/dev/ttys010)" "verification-failure pre-image"
assert_contains "$unverified" "h (resume tier exact" "verification-failure exact disclosure"
assert_contains "$unverified" "i (resume tier fresh" "verification-failure fresh disclosure"
[[ "$unverified" != *"verified 6 new iTerm viewer"* ]] || {
  echo "team-attach: missing-client path printed a false verified count" >&2
  printf '%s\n' "$unverified" >&2
  exit 1
}
[ "$(grep -Fc 'list-clients -t =demo/c -F #{client_tty}' "$TMUX_LOG")" = 11 ] || {
  echo "team-attach: demo/c should have one pre-image and ten bounded post-open probes" >&2
  cat "$TMUX_LOG" >&2
  exit 1
}
echo "team-attach: (1b) post-open proof names every seat without a new client: ok"

# (1c) Structural simulation only: the fake client becomes visible on a later
# probe, pinning early success and retry shape. A real iTerm run proves the race.
reset_logs
export DELAY_NEW_CLIENT_TARGET='=demo/c'
rc=0
delayed="$(cd "$TEAM_ROOT" && "$TAP" team attach 2>&1)" || rc=$?
unset DELAY_NEW_CLIENT_TARGET
[ "$rc" = 0 ] || {
  echo "team-attach: delayed client registration exited $rc, want 0" >&2
  printf '%s\n' "$delayed" >&2
  exit 1
}
assert_contains "$delayed" "verified 6 new iTerm viewer(s) for team 'demo'" "delayed-client verified receipt"
[ "$(grep -Fc 'list-clients -t =demo/c -F #{client_tty}' "$TMUX_LOG")" = 3 ] || {
  echo "team-attach: delayed demo/c client should stop after its first successful re-probe" >&2
  cat "$TMUX_LOG" >&2
  exit 1
}
echo "team-attach: (1c) delayed client registration is observed before failure: ok"

# (2) A machine without drivable iTerm gets copyable commands, not a false error.
reset_logs
export ITERM_CAPABLE=0
rc=0
fallback="$(cd "$TEAM_ROOT" && TERM_PROGRAM=tmux "$TAP" team attach 2>&1)" || rc=$?
[ "$rc" = 0 ] || {
  echo "team-attach: capability fallback exited $rc" >&2
  printf '%s\n' "$fallback" >&2
  exit 1
}
assert_contains "$fallback" "tmux attach -t '=demo/a'" "fallback attach command"
assert_contains "$fallback" "skipped because already attached: b (/dev/ttys010)" "fallback pre-image"
[ ! -e "$OSASCRIPT_INPUT" ] || {
  echo "team-attach: failed capability probe still executed AppleScript" >&2
  cat "$OSASCRIPT_LOG" >&2
  exit 1
}
grep -Fq 'osascript -e id of application "iTerm"' "$OSASCRIPT_LOG" || {
  echo "team-attach: missing iTerm capability probe" >&2
  cat "$OSASCRIPT_LOG" >&2
  exit 1
}
grep -Fqx 'osascript -' "$OSASCRIPT_LOG" && {
  echo "team-attach: capability fallback invoked osascript stdin" >&2
  cat "$OSASCRIPT_LOG" >&2
  exit 1
}
echo "team-attach: (2) unavailable iTerm degrades to commands: ok"

# (2b) A capability-success/execution-failure never prints a false opened
# receipt; it returns the same copyable manual commands.
reset_logs
export ITERM_CAPABLE=1 OSASCRIPT_EXEC_RC=1
rc=0
failed_open="$(cd "$TEAM_ROOT" && "$TAP" team attach 2>&1)" || rc=$?
unset OSASCRIPT_EXEC_RC
[ "$rc" = 1 ] || {
  echo "team-attach: failed iTerm execution exited $rc, want 1" >&2
  printf '%s\n' "$failed_open" >&2
  exit 1
}
assert_contains "$failed_open" "iTerm automation failed" "execution-failure detail"
assert_contains "$failed_open" "tmux attach -t '=demo/a'" "execution-failure manual command"
assert_contains "$failed_open" "skipped because already attached: b (/dev/ttys010)" "execution-failure pre-image"
assert_contains "$failed_open" "h (resume tier exact" "execution-failure exact disclosure"
assert_contains "$failed_open" "i (resume tier fresh" "execution-failure fresh disclosure"
[[ "$failed_open" != *"opened 6 iTerm viewer"* ]] || {
  echo "team-attach: failed iTerm execution printed a false opened receipt" >&2
  printf '%s\n' "$failed_open" >&2
  exit 1
}
echo "team-attach: (2b) iTerm execution failure is loud and never claims opened: ok"

# (3) Dry-run previews the artifact but names its proof boundary.
reset_logs
export ITERM_CAPABLE=1
rc=0
dry="$(cd "$TEAM_ROOT" && TERM_PROGRAM=Cursor "$TAP" team attach --dry-run 2>&1)" || rc=$?
[ "$rc" = 0 ] || {
  echo "team-attach: dry-run exited $rc" >&2
  printf '%s\n' "$dry" >&2
  exit 1
}
assert_contains "$dry" 'tell application "iTerm2"' "dry-run AppleScript"
assert_contains "$dry" "dry-run cannot prove attachment" "dry-run evidence boundary"
[ ! -e "$OSASCRIPT_INPUT" ] || {
  echo "team-attach: dry-run executed AppleScript" >&2
  exit 1
}
echo "team-attach: (3) dry-run previews without claiming attachment: ok"

# (4) Any unobservable exact client probe aborts before terminal automation.
reset_logs
export FAIL_CLIENT_TARGET='=demo/c'
rc=0
blocked="$(cd "$TEAM_ROOT" && "$TAP" team attach 2>&1)" || rc=$?
unset FAIL_CLIENT_TARGET
[ "$rc" = 1 ] || {
  echo "team-attach: failed client probe exited $rc, want 1" >&2
  printf '%s\n' "$blocked" >&2
  exit 1
}
assert_contains "$blocked" "demo/c" "unobservable session name"
assert_contains "$blocked" "no iTerm window was opened" "abort-before-automation detail"
assert_contains "$blocked" "skipped because already attached: b (/dev/ttys010)" "pre-image-failure partial client snapshot"
assert_contains "$blocked" "h (resume tier exact" "pre-image-failure exact disclosure"
assert_contains "$blocked" "i (resume tier fresh" "pre-image-failure fresh disclosure"
[ ! -e "$OSASCRIPT_INPUT" ] || {
  echo "team-attach: failed client probe opened terminal automation" >&2
  exit 1
}
[ ! -s "$OSASCRIPT_LOG" ] || {
  echo "team-attach: failed client probe reached osascript" >&2
  cat "$OSASCRIPT_LOG" >&2
  exit 1
}
echo "team-attach: (4) unobservable pre-image aborts before automation: ok"

# (5) Zero live sessions open nothing and fail after disclosing every known seat.
reset_logs
: >"$LIVE_SESSIONS"
rc=0
none="$(cd "$TEAM_ROOT" && "$TAP" team attach 2>&1)" || rc=$?
[ "$rc" = 1 ] || {
  echo "team-attach: zero-live exited $rc, want 1" >&2
  printf '%s\n' "$none" >&2
  exit 1
}
assert_contains "$none" "h (resume tier exact" "zero-live exact disclosure"
assert_contains "$none" "i (resume tier fresh" "zero-live fresh disclosure"
[ ! -e "$OSASCRIPT_INPUT" ] || {
  echo "team-attach: zero-live opened AppleScript" >&2
  exit 1
}
echo "team-attach: (5) zero live reports all unavailable and opens nothing: ok"

# (6) One live plus unavailable rows is partial success: attach one, disclose all.
reset_logs
printf '%s\n' demo/a >"$LIVE_SESSIONS"
export ITERM_CAPABLE=1
rc=0
partial="$(cd "$TEAM_ROOT" && "$TAP" team attach 2>&1)" || rc=$?
[ "$rc" = 0 ] || {
  echo "team-attach: partial attach exited $rc" >&2
  printf '%s\n' "$partial" >&2
  exit 1
}
[ "$(grep -Fc "exec tmux attach -t '=demo/a'" "$OSASCRIPT_INPUT")" = 1 ] || {
  echo "team-attach: partial case did not attach its one live seat" >&2
  cat "$OSASCRIPT_INPUT" >&2
  exit 1
}
assert_contains "$partial" "h (resume tier exact; next: tap session resume h)" "partial exact disclosure"
assert_contains "$partial" "i (resume tier fresh; next: tap session resume i)" "partial fresh disclosure"
echo "team-attach: (6) partial availability attaches all live seats and exits zero: ok"

# (6b) --except (tap-nt4c): spared seats never reach the viewer plan, and the
# receipt names them rather than dropping them. Refusal arms assert error_class
# AND detail — pre-flag code refuses --except as a usage_error too, so only the
# named handle plus the roster discriminates the two.
reset_logs
printf '%s\n' demo/a demo/c demo/d >"$LIVE_SESSIONS"
err_class() { python3 -c 'import json,sys; print(json.loads(sys.argv[1])["error_class"])' "$1"; }
rc=0
spared="$(cd "$TEAM_ROOT" && "$TAP" team attach --dry-run --except c 2>&1)" || rc=$?
[ "$rc" = 0 ] || {
  echo "team-attach: --except dry-run exited $rc" >&2
  printf '%s\n' "$spared" >&2
  exit 1
}
assert_contains "$spared" "plan for team 'demo' (2 new viewer(s))" "--except narrows the plan"
assert_contains "$spared" "exec tmux attach -t '=demo/a'" "--except keeps unnamed live seats"
assert_contains "$spared" "spared by --except: c (live)" "--except disclosure"
[[ "$spared" != *"exec tmux attach -t '=demo/c'"* ]] || {
  echo "team-attach: --except c still planned a viewer for demo/c" >&2
  printf '%s\n' "$spared" >&2
  exit 1
}
echo "team-attach: (6b) --except drops the named seat from the plan and discloses it: ok"

# (6c) Sparing every live seat is a legal no-op — exit 0 with the explicit line,
# NOT the "no live seats" failure, which would blame the team for the operator's
# own instruction. Unavailable seats stay disclosed.
reset_logs
printf '%s\n' demo/a demo/c demo/d >"$LIVE_SESSIONS"
rc=0
allspared="$(cd "$TEAM_ROOT" && "$TAP" team attach --except a,c,d 2>&1)" || rc=$?
[ "$rc" = 0 ] || {
  echo "team-attach: all-spared exited $rc, want 0" >&2
  printf '%s\n' "$allspared" >&2
  exit 1
}
assert_contains "$allspared" "no seats matched after exclusions" "all-spared no-op line"
assert_contains "$allspared" "h (resume tier exact" "all-spared keeps unavailable disclosure"
[ ! -e "$OSASCRIPT_INPUT" ] || {
  echo "team-attach: all-spared executed AppleScript" >&2
  exit 1
}
echo "team-attach: (6c) every live seat spared = exit 0 with the explicit line: ok"

# (6d) An unknown handle fails loud naming the handle and the roster; no window.
reset_logs
printf '%s\n' demo/a demo/c demo/d >"$LIVE_SESSIONS"
rc=0
badx="$(cd "$TEAM_ROOT" && TAP_JSON=1 "$TAP" team attach --except nosuch 2>&1)" || rc=$?
[ "$rc" = 1 ] || {
  echo "team-attach: unknown --except handle exited $rc, want 1" >&2
  printf '%s\n' "$badx" >&2
  exit 1
}
[ "$(err_class "$badx")" = not_found ] || {
  echo "team-attach: unknown --except handle needs error_class=not_found" >&2
  printf '%s\n' "$badx" >&2
  exit 1
}
assert_contains "$badx" "nosuch" "unknown --except handle named"
assert_contains "$badx" "roster:" "unknown --except refusal names the roster"
[ ! -e "$OSASCRIPT_INPUT" ] || {
  echo "team-attach: a refused --except opened a window" >&2
  exit 1
}
rc=0
qual="$(cd "$TEAM_ROOT" && TAP_JSON=1 "$TAP" team attach --except demo/a 2>&1)" || rc=$?
[ "$rc" = 1 ] || { echo "team-attach: team-qualified --except exited $rc, want 1" >&2; exit 1; }
[ "$(err_class "$qual")" = usage_error ] || {
  echo "team-attach: team-qualified --except needs error_class=usage_error" >&2
  printf '%s\n' "$qual" >&2
  exit 1
}
echo "team-attach: (6d) unknown handle refuses with not_found; team-qualified is a usage error: ok"
printf '%s\n' demo/a >"$LIVE_SESSIONS"

# (7) Runtime help teaches the scope and evidence boundary; unknown flags refuse.
help="$("$TAP" help team)"
assert_contains "$help" "tap team attach [--tabs] [--dry-run]" "team attach grammar"
assert_contains "$help" "handle-labeled" "labelled-viewer help (layout-neutral token)"
assert_contains "$help" "unattached live seat" "attach scope help (token, not sentence)"
assert_contains "$help" "cannot prove attachment" "dry-run help boundary"

contract="$(cat "$CONTRACT")"
assert_contains "$contract" "tap team attach [--tabs] [--dry-run]" "contract team attach grammar"
assert_contains "$contract" "all live seats are already attached exits 0 without opening a window" "contract idempotent outcome"
assert_contains "$contract" "counted automated success requires a new post-open client TTY" "contract client-delta proof"

rc=0
bad="$("$TAP" team attach --bogus 2>&1)" || rc=$?
[ "$rc" = 1 ] || {
  echo "team-attach: unknown flag exited $rc, want 1" >&2
  printf '%s\n' "$bad" >&2
  exit 1
}
assert_contains "$bad" "unexpected argument '--bogus'" "unknown-flag detail"
assert_contains "$bad" "next: tap help team" "unknown-flag recovery"
echo "team-attach: (7) dispatch, help, and argument refusal: ok"

echo "team-attach: ok"
