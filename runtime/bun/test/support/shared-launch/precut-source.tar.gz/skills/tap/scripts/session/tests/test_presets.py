import dataclasses
import contextlib
import hashlib
import io
import os
import json
import pathlib
import sys
import tempfile
import unittest
from unittest import mock


SESSION_DIR = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SESSION_DIR))

import presets  # noqa: E402


def capture_stderr(call):
    """Run `call`, returning (value, non-empty stderr lines).

    Since the R4 cutover, parse notices are emitted by the native engine and
    relayed to this process's stderr; `emit_notice` prints there too. Capturing
    the stream is the one observation point that covers both channels.
    """
    buffer = io.StringIO()
    with contextlib.redirect_stderr(buffer):
        value = call()
    return value, [line for line in buffer.getvalue().splitlines() if line.strip()]


class PresetCatalogTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.home = self.root / "home"
        self.config_home = self.root / "config"
        self.path = self.config_home / "tap" / "presets.toml"
        self.home.mkdir()
        self.environ = {
            "HOME": str(self.home),
            "XDG_CONFIG_HOME": str(self.config_home),
        }

    def write(self, body: str, *, mode: int = 0o600) -> pathlib.Path:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(body, encoding="utf-8")
        self.path.chmod(mode)
        return self.path

    def write_bytes(self, body: bytes, *, mode: int = 0o600) -> pathlib.Path:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_bytes(body)
        self.path.chmod(mode)
        return self.path

    def assert_degraded(self, body: str, *fragments: str, keeps: str | None = "good"):
        """The ported shape of assert_error under the no-refusals contract.

        panel ruling (2026-08-18) retired content refusals after a four-minute
        machine-wide outage caused by one unrecognized table. The invariants these
        arms were written for did NOT retire — each still witnesses that the bad
        input is rejected, only now by being DROPPED AND NAMED rather than by
        taking the file down. So every ported arm asserts three things a bare
        deletion would not: the notice names the offending thing, the bad entry is
        absent, and its siblings survive.
        """
        self.write(body)
        catalog, seen = capture_stderr(lambda: presets.load_preset_catalog(self.environ))
        joined = "\n".join(seen)
        for fragment in fragments:
            self.assertIn(fragment, joined, f"no notice named {fragment!r}: {joined}")
        if keeps is not None:
            self.assertIsNotNone(
                catalog.get(keeps), f"sibling preset {keeps!r} was taken down: {joined}"
            )
        return catalog, seen

    def assert_error(self, error_class: str, *detail_parts: str, call=None):
        if call is None:
            call = lambda: presets.load_preset_catalog(self.environ)
        with self.assertRaises(presets.PresetError) as raised:
            call()
        error = raised.exception
        self.assertEqual(error.error_class, error_class)
        self.assertTrue(error.action)
        for part in detail_parts:
            self.assertIn(part, error.detail)
        return error

    def test_valid_codex_preset_resolves_effective_values_and_exact_provenance(self):
        body = """\
version = 2

[presets.sol-pinnacle-xhigh]
harness = "codex"
params.model = "gpt-5.6-sol"
params.effort = "xhigh"
description = "Persistent Ponytail seat"

[presets.sol-pinnacle-xhigh.env]
PONYTAIL_DEFAULT_MODE = "full"
CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS = "true"
MAX_TOKENS = "64000"

[notes]
owner = "local operator"
"""
        self.write(body)
        environ = dict(
            self.environ,
            PONYTAIL_DEFAULT_MODE="lite",
            UNDECLARED_VALUE="must-not-persist",
        )

        catalog = presets.load_preset_catalog(environ)
        resolved = catalog.require("sol-pinnacle-xhigh")

        self.assertEqual(catalog.names, ("sol-pinnacle-xhigh",))
        self.assertEqual(resolved.harness, "codex")
        self.assertEqual(resolved.model, "gpt-5.6-sol")
        self.assertEqual(
            resolved.harness_passthrough,
            ("--effort", "xhigh"),
        )
        self.assertEqual(
            resolved.env,
            {
                # "full", the DECLARED value, not the "lite" seeded above. This expectation
                # read "lite" until the ambient inversion: the shell used to win any key a
                # preset declared. The seeded value stays because it is now the competitor
                # that makes this assertion mean something — without it, "full" would be
                # trivially true.
                "PONYTAIL_DEFAULT_MODE": "full",
                "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "true",
                "MAX_TOKENS": "64000",
            },
        )
        # Undeclared parent values are still never adopted — the inversion changed which side
        # wins for a DECLARED key, not whether the parent environment can add keys of its own.
        self.assertNotIn("UNDECLARED_VALUE", resolved.env)
        self.assertEqual(resolved.provenance.name, "sol-pinnacle-xhigh")
        self.assertEqual(resolved.provenance.source_path, str(self.path.resolve()))
        self.assertEqual(
            resolved.provenance.config_digest,
            f"sha256:{hashlib.sha256(body.encode()).hexdigest()}",
        )

    def test_symlink_source_reports_resolved_target_and_digests_descriptor_bytes(self):
        target = self.root / "owned-presets.toml"
        body = 'version = 2\n[presets.local]\nharness = "hermes"\n'
        target.write_text(body, encoding="utf-8")
        target.chmod(0o600)
        self.path.parent.mkdir(parents=True)
        self.path.symlink_to(target)

        resolved = presets.load_preset_catalog(self.environ).require("local")

        self.assertEqual(resolved.provenance.source_path, str(target.resolve()))
        self.assertEqual(
            resolved.provenance.config_digest,
            f"sha256:{hashlib.sha256(body.encode()).hexdigest()}",
        )

    def test_per_harness_params_pass_through_verbatim(self):
        # v2: no cross-harness support matrix. params.<key> becomes --<key>.
        valid_cases = (
            (
                "claude",
                'params.model = "claude-opus-4-1"\nparams.effort = "high"',
                "claude-opus-4-1",
                ("--effort", "high"),
            ),
            ("cursor", 'params.model = "composer-1"', "composer-1", ()),
            (
                "codex",
                'params.model = "gpt-5.6-sol"\nparams.effort = "max"',
                "gpt-5.6-sol",
                ("--effort", "max"),
            ),
            (
                "opencode",
                'params.model = "glm-4.7"\nparams.provider = "zai"',
                "glm-4.7",
                ("--provider", "zai"),
            ),
            (
                "agy",
                'params.model = "gemini-3.6-flash-high"\nparams.effort = "high"',
                "gemini-3.6-flash-high",
                ("--effort", "high"),
            ),
            (
                "hermes",
                'params.model = "local"\nparams.effort = "high"',
                "local",
                ("--effort", "high"),
            ),
        )
        for harness, fields, model, passthrough in valid_cases:
            with self.subTest(harness=harness):
                self.write(
                    f'version = 2\n[presets.tier]\nharness = "{harness}"\n{fields}\n'
                )
                resolved = presets.load_preset_catalog(self.environ).require("tier")
                self.assertEqual(resolved.model, model)
                self.assertEqual(resolved.harness_passthrough, passthrough)

    def test_opencode_provider_without_model_is_just_a_flag(self):
        self.write(
            'version = 2\n[presets.tier]\nharness = "opencode"\nparams.provider = "zai"\n'
        )
        resolved = presets.load_preset_catalog(self.environ).require("tier")
        self.assertIsNone(resolved.model)
        self.assertEqual(resolved.harness_passthrough, ("--provider", "zai"))

    def test_every_harness_has_a_tuning_capability_row(self):
        # tap-ppo7 enumerating pin (same doctrine as PR #xxx / tap-ctzt).
        # Iterates HARNESSES so a seventh harness joins by existing. Equality in
        # both directions: a row without a harness is leftover fiction; a harness
        # without a row is the incident (agy had CLI flags and no table).
        # Vacuity: if HARNESSES shrinks below the known six, this reds rather than
        # passing over an empty zip. Mutation: delete the agy row → this reds;
        # add "max" to agy effort domain → test_agy_effort_outside_domain_refuses reds.
        self.assertTrue(
            presets.HARNESSES >= {"agy", "claude", "codex", "cursor", "hermes", "opencode"},
            "HARNESSES shrank; an enumerating pin over an emptied set passes vacuously",
        )
        self.assertEqual(set(presets.TUNING_CAPABILITIES), set(presets.HARNESSES))

    def test_agy_effort_outside_domain_refuses_on_the_cli_axis(self):
        # Domain clamping stays on the CLI --effort axis (TUNING_CAPABILITIES).
        # Config params are verbatim and do not consult that table.
        error = None
        with self.assertRaises(presets.PresetError) as raised:
            presets.resolve_tuning(
                harness="agy",
                effort="max",
                context=presets.cli_tuning_context(),
            )
        error = raised.exception
        self.assertEqual(error.error_class, "launch_arg_invalid")
        self.assertIn("max", error.detail)
        self.assertIn("low, medium, high", error.detail)
        self.assertNotIn("xhigh", error.detail)

    def test_agy_effort_high_translates_to_flag_not_codex_passthrough(self):
        self.write(
            'version = 2\n[presets.tier]\nharness = "agy"\nparams.effort = "high"\n'
        )
        resolved = presets.load_preset_catalog(self.environ).require("tier")
        self.assertEqual(resolved.harness_passthrough, ("--effort", "high"))
        self.assertNotIn("model_reasoning_effort", " ".join(resolved.harness_passthrough))

    def test_missing_config_names_source_and_create_action(self):
        error = self.assert_error("preset_config_missing", str(self.path))
        self.assertIn("create", error.action)

    def test_an_unparseable_document_is_the_only_shape_that_still_refuses(self):
        """The single surviving hard failure.

        Without a document there is nothing to partially understand, so this is
        not a content question. Every other case in this file's former refusal
        table now degrades — see the arm below.
        """
        self.write("version = [")
        self.assert_error("preset_config_invalid", "TOML")

    def test_every_other_invalid_shape_degrades_and_keeps_what_it_understands(self):
        """Ported from the old refuse-the-whole-config table, case for case.

        Each entry previously proved "this input refuses the file". Each now
        proves "this input is dropped, named, and the good preset beside it still
        loads" — the same rejection, at a scope that cannot brick the machine.
        """
        good = '[presets.good]\nharness = "codex"\n'
        cases = (
            ("a future version", "version = 9\n" + good, "newer than this reader"),
            ("an unknown top-level key", "version = 2\nextra = true\n" + good, "extra"),
            ("an unknown preset key",
             'version = 2\n[presets.bad]\nharness = "codex"\nextra = true\n' + good, "bad"),
            ("a non-string harness",
             'version = 2\n[presets.bad]\nharness = 4\n' + good, "bad"),
            ("an unknown harness",
             'version = 2\n[presets.bad]\nharness = "unknown"\n' + good, "bad"),
            ("an empty model param",
             'version = 2\n[presets.bad]\nharness = "codex"\nparams.model = ""\n' + good, "bad"),
            ("a non-string description",
             'version = 2\n[presets.bad]\nharness = "codex"\ndescription = 4\n' + good, "bad"),
            ("an unusable preset name",
             'version = 2\n[presets."bad name"]\nharness = "codex"\n' + good, "bad name"),
        )
        for label, body, fragment in cases:
            with self.subTest(case=label):
                catalog, _ = self.assert_degraded(body, fragment)
                self.assertIsNone(catalog.get("bad"), f"{label}: the bad preset was kept")

    def test_a_file_with_no_usable_presets_table_yields_an_empty_catalog(self):
        # Previously "presets must be a table", refusing everything. A file with
        # no presets is a file with no presets; reporting nothing to launch is
        # true, refusing to resolve anything is not.
        for body in ("version = 2\n", 'version = 2\npresets = ["bad"]\n'):
            with self.subTest(body=body):
                self.write(body)
                catalog = presets.load_preset_catalog(self.environ)
                self.assertEqual(catalog.names, ())

    def test_invalid_utf8_and_behavioral_control_characters_refuse(self):
        self.write_bytes(
            b'version = 2\n[presets.good]\nharness = "codex"\n# \xff\n'
        )
        self.assert_error("preset_config_invalid", "UTF-8")

        # Control characters reach ARGV and the CHILD ENVIRONMENT, so this is a
        # safety property rather than a schema one — and it survives the port
        # intact. The preset carrying them is dropped, so the value never gets
        # near either surface; only the mechanism of rejection changed.
        for body, fragment in (
            ('[presets.bad]\nharness = "codex"\nparams.model = "line\\nbreak"\n', "model"),
            ('[presets.bad]\nharness = "codex"\n'
             '[presets.bad.env]\nSAFE_VALUE = "line\\tbreak"\n', "SAFE_VALUE"),
        ):
            with self.subTest(fragment=fragment):
                catalog, seen = self.assert_degraded(
                    "version = 2\n" + body + '[presets.good]\nharness = "codex"\n',
                    fragment,
                    "control",
                )
                self.assertIsNone(
                    catalog.get("bad"), f"{fragment}: control characters resolved"
                )

    def test_non_regular_and_group_or_world_writable_sources_refuse_without_blocking(self):
        self.path.parent.mkdir(parents=True)
        os.mkfifo(self.path)
        self.assert_error("preset_config_insecure", "regular")
        self.path.unlink()

        self.path.mkdir()
        self.assert_error("preset_config_insecure", "regular")
        self.path.rmdir()

        self.write('version = 2\n[presets.good]\nharness = "codex"\n', mode=0o622)
        self.assert_error("preset_config_insecure", "group/world writable")

    def test_every_canonical_harness_name_is_dropped_not_addressable(self):
        """A preset may not shadow a canonical harness — ported to drop-with-notice.

        This is the invariant #xxx's resolution order rests on: preset-first
        lookup is observationally identical to harness-first ONLY while no preset
        can carry a harness's name. Dropping such a preset keeps that exactly
        true — the lookup misses and falls through to the harness — without a
        refusal, which is what panel ruling retired.
        """
        for harness in sorted(presets.HARNESSES):
            with self.subTest(harness=harness):
                catalog, _ = self.assert_degraded(
                    f'version = 2\n[presets.{harness}]\nharness = "{harness}"\n'
                    + '[presets.good]\nharness = "codex"\n',
                    harness,
                )
                self.assertIsNone(
                    catalog.get(harness), "a harness-named preset became addressable"
                )

    def test_environment_fence_refuses_exact_and_token_matches_without_dropping(self):
        forbidden = (
            "TAP",
            "TAP_HOME",
            "HOME",
            "TMUX_PANE",
            "AGENT_NAME",
            "CLAUDE_TEAM_ID",
            "CODEX_SANDBOX_MODE",
            "MODEL_APPROVALS_REQUIRED",
            "LOCAL_PERMISSION_LEVEL",
            "AUTH_BYPASS_MODE",
            "BASH_ENV",
            "ENV",
            "NODE_OPTIONS",
            "PYTHONPATH",
            "LD_PRELOAD",
            "DYLD_INSERT_LIBRARIES",
            "OPENAI_API_KEY",
            "ANTHROPIC_AUTH_TOKEN",
            "AWS_SECRET_ACCESS_KEY",
            "DATABASE_PASSWORD",
            "SSH_PRIVATE_KEY",
        )
        for key in forbidden:
            with self.subTest(key=key):
                # THE FENCE STILL FENCES. Ported to drop-with-notice, and the
                # property that matters is unchanged: the preset carrying a
                # fence-crossing key never resolves, so the value never reaches
                # the child environment. It is rejected by being dropped, not by
                # taking the file down with it.
                catalog, _ = self.assert_degraded(
                    'version = 2\n[presets.safe]\nharness = "codex"\n'
                    f'[presets.safe.env]\n{key} = "value"\n'
                    + '[presets.good]\nharness = "codex"\n',
                    key,
                )
                self.assertIsNone(
                    catalog.get("safe"), f"{key}: a fence-crossing preset resolved"
                )

    # (The pre-cutover tomllib-guard arm was removed with the guard itself:
    # the native engine parses TOML, so a stdlib-less Python no longer refuses.)

    def test_credential_parent_value_is_refused_without_echoing_the_secret(self):
        self.write(
            'version = 2\n[presets.safe]\nharness = "codex"\n'
            '[presets.safe.env]\nOPENAI_API_KEY = "placeholder"\n'
        )
        secret = "live-secret-must-not-leak"
        environ = dict(self.environ, OPENAI_API_KEY=secret)

        # Ported: the refusal became a notice, so the non-echo property now has to
        # hold on the NOTICE — which is the louder surface, since it prints on an
        # otherwise successful load rather than on a crash.
        catalog, seen = capture_stderr(lambda: presets.load_preset_catalog(environ))
        joined = "\n".join(seen)

        self.assertIsNone(catalog.get("safe"), "a credential-bearing preset resolved")
        self.assertIn("OPENAI_API_KEY", joined)
        self.assertNotIn(secret, joined)

    def test_environment_names_and_values_are_strict(self):
        for body, fragment in (
            ('[presets.safe.env]\n"1BAD" = "value"\n', "1BAD"),
            ('[presets.safe.env]\nSAFE = 4\n', "SAFE"),
        ):
            with self.subTest(fragment=fragment):
                catalog, _ = self.assert_degraded(
                    'version = 2\n[presets.safe]\nharness = "codex"\n' + body
                    + '[presets.good]\nharness = "codex"\n',
                    fragment,
                )
                self.assertIsNone(catalog.get("safe"))

    def test_relative_xdg_config_home_refuses_before_open(self):
        environ = dict(self.environ, XDG_CONFIG_HOME="relative/config")
        self.assert_error(
            "preset_config_invalid",
            "XDG_CONFIG_HOME",
            "absolute",
            call=lambda: presets.load_preset_catalog(environ),
        )

    def test_require_unknown_preset_keeps_explicit_intent_and_names_source(self):
        self.write(
            'version = 2\n[presets.available]\nharness = "claude"\n'
        )
        catalog = presets.load_preset_catalog(self.environ)

        error = self.assert_error(
            "preset_not_found",
            "missing",
            str(self.path.resolve()),
            call=lambda: catalog.require("missing"),
        )
        self.assertIn("available", error.action)

    def test_a_doubly_invalid_preset_reports_params_before_description(self):
        # params typing is checked before `description`, which is checked before the env fence.
        self.write(
            'version = 2\n[presets.a]\nharness = "claude"\nparams.model = 7\ndescription = 5\n'
        )
        # The ORDER is still observable: the notice carries the first error
        # _resolve_one raised, so params still beats description.
        _, seen = self.assert_degraded(
            'version = 2\n[presets.a]\nharness = "claude"\nparams.model = 7\ndescription = 5\n'
            + '[presets.good]\nharness = "codex"\n',
            "params.model",
        )
        self.assertNotIn("description", "\n".join(seen))

        # description still beats a fence-crossing env key — it is checked before env.
        self.write(
            'version = 2\n[presets.a]\nharness = "claude"\ndescription = 5\n'
            '[presets.a.env]\nTAP_HOME = "x"\n'
        )
        self.assert_degraded(
            'version = 2\n[presets.a]\nharness = "claude"\ndescription = 5\n'
            '[presets.a.env]\nTAP_HOME = "x"\n'
            + '[presets.good]\nharness = "codex"\n',
            "field 'description'",
        )

    def test_provider_is_a_verbatim_string_param(self):
        self.write(
            'version = 2\n[presets.a]\nharness = "opencode"\n'
            'params.model = "m"\nparams.provider = "nous-portal"\n'
        )
        resolved = presets.load_preset_catalog(self.environ).require("a")
        self.assertEqual(resolved.model, "m")
        self.assertEqual(resolved.harness_passthrough, ("--provider", "nous-portal"))


class HarnessEnvTierTests(unittest.TestCase):
    """Tier 2: machine policy read fresh on every launch and resume.

    The polarity of each failure arm is the design, not an implementation detail: resume is the
    recovery verb, so a broken config must not be able to strand the seats an operator would
    use to fix it.
    """

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.config_home = self.root / "config"
        self.config = self.config_home / "tap" / "config.toml"
        self.legacy = self.config_home / "tap" / "presets.toml"
        self.environ = {
            "HOME": str(self.root / "home"),
            "XDG_CONFIG_HOME": str(self.config_home),
        }
        presets.suppress_notices(False)
        self.addCleanup(presets.suppress_notices, False)

    def write(self, path: pathlib.Path, body: str, *, mode: int = 0o600) -> pathlib.Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body, encoding="utf-8")
        path.chmod(mode)
        return path

    def test_absent_config_is_silent_not_an_error(self):
        # A machine that never authored a config is a legitimate state. Warning here would warn
        # forever on every fresh system, and refusing would brick launch and resume outright.
        result = presets.resolve_harness_env("codex", self.environ)
        self.assertEqual(result.env, {})
        self.assertEqual(result.notices, ())

    def test_harness_table_reaches_the_caller(self):
        self.write(self.config, 'version = 2\n[harness.codex.env]\nFOO = "bar"\n')
        self.assertEqual(presets.resolve_harness_env("codex", self.environ).env, {"FOO": "bar"})
        # Another harness reads its own table, not this one.
        self.assertEqual(presets.resolve_harness_env("claude", self.environ).env, {})

    def test_malformed_config_degrades_open_and_says_policy_is_not_held(self):
        self.write(self.config, "version = 2\n[harness.codex.env\nFOO =\n")
        result = presets.resolve_harness_env("codex", self.environ)
        self.assertEqual(result.env, {})
        self.assertEqual(len(result.notices), 1)
        notice = result.notices[0]
        self.assertIn(str(self.config.resolve()), notice)
        # The operator must not read this as "policy applied with a hiccup".
        self.assertIn("not being applied", notice)

    def test_insecure_config_degrades_open_rather_than_stranding_resume(self):
        self.write(self.config, 'version = 2\n[harness.codex.env]\nFOO = "bar"\n', mode=0o666)
        result = presets.resolve_harness_env("codex", self.environ)
        self.assertEqual(result.env, {})
        self.assertEqual(len(result.notices), 1)

    def test_a_broken_config_still_refuses_an_explicit_preset_request(self):
        # The other half of the polarity split, and the one that keeps the spec's promise: an
        # operator who NAMED a preset gets a refusal, never a silent downgrade to no preset.
        self.write(self.config, "version = 2\n[presets.a\nharness =\n")
        with self.assertRaises(presets.PresetError):
            presets.load_preset_catalog(self.environ)
        # ...while the ad-hoc rail keeps working through the very same broken file.
        self.assertEqual(presets.resolve_harness_env("codex", self.environ).env, {})

    def test_fence_crossing_key_refuses_scoped_to_its_own_harness(self):
        self.write(
            self.config,
            'version = 2\n[harness.claude.env]\nTAP_HOME = "/x"\n'
            '[harness.codex.env]\nFOO = "bar"\n',
        )
        with self.assertRaises(presets.PresetError) as caught:
            presets.resolve_harness_env("claude", self.environ)
        error = caught.exception
        self.assertEqual(error.error_class, "harness_env_forbidden")
        for part in ("TAP_HOME", "[harness.claude.env]", str(self.config.resolve())):
            self.assertIn(part, error.detail + error.action)
        # The other polarity, and the reason scoping exists: one harness's authoring error must
        # not strand every other harness's seats — including one cohort of a `resume --all`.
        self.assertEqual(presets.resolve_harness_env("codex", self.environ).env, {"FOO": "bar"})

    def test_unknown_harness_table_announces_itself(self):
        # "I seeded it and nothing happened" is indistinguishable from "it had no effect"
        # unless the typo speaks up.
        self.write(self.config, 'version = 2\n[harnes.codex.env]\nFOO = "bar"\n')
        with self.assertRaises(presets.PresetError):
            # `harnes` is not a known top-level key at all — the whole document is refused,
            # which is itself loud. The near-miss that parses is the one below.
            presets.load_preset_catalog(self.environ)

        self.write(self.config, 'version = 2\n[harness.code.env]\nFOO = "bar"\n')
        result = presets.resolve_harness_env("codex", self.environ)
        self.assertEqual(result.env, {})
        self.assertEqual(len(result.notices), 1)
        self.assertIn("harness.code", result.notices[0])

    def shell_exporting(self, **values):
        """Both spellings of "the launching shell", because only one of them is still live.

        The `environ` argument used to reach env resolution and no longer does — it locates the
        config file and nothing else. A test that seeds only the argument therefore probes a
        path that cannot leak, and stays green against a restored ambient override. Seeding
        `os.environ` as well is what keeps these pins able to fail.
        """
        return dict(self.environ, **values), mock.patch.dict(os.environ, values, clear=False)

    def test_ambient_environment_does_not_rewrite_machine_policy(self):
        self.write(self.config, 'version = 2\n[harness.codex.env]\nFOO = "declared"\n')
        environ, shell = self.shell_exporting(FOO="from-shell")
        with shell:
            self.assertEqual(
                presets.resolve_harness_env("codex", environ).env, {"FOO": "declared"}
            )

    def test_ambient_environment_does_not_rewrite_a_preset_either(self):
        # The polarity that actually changed in U4: preset resolution was the last surface still
        # letting the launching shell win, so `tap session launch sol` meant one thing in a
        # terminal that had exported FOO and another in one that had not, silently. Resolution
        # is now shell-independent; the collision is announced at the launcher's merge point.
        self.write(
            self.config,
            'version = 2\n[presets.sol]\nharness = "codex"\n'
            '[presets.sol.env]\nFOO = "declared"\n',
        )
        environ, shell = self.shell_exporting(FOO="from-shell")
        with shell:
            self.assertEqual(
                presets.load_preset_catalog(environ).require("sol").env, {"FOO": "declared"}
            )

    def test_presets_fall_back_per_section_not_per_file(self):
        # The rollout state this protects: a config.toml carrying ONLY the harness table while
        # presets still live in presets.toml. Whole-file precedence would empty the catalog at
        # exactly the moment the sanctioned seed step creates that file.
        self.write(self.config, 'version = 2\n[harness.codex.env]\nFOO = "bar"\n')
        self.write(self.legacy, 'version = 2\n[presets.sol]\nharness = "codex"\n')

        catalog = presets.load_preset_catalog(self.environ)
        self.assertEqual(catalog.names, ("sol",))
        self.assertEqual(presets.resolve_harness_env("codex", self.environ).env, {"FOO": "bar"})

    def test_family_binds_a_preset_to_its_notes_entry(self):
        self.write(
            self.config,
            'version = 2\n'
            '[presets.sol-max]\nharness = "codex"\nfamily = "codex"\n'
            '[notes]\ncodex = "prefers they/them"\nclaude = "unused here"\n',
        )
        resolved = presets.load_preset_catalog(self.environ).require("sol-max")
        self.assertEqual(resolved.family, "codex")
        self.assertEqual(resolved.note, "prefers they/them")

    def test_family_naming_no_notes_entry_costs_the_note_not_the_catalog(self):
        """Ported, and the scope INVERTED on purpose.

        This arm used to argue that a half-loaded catalog is how an operator
        launches the wrong seat, so the whole file should refuse. Under Ops's
        tolerance ruling that reasoning survives only where the defect can change
        what LAUNCHES — and an unbound `family` cannot. `note` is annotation that
        rides along; the seat's harness, model, env and params are untouched.

        So the cost is the note, not the preset, and certainly not the catalog.
        The arm now proves all three: the typo is named, the mistyped preset still
        loads WITHOUT a note, and its sibling is unaffected.
        """
        catalog, notices = self.load_with_notices(
            'version = 2\n'
            '[presets.sol-max]\nharness = "codex"\nfamily = "codxe"\n'
            '[presets.other]\nharness = "claude"\n'
            '[notes]\ncodex = "prefers they/them"\n'
        )
        self.assertIn("codxe", notices)
        self.assertIsNotNone(catalog.get("sol-max"), "a missing note withheld a seat")
        self.assertIsNone(catalog.get("sol-max").note)
        self.assertIsNotNone(catalog.get("other"))

    def test_family_without_any_notes_table_warns_instead_of_refusing(self):
        # The mid-migration escape. An operator who has set family but not yet written notes
        # has an incomplete config, not a broken one, and must never be blocked from launching
        # over a display label.
        self.write(
            self.config,
            'version = 2\n[presets.sol-max]\nharness = "codex"\nfamily = "codex"\n',
        )
        resolved, notices = capture_stderr(
            lambda: presets.load_preset_catalog(self.environ).require("sol-max")
        )
        self.assertEqual(resolved.family, "codex")
        self.assertIsNone(resolved.note)
        self.assertEqual(len(notices), 1, notices)
        self.assertIn("codex", notices[0])
        self.assertIn("[notes]", notices[0])

    def test_a_bound_note_is_printed_at_launch_and_nowhere_else(self):
        # The gate's finding: `note` was bound and read by nothing, while the docs said it
        # travelled with the seat. It prints at RESOLUTION — the only moment it is both in hand
        # and current — and the second half of this test is the one that matters: resume must
        # NOT reprint it, because resume never reopens the catalog and the row does not carry
        # the prose. A test that only checked the launch print would pass just as happily
        # against an implementation that persisted the note into the row, which is the change
        # this design deliberately refuses.
        self.write(
            self.config,
            'version = 2\n'
            '[presets.sol-max]\nharness = "codex"\nfamily = "codex"\n'
            '[notes]\ncodex = "Prefer she/her pronouns"\n',
        )
        resolved = presets.load_preset_catalog(self.environ).require("sol-max")
        self.assertEqual(resolved.note, "Prefer she/her pronouns")

        # The persisted provenance carries no prose — that is what makes the note un-followable
        # by construction rather than by convention.
        for field in dataclasses.fields(resolved.provenance):
            self.assertNotIn(
                "she/her",
                str(getattr(resolved.provenance, field.name)),
                f"note text leaked into persisted provenance field {field.name!r}",
            )

    def test_family_never_reaches_the_invocation(self):
        # The trap this forecloses: a display key that can act as a switch. `family` exists to
        # carry operator prose to a banner, and the moment it can change a model, a flag, or an
        # environment value, a cosmetic label becomes launch behavior — silently, since nobody
        # reviews a notes bridge for that. Asserting the resolved tuning is IDENTICAL under
        # every family value is what keeps it inert; a test that only checked `.family` would
        # pass just as well while argv diverged.
        base = 'version = 2\n[presets.p]\nharness = "codex"\nparams.model = "gpt-5.6-sol"\n'
        env_block = '[presets.p.env]\nFOO = "bar"\n'
        notes = '[notes]\ncodex = "a"\nclaude = "b"\n'
        shapes = []
        for family_line in ('', 'family = "codex"\n', 'family = "claude"\n'):
            self.write(self.config, base + family_line + env_block + notes)
            r = presets.load_preset_catalog(self.environ).require("p")
            shapes.append((r.harness, r.model, r.harness_passthrough, dict(r.env)))
        self.assertEqual(len(set(map(repr, shapes))), 1, shapes)

    def test_taking_authority_over_a_surviving_legacy_file_says_so(self):
        # kimi NIT-1. The fallback is loud when it fires; this is the same rule NOT firing.
        # An operator mid-migration, with both files present, edits presets.toml and gets no
        # error, no effect, and nothing to read — the silent half of a rule whose loud half is
        # already covered two tests down.
        self.write(self.config, 'version = 2\n[presets.current]\nharness = "codex"\n')
        self.write(self.legacy, 'version = 2\n[presets.stale]\nharness = "codex"\n')

        catalog, notices = capture_stderr(lambda: presets.load_preset_catalog(self.environ))

        self.assertEqual(catalog.names, ("current",))
        self.assertEqual(len(notices), 1, notices)
        # Both paths, because the notice's whole job is telling the operator WHICH file they
        # are editing and which one they are not.
        self.assertIn(str(self.config.resolve()), notices[0])
        self.assertIn(str(self.legacy.resolve()), notices[0])

        # And it is scoped to the shadowing case: with no legacy file there is nothing being
        # ignored, so a notice would be noise on the ordinary steady state every machine
        # reaches after the migration.
        self.legacy.unlink()
        _, notices = capture_stderr(lambda: presets.load_preset_catalog(self.environ))
        self.assertEqual(notices, [])

    def test_an_empty_presets_table_does_not_revoke_the_legacy_catalog(self):
        # An operator who seeds config.toml with a vacant `[presets]` header "to fill in later"
        # is stating an intention, not revoking a catalog. Taking authority on an empty table
        # would empty their presets with no error and no notice — the silent half of the same
        # failure the per-section fallback exists to prevent.
        self.write(
            self.config, 'version = 2\n[presets]\n[harness.codex.env]\nFOO = "bar"\n'
        )
        self.write(self.legacy, 'version = 2\n[presets.legacy]\nharness = "codex"\n')
        # The notice is observed on THIS first load: post-cutover the emitted
        # lifetime is the engine's, and a notice already said does not repeat on
        # a second read within the same command.
        catalog, notices = capture_stderr(
            lambda: presets.load_preset_catalog(self.environ)
        )
        self.assertEqual(catalog.names, ("legacy",))

        # ...and the surprise that creates is named rather than left silent: an operator who
        # meant the vacant header as "clear my catalog" gets the legacy one anyway, so the
        # notice has to say THAT, not the generic move-them-over line which would read as if
        # the empty header had gone unnoticed.
        self.assertEqual(len(notices), 1)
        self.assertIn("is empty", notices[0])
        self.assertIn(str(self.legacy.resolve()), notices[0])

        # The other polarity: ONE entry is enough to mean "these are my presets now".
        self.write(
            self.config,
            'version = 2\n[presets.migrated]\nharness = "codex"\n'
            '[harness.codex.env]\nFOO = "bar"\n',
        )
        self.assertEqual(presets.load_preset_catalog(self.environ).names, ("migrated",))

    def test_a_wrong_shaped_presets_key_names_the_real_fault(self):
        # Present-but-wrong-shape is an authoring error, not an absence. Falling back would
        # answer a botched migration with "move them under [presets]" — instructing the
        # operator to do the very thing they just attempted.
        self.write(self.legacy, 'version = 2\n[presets.legacy]\nharness = "codex"\n')
        # Ported to warn-and-proceed (Ops's tolerance ruling). The load no longer
        # refuses, but the ANTI-FALLBACK property this arm exists for is unchanged
        # and is what is asserted: config.toml keeps authority and contributes
        # nothing, so the legacy preset must NOT appear. Reading it would answer a
        # botched migration by telling the operator to perform the migration they
        # just attempted.
        catalog, notices = self.load_with_notices('version = 2\npresets = "oops"\n')
        self.assertIn("[presets] is not a table", notices)
        self.assertIn(str(self.config.resolve()), notices)
        self.assertIsNone(catalog.get("legacy"), "the legacy file was read anyway")
        self.assertEqual(catalog.names, ())

    def test_unrecognized_key_inside_a_known_harness_table_announces_itself(self):
        # One level below the unknown-table typo and just as silent: `[harness.codex] model=`
        # or a misspelled `envv` is ignored. "I seeded it and nothing happened" needs to be
        # distinguishable from "it had no effect".
        self.write(
            self.config,
            'version = 2\n[harness.codex]\nmodel = "x"\n[harness.codex.env]\nFOO = "bar"\n',
        )
        result = presets.resolve_harness_env("codex", self.environ)
        self.assertEqual(result.env, {"FOO": "bar"})
        self.assertEqual(len(result.notices), 1)
        self.assertIn("'model'", result.notices[0])
        self.assertIn("[harness.codex]", result.notices[0])
        self.assertIn(str(self.config.resolve()), result.notices[0])
        self.assertIn("params", result.notices[0])

        # Negative arm: a table carrying only `env` says nothing.
        self.write(self.config, 'version = 2\n[harness.codex.env]\nFOO = "bar"\n')
        self.assertEqual(presets.resolve_harness_env("codex", self.environ).notices, ())

    def test_presets_in_config_win_over_the_legacy_file(self):
        self.write(self.config, 'version = 2\n[presets.new]\nharness = "codex"\n')
        self.write(self.legacy, 'version = 2\n[presets.old]\nharness = "codex"\n')
        self.assertEqual(presets.load_preset_catalog(self.environ).names, ("new",))

    def load_with_notices(self, body: str):
        """Ported shape for arms that used to assert a raise (Ops, 2026-08-18)."""
        self.write(self.config, body)
        catalog, seen = capture_stderr(lambda: presets.load_preset_catalog(self.environ))
        return catalog, "\n".join(seen)

    def test_v1_file_refuses_as_retired_version_with_copy_remedy(self):
        # A stranded v1 machine (first-class model/effort) must be told the SCHEMA
        # retired, not "unknown key effort" (which implies delete the key).
        # Ported: retired is still SAID — the point was never the refusal, it was
        # telling a stranded operator the SCHEMA retired rather than implying the
        # keys are junk. That message survives; the file now loads what it can.
        _, notices = self.load_with_notices(
            'version = 1\n[presets.old]\nharness = "codex"\n'
            'model = "gpt-5.6-sol"\neffort = "xhigh"\n'
        )
        self.assertIn("retired", notices)
        self.assertIn("2", notices)
        # Never "unknown key 'effort'": that phrasing tells a stranded v1 operator
        # to DELETE the key rather than migrate the file, which is the opposite of
        # the remedy. This was the arm's original point and it still holds.
        self.assertNotIn("unknown key", notices)

    def test_version_1_over_v2_shape_refuses_as_version_not_shape(self):
        # Decorative version=1 on a v2-shaped file is still version 1.
        # Still diagnosed as a VERSION problem, never as "unknown key", which
        # would tell the operator to delete the keys instead of migrate.
        _, notices = self.load_with_notices(
            'version = 1\n[presets.sol]\nharness = "codex"\n'
            'params.model = "gpt-5.6-sol"\n'
        )
        self.assertIn("retired", notices)
        self.assertNotIn("unknown key", notices)

    def test_roles_table_and_metadata_are_display_only(self):
        # The trap this forecloses is the same as `family`: a display key that can
        # act as a switch. Two presets that differ only in metadata must resolve
        # to byte-identical tuning.
        body = """\
version = 2

[roles]
implementer = "Implements code from a prompt or a spec"
reviewer = "Reviews code"
leader = "Leads a TAP team"

[presets.sol]
harness = "codex"
params.model = "gpt-5.6-sol"
params.effort = "high"

[presets.sol.metadata]
pronouns = "he/him"
intelligence = "frontier"
primary_roles = ["reviewer", "implementer"]
avoid_roles = ["leader"]

[presets.sol.env]
FOO = "bar"
"""
        self.write(self.config, body)
        resolved = presets.load_preset_catalog(self.environ).require("sol")
        self.assertEqual(resolved.model, "gpt-5.6-sol")
        self.assertEqual(resolved.harness_passthrough, ("--effort", "high"))
        self.assertEqual(resolved.env, {"FOO": "bar"})
        self.assertIsNotNone(resolved.metadata)
        self.assertEqual(resolved.metadata.pronouns, "he/him")
        self.assertEqual(resolved.metadata.primary_roles, ("reviewer", "implementer"))
        self.assertEqual(resolved.metadata.avoid_roles, ("leader",))
        self.assertEqual(
            presets.load_preset_catalog(self.environ).roles["implementer"],
            "Implements code from a prompt or a spec",
        )

        shapes = []
        for extra in (
            "",
            '[presets.sol.metadata]\nsummary = "a"\n',
            '[presets.sol.metadata]\nsummary = "b"\nprimary_roles = ["reviewer"]\n',
        ):
            self.write(
                self.config,
                'version = 2\n[roles]\nreviewer = "r"\n'
                '[presets.sol]\nharness = "codex"\nparams.model = "gpt-5.6-sol"\n'
                '[presets.sol.env]\nFOO = "bar"\n' + extra,
            )
            r = presets.load_preset_catalog(self.environ).require("sol")
            shapes.append((r.harness, r.model, r.harness_passthrough, dict(r.env)))
        self.assertEqual(len(set(map(repr, shapes))), 1, shapes)

    def test_executor_is_retired_in_favor_of_implementer(self):
        # Ported: the retired role is still named and still not honored — it is
        # dropped from the vocabulary rather than taking the catalog down.
        catalog, notices = self.load_with_notices(
            'version = 2\n[roles]\nexecutor = "Implements code"\n'
            '[presets.sol]\nharness = "codex"\n'
        )
        self.assertIn("executor", notices)
        self.assertIn("retired", notices)
        self.assertIsNotNone(catalog.get("sol"), "a retired role took the catalog down")

        # Second half: a preset REFERENCING the retired role. Ported the same way
        # — named, unhonored, and non-fatal. `implementer` is still offered as the
        # replacement, which was the whole point of the message.
        catalog, notices = self.load_with_notices(
            'version = 2\n[roles]\nimplementer = "Implements code"\n'
            '[presets.sol]\nharness = "codex"\n'
            '[presets.sol.metadata]\nprimary_roles = ["executor"]\n'
        )
        self.assertIn("executor", notices)
        self.assertIn("implementer", notices)
        self.assertIsNotNone(catalog.get("sol"))

    def test_a_role_in_two_buckets_refuses(self):
        # Gemini's sleepy file put prose_writer in both secondary and avoid.
        # Overlap is an authoring error, not a ranking: banned is a hard exclusion,
        # avoid is a soft preference, and a name cannot be both.
        # Ported: overlap is still an authoring error and still named, but it
        # costs the ROLE, not the preset. Metadata never reaches argv or the
        # environment — an ambiguous ranking makes that one role unusable, while
        # the seat itself launches exactly as before.
        catalog, notices = self.load_with_notices(
            'version = 2\n[roles]\nprose_writer = "Writes prose"\n'
            '[presets.gemini]\nharness = "agy"\n'
            '[presets.gemini.metadata]\n'
            'secondary_roles = ["prose_writer"]\n'
            'avoid_roles = ["prose_writer"]\n'
        )
        self.assertIn("prose_writer", notices)
        # Both buckets still named, so the operator can see WHICH two conflict —
        # "prose_writer is in two buckets" without saying which two is not a fix.
        self.assertIn("secondary_roles", notices)
        self.assertIn("avoid_roles", notices)
        self.assertIsNotNone(catalog.get("gemini"), "a briefing typo cost a launch")
        # ...and the ambiguous role is absent from BOTH buckets, not silently
        # kept in whichever was parsed first.
        meta = catalog.get("gemini").metadata
        self.assertNotIn("prose_writer", meta.secondary_roles)
        self.assertNotIn("prose_writer", meta.avoid_roles)

    def test_unbound_role_refuses_when_the_roles_table_exists(self):
        # Ported: roles are HINTS. An unbound role says something about briefing
        # text, never about whether the seat can launch, so it warns and the
        # preset still resolves.
        catalog, notices = self.load_with_notices(
            'version = 2\n[roles]\nreviewer = "Reviews"\n'
            '[presets.sol]\nharness = "codex"\n'
            '[presets.sol.metadata]\nprimary_roles = ["architect"]\n'
        )
        self.assertIn("architect", notices)
        self.assertIn("reviewer", notices)
        self.assertIsNotNone(catalog.get("sol"))

    def test_metadata_roles_without_a_roles_table_are_a_hard_error(self):
        # Ported, and the bug it was written for still has a witness: "the
        # missing-header authoring bug shipped silently once" — it must never be
        # SILENT. It is not; it is a notice naming both the missing table and the
        # role that wanted it. What changed is that saying so no longer costs the
        # machine its preset resolution.
        catalog, notices = self.load_with_notices(
            'version = 2\n[presets.sol]\nharness = "codex"\n'
            '[presets.sol.metadata]\nprimary_roles = ["reviewer"]\n'
        )
        self.assertIn("no [roles] table", notices)
        self.assertIn("reviewer", notices)
        self.assertIsNotNone(catalog.get("sol"))

    def test_unknown_metadata_key_is_ignored(self):
        # Closed→open inversion (tap-2z5r item 6): unknown keys are briefing text.
        self.write(
            self.config,
            'version = 2\n[presets.sol]\nharness = "codex"\n'
            '[presets.sol.metadata]\ntier = "gold"\nsummary = "kept"\n',
        )
        resolved = presets.load_preset_catalog(self.environ).require("sol")
        self.assertEqual(resolved.metadata.summary, "kept")
        self.assertFalse(hasattr(resolved.metadata, "tier"))

    def test_for_handle_exact_then_longest_prefix(self):
        self.write(
            self.config,
            'version = 2\n'
            '[roles]\nreviewer = "r"\nimplementer = "i"\n'
            '[presets.opus]\nharness = "claude"\n'
            '[presets.opus.metadata]\nprimary_roles = ["reviewer"]\n'
            '[presets.opus-med]\nharness = "claude"\n'
            '[presets.opus-med.metadata]\nprimary_roles = ["implementer"]\n'
            '[presets."sol.max"]\nharness = "codex"\n'
            '[presets."sol.max".metadata]\nprimary_roles = ["reviewer"]\n',
        )
        catalog = presets.load_preset_catalog(self.environ)
        self.assertEqual(catalog.for_handle("opus").provenance.name, "opus")
        self.assertEqual(catalog.for_handle("opus-med").provenance.name, "opus-med")
        self.assertEqual(catalog.for_handle("opus-2").provenance.name, "opus")
        self.assertEqual(catalog.for_handle("opus-med-2").provenance.name, "opus-med")
        self.assertEqual(catalog.for_handle("sol.max").provenance.name, "sol.max")
        self.assertEqual(catalog.for_handle("sol.max-2").provenance.name, "sol.max")
        self.assertIsNone(catalog.for_handle("worker"))
        self.assertIsNone(catalog.for_handle(""))

    def test_roster_display_facts_omit_unjoined_and_survive_a_broken_catalog(self):
        self.write(
            self.config,
            'version = 2\n[roles]\nreviewer = "r"\n'
            '[presets.grok]\nharness = "cursor"\n'
            '[presets.grok.metadata]\nprimary_roles = ["reviewer"]\n'
            'summary = "spar"\n',
        )
        facts = presets.roster_display_facts(["grok", "grok-2", "worker"], self.environ)
        self.assertEqual(facts["grok"]["preset"], "grok")
        self.assertEqual(facts["grok"]["roles"], "reviewer")
        self.assertEqual(facts["grok-2"]["preset"], "grok")
        self.assertNotIn("worker", facts)
        self.assertEqual(facts["grok"]["metadata"]["primary_roles"], ["reviewer"])

        self.write(self.config, "version = 2\n[presets.broken\nharness =\n")
        _, notices = capture_stderr(
            lambda: presets.roster_display_facts(["grok"], self.environ)
        )
        self.assertEqual(
            presets.roster_display_facts(["grok"], self.environ),
            {},
        )
        self.assertEqual(notices, [])

    def test_a_recorded_preset_survives_an_unreadable_catalog(self):
        # The record is durable truth; the catalog is a lookup. Returning {} on a
        # broken catalog erased provenance the seat had persisted — and a config
        # that will not parse is exactly when an operator needs to know what a
        # running seat was launched with.
        self.write(self.config, "version = 2\n[presets.broken\nharness =\n")
        facts, notices = capture_stderr(
            lambda: presets.roster_display_facts(
                ["grok", "unknown"], self.environ, recorded={"grok": "cursor-grok"}
            )
        )
        self.assertEqual(facts["grok"]["preset"], "cursor-grok")
        # UNREADABLE is not REMOVED, and the two must not share a flag (CodeRabbit,
        # #xxx). `preset_absent_from_catalog` means the catalog is readable and
        # this recorded name is not in it — a consumer acts on that by telling the
        # operator the entry is gone. Here nothing is known about whether the entry
        # exists, and the repair is the FILE, not the preset. Collapsing them made
        # the two indistinguishable in --json.
        self.assertTrue(facts["grok"]["preset_catalog_unavailable"])
        self.assertNotIn("preset_absent_from_catalog", facts["grok"])
        # Roles live in the catalog, so they are omitted rather than invented.
        self.assertEqual(facts["grok"]["roles"], "")
        # A handle with no record still has nothing to say without a catalog.
        self.assertNotIn("unknown", facts)
        self.assertEqual(notices, [])

    def test_a_readable_catalog_missing_the_entry_says_absent_not_unavailable(self):
        """The other side of the discriminator.

        A flag that fires in both situations distinguishes nothing, so the
        readable-catalog case must NOT claim the catalog was unavailable — and
        this is the branch a consumer uses to say "that preset is gone".
        """
        self.write(self.config, 'version = 2\n[presets.grok]\nharness = "cursor"\n')
        facts = presets.roster_display_facts(
            ["grok"], self.environ, recorded={"grok": "retired-preset"}
        )
        self.assertEqual(facts["grok"]["preset"], "retired-preset")
        self.assertTrue(facts["grok"]["preset_absent_from_catalog"])
        self.assertNotIn("preset_catalog_unavailable", facts["grok"])

    def test_a_readable_empty_catalog_is_not_an_unreadable_one(self):
        """`source: null` must mean "I could not read a catalog", nothing else.

        A valid config.toml with a vacant `[presets]` and no legacy file used to
        propagate the missing-legacy error, which `try_load_catalog_for_display`
        absorbed into a bare None — so `tap presets --json` said no catalog was
        readable about a file that read perfectly and simply holds nothing yet.
        Those are different answers to "who can I launch?", and the JSON surface
        exists to tell them apart (codex, #xxx).

        Both directions, since a one-sided assertion here proves nothing: a
        readable-but-empty catalog KEEPS its source, and a genuinely absent
        config still reports None.
        """
        self.write(self.config, "version = 2\n[presets]\n")
        source, rows = presets.catalog_display_rows(self.environ)
        self.assertIsNotNone(source, "a readable empty catalog reported as unreadable")
        self.assertEqual(rows, ())

        self.config.unlink()
        source, rows = presets.catalog_display_rows(self.environ)
        self.assertIsNone(source, "an absent catalog claimed a source")
        self.assertEqual(rows, ())

    def test_a_flag_shaped_param_value_survives_the_config_floor(self):
        """A value that looks like a flag must not be read as one.

        `params_to_argv` rendered `foo = "--workspace"` as two tokens, and
        `splice_tokens_if_absent`'s floor decides "is the next token this flag's
        value?" by asking whether it starts with `-`. It therefore read the VALUE
        as an independent flag, found the builder already emitted `--workspace`,
        and dropped it — leaving `--foo` orphaned to swallow whatever came next.
        The `=` spelling is the only unambiguous one, for the floor and for the
        harness's own parser.
        """
        argv = list(presets.params_to_argv({"foo": "--workspace"}))
        self.assertEqual(argv, ["--foo=--workspace"])
        spliced = presets.splice_tokens_if_absent(
            ["cursor-agent", "--workspace", "/repo"], argv
        )
        self.assertIn("--foo=--workspace", spliced)
        # The builder's own flag is untouched, and the config did not replace it.
        self.assertEqual(spliced.count("--workspace"), 1)

    def test_the_floor_matches_by_option_name_not_token(self):
        """`--workspace=-tmp` and `--workspace` are the same option.

        The `=` rendering (added so a flag-shaped VALUE is unambiguous) does not
        equal the builder's bare token, so an exact-token floor stopped seeing it
        as a duplicate and the harness received the option twice — the config
        copy winning or erroring depending on the parser, with builder argv
        documented as the floor. Fixing one ambiguity re-opened the other; the
        floor has to compare option NAMES on both sides.
        """
        argv = ["cursor-agent", "--workspace", "/repo"]
        spliced = presets.splice_tokens_if_absent(argv, ["--workspace=-tmp"])
        self.assertEqual(spliced, argv, "the builder's flag must remain the floor")

        # ...and the builder using the `=` form is the same question mirrored.
        argv_eq = ["cursor-agent", "--workspace=/repo"]
        self.assertEqual(
            presets.splice_tokens_if_absent(argv_eq, ["--workspace", "/other"]),
            argv_eq,
        )

    def test_a_non_builder_option_with_a_flag_shaped_value_survives(self):
        # The floor skips DUPLICATES, not everything spelled with `=`. Without
        # this arm, a floor that dropped every `=` token would pass the test above.
        spliced = presets.splice_tokens_if_absent(
            ["cursor-agent", "--workspace", "/repo"], ["--foo=--workspace"]
        )
        self.assertIn("--foo=--workspace", spliced)
        self.assertEqual(spliced.count("--workspace"), 1)

    def test_ordinary_and_boolean_params_keep_their_spelling(self):
        # The `=` form is reserved for the ambiguous case; widening it would churn
        # every rendered invocation for no gain.
        self.assertEqual(
            list(presets.params_to_argv({"model": "opus", "quiet": True})),
            ["--model", "opus", "--quiet"],
        )

    def test_recorded_provenance_outranks_the_handle_guess(self):
        """The record is what a seat was launched WITH; the handle is a guess.

        This was live on the operator's own roster: seats launched with preset
        `cursor-grok` displayed `grok`, because a catalog entry of that name
        existed and `for_handle` matched it. Prefixing was invented partly to make
        the handle carry provenance; reading the record makes that unnecessary.
        """
        self.write(
            self.config,
            'version = 2\n'
            '[presets.grok]\nharness = "cursor"\n'
            '[presets.cursor-grok]\nharness = "cursor"\n',
        )
        facts = presets.roster_display_facts(
            ["grok"], self.environ, recorded={"grok": "cursor-grok"}
        )
        self.assertEqual(facts["grok"]["preset"], "cursor-grok")
        # A recorded value is authoritative, so it carries no inferred marker.
        self.assertNotIn("preset_inferred", facts["grok"])

    def test_an_inferred_preset_is_marked_as_inferred(self):
        # A row with no recorded provenance still gets the name match — dropping
        # it would blank facts that are usually right — but it must not print with
        # the authority of a record.
        self.write(self.config, 'version = 2\n[presets.grok]\nharness = "cursor"\n')
        facts = presets.roster_display_facts(["grok", "grok-2"], self.environ)
        self.assertTrue(facts["grok"]["preset_inferred"])
        self.assertTrue(facts["grok-2"]["preset_inferred"])
        self.assertEqual(facts["grok-2"]["preset"], "grok")

    def test_a_recorded_preset_absent_from_the_catalog_still_wins(self):
        # The operator deleted or renamed the entry after launching. Reporting the
        # handle match instead would substitute a DIFFERENT preset for the one the
        # seat actually runs — the exact misreport this change removes.
        self.write(self.config, 'version = 2\n[presets.grok]\nharness = "cursor"\n')
        facts = presets.roster_display_facts(
            ["grok"], self.environ, recorded={"grok": "retired-preset"}
        )
        self.assertEqual(facts["grok"]["preset"], "retired-preset")
        self.assertTrue(facts["grok"]["preset_absent_from_catalog"])
        self.assertNotIn("preset_inferred", facts["grok"])

    def test_try_load_catalog_for_display_is_none_when_nothing_exists(self):
        self.assertIsNone(presets.try_load_catalog_for_display(self.environ))

    def test_metadata_notice_stays_quiet_without_roles_or_summary(self):
        self.assertIsNone(presets.metadata_notice("grok", None))
        empty = presets.PresetMetadata()
        self.assertIsNone(presets.metadata_notice("grok", empty))
        with_roles = presets.PresetMetadata(primary_roles=("reviewer", "implementer"))
        self.assertEqual(
            presets.metadata_notice("grok", with_roles),
            "tap session: grok — reviewer, implementer",
        )
        both = presets.PresetMetadata(
            primary_roles=("reviewer",),
            summary="Adversarial sparring",
        )
        self.assertEqual(
            presets.metadata_notice("grok", both),
            "tap session: grok — reviewer — Adversarial sparring",
        )


class VerbatimParamsV2Tests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = pathlib.Path(tmp.name)
        self.config_home = self.root / "config"
        self.home = self.root / "home"
        self.home.mkdir()
        self.config = self.config_home / "tap" / "config.toml"
        self.environ = {
            "HOME": str(self.home),
            "XDG_CONFIG_HOME": str(self.config_home),
        }

    def write_config(self, body: bytes) -> pathlib.Path:
        self.config.parent.mkdir(parents=True, exist_ok=True)
        self.config.write_bytes(body)
        self.config.chmod(0o600)
        return self.config

    def load_reference(self, extra: bytes = b""):
        """Load the checked-in v3 reference (plus optional bytes) as config.toml.

        The reference is the sanitized catalog fixture; it replaces the module
        constant the pre-cutover reader carried, so the path is computed here.
        """
        reference = SESSION_DIR.parents[1] / "config" / "config.v3.toml"
        self.assertTrue(reference.is_file(), reference)
        self.write_config(reference.read_bytes() + extra)
        return capture_stderr(lambda: presets.load_preset_catalog(self.environ))

    def test_repeatable_params_from_toml_preserve_values_and_order(self):
        raw = b'\n'.join([
            b'version = 3', b'[presets.fast]', b'harness = "codex"',
            b'params.model = "gpt-5.6-sol"',
            b'params.config = ["service_tier=fast", "model_reasoning_effort=medium", "service_tier=fast", "-literal", "with spaces"]',
            b'params.unused = []',
        ])
        self.write_config(raw)
        resolved = presets.load_preset_catalog(self.environ).require("fast")
        expected = ["--config", "service_tier=fast", "--config", "model_reasoning_effort=medium",
                    "--config", "service_tier=fast", "--config=-literal", "--config", "with spaces"]
        self.assertEqual(resolved.model, "gpt-5.6-sol")
        self.assertEqual(resolved.param_keys, ("config",))
        self.assertEqual(list(resolved.harness_passthrough), expected)
        self.assertEqual(presets.splice_tokens_if_absent(["codex", "--model", resolved.model],
                                                       resolved.harness_passthrough),
                         ["codex", *expected, "--model", "gpt-5.6-sol"])

    def test_repeatable_params_keep_existing_tier_precedence(self):
        params = {"config": ["first", "second"], "quiet": True, "unused": []}
        self.assertEqual(presets.splice_verbatim_params(["codex"], params),
                         ["codex", "--config", "first", "--config", "second", "--quiet"])
        self.assertEqual(presets.splice_verbatim_params(["codex", "--config=existing"], params),
                         ["codex", "--quiet", "--config=existing"])

    def test_repeatable_params_reject_invalid_elements(self):
        # The policy tier carries the exact Python params diagnostics; a bad
        # `params.config` element refuses there with the same words. Written
        # explicitly rather than interpolated: each spelling is the TOML the
        # operator would have authored.
        bodies = (
            ('[harness.codex.params]\nconfig = [true]', "must be a boolean, a string, or an array of strings"),
            ('[harness.codex.params]\nconfig = [1]', "must be a boolean, a string, or an array of strings"),
            ('[harness.codex.params]\nconfig = [["nested"]]', "must be a boolean, a string, or an array of strings"),
            ('[harness.codex.params]\nconfig = [""]', "must be a non-empty string"),
            ('[harness.codex.params]\nconfig = ["   "]', "must be a non-empty string"),
            ('[harness.codex.params]\nconfig = ["bad\\nvalue"]', "contains a control character"),
            ('[harness.codex.params]\nconfig = ["ok", false]', "must be a boolean, a string, or an array of strings"),
        )
        for table_body, fragment in bodies:
            with self.subTest(fragment=fragment):
                self.write_config(("version = 3\n" + table_body + "\n").encode())
                with self.assertRaises(presets.PresetError) as ctx:
                    presets.resolve_harness_env("codex", self.environ)
                self.assertEqual(ctx.exception.error_class, "preset_config_invalid")
                self.assertIn(f"[harness.codex] params.config {fragment}", ctx.exception.detail)
                self.assertEqual(ctx.exception.action, f"fix {self.config.resolve()}")

    def test_model_array_is_passthrough_not_persisted_scalar(self):
        self.write_config(
            b'version = 3\n[presets.multi]\nharness = "codex"\nparams.model = ["one", "two"]\n'
        )
        resolved = presets.load_preset_catalog(self.environ).require("multi")
        self.assertIsNone(resolved.model)
        self.assertEqual(resolved.harness_passthrough, ("--model", "one", "--model", "two"))

    def test_reference_config_with_other_subsystem_tables_has_clean_stderr(self):
        catalog, stderr = self.load_reference(
            b'\n[recovery]\naggressiveness = "aggressive"\n'
            b'[delivery]\nnow_window_seconds = 10\n'
        )
        self.assertIn("grok", catalog.names)
        self.assertEqual(stderr, [])

    def test_reference_config_still_warns_for_a_typoed_preset_table(self):
        catalog, stderr = self.load_reference(
            b'\n[recovery]\naggressiveness = "aggressive"\n'
            b'[delivery]\nnow_window_seconds = 10\n'
            b'[preset]\nexample = true\n'
        )
        self.assertIn("grok", catalog.names)
        warning = "\n".join(stderr)
        self.assertIn("unknown top-level table 'preset'", warning)
        self.assertIn("did you mean 'presets'?", warning)
        self.assertEqual(warning.count("unknown top-level table"), 1)

    def test_checked_in_v3_reference_parses_with_the_real_parser(self):
        catalog, _ = self.load_reference()
        self.assertEqual(len(catalog.names), 31)
        self.assertIn("grok", catalog.names)
        self.assertIn("hermes-agent", catalog.names)
        grok = catalog.require("grok")
        self.assertEqual(grok.harness, "cursor")
        self.assertEqual(grok.model, "cursor-grok-4.6-high")
        hermes = catalog.require("hermes-agent")
        self.assertEqual(hermes.harness, "hermes")
        self.assertEqual(hermes.metadata.referenced_roles(), frozenset())
        self.assertEqual(hermes.harness_passthrough[0], "--provider")

    def test_splice_does_not_duplicate_a_builder_flag(self):
        argv = ["claude", "--dangerously-skip-permissions", "--model", "opus"]
        out = presets.splice_verbatim_params(
            argv, {"dangerously-skip-permissions": True, "effort": "medium"}
        )
        self.assertEqual(out.count("--dangerously-skip-permissions"), 1)
        self.assertEqual(
            out,
            [
                "claude",
                "--effort",
                "medium",
                "--dangerously-skip-permissions",
                "--model",
                "opus",
            ],
        )

    def test_splice_config_less_keeps_builder_flags(self):
        argv = ["claude", "--dangerously-skip-permissions", "--model", "opus"]
        self.assertEqual(presets.splice_verbatim_params(argv, {}), argv)
        # Blessed-file restatement of a builder flag. Removing the floor
        # duplicates the token; identity-on-empty-params would still green.
        restated = presets.splice_verbatim_params(
            argv, {"dangerously-skip-permissions": True}
        )
        self.assertEqual(restated.count("--dangerously-skip-permissions"), 1)
        self.assertEqual(restated, argv)

    def test_preset_tier_tokens_respect_the_builder_floor(self):
        argv = ["claude", "--dangerously-skip-permissions", "--model", "opus"]
        out = presets.splice_tokens_if_absent(
            argv, ("--dangerously-skip-permissions", "--effort", "high")
        )
        self.assertEqual(out.count("--dangerously-skip-permissions"), 1)
        self.assertEqual(
            out,
            [
                "claude",
                "--effort",
                "high",
                "--dangerously-skip-permissions",
                "--model",
                "opus",
            ],
        )
        operator = presets.splice_tokens_if_absent(
            argv,
            ("--dangerously-skip-permissions",),
            floor=False,
        )
        self.assertEqual(operator.count("--dangerously-skip-permissions"), 2)

    def test_splice_keeps_trailing_prompt_last(self):
        # Reds on append, greens on index-1. Cursor and agy both trail a positional.
        argv = [
            "cursor-agent",
            "--force",
            "--sandbox",
            "disabled",
            "--model",
            "cursor-grok-4.6-high",
            "run tap in",
        ]
        out = presets.splice_verbatim_params(argv, {"yolo": True})
        self.assertEqual(out[0], "cursor-agent")
        self.assertEqual(out[1], "--yolo")
        self.assertEqual(out[-1], "run tap in")
        self.assertNotEqual(out[-1], "--yolo")

    def test_splice_presence_is_exact_token_equality(self):
        argv = ["claude", "--model-reasoning", "x", "use --model x"]
        out = presets.splice_verbatim_params(argv, {"model": "opus"})
        self.assertEqual(out[1:3], ["--model", "opus"])
        self.assertEqual(out[-1], "use --model x")

    def test_false_on_a_builder_flag_is_a_noop(self):
        argv = ["cursor-agent", "--force", "--sandbox", "disabled"]
        out = presets.splice_verbatim_params(argv, {"force": False, "yolo": True})
        self.assertIn("--force", out)
        self.assertIn("--yolo", out)
        self.assertEqual(out[1], "--yolo")


class SchemaToleranceTests(unittest.TestCase):
    """The parser understands what it can and never refuses over content.

    THE INCIDENT (2026-08-17). Ops hand-edited the live machine config to
    version=3 with a new [intelligences] table. Every preset operation on the box
    refused for four minutes — `[intelligences]` tripped the unknown-top-level-key
    check before the version check even ran. Nothing was wrong with the presets.

    panel ruling: a config is its owner's to extend, so unknown content warns and
    is skipped. The ONLY hard failure left is a document that is not parseable at
    all. Every arm here therefore proves warn-and-proceed WITH THE UNDERSTOOD
    REMAINDER INTACT — a parser that silently returned nothing would satisfy
    "did not refuse" while being useless, so each arm checks the survivor too.
    """

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.home = self.root / "home"
        self.config_home = self.root / "config"
        self.path = self.config_home / "tap" / "config.toml"
        self.home.mkdir()
        self.environ = {
            "HOME": str(self.home),
            "XDG_CONFIG_HOME": str(self.config_home),
        }

    def write(self, body: str):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(body, encoding="utf-8")
        self.path.chmod(0o600)
        return self.path

    GOOD = '[presets.keeper]\nharness = "claude"\n'
    LEVELS = (
        "[intelligences]\n"
        'frontier = "Frontier model, top of the line."\n'
        'advanced = "Advanced model for general execution."\n'
    )

    def load_with_notices(self, body: str):
        """Load, capturing notices. Returns (catalog, notices)."""
        self.write(body)
        return capture_stderr(lambda: presets.load_preset_catalog(self.environ))

    def assert_warned(self, notices, *fragments):
        joined = "\n".join(notices)
        for fragment in fragments:
            self.assertIn(fragment, joined, f"no notice mentioned {fragment!r}: {joined}")

    # ---- versions: known, future, retired, malformed -----------------------

    def test_version_3_loads(self):
        catalog, _ = self.load_with_notices("version = 3\n" + self.GOOD)
        self.assertIsNotNone(catalog.get("keeper"))

    def test_version_2_still_loads(self):
        # The live file sits at v2 after the emergency downgrade.
        catalog, _ = self.load_with_notices("version = 2\n" + self.GOOD)
        self.assertIsNotNone(catalog.get("keeper"))

    def test_a_future_version_warns_and_still_loads(self):
        """Forward compatibility is the whole point of the incident.

        The next hand-edit to a version this reader has never heard of must cost
        a notice, not the machine.
        """
        catalog, notices = self.load_with_notices("version = 9\n" + self.GOOD)
        self.assertIsNotNone(catalog.get("keeper"))
        self.assert_warned(notices, "newer than this reader")

    def test_a_retired_version_warns_and_reads_no_presets(self):
        """RETIRED and FUTURE degrade differently, and the difference is the point.

        A future version is a file this reader UNDER-stands: the shapes it knows
        still mean what they meant, so it reads them and ignores the rest.

        A retired version is a file this reader MIS-reads: v1 put model/effort at
        preset top level, so parsing those entries under current rules emits
        "unknown key 'effort'" — which tells a stranded operator to DELETE the key
        when the remedy is to migrate the file. Saying "retired" once and reading
        no presets is the honest answer; adding per-key noise on top of it is
        worse than silence.
        """
        catalog, notices = self.load_with_notices("version = 1\n" + self.GOOD)
        self.assert_warned(notices, "retired")
        self.assertEqual(catalog.names, ())
        self.assertNotIn("unknown key", "\n".join(notices))

    def test_a_non_integer_version_warns_and_still_loads(self):
        catalog, notices = self.load_with_notices('version = "three"\n' + self.GOOD)
        self.assertIsNotNone(catalog.get("keeper"))
        self.assert_warned(notices, "version is not an integer")

    # ---- unknown tables ----------------------------------------------------

    def test_an_unknown_top_level_table_warns_and_the_rest_loads(self):
        catalog, notices = self.load_with_notices(
            "version = 3\n[wormhole]\nx = 1\n" + self.GOOD
        )
        self.assertIsNotNone(catalog.get("keeper"))
        self.assert_warned(notices, "wormhole")

    def test_a_near_miss_table_name_suggests_the_real_one(self):
        # Typo catchability: `[preset]` must not vanish silently.
        _, notices = self.load_with_notices("version = 3\n[preset]\nx = 1\n" + self.GOOD)
        self.assert_warned(notices, "did you mean 'presets'?")

    def test_intelligences_needs_no_version_gate(self):
        catalog, _ = self.load_with_notices("version = 2\n" + self.LEVELS + self.GOOD)
        self.assertIsNotNone(catalog.get("keeper"))

    # ---- per-preset degrade: the file survives, the bad entry does not -----

    def test_an_unusable_preset_is_dropped_and_its_siblings_survive(self):
        """The floor under "ignore what you do not understand".

        Without this, a typo'd harness yields an entry that parses and launches
        nothing — worse than dropping it, because `tap presets` would advertise it.
        """
        catalog, notices = self.load_with_notices(
            "version = 3\n[presets.broken]\nharness = 42\n" + self.GOOD
        )
        self.assertIsNotNone(catalog.get("keeper"), "a sibling preset was taken down")
        self.assertIsNone(catalog.get("broken"), "an unusable preset was kept")
        self.assert_warned(notices, "broken")

    def test_a_preset_named_after_a_harness_is_dropped_not_refused(self):
        """Preserves the #xxx resolution invariant with no refusal.

        Preset-first lookup is only equivalent to harness-first while no preset
        can be named after a canonical harness. Dropping it keeps that true: the
        lookup misses and falls through to the harness, exactly as before.
        """
        catalog, notices = self.load_with_notices(
            'version = 3\n[presets.claude]\nharness = "claude"\n' + self.GOOD
        )
        self.assertIsNone(catalog.get("claude"))
        self.assertIsNotNone(catalog.get("keeper"))
        self.assert_warned(notices, "canonical harness")

    # ---- vocabularies are hints -------------------------------------------

    def test_an_undefined_intelligence_warns_and_loads(self):
        # Ops's live `sonnet = "medium"` case: cosmetic, never blocking.
        catalog, notices = self.load_with_notices(
            "version = 3\n" + self.LEVELS + self.GOOD
            + '[presets.keeper.metadata]\nintelligence = "medium"\n'
        )
        self.assertEqual(catalog.get("keeper").metadata.intelligence, "medium")
        self.assert_warned(notices, "medium", "advanced")

    def test_an_undefined_role_warns_and_loads(self):
        catalog, notices = self.load_with_notices(
            'version = 3\n[roles]\nleader = "leads"\n' + self.GOOD
            + '[presets.keeper.metadata]\nprimary_roles = ["inventor"]\n'
        )
        self.assertIsNotNone(catalog.get("keeper"))
        self.assert_warned(notices, "inventor")

    def test_one_bad_vocabulary_entry_does_not_cost_the_others(self):
        catalog, notices = self.load_with_notices(
            'version = 3\n[intelligences]\nfrontier = "top"\n"bad name!" = "x"\n'
            + self.GOOD
            + '[presets.keeper.metadata]\nintelligence = "frontier"\n'
        )
        self.assertIsNotNone(catalog.get("keeper"))
        # frontier still bound, so no undefined-level warning for it
        self.assertNotIn("no [intelligences] entry", "\n".join(notices))
        self.assert_warned(notices, "bad name!")

    def test_a_hyphenated_level_name_is_legal(self):
        """Ops's real vocabulary opens with `s-tier`.

        The role-name regex forbids hyphens, so reusing it here would have made
        the reader reject the very file this work exists to read.
        """
        catalog, notices = self.load_with_notices(
            'version = 3\n[intelligences]\ns-tier = "Absolute top of the line."\n'
            + self.GOOD
            + '[presets.keeper.metadata]\nintelligence = "s-tier"\n'
        )
        self.assertEqual(catalog.get("keeper").metadata.intelligence, "s-tier")
        self.assertEqual(notices, [], f"a legal file produced notices: {notices}")

    # ---- unknown metadata flows through -----------------------------------

    def test_unknown_metadata_keys_are_carried_verbatim(self):
        """panel ruling: he adds a field, reading models work out what it means.

        This used to be a whitelist — "legal and ignored" meant the value reached
        nothing. Carrying it is the whole feature, so the arm checks the value
        SURVIVES rather than merely that the load did not fail.
        """
        catalog, _ = self.load_with_notices(
            "version = 3\n" + self.GOOD
            + '[presets.keeper.metadata]\n'
            'summary = "known field"\n'
            'vibes = "immaculate"\n'
            'tokens_per_dollar = 1234\n'
        )
        blob = catalog.get("keeper").metadata.to_json()
        self.assertEqual(blob["vibes"], "immaculate")
        self.assertEqual(blob["tokens_per_dollar"], 1234)
        # ...and the typed field is still typed, not swept into the bag.
        self.assertEqual(blob["summary"], "known field")

    def test_a_malformed_known_key_is_dropped_not_demoted_to_passthrough(self):
        """The one way passthrough could launder a validated field.

        `summary` is a known string key, so an unusable value is dropped with a
        notice. It must not reappear in the passthrough bag wearing a different
        hat — that would turn a warned-about error into a silently rendered value.
        """
        catalog, notices = self.load_with_notices(
            "version = 3\n" + self.GOOD
            + '[presets.keeper.metadata]\nsummary = 42\n'
        )
        self.assert_warned(notices, "summary")
        blob = catalog.get("keeper").metadata.to_json()
        self.assertIsNone(blob["summary"])
        self.assertNotEqual(blob["summary"], 42)

    def test_json_escapes_control_characters_in_passthrough_values(self):
        """Why PR A carries no render hazard, pinned rather than asserted in prose.

        Passthrough deliberately skips the control-character screen that guards
        known fields, so the question is where an unscreened value can land. On
        this branch it lands only in `--json`, and json.dumps escapes it — a
        terminal receives `\\u001b`, not ESC.

        The HUMAN render is a different surface and does not exist here (it comes
        with #xxx's `tap presets`). Sanitizing there is PR B's job; this arm is
        the boundary marker, so if a human render is ever fed from this data
        without a sanitizer, the omission is visible rather than assumed.
        """
        catalog, _ = self.load_with_notices(
            "version = 3\n" + self.GOOD
            + '[presets.keeper.metadata]\ninvented = "a\\u001B[31mRED"\n'
        )
        raw = catalog.get("keeper").metadata.to_json()["invented"]
        self.assertIn(chr(27), raw, "the parser should carry it verbatim")
        rendered = json.dumps(raw)
        self.assertNotIn(chr(27), rendered, "a raw ESC reached the JSON surface")

    # ---- an explicit request still fails CLOSED ----------------------------

    def test_requesting_a_dropped_preset_says_dropped_not_missing(self):
        """Tolerant reading must not turn a fence violation into "not found".

        The preset IS in the file. Answering "not found" sends the operator to
        re-add something already there instead of fixing what is wrong with it —
        and the case where that misdirects hardest is a fence-crossing `env`,
        where it points away from a security-relevant key.
        """
        self.write(
            'version = 3\n[presets.fenced]\nharness = "claude"\n'
            '[presets.fenced.env]\nPATH = "/evil"\n' + self.GOOD
        )
        catalog = presets.load_preset_catalog(self.environ)
        with self.assertRaises(presets.PresetError) as ctx:
            catalog.require("fenced")
        error = ctx.exception
        self.assertEqual(error.error_class, "preset_not_usable")
        self.assertIn("defined in", error.detail)
        self.assertIn("PATH", error.detail)
        self.assertIn("fenced", error.action)

    def test_requesting_a_genuinely_absent_preset_still_says_not_found(self):
        # The other side of the discriminator: a name that was never in the file
        # must NOT claim it was dropped, or the new message means nothing.
        self.write("version = 3\n" + self.GOOD)
        catalog = presets.load_preset_catalog(self.environ)
        with self.assertRaises(presets.PresetError) as ctx:
            catalog.require("never-existed")
        self.assertEqual(ctx.exception.error_class, "preset_not_found")

    # ---- the two entry points must not disagree ----------------------------

    def test_a_non_table_presets_value_degrades_on_the_PRODUCTION_path(self):
        """The refusal that survived the tolerance work, and why it hid.

        `load_preset_catalog` ran its OWN shape check before reaching the tolerant
        reader, so `presets = ["bad"]` degraded through `parse_preset_catalog` and
        RAISED through `load_preset_catalog` — same bytes, opposite outcomes, and
        the raising one is what a launch calls.

        It hid behind a FIXTURE PATH, not a missing test. An arm for exactly this
        input existed and passed, because `PresetCatalogTests` writes the legacy
        `presets.toml`, which reaches the tolerant parser at the END of the loader
        and never touches the `config.toml` branch that raised. Only a fixture
        written to config.toml can see it.
        """
        catalog, notices = self.load_with_notices('version = 3\npresets = ["bad"]\n')
        self.assertEqual(catalog.names, ())
        self.assert_warned(notices, "[presets] is not a table")

    def test_every_malformed_document_degrades_on_the_production_entry(self):
        """One entry point now; the sweep keeps the shapes honest on it.

        This used to compare `load_preset_catalog` against `parse_preset_catalog`
        because production drove one and the suite the other. The R4 cutover
        removed the second entry point (the parser lives in the native engine),
        so the comparison it enforced is vacuous — but the corpus still pins
        that every malformed shape DEGRADES on the production path with the
        right resolved/dropped split, which is the property the original
        divergence hid.
        """
        # DELIBERATELY EXCLUDED: a file with no `[presets]` key at all. There the
        # loader legitimately falls back to the legacy presets.toml — a designed
        # difference, not a divergence.
        cases = (
            ("non-table presets", 'version = 3\npresets = ["bad"]\n', (), ()),
            ("unknown table", "version = 3\n[wormhole]\nx = 1\n" + self.GOOD, ("keeper",), ()),
            ("future version", "version = 9\n" + self.GOOD, ("keeper",), ()),
            ("unusable preset", 'version = 3\n[presets.bad]\nharness = 42\n' + self.GOOD,
             ("keeper",), ("bad",)),
        )
        for label, body, names, dropped in cases:
            with self.subTest(case=label):
                self.write(body)
                catalog, _ = capture_stderr(
                    lambda: presets.load_preset_catalog(self.environ)
                )
                self.assertEqual(
                    (catalog.names, sorted(catalog.dropped)), (names, list(dropped)),
                    f"{label}: production load resolved/dropped the wrong split",
                )

    def test_a_toml_date_in_passthrough_stays_json_serializable(self):
        """Passthrough must not be able to blank the roster.

        TOML legally yields dates, times, and datetimes. Carried raw, they make
        json.dumps raise — and `tap team --json` writes through a helper guarded
        with `|| true`, so the TypeError does not surface: it silently drops EVERY
        preset and metadata fact. Silent partial output is worse than a crash,
        because nothing distinguishes it from a seat with no preset at all.

        My earlier reasoning that json.dumps "escapes control characters" was
        about CHARACTERS and never covered TYPES (codex, #xxx).
        """
        catalog, _ = self.load_with_notices(
            "version = 3\n" + self.GOOD
            + '[presets.keeper.metadata]\n'
            'calibrated_on = 2026-08-18\n'
            'window = [2026-08-18, 2026-08-19]\n'
            'nested = { since = 2026-01-01 }\n'
        )
        blob = catalog.get("keeper").metadata.to_json()
        self.assertEqual(blob["calibrated_on"], "2026-08-18")
        self.assertEqual(blob["window"], ["2026-08-18", "2026-08-19"])
        self.assertEqual(blob["nested"], {"since": "2026-01-01"})
        json.dumps(blob)  # the actual promise: this must not raise

    def test_a_malformed_notes_entry_costs_the_entry_not_the_file(self):
        catalog, notices = self.load_with_notices(
            "version = 3\n" + self.GOOD + '[notes]\nok = "fine"\nbad = 42\n'
        )
        self.assert_warned(notices, "notes.bad")
        self.assertIsNotNone(catalog.get("keeper"), "a bad note took down the catalog")

    # ---- the one remaining hard failure ------------------------------------

    def test_unparseable_toml_still_raises(self):
        """The single sanctioned refusal, and it must stay.

        Without a document there is nothing to partially understand — this is not
        a content question, and the callers already own the degrade path.
        """
        self.write("version = 3\n[presets.p\nharness =\n")
        with self.assertRaises(presets.PresetError) as ctx:
            presets.load_preset_catalog(self.environ)
        self.assertIn("TOML parse failed", ctx.exception.detail)



if __name__ == "__main__":
    unittest.main()
