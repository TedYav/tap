#!/usr/bin/env bash
# driver-rc6-effect-probe.test.sh — rc6 can come back with a keystroke already
# sent. EXECUTABLE, not structural (tap-49kp6).
#
# The tmux driver maps rc6 to `stop-ambiguous` / `effect: possible`. Whether that
# is right turns on one question — can `tap_submit_existing_verify` return
# identity_rc AFTER a send-keys Enter? — and that question was argued three times
# from reading the code, wrongly at least once, before anyone drove it.
#
# `driver_rc6_premise.py` guards the row STRUCTURALLY: it checks the retry loop
# still contains both a guard returning identity_rc and a send-keys Enter. Two
# reviewers independently read that as accepting a pre-Enter guard, because the
# guard TEXTUALLY precedes the Enter. It does — on iteration 1. On iterations 2
# through 5 the loop-back puts it after the previous iteration's Enter.
#
# That is a claim about control flow, and control flow is the thing reading gets
# wrong. So this file stops arguing and MEASURES: it drives the real function
# with a fake tmux that counts Enters and a guard that fails from the second call
# onward, in a tree where the post-Enter guard has been REMOVED — the exact
# mutant both reviewers built. If rc6 comes back with enters >= 1, the premise
# holds through the loop-back alone and the conservative row is correct.
#
# Result on the shipped tree: rc=6, enters=1.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

fail() { echo "driver-rc6-effect-probe: $*" >&2; exit 1; }

# The mutant: keep the top-of-loop guard, remove ONLY the post-Enter one. This is
# the tree both reviewers said the structural checker wrongly accepts.
cp "$ROOT/skills/tap/scripts/lib.sh" "$WORK/lib.sh"
cp "$ROOT/skills/tap/scripts/python-runtime.sh" "$WORK/python-runtime.sh"
cp -R "$ROOT/skills/tap/scripts/python-bin" "$WORK/python-bin"
python3 - "$WORK/lib.sh" <<'ENDPY'
import sys
p = sys.argv[1]
s = open(p).read()
i = s.index('  for _ in 1 2 3 4 5; do')
j = s.index('  done', i)
body = s[i:j]
k = body.index('if tap_submit_identity_guard')
body = body[:k] + body[k:].replace('return "$identity_rc"', ':', 1)
open(p, 'w').write(s[:i] + body + s[j:])
ENDPY
grep -q 'for _ in 1 2 3 4 5; do' "$WORK/lib.sh" || fail "the mutant did not apply; the retry loop moved"

# Drive it. The guard passes once and fails afterwards, so the failure lands on
# the SECOND arrival at the top of the loop — after iteration 1 pressed Enter.
cat > "$WORK/probe.sh" <<'ENDP'
ENTERS="$1"; GUARDS="$2"
. "$3" 2>/dev/null || true
: > "$ENTERS"; : > "$GUARDS"
tmux() {
  case "${1:-}" in
    send-keys) shift; case "$*" in *Enter*) echo E >> "$ENTERS" ;; esac; return 0 ;;
    *) return 0 ;;
  esac
}
tap_submit_identity_guard() { echo G >> "$GUARDS"; [ "$(wc -l < "$GUARDS")" -le 1 ]; }
tap_settle() { :; }
tap_pane_alive() { echo alive; }
tap_input_has_injected_content() { return 0; }
_rc=0
tap_submit_existing_verify "pane" "codex" "the-id" 1 id "" "" "" 6 "" "" 2>/dev/null || _rc=$?
echo "rc=$_rc enters=$(wc -l < "$ENTERS" | tr -d ' ')"
ENDP
out="$(bash "$WORK/probe.sh" "$WORK/enters" "$WORK/guards" "$WORK/lib.sh" 2>/dev/null | tail -1)"
rc="${out#rc=}"; rc="${rc%% *}"
enters="${out##*enters=}"

[ "$rc" = "6" ] || fail "the probe returned rc=$rc, not 6 — the premise cannot be measured this way any more, so re-derive the mapping row deliberately ($out)"
[ "${enters:-0}" -ge 1 ] || fail "rc6 came back with NO Enter sent ($out) — rc6 would be pre-effect and the conservative row should be re-derived"
echo "driver-rc6-effect-probe: rc6 returns after a sent Enter even with the post-Enter guard removed ($out): ok"

# The mirror. With NO guard in the loop at all, rc6 must NOT be reachable this
# way — otherwise the probe is measuring something other than the guard, and a
# green here would mean nothing.
cp "$ROOT/skills/tap/scripts/lib.sh" "$WORK/lib2.sh"
python3 - "$WORK/lib2.sh" <<'ENDPY'
import sys
p = sys.argv[1]
s = open(p).read()
i = s.index('  for _ in 1 2 3 4 5; do')
j = s.index('  done', i)
# `true #` was the first spelling and it was a FALSE GREEN: the guard call sits
# in `if ! tap_submit_identity_guard ...; then`, so commenting out the tail
# comments out `; then` and the mutant does not parse. The probe suppressed
# stderr, saw no rc=6, and concluded rc6 was unreachable -- an absence produced
# by a syntax error, read as evidence about the guard. `true` takes arbitrary
# arguments and always succeeds, so the line stays valid and means what the
# mutation intends.
open(p, 'w').write(s[:i] + s[i:j].replace('tap_submit_identity_guard', 'true') + s[j:])
ENDPY
# THE MUTANT MUST BE A RUNNABLE PROGRAM BEFORE ITS SILENCE MEANS ANYTHING.
# Each check answers a different way the previous version could lie: it parsed,
# it loaded, and the thing being mutated is actually gone.
bash -n "$WORK/lib2.sh" 2>"$WORK/m_syntax" || \
  fail "the guard-removed mutant does not parse, so its silence is a syntax error rather than evidence: $(cat "$WORK/m_syntax")"
bash -c '. "$1" >/dev/null 2>&1' _ "$WORK/lib2.sh" || \
  fail "the guard-removed mutant does not source, so it never reached the loop under test"
if grep -q 'tap_submit_identity_guard' "$(printf '%s' "$WORK/lib2.sh")" && \
   ! bash -c '. "$1" >/dev/null 2>&1; declare -f tap_submit_identity_guard >/dev/null' _ "$WORK/lib2.sh"; then
  fail "the guard helper is undefined in the mutant; the probe would be measuring a missing function, not a removed call"
fi
out2="$(bash "$WORK/probe.sh" "$WORK/enters2" "$WORK/guards2" "$WORK/lib2.sh" 2>/dev/null | tail -1)"
[ -n "$out2" ] || fail "the guard-removed mutant produced no output at all; an empty result is not a negative result"
case "$out2" in
  rc=6*) fail "rc6 came back with EVERY guard removed ($out2) — the probe is not measuring the guard" ;;
esac
echo "driver-rc6-effect-probe: with no guard in the loop, rc6 is unreachable ($out2): ok"

echo "driver-rc6-effect-probe: ok"
