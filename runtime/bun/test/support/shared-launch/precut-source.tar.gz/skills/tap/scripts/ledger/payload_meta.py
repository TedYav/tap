"""Strict TAP payload metadata parser for fold.sh and is-converged.sh."""

from __future__ import annotations

import re
from pathlib import Path


ID_RE = re.compile(r"\A[A-Za-z0-9][A-Za-z0-9_.-]*\Z")


def parse_payload(path: str) -> tuple[str, str, dict[str, str]]:
    raw = Path(path).read_text()
    lines = raw.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ValueError("missing frontmatter")

    metadata: dict[str, str] = {}
    body_start = None
    for index, line in enumerate(lines[1:], 1):
        if line.strip() == "---":
            body_start = index + 1
            break
        if ":" in line:
            key, value = line.split(":", 1)
            metadata[key.strip()] = value.strip()

    if body_start is None:
        raise ValueError("unterminated frontmatter")

    payload_id = metadata.get("id", "")
    if not payload_id:
        raise ValueError("missing id")
    if not ID_RE.match(payload_id):
        raise ValueError(f"unsafe id {payload_id!r}")

    return payload_id, "\n".join(lines[body_start:]).strip(), metadata
