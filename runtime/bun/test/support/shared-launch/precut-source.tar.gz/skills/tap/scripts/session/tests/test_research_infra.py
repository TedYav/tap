"""Tests for research-run receipts and clean-pair registry (tap-b80p)."""

import json
from pathlib import Path
import pytest
import tempfile

from skills.tap.scripts.research.receipt import (
    ResearchRunReceipt,
    ModelEffortInfo,
    VerifierVerdict,
    ReceiptStore,
    ReplayHarness,
)
from skills.tap.scripts.research.clean_pair import (
    CleanPairRegistry,
    CleanPairCell,
    VerificationRequirement,
)


def test_model_effort_info_drift_detection():
    # No drift
    info = ModelEffortInfo(
        declared_model="gpt-5.6-sol",
        observed_model="gpt-5.6-sol",
        declared_effort="high",
        observed_effort="high",
    )
    assert info.detect_drift() == []

    # Model & effort drift
    info_drift = ModelEffortInfo(
        declared_model="gpt-5.6-sol",
        observed_model="gpt-5.6-turbo",
        declared_effort="high",
        observed_effort="medium",
    )
    drifts = info_drift.detect_drift()
    assert len(drifts) == 2
    assert "Model drift" in drifts[0]
    assert "Effort drift" in drifts[1]


def test_research_run_receipt_creation_and_validation():
    receipt = ResearchRunReceipt.create(
        prompt="Synthesize research findings on cross-agent protocol",
        frozen_source_ids=["src-1", "src-2"],
        live_source_ids=["src-3"],
        required_item_count=5,
        observed_item_count=5,
        declared_model="claude-3-5-sonnet",
        observed_model="claude-3-5-sonnet",
        declared_effort="high",
        observed_effort="high",
        harness="claude",
        claim_ids=["claim-1", "claim-2"],
        verifier_verdicts=[
            VerifierVerdict(
                verifier_id="v1",
                verifier_model="gpt-5.6-sol",
                verifier_family="openai",
                verdict="pass",
            )
        ],
        task_class="eval_synthesis",
        seat="sol",
        tier="frontier",
    )

    assert receipt.receipt_id.startswith("rrr-")
    assert receipt.is_clean() is True

    valid, errors = receipt.validate()
    assert valid is True
    assert errors == []


def test_receipt_validation_detects_truncation_and_drift():
    receipt = ResearchRunReceipt.create(
        prompt="Evaluate source attribution",
        frozen_source_ids=["src-1"],
        live_source_ids=[],
        required_item_count=10,
        observed_item_count=4,  # Truncated denominator
        declared_model="claude-3-5-sonnet",
        observed_model="claude-3-5-haiku",  # Drift
        declared_effort="high",
        observed_effort="low",  # Drift
        harness="claude",
        verifier_verdicts=[],  # Missing verifier
    )

    valid, errors = receipt.validate()
    assert valid is False
    assert any("Denominator truncation" in e for e in errors)
    assert any("Model drift" in e for e in errors)
    assert any("Effort drift" in e for e in errors)
    assert any("No verifier verdicts" in e for e in errors)
    assert receipt.is_clean() is False


def test_receipt_store_and_replay_harness(tmp_path):
    store = ReceiptStore(base_dir=tmp_path / "receipts")

    prompt = "Compare model reasoning trajectories"
    receipt = ResearchRunReceipt.create(
        prompt=prompt,
        frozen_source_ids=["f1"],
        live_source_ids=["l1"],
        required_item_count=2,
        observed_item_count=2,
        declared_model="opus-4",
        observed_model="opus-4",
        declared_effort="max",
        observed_effort="max",
        harness="claude",
        verifier_verdicts=[
            VerifierVerdict(
                verifier_id="v-opus",
                verifier_model="opus-4",
                verifier_family="anthropic",
                verdict="pass",
            )
        ],
    )

    saved_path = store.save(receipt)
    assert saved_path.exists()

    loaded = store.load(receipt.receipt_id)
    assert loaded is not None
    assert loaded.receipt_id == receipt.receipt_id
    assert loaded.prompt_hash == receipt.prompt_hash

    harness = ReplayHarness(store)

    # Valid replay check
    ok, errs = harness.replay_check(
        receipt.receipt_id,
        target_prompt=prompt,
        expected_sources=["f1", "l1"],
    )
    assert ok is True
    assert errs == []

    # Prompt mismatch
    ok, errs = harness.replay_check(
        receipt.receipt_id,
        target_prompt="Different prompt string",
    )
    assert ok is False
    assert any("prompt hash mismatch" in e for e in errs)


def test_clean_pair_registry_flow(tmp_path):
    registry_path = tmp_path / "clean_pair_registry.json"
    registry = CleanPairRegistry(storage_path=registry_path, min_n=2, max_age_seconds=3600)

    task_class = "code_review"
    seat = "grok"
    tier = "frontier"

    # Initially missing
    req = registry.check_requirement(task_class, seat, tier)
    assert req.requires_verification is True
    assert "missing" in req.reason

    # Create clean receipt 1
    r1 = ResearchRunReceipt.create(
        prompt="Review pull request #xxx",
        frozen_source_ids=["pr-123"],
        live_source_ids=[],
        required_item_count=3,
        observed_item_count=3,
        declared_model="grok-3",
        observed_model="grok-3",
        declared_effort="high",
        observed_effort="high",
        harness="cursor",
        verifier_verdicts=[
            VerifierVerdict(
                verifier_id="v1",
                verifier_model="sol",
                verifier_family="openai",
                verdict="pass",
            )
        ],
        task_class=task_class,
        seat=seat,
        tier=tier,
    )

    cell, accepted, reason = registry.consume_receipt(r1)
    assert accepted is True
    assert cell.n_verified == 1

    # Check requirement: n_verified (1) < min_n (2)
    req = registry.check_requirement(task_class, seat, tier)
    assert req.requires_verification is True
    assert "n_verified=1 < required min_n=2" in req.reason

    # Consume clean receipt 2
    r2 = ResearchRunReceipt.create(
        prompt="Review pull request #xxx",
        frozen_source_ids=["pr-124"],
        live_source_ids=[],
        required_item_count=3,
        observed_item_count=3,
        declared_model="grok-3",
        observed_model="grok-3",
        declared_effort="high",
        observed_effort="high",
        harness="cursor",
        verifier_verdicts=[
            VerifierVerdict(
                verifier_id="v1",
                verifier_model="sol",
                verifier_family="openai",
                verdict="pass",
            )
        ],
        task_class=task_class,
        seat=seat,
        tier=tier,
    )

    cell, accepted, reason = registry.consume_receipt(r2)
    assert accepted is True
    assert cell.n_verified == 2

    # Now clean and verified!
    req = registry.check_requirement(task_class, seat, tier)
    assert req.requires_verification is False
    assert "clean and verified" in req.reason


def test_clean_pair_registry_rejects_unclean_receipt(tmp_path):
    registry_path = tmp_path / "clean_pair_registry.json"
    registry = CleanPairRegistry(storage_path=registry_path)

    bad_receipt = ResearchRunReceipt.create(
        prompt="Bad run with failed verifier",
        frozen_source_ids=[],
        live_source_ids=[],
        required_item_count=5,
        observed_item_count=5,
        declared_model="claude-3-5-sonnet",
        observed_model="claude-3-5-sonnet",
        declared_effort="high",
        observed_effort="high",
        harness="claude",
        verifier_verdicts=[
            VerifierVerdict(
                verifier_id="v1",
                verifier_model="sol",
                verifier_family="openai",
                verdict="fail",
            )
        ],
        task_class="research",
        seat="opus",
        tier="frontier",
    )

    cell, accepted, reason = registry.consume_receipt(bad_receipt)
    assert accepted is False
    assert cell.n_verified == 0
    assert "rejected" in reason


import subprocess
import sys


def test_research_cli_script_mode_execution(tmp_path):
    cli_script = Path(__file__).resolve().parents[2] / "research" / "cli.py"
    store_dir = str(tmp_path / "research_store")
    # Test direct script-mode execution (`python3 cli.py --store-dir <tmp>`)
    res = subprocess.run(
        [
            sys.executable,
            str(cli_script),
            "--store-dir",
            store_dir,
            "receipt",
            "create",
            "--prompt",
            "Subprocess test prompt",
            "--required-items",
            "3",
            "--observed-items",
            "3",
            "--declared-model",
            "sol-1",
            "--observed-model",
            "sol-1",
            "--declared-effort",
            "high",
            "--observed-effort",
            "high",
            "--harness",
            "codex",
            "--verdict-pass",
        ],
        capture_output=True,
        text=True,
    )
    assert res.returncode == 0, f"Script mode execution failed: {res.stderr}"
    data = json.loads(res.stdout)
    assert data["status"] == "created"
    receipt_id = data["receipt_id"]

    # Validate created receipt via script mode
    res_val = subprocess.run(
        [sys.executable, str(cli_script), "--store-dir", store_dir, "receipt", "validate", receipt_id],
        capture_output=True,
        text=True,
    )
    assert res_val.returncode == 0, f"Script mode validation failed: {res_val.stderr}"
    val_data = json.loads(res_val.stdout)
    assert val_data["ok"] is True
    assert val_data["is_clean"] is True


def test_research_cli_module_mode_execution(tmp_path):
    repo_root = Path(__file__).resolve().parents[5]
    import os

    env = dict(os.environ)
    env["PYTHONPATH"] = str(repo_root)
    env["TAP_RESEARCH_STORE_DIR"] = str(tmp_path / "research_store")

    res = subprocess.run(
        [
            sys.executable,
            "-m",
            "skills.tap.scripts.research.cli",
            "registry",
            "check",
            "--task-class",
            "eval",
            "--seat",
            "sol",
            "--tier",
            "frontier",
        ],
        cwd=repo_root,
        env=env,
        capture_output=True,
        text=True,
    )
    # Exits 2 because cell is missing from fresh registry
    assert res.returncode == 2, f"Module mode check failed: {res.stderr}"
    data = json.loads(res.stdout)
    assert data["requires_verification"] is True
    assert "missing" in data["reason"]


