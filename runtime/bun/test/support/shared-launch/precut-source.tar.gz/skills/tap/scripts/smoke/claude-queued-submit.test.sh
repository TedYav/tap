#!/usr/bin/env bash
# tap-maavp U1: a Claude delivered-but-unconsumed message parks as an indented
# prompt row above the active box fence. The Bash transition door must accept
# the real staged -> queued turn (rc 7) on exactly one owned Enter, never send
# a clear key for it; the preexisting-queue arm below is a lower-level
# zero-key observation, not the rejection proof (that is the native
# paneState-gate test in submit-frame.test.ts).
# Run through smoke-all --only; all pane operations below are a file-backed mock.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
export TAP_HOME="$WORK/bus" TAP_INDEX_HOME="$WORK/index"
export TAP_SPOOL_DISABLE_DELIVERER=1 TAP_TUI_SETTLE_SCALE=0
. "$ROOT/skills/tap/scripts/lib.sh"
tap_ensure_dirs
QUEUED="$ROOT/skills/tap/scripts/smoke/fixtures/submit-verify/claude-queued-live-draft-claudebar.ansi"
FRAME="$WORK/frame"
failures=0
bad() { echo "claude-queued-submit: FAIL $*" >&2; failures=$((failures + 1)); }
sentinel='[[TAP v0.23 note luna-moderator-20260918T085028Z-f75f1bd3af66 preview="Correction to my custody update: Astra independently verified all four SuiteSplit4 compute jobs are terminal/pass; they"]]'
# The pre-Enter frame is the captured queued-row state with THIS attempt's wire
# staged in the composer (glyph + NBSP + paint reset + draft text). After the
# owned Enter the live pane shows the same capture with the wire queued above
# the fence and the human draft back in the composer.
python3 -B - "$QUEUED" "$WORK/staged-frame" "$sentinel" <<'PY'
from pathlib import Path
import sys
s = Path(sys.argv[1]).read_text()
old = '\u00a0\x1b[39mCom'
assert old in s
Path(sys.argv[2]).write_text(s.replace(old, '\u00a0\x1b[39m' + sys.argv[3]))
PY
# Identity is a fixed premise in this transition control. Production capture,
# classification, phase evidence and the door's Enter loop remain in use.
tap_submit_identity_guard() { return 0; }
tap_bound_pane_identity_state() { printf match; }
tap_pane_harness_command() { printf claude; }
tap_pane_alive() { printf '%%7'; }
tap_settle() { printf 'settle:%s\n' "$1" >> "$WORK/keys"; }
tap_pane_effect_flash_body() { printf 'flash\n' >> "$WORK/keys"; }
# The transition door's Bun classifier consumes captured bytes only, but the
# door itself spawns the LITERAL tmux binary through PATH, so the mock is a
# PATH script (same shape as draft-submit-boundary): after the owned Enter the
# frame becomes the captured queued-row state.
export TAP_MOCK_WORK="$WORK" TAP_MOCK_FRAME="$FRAME" TAP_MOCK_QUEUED="$QUEUED"
mkdir -p "$WORK/bin"
cat > "$WORK/bin/tmux" <<'MOCK'
#!/usr/bin/env bash
set -u
WORK="${TAP_MOCK_WORK:?}" FRAME="${TAP_MOCK_FRAME:?}" QUEUED="${TAP_MOCK_QUEUED:?}"
case "$1" in
  capture-pane)
    case " $* " in
      *' -e '*) cat "$FRAME" ;;
      *) python3 -B - "$FRAME" <<'PY'
import re,sys
print(re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',re.sub(r'\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)','',open(sys.argv[1]).read())),end='')
PY
      ;;
    esac ;;
  display-message)
    case "${@: -1}" in
      *pane_in_mode*) printf '0\n' ;;
      *pane_id*pane_current_command*) printf '%%7\tsess\t4242\tclaude\n' ;;
      *pane_id*session_name*) printf '%%7\tsess\t4242:100\n' ;;
      *'#{pid}:#{start_time}'*) printf '4242:100\n' ;;
      *pane_id*) printf '%%7\n' ;;
      *pane_current_command*) printf 'claude\n' ;;
      *pane_width*) printf '238\n' ;;
      *) printf 'sess\n' ;;
    esac ;;
  send-keys)
    printf '%s\n' "$*" >> "$WORK/keys"
    case "${@: -1}" in
      Enter)
        n=$(( $(cat "$WORK/enters") + 1 )); printf '%s' "$n" > "$WORK/enters"
        cp "$QUEUED" "$FRAME" ;;
      C-u|BSpace) : > "$FRAME" ;;
      *) case " $* " in *' -l '*) printf '%s\n' "${@: -1}" >> "$FRAME" ;; esac ;;
    esac ;;
  *) exit 0 ;;
esac
MOCK
chmod +x "$WORK/bin/tmux"
export PATH="$WORK/bin:$PATH"

verify() {
  rc=0
  tap_submit_existing_verify %7 claude claude-queued-submit 0 id '' '' '' 6 '' '' "$sentinel" \
    > "$WORK/verify.log" 2>&1 || rc=$?
}
reset_frame() {
  cp "$1" "$FRAME"
  printf 0 > "$WORK/enters"
  : > "$WORK/keys"
}

# The real staged -> queued transition: the wire sits in the composer, the door
# proves it landed with one owned Enter, and the captured post-Enter frame
# shows the indented queue row over a live human draft (Claude Bar footer, no
# esc-to-interrupt chrome). Acceptance is rc 7 on that one Enter alone.
reset_frame "$WORK/staged-frame"
verify
[ "$rc" = 7 ] || { cat "$WORK/verify.log" >&2; bad "staged -> queued transition returned $rc"; }
[ "$(cat "$WORK/enters")" = 1 ] || bad 'queued transition did not send exactly one owned Enter'
[ "$(grep -c Enter "$WORK/keys")" = 1 ] || bad 'queued transition logged more than one Enter key'
grep -qE 'C-u|BSpace| -l ' "$WORK/keys" && bad 'queued transition sent a clear or inject key' || :
grep -q flash "$WORK/keys" && bad 'queued transition ran the fused clobber flash' || :

# Lower-level door observation, NOT the preexisting-queue rejection proof: rc 7
# is the accepted harness-queue disposition, so this arm only records that a
# frame already showing the queue classifies queued/working and spends zero
# keys at the door. The rejection proof lives in the native public-gate test
# (submit-frame.test.ts): the paneState gate refuses the attempt with no
# inject and no Enter before the door is ever reached.
reset_frame "$QUEUED"
verify
[ "$rc" = 7 ] || { cat "$WORK/verify.log" >&2; bad "preexisting queued frame returned $rc"; }
[ "$(cat "$WORK/enters")" = 0 ] || bad 'preexisting queued frame received an Enter'
grep -q Enter "$WORK/keys" && bad 'preexisting queued frame logged an Enter key' || :
grep -qE 'C-u|BSpace| -l ' "$WORK/keys" && bad 'preexisting queued frame sent a clear or inject key' || :

[ "$failures" = 0 ] || exit 1
echo 'claude-queued-submit: staged -> queued turn is owned-Enter verified; door spends no keys on a preexisting queue'
