#!/usr/bin/env bash
# lib.sh — shared TAP primitives (sourced by every tap-*.sh).
# TAP is the transport: dumb bus + deterministic tmux courier, zero liveness
# cybernetics. This file owns ONLY mechanical primitives — paths, atomic writes,
# id minting, envelope-shape parsing. It interprets no `kind` values and holds no
# timers/leases/watchdog/"peer is working" logic. (See CONTRACT.md.)

. "$(dirname "${BASH_SOURCE[0]}")/python-runtime.sh"

# --- text encoding (tap-bg19) -------------------------------------------------
# Every pane-reading primitive matches multi-byte glyphs (the ❯/› prompt marks,
# box borders, harness chrome) with sed/awk bracket expressions. Those match BYTES
# in the C/POSIX locale and CHARACTERS only in a UTF-8 one, so an unset LANG makes
# a 3-byte glyph strip down to 1 byte and leave 2 bytes of residue — which the
# readiness gate then reads as typed human input and parks every delivery as
# `pending-input`. That is not hypothetical: a launchd-started tmux server
# inherits no interactive shell environment, so its panes ran with LANG unset and
# push delivery stopped fleet-wide until this line existed. tap therefore pins its
# own text locale instead of trusting the caller's: correctness here cannot be an
# environment coincidence. Only LC_CTYPE is pinned (character classification, the
# single thing this affects) so user collation/time/number formats are untouched.
if [ -z "${TAP_SKIP_LOCALE_PIN:-}" ]; then
  # POSIX precedence is LC_ALL > LC_CTYPE > LANG, so a caller carrying LC_ALL=C
  # would silently defeat a bare LC_CTYPE pin — the same environment-coincidence
  # this block exists to end. Preserve what LC_ALL was expressing for every OTHER
  # category, then clear it so the ctype pin can take effect.
  if [ -n "${LC_ALL:-}" ]; then
    : "${LC_COLLATE:=$LC_ALL}" "${LC_MONETARY:=$LC_ALL}" "${LC_NUMERIC:=$LC_ALL}"
    : "${LC_TIME:=$LC_ALL}" "${LC_MESSAGES:=$LC_ALL}"
    export LC_COLLATE LC_MONETARY LC_NUMERIC LC_TIME LC_MESSAGES
    _tap_ctype="$LC_ALL"
    unset LC_ALL
  else
    _tap_ctype="${LC_CTYPE:-}"
  fi
  # ANY UTF-8 ctype already gives character-wise matching, which is all tap needs,
  # so a caller who chose ja_JP.UTF-8 keeps it. Only an absent or non-UTF-8 ctype
  # is replaced — pin the capability, never the caller's language.
  case "$_tap_ctype" in
    *[Uu][Tt][Ff]8*|*[Uu][Tt][Ff]-8*) export LC_CTYPE="$_tap_ctype" ;;
    *)                                export LC_CTYPE="${TAP_LC_CTYPE:-en_US.UTF-8}" ;;
  esac
  unset _tap_ctype
fi

# --- presentation primitives (Wave 1 style.sh) --------------------------------
_TAP_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
if [ "${TAP_VERBOSE:-}" = 1 ]; then
  # Source with no arguments: leaf arguments are owned by the leaf parser.
  source "$_TAP_SCRIPT_DIR/verbose.sh" --
fi
[ -f "$_TAP_SCRIPT_DIR/style.sh" ] && source "$_TAP_SCRIPT_DIR/style.sh"
tap_style_init 2  # stderr fd

# Shared runtime boundary for migrated decisions. Callers validate the returned
# shape; this helper reports runtime failures and never falls back to Bash policy.
tap_bun_call() { # <slice> <id> <module-relative-to-runtime/bun/src> [<args>...]
  local slice="$1" id="$2" module="$3" bun_bin
  shift 3
  bun_bin="$(command -v bun)" || {
    printf 'tap: runtime_missing id=%s slice=%s: install bun\n' "$id" "$slice" >&2
    return 1
  }
  "$bun_bin" "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/$module" "$@" || {
    printf 'tap: slice_failed id=%s slice=%s: classification failed\n' "$id" "$slice" >&2
    return 1
  }
}

# Shared inbox rows, with no Bash presentation fallback.
tap_slice_inbox_view() { # <actor>; one JSON facts object on stdin
  local rows
  rows="$(tap_bun_call inbox-view "$1" slices/inbox-view.ts)" || return 1
  printf '%s' "$rows" | python3 -B -c 'import json,sys
r=json.load(sys.stdin)
assert isinstance(r,list) and all(isinstance(x,dict) and isinstance(x.get("item"),dict) and isinstance(x.get("human"),str) and isinstance(x.get("warnings"),str) for x in r)
print(json.dumps(r,separators=(",",":")))' || {
    printf 'tap: slice_failed id=%s slice=inbox-view: invalid rows\n' "$1" >&2
    return 1
  }
}

# Message construction for `tap send` (D1): one Bun module both doors call.
# Runs one operation — parse / check / stage / wrap / obligation — and loads its result, a
# NUL-delimited key/value stream in tap-send.sh's OWN variable names, straight
# into this shell. No decision lives here: a refusal the module computed is
# raised through tap_fail with the module's bytes, a deferred refusal waits in
# `_MC_*` variables for the site the incumbent raised it at, and a missing or
# unreadable result is `slice_failed` — an infrastructure failure never reads as
# a verdict. stdin is inherited, which is how `stage` reads `-f -`.
# Read a slice's result carrier back into shell variables: NUL-separated
# `key\0value\0` pairs (runtime/bun/src/slices/result-pairs.ts is the one
# encoder), closed by the reserved completion pair `_TAP_PAIRS_END\0end\0`.
# The whole stream is read first and judged as a unit: a partial trailing
# field, an odd field count, a key that is not a variable name (a leading digit
# included), a duplicate key, a missing sentinel, or any pair after it is the
# slice's failure, named after <what> — a complete positive PREFIX of a cut
# stream must never read as a shorter positive result (sol-pinnacle-4, D2-u1).
# Only then are the variables assigned. _TAP_PAIRS_SEEN lists the keys read,
# space-separated and space-bounded, so an adapter can require its schema.
# The file is removed.
tap_bun_read_pairs() { # <result-file> <what>
  local _rp_file="$1" _rp_what="$2" _rp_field _rp_i _rp_key _rp_n=0 _rp_rc=0
  local -a _rp_fields=()
  _TAP_PAIRS_SEEN=" "
  while IFS= read -r -d '' _rp_field; do
    _rp_fields+=("$_rp_field")
  done < "$_rp_file" || _rp_rc=$?
  # `read -d ''` returns nonzero at EOF; a nonempty partial field then means
  # the stream ended without its NUL — a cut, not a pair.
  rm -f "$_rp_file"
  [ -z "$_rp_field" ] || tap_fail 1 slice_failed "tap doctor" "$_rp_what returned a truncated result"
  _rp_n=${#_rp_fields[@]}
  [ "$_rp_n" -ge 2 ] || tap_fail 1 slice_failed "tap doctor" "$_rp_what returned no result"
  [ $((_rp_n % 2)) -eq 0 ] || tap_fail 1 slice_failed "tap doctor" "$_rp_what returned a truncated result"
  [ "${_rp_fields[$((_rp_n - 2))]}" = "_TAP_PAIRS_END" ] && [ "${_rp_fields[$((_rp_n - 1))]}" = "end" ] \
    || tap_fail 1 slice_failed "tap doctor" "$_rp_what returned an unterminated result"
  _rp_i=0
  while [ "$_rp_i" -lt $((_rp_n - 2)) ]; do
    _rp_key="${_rp_fields[$_rp_i]}"
    case "$_rp_key" in
      _TAP_PAIRS_END) tap_fail 1 slice_failed "tap doctor" "$_rp_what returned a malformed result (sentinel not last)" ;;
      ''|[0-9]*|*[!A-Za-z0-9_]*) tap_fail 1 slice_failed "tap doctor" "$_rp_what returned a malformed key" ;;
    esac
    case "$_TAP_PAIRS_SEEN" in
      *" $_rp_key "*) tap_fail 1 slice_failed "tap doctor" "$_rp_what returned a duplicate key" ;;
    esac
    _TAP_PAIRS_SEEN="$_TAP_PAIRS_SEEN$_rp_key "
    _rp_i=$((_rp_i + 2))
  done
  [ "$_rp_n" -gt 2 ] || tap_fail 1 slice_failed "tap doctor" "$_rp_what returned no result"
  _rp_i=0
  while [ "$_rp_i" -lt $((_rp_n - 2)) ]; do
    printf -v "${_rp_fields[$_rp_i]}" '%s' "${_rp_fields[$((_rp_i + 1))]}"
    _rp_i=$((_rp_i + 2))
  done
}

# Require that the last carrier read carried every key named; an adapter whose
# outputs license anything (authorization, a stamped field) calls this before
# consulting them, so a syntactically complete but partial schema cannot.
tap_bun_require_pairs() { # <what> <key>...
  local _rq_what="$1" _rq_key
  shift
  for _rq_key in "$@"; do
    case "$_TAP_PAIRS_SEEN" in
      *" $_rq_key "*) ;;
      *) tap_fail 1 slice_failed "tap doctor" "$_rq_what returned an incomplete result (missing $_rq_key)" ;;
    esac
  done
}

tap_bun_construct() { # <op> [<args>...]
  local _mc_op="$1" _mc_result
  shift
  _mc_result="$(mktemp "${TMPDIR:-/tmp}/tap-construct.XXXXXX")" \
    || tap_fail 1 slice_failed "tap doctor" "could not allocate a construction result for $_mc_op"
  unset _MC_REFUSAL_CODE _MC_REFUSAL_CLASS _MC_REFUSAL_ACTION _MC_REFUSAL_DETAIL _MC_REFUSAL_JSON
  if ! tap_bun_call message-construction "$_mc_op" slices/message-construction.ts "$_mc_op" --result "$_mc_result" -- "$@"; then
    rm -f "$_mc_result"
    tap_fail 1 slice_failed "tap doctor" "message construction ($_mc_op) did not complete, so nothing was sent; resolve the runtime and retry"
  fi
  tap_bun_read_pairs "$_mc_result" "message construction ($_mc_op)"
  if [ -n "${_MC_REFUSAL_CLASS:-}" ]; then
    [ "${_MC_REFUSAL_JSON:-0}" != 1 ] || TAP_JSON=1
    tap_fail "${_MC_REFUSAL_CODE:-1}" "$_MC_REFUSAL_CLASS" "$_MC_REFUSAL_ACTION" "$_MC_REFUSAL_DETAIL"
  fi
}

# One payload address resolver, every door. Callers select on the status token
# and refuse anything they do not recognize; the adapter decides nothing.
tap_payload_resolve() { # <arg> <bus> <index> <mode> [<explicit>] [<actor>]
  tap_bun_call payload-resolve "$1" payload-view.ts resolve "$1" "$2" "$3" "$4" "${5:-}" "${6:-}"
}

# Work-order shape, decided in ONE place (tap-oglkh, tap-dk19b). Three answers,
# not two: "not an order" LICENSES an ordinary send, so the instrument must be
# able to say "I could not tell" distinctly from "no"
# (.claude/rules/licensing-zero-needs-a-refusable-instrument.md). 0 shaped,
# 1 not shaped, 2 no answer — the caller decides what a 2 means.
#
# The verdict is the TOKEN, never the exit status. A module that fails to load
# exits 1, which is the same status a computed "no" would have used, so a status
# convention cannot separate a broken classifier from a negative verdict — it
# reads as "send it". A token cannot be printed by a process that did not run,
# so anything but a recognized token is no answer: a non-zero status, empty
# output, extra output, or an unknown word.
tap_slice_order_shaped() { # <payload>
  local bun_bin verdict rc=0
  bun_bin="$(command -v bun)" || return 2
  verdict="$("$bun_bin" "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/slices/order-shape.ts" "$1")" || rc=$?
  [ "$rc" = 0 ] || return 2
  case "$verdict" in
    order-shape:shaped)     return 0 ;;
    order-shape:not-shaped) return 1 ;;
    *)                      return 2 ;;
  esac
}

# Observe one frame; Bun owns the band/disposition interpretation.
tap_slice_delivery_disposition() { # <pane> <harness> <urgent> <no-spool> <bound> <siblings> <id>
  local frame composer escaped glyph present=1 facts decision
  frame="$(tap_capture_input_frame "$1" "$2" 1)" || present=0
  case "$2" in
    hermes*) composer="$(tap_pending_input_text "$1" "$2" "$frame")" || present=0 ;;
    *) composer="$(printf '%s' "$frame" | tap_composer_input "$2")" || present=0 ;;
  esac
  if [ "$2" = agy ] && printf '%s' "$frame" | tap_strip_ansi | tap_agy_permission_overlay; then present=0; fi
  # Admit recognized survey chrome to the locked recovery stage; no key here.
  if [ "$2" = agy ] && printf '%s' "$frame" | tap_agy_survey_overlay; then
    if [ "$(printf '%s' "$frame" | tap_bun_call agy-survey-admission frame agy-survey.ts)" = recoverable ]; then present=1; composer="";
    else present=0; fi
  fi
  if [ -n "$composer" ]; then
    escaped="$(printf '%s' "$frame" | tap_escaped_prompt_from_frame "$2")"
    glyph="$(tap_prompt_glyph_re "$2")"
    # `! tap_text_has_paste_collapse` reads rc 2 ("could not read") as "no chip"
    # and blanks the composer, which is the inject-eligible direction: an
    # unreadable chip check would become idle-band evidence. Only a positive
    # rc 1 may blank it.
    if tap_dim_prompt_input "$composer" "$escaped" "$glyph" "$2"; then
      local _pn_chip_rc=0
      tap_text_has_paste_collapse "$2" "$composer" || _pn_chip_rc=$?
      if [ "$_pn_chip_rc" -eq 1 ]; then composer=""; fi
    fi
  fi
  facts="$(python3 -B -c 'import json,sys; print(json.dumps(dict(composer=sys.argv[1] if sys.argv[2]=="1" else None, frame=sys.argv[3], harness=sys.argv[4], urgent=sys.argv[5]=="1", noSpool=sys.argv[6]=="1", recipientBound=sys.argv[7]=="1", siblingsQueued=int(sys.argv[8]))))' "$composer" "$present" "$frame" "$2" "$3" "$4" "$5" "$6")" || return 1
  decision="$(printf '%s' "$facts" | tap_bun_call delivery-disposition "$7" slices/delivery-disposition.ts)" || return 1
  printf '%s' "$decision" | python3 -B -c 'import json,sys; d=json.load(sys.stdin)
if not isinstance(d,dict) or d.get("action") not in ("inject","park"):
    raise SystemExit("invalid delivery action")
print(json.dumps(d))' || {
    printf 'tap: slice_failed id=%s slice=delivery-disposition: invalid decision\n' "$7" >&2
    return 1
  }
}

# Bound ordinary clients, never the server. Preserve an injected function: it
# may own private-socket routing, which replacing it would silently discard.
#
# A caller-injected `tmux` may route to a private socket that only this shell can
# reach, and a Bun child cannot call a shell function — it selects a server only
# through TAP_TMUX_SOCKET_PATH, TAP_TMUX_SOCKET or ambient TMUX. A native
# observer that cannot reach the SAME server the effect will land on must refuse
# rather than answer about a different one (sol-pinnacle-2, #xxxx).
if ! declare -F tmux >/dev/null; then
  tmux() { python3 -B "$_TAP_SCRIPT_DIR/tmux_deadline.py" "$@"; }
  # The BODY, captured at definition, is the authority — not a boolean. A flag
  # records who defined the function at SOURCE TIME and keeps saying so after
  # someone replaces it, which is half the defect it was meant to prevent
  # (astra-pinnacle-reviewer, #xxxx P1).
  _TAP_TMUX_BODY="$(declare -f tmux)"
fi

# 0 only when the `tmux` function IN SCOPE RIGHT NOW is the one TAP defined, and
# therefore honors the same TAP_TMUX_SOCKET* selection the Bun child honors.
#
# AN ENVIRONMENT PIN IS NOT EVIDENCE ABOUT A FOREIGN FUNCTION. A pin says where
# the CHILD will go; it says nothing about where a caller's own function goes,
# and the two disagreeing is exactly the server-mismatch this refusal exists to
# catch. Measured: a foreign function routing to server B with a pin naming
# server A produced a FALSE ACTIVE — the guard authorized against a pane it had
# never looked at. The first version of this predicate accepted that case, and
# the arm written to prove the guard worked encoded the same wrong assumption
# instead of testing route agreement.
tap_tmux_router_representable() {
  [ -n "${_TAP_TMUX_BODY:-}" ] || return 1
  [ "$(declare -f tmux)" = "$_TAP_TMUX_BODY" ]
}

# --- bus location (R19 resolution chain) --------------------------------------
# The bus resolves in ONE place, in this order, recording which rule chose it in
# TAP_BUS_RULE (surfaced by `doctor` and `whoami --verbose`):
#   1. TAP_HOME env set       -> use it verbatim  (rule=env; custom homes are
#                                unindexable in the machine index — U8)
#   2. <repo>/.tap/bus exists -> the v0.3 layout   (rule=dotdir)
#   3. <repo>/tmp/tap exists  -> legacy v0.2 layout (rule=legacy; deprecation
#                                window, closes when the last legacy-named deployments migrate)
#   4. neither                -> default to <repo>/.tap/bus (rule=default; created
#                                on demand by tap_ensure_dirs)
# Split-brain is impossible by construction: while a non-empty legacy tmp/tap
# exists, rule=legacy keeps using it and tap_ensure_dirs refuses to bootstrap a
# fresh .tap/bus (R23) — only `tap init` migrates.
_tap_repo_root() { git rev-parse --show-toplevel 2>/dev/null || pwd; }
if [ -n "${TAP_HOME:-}" ]; then
  TAP_BUS_RULE="env"
else
  _tap_root="$(_tap_repo_root)"
  if [ -d "$_tap_root/.tap/bus" ]; then
    TAP_HOME="$_tap_root/.tap/bus"; TAP_BUS_RULE="dotdir"
  elif [ -d "$_tap_root/tmp/tap" ]; then
    TAP_HOME="$_tap_root/tmp/tap"; TAP_BUS_RULE="legacy"
  else
    TAP_HOME="$_tap_root/.tap/bus"; TAP_BUS_RULE="default"
  fi
fi
export TAP_BUS_RULE
# Step 1 — syntactic absolutization: prepend $PWD when TAP_HOME is relative.
# This works even when the directory does not exist yet (created later by
# tap_ensure_dirs).  A no-op for paths that already start with /.  Bash-3.2 portable.
case "$TAP_HOME" in
  /*) : ;;                         # already absolute — nothing to do
  *)  TAP_HOME="$PWD/$TAP_HOME" ;; # make relative absolute without needing the dir
esac
# Step 2 — trim trailing separators before shape checks and derived paths. Keep
# the filesystem root as /; the loop is Bash-3.2 portable.
while [ "$TAP_HOME" != "/" ] && [ "${TAP_HOME%/}" != "$TAP_HOME" ]; do
  TAP_HOME="${TAP_HOME%/}"
done
# Step 3 — optional canonicalization: resolve symlinks / .. components if the dir
# already exists.  cd + pwd -P is Bash-3.2 portable.  The printf fallback returns
# the normalized absolute value for a fresh (not-yet-created) bus directory.
TAP_HOME="$(cd "$TAP_HOME" 2>/dev/null && pwd -P || printf '%s' "$TAP_HOME")"
TAP_PAYLOADS="$TAP_HOME/payloads"
TAP_RECEIPTS="$TAP_HOME/receipts"
TAP_REGISTRY="$TAP_HOME/registry.json"
TAP_INPUT_BACKUPS="$TAP_HOME/input-backups"
TAP_REGISTRY_EVENTS="$TAP_HOME/registry-events.log"
TAP_SPOOL="$TAP_HOME/spool"
if [ "${TAP_VERBOSE:-}" = 1 ]; then
  python3 -B "$_TAP_SCRIPT_DIR/verbose.py" state "$TAP_REGISTRY" "$TAP_PAYLOADS" "$TAP_RECEIPTS" "$TAP_SPOOL"
fi
# shellcheck disable=SC2034  # used by tap-watch.sh, which sources this file
TAP_WATCH_LOGS="$TAP_HOME/watch/evaluator-prompts"
# shellcheck disable=SC2034  # used by the self compact submitters, which source this file
TAP_HANDOFF="$TAP_HOME/handoff"

# Reset decisions and writes live in reset.ts. These adapters carry shell state
# and real child statuses; tap_bun_call would collapse the refusal statuses.
_tap_reset_fence_native() {
  local mode="$1"; shift
  TAP_JSON="${TAP_JSON:-0}" bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/reset.ts" "$mode" "$TAP_HOME" "$@" --verb "${TAP_VERB:-tap}"
}
tap_reset_fence_path() { printf '%s/reset.fence.json' "$TAP_HOME"; }
tap_reset_fence_present() { [ -f "$(tap_reset_fence_path)" ]; }

tap_reset_fence_guard() {
  local what="${1:-this operation}" rc=0
  tap_reset_fence_present || return 0
  _tap_reset_fence_native guard --what "$what" || rc=$?
  [ "$rc" -ne 127 ] || tap_fail 1 runtime_missing "install bun" \
    "refusing $what — team bus is mid-reset (fence at $(tap_reset_fence_path)) and the fence engine could not run"
  [ "$rc" -eq 0 ] || exit "$rc"
}

tap_reset_generation_mark_reused() { _tap_reset_fence_native mark-reused --why "${1:-mutation}"; }

# Guard a bus other than $TAP_HOME (cross-team send recipient).
tap_reset_fence_guard_bus() { # <bus_home> <what>
  local bus="$1" what="${2:-this operation}" saved="$TAP_HOME"
  [ -n "$bus" ] || return 0
  TAP_HOME="$bus"
  tap_reset_fence_guard "$what"
  TAP_HOME="$saved"
}

# First post-reset mutation marks the one-use generation guard reused (design 328-334).
tap_reset_generation_touch() { # <why>
  tap_reset_generation_mark_reused "${1:-mutation}"
}

# Touch generation on a foreign bus (cross-worktree done --payload writes the
# receipt under the sender bus). Restore TAP_HOME even on failure (sol 053713).
tap_reset_generation_touch_bus() { # <bus_home> <why>
  local bus="$1" why="${2:-mutation}" saved="$TAP_HOME" rc=0
  [ -n "$bus" ] || return 0
  TAP_HOME="$bus"
  tap_reset_generation_touch "$why" || rc=$?
  TAP_HOME="$saved"
  return "$rc"
}

# tap_write_dotdir_gitignore <dotdir> — write the self-ignoring .tap/.gitignore
# (the .beads/ pattern): the ephemeral bus never lands in git; .tap/config does.
# Public so `tap init` (U7) can call it when it bootstraps/migrates the layout.
tap_write_dotdir_gitignore() {
  local dotdir="$1"
  mkdir -p "$dotdir"
  cat > "$dotdir/.gitignore" <<'GI'
# TAP bus — ephemeral, machine-local runtime state (payloads, receipts, registry,
# input backups). Never committed. `.tap/config` IS committed.
bus/
GI
}

# tap_require_bus_root — refuse a resolved container instead of building a
# second, internally consistent bus beneath it.
#
# Explicit custom TAP_HOME values are a documented layout and may bootstrap, so
# absence of a registry is not proof that an arbitrary path is wrong. Container
# shapes ARE proof: a .tap or legacy tmp container, a path that already contains
# a canonical bus, or a git worktree root. Check shape before any mkdir. A
# parent-side registry is deliberately not an escape hatch because it does not
# identify the bus itself.
tap_require_bus_root() {
  local expected="" repo_root=""
  case "$TAP_HOME" in
    */.tap/bus|*/tmp/tap) return 0 ;;
  esac
  case "$TAP_HOME" in
    */.tap) expected="$TAP_HOME/bus" ;;
    *)
      if [ -d "$TAP_HOME/.tap/bus" ]; then
        expected="$TAP_HOME/.tap/bus"
      elif [ -d "$TAP_HOME/tmp/tap" ]; then
        expected="$TAP_HOME/tmp/tap"
      else
        case "$TAP_HOME" in
          */tmp)
            if [ -d "$TAP_HOME/tap" ]; then
              expected="$TAP_HOME/tap"
            fi
            ;;
        esac
      fi
      if [ -z "$expected" ] && [ -d "$TAP_HOME" ]; then
        repo_root="$(git -C "$TAP_HOME" rev-parse --show-toplevel 2>/dev/null || true)"
        repo_root="$(cd "$repo_root" 2>/dev/null && pwd -P || printf '%s' "$repo_root")"
        [ -n "$repo_root" ] && [ "$repo_root" = "$TAP_HOME" ] \
          && expected="$TAP_HOME/.tap/bus"
      fi
      ;;
  esac
  [ -z "$expected" ] && return 0
  tap_fail 1 not_a_bus "unset TAP_HOME or point it at the bus dir" \
    "TAP_HOME='$TAP_HOME' does not name a bus; expected '$expected'"
}

# tap_ensure_dirs — validate the resolved bus, then create payloads/ + receipts/
# on demand. Ordinary payload/receipt writers cross this boundary before their
# first payload/receipt/tmp write.
# R23 guard: NEVER bootstrap a fresh .tap/bus while a non-empty legacy tmp/tap still
# holds live state — that would split the bus across two locations. `tap init` is the
# ONLY sanctioned migrator; it sets TAP_MIGRATING=1 to bypass this guard. When
# creating the .tap/ layout, also write the self-ignoring .tap/.gitignore.
tap_ensure_dirs() {
  tap_require_bus_root
  case "$TAP_HOME" in
    */.tap/bus)
      if [ ! -d "$TAP_HOME" ] && [ -z "${TAP_MIGRATING:-}" ]; then
        local _legacy="${TAP_HOME%/.tap/bus}/tmp/tap"
        if [ -d "$_legacy" ] && [ -n "$(ls -A "$_legacy" 2>/dev/null)" ]; then
          tap_fail 1 legacy_bus "tap init" "refusing to create $TAP_HOME while a non-empty legacy bus exists at $_legacy — run 'tap init' to migrate (it moves payloads/receipts/registry and closes the split)."
        fi
      fi
      mkdir -p "$TAP_PAYLOADS" "$TAP_RECEIPTS"
      [ -f "${TAP_HOME%/bus}/.gitignore" ] || tap_write_dotdir_gitignore "${TAP_HOME%/bus}" ;;
    *)
      mkdir -p "$TAP_PAYLOADS" "$TAP_RECEIPTS" ;;
  esac
  # tap-ncd4: stamp this bus as genuinely bootstrapped. Every real bus —
  # canonical or a supported custom home alike — passes through here before
  # its first write, so this is a one-time, no-operator-action authority
  # marker that tap_spool_home_authorized checks before any pane effect.
  #
  # NOT `|| true`: draining now DEPENDS on this marker existing (tap-ncd4
  # round 3, sol-pinnacle). A `|| true` here was defensible when the marker
  # was decorative; it is not defensible now — it would let setup report
  # success (mkdir -p above can succeed on a writable payloads/receipts pair
  # even when the bus ROOT itself is not writable) while every future
  # redelivery attempt on this bus refuses forever as "never bootstrapped".
  # A send parking successfully on a bus its own deliverer will refuse is
  # exactly the silent-setup-then-failed-delivery shape this fix exists to
  # end, not reintroduce one level up.
  local _authority="$TAP_HOME/${TAP_SPOOL_HOME_AUTHORITY_MARKER:-.tap-bus-authority}"
  [ -f "$_authority" ] || printf 'bootstrapped_at_epoch=%s\n' "$(date +%s)" >"$_authority" \
    || tap_fail 1 bus_authority_unwritable "fix TAP_HOME's own permissions, not just its children" \
      "could not write $_authority — a bus whose root cannot be stamped will accept sends now and silently refuse to redeliver them later"
}

# --- fail loud ----------------------------------------------------------------
tap_error_line() { # <error_class> <action> [detail]
  local klass="$1" action="$2" detail="${3:-}" verb="${TAP_VERB:-tap}"
  local human_detail="$detail" human_action="$action"
  human_detail="${human_detail//$'\n'/ }"
  human_detail="${human_detail//$'\r'/ }"
  human_action="${human_action//$'\n'/ }"
  human_action="${human_action//$'\r'/ }"
  [ -n "$human_detail" ] || human_detail="${klass//_/ }"
  case "$human_action" in
    *' '*|*/*) ;;
    *) human_action="${human_action//_/ }" ;;
  esac
  printf '%s: %s; next: %s\n' "$verb" "$human_detail" "$human_action" >&2
}

tap_error_json() { # <error_class> <action> [detail]
  python3 -B - "$1" "$2" "${3:-}" <<'PY'
import json, sys
klass, action, detail = sys.argv[1:4]
obj = {"ok": False, "error_class": klass, "action": action}
if detail:
    obj["detail"] = detail
print(json.dumps(obj, separators=(",", ":")))
PY
}

tap_fail() { # <exit-code> <error_class> <action> [detail]
  local rc="$1" klass="$2" action="$3" detail="${4:-}"
  if [ "${TAP_JSON:-0}" = "1" ]; then
    tap_error_json "$klass" "$action" "$detail"
  else
    tap_error_line "$klass" "$action" "$detail"
  fi
  exit "$rc"
}

# --- clearing fence (tap-36kb) ------------------------------------------------
# Content is the courier's signal. Flock serializes writers to the marker; the
# courier NEVER waits on that flock. Fail-OPEN past the family await ceiling —
# opposite polarity from the self-clear guard. A stale marker that wedged the
# fleet would be the more expensive failure.

# TAP_HOME is read HERE, in Bash, and passed as an argument. That is not
# incidental: the Bun module must never read it back out of the environment,
# because an in-process caller has no inheritance moment and would silently
# answer from its own (lane C's event-writer gotcha, one variable over).
tap_clear_fence_bus() {
  local reg="${1:-${TARGET_REGISTRY:-$TAP_REGISTRY}}"
  tap_bun_call clear-fence "${reg:-bus}" clear-fence.ts bus "$reg" "${TAP_HOME:-}"
}

tap_clear_fence_inspect() { # <handle> [<bus>]
  local handle="$1" bus="${2:-}"
  TAP_CLEAR_FENCE_STATE="absent"
  TAP_CLEAR_FENCE_SINCE=""
  TAP_CLEAR_FENCE_PID=""
  TAP_CLEAR_FENCE_NONCE=""
  [ -n "$bus" ] || bus="$(tap_clear_fence_bus)"
  [ -n "$bus" ] || return 0
  # Ordinary handles need no runtime when their marker is absent. Spellings
  # outside this set still go to the module, which owns the whitespace
  # normalization, and the resolver above still owns registry symlinks and
  # post-flip bus layouts.
  case "$handle" in
    *[!A-Za-z0-9._/-]*) ;;
    *) [ -e "$bus/clear-fence/${handle##*/}.json" ] || return 0 ;;
  esac
  local raw
  raw="$(tap_bun_call clear-fence "$handle" clear-fence.ts inspect "$bus" "$handle")" || return 0
  TAP_CLEAR_FENCE_STATE="$(printf '%s\n' "$raw" | sed -n '1p')"
  TAP_CLEAR_FENCE_SINCE="$(printf '%s\n' "$raw" | sed -n '2p')"
  TAP_CLEAR_FENCE_PID="$(printf '%s\n' "$raw" | sed -n '3p')"
  TAP_CLEAR_FENCE_NONCE="$(printf '%s\n' "$raw" | sed -n '4p')"
}

# The verdict is the TOKEN, never the exit status. The incumbent encoded
# "suppressed" as exit 1 - the same status a failed interpreter used, and the
# same status an uncaught TypeError on a non-string nonce produced, so three
# different outcomes arrived as one. Printing a warning is the action a zero
# would license here, so the instrument has to be able to REFUSE
# (.claude/rules/licensing-zero-needs-a-refusable-instrument.md): anything but
# the literal `notice` stays silent, including an empty read.
tap_clear_fence_notice_expired() { # <handle> [<bus>]
  local handle="$1" bus="${2:-}" verdict
  [ -n "$bus" ] || bus="$(tap_clear_fence_bus)"
  [ -n "$bus" ] || return 0
  verdict="$(tap_bun_call clear-fence "$handle" clear-fence.ts notice "$bus" "$handle")" || return 0
  [ "$verdict" = notice ] || return 0
  printf 'tap send: WARNING: clear fence for %s expired; delivering anyway (fail-open past the family await ceiling)\n' "$handle" >&2
}

die() { tap_fail 1 error fix_command "$*"; }

# tap_unknown_option <verb> <opt> — structured unknown-option failure (R17): points at
# `tap help <verb>` instead of the generic error/fix_command, so a mistyped/misplaced
# flag (e.g. `tap send --expect-reply`) is mechanically diagnosable. <verb> is the bare
# verb (send, reply, …); the TAP_VERB prefix already carries "tap <verb>".
tap_unknown_option() { tap_fail 1 unknown_option "tap help $1" "unknown option '$2'"; }

# --- scratch-only interlock (tap-kf9) -----------------------------------------
# TAP_SCRATCH_ONLY is a caller-declared directory prefix meaning "every state
# root I clear this session lives under here". When it is set, a state-clearing
# verb refuses unless the state root it actually RESOLVED sits under that prefix.
#
# Why it exists: on 2026-07-13 a review harness meant to run against a scratch
# directory set its overrides inside a $(command substitution), so those exports
# never reached the parent shell and a machine-wide cleanup cleared the real
# machine state instead. Every sanctioned gate on the command held. What was
# missing was any mechanical link between the scope the caller DECLARED and the
# root resolution actually produced — and a sentence in a brief cannot supply
# that link, because a harness bug does not read briefs.
#
# Three properties this guard must keep:
#   1. Opt-in and purely ADDITIVE. Unset means byte-identical behavior; set, it
#      can only refuse MORE, never permit more. That is the whole safety
#      argument for shipping it — it cannot take away a sanctioned path.
#   2. It reads the FINAL resolved root at the last moment before mutation, not
#      an argument and not an early copy. Catching "resolution produced a root
#      you did not believe you were in" is the entire point.
#   3. It must not itself be defeatable by the bug it exists to catch. Its only
#      inputs are this process's environment and values assigned in THIS shell;
#      no caller may invoke it from inside `$( )`, a pipeline segment, or a
#      background job, because there the `exit` below would end only the
#      subshell and let the mutation proceed. Every call site is in the current
#      shell for exactly that reason.
# Physical-canonicalize a path for TAP_SCRATCH_ONLY comparison (Darwin /var vs
# /private/var). Directories: cd + pwd -P. Files: dirname physically, then
# rejoin basename — plain `cd "$file"` fails and would leave a realpath'd
# registry next to a logical declaration (WAVE 6 resolve × rebuild RED).
tap_scratch_canon_path() {
  local p="$1" parent base
  case "$p" in
    /*) : ;;
    *)  p="$PWD/$p" ;;
  esac
  if [ -d "$p" ]; then
    (cd "$p" 2>/dev/null && pwd -P) || printf '%s' "$p"
    return 0
  fi
  parent="$(dirname -- "$p")"
  base="$(basename -- "$p")"
  parent="$(cd "$parent" 2>/dev/null && pwd -P || printf '%s' "$parent")"
  printf '%s/%s' "${parent%/}" "$base"
}

tap_scratch_only_guard() {  # <what> <resolved-root> [<resolved-root>...]
  [ -n "${TAP_SCRATCH_ONLY:-}" ] || return 0
  local what="$1"; shift
  local declared="$TAP_SCRATCH_ONLY" prefix root
  # Absolutize-then-PHYSICAL-canonicalize both sides identically so a covering
  # declaration under /var/... still admits /private/var/... (same inode tree).
  declared="$(tap_scratch_canon_path "$declared")"
  declared="${declared%/}"
  prefix="$declared"
  [ -n "$prefix" ] || { prefix=""; declared="/"; }   # a declared "/" covers every absolute path
  for root in "$@"; do
    [ -n "$root" ] || continue
    root="$(tap_scratch_canon_path "$root")"
    root="${root%/}"
    # Component-aware prefix match: /w/scratch must not admit /w/scratch-real.
    case "$root" in
      "$declared"|"$prefix"/*) ;;
      *) tap_fail 1 scratch_only_refused "unset TAP_SCRATCH_ONLY, or point it at the state root you actually meant to clear" \
           "TAP_SCRATCH_ONLY declares '$declared' but $what resolved to '$root' — refusing to clear state outside the declared scratch prefix" ;;
    esac
  done
}

# The sentinel grammar version, stamped into slot 1 of every `[[TAP v... ...]]`
# sentinel. The `=` went away with the v0.23 wire; a sweep keyed on `v=` therefore
# matches nothing and is vacuous rather than clean (contract-version-lockstep).
# ONE constant (round-2 review nit — this was hardcoded in two separate sentinel
# constructors: tap-send.sh's own injection and tap_reconstruct_sentinel's
# redelivery replay, despite a single-source-of-truth comment claiming otherwise).
# Bump this, not a literal, in lockstep with CONTRACT.md's protocol version —
# it advances when OBSERVABLE BEHAVIOR changes, not only the wire format
# (CONTRACT line 9 is the rule; v0.5 set the precedent by shipping the session
# layer under a bump with the wire unchanged). Deliberate ruling, opus gate #xxx.
TAP_SENTINEL_VERSION="0.23"

# The courier's own digest-envelope sender identity (tap-ix63). Teammate-SHAPED
# (`<team>/courier`) so it rides the uniform sentinel grammar, but reserved-and-
# unroutable: `tap register` refuses it as a seat handle and `tap send` refuses it
# as a destination, so a digest's from= can never route a reply back to a seat.
TAP_COURIER_IDENTITY="courier"

# --- the pointer's history, because the code no longer shows it ---------------
# EVERY sentinel that reaches a pane is rendered by ONE constructor PER RUNTIME, and
# the two are held to the same grammar by `differential.test.ts`: in bash, the
# direct send (tap-send.sh) and the redelivery replay (tap_reconstruct_sentinel)
# render below; in Bun, the courier digest renders through `sentinel.ts`
# `renderSentinel` inside `spool-digest-inject.ts`. The digest's own bash wrapper
# (`tap_digest_sentinel`) went with the transaction it served — this line used to
# name it as a third bash caller, and it is the kind of sentence that stays true-
# looking for a year after it stops being true, because it is not in anyone's diff.
#
# THIS BLOCK USED TO SAY "`path=` IS UNCONDITIONAL. Do not re-introduce an
# omission predicate here." It is kept, inverted, because deleting it would leave
# the next reader with a rule and no idea that the opposite rule was once load-
# bearing — and because the incident it records is still the reason the current
# rule is shaped the way it is.
#
# v0.18 (tap-wt0i) omitted the pointer whenever the payload already sat at the
# recipient's own canonical location, on the rationale that it "carried no
# information the recipient did not already have." tap-0z9l falsified that in its
# own terms: the information was derivable only by a reader who ALREADY KNEW THE
# CONVENTION, and that convention is taught by session-start injection on three
# harnesses, by nothing at all on the fourth (opencode has no SessionStart hook),
# and by no mechanism whatsoever to a compacted context or a human reading a pane.
# Concretely: a 97-second-old opencode crew seat received a path-less sentinel,
# had no way to know a body existed, and truthfully reported "just the header
# line, no message text." That was filed P1 as transport data loss. No bytes were
# ever lost. A signal a correct reader can read as "there is nothing more" is a
# defect of the signal, and the reader population is not enumerable — every future
# harness, every compaction, and every human starts out not knowing.
#
# v0.23 (tap-7r3fn.8, spec section 13) drops the pointer from the ordinary case
# anyway, and that reversal was ADJUDICATED rather than swept: nothing in the
# v0.23 decision chain cited tap-0z9l until the lane surfaced it, and
# fable-xhigh-developer ruled on 2026-09-04 that section 13 stands. What makes
# that safe is not that the old argument got weaker; it is that the REPLACEMENT is
# different in kind. v0.18 gave a naive reader a bare 12-hex id and a convention.
# v0.23 gives them `<handle>-<UTC>-<12hex>`, which pastes into `tap read` / `tap
# show` verbatim, and for a short note it gives them the note itself, inline. The
# affordance that tells a naive reader where the body lives IS still there —
# tap-0z9l acceptance 3, "the recipient must be able to TELL", is carried by the
# id rather than by the path. The residual is named in CONTRACT.
#
# NOTE FOR A FUTURE SIMPLIFIER, still true and now pointing the other way: the
# two cases that KEEP the pointer (the bare-recipient manual relay and
# a sender team the machine index cannot resolve) look removable on inspection —
# the reader "can" derive the location, the byte saving is measurable while the
# cost is not, and most tests would still pass. That asymmetry is why this is
# prose and not only a check. Each of those three is a case where the id alone
# does NOT resolve; read tap-0z9l before deciding otherwise.
# --- the one sentinel constructor (v0.23 wire, tap-7r3fn.8, spec section 13) ---
# `[[TAP <version> <ask|note> [<team>/]<id> [tag ...] [path=<abs>][: body]]]` —
# three fixed positional slots, then order-free bare tags from a closed set. ~55
# tokens became ~20, which is the whole point of the protocol diet.
#
# ONE SHAPE PER RELEASE. The v0.22 key=value branch that briefly lived beside this
# one is gone, deleted in the same commit that flipped the constant; there is no
# compatibility renderer and no --wire-version. The only place the old shape still
# exists is the READ side, where `tap_stuck_sentinel_fields_from_region` gives a
# pre-0.23 band its own verdict so a sentinel already sitting in a pane at install
# time is submitted rather than clobbered. That is a transition affordance on the
# parser, deliberately not on the producer.
#
# The ARGV is unchanged on purpose. `from` and `to` already arrive team-qualified
# when the caller resolved a team (tap-send.sh:1583-1588, tap_reconstruct_sentinel,
# tap_spool_digest_sentinel), so the one comparison section 13 needs is available
# from the tokens this function already receives — no caller has to learn a new
# signature, and the Bun renderer stays a straight port.
tap_sentinel_render() { # <from> <to> <id> <kind> <reply> <urgency> <payload-path> [inline-body]
  local from="$1" to="$2" id="$3" kind="$4" reply="$5" urgency="$6" payload_path="$7" body="${8:-}"
  local out obligation from_team raw_to_team to_team wire_id _wire_pointer preview

  # Slot 2. `ask|note` replaces `reply=`; section 13 calls it the one word every
  # reader must see, so it is never omitted. Anything that is not an expectation of
  # a reply is a note — the at-rest envelope keeps the precise `reply:` value.
  case "$reply" in expected) obligation=ask ;; *) obligation=note ;; esac

  # Slot 3. The prefix is the SENDER's team and it is a BUS LOCATOR, not a label
  # naming who spoke: the canonical payload lives on the sender's bus, and the only
  # cross-worktree write is the tmux inject (tap-send.sh:660-665). A reader splits
  # on the first `/` to find the bus and reads the remainder as the file id; ids on
  # disk are never qualified.
  #
  # An unqualified recipient is same-team BY CONSTRUCTION — `to` is qualified only
  # when the target's team was actually resolved, and a manual
  # `--cross-worktree --pane <bare-handle>` send never learns it (tap-send.sh:1580).
  # Comparing the RAW stamps would therefore read cross-team on exactly the case
  # section 13 reserves for `path=`, the unindexed manual relay, and stamp a prefix
  # that resolves through the machine index to one registry location — not
  # necessarily the worktree whose bus holds the payload. So default the empty side
  # to the sender's team first, the same way tap_spool_digest_sentinel defaults its
  # own empty to_team at the digest path.
  # The split assumes the `/` qualified form. `tap_valid_qualified_token` also
  # accepts the legacy `<team>:<handle>`, which this reads as unqualified — no live
  # producer builds one (tap-send.sh always uses `/`), but say so rather than leave
  # it to be rediscovered.
  from_team="${from%%/*}"; [ "$from_team" = "$from" ] && from_team=""
  raw_to_team="${to%%/*}"; [ "$raw_to_team" = "$to" ] && raw_to_team=""
  to_team="$raw_to_team"
  # Qualified recipient with an unqualified sender is unreachable today — every
  # caller stamps `from_team` for any cross-worktree send and `to_team` only inside
  # that same branch. If it ever arrives, this function would emit no prefix AND no
  # pointer, and the reader would look for the payload on its own bus while the
  # bytes sit on the sender's. Refuse instead, the way tap_reconstruct_sentinel
  # refuses a non-canonical payload rather than shipping a pointer to nowhere: one
  # line turns an invariant into a check.
  if [ -z "$from_team" ] && [ -n "$raw_to_team" ]; then
    die "sentinel_render: recipient '$to' is team-qualified but sender '$from' is not"
  fi
  [ -n "$to_team" ] || to_team="$from_team"
  wire_id="$id"
  if [ -n "$from_team" ] && [ "$from_team" != "$to_team" ]; then
    wire_id="${from_team}/${id}"
  fi

  out="[[TAP v${TAP_SENTINEL_VERSION} ${obligation} ${wire_id}"

  # Tags: bare words from a closed set, present only when true. `escalate` implies
  # urgent (human-bound, default-urgent) and the two are NEVER both emitted — the
  # send path really does stamp urgency=urgent alongside kind=escalate, so the
  # exclusivity has to be enforced here rather than assumed upstream. Every kind
  # other than escalate/digest leaves the wire and stays in the envelope.
  # `critical` has no producer today; it is reserved parse-side only. A digest
  # never carries an urgency either (tap_spool_digest_sentinel always passes ""),
  # so the digest arm does not append one — a branch with no producer and no arm is
  # a claim nothing checks.
  case "$kind" in
    escalate) out="${out} escalate" ;;
    digest)   out="${out} digest" ;;
    *)        [ -n "$urgency" ] && out="${out} ${urgency}" ;;
  esac

  # path=, the ONE surviving key, and the one line in this function that RETIRES a
  # ratified fix rather than porting it.
  #
  # tap-0z9l's fix direction was "restore the pointer unconditionally — fix the
  # signal, not the reader", after v0.18's pointer diet produced a P1 filed as
  # silent transport data loss. No bytes were ever lost: a 97-second-old opencode
  # crew seat read a path-less sentinel as a message with no body and said so,
  # confidently and wrongly. Nothing in the v0.23 decision chain cites that bead, so
  # the reversal was adjudicated rather than swept: section 13 STANDS
  # (fable-xhigh-developer, 2026-09-04), and what replaces the pointer is the full
  # id in slot 3, which pastes into `tap read`/`tap show` verbatim. tap-0z9l
  # acceptance 3 — "the recipient must be able to TELL" — is preserved by the id,
  # not by the path; the residual is named in CONTRACT.
  #
  # Two cases keep it, and both are cases where the id alone does NOT resolve:
  #
  # Same-bus digests resolve through tap read/show (tap-7r3fn.3.3).
  #   the unindexed manual relay — `--cross-worktree --pane <bare-handle>`, which is
  #     the send that never learns the recipient's team (tap-send.sh:1580), so no
  #     machine-index lookup can find the bus. That is exactly the shape seen here:
  #     `from` qualified, `to` BARE. A same-team send has neither qualified; a
  #     resolved cross-team send has both.
  #
  # If you are here to win the pointer back on the ordinary case, read tap-0z9l
  # first — and then read section 13, which retired it on purpose.
  # WHERE `path=` SURVIVES: exactly where the id in slot 3 does not resolve on its
  # own. The manual relay is a shape test; the other is a PROBE, and that is the
  # architect's ruling of 2026-09-04 rather than my design.
  #
  # Section 13 says the `<team>/` prefix resolves the bus through the machine index.
  # CONTRACT:53 records tap-j20w in the opposite voice — "the index is routinely
  # incomplete; the payload is self-contained; the path is the route" — and that is
  # why every cross-team `tap reply` passes `--remote-registry`. Both cannot hold,
  # and the reconciliation is that tap-j20w is a 2026-07-22 pre-v0.20 observation:
  # post-flip, `tap register` enrolls every git-worktree team (R13, tap-nvtx), so a
  # team that can SEND has a registered sender and a registered sender in a git
  # worktree is enrolled. The senders still outside the index are non-git
  # directories, which are not stable machine-wide addresses.
  #
  # So the rule is stated as an OBSERVABLE instead of a claim: ask the same resolver
  # the reader will use, at construction time, and emit the pointer exactly where
  # the index cannot answer. A resolved cross-team send whose sender team IS
  # enrolled needs no pointer — its prefix is the locator. Same-team sends never
  # probe.
  #
  # The polarity is `tap_authority_context`'s: an ABSENT marker takes the legacy
  # worktree-scan door, while an INVALID or UNREADABLE one refuses the render rather
  # than guessing at reachability — a pointer chosen by a coin flip is worse than a
  # refusal, because it is silent.
  #
  # Residual, named here and in CONTRACT: an enroll or retire between construction
  # and read can change the answer (`tap admin retire` is an operator act, after
  # which `tap show <team>/<id>` says `no enrolled team`).
  _wire_pointer=0
  if [ -n "$from_team" ] && [ -z "$raw_to_team" ]; then
    # The bare-recipient manual relay: `--cross-worktree --pane <bare-handle>` never
    # learns the recipient's team, so nothing a reader looks up finds the bus. Kept
    # as a sufficient condition in its own right rather than folded into the probe.
    _wire_pointer=1
  elif [ -n "$from_team" ] && [ "$from_team" != "$to_team" ]; then
    if ! tap_authority_context "$from_team" >/dev/null 2>&1; then
      case "${TAP_AUTH_STATUS:-}" in
        invalid_flip|marker_unreadable)
          die "sentinel_render: registry marker is ${TAP_AUTH_STATUS}; refusing to render rather than guess whether team '$from_team' is reachable" ;;
        *) _wire_pointer=1 ;;
      esac
    fi
  fi
  preview=""
  # Missing config disables previews without a Bun fork; configured rendering
  # also derives body hints when the payload has no explicit sentinel_preview.
  if [ -f "$payload_path" ] && [ -f "${XDG_CONFIG_HOME:-${HOME:-}/.config}/tap/config.toml" ]; then
    preview="$(tap_bun_call sentinel-preview "$id" sentinel-preview.ts render "$payload_path" "$kind" || true)"
  fi
  out="${out}${preview}"
  [ "$_wire_pointer" = 1 ] && out="${out} path=${payload_path}"

  # `: ` starts the inline note body, and it is LAST because it may run to the end
  # of the line (spec section 13's grammar puts it after `path=` for that reason).
  #
  # Section 1 is the eligibility rule and it is deliberately narrow: the body rides
  # the wire ONLY when it is already wire-safe byte for byte — no newline, no
  # control character, no `]]`, at most 200 characters — and it is NEVER
  # transformed. An ineligible body is not an error and not truncated: it simply
  # takes the read path, which is the path every message already has. The payload
  # file and the receipt chain are written either way; inline is a delivery form,
  # not a second record, so nothing here is the only copy of anything.
  #
  # Notes only. An `ask` names an obligation the recipient has to act on, and the
  # act is reading the payload; section 1 scopes this to "inline one-line notes"
  # and section 13's example carries a body only on a note.
  #
  # Escaping is the trap this rule exists to close, and the answer is that there is
  # no escaping: a transformed body would make the wire a second, lossy record of
  # the message, and then two readers of the same id could disagree about what was
  # said. Refusing to inline is cheap; a body that reads differently on the wire
  # than on the bus is not.
  # NEVER alongside `path=`. The two are the only header parts that can run to the
  # end of the line, and nothing in the grammar says which wins: a path holding
  # `": "` makes `path=/home/me/my: dir/p.md: hello` parse as the pointer
  # `/home/me/my` and the body `dir/p.md: hello` — a silently wrong pointer to the
  # transport's one remaining locator, on the one case section 13 keeps it for.
  # Both pointer cases already hand the reader an explicit path, so suppressing the
  # body there costs a convenience and never a record. Same reasoning as the
  # no-escaping rule: where two things cannot be represented unambiguously, drop
  # the optional one. Found by opus-line-sponsor.
  if [ -z "$preview" ] && [ -n "$body" ] && [ "$obligation" = note ] && [ "$_wire_pointer" = 0 ] \
     && tap_sentinel_body_inlineable "$body"; then
    out="${out}: ${body}"
  fi
  printf '%s]]' "$out"
}

# Section 1's eligibility test, as its own predicate so the rule can be exercised
# directly rather than only through a rendered line.
tap_sentinel_body_inlineable() { # <body>
  local body="$1"
  [ -n "$body" ] || return 1
  # BYTES, measured locale-independently. `${#body}` counts CHARACTERS under a
  # UTF-8 LC_CTYPE and BYTES under LC_ALL=C — "😀x" is 2 there and 5 here — and
  # `tap send` runs in the OPERATOR's environment, which pins nothing. The suite
  # does pin a UTF-8 LC_CTYPE, so a character-based rule agrees with the Bun side
  # only when the locale cooperates: a fixture more generous than the world, and
  # the parity arm could never have caught it. A limit on a WIRE is a limit on
  # bytes, so both runtimes count bytes and neither asks what locale it is in.
  # Found by opus-line-sponsor, measured rather than reasoned.
  [ "$(LC_ALL=C; printf '%s' "$body" | wc -c | tr -d ' ')" -le 200 ] || return 1
  case "$body" in *']]'*) return 1 ;; esac
  # [:cntrl:] covers the newline, so this is one test rather than two — but a
  # newline is the case worth naming: the sentinel is ONE line by construction, and
  # a body carrying one would split it into a header the parser accepts and a tail
  # it never sees.
  [[ "$body" =~ [[:cntrl:]] ]] && return 1
  return 0
}

# --- id discipline ------------------------------------------------------------
# IDs are sender-scoped + collision-resistant, minted by the courier. No ULID dep:
# <sender>-<utc-compact>-<12 hex chars from 6 urandom BYTES>. `od -An -N6` reads
# six BYTES and renders each as two hex digits, which is the 12-char suffix spec
# section 13's right-anchored regex requires; the comment said "6 hex" for a long
# time and was simply wrong about its own output. Charset-locked so an id can never
# break the one-line sentinel grammar.
TAP_ID_RE='^[A-Za-z0-9][A-Za-z0-9._-]*$'
tap_valid_id() { [[ "$1" =~ $TAP_ID_RE ]]; }
# Route/sentinel tokens (from/to/kind, agent handles) share the id charset so a
# value can never break the one-line sentinel grammar or be misread by a parser
# (codex P1). Receipts additionally go through tap_json_obj for escape-safety.
# STRICT, always — envelope from/to/kind, ids, team/handle halves (including the
# slash-target split) all go through this one gate. Qualified route tokens are
# handled by a SEPARATE, narrowly-scoped validator (tap_valid_qualified_token,
# below) — codex P1: a colon accepted here would let a writer
# place a colon-bearing from/to/kind into the canonical envelope, which
# tap doctor then declares torn, and would let 'a:b/c' reach team resolution
# instead of failing as malformed mixed ':' + '/' input.
tap_valid_token() { [[ "$1" =~ $TAP_ID_RE ]]; }

# tap_handle_reserved <candidate> — 0 if the name may NOT be claimed as a seat
# handle, printing why; 1 otherwise. The ONE home for reserved handles, so every
# claim path refuses the same set.
#
# DELIBERATELY NOT PART OF tap_valid_token. That is a pure CHARSET predicate and
# it validates far more than new handles — envelope from/to/kind (lib.sh:1540),
# team names, and EXISTING actors in `tap done --by` / `tap cancel --by`
# (tap-reply-settle.sh:274,333). Reserving inside it would refuse to SETTLE a payload on
# behalf of an actor: a transport correctness break produced by a help-text
# change. "Is this a syntactically valid token" and "may this be CLAIMED as a new
# handle" are different questions and need different predicates.
#
# `help` (tap-7af): Ops ruled that `tap <verb> help` must ALWAYS print that verb's
# help. For verbs whose first operand is a handle (poll, peek, nudge, outstanding,
# register, unregister) a sole `help` would otherwise be valid user data. Making
# the name unclaimable removes the ambiguity AT THE SOURCE instead of
# disambiguating at dispatch — a runtime "is a seat called help registered right
# now?" test would make what a command MEANS depend on ambient state.
#
# Scope is coupled to what the dispatcher intercepts: exact lowercase `help`, so
# a seat may still be called `HELP` and `tap poll HELP` still reaches poll. Widen
# this only together with interception, never ahead of it.
#
# Payload ids are `<sender>-<UTC>-<hash>` and can never be the literal `help`, so
# id-taking verbs were never at risk; handles are the whole collision surface.
# Declared as a LIST rather than inlined in the case below so the set is
# introspectable: the launcher claims handles in Python without going through
# tap-register.sh, so the two languages must agree, and reserved-handle.test.sh
# pins them in lockstep the same way server-epoch-guard.test.sh pins the epoch.
# shellcheck disable=SC2034  # read by reserved-handle.test.sh and mirrored in launcher.py
TAP_RESERVED_HANDLES="help"
# tap_valid_qualified_token — canonical <team>/<handle>, with legacy
# <team>:<handle> remains INPUT-ONLY legacy compatibility at the v0.7 stamp.
# Each half is validated separately against tap_valid_token's charset, with
# exactly one delimiter allowed so mixed or nested forms cannot smuggle a route
# past a parser. Never use this for envelope fields, kind, ids, or team/handle
# halves — those stay strict via tap_valid_token (codex P1).
tap_valid_qualified_token() {
  local tok="$1" team handle
  case "$tok" in
    *:*/*|*/*:*) return 1 ;;
    */*)
      team="${tok%%/*}"; handle="${tok#*/}"
      [[ "$handle" != */* ]] || return 1
      [[ "$team" =~ $TAP_ID_RE ]] && [[ "$handle" =~ $TAP_ID_RE ]] ;;
    *:*)
      team="${tok%%:*}"; handle="${tok#*:}"
      [[ "$handle" != *:* ]] || return 1
      [[ "$team" =~ $TAP_ID_RE ]] && [[ "$handle" =~ $TAP_ID_RE ]] ;;
    *) [[ "$tok" =~ $TAP_ID_RE ]] ;;
  esac
}

# Known agent harness families, in ONE place so tap_is_harness, tap_harness_family,
# and tap_derive_handle can't drift. A tmux command basename or session-name segment
# equal to one of these (or "<fam>-...") is that harness.
TAP_HARNESS_FAMILIES="claude codex opencode cursor hermes agy"
tap_valid_path_token() {
  [ -n "$1" ] || return 1
  [[ "$1" != *"]"* ]] || return 1
  [[ "$1" != *[[:space:]]* ]]
}
tap_mint_id() {
  local sender="$1" rand
  tap_valid_id "$sender" || die "mint_id: sender '$sender' fails charset $TAP_ID_RE"
  rand="$(od -An -N6 -tx1 /dev/urandom 2>/dev/null | tr -d ' \n')"
  # Entropy fallback + assertion: never mint a thin/empty suffix (same-second collision).
  [ "${#rand}" -ge 12 ] || rand="$(printf '%08x%04x' "$((RANDOM * 32768 + RANDOM))" "$RANDOM")"
  [ "${#rand}" -ge 8 ] || die "mint_id: could not gather id entropy"
  printf '%s-%s-%s' "$sender" "$(date -u +%Y%m%dT%H%M%SZ)" "$rand"
}

# tap_send_epoch_from_id <id> / tap_id_age_seconds <id> [<now-epoch>]
# The courier's immutable id timestamp is the one age clock for both ends of an
# unsettled message: sender-side `outstanding --stale` and recipient-side pending
# warnings. Redelivery, spool moves, and archive touches therefore never reset age.
#
# tap-56ig: a future-stamped id (clock drift, tz bug, hand-minted id) yields a
# negative age. Without a clamp it silently fails every overdue threshold
# (`age < stale` / `age < pending-age`). Clamp to 0 for display/filter math and
# emit one stderr warning — the future stamp is itself the fault signal; we do
# not invent a synthetic "very stale" age.
tap_send_epoch_from_id() {
  local id="$1" ts date_part time_part re='[0-9]{8}T[0-9]{6}Z'
  [[ "$id" =~ $re ]] || return 1
  ts="${BASH_REMATCH[0]}"
  date_part="${ts%%T*}"
  time_part="${ts#*T}"
  time_part="${time_part%Z}"
  python3 -B -c '
import datetime, sys
d, t = sys.argv[1:3]
dt = datetime.datetime(int(d[0:4]), int(d[4:6]), int(d[6:8]),
                       int(t[0:2]), int(t[2:4]), int(t[4:6]),
                       tzinfo=datetime.timezone.utc)
print(int(dt.timestamp()))
' "$date_part" "$time_part"
}

# tap_iso_age_seconds <iso-8601-Z>
# Age in seconds of a receipt's own `at` stamp. Distinct from
# tap_id_age_seconds, which reads the id's minted timestamp: a `.read` receipt
# is asking "how long since it was SEEN", not "how long since it was sent", and
# conflating those would report the message's age as the reader's latency.
tap_iso_age_seconds() {
  [ -n "${1:-}" ] || return 1
  python3 -B -c '
import calendar, os, sys, time
try:
    t = time.strptime(sys.argv[1], "%Y-%m-%dT%H:%M:%SZ")
except ValueError:
    raise SystemExit(1)
now = int(os.environ["TAP_SPOOL_NOW"]) if os.environ.get("TAP_SPOOL_NOW") else time.time()
age = int(now - calendar.timegm(t))
print(age if age > 0 else 0)
' "$1" 2>/dev/null
}

tap_id_age_seconds() {
  local id="$1" now="${2:-${TAP_SPOOL_NOW:-}}" sent age
  [ -n "$now" ] || now="$(date +%s)"
  sent="$(tap_send_epoch_from_id "$id")" || return 1
  age=$((now - sent))
  if [ "$age" -lt 0 ]; then
    printf "tap: warning: payload id '%s' is future-stamped (%ss ahead of now); treating age as 0\n" \
      "$id" "$((-age))" >&2
    age=0
  fi
  printf '%s' "$age"
}

# --- atomic write -------------------------------------------------------------
# Write stdin to $1 via temp-file + rename (atomic on the same filesystem), so a
# concurrent `tap poll` never observes a half-written payload or receipt.
tap_atomic_write() {
  local dest="$1" dir tmp
  dir="$(dirname -- "$dest")"
  tmp="$(mktemp "$dir/.tap.XXXXXX")" || die "atomic_write: mktemp failed in $dir"
  cat > "$tmp" || { rm -f "$tmp"; die "atomic_write: write failed for $dest"; }
  mv -f "$tmp" "$dest" || { rm -f "$tmp"; die "atomic_write: rename failed for $dest"; }
}

# Emit a flat JSON object to stdout from alternating `key value` args, via
# json.dumps so ANY value (quotes, a colon in a pane target, an arbitrary epoch)
# is safely escaped — receipts can never be syntactically corrupt (codex P1).
# `-B` keeps the tracked tree free of __pycache__ (codex P2).
tap_json_obj() {
  python3 -B - "$@" <<'PY'
import json, sys
a = sys.argv[1:]
print(json.dumps({a[i]: a[i + 1] for i in range(0, len(a) - 1, 2)}, separators=(",", ":")))
PY
}

# Refresh's reservation clock is shared with native callers. Launcher boot-aware
# reservations retain their separate authority in reservation.ts / seat_corpse.
tap_pending_reservation_expired() {
  local expired
  expired="$(tap_bun_call pending-reservation "$1" pending-reservation.ts expired "$1" "$2")" || return 1
  [ "$expired" = true ]
}

tap_pending_reservation_grace_detail() {
  tap_bun_call pending-reservation "$1" pending-reservation.ts grace "$1" "$2"
}

tap_registry_pending_expired() {
  local handle="$1" row session registered_at
  tap_require_acting_registry || return 1
  row="$(python3 -B - "$TAP_REGISTRY" "$handle" "${_TAP_SCRIPT_DIR}" <<'PY'
import json
import sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import _seat_map
try:
    reg = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(1)
entry = _seat_map(reg).get(sys.argv[2]) or {}
if entry.get("status") != "pending":
    sys.exit(1)
print("\x1f".join([entry.get("session") or "", entry.get("registered_at") or ""]))
PY
)" || return 1
  IFS=$'\x1f' read -r session registered_at <<< "$row"
  tap_pending_reservation_expired "$session" "$registered_at"
}

# --- bus path helpers ---------------------------------------------------------
tap_payload_path()  { printf '%s/%s.md' "$TAP_PAYLOADS" "$1"; }
tap_done_path()     { printf '%s/%s.done' "$TAP_RECEIPTS" "$1"; }
tap_sent_path()     { printf '%s/%s.sent' "$TAP_RECEIPTS" "$1"; }
# tap-ejpf: courier attribution written at place time (before submit-verify).
# Distinct from .sent (post-submit telemetry). Exit-5 keeps a canonical and MUST
# still carry .placed — that is why .sent alone cannot be the provenance mark.
tap_placed_path()   { printf '%s/%s.placed' "$TAP_RECEIPTS" "$1"; }
tap_cancel_path()   { printf '%s/%s.cancelled' "$TAP_RECEIPTS" "$1"; }
# tap_write_sent_receipt <id> <from> <to> <pane> <kind> <delivery pane|poll>
# THE ONE `.sent` writer (tap-dnub). The direct send path and spool redelivery
# both call it, so the receipt has one shape wherever it is minted:
# turn=unconfirmed is constant by design (CONTRACT §turn=unconfirmed — the
# instrument sees the id leave the input band, never a turn begin), and
# delivery= records which transport touched the seat. Atomic via
# tap_atomic_write; a caller that must not abort on a failed write (the
# redelivery path) runs it in a subshell and warns.
tap_write_sent_receipt() {
  tap_json_obj id "$1" from "$2" to "$3" pane "$4" kind "$5" turn unconfirmed delivery "$6" \
    | tap_atomic_write "$(tap_sent_path "$1")"
}
# tap_quarantine_payload <abs-payload> <reason>
# Move a malformed canonical ONCE into payloads/.quarantine/, preserving its
# bytes. Exit 0 when this call moved it, 1 when there was nothing to move.
#
# The behaviour it replaces warned once per malformed file per poll, forever —
# five stale files on the live bus meant five warnings on every poll by every
# seat, about state nobody was going to act on. Moving the file is what makes
# the warning stop: the scan no longer sees it, so the pointer is printed once,
# by the run that acted, and never again.
#
# `.quarantine` sits INSIDE payloads/ deliberately: it travels with the bus,
# survives a relocation, and a dot-prefixed name is already skipped by the
# `*.md` glob every scanner uses. Bytes are never overwritten — a name that is
# already taken gets a numbered sibling, because the file being moved is
# evidence about a defect and the one already there is evidence about an
# earlier instance of it.
# EXIT CODES, and the distinction is load-bearing:
#   0  moved, and the bus generation was marked reused
#   1  nothing to move — the source is already gone (a sibling scanner won the
#      race). A no-op, and the caller may say nothing.
#   2  the operation FAILED where the caller must not report a clean pass: the
#      directory could not be made, the move failed and the malformed payload is
#      still live, or the move landed but the generation mark did not (leaving
#      `tap team restore` admitted over the bytes just preserved).
# Collapsing 2 into 1 is what let a real failure read as "somebody else handled
# it" (luna's partner re-review); a caller that treats them alike cannot tell a
# race it can ignore from a failure it must surface.
tap_quarantine_payload() ( # <abs-payload> <reason>
  local src="$1" reason="${2:-malformed}" qdir base rc=0
  base="$(basename "$src")"
  # Serialize scanners for this id, scoped to this call. Another scanner may
  # already have moved the malformed file and a sender may have corrected it.
  tap_obligation_lock "${base%.md}" 5 || return 2
  [ -f "$src" ] || return 1
  case "$reason" in
    invalid_envelope) tap_validate_envelope "$src" >/dev/null 2>&1 && return 1 ;;
    id_mismatch) [ "$(tap_envelope_field "$src" id || true)" = "${base%.md}" ] && return 1 ;;
  esac
  qdir="$(dirname "$src")/.quarantine"
  mkdir -p "$qdir" || return 2
  # link() claims the destination exclusively. A collision retries a numbered
  # sibling; it never overwrites earlier evidence. Rechecking after the lock
  # keeps a later scanner from moving a corrected replacement.
  python3 -B - "$src" "$qdir" "$base" <<'PYQUAR' || rc=$?
import os, sys
src, qdir, base = sys.argv[1:]
linked = False
try:
    n = 0
    while True:
        dest = os.path.join(qdir, base if n == 0 else f"{base}.{n}")
        try:
            os.link(src, dest)
            linked = True
            break
        except FileExistsError:
            n += 1
    os.unlink(src)
except FileNotFoundError:
    # ENOENT can name the destination directory, not just the source. Only an
    # independently confirmed absent source before publication is a no-op.
    try:
        os.lstat(src)
    except FileNotFoundError:
        sys.exit(2 if linked else 1)
    except OSError:
        sys.exit(2)
    sys.exit(2)
except OSError as exc:
    print(f"quarantine: could not preserve {src}: {exc}", file=sys.stderr)
    sys.exit(2)
PYQUAR
  [ "$rc" = 0 ] || return "$rc"
  printf '%s\t%s\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$reason" "$base" \
    >> "$qdir/.log" 2>/dev/null || true
  # The move and the log append are real first mutations of this bus, so the
  # generation must stop reading `pristine` — otherwise `tap team restore` is
  # still admitted and replaces the bus, discarding the quarantined evidence in
  # favour of obsolete checkpoint state. Same rule the settle paths follow; the
  # bus is derived from the payloads dir this file came out of, never $TAP_HOME,
  # because the caller may be quarantining on another team's bus.
  # PART OF THE SUCCESS CONTRACT, not best-effort. If the generation stays
  # `pristine` after a real move, `tap team restore` is still admitted and
  # replaces the bus — discarding the very evidence this function preserved.
  # Reporting success there is the success-shaped-signal class: the caller
  # counts a clean quarantine while the protection it depends on did not land.
  # rc 2 distinguishes it from rc 1 (nothing to move), because the file HAS
  # moved and the caller must say so rather than treat it as a no-op.
  tap_reset_generation_touch_bus "$(dirname "$(dirname "$qdir")")" "quarantine" || return 2
  return 0
)

tap_spool_payload_path() { printf '%s/%s.md' "$TAP_SPOOL" "$1"; }
# Persistent Bash sidecars snapshot their sources BEFORE loading this library.
# Re-exec at the next iteration boundary: no stale function reload in-place,
# no second process, and exec preserves the sidecar's PID and external custody.
tap_sidecar_source_refresh() { # <absolute entrypoint> [original arguments...]
  local current
  if ! current="$(git hash-object --no-filters -- "${_tap_sidecar_source_files[@]}" 2>/dev/null)"; then
    echo "tap sidecar: source-unreadable; refusing another iteration: $1" >&2
    exit 1
  fi
  [ "$current" != "$_tap_sidecar_source_stamp" ] || return 0
  echo "tap sidecar: source-changed; re-exec: $1" >&2
  exec bash "$@"
}

tap_spool_meta_path()    { printf '%s/%s.meta.json' "$TAP_SPOOL" "$1"; }
# unprocessed = a payload with no matching .done OR .cancelled. (The whole liveness model.)
# tap cancel writes .cancelled for sends whose addressee is gone — the id drains
# from outstanding just like .done, but provenance records via=cancelled, not via=done.
tap_is_done()       { [ -f "$(tap_done_path "$1")" ] || [ -f "$(tap_cancel_path "$1")" ]; }

# Terminal-by-cancellation is terminal on EVERY door — refuse BEFORE any effect.
#
# Native `assertUnsettled` (done.ts) consults `bus.isDone`, which is `.done` OR
# `.cancelled`. The Bash reply/settle doors checked `.done` ALONE, and that gap
# only became reachable when `tap withdraw` started leaving a withdrawn payload
# RESIDENT in payloads/ (archiving would have failed the inbound lookup instead).
# A resident withdrawn payload is an ordinary-looking inbound to Bash: it would
# compose and deliver an outbound, then write `.done` beside the `.cancelled` —
# and since every reader prefers `.done`, the tombstone vanished and provenance
# claimed the recipient settled a retraction the sender had taken back.
#
# The live Bash-owned forms are real, not residual: `--pane`, `--reply-to`,
# `--kind escalate`, `--delivery interrupt`, and the whole verb when the flip
# marker is absent (grok-examiner-8, #xxxx RETAIN panel).
tap_refuse_if_cancelled() { # <cancel-path> <id>
  local _cancel_path="$1" _id="$2" _via _reason _successor _next
  # `-f`, matching tap_is_done's own predicate on this very record (and rule 38:
  # a state question is a REGULAR-FILE question). `-e` disagreed with the
  # function it gates alongside — the same two-predicates-one-record divergence
  # this member exists to remove (grok-examiner-8, #xxxx F&S residual).
  [ -f "$_cancel_path" ] || return 0
  _via="$(python3 -B -c 'import json,sys
try: print(json.load(open(sys.argv[1])).get("via") or "cancelled")
except Exception: print("cancelled")' "$_cancel_path")"
  if [ "$_via" != withdrawn ]; then
    tap_fail 1 already_settled "tap show $_id" \
      "'$_id' is already terminal (via: $_via); it cannot be answered or settled again"
  fi
  _reason="$(python3 -B -c 'import json,sys
try: print(json.load(open(sys.argv[1])).get("reason") or "")
except Exception: print("")' "$_cancel_path")"
  _successor="$(python3 -B -c 'import json,sys
try: print(json.load(open(sys.argv[1])).get("superseded_by") or "")
except Exception: print("")' "$_cancel_path")"
  # Same error class and the same next step as native assertUnsettled.
  if [ -n "$_successor" ]; then
    _next="tap read $_successor"
  else
    _next="tap show $_id"
  fi
  tap_fail 1 withdrawn "$_next" \
    "'$_id' was withdrawn by its sender — superseded: ${_reason:-no reason given}$([ -n "$_successor" ] && printf "; answer '%s' instead" "$_successor" || printf '; the sender named no successor'). Nothing is owed on '$_id'."
}

# Courier-attributed mail: .placed (place-time, preferred) OR legacy .sent
# (pre-tap-ejpf telemetry grandfather — so the historic bus is not mass-flagged).
# Hand-written payloads have neither. Never use this to HIDE mail — only to LABEL.
tap_is_courier_attributed() {
  [ -f "$(tap_placed_path "$1")" ] || [ -f "$(tap_sent_path "$1")" ]
}

# Write receipts/<id>.placed after a successful courier rename into payloads/.
# Best-effort identity only — flock on the payload rename is the place authority;
# a missing .placed after a crash mid-write is still labeled unattributed (LABEL).
tap_write_placed() { # <id> [<via>]
  local id="$1" via="${2:-courier}" at
  tap_valid_id "$id" || return 1
  mkdir -p "$TAP_RECEIPTS" || return 1
  at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  tap_json_obj id "$id" via "$via" at "$at" \
    | tap_atomic_write "$(tap_placed_path "$id")"
}

# --- delivery clock (tap-7r3fn.20) -------------------------------------------
# The window runs from the last VERIFIED delivery to a seat, so the clock is the
# RECIPIENT's fact and lives on the RECIPIENT's bus, resolved from the entry's
# `target_registry` (rulings 23 and 43). One file per seat, holding one field.
#
# THE HANDLE IS BARE HERE, AND THAT IS THE CLEAR-FENCE PRECEDENT RATHER THAN AN
# OVERSIGHT. A registry belongs to one team — `tap_registry_matches_team` answers
# `gone` otherwise — so a bus resolved from a registry is already team-scoped, and
# qualifying the handle inside it would name nothing new. `clear_fence.fence_path`
# strips `<team>/` for that reason on that same directory. Config override keys
# ARE team-qualified (ruling 46) because config is one file spanning every team;
# the two answers differ because the questions do.
#
# AN EMPTY REGISTRY IS A NO-OP, NOT A FALLBACK. A manual unbound `--cross-worktree
# --pane` send has no authoritative registry, so it has no clock to read or stamp:
# it is a direct attempt by construction and never enters the window (ruling 43).
# Resolving an empty path instead would land on the courier's CWD —
# `busForRegistry("")` resolves the empty path there — which is exactly
# how a stray clock file appears inside a repository checkout.
# Bun owns path resolution, monotonic sidecar-flock stamping and tolerant reads.
tap_delivery_clock_path() { # <target_registry> <handle>
  tap_bun_call delivery-clock "${2:-}" delivery-clock.ts path "${1:-}" "${2:-}" 2>/dev/null || return 0
}

tap_delivery_clock_stamp() { # <target_registry> <handle> [<epoch>]
  tap_bun_call delivery-clock "${2:-}" delivery-clock.ts stamp "${1:-}" "${2:-}" "${3:-}" 2>/dev/null || return 0
}

tap_delivery_clock_read() { # <target_registry> <handle>
  tap_bun_call delivery-clock "${2:-}" delivery-clock.ts read "${1:-}" "${2:-}" 2>/dev/null || return 0
}

tap_spool_team_name() {
  local team="" reg="" root=""
  # Do NOT call tap_require_acting_registry here — tap_authority_context (live
  # arm) calls this to discover the team name, so a rebind would recurse until
  # the process table fills.
  # WAVE 6.9 / sol cwd-relocated: post-flip cwd identity MUST come from the
  # global root→enrollment key (or basename only when genuinely unenrolled).
  # Sibling/bus team.name is pre-authority and cannot discover a relocated
  # acting registry (decoy team.name poisons rebind into the wrong key).
  if tap_registry_v20_live 2>/dev/null; then
    root="$(tap_team_dir_from_bus 2>/dev/null || true)"
    [ -n "$root" ] || root="$(_tap_repo_root 2>/dev/null || true)"
    if [ -n "$root" ]; then
      team="$(python3 -B - "$root" "${_TAP_SCRIPT_DIR}" <<'PY' 2>/dev/null || true
import os, sys
sys.path.insert(0, sys.argv[2])
from registry_v20 import enrolled_team_name_for_root, resolve_team_registry_for_root
root = sys.argv[1]
st, name = enrolled_team_name_for_root(root)
if st == "ok" and name:
    print(name)
    raise SystemExit(0)
# Genuinely unenrolled only — basename path (not bus/sibling content).
rst, _path = resolve_team_registry_for_root(root)
if rst == "live_unenrolled":
    print(os.path.basename(os.path.realpath(root).rstrip(os.sep)))
PY
)"
      [ -n "$team" ] && { printf '%s' "$team"; return 0; }
    fi
    # Enrolled-unreachable / invalid / no root: empty — callers fail closed.
    return 0
  fi
  # Pre-flip (marker absent): ambient bus / sibling / basename — unchanged.
  if [ -n "${TAP_REGISTRY:-}" ] && [ -f "$TAP_REGISTRY" ]; then
    reg="$TAP_REGISTRY"
  elif [ -n "${TAP_HOME:-}" ] && [ -f "$(dirname "$TAP_HOME")/team-registry.json" ]; then
    reg="$(dirname "$TAP_HOME")/team-registry.json"
  fi
  if [ -n "$reg" ]; then
    team="$(python3 -B - "$reg" <<'PY' 2>/dev/null || true
import json, sys
try:
    print(((json.load(open(sys.argv[1])).get("team") or {}).get("name") or "").strip())
except Exception:
    pass
PY
)"
    [ -n "$team" ] && { printf '%s' "$team"; return 0; }
  fi
  basename "$(_tap_repo_root)"
}

# A team-qualified envelope is local only when its target team matches this
# bus. Empty to_team preserves legacy/manual-relay behavior: those payloads are
# handle-qualified because the courier never learned a recipient team.
tap_target_team_is_local() { # <to-team> [<local-team>]
  local target_team="${1:-}" local_team="${2:-}"
  [ -z "$target_team" ] && return 0
  [ -n "$local_team" ] || local_team="$(tap_spool_team_name)"
  [ "$target_team" = "$local_team" ]
}

tap_registry_matches_team() { # <registry> <expected-team>; empty expectation is unqualified
  local registry="$1" expected_team="${2:-}"
  [ -z "$expected_team" ] && return 0
  [ -f "$registry" ] || return 1
  python3 -B - "$registry" "$expected_team" <<'PY' 2>/dev/null
import json, sys
try:
    actual = ((json.load(open(sys.argv[1])).get("team") or {}).get("name") or "").strip()
except Exception:
    raise SystemExit(1)
raise SystemExit(0 if actual == sys.argv[2] else 1)
PY
}

# --- Legacy autosettle park custody -------------------------------------------
# The policy name remains readable for existing parks, deadlines and recovery.
# New sends use the shared delivery disposition; no courier path writes .done.
TAP_AUTOSETTLE_POLICY="autosettle"
# TAP_AUTOSETTLE_HOLD_DEFAULT (300) AND tap_autosettle_hold_seconds ARE DELETED,
# not kept for compatibility: 300 seconds measured from ENQUEUE is the defect
# tap-7r3fn.20 opens with, and a helper still returning it is an invitation to a
# future caller. Windows now come from tap_delivery_window_seconds, measured from
# the recipient's last verified delivery. TAP_AUTOSETTLE_HOLD_SECONDS survives
# under its own name as the short-window override (ruling 24) and is read there.

# tap-6vwz: how long past its delivery deadline a drain-excluded entry waits
# before its sender is told it was never routed. Generous on purpose — this is a
# backstop for a state nothing else reports, not a delivery timeout, and the
# entry has already missed its own deadline by the time the clock starts.
TAP_SPOOL_UNROUTED_GRACE="${TAP_SPOOL_UNROUTED_GRACE:-1800}"

# --- delivery windows (tap-7r3fn.20) -----------------------------------------
# The two built-in windows (now 10 s, polite 60 s) live with their reader in
# runtime/bun/src/digest-window.ts. `now` is the short flood limiter every class
# but `polite` rides; `polite` is the long one. Both are floors rather than
# deadlines — the deliverer wakes at the due time, and a busy pane still parks.

# The delivery window and the recipient's digest-window override live in ONE
# native implementation, runtime/bun/src/digest-window.ts (lane A, batch 2,
# slice A1a). These are adapters: they resolve the facts that live in other
# functions (config path, team name) and call it; no decision, retry, state
# write or parser stays here. The "python3 without tomllib" degrade (rc 4) has
# no native counterpart — Bun always parses TOML — so the advisory that
# accompanied it is gone with it.
#
# PRECEDENCE, most specific first (ruling 46):
#   [delivery.overrides."<team>/<handle>"]   the seat, named unambiguously
#   [delivery.overrides."<handle>"]          shorthand for the acting team
#   [delivery]                               the fleet default
# A bare handle is documented shorthand rather than a second address space:
# handles are team-scoped and collide across teams, so the qualified form is the
# one that always means what it says.
# How long this entry's window is. THE one answer; every caller asks here.
#
# W IS DERIVED FROM `policy`, NOT FROM A NEW FIELD, AND THAT IS A CONSTRAINT
# RATHER THAN A PREFERENCE. runtime/bun/src/spool.ts builds a closed-set object
# on write (:280) and again on normalize (:680), so a key it does not know is
# dropped the first time a native verb touches the entry, and `asPolicy` (:616)
# coerces an unrecognized policy to `standard`. A `delivery` field or a `window`
# policy value would therefore survive in Bash and evaporate through Bun. The
# existing four values already carry the distinction the window needs: `polite`
# takes the long window and everything else — `standard`, `urgent`, `autosettle`
# — takes the short one, which is how the window reaches `reply=expected` sends
# (they park as `standard`) without inventing state Bun would eat.
#
# TAP_AUTOSETTLE_HOLD_SECONDS SURVIVES AND OVERRIDES THE SHORT WINDOW (ruling 24).
# It is the only seam by which courier-auto-settle and send-default-settle-only
# compress or extend the window without sleeping. It does NOT touch the polite
# window: it is named for one class, `--polite-timeout` already addresses the
# other, and one variable silently meaning two durations is the shape this bead
# exists to remove.
tap_delivery_window_seconds() { # <policy> [<team>] [<handle>] [<reply>] -> integer seconds
  local policy="${1:-standard}" team="${2:-}" handle="${3:-}" reply="${4:-expected}" acting
  acting="$(tap_spool_team_name 2>/dev/null || true)"
  [ -n "$team" ] || team="$acting"
  tap_bun_call digest-window "${handle:-window}" digest-window.ts window-seconds "$policy" "$team" "$handle" "$reply" "$acting"
}

# Is this spool entry HELD for a coalescing window — i.e. parked by policy rather
# than by a pane that could not take it? Named for WHY the item is held, not for
# who held it: the same hold machinery (`hold_until_epoch`, the Phase A flush
# rule, the Phase B suppression) is where a second held class would land, and it
# would join by adding one member HERE rather than by re-deriving the class at
# each site. Reads the marker minted at the send gate; never re-infers a class
# from reason strings or kinds.
tap_spool_entry_is_held() { # <policy>
  [ "${1:-}" = "$TAP_AUTOSETTLE_POLICY" ]
}


# One scalar out of a spool entry's meta, empty when absent or unreadable.
tap_spool_meta_field() { # <id> <key>
  tap_bun_call spool-sidecar "$1" spool-sidecar.ts field "$TAP_SPOOL" "$1" "$2" 2>/dev/null || printf ''
}

# Thin adapter over the native pair writer (runtime/bun/src/spool-publication.ts):
# it gathers the facts other functions own and passes them as argv. The window
# and the recipient's clock are resolved HERE, in the branch that mints the
# park (tap-7r3fn.20), so the stamped epoch is a fact about this entry rather
# than something a later reader recomputes; `tap_delivery_window_seconds`
# resolves the acting team itself, so this site and the direct-send park in
# tap-send.sh cannot disagree about the window. Both may be empty — an unbound
# relay has no clock, a seat that has heard nothing has no reading — and empty
# means "due now". Validation, classification, ordering and the sidecar lock
# live in the writer; a nonzero status here means nothing was published that
# the caller may treat as complete, and the canonical payload is untouched.
tap_spool_add() { # <id> <canonical-payload> <target> <team> <reason> [<reason_class>] [<timeout_seconds>] [<pane>] [<pane_id>] [<to_team>] [<policy>] [<grace_seconds>] [<target_registry>] [<cue_style>] [<cue_red_at>]
  local team="${4:-}" _window _last_delivered
  [ -n "$team" ] || team="$(tap_spool_team_name)"
  _window="$(tap_delivery_window_seconds "${11:-standard}" "${10:-}" "$3" "$(tap_envelope_field "$2" reply)")"
  _last_delivered="$(tap_delivery_clock_read "${13:-}" "$3")"
  tap_bun_call spool-publication "$1" spool-publication.ts add "$TAP_SPOOL" "$1" "$2" "$3" "$team" "$5" \
    "${6:-}" "${7:-}" "${8:-}" "${9:-}" "${10:-}" "${11:-standard}" "${12:-}" "${13:-}" \
    "$_window" "$_last_delivered" "${14:-}" "${15:-}"
}

tap_send_success_receipt() { # <ok|queued> <verbose detail>
  local verb=send
  [ "${TAP_ASSIGN_VERB:-0}" = 1 ] && verb=assign
  if [ "${TAP_VERBOSE:-0}" = 1 ]; then
    tap_receipt "$verb" "$2"
  else
    tap_receipt "$verb" "$1 $ID"
  fi
}

# Publish one already-placed message through the shared Bash spool engine.
# Both runtime doors supply the binding captured before placement; this helper
# never re-resolves the recipient. The spool copy replaces canonical residency.
tap_spool_schedule_probe() { # <id> <delay>; record the actual scheduled sleep; rc 1 when it could not
  local verdict
  verdict="$(tap_bun_call spool-state "$1" spool-state.ts schedule-probe "$TAP_SPOOL" "$1" "$2")" || return 1
  case "$verdict" in
    scheduled) return 0 ;;
    refused) return 1 ;;
    *) printf 'tap: slice_failed id=%s slice=spool-state: invalid schedule verdict\n' "$1" >&2; return 1 ;;
  esac
}

tap_queue_explanation() { # <id>; read-only
  tap_bun_call queue-explanation "$1" queue-explanation.ts "$TAP_HOME" "$1"
}

tap_spool_park_placed() { # <id> <canonical> <from> <to> <kind> <reply> <pane> <pane_id> <to_team> <registry> <reason> <timeout> <policy> <grace> <json> [cue] [cue_red_at]
  local ID="$1" CANON="$2" FROM="$3" TO="$4" KIND="$5" REPLY_EXPECT="$6"
  local PANE="$7" PANE_ID="$8" _to_team_stamp="$9" TARGET_REGISTRY="${10}"
  local reason="${11}" timeout_seconds="${12}" policy="${13}" grace_seconds="${14}" TAP_JSON="${15}" cue_style="${16:-}" cue_red_at="${17:-}"
  local _report _verdict _detail _state="" _verb=send
  # Resolved pane/pane_id/to_team are captured HERE, at park time, from this
  # send's own resolution (PANE/PANE_ID/_to_team_stamp) — redelivery must
  # replay against this exact pane, never re-resolve TO (a bare, team-stripped
  # handle) through any registry (round-2 review blocker).
  # The whole route — the A1b transaction, the flash cue, the deliverer spawn, the
  # backlog report/warning, the injection facts — is runtime/bun/src/spool-park-report.ts
  # (`parkAndReport`), the same export native `send` calls in process. It answers one
  # verdict at rc 0: `ok` with the report, or `spool_busy` / `spool_publish_failed`
  # with the incumbent's detail, the claim already released and the canonical payload
  # retained. A missing runtime fails through tap_bun_call loudly; an empty or unknown
  # verdict is refused.
  _report="$(tap_bun_call spool-park-report "$ID" spool-park-report.ts park-report "$TAP_SPOOL" "$TAP_HOME" "$ID" "$CANON" \
    "$FROM" "$TO" "$KIND" "$REPLY_EXPECT" "$(tap_spool_team_name)" "$reason" "$timeout_seconds" "$PANE" "${PANE_ID:-}" \
    "$_to_team_stamp" "${TARGET_REGISTRY:-}" "$policy" "$grace_seconds" "$cue_style" "$cue_red_at" "$_TAP_SCRIPT_DIR")" \
    || tap_fail 1 spool_publish_failed "inspect with tap show $ID" "spool park did not run; canonical payload retained"
  # Two lines; a refusal with an empty detail is one line, and under the send doors'
  # errexit the second read's EOF must not abort before the refusal is reported.
  { IFS= read -r _verdict; IFS= read -r _detail || true; } <<<"$_report"
  case "$_verdict" in
    ok) ;;
    spool_busy|spool_publish_failed) tap_fail 1 "$_verdict" "inspect with tap show $ID" "$_detail" ;;
    *) printf 'tap: slice_failed id=%s slice=spool-park-report: invalid park verdict\n' "$ID" >&2
       tap_fail 1 spool_publish_failed "inspect with tap show $ID" "spool park verdict unreadable; canonical payload retained" ;;
  esac
  [ "${TAP_ASSIGN_VERB:-0}" != 1 ] || _verb=assign
  # The verbose human receipt's readiness token. READINESS IS STILL BASH
  # (`tap_spool_pane_ready`, ported with the drain's attempt transaction once lane B's
  # reader lands), so it is computed here — after the park, because it reads the
  # entry's sidecar — and handed to the renderer as data. The incumbent probed it for
  # every non-JSON park, verbose or not; so does this.
  [ "$TAP_JSON" = 1 ] || _state="$(tap_spool_display_state "$ID")"
  tap_bun_call spool-park-report "$ID" spool-park-report.ts park-receipt "$TAP_HOME" "$_detail" "$ID" "$FROM" "$TO" "$PANE" "$KIND" \
    "$REPLY_EXPECT" "$reason" "$policy" "${TAP_JSON:-0}" "${TAP_VERBOSE:-0}" "$_verb" "$_state" \
    || tap_fail 1 spool_publish_failed "inspect with tap show $ID" "the entry is parked but its receipt did not render"
}

tap_spool_list() { # [target] [target_registry] — optional register recovery scope
  local answer
  [ -d "$TAP_SPOOL" ] || return 0
  answer="$(tap_bun_call spool-state list spool-state.ts list "$TAP_SPOOL" "${1:-}" "${2:-}")" || return 1
  # The runtime's completion marker is its verdict: an empty answer from a runtime that
  # exited 0 is refused, not read as "no entries" (the same shape check every slice
  # adapter does). Consumers get exactly the incumbent's rows, marker stripped.
  case "$answer" in
    *$'\n'"#spool-state list complete") printf '%s\n' "${answer%$'\n'"#spool-state list complete"}" ;;
    "#spool-state list complete") ;;
    *) printf 'tap: slice_failed id=list slice=spool-state: incomplete listing\n' >&2; return 1 ;;
  esac
}

tap_spool_remove() { # <id>
  # The charset guard stays in Bash on purpose. `die` EXITS, and 33 call sites
  # here call this function directly rather than in a command substitution, so
  # the incumbent's hard stop on a malformed id is the behavior they are written
  # against — a native refusal would return 1 into shells that do not check it.
  tap_valid_id "$1" || die "spool_remove: id '$1' fails charset $TAP_ID_RE"
  tap_bun_call spool-sidecar "$1" spool-sidecar.ts remove "$TAP_SPOOL" "$1"
}

# --- The `.reown` owner lease -------------------------------------------------------
#
# `.reown` answers one question: has anyone started an owner for this id recently? It is
# NOT the delivery claim (`.claim`) — that is a lease over *delivering* an entry, held by
# whoever is mid-attempt, and consuming it here would make re-own contend with the drain
# for the very lease the drain needs.
#
# IT CARRIES AN OWNER TOKEN RATHER THAN BEING AN EMPTY mtime FILE, and that is the whole
# design. An exiting waiter must delete its own lease (or a crashed-owner entry waits out
# the full stale window for nothing) while NOT deleting a successor's (or the exit itself
# mints the multi-owner defect the lease exists to prevent). Those two are the same
# unlink unless the file says whose it is, and a mtime cannot: a successor minted one
# second ago and an incumbent refreshed one second ago look identical.
#
# Every operation runs under the entry's EXISTING `$(tap_spool_meta_path).lock`. No lock
# protecting a lock, and no second serialization point to keep consistent — the meta lock
# is already the file both the metadata writers and the stale-sidecar reaper agree on.

# Claim the lease. Prints the new owner token and returns 0, or prints nothing and
# returns 1 when a FRESH incumbent holds it. A stale incumbent is replaced under the same
# lock: a crashed owner must not suppress ownership forever, which would be this bead's
# own defect wearing the fix's clothes.
tap_reown_claim() { # <id> -> token on stdout; rc 1 when not claimed (a fresh incumbent, a settled entry)
  local lease
  lease="$(tap_bun_call spool-reown "$1" spool-reown.ts claim "$TAP_SPOOL" "$1" "${TAP_SPOOL_REOWN_LEASE_SECONDS:-20}")" || return 1
  [ -n "$lease" ] || return 1
  printf '%s' "$lease"
}

# Refresh only on token match. A mismatch means this waiter has been superseded, and the
# caller's contract is to exit rather than to keep refreshing someone else's lease.
tap_reown_refresh() { # <id> <token>; rc 1 when superseded
  local verdict
  [ -n "${2:-}" ] || return 1
  # The runtime's STATUS first, then its token: a recognized word from a child that
  # exited nonzero certifies nothing (astra F2 on #xxxx).
  verdict="$(tap_bun_call spool-reown "$1" spool-reown.ts refresh "$TAP_SPOOL" "$1" "$2")" || return 1
  case "$verdict" in
    refreshed) return 0 ;;
    superseded) return 1 ;;
    *) printf 'tap: slice_failed id=%s slice=spool-reown: invalid refresh verdict\n' "$1" >&2; return 1 ;;
  esac
}

# Release on token match, and NO-OP on anything else. The no-op is the point: a departing
# waiter whose lease was already replaced must leave the successor's authority standing.
tap_reown_release() { # <id> <token>
  [ -n "${2:-}" ] || return 0
  tap_bun_call spool-reown "$1" spool-reown.ts release "$TAP_SPOOL" "$1" "$2" || true
}

tap_spool_bump_attempts() { # <id> — best-effort; a delivery attempt was just made
  tap_bun_call spool-sidecar "$1" spool-sidecar.ts bump "$TAP_SPOOL" "$1" 2>/dev/null || true
}

tap_spool_mark_legacy_no_binding() { # <id> — fail-closed upgrade marker
  # The event's registry facts (`tap_registry_event_append` resolved them the same way).
  tap_bun_call spool-state "$1" spool-state.ts mark-legacy-no-binding "$TAP_SPOOL" "$1" "$TAP_REGISTRY_EVENTS" "$(tap_spool_team_name)" "${TAP_VERB:-tap}" || true
}

# A spool claim is deliberately a tiny, per-entry sidecar rather than a process
# registry: only the holder may move an entry into the live courier path.
tap_spool_claim_path() { printf '%s/%s.claim' "$TAP_SPOOL" "$1"; }

tap_spool_claim_acquire() { # <id> [no-steal] — readers never reclaim an existing claim
  # The writer answers `acquired` or `held` at rc 0: a held claim is routine
  # contention and the incumbent said nothing about it, while a missing runtime
  # still fails through tap_bun_call loudly, as it must. The shape check below
  # is what every slice adapter does with its result — an empty answer from a
  # runtime that exited 0 having written nothing is refused, not read as held.
  local verdict
  verdict="$(tap_bun_call spool-sidecar "$1" spool-sidecar.ts claim "$TAP_SPOOL" "$1" "${2:-}")" || return 1
  case "$verdict" in
    acquired) return 0 ;;
    held) return 1 ;;
    *) printf 'tap: slice_failed id=%s slice=spool-sidecar: invalid claim verdict\n' "$1" >&2; return 1 ;;
  esac
}

tap_spool_claim_release() { rm -f "$(tap_spool_claim_path "$1")"; }

tap_spool_reap_stale_sidecars() { # removes inert writer locks/claims and canonical-orphan metadata
  [ -d "$TAP_SPOOL" ] || return 0
  tap_bun_call spool-sidecar reap spool-sidecar.ts reap "$TAP_SPOOL" "${1:-$TAP_PAYLOADS}"
}

tap_spool_pane_ready() { # <pane> <pane_id> <handle> <to_team> <target_registry> [policy] -> ready|unsafe|busy|busy:*|gone
  # Body: runtime/bun/src/spool-readiness.ts `readinessWalk` — the whole decision tree
  # and every subclass it answers with. What stays here is OBSERVATION, because B1 ruled
  # capture belongs to the caller's language (pane/reader.ts's header): a native capture
  # would ask a different tmux server than this bare `tap_capture_pane` and would be
  # invisible to the smokes that stub it as a shell function.
  #
  # THE WALK ASKS; THIS FETCHES — for EVERY observation, not just the captures. The
  # incumbent read the world lazily all the way down: an empty pane answered `gone`
  # without an identity probe, a held pane without a `#{pane_current_command}`, an
  # unsafe harness without a `#{pane_in_mode}`, and a team-targeted entry never opened the
  # watch arm record at all. A loop that gathered the cheap facts up front would put that
  # traffic on panes the incumbent never touched — a cost in a per-entry drain loop and a
  # new call in a sequence the fixtures' fake tmux does not expect. So the native side
  # returns `need <kind>` for exactly the one thing it wants next, this loop takes that
  # one and asks again. No branch of the incumbent's tree is decided here.
  local pane="$1" pane_id="$2" handle="$3" to_team="$4" target_registry="${5:-}" policy="${6:-}"
  local answer kind verdict cleared need args=() tmpdir="" rc=0 round cmd=""

  # THE CEILING, stated against the measured path rather than the count of observation kinds.
  # Eight kinds exist, but the LONGEST path takes seven of them — agy under `polite` with an
  # unqualified target: identity, harness, pane-mode, blocked-fields, in-turn-frame,
  # survey-frame, pending — which is eight rounds counting the one that returns the verdict.
  # Nine leaves one round of headroom. An earlier version of this comment said the ceiling was
  # eight while the loop below ran nine (grok-examiner-8, #xxxx gate).
  #
  # Exhausting it is not loud: it falls out below as `busy:decision-unavailable`, a hold that
  # reads like a decision. `spool-readiness.test.ts` counts the longest path and asserts it
  # against this number, so adding an observation kind without raising it reddens there.
  for round in 1 2 3 4 5 6 7 8 9; do
    rc=0
    answer="$(tap_bun_call spool-readiness "$handle" spool-readiness.ts readiness \
      "$pane" "$pane_id" "$handle" "$to_team" "$target_registry" "$policy" \
      ${cleared:+--cleared "$cleared"} "${args[@]}")" || rc=$?
    if [ "$rc" != 0 ]; then
      [ -z "$tmpdir" ] || rm -rf "$tmpdir"
      printf 'busy:decision-unavailable'; return 0
    fi
    # Three lines for a `need`: the word, the kind, and the prefix predicates the module has
    # already evaluated. Handing that third line back is what stops the walk re-reading the
    # registry once per round (sol-pinnacle-1, #xxxx P2) — and, more than cost, what keeps the
    # whole conversation on ONE snapshot of the registry, recovery and fence state, as the
    # incumbent's single pass was.
    { IFS= read -r kind; IFS= read -r verdict || true; IFS= read -r cleared || true; } <<<"$answer"
    case "$kind" in
      verdict)
        [ -z "$tmpdir" ] || rm -rf "$tmpdir"
        printf '%s' "$verdict"; return 0 ;;
      need) need="$verdict" ;;
      *)
        [ -z "$tmpdir" ] || rm -rf "$tmpdir"
        printf 'tap: slice_failed id=%s slice=spool-readiness: invalid answer\n' "$handle" >&2
        printf 'busy:decision-unavailable'; return 0 ;;
    esac
    case "$need" in
      identity)
        # No `|| true` and no stderr redirect: every branch of the identity state prints a
        # reason at rc 0, so a status here is the slice breaking. The incumbent let that
        # kill the deliverer door (`set -euo pipefail`) and read as `gone` in the watcher's;
        # swallowing it would turn a broken slice into an undeliverable seat in both.
        args+=(--identity "$(tap_bound_pane_identity_state "$target_registry" "$handle" "$pane" "$pane_id")") ;;
      harness)
        local _cmd_raw
        _cmd_raw="$(tmux display-message -p -t "$pane" '#{pane_current_command}' 2>/dev/null || true)"
        cmd="$(tap_pane_harness_command "$pane" "$_cmd_raw")"
        args+=(--harness "$cmd") ;;
      pane-mode)
        args+=(--pane-mode "$(tmux display-message -p -t "$pane" '#{pane_in_mode}' 2>/dev/null || true)") ;;
      blocked-fields)
        local _map _exempt
        _map="$(tap_watch_field blocked_map)"; [ -n "$_map" ] || _map="{}"
        _exempt="$(tap_watch_field blocked_exempt)"; [ -n "$_exempt" ] || _exempt="[]"
        args+=(--blocked-map "$_map" --blocked-exempt "$_exempt") ;;
      in-turn-frame|survey-frame|pending)
        [ -n "$tmpdir" ] || tmpdir="$(mktemp -d "${TMPDIR:-/tmp}/tap-readiness.XXXXXX")" \
          || { printf 'busy:decision-unavailable'; return 0; }
        case "$need" in
          in-turn-frame)
            tap_capture_pane -t "$pane" -p > "$tmpdir/in-turn" 2>/dev/null || : > "$tmpdir/in-turn"
            args+=(--in-turn-frame "$tmpdir/in-turn") ;;
          survey-frame)
            tap_capture_pane -t "$pane" -p > "$tmpdir/survey" 2>/dev/null || : > "$tmpdir/survey"
            args+=(--survey-frame "$tmpdir/survey") ;;
          pending)
            local _pending _pending_rc=0
            _pending="$(tap_pending_input_text "$pane" "$cmd" 2>/dev/null)" || _pending_rc=$?
            # THE INCUMBENT'S OWN MAPPING, INCLUDING ITS LAST BRANCH. It tested rc 4 and rc
            # 3 by name and sent EVERY other status — including the rc 1 the reader returns
            # for a broken opencode verdict — down the `[ -n "$pending" ]` path, where an
            # unset variable reads as `ready`. Carried verbatim rather than corrected: a
            # port is not the place to change which panes admit a submit attempt, and the
            # arm that pins it says so. (tap-ilj2m-adjacent; noted in the PR body.)
            case "$_pending_rc" in
              4) args+=(--pending modal) ;;
              3) args+=(--pending no-band) ;;
              # An OpenCode overprint is input-free but needs the bound submit
              # path's one-shot repaint before injection. Admit that attempt;
              # tap_submit_verify_body reclassifies the repaint before typing.
              5) args+=(--pending empty) ;;
              *) if [ -n "$_pending" ]; then printf '%s' "$_pending" > "$tmpdir/pending"; args+=(--pending text --pending-text "$tmpdir/pending")
                 else args+=(--pending empty); fi ;;
            esac ;;
        esac ;;
      band)
        # A refusal to decide is `?`, which the module reads as a band it does not have —
        # `busy:decision-unavailable`, the incumbent's answer when the disposition failed.
        local _band _band_rc=0
        _band="$(tap_spool_observed_band "$pane" "$cmd")" || _band_rc=$?
        [ "$_band_rc" = 0 ] && [ -n "$_band" ] || _band='?'
        args+=(--band "$_band") ;;
      *)
        [ -z "$tmpdir" ] || rm -rf "$tmpdir"
        printf 'tap: slice_failed id=%s slice=spool-readiness: unknown observation %s\n' "$handle" "$need" >&2
        printf 'busy:decision-unavailable'; return 0 ;;
    esac
  done
  [ -z "$tmpdir" ] || rm -rf "$tmpdir"
  printf 'tap: slice_failed id=%s slice=spool-readiness: observations did not converge\n' "$handle" >&2
  printf 'busy:decision-unavailable'
}

# The band half of `tap_slice_delivery_disposition`, which readiness owns natively
# (opus-2, 2026-09-16: its only live callers are readiness and the send path). The
# capture stays here for the same reason as above; `-` is "could not capture", which the
# module reads as unobservable rather than an idle band.
tap_spool_observed_band() { # <pane> <harness> -> a DeliveryBand word
  local frame_file width="" rc=0 band
  frame_file="$(mktemp "${TMPDIR:-/tmp}/tap-band.XXXXXX")" || return 1
  if ! tap_capture_input_frame "$1" "$2" 1 > "$frame_file" 2>/dev/null; then
    rm -f "$frame_file"; frame_file=-
  fi
  case "$2" in claude*) width="$(tmux display-message -p -t "$1" '#{pane_width}' 2>/dev/null || true)" ;; esac
  band="$(tap_bun_call spool-readiness "$1" spool-readiness.ts band "$frame_file" "$2" "$width")" || rc=$?
  [ "$frame_file" = - ] || rm -f "$frame_file"
  [ "$rc" = 0 ] || return 1
  printf '%s' "$band"
}


# Record a drain probe that found the band still busy (tap-nr7b visibility).
# A read-only display snapshot, independent of settlement policy. Reuse the
# courier's readiness predicate; do not count a probe, claim, drain, or rewrite
# metadata. The window test matches the drain's armed-epoch/backward-jump rule.
tap_spool_display_state() { # <id> -> hold|batch|ready|focus|gone|unsafe|unknown
  # Body: runtime/bun/src/spool-readiness.ts `displayRow` + `displayState`. The sidecar
  # read and the mapping are one native call; the readiness verdict is fetched by the
  # adapter above, because only it knows how to observe a pane.
  local row pane pane_id target team registry policy waiting ready
  local now="${TAP_SPOOL_NOW:-$(date +%s)}"
  # ONE sidecar snapshot for the whole mapping. The incumbent's heredoc read the metadata once
  # and carried `waiting` and the binding THROUGH the readiness call; re-opening the file after
  # readiness would map one snapshot's verdict onto another snapshot's hold window if the entry
  # were reparked or rebound in between (sol-pinnacle-1, #xxxx P2).
  row="$(tap_bun_call spool-readiness "$1" spool-readiness.ts display-row "$now" "$(tap_spool_meta_path "$1")")" \
    || { printf unknown; return 0; }
  [ "$row" != unknown ] || { printf unknown; return 0; }
  IFS=$'\x1f' read -r pane pane_id target team registry policy waiting <<< "$row"
  ready=""
  if [ -n "$pane" ] && [ -n "$pane_id" ] && [ -n "$target" ] && [ -n "$registry" ]; then
    ready="$(tap_spool_pane_ready "$pane" "$pane_id" "$target" "$team" "$registry" "$policy" 2>/dev/null || true)"
  fi
  # The incumbent printed the state with NO trailing newline and its callers embed it in
  # a receipt line, so the CLI's newline is stripped rather than passed through.
  local state
  state="$(tap_bun_call spool-readiness "$1" spool-readiness.ts display "$ready" "${waiting:-0}" \
    "$pane" "$pane_id" "$target" "$registry")" || { printf unknown; return 0; }
  printf '%s' "$state"
}


# Only busy:pending increments the wedge counter — busy:noprompt is a healthy
# mid-suite shape and must not accumulate toward the CONDITION.
tap_spool_note_busy_probe() { # <id> <ready-detail>
  tap_bun_call spool-state "$1" spool-state.ts note-busy-probe "$TAP_SPOOL" "$1" "$2" || true
}

# THE FORCED-INJECTION BOUND (ruling 15, leader 2026-09-03, bead tap-7r3fn.13).
#
# Ops watched a conductor's pane flash the courier's warn over and over while she was
# mid-turn. She was not wedged, she was working, and Antigravity queues typed input
# during generation — so every one of those refusals was the courier declining to deliver
# to a seat that would have received it. Holding instead of terminalizing (tap-92v3r) had
# already stopped the courier LYING to senders about it; it did not make the mail arrive.
# His ruling: be more aggressive. After a bounded number of post-deadline observations of
# a live pane, inject anyway.
#
# N = 3, and it is a SEPARATE, DURABLE counter rather than a widening of
# `busy_pending_probes`, for two reasons that both bite. That counter answers "is a typed
# sentinel wedged on the band?" and feeds the backlog CONDITION; widening it would make
# ordinary heads-down mid-suite traffic report as a wedge. And it deliberately ignores
# `busy:noprompt` — the exact class this bound is FOR — so reusing it would have counted
# the one shape it was written to exclude.
#
# WHAT MAY PAY TOWARD THE BOUND is narrow on purpose, because every way of inflating this
# number is a way of forcing early:
#   - POST-DEADLINE only. A pre-deadline look is the entry's ordinary wait.
#   - LIVE only. `gone` and `unsafe` are terminal; a forced inject at a departed pane
#     types into whatever now holds that pane id.
#   - NON-MODAL only. `busy:modal` can never force, so it must not bank credit toward
#     forcing either — otherwise dismissing the dialog on look four forces immediately,
#     with three observations that were never evidence of anything injectable.
#   - A REAL LOOK only. The waiter's rc-1 exit (a drain that refused an unauthorized bus
#     and attempted nothing) is handled before any accounting, so an unauthorized home
#     cannot manufacture the observations that authorize forcing.
tap_spool_force_probe_threshold() { printf '%s' "${TAP_SPOOL_FORCE_PROBES:-3}"; }

# How long a live-probe accounting write waits for the entry's meta lock before skipping
# without counting. Short by design: this runs inside opportunistic drains.
tap_spool_probe_lock_timeout() { printf '%s' "${TAP_SPOOL_PROBE_LOCK_TIMEOUT:-0.5}"; }

tap_spool_note_live_probe() { # <id> <ready-detail>
  tap_bun_call spool-state "$1" spool-state.ts note-live-probe "$TAP_SPOOL" "$1" "$2" "$(tap_spool_probe_lock_timeout)" || true
}

tap_spool_live_probes() { # <id> -> integer
  tap_bun_call spool-state "$1" spool-state.ts live-probes "$TAP_SPOOL" "$1" || printf 0
}

tap_spool_update_held_visits() { # <id> <increment|clear> — fairness only; never waits
  case "${2:-}" in increment|clear) ;; *) return 2 ;; esac
  tap_bun_call spool-state "$1" spool-state.ts update-held-visits "$TAP_SPOOL" "$1" "$2" || true
}

# HERMES IS EXCLUDED, and it is a property of the harness rather than a carve-out.
# Every other supported family queues typed input while generating, so a forced inject
# lands in the queue and is read when the turn ends. hermes bare delivery INTERRUPTS the
# running turn (lib.sh: "hermes is the only family whose default mid-turn behavior is
# INTERRUPT"), and its queue is reached through the `/queue ` prefix rather than by
# typing over the band. Forcing there would not deliver sooner; it would cut a working
# seat off mid-thought, which is the opposite of what the ruling asks for.
tap_spool_force_allowed_for_harness() { # <cmd>
  case "$(tap_harness_family "$1")" in
    hermes) return 1 ;;
    *)      return 0 ;;
  esac
}

# tap-w4f7 Arch 1. A BODY IN spool/ ALWAYS HAS AN OWNER.
#
# `tap_spool_redeliver` moves a body spool -> canonical and, on four distinct
# failure paths, moves it BACK. Those re-parks bypass `tap_spool_add`, which
# normally spawns the deliverer. A watch tick or scoped register recovery may
# then exit without leaving an owner scheduled to revisit the entry. Every
# re-park therefore restores ownership, regardless of which actor drained it.
#
# SPAWN ALWAYS, LET THE CLAIM CAS DEDUPE (kimi's amendment, judging Fork B). The
# tempting shape is "spawn only if no live deliverer for this id" — a pre-check,
# and a new race to manage. It is unnecessary: `tap_spool_claim_acquire` is an
# O_EXCL create with stale-age authority, so a redundant deliverer either claims
# the id and proceeds or loses and exits. Redundant spawns on a wedged pane
# collapse to one claimant plus short-lived losers, each bounded by the
# deliverer's own lifetime bound. The storm is a process-count question, not a
# correctness one — and this framing removes the race instead of managing it.
#
# UNKNOWN IS NOT OWNERSHIP. If we cannot tell whether an entry still has an owner,
# that is neither "owned" nor "ownerless": we spawn anyway, because the CAS makes
# a wrong guess cost one short-lived process, while the opposite wrong guess is
# the silence this bead exists to end.
tap_spool_reown_after_repark() { # <id> — every path that returns a body to spool/
  # The mint (payload-present/unknown check, freshness, token) is native; the token
  # reaches the deliverer by ENV, not argv (it consumes `$@` as its cadence list).
  local lease
  lease="$(tap_bun_call spool-reown "$1" spool-reown.ts after-repark "$TAP_SPOOL" "$1" "${TAP_SPOOL_REOWN_LEASE_SECONDS:-20}")" || return 0
  [ -n "$lease" ] || return 0
  TAP_SPOOL_REOWN_TOKEN="$lease" tap_spool_spawn_deliverer "$1"
  return 0
}

# tap-ncd4: TAP_HOME sandboxes the SPOOL location only. `pane`, `pane_id` and
# `target_registry` are plain ARGUMENTS, untouched by redirecting TAP_HOME — so
# a caller who sandboxed TAP_HOME (e.g. `TAP_HOME=$(mktemp -d)` to probe a pane
# effect function in isolation) but passed real, stored specimen arguments
# still resolved and injected into a REAL live pane, rc=0, no warning. Live
# incident: a probe did that to `tap/gemini:0.0`.
#
# REJECTED: a path-shape check (`<root>/.tap/bus` / `<root>/tmp/tap`). Two
# independent decorrelated reviewers broke it in both directions —
# CONTRACT.md's bus-layout resolution explicitly supports an arbitrary,
# non-canonically-shaped custom TAP_HOME as a first-class production
# deployment, so the shape check made the override the thing every genuine
# custom-home deployment must set (ambient, i.e. exactly the incident class
# it exists to prevent); and a sandbox trivially wins by naming itself
# `.../.tap/bus`, which one reviewer demonstrated live.
#
# THE MARKER instead: `tap_ensure_dirs` — the one function every real bus
# passes through before anything is written to it (`tap-send.sh` calls it
# unconditionally before parking or delivering) — stamps
# `$TAP_HOME/$TAP_SPOOL_HOME_AUTHORITY_MARKER` the first time a bus is
# bootstrapped. A production bus, canonical-shaped or custom-home, is stamped
# for free the moment any real `tap` verb touches it — no operator action, no
# override. A bare directory nobody ever ran `tap` against (a probe's
# `TAP_HOME=$(mktemp -d)` with hand-copied specimen files, never bootstrapped)
# has no marker and is refused by default. Ceiling, stated honestly: this is
# an INTENT gate, not a provenance proof — a prober who reads this comment can
# `touch` the marker or the override just as before. What it buys is that
# genuine use never has to.
TAP_SPOOL_HOME_AUTHORITY_MARKER=".tap-bus-authority"

tap_spool_home_authorized() { # <tap_home>
  local home="${1:-}"
  [ -n "$home" ] || return 1
  [ -f "$home/$TAP_SPOOL_HOME_AUTHORITY_MARKER" ] && return 0
  [ "${TAP_SPOOL_PANE_EFFECTS_UNSTAMPED_HOME_OK:-0}" = "1" ]
}

tap_spool_home_authorized_or_warn() { # <caller-label>
  tap_spool_home_authorized "${TAP_HOME:-}" && return 0
  # tap-zuj7 shape (named by grok-examiner, PR #xxx round 2): lead the hint
  # with the SAFE remedy — a caller probing real specimen args against a
  # sandbox almost certainly wants to bootstrap it, not bypass the guard
  # that exists because of exactly that probe. The override is real and
  # stays available, but it is not what a confused reader should reach for
  # first.
  echo "tap: $1 refused — TAP_HOME '${TAP_HOME:-}' carries no $TAP_SPOOL_HOME_AUTHORITY_MARKER (never bootstrapped by a real tap verb); run 'tap_ensure_dirs' against this TAP_HOME first if it should be a real bus. Only if this is a deliberate hermetic caller that must inject without bootstrapping, set TAP_SPOOL_PANE_EFFECTS_UNSTAMPED_HOME_OK=1 (tap-ncd4)" >&2
  return 1
}

tap_delivery_attempt_begin() { # <id> — a write failure must stop the attempt
  local verdict
  # Current-call provenance only: survey recovery must distinguish this newly
  # admitted attempt from an existing possible-effect marker. Never overwrite it.
  export TAP_DELIVERY_NEW_ATTEMPT=""
  verdict="$(tap_bun_call attempt-evidence "$1" delivery-attempt.ts begin "$TAP_HOME" "$1")" || return 1
  case "$verdict" in
    created) TAP_DELIVERY_NEW_ATTEMPT="$1" ;;
    existing) ;;
    *) return 1 ;;
  esac
}

# Admit possible-effect evidence at the first pane effect, after every retry-safe
# compositor precheck. Courier callers supply one payload id or every digest
# member; non-courier users of the shared submit primitive create no receipt.
# Repeated calls in one submit are intentionally free.
tap_delivery_effect_begin() { # <current-id>
  [ "${TAP_DELIVERY_EFFECT_STARTED:-0}" = 1 ] && return 0
  local current="$1" attempt_id newly_created="" attempts="${TAP_DELIVERY_ATTEMPT_IDS:-}"
  [ -n "$attempts" ] || { TAP_DELIVERY_EFFECT_STARTED=1; return 0; }
  for attempt_id in $attempts; do
    tap_delivery_attempt_begin "$attempt_id" || {
      echo "tap: cannot record attempt before pane effect; refusing to touch the pane" >&2
      return 1
    }
    [ "$TAP_DELIVERY_NEW_ATTEMPT" != "$current" ] || newly_created="$current"
  done
  export TAP_DELIVERY_NEW_ATTEMPT="$newly_created"
  TAP_DELIVERY_EFFECT_STARTED=1
}

# Debug is a live machine setting, not an environment inherited at helper startup.
tap_debug_enabled() { [ -f "${TAP_INDEX_HOME:-$HOME/.tap}/debug/enabled.json" ]; }

# Same submit and outcome table as before; diagnostics never select a driver or retry.
tap_debug_spool_submit() {
  local payload="$1" id="$2" members="$3"; shift 3
  local detail_file rc=0 started ended outcome disposition effect tier detail
  if ! tap_debug_enabled; then
    tap_submit_verify "$@" 2>/dev/null
    return $?
  fi
  detail_file="$(mktemp "${TMPDIR:-/tmp}/tap-debug-submit.XXXXXX")" || {
    echo 'tap debug: cannot capture courier detail' >&2
    tap_submit_verify "$@" 2>/dev/null
    return $?
  }
  started="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  tap_submit_verify "$@" 2>"$detail_file" || rc=$?
  ended="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  detail="$(cat "$detail_file")"
  rm -f "$detail_file"
  [ -z "$members" ] || detail="members=[$members] $detail"
  outcome="$(tapdrv_tmux_outcome "$rc")"
  IFS=$'\x1f' read -r disposition effect tier <<< "$outcome"
  # Diagnostic summaries are not retry-authority records. In particular a
  # legacy-shaped pre-effect row must never make native delivery refuse a retry.
  tap_attempt_append "${payload%.md}.debug.md" "$id" 1 deliver tmux queue "$disposition" "$effect" "$tier" \
    "$detail" "$started" "$ended" || true
  return "$rc"
}

# stdin is an already observed frame. No extra pane read at failure time.
tap_debug_submit_frame() {
  tap_debug_enabled || return 0
  local error
  error="$(
    [ ! -t 0 ] || exec </dev/null
    TAP_HOME="$TAP_HOME" BUN_RUNTIME_TRANSPILER_CACHE_PATH=0 exec bun "$_TAP_SCRIPT_DIR/../../../runtime/bun/src/debug-capture.ts" _frame "$@" 2>&1
  )" || true
  [ -z "$error" ] || printf '%s\n' "$error" >&2
  return 0
}

tap_spool_redeliver() ( # Direct callers own only the exact-id obligation lock.
  tap_obligation_lock "$1" 0 || return 1
  tap_spool_redeliver_locked "$@"
)

# Internal: caller holds the obligation lock; Phase B also holds the spool claim.
# The subshell confines submit/repark state, without reacquiring the caller's lock.
tap_spool_redeliver_locked() (
  local id="$1" handle="$2" pane="$3" pane_id="$4" to_team="$5" target_registry="${6:-}" spool_payload canon cmd_raw cmd sentinel rc cm_rc=0 cm_effect="" eligibility reprobe_only=0
  eligibility="$(tap_bun_call redelivery-eligibility "$id" slices/redelivery-eligibility.ts "$TAP_HOME" "$id")" || return 1
  case "$eligibility" in
    eligible) ;;
    settled-before-delivery|settled-after-delivery-attempt|cancelled-before-delivery|cancelled-after-delivery-attempt)
      tap_registry_event_append_or_warn courier redelivery_skipped "$handle" "$pane" "id=$id reason=$eligibility effect=none"
      return 0 ;;
    *) return 1 ;;
  esac
  spool_payload="$(tap_spool_payload_path "$id")"; canon="$(tap_payload_path "$id")"
  [ -f "$spool_payload" ] || return 1
  [ -n "$pane" ] && [ -n "$pane_id" ] && [ -n "$target_registry" ] || return 1
  tap_spool_home_authorized_or_warn tap_spool_redeliver || return 1
  tap_registry_matches_team "$target_registry" "$to_team" \
    || { tap_spool_mark_legacy_no_binding "$id"; return 1; }
  [ "$(tap_bound_pane_identity_state "$target_registry" "$handle" "$pane" "$pane_id")" = match ] || return 1
  tap_clear_fence_inspect "$handle" "$(tap_clear_fence_bus "$target_registry")"
  [ "${TAP_CLEAR_FENCE_STATE:-absent}" = live ] && return 1
  cm_effect="$(tap_exit_copy_mode "$pane" "$target_registry" "$handle" "$pane_id" "" "" "$id" 2>/dev/null)" || cm_rc=$?
  [ "$cm_rc" = 0 ] || return 1
  if [ "$cm_effect" = effect ]; then
    export TAP_DELIVERY_NEW_ATTEMPT="$id"
  fi
  mv -f "$spool_payload" "$canon" 2>/dev/null || return 1
  cmd_raw="$(tmux display-message -p -t "$pane" '#{pane_current_command}' 2>/dev/null || true)"
  cmd="$(tap_pane_harness_command "$pane" "$cmd_raw")"
  sentinel="$(tap_reconstruct_sentinel "$canon" 2>/dev/null || true)"
  [ -n "$sentinel" ] || { mv -f "$canon" "$spool_payload" 2>/dev/null || true; tap_spool_reown_after_repark "$id"; return 1; }
  tap_registry_matches_team "$target_registry" "$to_team" \
    || { mv -f "$canon" "$spool_payload" 2>/dev/null || true; tap_spool_mark_legacy_no_binding "$id"; tap_spool_reown_after_repark "$id"; return 1; }
  [ "$(tap_bound_pane_identity_state "$target_registry" "$handle" "$pane" "$pane_id")" = match ] \
    || { mv -f "$canon" "$spool_payload" 2>/dev/null || true; tap_spool_reown_after_repark "$id"; return 1; }
  rc=0
  # The transition carve-out is submit-in-place authority, never retry-inject
  # authority. The submit body refuses if this exact sentinel is no longer there.
  tap_submit_reprobe_pending "$id" && reprobe_only=1
  TAP_DELIVERY_ATTEMPT_IDS="$id" TAP_SUBMIT_REPROBE_ONLY="$reprobe_only" tap_debug_spool_submit "$canon" "$id" "" "$pane" "$cmd" "$sentinel" "$id" "$handle" 0 id \
    "$target_registry" "$handle" "$pane_id" || rc=$?
  case "$rc" in
    0) tap_spool_note_redelivered "$id" "$canon" "$handle" "$pane" "$target_registry"; tap_spool_remove "$id"; return 0 ;;
    7)
      tap_bun_call harness-queue "$id" harness-queue.ts record "$TAP_HOME" "$id"
      tap_spool_remove "$id"; return 0 ;;
    5|124)
      # The sentinel may still be staged in the live input. Keep the canonical
      # payload but retire this automatic-delivery obligation: re-spooling would
      # re-inject the same id indefinitely. Record the condition durably because
      # foreground opportunistic drains intentionally suppress their own output.
      tap_registry_event_append_or_warn courier redelivery_submit_unverified \
        "$handle" "$pane" "id=$id"
      tap_spool_remove "$id"
      printf "tap: redelivery id '%s' is canonical but submit-unverified; automatic retry stopped to avoid duplicate injection\n" "$id" >&2
      return "$rc"
      ;;
    *)
      mv -f "$canon" "$spool_payload" 2>/dev/null || true; tap_spool_reown_after_repark "$id"
      if [ "$rc" = 4 ] && [ "${TAP_SUBMIT_DEFER_REASON:-}" = lock-park ]; then
        local lock_detail
        lock_detail="$(tap_bun_call lock-attribution "$id" lock-attribution.ts \
          "$(tap_spool_meta_path "$id")" "$(tap_pane_submit_lock_path "$pane_id")")" \
          || lock_detail='reason=lock-park; holder attribution unavailable'
        tap_spool_notify_sender_on_escalate "$id" "$handle" "$lock_detail" "$target_registry" \
          lock-park "$id-lock-park" || true
      fi
      return 1 ;;
  esac
)

# tap_spool_note_redelivered <id> <canonical> <to-handle> <pane> [<target_registry>]
# Called on tap_spool_redeliver's rc-0 arm only, BEFORE tap_spool_remove.
#
# Until tap-dnub (2026-09-01) a verified redelivery left exactly this trace:
# `.placed` only, no `.sent`, no registry line, no deliver-log line, spool entry
# gone — byte-for-byte the trace of the 2026-09-01 specimens whose sentinels
# never rendered (K1's joined re-grep, history intact). Reproduced live: a
# parked send redelivered on idle DID render as a submitted user message and
# left that same trace (lane K3, claude-C, …214124Z-891c8916d261). So the trace
# said nothing: success and disappearance were indistinguishable after the fact.
#
# This writes the same `.sent` the direct path writes (from/kind read from the
# promoted canonical's frontmatter; to/pane are the bound target the submit was
# verified against; delivery=pane because a pane was touched) and a NEW
# `redelivery_delivered` registry event. The event is new observability, not
# symmetry: the direct path writes `.sent` and no success event. Neither write
# is a recipient-processing claim — `.sent` still means "the id left the input
# band" and nothing more (CONTRACT §turn=unconfirmed).
#
# Best-effort by construction: the receipt write runs in a subshell so a
# failed atomic write (tap_atomic_write dies) cannot abort the deliverer
# between a verified submit and tap_spool_remove — that gap would leave the
# entry spooled and re-inject a sentinel that already left the band, the exact
# duplicate the rc-5 arm exists to avoid. The rc-0 disposition is unchanged
# whether or not the receipt or event lands; the warning is the only signal.
#
# NEAR MISS, recorded so it is not tidied back in: the brief's shape 2/3 — a
# `queued-in-harness` submit outcome that re-probes the transcript at turn end
# and re-injects when the sentinel is absent — was NOT built. No causal loss
# specimen exists (the codex queued chip survived a prose-only turn end in the
# 2026-09-01 control), and no-retry-after-possible-effect forbids a re-inject
# whose pre-effect proof is a chip's absence rather than a transcript read.
tap_spool_note_redelivered() {
  local id="$1" canon="$2" handle="$3" pane="$4" target_registry="${5:-}" from kind
  from="$(tap_envelope_field "$canon" from 2>/dev/null || true)"
  kind="$(tap_envelope_field "$canon" kind 2>/dev/null || true)"
  ( tap_write_sent_receipt "$id" "${from:-unknown}" "$handle" "$pane" "${kind:-unknown}" pane ) 2>/dev/null \
    || printf 'tap: WARNING — redelivery of %s verified but its .sent receipt could not be written\n' "$id" >&2
  # tap-7r3fn.20: this is a verified pane injection, so it resets the recipient's
  # window exactly as a direct send does. Reached only from the rc-0 arm; rc 5
  # takes a different branch and deliberately does not stamp.
  tap_delivery_clock_stamp "$target_registry" "$handle"
  tap_registry_event_append_or_warn courier redelivery_delivered "$handle" "$pane" "id=$id"
}

# --- compaction handoff (tap-joqz) --------------------------------------------
# An explicit /compact CONSUMES the turn that submitted it: the harness ends that
# turn, and with no inbound traffic nothing starts the next one. Whatever resumes
# afterward reads a SUMMARY — precisely the artifact that cannot be trusted to
# have carried in-flight work. So the agent writes itself a handoff file BEFORE
# the compact is submitted, and the resume ping names that path. Sibling of
# spool/ and watch/ under the bus.
#
# NOT owed by AUTO-compaction. When the harness compacts on its own (context
# fill) it re-invokes and the turn resumes unaided; only the EXPLICIT path
# (/self compact, tap command compact) ends a turn with nothing to restart it.
# Recorded because the distinction is an expensive one to rediscover: anyone who
# "tests compaction" by letting a session fill up observes a clean auto-resume
# and concludes this bug is fixed or never existed.

# tap_handoff_path <seat> — canonical path for a handoff written NOW.
tap_handoff_path() {
  local safe
  # A cross-team address ("team/handle") — or any other separator — must not be
  # able to walk out of the handoff directory.
  safe="$(printf '%s' "$1" | tr -c '[:alnum:]._-' '-')"
  printf '%s/%s-%s.md' "$TAP_HANDOFF" "$safe" "$(date -u +%Y%m%dT%H%M%SZ)"
}

# tap_handoff_write <seat> — body on stdin; prints the absolute path written.
tap_handoff_write() {
  local seat="$1" dest
  dest="$(tap_handoff_path "$seat")"
  mkdir -p "$TAP_HANDOFF" || return 1
  {
    printf '# TAP compaction handoff — %s\n' "$seat"
    printf '# written %s, BEFORE an explicit /compact\n#\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    printf '# You are reading this after a compaction. Your context is a SUMMARY of\n'
    printf '# the work; these bytes were written by the agent that still had all of\n'
    printf '# it. Where the two disagree, this file is the record.\n\n'
    cat
  } | tap_atomic_write "$dest" || return 1
  tap_reset_generation_touch "handoff"
  printf '%s' "$dest"
}

# tap_beads_reachable <dir> — would `bd` find a database from this directory?
# Written with `||` rather than `&&` so it stays safe under `set -e` if it is
# ever called outside a condition: a bare `[ ... ] && return 0` whose test fails
# is a failing statement, and would abort the caller.
tap_beads_reachable() {
  local dir="$1"
  [ -z "${BEADS_DIR:-}" ] || return 0
  while [ -n "$dir" ] && [ "$dir" != "/" ]; do
    [ ! -d "$dir/.beads" ] || return 0
    dir="$(dirname "$dir")"
  done
  return 1
}

# tap_handoff_ping <handoff-path> [seat] [pane] [focus] — the one-line resume prompt.
# DEIXIS-FREE BY CONSTRUCTION: it lands where "this", "the above", and "what you
# were doing" resolve to nothing, so every reference is an absolute path or a
# runnable command. It also never asks the agent to RECALL, because the summary
# is the unreliable artifact — it points only at durable state. <pane> is used
# only to resolve the TARGET's cwd, so the commands named are checked against the
# pane that will run them rather than the one that composed the ping.
# [focus] carries the caller's own focus text across the compaction INLINE
# (tap-thgv). On a deferred harness the focus cannot ride the `/compact` line,
# and it no longer rides a capsule file either — this ping is the rail. The
# clause is verbatim: a focus paraphrased on the way through is not the focus.
tap_handoff_ping() {
  local path="$1" seat="${2:-}" pane="${3:-}" focus="${4:-}" poll="" lead="" beads="" cwd="" focus_clause=""
  [ -z "$seat" ] || poll=" Run 'tap poll ${seat}' and settle or answer anything unsettled."
  # EVERY COMMAND NAMED HERE MUST BE RUNNABLE BY THE READER WHO RECEIVES IT.
  # This ping is remediation text handed to a freshly-compacted agent that has
  # little else to go on and will trust it, so a command that errors is worse
  # than one that was never offered — it burns the one instruction it was given.
  # `bd ready` fails with "no beads database found" from any pane whose cwd has
  # no .beads, and the poll clause above is likewise emitted only for a handle
  # that is genuinely registered.
  if [ -n "$pane" ]; then
    cwd="$(tmux display-message -p -t "$pane" '#{pane_current_path}' 2>/dev/null || true)"
  fi
  [ -n "$cwd" ] || cwd="$PWD"
  if command -v bd >/dev/null 2>&1 && tap_beads_reachable "$cwd"; then
    beads=" and 'bd ready'"
  fi
  if [ -n "$path" ]; then
    lead="Read ${path} first — it is a handoff written to you, before compacting, by the agent that still had the full context."
  else
    # panel ruling: ALWAYS arm, never conditionally — the agent decides whether
    # work remains, not the arming logic. So a compact with no handoff still
    # gets a ping; it just cannot point at one, and says so rather than
    # implying the summary is complete.
    lead="No handoff file was written before this compaction, so treat your summary as lossy rather than authoritative."
  fi
  [ -z "$focus" ] || focus_clause=" Focus written for you BEFORE this compaction, by the agent that still had the full context: ${focus}"
  printf "Post-compaction resume check. %s%s%s Check your task list%s for work already claimed. If work is in progress or owed, continue it without waiting to be asked. If nothing is in progress, reply 'nothing in progress' and end the turn." "$lead" "$focus_clause" "$poll" "$beads"
}

# --- courier digest (tap-ix63) ------------------------------------------------
# When a spool drain finds N>=2 plain-redeliverable entries bound to the SAME
# recipient, the courier injects ONE `kind=digest` sentinel whose id resolves to a
# courier-owned index listing those N payloads. N wakes collapse to 1 doorbell;
# every listed payload keeps its own reply=, receipts, and `tap outstanding`
# visibility (the digest is a DELIVERY ENVELOPE, never a settleable obligation).
# The index is derived from TAP_HOME (not the cached TAP_SPOOL) so it stays correct
# after a --team bus override, which re-roots TAP_HOME but not TAP_SPOOL.
tap_digest_dir()        { printf '%s/spool/digests' "$TAP_HOME"; }
tap_digest_index_path() { printf '%s/%s.json' "$(tap_digest_dir)" "$1"; }
# A digest id is one whose courier-owned index still exists — the settle-refusal
# and retention checks key on this, never on the `courier-` id prefix.
tap_digest_is_index()   { [ -f "$(tap_digest_index_path "$1")" ]; }



# Resolve the complete decision table before any possible pane effect.
# Rows are fixed-order (0, 5, 124, 7, other); Bash validates and selects, never defaults.

# The digest transaction. P0 (ratified): claim=snapshot (CAS via the per-id .claim
# sidecars blocks double-flush); SUBMIT-THEN-MOVE (spool copies stay in place until
# the submit verifies, so a crash never half-canonicalizes a subset without a
# doorbell); inject failure discards the index and leaves every entry individually
# redeliverable. Returns 0 on a verified digest, 5 or 124 when submission is unverified or timed out
# after canonicalization, 2 if fewer than 2 entries survive revalidation (caller
# lets the per-id path handle the survivors), 1 on any other failure.
# The sender-notice loop the digest transaction triggers. RETAINED IN BASH, deliberately:
# its body is a loop over two SHARED effects — `tap_spool_claim_acquire` and
# `tap_spool_notify_sender_on_escalate`, which has three other production callers — around
# a grouping door (`notice.ts digest-groups`) that is already native. Porting it would move
# the claim-name string and nothing else, while forcing the NUL-separated group wire through
# a second process boundary that bash command substitution cannot carry. It is also the entry
# point `digest-sender-notices.test.sh` drives directly in its re-entry arm.
tap_spool_notify_digest_senders() ( # <digest-id> <target> <registry> <member-ids...>
  local digest_id="$1" target="$2" registry="$3" plan header sender members id notice detail rc=0
  shift 3
  [ "$#" -gt 0 ] || return 0
  plan="$(mktemp "${TMPDIR:-/tmp}/tap-digest-notices.XXXXXX")" || return 1
  trap 'rm -f "$plan"' EXIT
  tap_bun_call digest-notices "$digest_id" notice.ts digest-groups "$TAP_PAYLOADS" "$TAP_RECEIPTS" "$@" > "$plan" || return 1
  while IFS= read -r header && IFS= read -r -d '' detail; do
    sender="${header%% *}"; members="${header#* }"; id="${members%% *}"
    notice="$digest_id-$sender-delivery-unconfirmed"
    # The stable group claim also covers re-entry with a different live member.
    tap_spool_claim_acquire "$notice" no-steal || { rc=1; continue; }
    tap_spool_notify_sender_on_escalate "$id" "$target" "$detail" "$registry" \
      unconfirmed "$notice" "$members" || rc=1
    tap_spool_claim_release "$notice"
  done < "$plan"
  return "$rc"
)

# Release the claims this transaction's ledger names, in PURE BASH.
#
# THE ABORT DOOR CANNOT BE THE ONLY RELEASE PATH, because it rides `tap_bun_call`: a missing
# or broken runtime takes the cleanup out with the thing it was cleaning up after
# (glm53-blaze-examiner-7, #xxxx finding 2b). The incumbent was structurally immune — its
# release was `rm -f` with no record and no runtime between it and the file — and this
# restores that property rather than narrowing the window again.
#
# It decides nothing: the ledger names ids the walk acquired, and this removes exactly their
# claim files. An id it never acquired is not in the file, so this can never reach a
# sibling's claim. Running it after the door is harmless — claim release is idempotent.
tap_spool_digest_release_ledger() { # <ledger-path>
  local _id
  [ -f "$1" ] || return 0
  while IFS= read -r _id || [ -n "$_id" ]; do
    [ -n "$_id" ] || continue
    tap_spool_claim_release "$_id"
  done < "$1"
  rm -f "$1"
}

tap_spool_digest_inject() { # <target_registry> <to_team> <handle> <pane> <pane_id> <id1> <id2> [...]
  # Body: runtime/bun/src/spool-digest-inject.ts `digestInjectStep` — the whole
  # transaction. What stays here is OBSERVATION and EFFECT, on A3a's ratified boundary:
  # the walk names the one thing it wants next, this loop fetches or performs exactly that
  # and hands back the answer. No branch of the incumbent's transaction is decided here.
  #
  # THE AUTHORITY GATE STAYS AHEAD OF THE DOOR (tap-ncd4, charter rule 3). A digest is a
  # pane effect, and P1 review found this door delivering from a non-canonical TAP_HOME
  # with the redeliver-only guard in place. It is a shared refusal with production callers
  # on the drain entry and on redeliver, so it is not absorbed into the port — the same
  # placement A3a gave the clear-fence pre-check.
  local target_registry="$1" to_team="$2" handle="$3" pane="$4" pane_id="$5"; shift 5
  tap_spool_home_authorized_or_warn tap_spool_digest_inject || return 1

  local state kind id rc=0 round ceiling answer="" cmd="" line
  state="$(mktemp "${TMPDIR:-/tmp}/tap-digest-inject.XXXXXX")" || return 1

  # The record round-trips as this file and this loop never opens it. The ceiling is a
  # FUNCTION OF THE BATCH, not a constant: revalidation spends up to two observations per
  # claimed entry (matches-team, identity), and the fixed rounds are five — begin, readiness,
  # harness, submit, notify — with the verdict riding the last of them rather than costing a
  # round of its own. The longest real path is 2N + 5 against a ceiling of 2N + 8; this
  # comment used to say six, which was wrong in the harmless direction and is still wrong.
  ceiling=$(( ( $# * 2 ) + 8 ))
  local -a args=(--begin "$TAP_HOME" "$TAP_SPOOL" "$TAP_PAYLOADS" "$TAP_RECEIPTS" \
    "$(tap_spool_team_name)" "$TAP_COURIER_IDENTITY" "$target_registry" "$to_team" \
    "$handle" "$pane" "$pane_id" "$@")

  for (( round = 0; round < ceiling; round++ )); do
    rc=0
    answer="$(tap_bun_call spool-digest-inject "$handle" spool-digest-inject.ts \
      --state "$state" "${args[@]}")" || rc=$?
    if [ "$rc" != 0 ]; then
      # The slice broke. Release what the record still holds rather than leaving the batch
      # claimed for a drainer that will never come back for it, then refuse.
      tap_bun_call spool-digest-inject "$handle" spool-digest-inject.ts --state "$state" --spool "$TAP_SPOOL" --abort >/dev/null 2>&1 || true
      tap_spool_digest_release_ledger "$state.claims"
      rm -f "$state" "$state.claims" "$state.next"
      return 1
    fi
    args=()
    { IFS= read -r kind; IFS= read -r line || true; } <<<"$answer"
    case "$kind" in
      "need readiness")
        args=(--readiness "$(tap_spool_pane_ready "$pane" "$pane_id" "$handle" "$to_team" "$target_registry")") ;;
      "need matches-team")
        id="$line"
        if tap_registry_matches_team "$target_registry" "$to_team"; then args=(--matches-team 1); else args=(--matches-team 0); fi ;;
      "need identity")
        id="$line"
        args=(--identity "$(tap_bound_pane_identity_state "$target_registry" "$handle" "$pane" "$pane_id")") ;;
      "need harness")
        local _cmd_raw
        _cmd_raw="$(tmux display-message -p -t "$pane" '#{pane_current_command}' 2>/dev/null || true)"
        cmd="$(tap_pane_harness_command "$pane" "$_cmd_raw")"
        args=(--harness "$cmd") ;;
      "need submit")
        local _payload _did _members _spane _sentinel _shandle _sreg _spid _attempts _preserve_draft
        local _table _row _key _canon _stamp _notify _result _event _diag _count=0 _sid _trow _last
        IFS=$'\x1f' read -r _payload _did _members _spane _sentinel _shandle _sreg _spid _attempts _preserve_draft <<< "$line"
        # THE DECISION TABLE ARRIVES WITH THE REQUEST, and is validated BEFORE a single
        # `.attempted` marker exists — the incumbent's `tap_slice_digest_outcome` refusal,
        # restored: a malformed table releases the claims, removes the index and refuses while
        # refusing is still free, because after the submit it is not.
        _table="$(printf '%s\n' "$answer" | tail -n +3)"
        while IFS=$'\x1f' read -r _key _canon _stamp _notify _result _event _diag; do
          _count=$((_count + 1))
          case "$_count:$_key" in 1:0|2:5|3:124|4:7|'5:*') ;; *) _count=0; break ;; esac
          case "$_canon:$_stamp:$_notify" in [01]:[01]:[01]) ;; *) _count=0; break ;; esac
          case "$_result" in 0|1|5|124) ;; *) _count=0; break ;; esac
          case "$_event" in digest|redelivery_submit_unverified|redelivery_submit_timeout|digest_inject_failed) ;; *) _count=0; break ;; esac
        done <<< "$_table"
        if [ "$_count" != 5 ]; then
          printf 'tap: slice_failed id=%s slice=spool-digest-inject: invalid decision table\n' "$_did" >&2
          rm -f "$(tap_digest_index_path "$_did")"
          tap_bun_call spool-digest-inject "$handle" spool-digest-inject.ts --state "$state" --spool "$TAP_SPOOL" --abort >/dev/null 2>&1 || true
          tap_spool_digest_release_ledger "$state.claims"
          rm -f "$state" "$state.claims" "$state.next"
          return 1
        fi
        {
          # The submit body mints member markers at its first pane effect. A
          # pre-effect refusal therefore leaves every member retry-owned.
          rc=0
          TAP_DELIVERY_ATTEMPT_IDS="$_attempts" TAP_SUBMIT_PRESERVE_DRAFT="${_preserve_draft:-1}" tap_debug_spool_submit "$_payload" "$_did" "$_members" \
            "$_spane" "$cmd" "$_sentinel" "$_did" "$_shandle" 0 id \
            "$_sreg" "$_shandle" "$_spid" || rc=$?
          # CUSTODY IS APPLIED HERE, IN THE SHELL THAT OBSERVED THE EFFECT — the property the
          # incumbent had and this port had lost (rule 54). The row is pre-decided; this loop
          # selects it by status and performs it, with no branch of its own. Everything AFTER
          # custody — notify, stamp, queue record, events, the verdict — stays in the next
          # native round, where a runtime death costs telemetry and a sender notice, exactly
          # what a shell death cost the incumbent at the same point, and never custody.
          # ROW SELECT IN THE SHELL, NOT IN AWK. `awk -F'\x1f'` does not mean the byte here:
          # BSD awk reads the two characters literally, so the whole row stayed ONE field, no
          # key ever matched, and every submit fell through to the generic failure row — a
          # verified digest would have skipped custody entirely. The (0c) arm caught it on its
          # first run, which is what that arm is for.
          _row=""; _last=""
          while IFS= read -r _trow; do
            [ -n "$_trow" ] || continue
            _last="$_trow"
            case "$_trow" in "$rc"$'\x1f'*) _row="$_trow"; break ;; esac
          done <<< "$_table"
          [ -n "$_row" ] || _row="$_last"
          IFS=$'\x1f' read -r _key _canon _stamp _notify _result _event _diag <<< "$_row"
          if [ "$_canon" = 1 ]; then
            for _sid in $_members; do
              mv -f "$(tap_spool_payload_path "$_sid")" "$(tap_payload_path "$_sid")" 2>/dev/null || true
              # `|| true` because `rm -f` FAILS on a directory and the incumbent continued —
              # it ran where errexit was suppressed for its whole body, so the digest completed.
              # Moving the rm into this loop moved it next to a `tap_spool_digest_release_ledger`
              # that must still run: a member whose sidecar cannot be removed must not be able to
              # strand the ledger after a verified submit (grok-examiner-8, #xxxx).
              rm -f "$(tap_spool_meta_path "$_sid")" || true
            done
            # Releasing every claim and retiring the ledger are the same operation, for the
            # reason unit 6 established: a ledger that outlives the claims it names is a list
            # of somebody else's claims.
            tap_spool_digest_release_ledger "$state.claims"
          fi
          args=(--submit-rc "$rc")
        } ;;
      "need notify-senders")
        # Exit 5/124 is ATTEMPTED, not confirmed. The index already says the truthful thing
        # (nothing was pre-settled), so nothing is rewritten — what is owed is the sender,
        # because rc 5 also drops the spool meta and stops automatic retry, taking the
        # delivery deadline with it. The notice says UNCONFIRMED, never failed: the courier
        # cannot observe which happened. Its own grouping keeps the NUL-separated wire that
        # a command substitution here could not carry.
        local _did _target _registry _ids
        IFS=$'\x1f' read -r _did _target _registry _ids <<< "$line"
        tap_spool_notify_digest_senders "$_did" "$_target" "$_registry" $_ids || true
        args=(--notified) ;;
      "done "*)
        # Two lines of verdict, then one row per registry-event append. Warnings were
        # already written to stderr by the door, in the incumbent's bytes.
        local _rcout="${kind#done }" _stamp="$line" _tag _a _b _c _d _e _f
        [ "$_stamp" != 1 ] || tap_delivery_clock_stamp "$target_registry" "$handle"
        while IFS=$'\x1f' read -r _tag _a _b _c _d _e _f; do
          [ "$_tag" = event ] || continue
          if [ "$_f" = 1 ]; then
            tap_registry_event_append_or_warn "$_a" "$_b" "$_c" "$_d" "$_e"
          else
            tap_registry_event_append "$_a" "$_b" "$_c" "$_d" 2>/dev/null || true
          fi
        done <<<"$(printf '%s\n' "$answer" | tail -n +3)"
        rm -f "$state" "$state.claims" "$state.next"
        return "$_rcout" ;;
      *)
        tap_bun_call spool-digest-inject "$handle" spool-digest-inject.ts --state "$state" --spool "$TAP_SPOOL" --abort >/dev/null 2>&1 || true
        tap_spool_digest_release_ledger "$state.claims"
        rm -f "$state" "$state.claims" "$state.next"
        printf 'tap: slice_failed id=%s slice=spool-digest-inject: invalid answer\n' "$handle" >&2
        return 1 ;;
    esac
  done

  tap_bun_call spool-digest-inject "$handle" spool-digest-inject.ts --state "$state" --spool "$TAP_SPOOL" --abort >/dev/null 2>&1 || true
  tap_spool_digest_release_ledger "$state.claims"
  rm -f "$state" "$state.claims" "$state.next"
  printf 'tap: slice_failed id=%s slice=spool-digest-inject: rounds did not converge\n' "$handle" >&2
  return 1
}

# Stamp the moment the doorbell verifiably injected (tap-31it). Written AFTER the
# submit, so it can only ever describe a delivery that happened; the index itself
# must exist before the submit because the sentinel's path= names it.

# Retention GC requires every item terminal AND the pointer lifetime elapsed.
# Verified auto-settle digests use their injection stamp (or an auto-receipt
# mtime if stamping failed). Ordinary and unverified indexes use publication
# mtime when no delivery witness exists: a failed submit can leave its sentinel
# staged after the items are settled separately. This timestamp is retention
# evidence only, never proof of injection. Settled rows without any delivery
# witness remain retained rather than guessed terminal on age alone.
#
# WHY A TIME PROXY AND NOT A READ WITNESS (kimi, tap-31it — the cheaper designs
# were measured and rejected, so a future simplifier does not have to re-derive
# it). The doorbell tells the seat to read `payloads/<id>.md`: a pure file read on
# its own bus. The common case — seat wakes, reads its items — leaves NO bus
# footprint at all, and a harness can complete an entire turn without touching the
# bus. So every cheap activity-keyed witness would miss exactly the case retention
# exists to cover, racing GC against a recipient who left no observable signal.
# The two witnesses that would actually be true cost more than the mechanism
# saves: pane-observing the sentinel being consumed re-introduces courier pane
# probing, and making the doorbell settleable adds one `tap done` turn per digest
# — the very class this feature removes. Accepted property, not a leak: an index
# whose pane never wakes again occupies its bytes for the full window, and GC is
# drain-scheduled, so it goes on the next drain after that.
tap_digest_reap_settled() {
  # Retention rule, `TAP_DIGEST_RETAIN_SECONDS` validation and the `TAP_SPOOL_NOW`
  # pin are the module's; a missing digests directory is its no-op.
  tap_bun_call digest-index - digest-index.ts reap "$(tap_digest_dir)" "$TAP_RECEIPTS"
}

# Presentation is cosmetic and must never decide delivery. The machine-global
# pane-submit lock serializes effects across team buses; each bus token records
# the exact target generation and leaves interrupted cleanup safe to retry.
tap_pane_effect_clear_verified() { # <pane-id> <server-epoch>
  # Body: runtime/bun/src/spool-park-report.ts `paneEffectClearVerified` (yes|no at rc 0).
  local verdict
  verdict="$(tap_bun_call spool-park-report "${1:-}" spool-park-report.ts clear-verified "${1:-}" "${2:-}")" || return 1
  case "$verdict" in
    yes) return 0 ;;
    no) return 1 ;;
    *) printf 'tap: slice_failed id=%s slice=spool-park-report: invalid clear verdict\n' "${1:-}" >&2; return 1 ;;
  esac
}

# tap_notify_draft_backed_up <pane> <pane_id> <generation> <session>
# Tell the PANE OWNER, at their own pane, that their cleared draft was saved and
# how to get it back (tap-cnka).
#
# The clobber pipeline already backs the draft up correctly and already prints
# recovery instructions -- to STDERR, which belongs to the courier process. That
# is the sender terminal. The pane owner is a different human at a different pane
# and never sees a word of it, so from the only vantage point that matters the
# sequence is: red flash, draft gone, silence. A backup nobody is told about is,
# experientially, a deletion. Ops lost a ten-line draft to exactly this and
# reported it as the restore being broken; the restore was working as ruled
# (tap-jb3), and what was missing was the signal.
#
# display-message, deliberately, and NOT an injection. It writes to a client
# status line and never touches the input band, so it cannot clobber the draft it
# is describing, cannot recurse into the courier, and cannot race the drain. The
# existing red flash is the same idea without words: this pairs a cue the owner
# already sees with the one fact that makes it survivable.
#
# TARGETING IS THE WHOLE POINT AND IT IS EASY TO GET BACKWARDS. `-t target-pane`
# selects only the pane used for FORMAT CONTEXT; `-c target-client` selects who
# actually receives the message. A first version of this helper passed -t alone,
# which delivered the notice to the INVOKING client -- the courier, i.e. the
# sender -- reproducing at one level up the exact defect this function exists to
# fix: the owner gets the red flash and the cleared draft, somebody else gets the
# explanation. Reproduced by cnka-examiner on tmux 3.7b with two attached
# clients, and by the two-session probe below.
#
# So the clients are resolved EXPLICITLY from the pane owner side and addressed
# one at a time:
#   MANY clients  -- every client attached to the owner session is notified. Two
#                    humans watching one pane both saw the draft vanish, so both
#                    are owed the recovery command.
#   ZERO clients  -- an unattended pane (the common shape for crew seats) has no
#                    status line to write to. That is a best-effort no-op and must
#                    NOT fail the delivery path: the courier is mid-send and a
#                    cosmetic notice can never be the thing that breaks it. It is
#                    also precisely where the durability follow-up begins
#                    (tap-xz2t) -- an owner who was not watching is exactly the
#                    owner who needs to find this later.
#
# Identity is re-verified before each effect, as it is for a pane flash -- a pane
# that died and was replaced must not be told about a stranger draft.
tap_notify_draft_backed_up() {
  local pane="$1" pane_id="${2:-}" epoch="${3:-}" session="${4:-}" client epoch_now
  [ -n "$pane_id" ] || return 0
  # A `%N` id is immutable only WITHIN one tmux server generation; this file
  # documents elsewhere that ids RECYCLE across generations. So a server restart
  # mid-command that recreates the same address and the same numeric id passes
  # both identity checks below and would notify an unrelated pane. The generation
  # stamp is observed ONCE here and compared at the effect boundary, which is what
  # makes "the same pane" mean the same pane rather than the same number.
  # Unreadable generation fails closed: identity cannot be claimed without it, and
  # refusing a cosmetic notice costs nothing next to telling a stranger.
  # The generation is the CALLER's, captured in the same tmux record as the pane
  # id the backup was written for. Minting it here instead would sample whatever
  # server is running by the time this helper runs, so a restart during the backup
  # write would make entry and effect agree -- with each other, about the wrong
  # pane. Absent stamp is a cosmetic no-op, never an unverified notice.
  [ -n "$epoch" ] || return 0
  [ "$(tap_pane_alive "$pane" 2>/dev/null || true)" = "$pane_id" ] || return 0
  # EVERY subsequent target is the VERIFIED pane ID, never the caller address.
  # `$pane` is a registry address like `tap/fable:5.0`; window indices renumber
  # and panes close, so the same address can name a DIFFERENT pane a moment after
  # the check above passed. Resolving the session or writing the message through
  # that address would then enumerate a replacement session and tell its clients
  # about the previous owner draft -- which the comment above and CONTRACT both
  # promise never happens. A `%N` id cannot drift onto another pane.
  # The session comes from the SAME record as the id and the generation. Re-reading
  # it here would be the split-observation defect one field over: a pane can be
  # moved between sessions, so a session resolved at notice time may not be the
  # session the backed-up pane belonged to, and its clients are then strangers.
  [ -n "$session" ] || return 0
  # Zero attached clients yields an empty list and therefore no iterations: a
  # deliberate no-op, not an error, and never a non-zero return into the caller.
  while IFS= read -r client; do
    [ -n "$client" ] || continue
    # Re-authorize at the EFFECT boundary, not once at entry: the repo first-effect
    # barrier. Between listing clients and writing to them the pane can die, and a
    # dead pane earns no notice.
    epoch_now="$(tap_server_epoch_now 2>/dev/null || true)"
    [ "$epoch_now" = "$epoch" ] || return 0
    [ "$(tap_pane_alive "$pane" 2>/dev/null || true)" = "$pane_id" ] || return 0
    tmux display-message -c "$client" -t "$pane_id" -d 8000 \
      "tap: your draft was saved, not lost -- recover it with: tap draft" 2>/dev/null || true
  done <<EOF
$(tmux list-clients -t "$session" -F '#{client_name}' 2>/dev/null || true)
EOF
  return 0
}

tap_pane_effect_flash_body() { # <pane> <pane_id> <owner_id> [<style>] [<count>] — caller holds the pane submit lock
  tap_bun_call spool-park-report "$3" spool-park-report.ts flash "$TAP_HOME" "$1" "$2" "$3" "${4:-bg=red}" "${5:-1}" locked
}

tap_pane_effect_flash() { # <pane> <pane_id> <owner_id> [<style>] [<count>]
  # Body: runtime/bun/src/spool-park-report.ts `flashPane` — the pane submit lock and the
  # recovery guard around the effect; no lock or a held pane, no flash.
  tap_bun_call spool-park-report "$3" spool-park-report.ts flash "$TAP_HOME" "$1" "$2" "$3" "${4:-bg=red}" "${5:-1}"
}

tap_pane_effect_repair_orphans() {
  local path pane pane_id epoch
  [ -d "$TAP_HOME/pane-effects" ] || return 0
  while IFS=$'\x1f' read -r path pane pane_id epoch; do
    [ -n "$path" ] || continue
    (
      local epoch_now
      if ! tap_pane_submit_lock "$pane_id"; then
        tap_pane_submit_unlock
        exit 0
      fi
      trap tap_pane_submit_unlock EXIT
      local recovery_state
      recovery_state="$(tap_bun_call recovery repair recovery/cli.ts guard "$pane_id")" || recovery_state=park
      [ "$recovery_state" = allowed ] || exit 0
      if tap_pane_effect_clear_verified "$pane_id" "$epoch"; then
        rm -f "$path"
      else
        epoch_now="$(tap_server_epoch_now 2>/dev/null || true)"
        [ -n "$epoch" ] && [ -n "$epoch_now" ] && [ "$epoch_now" != "$epoch" ] && rm -f "$path"
      fi
      exit 0
    )
  done < <(python3 -B - "$TAP_HOME/pane-effects" <<'PY'
import glob, json, os, sys
for path in glob.glob(os.path.join(sys.argv[1], "*.json")):
    try:
        d = json.load(open(path))
        print("\x1f".join([path, str(d.get("pane", "")), str(d.get("pane_id", "")),
                           str(d.get("server_epoch", ""))]))
    except Exception:
        pass
PY
  )
  return 0
}

# tap-13c8: the kind that marks a delivery-failure notice. It exists to give the
# self-recursion guard below something exact to key on — a notice that itself
# fails must never mint a second notice.
TAP_KIND_DELIVERY_FAILED="delivery-failed"

# One durable notice per sender in this digest, using the original member's
# sender-registry resolution and the existing publication-before-attempt guard.

# --- deadline dispositions (runtime/bun/src/spool-deadline.ts) --------------------
#
# The drain's deadline transactions and the helpers only they still call live in
# Bun: the sender notice, the grace disposition, the escalation mark, terminalize
# and the delivery-failed receipt. What remains here is one door plus the verdict
# adapters other Bash sites still call. Every argument the door passes is a FACT
# the caller already held; every decided outcome answers at rc 0 with a verdict,
# and a nonzero exit is a slice failure that the adapter refuses to interpret.
#
# THE HUMAN ALERT IS A FACT ABOUT THE CALLER. Only a drain running inside the
# watcher's tick has a human to alert; the watcher says so with a LOCAL
# (`TAP_SPOOL_HUMAN_ALERT=watcher` at its one drain call, inside `tap_watch_tick`,
# tap-watch.sh) that reaches this function by dynamic scope and reaches no child —
# a detached waiter the watcher's drain spawns copies the environment and must
# read `none` here. The tick's arm snapshot (`TAP_WATCH_TICK_*`) travels the same
# way, so the door hands over the fact and the two snapshot values the watcher's
# former callback read. The native side composes the same alert that callback
# composed and publishes it through the same notify-human door; nothing about the
# alert is decided here.
tap_spool_deadline_call() { # <id> <now-epoch|""> <verb> [<args>...]
  local id="$1" now="${2:-}" verb="$3" alert=none queued_probe="" probe_timeout="" acting team
  shift 3
  if [ "${TAP_SPOOL_HUMAN_ALERT:-}" = watcher ]; then
    alert=tick
    queued_probe="${TAP_WATCH_TICK_QUEUED_PROBE_ID:-}"
    probe_timeout="${TAP_WATCH_TICK_PROBE_TIMEOUT:-}"
  fi
  team="$(tap_spool_team_name)"
  # The sender's own registry is the acting registry of the bus being drained; the
  # native side falls back to the bound registry when this is empty.
  acting="$(tap_acting_registry "$team" 2>/dev/null || true)"
  [ -n "$now" ] || now="$(date +%s)"
  tap_bun_call spool-deadline "$id" spool-deadline.ts "$TAP_HOME" "$TAP_SPOOL" "$TAP_REGISTRY_EVENTS" \
    "$team" "${TAP_VERB:-tap}" "$acting" "$_TAP_SCRIPT_DIR" "$alert" "$queued_probe" "$probe_timeout" \
    "$now" "$TAP_SPOOL_UNROUTED_GRACE" "$verb" "$@"
}

# tap_spool_notify_sender_on_escalate <id> <target> <detail> <registry> <outcome> [durable-id [digest-members]]
# 0 iff the sender was already settled, or was woken AND that wake was CONFIRMED
# delivered (a durable notice: iff published). The caller uses the nonzero to decide
# terminal-vs-held, so an unverified wake must not read as success.
tap_spool_notify_sender_on_escalate() {
  local verdict
  verdict="$(tap_spool_deadline_call "$1" "" notify "$1" "${2:-}" "${3:-}" "${4:-}" "${5:?notice outcome required}" "${6:-}" "${7:-}")" || return 1
  case "$verdict" in
    woken) return 0 ;;
    unwoken) return 1 ;;
    *) printf 'tap: slice_failed id=%s slice=spool-deadline: invalid notify verdict\n' "$1" >&2; return 1 ;;
  esac
}

# A possible-effect marker never authorizes another grace-window injection.
tap_spool_grace_attempted() { # <id>
  local verdict
  verdict="$(tap_spool_deadline_call "$1" "" grace-attempted "$1")" || return 1
  case "$verdict" in
    yes) return 0 ;;
    no) return 1 ;;
    *) printf 'tap: slice_failed id=%s slice=spool-deadline: invalid grace verdict\n' "$1" >&2; return 1 ;;
  esac
}

# tap_spool_terminalize <id> <handle> <pane> <reason> [<action>] — remove the retry
# state, keep the payload (promoted first: while parked, the spool file is the only
# copy). The action names the event, because the event is a claim.
tap_spool_terminalize() {
  local verdict
  verdict="$(tap_spool_deadline_call "$1" "" terminalize "$1" "${2:-}" "${3:-}" "${4:-delivery_failed}" "${5:-spool_terminal_delivery_failed}")" || return 1
  case "$verdict" in
    ok) return 0 ;;
    failed) return 1 ;;
    *) printf 'tap: slice_failed id=%s slice=spool-deadline: invalid terminalize verdict\n' "$1" >&2; return 1 ;;
  esac
}

# tap_spool_recipient_is_present <ready> — 0 iff the last readiness probe proves the
# recipient is STILL THERE and merely unable to take input this instant. The native
# predicate names the terminal states (`gone`, `unsafe`), not the live ones.
tap_spool_recipient_is_present() { # <ready>
  local verdict
  verdict="$(tap_spool_deadline_call "" "" recipient-present "${1:-}")" || return 1
  case "$verdict" in
    present) return 0 ;;
    absent) return 1 ;;
    *) printf 'tap: slice_failed id=- slice=spool-deadline: invalid presence verdict\n' >&2; return 1 ;;
  esac
}

# Receipt-backed withdrawal owns the same obligation/queue claims as cancellation.
# Bun revalidates registry chronology under its existing registry/metadata locks.
tap_spool_withdraw_retired() ( # <id> <acting-registry>
  local id="$1" registry="$2" decision
  tap_valid_id "$id" || return 1
  tap_obligation_lock "$id" 0 || return 0
  tap_spool_claim_acquire "$id" no-steal || return 0
  trap 'tap_spool_claim_release "$id"' EXIT
  decision="$(tap_bun_call spool-retired "$id" spool-retired.ts withdraw "$TAP_HOME" "$registry" "$id")" || return 1
  [ "$decision" = withdrawn ] || return 0
  tap_reset_generation_touch "spool-instance-retired"
  tap_registry_event_append_or_warn courier spool_instance_retired "$id" "" "receipt=$id.cancelled"
  tap_spool_remove "$id"
)

tap_spool_drain_once() { # [now_epoch] [cap] [target] [target_registry]
  [ "${TAP_SPOOL_DRAIN_ACTIVE:-0}" != 1 ] || return 0
  # Mid-reset: successful no-op (design: spool draining does not refuse, it idles).
  tap_reset_fence_present && return 0
  [ -d "$TAP_SPOOL" ] || return 0
  # tap-ncd4: the SAME authority gate as tap_spool_redeliver/digest_inject, but
  # at the drain's own front door — P1 review found Phase A's readiness probes
  # (tap_spool_pane_ready, before either helper is ever reached) and Phase C's
  # digest path both touch panes on a route the redeliver-only guard never saw.
  # Checked once here, not per-candidate: every candidate in one drain tick
  # shares this one TAP_HOME. Unlike the early-outs above (0 = "nothing to do"
  # this tick, a normal idle result), this is a real refusal — 1, propagated —
  # because a caller running the drain against a never-bootstrapped TAP_HOME is
  # not idle, it is misconfigured, and tap-watch's own caller already treats
  # anything outside {0,5} as a hard stop rather than silence.
  tap_spool_home_authorized_or_warn tap_spool_drain_once || return 1
  (
  export TAP_SPOOL_DRAIN_ACTIVE=1
  local now="${1:-${TAP_SPOOL_NOW:-$(date +%s)}}" cap="${2:-${TAP_SPOOL_DRAIN_CAP:-8}}"
  local scope_target="${3:-}" scope_registry="${4:-}"
  [ -z "$scope_target" ] || [ -n "$scope_registry" ] || return 0
  local id target reason reason_class timeout_seconds first_epoch pane pane_id to_team target_registry policy deadline_epoch escalated_at deadline_source hold_until_epoch ready attempt delivered redeliver_rc seen=0 due=0 unverified=0 _cls _held_slot=0 _forced=0 _reprobe=0 _fcmd _refunds=0 _held_visits=0
  local _digest_plan="" _digest_members=" " _elig="" _tr _tt _h _p _pi _ids _m _digest_rc
  local -a _row
  local _grace _unrouted _deadline
  # Register recovery owns one recipient. Global maintenance may touch other
  # recipients and stays with the unscoped watcher pass.
  if [ -z "$scope_target" ]; then
    tap_spool_reap_stale_sidecars
    tap_digest_reap_settled
    tap_pane_effect_repair_orphans
  fi
  compgen -G "$TAP_SPOOL/*.md" >/dev/null || return 0

  # Retired entries must leave before either phase considers readiness, including
  # old escalated entries that the ordinary delivery loops deliberately skip.
  local _retirement_registry _retirement_ids _retirement_id _retirement_members=" "
  _retirement_registry="$(tap_acting_registry 2>/dev/null || true)"
  if [ -n "$_retirement_registry" ]; then
    _retirement_ids="$(tap_bun_call spool-retired "" spool-retired.ts candidates "$TAP_HOME" \
      "$_retirement_registry" "$scope_target" "$scope_registry")" || return 1
    case "$_retirement_ids" in
      ok) _retirement_ids="" ;;
      ok$'\n'*) _retirement_ids="${_retirement_ids#*$'\n'}" ;;
      *) printf 'tap: slice_failed id=- slice=spool-retired: invalid candidate response\n' >&2; return 1 ;;
    esac
    while IFS= read -r _retirement_id; do
      [ -n "$_retirement_id" ] || continue
      tap_valid_id "$_retirement_id" || {
        printf 'tap: slice_failed id=- slice=spool-retired: invalid candidate id\n' >&2; return 1;
      }
      _retirement_members="$_retirement_members$_retirement_id "
      tap_spool_withdraw_retired "$_retirement_id" "$_retirement_registry" || \
        tap_registry_event_append_or_warn courier spool_retirement_incomplete "$_retirement_id" "" "custody retained"
    done <<< "$_retirement_ids"
  fi

  # --- Phase A: plan courier digests (tap-ix63) --------------------------------
  # Group plain-redeliverable, currently-ready entries by bound recipient. The
  # urgent/escalate carve-out is PRE-CLAIM: policy==urgent covers both classes
  # (kind=escalate defaults --urgent at park), so those keep their solo interrupt
  # wake and never fold into a batch. A recipient with >=2 eligible entries plans a
  # digest; <2 falls straight through to the per-id path below. Readiness probed
  # here is only a filter — tap_spool_digest_inject re-checks under its held claims.
  while IFS=$'\x1f' read -r id target reason reason_class timeout_seconds first_epoch pane pane_id to_team target_registry policy deadline_epoch escalated_at deadline_source hold_until_epoch _held_visits; do
    [ -n "$id" ] || continue
    case "$_retirement_members" in *" $id "*) continue ;; esac
    [ -f "$(tap_spool_payload_path "$id")" ] && [ -f "$(tap_spool_meta_path "$id")" ] || continue
    [ "$reason" = legacy_meta_no_binding ] && continue
    # tap-zeng: escalated mail is awaiting human disposition — never fold into a
    # courier digest (that would move it out of spool and "clear" the obligation).
    [ -z "$escalated_at" ] || continue
    tap_spool_grace_attempted "$id" && continue
    { [ -z "$target_registry" ] || [ -z "$pane_id" ] || [ -z "$pane" ]; } && continue
    tap_registry_matches_team "$target_registry" "$to_team" || continue
    tap_is_done "$id" && continue
    # Urgent mail never joins a digest. Preserve that fast skip for fresh entries;
    # only a marked urgent entry needs one readiness look to shed stale held priority.
    [ "$policy" = urgent ] && [ "${_held_visits:-0}" -eq 0 ] && continue
    ready="$(tap_spool_pane_ready "$pane" "$pane_id" "$target" "$to_team" "$target_registry" "$policy")"
    # The visit count schedules HELD mail; it is not lifetime priority. Phase A sees
    # every digest-eligible entry before Phase B applies its cap, so clear a stale mark
    # as soon as the old entry becomes deliverable. A contended nonblocking update may
    # defer this cleanup to a later drain, but never puts courier latency behind it.
    [ "$ready" = ready ] && tap_spool_update_held_visits "$id" clear
    [ "$policy" = urgent ] && continue
    [ -n "$first_epoch" ] || first_epoch=0
    # tap-7r3fn.20: A DIGEST CARRIES ONLY DUE ITEMS, so a row that is not due
    # never reaches the grouper at all. That deletes the RIDE-ALONG: an in-window
    # entry used to be classified `auto-held` and could travel inside a doorbell
    # that some neighbour caused, arriving early through no rule of its own. Its
    # window is its promise to the recipient, and a promise another sender's
    # timing can cancel is not one.
    #
    # EVERY CLASS IS GATED, not only the held one. The window is a flood limiter
    # for the seat rather than a property of one policy, so a `standard` entry —
    # which is what a reply=expected send parks as — waits for its own epoch too.
    # Before this, `hold_until_epoch` was consulted at exactly one line and only
    # for auto-settle; nothing else in the drain ever compared it.
    #
    # A BACKWARD CLOCK JUMP IS DUE. The plan proposed `hold - now > W` for this,
    # which needs W at every row and misreads a seat whose configured window
    # legitimately exceeds the fleet default. `now < first_spooled_epoch` is
    # exact, needs no window, and reads a field already stored: the clock cannot
    # honestly be earlier than the moment this entry was parked.
    #
    # AN ENTRY WITH NO EPOCH IS DUE. That is an object written before this change;
    # fail-open, because the alternative strands it forever.
    _due=1
    if [ -n "$hold_until_epoch" ] && [ "$now" -lt "$hold_until_epoch" ]; then
      _due=0
      [ -n "$first_epoch" ] && [ "$first_epoch" != 0 ] && [ "$now" -lt "$first_epoch" ] && _due=1
    fi
    [ "$_due" = 1 ] || continue
    # `plain` needs a partner to justify an envelope; an auto-settle entry has no
    # per-id delivery path at all — the doorbell IS its delivery — so N=1 stays
    # legal for that class and only that class.
    _cls=plain
    tap_spool_entry_is_held "$policy" && _cls=auto-due
    _elig="$_elig$target_registry"$'\x1f'"$to_team"$'\x1f'"$target"$'\x1f'"$pane"$'\x1f'"$pane_id"$'\x1f'"$first_epoch"$'\x1f'"$id"$'\x1f'"$_cls"$'\x1f'"$ready"$'\n'
  done < <(tap_spool_list "$scope_target" "$scope_registry" | python3 -B -c '
import json, sys
for line in sys.stdin:
    try: r = json.loads(line)
    except Exception: continue
    if r.get("incomplete"): continue
    print("\x1f".join(str(r.get(k) or "") for k in ("id", "target", "reason", "reason_class", "timeout_seconds", "first_spooled_epoch", "pane", "pane_id", "to_team", "target_registry", "policy", "deadline_epoch", "escalated_at", "deadline_source", "hold_until_epoch", "held_drain_visits")))
')
  if [ -n "$_elig" ]; then
    _digest_plan="$(printf '%s' "$_elig" | tap_bun_call injection-behavior plan injection-behavior.ts plan "$TAP_SPOOL" "$now")" || return 1
  fi
  if [ -n "$_digest_plan" ]; then
    while IFS=$'\x1f' read -r _tr _tt _h _p _pi _ids; do
      [ -n "$_ids" ] || continue
      for _m in $_ids; do _digest_members="$_digest_members$_m "; done
    done <<EOF
$_digest_plan
EOF
  fi

  while IFS=$'\x1f' read -r id target reason reason_class timeout_seconds first_epoch pane pane_id to_team target_registry policy deadline_epoch escalated_at deadline_source hold_until_epoch; do
    [ -n "$id" ] || continue
    case "$_retirement_members" in *" $id "*) continue ;; esac
    case "$_digest_members" in *" $id "*) continue ;; esac   # tap-ix63: delivered as a digest in Phase C
    # The row as the deadline transactions read it: the listing SNAPSHOT, in
    # listing order, never a re-read (a field another drain changed mid-loop is
    # the incumbent's race too).
    _row=("$id" "$target" "$reason" "$reason_class" "$timeout_seconds" "$first_epoch" "$pane" "$pane_id" "$to_team" "$target_registry" "$policy" "$deadline_epoch" "$escalated_at" "$deadline_source" "$hold_until_epoch")
    # tap-6vwz: A SETTLED ENTRY IS TERMINAL, AND THIS IS THE ONLY PLACE THAT CAN
    # SAY SO. Every `tap_is_done` check below sits under a `continue` — the
    # escalated gate on the next line, and the terminal-reason branch after it —
    # so a settled entry that reached either state is skipped before anything
    # reaps it and stays spooled forever. That is how the live specimen survived
    # its own delivery: received, settled, and still in the spool with attempts=0.
    #
    # Found by the END-TO-END leg, not by the unit arms. Arm 4 settles an entry
    # that has not escalated yet and passes; the ordering defect only appears
    # once a disposition has already been recorded, which no single-drain test
    # reaches. That is the argument for the leg being in the acceptance bar.
    #
    # Deliberately GENERAL, not scoped to the sunk class: any settled entry in
    # any of these states has nothing left to wait for, and leaving it parked is
    # the same defect wherever it happens. Reaping retires retry state only —
    # settlement already happened, so nothing is lost and nothing is resurrected.
    if [ -n "$escalated_at" ] || [ "$reason" = legacy_meta_no_binding ]; then
      # Promote before discarding: a settled entry can still be spool-only (settled
      # by a route that never moved the body), and `tap_spool_remove` is the raw
      # retry-state cleaner — it deletes the sole copy. Same invariant as the
      # notice path above; `|| true` because a settled obligation is discharged
      # either way and a promotion failure must not strand the row.
      if tap_is_done "$id"; then
        tap_spool_terminalize "$id" "$target" "$pane" "settled" spool_terminal_settled || tap_spool_remove "$id"
        continue
      fi
    fi
    # Recover old escalated grace entries before the general exclusion. Neither
    # phase may retry a possible effect while notice publication is incomplete.
    # The disposition is one native transaction under the entry's claim
    # (spool-deadline.ts `disposeGraceDue`); a marked grace entry leaves this loop
    # whether or not it was due.
    _grace="$(tap_spool_deadline_call "$id" "$now" grace-due "${_row[@]}")" || continue
    case "$_grace" in
      not-grace) ;;
      grace-waiting|grace-disposed) continue ;;
      *) printf 'tap: slice_failed id=%s slice=spool-deadline: invalid grace-due verdict\n' "$id" >&2; continue ;;
    esac
    # tap-zeng: already-escalated entries stay for human disposition but must NOT
    # consume TAP_SPOOL_DRAIN_CAP — oldest-first + cap otherwise starves younger
    # ready mail (attempts stayed 0 for days behind escalated junk).
    [ -z "$escalated_at" ] || continue
    [ -f "$(tap_spool_payload_path "$id")" ] && [ -f "$(tap_spool_meta_path "$id")" ] || continue
    # tap-6vwz — THE ESCAPE ROUTE for an entry excluded from every delivery path
    # (a legacy mark, a missing binding field, a registry that no longer names the
    # bound team): reconciled if settled, marked unroutable, and once aged past
    # TAP_SPOOL_UNROUTED_GRACE promoted as `unrouted` with the sender told no attempt
    # was ever made — never that delivery failed. One native transaction
    # (spool-deadline.ts `disposeUnrouted`); the predicate is read at the STATE, so
    # the next terminal condition inherits the route by construction.
    _unrouted="$(tap_spool_deadline_call "$id" "$now" unrouted "${_row[@]}")" || continue
    case "$_unrouted" in
      routable) ;;
      settled|unrouted-waiting|unrouted-escalated) continue ;;
      *) printf 'tap: slice_failed id=%s slice=spool-deadline: invalid unrouted verdict\n' "$id" >&2; continue ;;
    esac
    # Defense in depth: a cancelled/settled id must never be resurrected by a drain.
    tap_is_done "$id" && continue
    # tap-31it: an auto-settle park never takes a solo per-id injection. This
    # guard applies to deliverer, watch and scoped register drains alike: the
    # per-id path below otherwise redelivers a lone ready entry. Its delivery
    # belongs to the digest doorbell planned in Phase A, whose members were
    # already skipped above.
    #
    # Past its DELIVERY deadline (hold window + the busy tail) it still owes the
    # sender a delivery-failed, so it falls through to the escalation branch below
    # and to nothing else: `attempt` is forced to 0 there. Before that deadline it
    # leaves the loop without consuming a drain slot — same starvation class as an
    # escalated entry.
    if tap_spool_entry_is_held "$policy"; then
      { [ -n "$deadline_epoch" ] && [ "$now" -ge "$deadline_epoch" ]; } || continue
    fi
    # REBASE NOTE (tap-7r3fn.20 onto #xxx): both sides of this conflict were
    # ADDITIONS at one line, and they are independent — #xxx's drain-slot
    # starvation fix and this bead's Phase B window gate. Keeping both is the
    # resolution; taking either alone silently drops a shipped property.
    # ORDER IS DELIBERATE: the window gate runs first because a `continue` here
    # means the entry is not delivered at all this tick, so it consumes no slot
    # and needs no slot bookkeeping. An entry past its DELIVERY deadline escapes
    # the window gate and reaches #xxx's block exactly as before.
    # tap-7r3fn.20: THE SAME SUPPRESSION FOR EVERY OTHER CLASS. The block above
    # has stopped a held entry from taking a solo injection since tap-31it, and
    # now that `standard` and `polite` entries carry a window too, an in-window
    # one must not take one either — otherwise the per-id path below delivers it
    # the moment any drain runs and the window it was given means nothing.
    #
    # This is where `hold_until_epoch` starts being READ. Before this change the
    # field was destructured on both loops and compared at exactly one line, in
    # Phase A, for one policy; Phase B carried it and never looked at it.
    #
    # Same escape as the held branch, and for the same reason: past its DELIVERY
    # deadline the entry still owes its sender a delivery-failed, so it falls
    # through rather than waiting forever. A backward clock jump is due, tested
    # as `now < first_spooled_epoch` — the clock cannot honestly be earlier than
    # the moment this entry parked.
    #
    # ARMED SEPARATELY FROM PHASE A'S IDENTICAL CLAUSE, by delivery-window-drain
    # arm 8. The discriminator is a LONE standard entry: Phase A plans DIGESTS,
    # so its flush rule drops a single plain row and never makes it a member,
    # while this loop walks that row and delivers it per-id. A readiness-based
    # fixture cannot separate the two — Phase B reads readiness as well, so the
    # entry stays spooled whichever clause decided.
    if [ -n "$hold_until_epoch" ] && [ "$now" -lt "$hold_until_epoch" ] \
       && { [ -z "$first_epoch" ] || [ "$first_epoch" = 0 ] || [ "$now" -ge "$first_epoch" ]; }; then
      { [ -n "$deadline_epoch" ] && [ "$now" -ge "$deadline_epoch" ]; } || continue
    fi

    # A HELD READINESS-GATE ENTRY DOES NOT CONSUME A DRAIN SLOT (tap-92v3r, round 5).
    #
    # This loop is oldest-first under TAP_SPOOL_DRAIN_CAP, and it already exempts two
    # classes for exactly this reason, both of which say so in their own comments: an
    # escalated entry (":3423 — oldest-first + cap otherwise starves younger ready mail,
    # attempts stayed 0 for days behind escalated junk") and an auto-settle park inside
    # its hold window (":3528 — leaves the loop without consuming a drain slot, same
    # starvation class as an escalated entry"). Both `continue` BEFORE the cap.
    #
    # tap-92v3r added a THIRD entry that can leave this loop having delivered nothing —
    # the post-deadline hold at the escalation branch below — and it took a slot per
    # tick per held entry. A seat that stays busy long enough would let its held mail
    # crowd out newer, deliverable mail behind it: the failure this file wrote down
    # twice. Caught by a review bot and corroborated by opus6-gate against those two
    # comments; I had read neither.
    #
    # THE SLOT IS RELEASED, THE WORK IS NOT SKIPPED, and that distinction is the whole
    # correctness of this block. The first version `continue`d here, which also skipped
    # the forced past-deadline redelivery below — the one attempt per tick that is how a
    # held entry ever reaches its recipient. courier-busy-hold arm 2 reddened
    # immediately ("the held entry never delivered after the band freed"), which is
    # exactly right: a held entry that is never retried is the zombie this lane exists
    # to prevent, reintroduced while fixing a starvation bug. So the flag below refunds
    # `seen` after the attempt instead, leaving the cap measuring what it is for —
    # entries that consumed a delivery opportunity.
    _held_slot=0
    _forced=0
    if [ "$deadline_source" = readiness-gate ] && [ -n "$deadline_epoch" ] \
       && [ "$now" -ge "$deadline_epoch" ]; then
      _held_slot=1
    fi
    [ "$seen" -lt "$cap" ] || break
    seen=$((seen + 1))
    [ -n "$first_epoch" ] || first_epoch=0
    ready="$(tap_spool_pane_ready "$pane" "$pane_id" "$target" "$to_team" "$target_registry" "$policy")"
    _reprobe=0
    # Generic pending input waits for its grace. This exact zero-Enter record may
    # immediately re-enter the safe own-sentinel submit path.
    [ "$ready" != busy:pending ] || { tap_submit_reprobe_pending "$id" && _reprobe=1; }
    case "$ready" in busy:queued|busy:decision-unavailable|busy:recovery) continue ;; esac
    attempt=0; due=0
    case "$ready" in
      busy:clearing)
        # Live fence: wait for the marker, not the spool busy-deadline.
        ;;
      busy|busy:*)
        # Wedge counter only (busy:pending). Mid-suite noprompt stays silent.
        tap_spool_note_busy_probe "$id" "$ready"
        # THE FORCED-INJECTION BOUND (ruling 15 item 2). Readiness-gate parks are due
        # at their deadline, but an ordinary attempt still refuses a busy submit and
        # reparks. Three post-deadline looks at a live, non-modal pane authorize an
        # injection the recipient's harness will queue.
        #
        # The harness is read only here, once the deadline has passed, so the ordinary
        # pre-deadline path costs nothing extra.
        if [ -n "$deadline_epoch" ] && [ "$now" -ge "$deadline_epoch" ]; then
          # RESOLVED, not the shallow command. `pane_current_command` for a venv-launched
          # hermes is `python3.11` (that exact shape is pinned in cursor-harness.test.sh),
          # and `tap_harness_family` cannot classify it — so the hermes exclusion would not
          # have fired for the launcher shape hermes actually ships with, and the one seat
          # ruling 15 protects from a forced inject is the one it would have interrupted.
          # `tap_pane_harness_command` is the resolver the redelivery path already uses; it
          # trusts a known family immediately and walks the process tree only when the
          # shallow name is unclassifiable.
          _fcmd="$(tmux display-message -p -t "$pane" '#{pane_current_command}' 2>/dev/null || true)"
          _fcmd="$(tap_pane_harness_command "$pane" "$_fcmd")"
          if tap_spool_force_allowed_for_harness "$_fcmd"; then
            tap_spool_note_live_probe "$id" "$ready"
            [ "$(tap_spool_live_probes "$id")" -ge "$(tap_spool_force_probe_threshold)" ] && _forced=1
          fi
        fi
        if [ -n "$deadline_epoch" ] && [ "$reason_class" = busy ] && [ "$now" -ge "$deadline_epoch" ]; then due=1; fi
        local _cue_red_at _draft_deadline
        local _cue_fields
        _cue_fields="$(tap_bun_call injection-behavior "$id" injection-behavior.ts cue "$TAP_SPOOL" "$id")" || continue
        IFS=$'\x1f' read -r _cue_red_at _draft_deadline <<< "$_cue_fields"
        case "$_cue_red_at" in
          ''|*[!0-9]*) ;;
          *)
            if [ -n "$_draft_deadline" ] && [ "$ready" = busy:pending ] \
               && [ "$now" -ge "$(( _draft_deadline - _cue_red_at ))" ] && [ "$now" -lt "$_draft_deadline" ]; then
              tap_pane_effect_flash "$pane" "$pane_id" "$id" 'bg=red' 1
            fi ;;
        esac
        ;;
    esac
    if [ "$ready" = ready ]; then
      attempt=1
    elif [ "$due" = 1 ]; then
      attempt=1
    elif [ "$_forced" = 1 ]; then
      attempt=1
    elif [ "$_reprobe" = 1 ]; then
      attempt=1
    fi
    # tap-31it: never a solo redelivery for this class (see the guard above). The
    # entry is here only to reach the escalation branch at its delivery deadline.
    tap_spool_entry_is_held "$policy" && attempt=0
    delivered=0
    redeliver_rc=0
    if [ "$attempt" = 1 ]; then
      # Match read/cancel: obligation before spool. Reverse ordering lets each
      # contender hold the lock the other needs and makes both abandon the item.
      if ! tap_obligation_lock "$id" 0; then exec 8>&-; continue; fi
      if ! tap_spool_claim_acquire "$id"; then exec 8>&-; continue; fi
      # A competing drain may have attempted since the planning snapshot.
      if tap_spool_grace_attempted "$id" && ! tap_submit_reprobe_pending "$id"; then
        tap_spool_claim_release "$id"
        exec 8>&-
        continue
      fi
      ready="$(tap_spool_pane_ready "$pane" "$pane_id" "$target" "$to_team" "$target_registry" "$policy")"
      _reprobe=0
      [ "$ready" != busy:pending ] || { tap_submit_reprobe_pending "$id" && _reprobe=1; }
      case "$ready" in busy:queued|busy:decision-unavailable|busy:recovery) tap_spool_claim_release "$id"; exec 8>&-; continue ;; esac
      due=0
      case "$ready" in
        busy:clearing) ;;
        busy|busy:*)
          [ -n "$deadline_epoch" ] && [ "$reason_class" = busy ] && [ "$now" -ge "$deadline_epoch" ] && due=1
          ;;
      esac
      # WHICH OF THE THREE MODAL GUARDS IS INDIVIDUALLY OBSERVABLE — read this before
      # deleting one as untested. Three separate places refuse to force on a modal: the
      # counter (`tap_spool_note_live_probe` excludes `busy:modal`), this re-validation,
      # and the submit gate's `_pi_rc != 4`. Only the FIRST reds an arm on its own; both
      # others survive mutation individually, because removing either still leaves the
      # other two refusing. Mutating all three together reds courier-busy-hold arm 19
      # with its own message, so the property is covered and the redundancy is what makes
      # each part invisible.
      #
      # They stay. Each answers at a different moment — count time, decision time, submit
      # time — and the window between them is real: the claim is acquired between the two
      # looks, so a dialog can appear after the counter armed and before anything types.
      # A guard that is unobservable because its siblings hold is not the same as a guard
      # that does nothing, and this is the one refusal the aggression ruling leaves
      # standing.
      #
      # THE FORCE IS RE-VALIDATED AGAINST THIS SECOND LOOK, not carried on the first.
      # The claim was acquired between the two, and a permission dialog can appear in
      # that window — which is exactly the state the bound must never type over. A seat
      # that left the roster between the looks is the same story. Re-reading here costs
      # nothing (the readiness was recomputed anyway) and makes the force answer the
      # question at the moment it acts rather than a moment earlier.
      if [ "$_forced" = 1 ]; then
        case "$ready" in
          busy:modal|busy:clearing|gone|unsafe) _forced=0 ;;
        esac
      fi
      if [ "$ready" = ready ] || [ "$due" = 1 ] || [ "$_forced" = 1 ] || [ "$_reprobe" = 1 ]; then
        tap_spool_bump_attempts "$id"
        # The force reaches the submit path as state, not as an argument, because it has
        # to survive `tap_spool_redeliver`'s own re-derivation of pane, harness and
        # sentinel — and because every other caller of that function must keep today's
        # behavior exactly. Set immediately before the call and cleared immediately
        # after, so no later iteration of this loop inherits a decision made for a
        # different entry.
        [ "$_forced" = 1 ] && export TAP_SUBMIT_FORCE_NO_PROMPT=1
        tap_spool_redeliver_locked "$id" "$target" "$pane" "$pane_id" "$to_team" "$target_registry" || redeliver_rc=$?
        unset TAP_SUBMIT_FORCE_NO_PROMPT
        case "$redeliver_rc" in
          0) delivered=1 ;;
          5) unverified=1 ;;
        esac
      else
        tap_spool_note_busy_probe "$id" "$ready"
      fi
      tap_spool_claim_release "$id"
      exec 8>&-
    fi
    # Refund the slot for a held entry (see `_held_slot` above): it either delivered —
    # in which case it is no longer held and the slot was legitimately used — or it is
    # still waiting on a recipient that is demonstrably there, and must not crowd out
    # the mail behind it. Checked against the CURRENT readiness, not the pre-attempt
    # one, so an entry whose seat left the roster keeps its slot and reaches the
    # terminal branch normally.
    #
    # AND NOT AT rc 5 (tap-nj22m U3, Codex thread `lib.sh:3622`). The predicate above
    # tested `_held_slot`, `delivered` and `ready` — none of which changes at
    # submit-unverified — while `tap_spool_redeliver` has ALREADY removed the spool
    # payload and metadata on that arm and stopped automatic retry. So the slot was
    # refunded for an entry that no longer exists, and a backlog of overdue entries all
    # going rc 5 processes the whole set in ONE invocation whatever the cap says. The
    # cap is the only bound on how much mail a single drain may move; an unbounded
    # refund does not slow the drain down, it removes that bound.
    #
    # The residency checks are not redundant with the rc-5 test and are not there for
    # symmetry: they are what makes the predicate true of the STATE rather than of one
    # known route to it. rc 5 is the route this thread found; any other path that
    # removes the entry mid-iteration refunds a slot for the same nonexistent entry, and
    # a predicate that names only rc 5 would have to be re-derived when one appears.
    #
    # `ready` stays in the predicate and stays LAST. It is the readiness the attempt was
    # made against, and the refund's original purpose — do not let an entry waiting on a
    # demonstrably-present recipient crowd out the mail behind it — is still exactly what
    # it answers.
    # A refund for every held entry removes the drain's only work bound. Preserve the
    # anti-starvation refund, but grant it at most `cap` times per invocation.
    if [ "$_held_slot" = 1 ] && [ "$delivered" != 1 ] && [ "$redeliver_rc" != 5 ] \
       && [ -f "$(tap_spool_payload_path "$id")" ] && [ -f "$(tap_spool_meta_path "$id")" ] \
       && tap_spool_recipient_is_present "$ready"; then
      tap_spool_update_held_visits "$id" increment
      if [ "$_refunds" -lt "$cap" ]; then
        seen=$((seen - 1)); _refunds=$((_refunds + 1))
      fi
    fi
    [ "$delivered" = 1 ] && continue
    if [ "$redeliver_rc" = 5 ]; then
      # rc 5 = canonical but submit-UNVERIFIED, and tap_spool_redeliver has
      # already removed the spool entry and stopped automatic retry. That is a
      # deliberate, correct decision — and until tap-13c8 it had NO ADDRESSEE:
      # it recorded itself to registry-events (rendered only by `tap outstanding`,
      # a PULL surface behind a doctrine that tells senders never to poll) and the
      # sender was never told. The entry vanished and the send simply never
      # arrived.
      #
      # This is the same defect the deadline path fixes, reached by a different
      # route — and it is why the arc pin was intermittent: whether the due
      # attempt got far enough to return 5, or was skipped as not-ready, decided
      # whether the sender heard anything at all.
      #
      # DELIBERATELY UNSCOPED, unlike the deadline branch below (which is limited
      # to deadline_source=readiness-gate). The difference is who removed the
      # entry: there, THIS code removes it, so the predicate decides whether an
      # entry that should have been held gets dropped. Here tap_spool_redeliver
      # has ALREADY removed it, for every park, as pre-existing behavior — so the
      # notice adds an addressee and changes no spool state at all. Scoping this
      # one for symmetry would only restore the silent discard for everyone else.
      #
      # The retry decision stands. What changes is that it now reaches someone.
      tap_spool_notify_sender_on_escalate "$id" "$target" \
        "submit unverified; automatic retry stopped" "$target_registry" possible || true
      continue
    fi
    # Escalation is an effect too: a losing contender must not notify while a
    # winning claimant is still submitting the same entry. The whole deadline
    # disposition — the live-recipient hold (tap-92v3r), the grace disposition, the
    # pre-effect grace reprobe, the settlement re-check inside the critical section
    # (P5), the escalation mark, the watcher's human alert, the sender wake and the
    # terminal step only a CONFIRMED wake licenses (tap-13c8, tap-31it) — is one
    # native transaction under the entry's claim: spool-deadline.ts
    # `disposeAtDeadline`. Its verdict is recorded, not acted on: the entry has
    # either left the spool or stays exactly as the transaction left it.
    _deadline="$(tap_spool_deadline_call "$id" "$now" at-deadline "$ready" "${_row[@]}")" || continue
    case "$_deadline" in
      not-due|claim-held|held-present|grace-disposed|reprobe-unreadable|reprobe-eligible|escalate-declined|escalated|terminalized) ;;
      *) printf 'tap: slice_failed id=%s slice=spool-deadline: invalid deadline verdict\n' "$id" >&2 ;;
    esac
  done < <(tap_spool_list "$scope_target" "$scope_registry" | python3 -B -c '
import json, sys
rows = []
for line in sys.stdin:
    try: rows.append(json.loads(line))
    except Exception: continue
def held_visits(row):
    try: return int(row.get("held_drain_visits") or 0)
    except Exception: return 0
def arrival_epoch(row):
    try: return int(row.get("first_spooled_epoch"))
    except Exception: return float("inf")
# Phase A clears the count when an entry becomes ready. The full key is local here:
# rotate still-held mail first, then preserve arrival order and its deterministic id tie.
for r in sorted(rows, key=lambda row: (held_visits(row), arrival_epoch(row), str(row.get("id") or ""))):
    # The pair may finish publishing after enumeration. Wait for a new snapshot;
    # never mark a fresh binding missing from a row that could not read it.
    if r.get("incomplete"): continue
    print("\x1f".join(str(r.get(k) or "") for k in ("id", "target", "reason", "reason_class", "timeout_seconds", "first_spooled_epoch", "pane", "pane_id", "to_team", "target_registry", "policy", "deadline_epoch", "escalated_at", "deadline_source", "hold_until_epoch")))
')

  # --- Phase C: inject planned digests (tap-ix63) ------------------------------
  # Runs AFTER the per-id pass so carved-out urgent/escalate entries and any lone
  # individuals already took their solo wakes this tick. Each group is one claim-
  # snapshotted, submit-then-move digest; a skip/failure (rc 1|2) leaves its
  # entries individually redeliverable on the next drain. Submit-unverified
  # (rc 5/124) is canonicalized without retry and aggregated after this bounded pass.
  if [ -n "$_digest_plan" ]; then
    while IFS=$'\x1f' read -r _tr _tt _h _p _pi _ids; do
      [ -n "$_ids" ] || continue
      _digest_rc=0
      tap_spool_digest_inject "$_tr" "$_tt" "$_h" "$_p" "$_pi" $_ids || _digest_rc=$?
      case "$_digest_rc" in 5|124) unverified=1 ;; esac
    done <<EOF
$_digest_plan
EOF
  fi
  if [ "$unverified" = 1 ]; then
    exit 5
  fi
  exit 0
  )
}

# RIDE-ALONG IS DRAIN-SIDE ONLY (tap-31it, cut ratified by fable-compress
# 2026-08-18). A direct-path flush existed here: `tap send` rang the doorbell for
# a pane's held items immediately before injecting its own sentinel. It was
# deleted rather than re-ordered, and the reason is worth keeping because the
# shape is inviting.
#
# The doorbell's own Enter STARTS A TURN, and a working claude/codex pane shows no
# input prompt while it runs (the `busy:noprompt` class). The very next
# `tap_submit_verify` — for the message the sender actually typed — then found no
# prompt and deferred to the spool. Driven, not argued: with a held item present
# the direct send returned `status=queued`; with no held item, byte-identical
# input returned `status=injected`. So the flush converted the carve-out's
# beneficiary into its victim: a `tap reply` outbound carrying `--wake` (the caller
# shape of the day — ruling 51 has since dropped `--wake` from tap reply in favour
# of its unconditional `--in-reply-to`), the answer a peer is yielded on, parked
# behind an unrelated FYI.
#
# Flushing AFTER the submit instead only moves the collision: the digest's own
# submit would meet the same prompt-less pane. The original ordering was chosen to
# avoid a REFUSED flush — and a refused flush is benign: the items stay spooled and
# claim-free and arrive on the hold clock, which is the latency the hold already
# tolerates by design. Protecting against the benign failure cost the one message
# class that could least afford it.
#
# If ride-along on the direct path ever returns, it returns behind a SINGLE
# SERIALIZED DELIVERY OWNER — never a pre-submit helper that changes the pane
# state the next submit depends on.

# Register-only recovery. Sender and private settlement paths have no drain.
# A scope must be explicit so an old caller cannot silently recover the whole bus.
tap_spool_opportunistic_drain() { # <registering target> <target_registry>
  [ -n "${1:-}" ] && [ -n "${2:-}" ] || return 0
  [ "${TAP_SPOOL_DRAIN_ACTIVE:-0}" != 1 ] || return 0
  [ "${TAP_SPOOL_DISABLE_OPPORTUNISTIC:-0}" != 1 ] || return 0
  tap_reset_fence_present && return 0
  [ -d "$TAP_SPOOL" ] || return 0
  compgen -G "$TAP_SPOOL/*.md" >/dev/null || return 0
  tap_spool_drain_once "" "" "$1" "$2" >/dev/null 2>&1 || true
}

# <id> — one detached waiter per actual park. Bounded by the park's deadline for every
# class EXCEPT a held live entry (tap-92v3r): a readiness-gate park whose recipient is
# still present outlives its deadline, and its waiter stays with it, holding and
# refreshing the `.reown` lease so this function's caller declines to mint a second
# owner. See runtime/bun/src/spool-waiter-loop.ts for the lifetime rule.
tap_spool_spawn_deliverer() { # <id>; a `.reown` lease travels in TAP_SPOOL_REOWN_TOKEN
  # Body: runtime/bun/src/spool-park-report.ts `spawnDeliverer` — the detached waiter
  # launch, `TAP_SPOOL_DISABLE_DELIVERER` honoured, the lease released on a suppressed
  # or failed spawn (the only place that knows the spawn did not happen).
  local verdict
  verdict="$(tap_bun_call spool-park-report "$1" spool-park-report.ts spawn-deliverer "$_TAP_SCRIPT_DIR" "$TAP_HOME" "$TAP_SPOOL" "$1" "${TAP_SPOOL_REOWN_TOKEN:-}")" || return 1
  case "$verdict" in
    ok) return 0 ;;
    failed) return 1 ;;
    *) printf 'tap: slice_failed id=%s slice=spool-park-report: invalid spawn verdict\n' "$1" >&2; return 1 ;;
  esac
}



# --- envelope shape (transport validates SHAPE only; kind stays opaque) --------
# Parse a `key: value` field from a payload's YAML-ish frontmatter (first block).
tap_envelope_field() {
  local payload="$1" key="$2"
  awk -v k="$key" '
    NR==1 && $0!="---" { exit 1 }
    NR>1 && $0=="---"  { exit 0 }
    NR>1 { if ($0 ~ "^"k":[ \t]") { sub("^"k":[ \t]*",""); sub(/\r$/,""); print; exit 0 } }
  ' "$payload" 2>/dev/null
}
# Assert the required envelope fields exist + are non-empty. Interprets NO values
# (kind must be present + non-empty, but its meaning belongs to AESOP, not TAP).
tap_validate_envelope() {
  local payload="$1" f v
  [ -f "$payload" ] || { echo "envelope: payload not found: $payload" >&2; return 1; }
  for f in id from to kind path; do
    v="$(tap_envelope_field "$payload" "$f")"
    [ -n "$v" ] || { echo "envelope: missing/empty field '$f' in $payload" >&2; return 1; }
    case "$f" in
      id) tap_valid_id "$v" || { echo "envelope: field 'id' value '$v' fails charset $TAP_ID_RE in $payload" >&2; return 1; } ;;
      from|to|kind) tap_valid_token "$v" || { echo "envelope: field '$f' value '$v' fails charset $TAP_ID_RE in $payload" >&2; return 1; } ;;
      path) tap_valid_path_token "$v" || { echo "envelope: field 'path' value '$v' is not sentinel-safe (no whitespace or ]) in $payload" >&2; return 1; } ;;
    esac
  done
  return 0
}

# Describe a replayed settlement and the actor's still-open inbound work.
# ponytail: O(n) only on this error path; add an index if large buses make it slow.
tap_already_settled_detail() ( # <id> <actor> <payloads-dir> <receipts-dir>
  local id="$1" actor="${2:-}" payloads_dir="$3" receipts_dir="$4"
  local receipt="$receipts_dir/$id.done" cancel_receipt="$receipts_dir/$id.cancelled"
  local settled_at="" settled_via="" payload base open_id local_team=""
  local -a open_ids=()

  if [ -f "$receipt" ]; then
    settled_at="$(python3 -B -c 'import json,sys; print(json.load(open(sys.argv[1])).get("at", ""))' "$receipt" 2>/dev/null || true)"
    settled_via="$(python3 -B -c 'import json,sys; print(json.load(open(sys.argv[1])).get("via", "done"))' "$receipt" 2>/dev/null || true)"
    [ -n "$settled_at" ] || settled_at="unknown"
  elif [ -f "$cancel_receipt" ]; then
    settled_at="$(python3 -B -c 'import json,sys; print(json.load(open(sys.argv[1])).get("at", ""))' "$cancel_receipt" 2>/dev/null || true)"
    # Read the field, exactly as the .done branch above does. Hardcoding
    # "cancelled" reported a sender WITHDRAWAL (via: withdrawn, tap withdraw) as
    # an ordinary cancellation — the difference between "your addressee was
    # gone" and "the sender superseded this". An unreadable receipt keeps the
    # historical answer rather than inventing one.
    settled_via="$(python3 -B -c 'import json,sys; print(json.load(open(sys.argv[1])).get("via", "cancelled"))' "$cancel_receipt" 2>/dev/null || true)"
    [ -n "$settled_via" ] || settled_via="cancelled"
    [ -n "$settled_at" ] || settled_at="unknown"
  else
    settled_at="unknown"
    settled_via="unknown"
  fi

  shopt -s nullglob
  if [ -n "$actor" ]; then
    local_team="$(tap_spool_team_name)"
    for payload in "$payloads_dir"/*.md; do
      base="${payload##*/}"
      case "$base" in _*) continue ;; esac
      open_id="${base%.md}"
      [ ! -e "$receipts_dir/$open_id.done" ] || continue
      [ ! -e "$receipts_dir/$open_id.cancelled" ] || continue
      tap_validate_envelope "$payload" >/dev/null 2>&1 || continue
      [ "$(tap_envelope_field "$payload" id || true)" = "$open_id" ] || continue
      [ "$(tap_envelope_field "$payload" to || true)" = "$actor" ] || continue
      tap_target_team_is_local "$(tap_envelope_field "$payload" to_team || true)" "$local_team" || continue
      open_ids+=("$open_id")
    done
  fi

  if [ "${#open_ids[@]}" -eq 0 ]; then
    printf 'id %s already settled at %s; you have 0 open: none' "$id" "$settled_at"
  else
    printf 'id %s already settled at %s; you have %s open: %s' \
      "$id" "$settled_at" "${#open_ids[@]}" "${open_ids[*]}"
  fi
)

# Stamp the courier-authoritative routing fields (id/from/to/kind/path) into a
# payload's first frontmatter block and emit to stdout, preserving every other
# frontmatter key (re:, verdict:, …) and the body verbatim. This is what makes
# "omit --id" REAL (CONTRACT §send / F9): the writer may leave id/path out and
# the courier fills them into the CANONICAL payload BEFORE validation, so the
# on-disk payload can never disagree with the injected sentinel. Routing args win
# over any writer-supplied copy of these five fields; they are re-emitted once,
# just inside the closing fence. The source must open with a `---` frontmatter
# fence (writers always include one); fail loud otherwise.
tap_stamp_envelope() {
  local src="$1" id="$2" from="$3" to="$4" kind="$5" path="$6" xwt="${7:-}" reply="${8:-}" from_team="${9:-}" to_team="${10:-}" urgency="${11:-}" reply_to="${12:-}" in_reply_to="${13:-}" recipient_instance="${14:-}" sender_instance="${15:-}" first=""
  local to_adopted_from="${16:-}" original_recipient_instance="${17:-}" adopted_from="${18:-}" sentinel_preview="${19:-}"
  [ -f "$src" ] || die "stamp_envelope: source not found: $src"
  IFS= read -r first < "$src" || true   # portable first-line read (macOS sed lacks --)
  [ "$first" = "---" ] || die "stamp_envelope: $src has no opening frontmatter fence"
  # xwt: when non-empty, stamp cross_worktree: true (F2B-1). reply: when non-empty,
  # stamp the sender-declared reply expectation (R22, expected|settle-only) — the
  # courier always sets it on v0.3 sends; absent on old v0.2 traffic reads as
  # reply-expected. from_team/to_team (tap-yv3, codex P1): courier-owned cross-team
  # provenance, same class as the five routing fields — a writer-supplied copy is
  # ALWAYS dropped (unconditionally, regardless of whether this send re-stamps a
  # value), never merely overwritten-when-present. Spoofed provenance here isn't
  # just trust-model noise: poll/outstanding/health display these and a reply
  # addresses off from_team, so a surviving fake value misroutes a reply. urgency
  # (delivery-policies plan PR-B): same courier-owned class, present only on a
  # `--urgent` send (value `urgent`) — absent means default/polite, same
  # present-only-when-relevant pattern as to_team. reply_to (tap-ywb, v0.5):
  # same courier-owned-when-present class — stamped only from a validated
  # `--reply-to`/seat auto-stamp, never trusted from the writer, since a
  # surviving spoofed value would misroute the NEXT reply just like from_team.
  # in_reply_to (tap-qnpn) is likewise courier-owned and appears only on an
  # outbound composed by tap reply; it correlates that canonical to its inbound.
  # recipient_instance / sender_instance (v0.20 KTD-16): courier-owned when the
  # flip is live — omit when empty (null = unbound). Writer copies are dropped.
  awk -v id="$id" -v from="$from" -v to="$to" -v kind="$kind" -v path="$path" -v xwt="$xwt" -v reply="$reply" -v from_team="$from_team" -v to_team="$to_team" -v urgency="$urgency" -v reply_to="$reply_to" -v in_reply_to="$in_reply_to" -v recipient_instance="$recipient_instance" -v sender_instance="$sender_instance" -v to_adopted_from="$to_adopted_from" -v original_recipient_instance="$original_recipient_instance" -v adopted_from="$adopted_from" -v sentinel_preview="$sentinel_preview" '
    BEGIN { infm=0; stamped=0 }
    NR==1 && $0=="---" { print; infm=1; next }
    infm && $0=="---" {
      print "id: " id; print "from: " from; print "to: " to
      print "kind: " kind; print "path: " path
      if (xwt != "") print "cross_worktree: true"
      if (reply != "") print "reply: " reply
      if (from_team != "") print "from_team: " from_team
      if (to_team != "") print "to_team: " to_team
      if (urgency != "") print "urgency: " urgency
      if (reply_to != "") print "reply_to: " reply_to
      if (in_reply_to != "") print "in_reply_to: " in_reply_to
      if (recipient_instance != "") print "recipient_instance: " recipient_instance
      if (sender_instance != "") print "sender_instance: " sender_instance
      if (to_adopted_from != "") print "to_adopted_from: " to_adopted_from
      if (original_recipient_instance != "") print "original_recipient_instance: " original_recipient_instance
      if (adopted_from != "") print "adopted_from: " adopted_from
      if (sentinel_preview != "") print "sentinel_preview: " sentinel_preview
      print "---"; infm=0; stamped=1; exit
    }
    infm && $0 ~ /^(id|from|to|kind|path|cross_worktree|reply|from_team|to_team|urgency|reply_to|in_reply_to|recipient_instance|sender_instance|to_adopted_from|original_recipient_instance|adopted_from|sentinel_preview):[ \t]/ { next }   # drop writer copies unconditionally; re-emitted above only from courier args
    { print }
    END { if (!stamped) { print "stamp_envelope: no closing frontmatter fence" > "/dev/stderr"; exit 1 } }
  ' "$src" || die "stamp_envelope: failed to stamp $src (malformed frontmatter?)"
  python3 -B - "$src" <<'PYBODY'
from pathlib import Path
import sys
data = Path(sys.argv[1]).read_bytes()
end = data.find(b"\n---\n", 3)
end = end + 5 if end >= 0 else len(data)
sys.stdout.buffer.write(data[end:])
PYBODY
}

# tap_canonical_place <src> <id> <from> <to> <kind> <dest> [xwt] [reply] [from_team] [to_team] [urgency] [reply_to] [in_reply_to] [recipient_instance] [sender_instance]
# Unit 2 atomic-write contract: stamp routing fields into a private staging file
# under $TAP_HOME/tmp/ (same filesystem as payloads/ so mv is atomic), validate
# the staged envelope, then rename into <dest>. If stamping or validation fails
# the staging file is removed and die exits 1 — <dest> is never created.
# tap send is the production caller. tap command's auto-settled audit writer
# applies the same stamp/validate/stage/rename invariants directly because it
# prebuilds several mutually exclusive outcomes before pane input.
tap_canonical_place() {
  local src="$1" id="$2" from="$3" to="$4" kind="$5" dest="$6" xwt="${7:-}" reply="${8:-}" from_team="${9:-}" to_team="${10:-}" urgency="${11:-}" reply_to="${12:-}" in_reply_to="${13:-}" recipient_instance="${14:-}" sender_instance="${15:-}"
  local to_adopted_from="${16:-}" original_recipient_instance="${17:-}" adopted_from="${18:-}" sentinel_preview="${19:-}"
  local stage_dir staging spool_payload spool_meta
  spool_payload="$(tap_spool_payload_path "$id")"
  spool_meta="$(tap_spool_meta_path "$id")"
  if [ -e "$spool_payload" ] || [ -e "$spool_meta" ]; then
    tap_fail 1 spooled_id wait_for_redelivery_or_remove_spool_entry \
      "id '$id' already has a spool entry: $spool_payload"
  fi
  if [ -e "$TAP_HOME/archive/index.ndjson" ] || [ -L "$TAP_HOME/archive/index.ndjson" ] || [ -L "$TAP_HOME/archive" ]; then
    local archive_rc=0
    python3 -B "$_TAP_SCRIPT_DIR/bus_archive_index.py" "$TAP_HOME" "$id" contains || archive_rc=$?
    case "$archive_rc" in
      0) die "canonical_place: refusing duplicate archived id '$id'" ;;
      1) ;;
      *) die "canonical_place: archive index unreadable; refusing placement" ;;
    esac
  fi
  stage_dir="$TAP_HOME/tmp"
  mkdir -p "$stage_dir"
  staging="$(mktemp "$stage_dir/.tap.XXXXXX")" \
    || die "canonical_place: mktemp failed in $stage_dir"
  # Run tap_stamp_envelope in a subshell: its die/exit exits only the subshell,
  # letting us clean up the staging file before re-dying in the outer shell.
  if ! ( tap_stamp_envelope "$src" "$id" "$from" "$to" "$kind" "$dest" "$xwt" "$reply" "$from_team" "$to_team" "$urgency" "$reply_to" "$in_reply_to" "$recipient_instance" "$sender_instance" "$to_adopted_from" "$original_recipient_instance" "$adopted_from" "$sentinel_preview" > "$staging" ) 2>/dev/null; then
    rm -f "$staging"
    die "canonical_place: stamp failed for $src"
  fi
  if ! tap_validate_envelope "$staging" >/dev/null 2>/dev/null; then
    rm -f "$staging"
    die "canonical_place: envelope invalid after stamp (need id/from/to/kind/path)"
  fi
  if [ -e "$dest" ]; then
    rm -f "$staging"
    die "canonical_place: refusing duplicate id '$id' (payload already exists: $dest)"
  fi
  if [ -e "$TAP_RECEIPTS/$id.done" ]; then
    rm -f "$staging"
    die "canonical_place: refusing duplicate id '$id' (receipt already settled: $TAP_RECEIPTS/$id.done)"
  fi
  mv -f "$staging" "$dest" \
    || { rm -f "$staging"; die "canonical_place: rename to $dest failed"; }
  # Place-time attribution (tap-ejpf): written HERE so exit-5 / deferred-spool
  # paths that never reach .sent still count as courier mail. Failure to write
  # is loud but non-fatal to the already-renamed payload — poll will LABEL it
  # unattributed rather than invent a second source of truth.
  tap_write_placed "$id" courier \
    || echo "tap: warning: placed receipt not written for $id (payload is on the bus; poll will label unattributed)" >&2
}

# tap_reconstruct_sentinel <canonical-payload-path> -> the [[TAP ...]] sentinel string
# Rebuilds the EXACT sentinel `tap send` would have injected, from a canonical
# payload's OWN already-stamped frontmatter (id/from/to/kind/reply/from_team/
# to_team/urgency) — the shared single source of truth for sentinel shape, so a
# second injection site (redelivery, U14) can never drift from tap-send.sh's own
# construction. Slash-qualification mirrors tap-send.sh's canonical <team>/<handle>
# form exactly (NamingWave; colon stays legacy INPUT-ONLY, never emitted): from is
# qualified whenever from_team is stamped (every cross-worktree send stamps its
# own team); to is qualified only when to_team is also stamped (a manual
# --cross-worktree --pane send never learns the recipient's team). urgency is
# carried through informationally (the recipient's context for why its turn
# died) even though a redelivery here never replays the interrupt itself — an
# urgent send only ever reaches the spool via a safety-gate defer (copy-mode/
# dead pane), and by the time such an entry is genuinely ready to redeliver the
# harness is no longer mid-turn, so a plain injection is already correct.
#
# It took a <target-registry> argument until tap-0z9l: that parameter existed
# solely to measure the v0.18 path diet, which is gone, so every caller now passes
# one fewer argument and the pointer is emitted unconditionally. The argument was
# DROPPED rather than left unread — plumbing nothing consumes is the on-ramp for
# restoring the diet, and the constructor comment above is the reason we do not
# want it restored. (tap_spool_add still persists target_registry in entry meta;
# it stays live for team resolution, just no longer for the wire.)
tap_reconstruct_sentinel() {
  local payload="$1" id from to kind reply from_team to_team urgency canon sentinel_from sentinel_to
  id="$(tap_envelope_field "$payload" id)"
  from="$(tap_envelope_field "$payload" from)"
  to="$(tap_envelope_field "$payload" to)"
  kind="$(tap_envelope_field "$payload" kind)"
  reply="$(tap_envelope_field "$payload" reply)"
  from_team="$(tap_envelope_field "$payload" from_team)"
  to_team="$(tap_envelope_field "$payload" to_team)"
  urgency="$(tap_envelope_field "$payload" urgency)"
  [ -n "$id" ] && [ -n "$from" ] && [ -n "$to" ] && [ -n "$kind" ] \
    || die "reconstruct_sentinel: $payload missing id/from/to/kind"
  canon="$(tap_payload_path "$id")"
  # The argument is read for FRONTMATTER; the wire pointer is the AMBIENT
  # canonical derived from the id. So the two must name the same file, or this
  # would emit a pointer to a path the bytes are not at. (Under the v0.18 diet,
  # removed by tap-0z9l, a mismatch could also SILENTLY OMIT the pointer on the
  # strength of a location the payload does not occupy; that half is gone with
  # the predicate, but the wrong-pointer half remains and is why this check
  # stays.) The
  # sole caller moves the payload to exactly this location immediately before
  # calling, which makes the check a no-op invariant today; it is here so a
  # future caller handed a non-canonical file fails LOUDLY instead of shipping a
  # sentinel that points nowhere. Callers wrap this in `$(… || true)`, so a
  # refusal yields an empty sentinel and the entry stays spooled for retry —
  # never a delivery with a wrong pointer.
  [ "$payload" = "$canon" ] \
    || die "reconstruct_sentinel: '$payload' is not this bus's canonical for id '$id' (expected $canon)"
  sentinel_from="$from"; sentinel_to="$to"
  [ -n "$from_team" ] && sentinel_from="${from_team}/${from}"
  [ -n "$to_team" ] && sentinel_to="${to_team}/${to}"
  tap_sentinel_render "$sentinel_from" "$sentinel_to" \
    "$id" "$kind" "${reply:-expected}" "$urgency" "$canon"
}

# --- registry helpers (Unit 1) -----------------------------------------------
# These primitives give tap-register.sh and tap-send.sh a clean, portable interface
# to the new registry schema without each script embedding its own JSON logic.
# Back-compat: absent registry, absent entry, or absent status field → treated as
# "active" so that legacy {pane}-only registries never produce a hard failure.

# tap_registry_status <handle>
# Returns the routing state for <handle> from the acting registry (stored
# registry_location post-flip; $TAP_REGISTRY pre-flip). Seats-first map.
# An active row whose launcher transaction is not ready reports "launching"
# and is non-routable. Absent registry, absent entry, or missing status field
# → "active" (back-compat). Always exits 0 and always prints exactly one line.
tap_registry_status() {
  local handle="$1" reg
  reg="$(tap_acting_registry)" || { printf 'active'; return 0; }
  [ -f "$reg" ] || { printf 'active'; return 0; }
  python3 -B - "$reg" "$handle" "${_TAP_SCRIPT_DIR}" <<'PY'
import sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import _seat_map, load_state_doc
try:
    reg = load_state_doc(sys.argv[1])
except Exception:
    print("active"); sys.exit(0)
ent = _seat_map(reg).get(sys.argv[2]) or {}
if not isinstance(ent, dict):
    print("active"); sys.exit(0)
if ent.get("status", "active") == "active" and ent.get("status_reason") == "launching":
    print("launching")
else:
    print(ent.get("status", "active"))
PY
}

# Shared read/reply/done authority (tap-7r3fn.27). Success sets _ADDRESSEE_GRANT
# and prints grant_from; --quiet suppresses the print, never error output.
# Failure leaves class/detail/action for the caller; only verified mismatches
# may be overridden by read --force. ID, FROM and LOCAL_TEAM are caller context.
tap_addressee_grant_check() { # <actor> <to> <to_adopted_from> <recipient_instance> [--quiet]
  # One implementation on both doors: runtime/bun/src/addressee-grant.ts (D2-u1).
  # This adapter resolves what the incumbent resolved — the flip marker (its
  # hard refusals on an invalid or unreadable marker stay in
  # tap_v20_obligation_live), the two acting-registry lookups it used, and the
  # team history dir — and hands them to the module; it decides nothing. The
  # module fills _ADDRESSEE_GRANT, _ADDRESSEE_ACTOR_INSTANCE, _ADDRESSEE_CLASS,
  # _ADDRESSEE_DETAIL, _ADDRESSEE_NEXT, _ADDRESSEE_INST_MISMATCH and the
  # _REMEDY_* trio exactly as the Bash body did.
  local _ag_actor="$1" _ag_to="$2" _ag_adopted="$3" _ag_rinst="$4" _ag_quiet="${5:-}"
  local _ag_marker=absent _ag_reg _ag_adopt_reg _ag_hist _ag_result
  _ADDRESSEE_GRANT=""; _ADDRESSEE_ACTOR_INSTANCE=""; _ADDRESSEE_CLASS=not_addressee; _ADDRESSEE_INST_MISMATCH=0
  _ADDRESSEE_DETAIL=""; _ADDRESSEE_NEXT=""; _REMEDY_KIND=unknown; _REMEDY_NEXT=""; _REMEDY_DETAIL=""; _AG_OK=0
  # Do not short-circuit marker validation under --force.
  if tap_v20_obligation_live; then _ag_marker=live; fi
  _ag_reg="$(tap_acting_registry "${LOCAL_TEAM:-}" || true)"
  _ag_adopt_reg="$(tap_acting_registry || true)"
  _ag_hist="$(tap_team_dir_from_bus 2>/dev/null || true)"
  [ -z "$_ag_hist" ] || _ag_hist="$(tap_team_history_dir "$_ag_hist")"
  _ag_result="$(mktemp "${TMPDIR:-/tmp}/tap-grant.XXXXXX")" \
    || tap_fail 1 slice_failed "tap doctor" "could not allocate an addressee-grant result"
  if ! tap_bun_call addressee-grant "${ID:-}" addressee-grant.ts grant --result "$_ag_result" -- \
      "$_ag_reg" "$_ag_adopt_reg" "$_ag_marker" "${LOCAL_TEAM:-}" "$_ag_hist" "${ID:-}" "${FROM:-}" \
      "$_ag_actor" "$_ag_to" "$_ag_adopted" "$_ag_rinst"; then
    rm -f "$_ag_result"
    tap_fail 1 slice_failed "tap doctor" "addressee grant did not complete for '${ID:-}'; resolve the runtime and retry"
  fi
  tap_bun_read_pairs "$_ag_result" "addressee grant"
  tap_bun_require_pairs "addressee grant" _AG_OK _ADDRESSEE_GRANT _ADDRESSEE_ACTOR_INSTANCE _ADDRESSEE_CLASS \
    _ADDRESSEE_DETAIL _ADDRESSEE_NEXT _ADDRESSEE_INST_MISMATCH _REMEDY_KIND _REMEDY_NEXT _REMEDY_DETAIL
  if [ "$_AG_OK" = 1 ]; then
    if [ "$_ag_quiet" != --quiet ] && [ -n "$_ADDRESSEE_GRANT" ]; then printf '%s' "$_ADDRESSEE_GRANT"; fi
    return 0
  fi
  return 1
}

# tap_adopted_into <handle> — prints the successor seat that adopted <handle> at reclaim
# (the row carrying <handle> in its `adopted_handles` grant), or nothing. tap-p6el: a
# released fork is NOT a settler (§6, whole-ass), so `tap done|reply --by <fork>` refuses
# and names the successor. A <handle> that is ITSELF a currently-active registered seat is
# NOT treated as adopted-away — a re-registered handle settles its own mail normally, and a
# stale grant never blocks a live seat. Always exits 0; prints exactly the successor or "".
# Grant-path settlement that must survive a fresh same-handle fork uses
# tap_addressee_grant_check instead (the Bun addressee grant, keyed by successor +
# fork [+ instance]).
# Reads the acting registry (stored loc post-flip) via seats-first map.
tap_adopted_into() {
  local handle="$1" reg
  reg="$(tap_acting_registry)" || return 0
  [ -f "$reg" ] || return 0
  python3 -B - "$reg" "$handle" "${_TAP_SCRIPT_DIR}" <<'PY'
import sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import _seat_map, load_state_doc
try:
    reg = load_state_doc(sys.argv[1])
except Exception:
    sys.exit(0)
seats = _seat_map(reg)
handle = sys.argv[2]
live = seats.get(handle)
# A live active seat by that name owns its own mail — never adopted-away.
if isinstance(live, dict) and live.get("status", "active") == "active":
    sys.exit(0)
for name, ent in sorted(seats.items()):
    if not isinstance(ent, dict):
        continue
    grant = ent.get("adopted_handles") or []
    if isinstance(grant, list) and handle in grant:
        print(name)
        break
PY
}

# tap_delivery_class <handle> -> pane|poll (default pane)
# THE single authority for a member's delivery class (CONTRACT.md §Poll-mode
# delivery class): decided once, at register time, and read here by send, reply,
# health, watch, and nudge. Never inferred at send time from pane state — an absent
# registry, absent entry, or missing/unrecognized `delivery` field all read as the
# back-compat default "pane". Always exits 0 and prints exactly one line.
# Acting registry + seats-first (Cluster A).
tap_delivery_class() {
  local handle="$1" reg
  reg="$(tap_acting_registry)" || { printf 'pane'; return 0; }
  [ -f "$reg" ] || { printf 'pane'; return 0; }
  python3 -B - "$reg" "$handle" "${_TAP_SCRIPT_DIR}" <<'PY'
import sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import _seat_map, load_state_doc
try:
    reg = load_state_doc(sys.argv[1])
except Exception:
    print("pane"); sys.exit(0)
ent = _seat_map(reg).get(sys.argv[2]) or {}
if not isinstance(ent, dict):
    print("pane"); sys.exit(0)
d = ent.get("delivery") or "pane"
print(d if d in ("pane", "poll") else "pane")
PY
}

# tap_registry_mark_suspended <handle> <reason>
# Atomically sets status/status_reason for <handle> in TAP_REGISTRY under the
# registry flock (temp+rename, preserves all other keys). No-op when registry
# is absent or handle is not in it. Best-effort: any Python/IO error is
# silently swallowed so callers can always proceed to their own exit path
# without being killed by set -e. When reason is pane_gone, also stamps
# exited_at (first observation wins) so `tap out -` can order dead seats.
#
# tap-o4ae: a pane_gone suspension requires a REACHABLE tmux server. A dead or
# synthetic socket (e.g. leaked TMUX=/fake/socket from a smoke fixture) is not
# evidence the pane is gone — fail closed means NO registry write (return 1).
# Other reasons (user_removed, …) are unaffected.
#
# tap-yn2y: in-lock validate_locked_registry_authority after flock; on
# AUTHORITY_RETRY_EXIT (17) rebind once and retry — never mutate a retired
# bus mirror a writer locked before migrate published the marker.
tap_registry_mark_suspended() {
  local handle="$1" reason="$2" attempt=0 rc=0 root=""
  # No-op when acting registry unreachable/absent (same polarity as pre-flip
  # missing bus registry) — never write through a retired bus decoy.
  tap_require_acting_registry || return 0
  if [ "$reason" = "pane_gone" ] && ! tap_tmux_server_reachable; then
    return 1
  fi
  root="$(tap_team_dir_from_bus 2>/dev/null || true)"
  [ -n "$root" ] || root="$(_tap_repo_root 2>/dev/null || true)"
  [ -n "$root" ] || return 1
  while [ "$attempt" -lt 2 ]; do
    attempt=$((attempt + 1))
    rc=0
    TAP_SCRIPTS_DIR="${_TAP_SCRIPT_DIR}" TAP_INDEX_HOME="$(tap_index_home)" \
      python3 -B - "$TAP_REGISTRY" "$handle" "$reason" "$root" <<'PY' || rc=$?
import datetime, fcntl, json, os, sys, tempfile
sys.path.insert(0, os.environ.get("TAP_SCRIPTS_DIR") or "")
from registry_v20 import validate_locked_registry_authority
path, handle, reason, root = sys.argv[1:5]
d = os.path.dirname(path) or "."
index_home = os.environ.get("TAP_INDEX_HOME")
with open(path + ".lock", "w") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    validate_locked_registry_authority(path, root, index_home=index_home)
    try:
        with open(path) as fh:
            reg = json.load(fh)
    except Exception:
        sys.exit(0)
    # Mutate the live storage key (seats post-flip, agents pre-flip) — never
    # invent a parallel agents map beside seats-only team-registry.json.
    seat_key = "seats" if isinstance(reg.get("seats"), dict) else "agents"
    agents = reg.get(seat_key) if isinstance(reg.get(seat_key), dict) else {}
    ent = agents.get(handle)
    if ent is None:
        sys.exit(0)
    ent["status"] = "suspended"
    ent["status_reason"] = reason
    if reason == "pane_gone" and not ent.get("exited_at"):
        ent["exited_at"] = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    reg[seat_key] = agents
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tap.")
    with os.fdopen(fd, "w") as fh:
        json.dump(reg, fh, indent=2, sort_keys=True)
        fh.write("\n")
    os.replace(tmp, path)
PY
    [ "$rc" != 17 ] && break
    [ "$attempt" = 2 ] && break
    tap_rebind_acting_registry || break
  done
  # Best-effort: refuse/retry exhaustion → no write (callers proceed).
  [ "$rc" = 0 ] || return 1
  return 0
}

# tap_registry_invalidate_server_restart [<team>]
# Write-time catch-up for the shared session-name classifier's restart verdict.
# Every ordinary command calls this once for its acting team before dispatch. If
# a pane-backed row's stored server epoch or boot id is positively stale, clear
# every live pane coordinate under the registry lock and park an active row as
# suspended/server_restarted. Session name, native resume identity, instance,
# policy, and unknown fields are preserved. Rows already suspended keep their
# stronger lifecycle reason (for example user_removed); their stale coordinates
# are still cleared, but a machine restart must never make a deliberately
# removed seat relaunchable.
#
# This is deliberately TEAM-LOCAL. A normal command taking every enrolled
# team's lock would be surprising authority; each team's first command catches
# up its own durable bookkeeping while the read-time classifier already renders
# stale rows offline everywhere. A machine-wide rewrite adds no safety unless a
# future external registry reader bypasses that classifier (tap-y15e's reopen
# trigger).
#
# Both old and current stamps must be known before disagreement authorizes a
# write. An unreachable tmux server or unreadable boot id changes nothing. The
# caller treats failure as best-effort: point-of-effect recipient checks still
# refuse stale identity, so a lock/authority failure cannot turn the old id into
# delivery authority.
tap_registry_invalidate_server_restart() {
  local team="${1:-}" registry root output rc=0 attempt=0 probe_epoch probe_boot probe_boot_legacy probe_socket mismatch_possible
  local handle old_pane

  while [ "$attempt" -lt 2 ]; do
    attempt=$((attempt + 1))
    tap_authority_context "$team" || return 0
    registry="$TAP_AUTH_REGISTRY"
    [ -f "$registry" ] || return 0

    # Stay observational until there is evidence that catch-up may actually be
    # needed. Opening registry.lock is itself durable filesystem mutation, so a
    # rejected command against a current or unstamped registry must not leave a
    # sidecar behind. These samples are only a cheap filter: they NEVER license
    # a write. The authoritative samples are taken again below after the lock is
    # held, closing the registration/restart race at the mutation boundary.
    probe_socket="$(tap_server_socket_now 2>/dev/null || true)"
    [ -n "$probe_socket" ] || return 0
    probe_epoch="$(tap_server_epoch_now 2>/dev/null || true)"
    probe_boot="$(tap_boot_id 2>/dev/null || true)"
    probe_boot_legacy="$(tap_boot_epoch_id 2>/dev/null || true)"
    [ -n "$probe_epoch" ] || [ -n "$probe_boot" ] || return 0
    mismatch_possible="$(python3 -B - "$registry" "$probe_epoch" "$probe_boot" "$probe_boot_legacy" "$probe_socket" <<'PY'
import json, os, re, sys

registry, now_epoch, now_boot, now_legacy, now_socket = sys.argv[1:6]

def boot_matches(stored):
    if stored == now_boot:
        return True
    if "TAP_BOOT_ID" in os.environ and "TAP_BOOT_ID_LEGACY" not in os.environ:
        return False
    old = re.fullmatch(r"boot:(\d+)", stored or "")
    current = re.fullmatch(r"boot:(\d+)", now_legacy or "")
    return bool(old and current and abs(int(old.group(1)) - int(current.group(1))) <= 5)
try:
    document = json.load(open(registry))
except Exception:
    print("0")
    raise SystemExit
seats = document.get("seats") if isinstance(document.get("seats"), dict) else document.get("agents")
seats = seats if isinstance(seats, dict) else {}
for entry in seats.values():
    if not isinstance(entry, dict) or entry.get("delivery") == "poll":
        continue
    if not any(isinstance(entry.get(key), str) and entry.get(key)
               for key in ("pane", "pane_id", "pane_current_command")):
        continue
    if entry.get("server_socket") != now_socket:
        continue
    row_epoch = entry.get("server_epoch") or ""
    row_boot = entry.get("boot_id") or ""
    if ((row_epoch and now_epoch and row_epoch != now_epoch)
            or (row_boot and now_boot and not boot_matches(row_boot))):
        print("1")
        raise SystemExit
print("0")
PY
)"
    [ "$mismatch_possible" = 1 ] || return 0

    root="${TAP_IDX_ROOT:-}"
    [ -n "$root" ] || root="$(tap_team_dir_from_bus 2>/dev/null || true)"
    [ -n "$root" ] || root="$(_tap_repo_root 2>/dev/null || true)"
    [ -n "$root" ] || return 0

    # Automatic bookkeeping must not interleave with team reset or escape a
    # caller-declared scratch boundary. Run exit-bearing guards in subshells so
    # a refusal skips this best-effort catch-up without terminating dispatch.
    ( tap_reset_fence_guard "server-restart reconciliation" ) >/dev/null 2>&1 || return 0
    ( tap_scratch_only_guard "server-restart reconciliation" "$root" ) >/dev/null 2>&1 || return 0

    rc=0
    output="$(TAP_SCRIPTS_DIR="${_TAP_SCRIPT_DIR}" TAP_INDEX_HOME="$(tap_index_home)" \
      python3 -B - "$registry" "$root" <<'PY'
import fcntl, json, os, re, subprocess, sys, tempfile

sys.path.insert(0, os.environ.get("TAP_SCRIPTS_DIR") or "")
from registry_v20 import validate_locked_registry_authority

registry, root = sys.argv[1:3]
index_home = os.environ.get("TAP_INDEX_HOME")
directory = os.path.dirname(registry) or "."
changed = []

def current_epoch():
    override = os.environ.get("TAP_SERVER_EPOCH")
    if override is not None:
        return override
    try:
        result = subprocess.run(
            ["tmux", "display-message", "-p", "#{pid}:#{start_time}"],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
    except OSError:
        return ""
    raw = result.stdout.strip() if result.returncode == 0 else ""
    return "srv:" + raw if re.fullmatch(r"[0-9]+:[0-9]+", raw) else ""

def current_socket():
    try:
        result = subprocess.run(["tmux", "display-message", "-p", "#{socket_path}"],
                                text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        value = result.stdout.strip() if result.returncode == 0 else ""
        return value if os.path.isabs(value) and "\n" not in value else ""
    except OSError:
        return ""

def current_boot():
    override = os.environ.get("TAP_BOOT_ID")
    if override is not None:
        return override
    try:
        result = subprocess.run(
            ["sysctl", "-n", "kern.bootsessionuuid"], text=True,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
        value = result.stdout.strip().lower() if result.returncode == 0 else ""
        if re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", value):
            return "bootuuid:" + value
    except OSError:
        pass
    return current_boot_legacy()

def current_boot_legacy():
    override = os.environ.get("TAP_BOOT_ID_LEGACY")
    if override is not None:
        return override
    primary = os.environ.get("TAP_BOOT_ID")
    if primary and re.fullmatch(r"boot:\d+", primary):
        return primary
    try:
        result = subprocess.run(
            ["sysctl", "-n", "kern.boottime"], text=True,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
        match = re.search(r"\\{ sec = ([0-9]+)", result.stdout) if result.returncode == 0 else None
        if match:
            return "boot:" + match.group(1)
    except OSError:
        pass
    try:
        with open("/proc/stat") as fh:
            for line in fh:
                if line.startswith("btime "):
                    return "boot:" + line.split()[1]
    except OSError:
        pass
    return ""

def boot_matches(stored, current, legacy):
    if stored == current:
        return True
    if "TAP_BOOT_ID" in os.environ and "TAP_BOOT_ID_LEGACY" not in os.environ:
        return False
    old = re.fullmatch(r"boot:(\d+)", stored or "")
    now = re.fullmatch(r"boot:(\d+)", legacy or "")
    return bool(old and now and abs(int(old.group(1)) - int(now.group(1))) <= 5)

with open(registry + ".lock", "w") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    validate_locked_registry_authority(registry, root, index_home=index_home)
    # Observe machine provenance only after the registry lock is ours. A newly
    # registered binding from a restarted server must not be compared to a
    # generation sampled before the lock wait and then erased as "stale".
    now_socket = current_socket()
    if not now_socket:
        raise SystemExit(0)
    now_epoch, now_boot, now_boot_legacy = current_epoch(), current_boot(), current_boot_legacy()
    if not now_epoch and not now_boot:
        raise SystemExit(0)
    try:
        with open(registry) as fh:
            document = json.load(fh)
    except FileNotFoundError:
        raise SystemExit(0)

    seat_key = "seats" if isinstance(document.get("seats"), dict) else "agents"
    seats = document.get(seat_key) if isinstance(document.get(seat_key), dict) else {}
    for handle, entry in seats.items():
        if not isinstance(entry, dict) or entry.get("delivery") == "poll":
            continue
        has_binding = any(
            isinstance(entry.get(key), str) and bool(entry.get(key))
            for key in ("pane", "pane_id", "pane_current_command")
        )
        if not has_binding:
            continue
        if entry.get("server_socket") != now_socket:
            continue
        row_epoch = entry.get("server_epoch") or ""
        row_boot = entry.get("boot_id") or ""
        stale_epoch = bool(row_epoch and now_epoch and row_epoch != now_epoch)
        stale_boot = bool(row_boot and now_boot and not boot_matches(row_boot, now_boot, now_boot_legacy))
        if not (stale_epoch or stale_boot):
            continue

        old_pane = entry.get("pane") or entry.get("pane_id") or ""
        for key in ("pane", "pane_id", "pane_current_command"):
            entry.pop(key, None)
        if entry.get("status", "active") in ("active", "pending"):
            entry["status"] = "suspended"
            entry["status_reason"] = "server_restarted"
        changed.append((str(handle), str(old_pane)))

    if changed:
        document[seat_key] = seats
        fd, temporary = tempfile.mkstemp(dir=directory, prefix=".tap.")
        try:
            with os.fdopen(fd, "w") as fh:
                json.dump(document, fh, indent=2, sort_keys=True)
                fh.write("\n")
            os.replace(temporary, registry)
        except BaseException:
            try:
                os.unlink(temporary)
            except OSError:
                pass
            raise

for handle, old_pane in changed:
    print(handle + "\x1f" + old_pane)
PY
    )" || rc=$?

    if [ "$rc" = 17 ] && [ "$attempt" -lt 2 ]; then
      continue
    fi
    [ "$rc" = 0 ] || return 1
    while IFS=$'\x1f' read -r handle old_pane; do
      [ -n "$handle" ] || continue
      tap_registry_event_append "dispatcher" server_restarted "$handle" "$old_pane" \
        "cleared stale pane binding" >/dev/null 2>&1 || true
    done <<< "$output"
    return 0
  done
  return 1
}

# tap_registry_ensure_team <registry-path> <worktree-root> <branch> [lock-timeout]
# Shared bootstrap for the top-level registry team block. `tap register` and
# `tap init` both call this so their first-writer behavior stays byte-identical:
# JSON is dumped with sort_keys + indent=2, existing team metadata is preserved,
# and legacy registries get an `agents` object plus a missing team name only.
# Omitting lock-timeout preserves the legacy blocking flock; register passes its
# hook-only bound so SessionStart cannot stall behind another registry writer.
#
# tap-yn2y: in-lock validate_locked_registry_authority (with unenrolled-canonical
# bootstrap carve-out). AUTHORITY_RETRY_EXIT (17) rebinds TAP_REGISTRY once and
# retries — a writer that locked the bus through migrate publication must not
# mutate the retired mirror.
tap_registry_ensure_team() {
  local path="$1" worktree="$2" branch="${3:-unknown}" lock_timeout="${4:-}" err detail rc attempt=0
  mkdir -p "$(dirname -- "$path")"
  while [ "$attempt" -lt 2 ]; do
    attempt=$((attempt + 1))
    err="$(mktemp "${TMPDIR:-/tmp}/tap-registry-team.XXXXXX")"
    rc=0
    TAP_SCRIPTS_DIR="${_TAP_SCRIPT_DIR}" TAP_INDEX_HOME="$(tap_index_home)" \
      python3 -B - "$path" "$worktree" "$branch" "$lock_timeout" 2>"$err" <<'PY' || rc=$?
import datetime, fcntl, json, os, sys, tempfile, time
sys.path.insert(0, os.environ.get("TAP_SCRIPTS_DIR") or "")
from registry_v20 import validate_locked_registry_authority

path, worktree, branch, lock_timeout = sys.argv[1:5]
team_name = os.path.basename(worktree.rstrip("/")) if worktree else ""
d = os.path.dirname(path) or "."
lock_path = path + ".lock"
index_home = os.environ.get("TAP_INDEX_HOME")
with open(lock_path, "w") as lock:
    if lock_timeout:
        try:
            timeout = float(lock_timeout)
        except ValueError:
            timeout = 0
        if not 0 < timeout < float("inf"):
            print("invalid TAP_REGISTER_LOCK_TIMEOUT", file=sys.stderr)
            sys.exit(2)
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    print(f"registry lock busy >{timeout:g}s", file=sys.stderr)
                    sys.exit(75)
                time.sleep(0.01)
    else:
        fcntl.flock(lock, fcntl.LOCK_EX)
    # WAVE 6.12 / tap-yn2y: prove locked path is still authority before mutate.
    # allow_unenrolled_canonical: init/register bootstrap of team-registry.json
    # before global enroll — never the bus mirror under live.
    validate_locked_registry_authority(
        path, worktree, index_home=index_home, allow_unenrolled_canonical=True,
    )
    reg = {}
    if os.path.exists(path):
        try:
            with open(path) as fh:
                reg = json.load(fh)
        except Exception as exc:
            print(f"tap registry: registry '{path}' is invalid JSON; refusing to overwrite it ({exc})", file=sys.stderr)
            sys.exit(1)
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    if "team" not in reg:
        reg["team"] = {
            "branch_at_bootstrap": branch,
            "created_at": now,
            "name": team_name,
            "schema_version": "1",
            "worktree_root": worktree,
        }
    else:
        reg["team"].setdefault("name", team_name)
    seat_key = "seats" if isinstance(reg.get("seats"), dict) else "agents"
    if not isinstance(reg.get(seat_key), dict):
        reg[seat_key] = {}

    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tap.")
    with os.fdopen(fd, "w") as fh:
        json.dump(reg, fh, indent=2, sort_keys=True)
        fh.write("\n")
    os.replace(tmp, path)
PY
    if [ "$rc" = 0 ]; then
      rm -f "$err"
      return 0
    fi
    detail="$(cat "$err" 2>/dev/null || true)"
    rm -f "$err"
    if [ "$rc" = 17 ] && [ "$attempt" -lt 2 ]; then
      tap_rebind_acting_registry || break
      path="$TAP_REGISTRY"
      mkdir -p "$(dirname -- "$path")"
      continue
    fi
    break
  done
  case "$rc" in
    75) tap_fail 75 registry_lock_busy "tap register" "${detail:-registry lock busy}" ;;
    2)  tap_fail 2 error "set TAP_REGISTER_LOCK_TIMEOUT to a finite positive number" \
          "${detail:-invalid TAP_REGISTER_LOCK_TIMEOUT}" ;;
    17) tap_fail 1 flip_in_progress "tap register" \
          "${detail:-registry authority moved during flip — retry}" ;;
    4)  tap_fail 1 invalid_flip "tap doctor" \
          "${detail:-registry flip marker invalid — refusing membership mutation}" ;;
    *)  tap_fail 1 registry_invalid repair_registry "${detail:-registry team bootstrap failed}" ;;
  esac
}

tap_registry_event_append() {  # <actor> <action> <handle> <pane> [detail]
  # One writer (runtime/bun/src/events.ts): lock sidecar, bounded rewrite and
  # line format all live there. This adapter only names the log and the team.
  local actor="$1" action="$2" handle="$3" pane="${4:-}" detail="${5:-}" team
  team="$(tap_spool_team_name)"
  tap_bun_call registry-event "$action" events.ts append "$TAP_REGISTRY_EVENTS" "$actor" "$action" "$handle" "$pane" "$team" "$detail"
}

tap_registry_event_append_or_warn() {  # <actor> <action> <handle> <pane> [detail]
  local actor="$1" action="$2" handle="$3" pane="${4:-}" detail="${5:-}" verb="${TAP_VERB:-tap}"
  if ! tap_registry_event_append "$actor" "$action" "$handle" "$pane" "$detail" 2>/dev/null; then
    printf '%s: warning: registry event log append failed action=%s handle=%s\n' "$verb" "$action" "$handle" >&2
  fi
}

# --- machine-wide team index (U8) ---------------------------------------------
# ~/.tap/teams.json maps team name -> {root, enrolled_at}. It stores the repo ROOT
# (not a bus path — roots survive bus migration); the remote bus is derived from the
# root at resolve time (.tap/bus else legacy tmp/tap). Guarded by a .lock flock like
# the registry. Reads are read-only (a vanished root answers missing; no prune-on-
# read — PR #xxxx). Redirect the index home with TAP_INDEX_HOME so tests never
# touch the real ~/.tap.
#
# v0.20 (registry single-source, PR #xxx) — DORMANT until the one flip:
# `~/.tap/global-registry.json` with schema "0.20" IS the completion marker.
# Pre-flip: teams.json (read-only) + worktree-scan fallback stay live.
# Post-flip: resolve via stored registry_location; no prune-on-read (KTD-14);
# worktree-scan deleted. Helpers live in runtime/bun (Bun port, PR #xxxx).
tap_index_home() { printf '%s' "${TAP_INDEX_HOME:-$HOME/.tap}"; }
tap_index_file() { printf '%s/teams.json' "$(tap_index_home)"; }
tap_global_registry_file() { printf '%s/global-registry.json' "$(tap_index_home)"; }

# tap_authority_index_file — marker-selected machine index (WAVE 6 / 3681907109).
# live → global-registry.json; absent → teams.json; invalid → empty + exit 1
# (callers must fail closed — never enumerate retired teams.json under invalid).
# WAVE 6.5 / sol 111912Z: capture state rc SEPARATELY. case-on-$(cmd) treated
# ANY execution failure / unknown token as the absent branch (retired teams.json
# with rc=0). Accept ONLY exact absent|live|invalid; every other outcome → exit 1.
tap_authority_index_file() {
  local state rc=0
  tap_registry_v20_state_load 2>/dev/null || rc=$?
  state="$_TAP_V20_STATE_VAL"
  [ "$rc" -eq 0 ] || return 1
  case "$state" in
    live) printf '%s' "$(tap_global_registry_file)"; return 0 ;;
    invalid) return 1 ;;
    absent) printf '%s' "$(tap_index_file)"; return 0 ;;
    *) return 1 ;;
  esac
}

# --- flip-marker read memo (tap-v8o8) ----------------------------------------
# The marker read is the single hottest fork in the library: a plain `tap whoami`
# asked for it five times, each answer identical, each costing a ~25ms python
# interpreter start. The answer is a property of one file, so one process needs
# to read it once.
#
# PROCESS-LOCAL ON PURPOSE — never exported. tap.sh reaches every verb by
# `exec bash tap-<verb>.sh`, so an exported memo would outlive the process that
# proved it and let one command's read answer for a later command that ran after
# a migration. Crossing that boundary would trade a fork for a stale-authority
# bug, which is the wrong trade at any price. Per process, one fork.
#
# THE KEY IS EVERY INPUT THE READ HAS. Not "the inputs we thought of" — the
# enumeration below is the contract, and it is written out because five separate
# defects in this function were all the same defect: an input the classification
# depends on that the key did not hold. Each was found one at a time, each fix
# was aimed exactly at the one before it, and the next one was always adjacent.
# So: if you change what this read does, add the new input HERE, and add an arm
# to smoke/marker-memo-fail-closed.test.sh that reds without it.
#
#   physical cwd          both path inputs may be relative, and a relative path
#                         resolves against the cwd (arms 8, 9)
#   index home            the marker's directory: TAP_INDEX_HOME, or $HOME/.tap
#   marker bytes          the thing being classified (arms 1-5)
#   TAP_SCRIPTS_DIR       where the reader imports registry_v20 from (arm 7)
#   _TAP_SCRIPT_DIR       its fallback, same role
#   PATH                  which `python3` runs at all — a PATH change to an
#                         interpreter that cannot import made the classification
#                         fail while a cached `live` survived (arm 10). Keyed
#                         AND constrained: PATH only selects the interpreter
#                         because the call is `PATH=... command python3`, which
#                         eliminates the two overrides that change the answer
#                         without touching PATH (arm 12).
#
# ELIMINATED rather than keyed, in two families. Command resolution: a `hash -p`
# remap and a shell function named `python3` both change which executable runs
# without changing PATH, and neither belongs in a cache key — the invocation is
# constrained instead (arm 12). Interpreter environment: it runs under `-I`, so every
# `PYTHON*` environment variable and the user-site directory are ignored
# (`-I` implies `-E -P -s`). PYTHONHOME was the next one of these to turn up —
# point it at a missing directory and startup fails while a cached `live` is
# still served — and keying it would only have queued up PYTHONSTARTUP,
# sitecustomize, and whatever arrives next. An input the read cannot consume is
# bounded; an input the key merely tracks is a subscription (sol-pinnacle).
# Arm (11) reds if the isolation is removed. The cost is deliberate: a scripts
# dir that does not exist can no longer be rescued by an ambient PYTHONPATH, and
# this classifier fails closed instead, which is the polarity it should have.
#
# NOT keyed, and accepted as residuals rather than overlooked: the reader's own
# code and the interpreter behind an unchanged PATH string (registry_v20.py or
# the `python3` executable replaced in place, or a version shim swapped under a
# path that did not move, in a long-lived sourced shell — grok-pinnacle-inner),
# and the window between building the key and running the read (an A→B→A rewrite
# inside ~25ms). All need a rewrite production migrations do not perform, and
# pricing them in — hashing the reader, resolving the executable, holding a lock
# across the read — would cost the fork this memo exists to avoid.
#
# It is this broad because a narrower key was WRONG and the suite proved it. The first version keyed on the index
# home plus whether the marker file existed, on the theory that only two
# in-process writers could rewrite it in place. Two smokes red immediately:
# authority-context breaks the read by pointing TAP_SCRIPTS_DIR at an empty dir
# and requires a REFUSAL (the memo happily answered "live" without forking), and
# registry-acting-readers corrupts the marker in place inside one sourced shell
# and requires "invalid" (the file still existed, so an existence probe saw
# nothing change). A memo whose key omits an input answers questions it was
# never asked.
#
# So the key is: index home, the import path the reader would use, and the
# marker's CONTENTS. Reading the contents is free — `$(<file)` is a bash builtin
# read, not a fork — and it makes the cache exact rather than merely usually
# right: same three inputs, same answer, whoever wrote the file and from where.
# No invalidation hooks are needed at the writers, which is the point; a hook is
# a promise every future writer has to keep, and a content key is a fact.
#
# TWO RESIDUALS, examined and accepted (grok-pinnacle-inner, PR #xxx). The
# READER's code is not part of the key: a long-lived sourced shell (watch,
# goalie) that survives a TAP upgrade could hold an answer computed by the old
# registry_v20.py while the marker's bytes never changed. And building the key
# and running the read are two separate looks at the file, so an A→B→A rewrite
# inside that window could file B's answer under A's key. Both need a rewrite
# that production migrations do not perform, and a restart cures the first;
# pricing either one in (hashing the reader, holding a lock across the read)
# would cost more than the fork this memo saves.
_TAP_V20_STATE_KEY=""    # the inputs the cached answer belongs to
_TAP_V20_STATE_VAL=""    # absent|live|invalid ("" ⇒ nothing cached)

# tap_registry_v20_state_forget — drop the memo. Not needed for correctness (the
# key covers every input), kept for the caller that wants to force a re-read.
tap_registry_v20_state_forget() {
  _TAP_V20_STATE_KEY=""
  _TAP_V20_STATE_VAL=""
}

# tap_registry_v20_state_load — populate _TAP_V20_STATE_VAL in the CALLER's shell.
# Callers in the parent scope must prefer this over `$(tap_registry_v20_state)`:
# a command substitution caches inside a subshell that exits immediately, so the
# next read forks again. Same rc contract as tap_registry_v20_state: 0 with a
# value, or the python failure code with no value cached.
tap_registry_v20_state_load() {
  local home gpath key val bytes rc=0 unkeyable=0
  local TAP_SCRIPTS_DIR_KEY="${TAP_SCRIPTS_DIR:-}"
  local PATH_KEY="${PATH:-}"
  local cwd
  # A cwd that cannot be resolved physically is UNKEYABLE, never logical. The
  # obvious fallback — `|| cwd="$PWD"` — reinstates exactly the identity the
  # physical resolution exists to replace, and sol-pinnacle reproduced it on a
  # real macOS `getcwd` failure: deny traversal to a parent, and the logical name
  # still matches a key filed when the same name meant a different directory, so
  # the cached `live` is served again. A fallback to a known-unsafe identity is
  # worse than no fallback, because it looks like a safety net.
  #
  # Not a refusal, though: when the inputs are absolute — the ordinary case — the
  # marker read itself is unaffected by a broken cwd, so refusing would break
  # working setups to protect a key. Classify normally, and simply do not cache.
  cwd="$(pwd -P 2>/dev/null)" || { cwd=""; unkeyable=1; }
  home="$(tap_index_home)"
  gpath="$home/global-registry.json"
  # `read -d ''` is a builtin read — no fork — and it does two jobs at once: it
  # hands back the marker's bytes for the key, and its EXIT STATUS says whether a
  # NUL was found (success = a NUL delimiter was reached; failure = EOF first).
  #
  # The NUL probe is not decoration. `$(<file)` — the obvious way to read the
  # bytes — silently DROPS NUL bytes, so a valid marker and that same marker with
  # a NUL appended produce the IDENTICAL key. sol-pinnacle's probe walked it:
  # cache a live marker, append one NUL, and the memo returns the cached `live`
  # while a fresh read classifies `invalid` and the obligation refuses. That is a
  # fail-closed bypass at a trust boundary — the memo answering `live` for a
  # marker the classifier rejects — and it is a third staleness axis, not one of
  # the two accepted residuals below.
  #
  # A NUL-bearing marker is therefore never cached and never served from cache:
  # it forks every time and takes the classifier's word for it. Corrupt markers
  # are rare, and paying an interpreter start to stay fail-closed on one is the
  # trade this memo should make.
  # LENGTH-PREFIXED, not `|`-joined. A separator is only a separator if it cannot
  # occur inside a component, and `|` is legal in every path here: sol-pinnacle
  # built two different (index home, scripts dir) pairs that joined to the same
  # string, and the second — with a reader that could not import — was served the
  # first's cached `live`. Prefixing each component with its own length makes the
  # encoding injective for any bytes at all, which is a property rather than an
  # assumption about what paths people use.
  #
  # `bytes` is initialized before the read because the read can FAIL: a marker
  # that passes `-f` but cannot be opened (mode 000) leaves it unset, and under
  # `set -u` the expansion below would abort the whole command with an unbound
  # variable instead of letting the classifier return `invalid`. An unreadable
  # marker must refuse through the normal path, not take the process down.
  bytes=""
  # The cwd is a component because both inputs may be RELATIVE, and a relative
  # path is only an identity together with the directory it resolves from: one
  # shell that cached `live` in cwd A was served that answer in cwd B, where the
  # same strings named a different marker and a reader that could not import
  # (sol-pinnacle). Unconditionally, rather than only when an input looks
  # relative — a branch that decides when identity matters is a branch that can
  # be wrong, and an extra miss after an in-process `cd` costs a fork, while an
  # extra HIT costs a stale `live` at a fail-closed boundary.
  #
  # PHYSICAL, not `$PWD`. `$PWD` is the LOGICAL cwd, so a stable symlink name
  # retargeted from A to B leaves it byte-identical while the directory it names
  # is a different one — same relative inputs, different marker, reader that
  # cannot import, and the cached `live` was served again (sol-pinnacle's second
  # probe; `$PWD` was my fix for the first). `pwd -P` is a builtin, so resolving
  # it needs no external executable (it is a builtin in a command substitution,
  # so a shell subshell but no exec), and it is what the marker read follows.
  #
  # `present:`/`absent:` and the bytes are a trailing REMAINDER, deliberately not
  # length-prefixed. That is injective only while they stay LAST (grok's
  # precision): anything appended after them would need its own prefix, or the
  # encoding stops being one.
  if [ -f "$gpath" ]; then
    # `2>/dev/null` FIRST: bash applies redirections left to right, so a trailing
    # suppression is not yet in place when the input redirect itself fails, and a
    # mode-000 marker printed `Permission denied` to the caller's stderr.
    if IFS= read -r -d '' bytes 2>/dev/null < "$gpath"; then unkeyable=1; fi
    key="${#cwd}:$cwd${#home}:$home${#TAP_SCRIPTS_DIR_KEY}:$TAP_SCRIPTS_DIR_KEY${#_TAP_SCRIPT_DIR}:${_TAP_SCRIPT_DIR}${#PATH_KEY}:${PATH_KEY}present:$bytes"
  else
    key="${#cwd}:$cwd${#home}:$home${#TAP_SCRIPTS_DIR_KEY}:$TAP_SCRIPTS_DIR_KEY${#_TAP_SCRIPT_DIR}:${_TAP_SCRIPT_DIR}${#PATH_KEY}:${PATH_KEY}absent:"
  fi
  if [ "$unkeyable" = 1 ]; then
    tap_registry_v20_state_forget
  elif [ -n "$_TAP_V20_STATE_VAL" ] && [ "$_TAP_V20_STATE_KEY" = "$key" ]; then
    return 0
  fi
  # `PATH=... command python3`, and BOTH halves are load-bearing against a
  # DIFFERENT override — measured on this host, not assumed:
  #   `hash -p <other> python3`  defeats a bare call AND `command python3`;
  #                              only the PATH assignment clears it (bash drops
  #                              the hash entry when PATH is assigned).
  #   a shell function `python3`  defeats a bare call and the PATH assignment
  #                              (functions precede PATH lookup entirely);
  #                              only `command` steps past it.
  # Neither changes PATH, so neither moves the key — which is what makes them
  # the same class as PYTHONHOME rather than something to key (sol-pinnacle).
  # Keying `PATH` is only sufficient once the invocation is CONSTRAINED to a
  # PATH lookup, and that is what this form does. Arm (12) reds without it.
  val="$(TAP_INDEX_HOME="$home" PATH="$PATH_KEY" command python3 -I -B -c \
    'import os, sys; sys.path.insert(0, os.environ.get("TAP_SCRIPTS_DIR") or "'"${_TAP_SCRIPT_DIR}"'"); from registry_v20 import flip_marker_state; print(flip_marker_state(os.environ.get("TAP_INDEX_HOME")))')" || rc=$?
  if [ "$rc" -ne 0 ]; then
    tap_registry_v20_state_forget
    return "$rc"
  fi
  if [ "$unkeyable" = 1 ]; then
    # Classified, but never filed: the key cannot represent this input — either
    # the marker holds bytes a key cannot carry, or the cwd half of the identity
    # could not be resolved. Both take the same door on purpose; a second
    # mechanism for the second cause is how the two drift apart.
    _TAP_V20_STATE_VAL="$val"
    _TAP_V20_STATE_KEY=""
    return 0
  fi
  _TAP_V20_STATE_VAL="$val"
  _TAP_V20_STATE_KEY="$key"
  return 0
}

# tap_registry_v20_state — prints absent|live|invalid (never empty).
# absent  = no marker (pre-flip; legacy routing allowed)
# live    = schema 0.20
# invalid = marker present but unreadable/wrong schema — FAIL CLOSED (never legacy)
tap_registry_v20_state() {
  local rc=0
  tap_registry_v20_state_load || rc=$?
  [ "$rc" -eq 0 ] || return "$rc"
  printf '%s\n' "$_TAP_V20_STATE_VAL"
}

# tap_registry_v20_live — soft boolean: 0 only when state=live.
# invalid/unreadable both yield false (command-substitution discards the python
# rc). That is FAIL-OPEN for ACTS obligations — use tap_v20_obligation_live
# (or TAP_AUTH_V20_BOUND after tap_authority_context) at those sites (tap-zex3).
# Soft callers: discovery / waiters that treat "not live" as a non-fatal branch.
tap_registry_v20_live() {
  # Load form, not $(...): this is the most-called reader in the library, and a
  # subshell would strand the memo it just paid for (tap-v8o8). Fail-open
  # polarity is unchanged — an unreadable marker leaves the value empty, which
  # is not "live".
  tap_registry_v20_state_load || return 1
  [ "$_TAP_V20_STATE_VAL" = "live" ]
}

# tap_v20_obligation_live — ACTS polarity for "if live then run a v0.20 obligation".
#   live    → return 0 (run the obligation)
#   absent  → return 1 (skip; the ONLY legacy door)
#   invalid / unreadable / unknown → tap_fail (never skip the obligation by
#     mistaking a broken marker read for pre-flip absence). Same refuse polarity
#     as tap_authority_context; keeps sites that have not yet sampled authority
#     from re-deriving liveness via the soft boolean (tap-zex3).
tap_v20_obligation_live() {
  local state rc=0
  tap_registry_v20_state_load 2>/dev/null || rc=$?
  state="$_TAP_V20_STATE_VAL"
  if [ "$rc" -ne 0 ] || [ -z "$state" ]; then
    tap_fail 1 marker_unreadable "tap doctor" \
      "could not read registry flip marker; refusing rather than skipping a v0.20 obligation"
  fi
  case "$state" in
    live) return 0 ;;
    absent) return 1 ;;
    invalid)
      tap_fail 1 invalid_flip "tap doctor" \
        "registry flip marker is present but invalid; refusing rather than skipping a v0.20 obligation"
      ;;
    *)
      tap_fail 1 marker_unreadable "tap doctor" \
        "registry flip marker state '$state' is not absent|live|invalid; refusing"
      ;;
  esac
}

# tap_bus_home_for_registry <registry_path>
# Bus home that owns reset.fence.json / payloads — NEVER dirname(registry) alone.
# Canonical post-flip: <root>/.tap/team-registry.json → <root>/.tap/bus
# Legacy / pre-flip:   <root>/.tap/bus/registry.json → <root>/.tap/bus
tap_bus_home_for_registry() {
  local reg="${1:-}" parent base
  [ -n "$reg" ] || return 1
  parent="$(dirname "$reg")"
  base="$(basename "$reg")"
  case "$base" in
    team-registry.json) printf '%s/bus' "$parent" ;;
    registry.json)      printf '%s' "$parent" ;;
    *)
      case "$parent" in
        */bus)  printf '%s' "$parent" ;;
        */.tap) printf '%s/bus' "$parent" ;;
        *)      return 1 ;;
      esac
      ;;
  esac
}

# tap_worktree_team_root <team> <sender-root>
# Set the pre-flip worktree-scan diagnostics (Bun slice, result-pairs carrier):
#   TAP_WT_STATE   found|ambiguous|missing|error
#   TAP_WT_ROOT    the unique worktree path (found only)
#   TAP_WT_DETAIL  ambiguous: matching paths ", "-joined · missing: sibling
#                  basenames or "<none>" · error: the git failure reason
# ERROR is its own state, never a silent miss (u1 round-1, r4045876930): an
# unusable git spawn or a truncated listing must not hide a sibling behind
# missing. Always returns 0. Pre-flip delivery fallback only — CONTRACT deletes
# worktree-scan once global-registry.json flip is live; callers must stay on
# the absent arm (never invoke from the live arm).
tap_worktree_team_root() {
  TAP_WT_STATE="missing"; TAP_WT_ROOT=""; TAP_WT_DETAIL=""
  [ -n "${1:-}" ] && [ -n "${2:-}" ] || return 0
  local _iw_result
  _iw_result="$(mktemp "${TMPDIR:-/tmp}/tap-wt-root.XXXXXX")" || {
    TAP_WT_STATE="error"; TAP_WT_DETAIL="mktemp failed"; return 0
  }
  if ! tap_bun_call team-selection "$1" team-selection.ts worktree-root --result "$_iw_result" -- "$1" "$2"; then
    rm -f "${_iw_result:?}"
    TAP_WT_STATE="error"; TAP_WT_DETAIL="worktree scan unavailable (bun slice failed)"
    return 0
  fi
  tap_bun_read_pairs "$_iw_result" "worktree scan ($1)"
  tap_bun_require_pairs "worktree scan ($1)" _IW_STATE _IW_ROOT _IW_DETAIL
  TAP_WT_STATE="$_IW_STATE"; TAP_WT_ROOT="$_IW_ROOT"; TAP_WT_DETAIL="$_IW_DETAIL"
  return 0
}

# tap_authority_context [<team>]
# ONE immutable post-flip authority sample for ACTS commands (sol/opus 2026-07-29).
# Sets globals (do not re-sample mid-command into a contradictory placement mode):
#   TAP_AUTH_MARKER     absent|live|invalid (empty ⇒ marker_unreadable)
#   TAP_AUTH_REGISTRY   usable registry path, or empty
#   TAP_AUTH_BUS        bus home for fence/payloads (never interchangeable with registry)
#   TAP_AUTH_V20_BOUND  1 iff live + registry resolved → recipient lock/stamp required
#   TAP_AUTH_STATUS     ok|invalid_flip|unreachable|unresolved|marker_unreadable
# Rules: ONLY the word `absent` may select legacy; invalid / unreadable REFUSE.
# A failed marker read (python missing, import fail) must NOT fall through to legacy —
# command-substitution exit status is discarded, so the case enumeration is exhaustive.
# Pre-flip foreign teams: teams.json root, then worktree-scan basename fallback
# (same capability as tap_resolve_team_target — e929a79f closed the hole that
# left cancel/send refusing deliverable siblings not yet in teams.json).
tap_authority_context() {
  local team="${1:-}" root sender_root
  # Load form (tap-v8o8): this is the FIRST marker read of most commands, so
  # paying for it in the parent shell is what lets every later reader — including
  # ones inside command substitutions — answer from the memo.
  if tap_registry_v20_state_load; then
    TAP_AUTH_MARKER="$_TAP_V20_STATE_VAL"
  else
    TAP_AUTH_MARKER=""
  fi
  TAP_AUTH_REGISTRY=""
  TAP_AUTH_BUS=""
  TAP_AUTH_V20_BOUND=0
  TAP_AUTH_STATUS=""
  case "$TAP_AUTH_MARKER" in
    live)
      [ -n "$team" ] || team="$(tap_spool_team_name 2>/dev/null || true)"
      if [ -z "$team" ]; then
        TAP_AUTH_STATUS="unresolved"
        return 1
      fi
      tap_index_resolve_team "$team"
      if [ "$TAP_IDX_STATUS" != "ok" ] || [ -z "${TAP_IDX_REGISTRY_LOCATION:-}" ]; then
        TAP_AUTH_STATUS="unreachable"
        return 1
      fi
      TAP_AUTH_REGISTRY="$TAP_IDX_REGISTRY_LOCATION"
      if [ ! -f "$TAP_AUTH_REGISTRY" ]; then
        TAP_AUTH_STATUS="unreachable"
        return 1
      fi
      # Canonical sibling layout → bus beside the file. Relocated acting stores
      # live outside <root>/.tap/; bus stays under the enrolled root (WAVE 6.9
      # cwd-relocated / sol): never fail closed solely because basename(reg) is
      # not team-registry.json.
      if ! TAP_AUTH_BUS="$(tap_bus_home_for_registry "$TAP_AUTH_REGISTRY" 2>/dev/null)"; then
        if [ -n "${TAP_IDX_ROOT:-}" ] && [ -d "${TAP_IDX_ROOT}/.tap/bus" ]; then
          TAP_AUTH_BUS="${TAP_IDX_ROOT}/.tap/bus"
        elif [ -n "${TAP_IDX_ROOT:-}" ] && [ -d "${TAP_IDX_ROOT}/tmp/tap" ]; then
          TAP_AUTH_BUS="${TAP_IDX_ROOT}/tmp/tap"
        else
          TAP_AUTH_STATUS="unreachable"
          return 1
        fi
      fi
      TAP_AUTH_V20_BOUND=1
      TAP_AUTH_STATUS="ok"
      return 0
      ;;
    invalid)
      TAP_AUTH_STATUS="invalid_flip"
      return 1
      ;;
    absent)
      # The ONLY legacy door — explicit pre-flip absence, never empty/unknown.
      ;;
    *)
      TAP_AUTH_STATUS="marker_unreadable"
      return 1
      ;;
  esac
  # Pre-flip / explicit absent — legacy paths only.
  if [ -z "$team" ] || [ "$team" = "$(tap_spool_team_name 2>/dev/null || true)" ]; then
    if [ -n "${TAP_REGISTRY:-}" ]; then
      TAP_AUTH_REGISTRY="$TAP_REGISTRY"
      if [ -n "${TAP_HOME:-}" ]; then
        TAP_AUTH_BUS="$TAP_HOME"
      else
        TAP_AUTH_BUS="$(tap_bus_home_for_registry "$TAP_AUTH_REGISTRY" 2>/dev/null || dirname "$TAP_AUTH_REGISTRY")"
      fi
      TAP_AUTH_STATUS="ok"
      return 0
    fi
    TAP_AUTH_STATUS="unresolved"
    return 1
  fi
  root="$(tap_index_resolve_root "$team" 2>/dev/null || true)"
  if [ -z "$root" ]; then
    # Absent-arm only: worktree-scan basename fallback (CONTRACT dormancy).
    # Live arm returns above and must never reach this.
    sender_root=""
    if [ -n "${TAP_HOME:-}" ]; then
      sender_root="$(tap_team_dir_from_bus 2>/dev/null || true)"
    fi
    if [ -z "$sender_root" ]; then
      sender_root="$(_tap_repo_root 2>/dev/null || true)"
    fi
    if [ -n "$sender_root" ]; then
      tap_worktree_team_root "$team" "$sender_root" || true
      # Only a FOUND scan yields a root; error/ambiguous/missing all answer
      # empty here, exactly as the old silent-on-failure scan did.
      [ "$TAP_WT_STATE" = "found" ] && root="$TAP_WT_ROOT"
    fi
  fi
  if [ -z "$root" ]; then
    TAP_AUTH_STATUS="unreachable"
    return 1
  fi
  if [ -f "$root/.tap/bus/registry.json" ]; then
    TAP_AUTH_REGISTRY="$root/.tap/bus/registry.json"
    TAP_AUTH_BUS="$root/.tap/bus"
  elif [ -f "$root/tmp/tap/registry.json" ]; then
    TAP_AUTH_REGISTRY="$root/tmp/tap/registry.json"
    TAP_AUTH_BUS="$root/tmp/tap"
  else
    TAP_AUTH_STATUS="unreachable"
    return 1
  fi
  TAP_AUTH_STATUS="ok"
  return 0
}

# tap_acting_registry [<team>]
# Registry path ACTS readers must use. Thin wrapper over tap_authority_context
# (resolve axis). Map axis remains _seat_map / tap_registry_current_instance.
# invalid / unreachable → empty + exit 1 (callers MUST fail closed — never
# substitute ambient $TAP_REGISTRY after a failed sample).
tap_acting_registry() {
  tap_authority_context "${1:-}" || return 1
  printf '%s' "$TAP_AUTH_REGISTRY"
  return 0
}

# tap_rebind_acting_registry [<team>]
# Lifecycle verbs (`tap in` / `tap out`) set ambient TAP_REGISTRY from the bus
# home first, then MUST rebind through the acting-registry choke point so a
# post-flip stored team-registry.json is the file they read and write. Pre-flip
# (marker absent) returns the ambient bus path — a no-op rebind. Fail closed on
# invalid / unreachable (never keep the bus decoy after a failed sample).
tap_rebind_acting_registry() {
  local _ar
  _ar="$(tap_acting_registry "${1:-}")" || return 1
  [ -n "$_ar" ] || return 1
  TAP_REGISTRY="$_ar"
  [ "${TAP_VERBOSE:-}" != 1 ] || python3 -B "$_TAP_SCRIPT_DIR/verbose.py" state "$TAP_REGISTRY"
  return 0
}

# tap_require_acting_registry [<team>]
# Identity / registry readers that used to early-return on
# `[ -f "$TAP_REGISTRY" ]` MUST go through this (or an explicit rebind + check).
# Post-flip the ambient bus path is retired; without rebind the early return
# fires before seats-first parsing and a live seat looks unregistered.
# Exit: 0 file present after rebind | 1 rebind failed or file absent.
tap_require_acting_registry() {
  tap_rebind_acting_registry "${1:-}" || return 1
  [ -f "$TAP_REGISTRY" ] || return 1
  return 0
}

# Post-flip team registry path for a worktree root (sibling of bus/, not inside it).
tap_team_registry_file() { # <team-dir>
  printf '%s/.tap/team-registry.json' "$1"
}

# tap_fold_bus_registry_into_acting <acting-path> <bus-registry-path>
# WAVE 6.11 / 3682836481: merge seats/agents from a migrated bus (or legacy)
# registry into the acting team-registry before enroll. Preserves instance ids
# and row fields; acting seats win on key conflict. No-op if source missing.
# Writes seats-axis on the acting doc (schema 0.20).
tap_fold_bus_registry_into_acting() {
  local acting="${1:-}" source="${2:-}"
  [ -n "$acting" ] || return 1
  [ -f "$source" ] || return 0
  python3 -B - "$acting" "$source" "${_TAP_SCRIPT_DIR}" <<'PY'
import fcntl, os, sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import _seat_map, load_state_doc, save_state_doc, SCHEMA

acting_path, source_path = sys.argv[1:3]
# Source may be read outside the acting lock (sol: source before lock OK).
try:
    src = load_state_doc(source_path)
except Exception as exc:
    print(f"tap enroll: cannot read bus/legacy registry '{source_path}': {exc}", file=sys.stderr)
    raise SystemExit(1)
src_seats = _seat_map(src)
if not src_seats:
    raise SystemExit(0)
# WAVE 6.11 follow-on: hold acting sidecar across load → merge → save so a
# concurrent seat writer cannot be lost to unlocked save_state_doc replace.
os.makedirs(os.path.dirname(acting_path) or ".", exist_ok=True)
lock_path = acting_path + ".lock"
with open(lock_path, "a+") as lf:
    fcntl.flock(lf, fcntl.LOCK_EX)
    try:
        acting = load_state_doc(acting_path) if os.path.isfile(acting_path) else {}
    except Exception as exc:
        print(f"tap enroll: cannot read acting registry '{acting_path}': {exc}", file=sys.stderr)
        raise SystemExit(1)
    # Test-only: prove the acting lock is held across the critical section.
    # Hook runs after acting read, still under flock — must not take the lock.
    _hook = os.environ.get("TAP_FOLD_AFTER_ACTING_READ_HOOK")
    if _hook:
        import subprocess
        subprocess.run(["bash", "-c", _hook], check=False)
    if not isinstance(acting, dict):
        acting = {}
    acting.setdefault("schema", SCHEMA)
    team = acting.get("team") if isinstance(acting.get("team"), dict) else {}
    src_team = src.get("team") if isinstance(src.get("team"), dict) else {}
    if not team.get("name") and src_team.get("name"):
        team = dict(team)
        team["name"] = src_team["name"]
    if not team.get("worktree_root") and src_team.get("worktree_root"):
        team = dict(team)
        team["worktree_root"] = src_team["worktree_root"]
    acting["team"] = team
    # seats-first via _seat_map — never raw acting["agents"] (shell-seats-axis-enum).
    seats = dict(_seat_map(acting))
    for handle, row in src_seats.items():
        if not isinstance(row, dict):
            continue
        if handle in seats and isinstance(seats[handle], dict):
            merged = dict(row)
            merged.update(seats[handle])  # acting wins
            if not merged.get("instance") and row.get("instance"):
                merged["instance"] = row["instance"]
            seats[handle] = merged
        else:
            seats[handle] = dict(row)
    acting["seats"] = seats
    acting.pop("agents", None)
    save_state_doc(acting_path, acting)
PY
}

# tap_instance_clearing_remedy <handle> <pinst> — the actor-side clearing door
# for mail bound to a predecessor instance, split by what is actually possible.
# LIFTED VERBATIM from tap-cancel.sh (was verb-local `_cancel_instance_remedy`)
# so `tap read`'s forced-ask tail and `tap reply`'s instance refusal print the
# SAME computed doors the cancel paths print — one helper, one string, no drift
# (the parity reasoning is the architect ruling's own). The caller contract is
# unchanged: on return 0, _REMEDY_NEXT holds a NON-DESTRUCTIVE next action
# (restore only where no current seat exists; the LOOK where one does; the
# door's destructive half — `tap out` — rides DETAIL prose only), and
# _REMEDY_DETAIL holds cancel-caller prose; read/reply print NEXT plus their
# own one-line detail and must not print _REMEDY_DETAIL.
#
# _REMEDY_KIND says WHICH of those two things _REMEDY_NEXT is, because two of
# the computed cases put PROSE there — "no remaining clearing path (…)" — and a
# caller that prints NEXT alone renders that prose as if it were a command. The
# return code cannot carry this: it means "could not compute" (the caller has no
# door to describe), and a computed no-door case is a real answer, so it returns
# 0. `command` = _REMEDY_NEXT is runnable; `none` = it is prose naming the
# absence of a door. On return 1, _REMEDY_KIND is `unknown`. Branch on the KIND,
# never on the shape of the string.
#
# <handle> is the ACTOR's
# own handle, never the payload's `to` — for locally adopted mail `to` is the
# successor while the binding is the fork's, so keying on `to` would consult the
# wrong history and could offer a restore that cannot run.
# The one no-door sentence, named once. It is rendered in the `next:` action slot
# by callers that have no better answer, and `tap-cancel.sh` also needs it on a
# path where the helper did not run — two copies of a string that must agree is
# a drift seam, so there is one (opus-door, #xxx whole-diff).
TAP_NO_CLEARING_PATH="no remaining clearing path (CONTRACT.md Cancellation)"

_REMEDY_NEXT=""
_REMEDY_DETAIL=""
_REMEDY_KIND=""

tap_team_history_dir() { # <team-dir>
  printf '%s/.tap/team-history' "$1"
}

# Derive the team worktree dir that owns $TAP_HOME (bus parent, or .tap parent).
tap_team_dir_from_bus() {
  local bus_parent
  bus_parent="$(cd "$(dirname "$TAP_HOME")" 2>/dev/null && pwd -P || true)"
  case "$bus_parent" in
    # <root>/.tap/bus → <root>
    */.tap) printf '%s' "$(dirname "$bus_parent")" ;;
    # <root>/tmp/tap → <root> (accepted legacy layout; sol #xxx P2 — must not
    # report <root>/tmp as the worktree or post-flip enroll lookup misses).
    */tmp) printf '%s' "$(dirname "$bus_parent")" ;;
    *)      printf '%s' "$bus_parent" ;;
  esac
}

# Echo current instance id for <handle> on <registry> (empty if unbound/absent).
tap_registry_current_instance() { # <registry> <handle>
  python3 -B - "$1" "$2" "${_TAP_SCRIPT_DIR}" <<'PY'
import os, sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import current_instance
sys.stdout.write(current_instance(sys.argv[1], sys.argv[2]))
PY
}

# tap_ensure_empty_team_registry <path> <name> <worktree_root>
# Write empty_team_registry(name, worktree_root) through save_state_doc under
# <path>.lock with an in-lock isfile recheck (WAVE 6.6 / 3682338118). seats is
# PRESENT-as-{} (seat_axis tri-state); no doc-level epoch/boot. Shared by
# tap_bootstrap_postflip_enroll and post-reset reboot (tap-w3op) so reset never
# invents a parallel writer. No-op when the file already exists AND parses as
# the schema-0.20 team shape; an existing file that does not parse (unreadable
# bytes, wrong schema, non-map team, missing/non-map seats) refuses under the
# same lock (#xxxx review, PRRT_kwDOTMYQYs6jnSWc) — the former unconditional
# no-op let a malformed store at the acting path sail through first-entry
# fold/enrollment and become authority.
tap_ensure_empty_team_registry() {
  local path="$1" name="$2" root="$3" branch=""
  [ -n "$path" ] && [ -n "$name" ] && [ -n "$root" ] || return 1
  # tap-14zzv: this is the CREATION site for the canonical store, and on the
  # born-live register door it is the only writer the team block ever sees —
  # tap_registry_ensure_team, which composes the full block for `tap init`, is
  # never reached on that path. empty_team_registry() carries the pure team
  # fields; this repository-owning layer adds branch_at_bootstrap.
  # The branch is resolved HERE because this is the layer that still has the
  # repository; registry_v20 is a pure document module with no git access.
  #
  # This is the INCUMBENT derivation verbatim (init-storage.sh:12,
  # tap-register.sh:443), and it has to be: a convergence fix that derives the
  # value its own way converges the field's PRESENCE while diverging its VALUE in
  # exactly the corners nobody fixtures. `rev-parse --abbrev-ref HEAD` — my first
  # cut — prints "HEAD" and exits 128 on an unborn repo where symbolic-ref prints
  # the branch, and yields "" where the incumbents record "unknown" on a detached
  # HEAD or a non-git root (glm53-examiner, CodeRabbit P2 on #xxxx). Every failure
  # corner disagreed, which is the defect this function exists to prevent, one
  # round later.
  branch="$(git -C "$root" symbolic-ref --quiet --short HEAD 2>/dev/null || echo "unknown")"
  python3 -B - "$path" "$name" "$root" "${_TAP_SCRIPT_DIR}" "$branch" <<'PY'
import fcntl, json, os, sys
sys.path.insert(0, sys.argv[4])
from registry_v20 import SCHEMA, empty_team_registry, save_state_doc
path, name, root = sys.argv[1:4]
branch = sys.argv[5] if len(sys.argv) > 5 else ""
os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
lock_path = path + ".lock"
with open(lock_path, "a+") as lf:
    fcntl.flock(lf, fcntl.LOCK_EX)
    if os.path.isfile(path):
        # #xxxx review (PRRT_kwDOTMYQYs6jnSWc): the smallest shared validation,
        # under the same sidecar lock the creation write holds. An existing file
        # is accepted only when it parses as the schema-0.20 team shape —
        # dict, right schema, a map team, and a map seats axis. Valid stores
        # keep the exact prior no-op (reset/reboot unchanged).
        try:
            with open(path) as fh:
                doc = json.load(fh)
        except Exception:
            doc = None
        if not (isinstance(doc, dict)
                and str(doc.get("schema") or "") == SCHEMA
                and isinstance(doc.get("team"), dict)
                and isinstance(doc.get("seats"), dict)):
            print(
                f"tap enroll: acting registry '{path}' exists but is not a valid "
                f"schema-{SCHEMA} team registry; refusing to fold or enroll over it",
                file=sys.stderr,
            )
            sys.exit(2)
    else:
        doc = empty_team_registry(name=name, worktree_root=root)
        # Same field set and same values tap_registry_ensure_team writes for the
        # init door, so the two first-entry doors bootstrap one document shape.
        # empty_team_registry minted created_at when this absent-file arm called
        # it; reset therefore records the reboot creation time, not team age.
        doc["team"]["branch_at_bootstrap"] = branch
        save_state_doc(path, doc)
PY
}

# tap_bootstrap_postflip_enroll <repo-root>
# tap-nvtx: first post-flip seat in a worktree missing from global-registry.
# Owns the complete first-entry sequence: eligibility gate, canonical bus
# directories, tap_ensure_empty_team_registry, the bus-to-acting fold, TAP_HOME
# normalisation, then enrollment. Call BEFORE acting-registry rebind when flip
# is live and resolve is missing/unreachable.
tap_bootstrap_postflip_enroll() {
  local root="$1" canon_root loc name
  [ -n "$root" ] || return 1
  tap_registry_v20_live || return 1
  # SELF-GATED, because gating the CALL SITES is not the same thing. This helper
  # is what actually writes: it mkdir's <root>/.tap/bus and creates
  # <root>/.tap/team-registry.json. Register's tap-nvtx door is gated, but
  # `tap init` on an ALREADY-LIVE machine reaches here through
  # init_apply_postflip_authority -> live_unenrolled without passing that door,
  # so a non-git root or custom home still got the cross-boundary write the
  # shared predicate exists to prevent (sol-pinnacle-3, P1 on #xxxx). Enrollment
  # refusing afterwards is too late -- the directories are already on disk.
  # The check is BEFORE the first mkdir for that reason.
  #
  # It judges the home this helper will USE, not the caller ambient one. The
  # helper normalises TAP_HOME to the canonical bus for this root a few lines
  # below, so gating on the caller value asked the wrong question and declined a
  # shape the incumbent supported: the Python launcher bootstraps a primary
  # repository with TAP_HOME UNSET (session/tests/test_launch_worktree_team.py
  # deletes it), and an unset TAP_HOME means "derive it" -- for a git top-level
  # the derivation IS the canonical bus. Found by opus-6 while stacking 4a, with
  # the helper called exactly as the deleted Python body called it.
  #
  # An explicitly NON-canonical TAP_HOME is a different fact and still refuses:
  # the caller named a DIFFERENT bus, so bootstrapping this root store is not
  # what was asked, and that mismatch -- home pointing one place while the write
  # lands in the checkout -- is the escape this gate exists to stop.
  canon_root="$(cd "$root" 2>/dev/null && pwd -P || printf '%s' "$root")"
  # WHICH RULE CHOSE TAP_HOME is the question, not what it currently holds.
  # TAP_HOME is never actually unset here: sourcing lib.sh DERIVES it from cwd
  # (R19 chain, TAP_BUS_RULE). So a caller that deleted TAP_HOME still arrives
  # with one, pointing at whatever repo the process happened to stand in, and
  # gating on that value refused a legitimate bootstrap of a DIFFERENT root --
  # the Python launcher bootstrapping a primary repository from another cwd
  # (session/tests/test_launch_worktree_team.py, found by opus-6 stacking 4a).
  #
  # lib.sh:261 already draws the line this gate needs: "rule=env; custom homes
  # are unindexable in the machine index — U8". An ENV home is an explicit
  # instruction to use a different bus, and bootstrapping this root store is then
  # not what was asked -- that mismatch, home naming one place while the write
  # lands in another, is the checkout escape. A DERIVED home (dotdir/legacy/
  # default) is incidental to cwd and says nothing about whether <root> may be
  # indexed; the helper normalises TAP_HOME to this root canonical bus below
  # regardless.
  case "${TAP_BUS_RULE:-}" in
    env) tap_index_root_indexable "$root" || return 1 ;;
    *)   ( TAP_HOME="$canon_root/.tap/bus"; tap_index_root_indexable "$root" ) || return 1 ;;
  esac
  name="$(basename "$canon_root")"
  tap_valid_token "$name" || return 1
  mkdir -p "$canon_root/.tap/bus/payloads" "$canon_root/.tap/bus/receipts"
  loc="$(tap_team_registry_file "$canon_root")"
  tap_ensure_empty_team_registry "$loc" "$name" "$canon_root" || return 1
  # The fold sits immediately after the empty-store ensure and BEFORE
  # enrollment (tap-q4fw5/tap-moa6x): register-first must pick up pre-existing
  # bus rows instead of stranding them on the retired store, and an unreadable
  # target bus registry must refuse before enrollment rather than enroll a
  # store that dropped them. The source is the TARGET root's canonical bus --
  # never ambient TAP_HOME, which on the Python launcher's explicit-root call
  # may belong to the caller's cwd. An absent bus registry is a no-op (the fold
  # helper's own contract). This helper is reached only for a team the index
  # does not know -- register refuses known/unreachable teams first, init
  # reaches it only through live_unenrolled, and reset calls
  # tap_ensure_empty_team_registry directly -- so the fold cannot resurrect
  # rows into an established acting store.
  tap_fold_bus_registry_into_acting "$loc" "$canon_root/.tap/bus/registry.json" || return 1
  # Point TAP_HOME at the canonical bus so enroll's shape check passes.
  local _saved_home="${TAP_HOME:-}"
  TAP_HOME="$canon_root/.tap/bus"
  tap_index_enroll_team "$canon_root" || {
    [ -n "$_saved_home" ] && TAP_HOME="$_saved_home"
    return 1
  }
  [ -n "$_saved_home" ] && TAP_HOME="$_saved_home"
  return 0
}

# tap_index_root_indexable <repo-root>
# The single answer to "can this root hold machine-index state at all?"
#
# `tap_index_enroll_team` has always skipped a non-canonical TAP_HOME as
# unindexable by design, so a team on a custom bus has NO post-flip existence:
# tap_authority_context on `live` resolves only through the index. Every door
# that creates or flips index state therefore owes the SAME predicate, or it
# manufactures a state the enroller refuses to record -- which is what flipped
# 53 custom-TAP_HOME fixtures on #xxxx, and what wrote
# <checkout>/.tap/team-registry.json out of a mktemp-d session (the tap-nvtx
# door, main-side: on an operator shell that enrolls into the PRODUCTION
# ~/.tap/global-registry.json).
#
# RULE 19: a root that cannot be RESOLVED is not-indexable, never indexable.
# The old inline form fell back to the unresolved string and compared that, so a
# vanished root whose TAP_HOME still matched textually read as canonical and
# proceeded to enroll a root that was not there.
tap_index_root_indexable() {
  local root="$1" canon_root top canon_top
  [ -n "$root" ] || return 1
  canon_root="$(cd "$root" 2>/dev/null && pwd -P)" || return 1
  [ -n "$canon_root" ] || return 1
  # THE GIT HALF, and why it is not optional: CONTRACT:565 "Only git worktrees
  # enroll in the machine-wide team index", :454 "non-git folders are not
  # enrolled". A non-git directory still gets a canonical default bus
  # ($ROOT/.tap/bus -- init-storage.sh sets exactly that with IN_GIT=0), so a
  # TAP_HOME-only predicate admits any ordinary folder and would make
  # machine-index authority depend on a folder basename (sol-pinnacle-3, P1 on
  # the #xxxx new head). Prove the worktree POSITIVELY and prove it is the
  # TOP-LEVEL: a nested path inside a worktree is not the team root either.
  # RULE 19: no git observation is not-indexable, never indexable -- the failure
  # to observe must not license a machine-index write.
  top="$(git -C "$canon_root" rev-parse --show-toplevel 2>/dev/null)" || return 1
  [ -n "$top" ] || return 1
  canon_top="$(cd "$top" 2>/dev/null && pwd -P)" || return 1
  [ "$canon_top" = "$canon_root" ] || return 1
  # COMPARE RESOLVED ROOTS, NOT SPELLINGS. Comparing a physically resolved
  # canon_root against TAP_HOME as the caller spelled it made a repo reached
  # through a symlink -- a symlinked home, a symlinked mount, macOS's own
  # /tmp -> /private/tmp -- read NOT indexable: born-live silently did not fire
  # and enrollment silently skipped, for a machine entitled to both. A silent
  # false negative in this PR's single authority for every enroll and bootstrap
  # door is the very class this change exists to close.
  #
  # Accepting the raw spelling as well would fix it and would also let an
  # unresolved path license a checkout write, which is what the resolved
  # comparison prevents. So strip the KNOWN bus suffix and resolve what remains:
  # TAP_HOME has only two indexable shapes, and the home root exists even when
  # .tap/bus does not, so no partial path is ever resolved (sol-pinnacle-3's
  # ruling). An unknown suffix, a failed resolve, or a mismatch is
  # not-indexable -- a foreign root that merely ENDS in the right characters is
  # still a different root and still refused.
  local home_root canon_home
  case "${TAP_HOME:-}" in
    */.tap/bus) home_root="${TAP_HOME%/.tap/bus}" ;;
    */tmp/tap)  home_root="${TAP_HOME%/tmp/tap}" ;;
    *) return 1 ;;
  esac
  [ -n "$home_root" ] || return 1
  canon_home="$(cd "$home_root" 2>/dev/null && pwd -P)" || return 1
  [ "$canon_home" = "$canon_root" ]
}

# tap_index_enroll_preflight <repo-root>
# Refuse an unpinned system-temporary team before a caller can write membership.
# Keep this separate from the index writer because register writes the acting
# seat first and enrolls afterward on an existing team; a writer-only guard can
# therefore report failure after the registration already happened.
tap_index_enroll_preflight() {
  local root="$1" canon_root
  tap_index_root_indexable "$root" || return 0
  canon_root="$(cd "$root" 2>/dev/null && pwd -P || printf '%s' "$root")"
  [ -z "${TAP_INDEX_HOME:-}" ] || return 0
  if python3 -B - "$canon_root" <<'PY'
import os, sys, tempfile

root = os.path.realpath(sys.argv[1])
candidates = {tempfile.gettempdir(), "/tmp"}
candidates.update(os.environ.get(key, "") for key in ("TMPDIR", "TMP", "TEMP"))
for candidate in candidates:
    if not candidate:
        continue
    base = os.path.realpath(candidate)
    try:
        inside = os.path.commonpath([root, base]) == base
    except ValueError:
        inside = False
    if inside:
        sys.exit(0)
sys.exit(1)
PY
  then
    printf 'tap enroll: refusing system temporary root '\''%s'\''; next: set TAP_INDEX_HOME to a sandbox index and retry\n' \
      "$canon_root" >&2
    return 1
  fi
  return 0
}

# tap_index_enroll_team <repo-root>
# Upsert this team (basename of root) into the machine index — IFF the resolved bus
# is the canonical <root>/.tap/bus or <root>/tmp/tap. A custom TAP_HOME is unindexable
# by design (the index stores the root and derives the bus, so it can't point at an
# arbitrary home) and is skipped silently. Refuses a name already indexed at a
# DIFFERENT, still-existing root — no last-writer-wins (R13/AE8); dies naming both.
tap_index_enroll_team() {
  local root="$1" canon_root name idx gpath loc rc
  # custom / non-canonical home — unindexable, skip (shared predicate)
  tap_index_root_indexable "$root" || return 0
  canon_root="$(cd "$root" 2>/dev/null && pwd -P || printf '%s' "$root")"
  tap_index_enroll_preflight "$canon_root" || return 1
  name="$(basename "$canon_root")"
  tap_valid_token "$name" || return 0
  mkdir -p "$(tap_index_home)"

  # 3681625756: polarity (preflip teams.json vs postflip global-registry) is
  # decided UNDER teams.json.lock after a marker recheck — never from a
  # pre-lock tap_registry_v20_live snapshot. A waiter that entered preflip can
  # wake after migrate publishes the marker; without the in-lock recheck it
  # would write retired teams.json (sol RED: legacy_written_after_marker=true).
  gpath="$(tap_global_registry_file)"
  loc="$(tap_team_registry_file "$canon_root")"
  # WAVE 6.9 / 3682717708: post-flip must never enroll the retired bus file as
  # registry_location. Callers (tap init) bootstrap the acting store first;
  # bus fallback is pre-flip only.
  [ -f "$loc" ] || {
    if ! tap_registry_v20_live 2>/dev/null; then
      case "$TAP_HOME" in
        */.tap/bus) [ -f "$TAP_HOME/registry.json" ] && loc="$TAP_HOME/registry.json" ;;
      esac
    fi
  }
  idx="$(tap_index_file)"
  rc=0
  python3 -B - "$idx" "$gpath" "$name" "$canon_root" "$loc" "${_TAP_SCRIPT_DIR}" <<'PY' || rc=$?
import datetime, fcntl, json, os, sys, tempfile
sys.path.insert(0, sys.argv[6])
from registry_v20 import (
    SCHEMA, empty_global_registry, flip_marker_state, load_state_doc,
    _enrolled_entry_for_root,
)

idx, gpath, name, root, loc = sys.argv[1:6]
index_home = os.environ.get("TAP_INDEX_HOME") or os.path.dirname(idx) or "."
os.makedirs(os.path.dirname(idx) or ".", exist_ok=True)
os.makedirs(os.path.dirname(gpath) or ".", exist_ok=True)

def _write_json(path, data):
    d = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tap.")
    with os.fdopen(fd, "w") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
        fh.write("\n")
    os.replace(tmp, path)

with open(idx + ".lock", "w") as tlf:
    fcntl.flock(tlf, fcntl.LOCK_EX)
    # Recheck UNDER the lock — this is the load-bearing redirect.
    state = flip_marker_state(index_home)
    if state == "invalid":
        print("global-registry.json is present but unreadable or wrong schema", file=sys.stderr)
        sys.exit(4)
    # BORN LIVE: a machine holding NEITHER store is not pre-flip, it is new.
    #
    # `flip_marker_state` returns "absent" solely because global-registry.json
    # is missing, and its docstring reads that as "genuine pre-flip; legacy
    # routing allowed". That reading is only true when a legacy store actually
    # EXISTS. On a machine that has never held TAP state the same "absent" sent
    # first enrollment down the pre-flip path and wrote retired teams.json --
    # after which "absent" could mean either "predates the flip" or "brand
    # new", and no reader downstream could separate them.
    #
    # Bootstrap the marker here rather than teaching the classifier about
    # freshness: flip_marker_state has ~20 consumers (launcher, routing, hooks,
    # send, migrate, provenance), and changing what it MEANS would change all
    # of them. Writing the file instead makes its existing answer TRUE, and
    # every consumer reaches "live" through the path it already takes.
    #
    # DE-ENROLL DELIBERATELY DOES NOT DO THIS. tap_index_deenroll_team carries
    # the identical polarity block; bootstrapping a marker while REMOVING state
    # would create machine state during a teardown.
    #
    # Safe under this lock: teams.json.lock is the machine-wide polarity lock
    # (migrate holds it across its own marker publish), and gpath cannot exist
    # here, so no live enroll can be in flight for this index.
    # RULE 38, by OPERATOR: the question is "does a legacy STORE exist", and a
    # store is a regular file. `exists` would count a DIRECTORY at teams.json as
    # a legacy store and deny born-live on that machine permanently.
    # flip_marker_state asks the parallel question about global-registry.json
    # with isfile (registry_v20.py:51); match it.
    if state == "absent" and not os.path.isfile(idx):
        _write_json(gpath, empty_global_registry())
        # Re-ask the same instrument rather than assuming the write landed
        # live. A bootstrapped marker that does not classify live means the
        # document we just wrote is wrong, and enroll must not continue.
        state = flip_marker_state(index_home)
        if state != "live":
            print(
                "bootstrapped global-registry.json but the flip marker did not "
                f"classify live (got {state!r}) -- refusing enroll",
                file=sys.stderr,
            )
            sys.exit(4)
    if state == "live":
        with open(gpath + ".lock", "w") as glf:
            fcntl.flock(glf, fcntl.LOCK_EX)
            # Marker can still move between the two locks; recheck again.
            if flip_marker_state(index_home) != "live":
                print("flip marker moved during enroll; retry", file=sys.stderr)
                sys.exit(5)
            if os.path.isfile(gpath):
                try:
                    data = load_state_doc(gpath)
                except Exception:
                    data = empty_global_registry()
            else:
                data = empty_global_registry()
            if str(data.get("schema") or "") != SCHEMA:
                print(f"global-registry schema is not {SCHEMA}; refusing enroll", file=sys.stderr)
                sys.exit(4)
            # WAVE 6.6 / 3682338121 + sol 114826Z: initialize ONLY when the key
            # is absent. A present null/list/scalar must refuse — never normalize
            # to {} (that erased prior enrollments). flip_marker_state already
            # classifies this invalid; refuse here as a defensive belt.
            if "teams" not in data:
                data["teams"] = {}
                teams = data["teams"]
            elif not isinstance(data["teams"], dict):
                print(
                    "global-registry.json 'teams' is not an object — refusing enroll "
                    "(would erase prior enrollments)",
                    file=sys.stderr,
                )
                sys.exit(4)
            else:
                teams = data["teams"]
            # WAVE 6.11 / 3682919080: preserve an existing alias key when the
            # same real root is already enrolled — never mint a basename key.
            # WAVE 6.12 / sol 133549Z: also preserve that entry's stored
            # registry_location byte-for-byte — refresh may update root/state/
            # enrolled_at but must not repoint acting authority to the
            # canonical path (relocated custom acting → live_unreachable).
            root_real = os.path.realpath(root)
            match_st, existing_name, _existing_ent = _enrolled_entry_for_root(
                root_real, index_home,
            )
            if match_st == "ambiguous":
                print(
                    f"multiple global enrollments for root {root} — refusing enroll",
                    file=sys.stderr,
                )
                sys.exit(6)
            if match_st == "ok" and existing_name:
                enroll_key = existing_name
            else:
                enroll_key = name
            ent = teams.get(enroll_key) or {}
            if not isinstance(ent, dict):
                ent = {}
            old_root = ent.get("root")
            if (old_root and os.path.realpath(old_root) != root_real
                    and os.path.isdir(old_root)):
                print(f"already indexed at {old_root} (refusing to re-point to {root})", file=sys.stderr)
                sys.exit(3)
            now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            stored_loc = ent.get("registry_location") or ""
            if match_st == "ok" and stored_loc:
                use_loc = stored_loc
            else:
                # New / live_unenrolled enrollment — canonical acting path.
                use_loc = loc
            teams[enroll_key] = {
                "root": root,
                "registry_location": use_loc,
                "state": ent.get("state") or "registered",
                "enrolled_at": ent.get("enrolled_at") or now,
            }
            _write_json(gpath, data)
        sys.exit(0)

    # Pre-flip path — still under teams.json.lock.
    data = {}
    if os.path.exists(idx):
        try:
            with open(idx) as fh:
                data = json.load(fh)
        except Exception:
            data = {}
    teams = data.get("teams") or {}
    ent = teams.get(name) or {}
    old_root = ent.get("root")
    if (old_root and os.path.realpath(old_root) != os.path.realpath(root)
            and os.path.isdir(old_root)):
        print(f"already indexed at {old_root} (refusing to re-point to {root})", file=sys.stderr)
        sys.exit(3)
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    teams[name] = {"root": root, "enrolled_at": ent.get("enrolled_at", now)}
    data["teams"] = teams
    _write_json(idx, data)
PY
  [ "$rc" = 3 ] && tap_fail 1 name_collision "tap admin dashboard" "team '$name' is already indexed at a different path — run 'tap admin retire $name' to de-enroll the stale entry, or rename one team"
  [ "$rc" = 4 ] && tap_fail 1 invalid_flip "tap doctor" "global-registry.json is present but wrong schema — refusing enroll"
  [ "$rc" = 5 ] && tap_fail 1 enroll_retry "tap in" "flip marker moved during enroll — retry"
  [ "$rc" = 6 ] && tap_fail 1 ambiguous_root "tap admin dashboard" "multiple global enrollments for this root — resolve ambiguity before enroll"
  # CATCH-ALL. Every mapped refusal is handled above; anything else is an
  # unmapped writer failure and must NOT return success. Returning 0 here let an
  # exception inside the enroll writer read as a completed enrollment
  # (sol-pinnacle-3, P1 on #xxxx) -- Rule 19: infrastructure failure never
  # becomes a successful mutation.
  [ "$rc" = 0 ] || tap_fail 1 enroll_failed "tap doctor" \
    "machine-index enrollment did not complete (writer exit $rc) — the team may not be enrolled"
  return 0
}

# tap_index_resolve_team <team>
# Structured post/pre-flip team lookup (Bun slice, result-pairs carrier). Sets:
#   TAP_IDX_STATUS             ok|unreachable|historical|missing|invalid
#   TAP_IDX_ROOT               stored root (may be vanished — KTD-14)
#   TAP_IDX_REGISTRY_LOCATION  exact stored registry path (post-flip); empty pre-flip
# Delivery consumers (send/nudge) must use STATUS — only ok is deliverable.
# Root echo helpers may still surface unreachable/historical roots for doctor.
# Refuse-closed (driver ruling a): a bun runtime failure answers invalid,
# never missing, and returns 0. A malformed carrier is a slice failure and
# tap_fails — the shared reader owns that verdict, no local parser here.
tap_index_resolve_team() {
  local team="${1:-}" _it_result
  TAP_IDX_STATUS="missing"; TAP_IDX_ROOT=""; TAP_IDX_REGISTRY_LOCATION=""
  _it_result="$(mktemp "${TMPDIR:-/tmp}/tap-idx-team.XXXXXX")" || { TAP_IDX_STATUS="invalid"; return 0; }
  if ! TAP_INDEX_HOME="$(tap_index_home)" tap_bun_call team-selection "$team" team-selection.ts resolve-team --result "$_it_result" -- "$team"; then
    rm -f "${_it_result:?}"
    TAP_IDX_STATUS="invalid"
    return 0
  fi
  tap_bun_read_pairs "$_it_result" "team resolution ($team)"
  tap_bun_require_pairs "team resolution ($team)" _IT_STATUS _IT_ROOT _IT_REGISTRY_LOCATION
  TAP_IDX_STATUS="$_IT_STATUS"; TAP_IDX_ROOT="$_IT_ROOT"; TAP_IDX_REGISTRY_LOCATION="$_IT_REGISTRY_LOCATION"
  return 0
}

# tap_index_resolve_root <team>
# Echo the indexed repo root for <team> if present and still existing.
# READ-ONLY on every arm: the pre-flip prune-on-read is retired (R13) — a
# vanished root answers missing without rewriting teams.json. Post-flip, a
# vanished root is observed evidence (KTD-14); echo the stored root when the
# team is registered (even if the registry_location is unreachable — callers/
# doctor surface that).
# Silent (no output, rc 0) on miss AND on bun runtime failure — every caller
# already treats empty output as unresolved. NOTE: this is NOT the delivery
# authority — use tap_index_resolve_team / TAP_IDX_STATUS for send/nudge binding.
tap_index_resolve_root() {
  local team="${1:-}" _ir_result
  _ir_result="$(mktemp "${TMPDIR:-/tmp}/tap-idx-root.XXXXXX")" || return 0
  if ! TAP_INDEX_HOME="$(tap_index_home)" tap_bun_call team-selection "$team" team-selection.ts resolve-root --result "$_ir_result" -- "$team"; then
    rm -f "${_ir_result:?}"
    return 0
  fi
  tap_bun_read_pairs "$_ir_result" "team root resolution ($team)"
  tap_bun_require_pairs "team root resolution ($team)" _IR_ROOT
  printf '%s' "$_IR_ROOT"
  return 0
}

# tap_index_find_pane_team <pane_id>
# Search machine-indexed teams for <pane_id>. Output "team<TAB>root<TAB>handle"
# on match, exit 0. Silent exit 1 on miss.
# Post-flip: walk global-registry.json registered teams via stored registry_location.
# Pre-flip: teams.json + legacy bus registries only (team-registry.json inert).
# Verdicts (tap-3kwy). A pane id is EVIDENCE, not an identity: ids are unique only
# within one tmux server lifetime, so a row from a prior generation names a pane the
# current server may have given to someone else. Exit code carries the verdict and
# only 0 yields an identity, so a caller cannot reach a confident answer by accident:
#
#   0  resolved      one current-epoch claimant, confirmed by tmux; stdout team/root/handle
#   1  unregistered  pane exists, no current-epoch claimant (today's tap register case)
#   3  no_such_pane  the pane id does not exist on the live server
#   4  contested     >1 current-epoch claimant — refuses rather than picking one
#   5  unknown       tmux unobservable; per Ops this escalates immediately, never parks
#
# A non-resolved run writes "<verdict>\t<evidence>" on stdout so the caller's remedy
# line can name what was actually observed. Ordering is never a tiebreak.
tap_index_find_pane_team() {
  local target_pane="$1" idx gpath epoch_now pane_session tmux_state out rc
  [ -n "$target_pane" ] || return 1
  gpath="$(tap_global_registry_file)"
  if tap_registry_v20_live; then
    [ -f "$gpath" ] || return 1
    # ONE tmux answer carries the session AND the generation it was observed under
    # (sol #1): reading them from two calls lets a server replacement land between
    # them, so an E1 row can be validated against a recycled pane on E2 — the exact
    # split-observation failure CONTRACT.md:31 records for the launcher's verifier.
    obs="$(tmux display-message -p -t "$target_pane" '#{session_name}	#{pid}:#{start_time}' 2>/dev/null)" && obs_rc=0 || obs_rc=$?
    pane_session=""; observed_gen=""; tmux_state="ok"
    if [ "${obs_rc:-1}" -eq 0 ] && [ -n "$obs" ]; then
      pane_session="${obs%%	*}"
      observed_gen="$(tap_server_epoch_from_raw "${obs##*	}" 2>/dev/null || true)"
    else
      # Capture status AND text OUTSIDE a pipeline (sol #6): under the callers'
      # `set -o pipefail`, `tmux list-sessions 2>&1 | grep` stays nonzero when tmux
      # itself failed, so a canonical no-server reply could never reach no_such_pane.
      ls_out="$(tmux list-sessions 2>&1)" && ls_rc=0 || ls_rc=$?
      if [ "${ls_rc:-1}" -eq 0 ]; then
        tmux_state="absent"
      elif printf '%s' "$ls_out" | grep -qE 'no server running|error connecting to .*\(No such file or directory\)'; then
        tmux_state="absent"
      else
        tmux_state="unknown"
      fi
    fi
    local _verdict_file
    _verdict_file="$(mktemp -t tap-pane-verdict.XXXXXX)"
    local _py_file
    _py_file="$(mktemp -t tap-pane-resolve.XXXXXX)"
    cat >"$_py_file" <<'PY'
import json, os, sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import seat_axis
gpath, target_pane = sys.argv[1:3]
pane_session, observed_gen, tmux_state = sys.argv[4:7]

claims = []
unreadable = []          # registered sources we could NOT observe (sol #3)
missing = []             # registered sources whose acting file is positively gone
try:
    data = json.load(open(gpath))
except Exception:
    sys.exit(1)
for team_name, ent in (data.get("teams") or {}).items():
    if not isinstance(ent, dict):
        continue
    if str(ent.get("state") or "registered") != "registered":
        continue
    loc = ent.get("registry_location") or ""
    root = ent.get("root") or ""
    if not loc:
        unreadable.append(team_name); continue
    # An enrolled team whose acting authority cannot be read is UNREACHABLE, never
    # proven empty — including when the file is simply gone. CONTRACT grants
    # "absent is an answer" to cancel alone and says so on purpose, keeping
    # fail-closed polarity for identity-sensitive consumers; this lookup hands out
    # an identity and an executable root door, so it sits on the fail-closed side.
    # A genuinely empty team is a PRESENT file with an empty seat axis.
    try:
        with open(loc) as fh:
            rdata = json.load(fh)
    except FileNotFoundError:
        missing.append(team_name); continue
    except Exception:
        unreadable.append(team_name); continue
    if not isinstance(rdata, dict):
        unreadable.append(team_name); continue
    # A registry whose seats axis is absent or malformed (`{"seats": []}`) reads as
    # an empty seat map, so a structural defect would silently become "no claims".
    axis = seat_axis(rdata)
    if axis is None:
        unreadable.append(team_name); continue
    for handle, seat in axis.items():
        if not isinstance(seat, dict):
            continue
        pid = seat.get("pane_id") or ""
        pname = seat.get("pane") or ""
        if pid == target_pane or pname == target_pane or pname.endswith("/" + target_pane):
            claims.append({
                "team": team_name, "root": root, "handle": handle,
                "epoch": str(seat.get("server_epoch") or ""),
                # The row's OWN session claim. Crew seats live in their driver's
                # session (CONTRACT: crew share the driver's tmux session), so a
                # synthesized "<team>/<handle>" is wrong for them (sol #5).
                "session": str(seat.get("session") or ""),
            })

def describe(rows):
    return "; ".join(
        "{}/{} (session {}, epoch {})".format(
            c["team"], c["handle"], c["session"] or "unrecorded", c["epoch"] or "UNSTAMPED")
        for c in rows) or "no claimant rows"

def emit(verdict, evidence, payload=None, code=1):
    if payload:
        sys.stdout.write(payload)
    else:
        sys.stdout.write(verdict + "\t" + evidence + "\n")
    sys.exit(code)

if tmux_state == "unknown":
    emit("unknown", "tmux could not be observed; rows naming it: " + describe(claims), code=5)
if tmux_state == "absent" or not pane_session:
    emit("no_such_pane", "rows still naming it: " + describe(claims), code=3)

# CORROBORATION, not absence of objection (sol #2 / gate's retraction). The row's
# stored session must EQUAL what tmux reports. No parsing, so there is no
# "uninterpretable" branch to skip: a session name the convention did not produce
# simply fails to match, which is a missing second source rather than a free pass.
matched = [c for c in claims if c["session"] and c["session"] == pane_session]

# Session equality corroborates the CO-TENANT GROUP, not the handle: crew seats
# deliberately share their driver's session, so a prior-generation crew row still
# matches when the id is recycled into the same session. Only the generation stamp
# binds a row's pane id to THIS server lifetime, so an unstamped row cannot confer
# identity here — it gets the re-attestation door instead.
if not observed_gen:
    emit("unknown",
         "the pane's generation could not be observed, so no claimant can be bound to this "
         "server lifetime; rows naming it: " + describe(matched or claims), code=5)
current = [c for c in matched if c["epoch"] == observed_gen]

if len(current) > 1:
    emit("contested",
         "{} claimants agree with this pane's session: {}".format(len(current), describe(current)),
         code=4)

# Uniqueness is a claim over the REGISTERED population, so an unobservable source
# leaves it unproven — silently skipping one cannot support it (sol #3).
if unreadable:
    emit("unknown",
         "registered team(s) {} could not be read, so single-claimant uniqueness is unproven; "
         "readable rows naming it: {}".format(", ".join(sorted(unreadable)), describe(claims)),
         code=5)

# A missing acting file is still fail-closed for identity, but unlike a corrupt
# source it has an existing machine-wide repair: admin refresh rechecks under
# the index writer lock and purges data-gone enrollments. Name that executable
# door instead of escalating a state the operator can repair directly.
if missing:
    emit("stale_enrollment",
         "registered team(s) {} have no acting registry file, so single-claimant "
         "uniqueness is unproven; readable rows naming it: {}".format(
             ", ".join(sorted(missing)), describe(claims)),
         code=5)

if not current:
    emit("unregistered",
         "it is live in session '{}' but no CURRENT-generation seat claims that session "
         "(an unstamped row cannot bind a pane id to this server lifetime); rows naming it: "
         "{}".format(pane_session, describe(claims)), code=1)

c = current[0]
emit("resolved", "{} is {}/{}".format(target_pane, c["team"], c["handle"]),
     payload="{}\t{}\t{}\n".format(c["team"], c["root"], c["handle"]), code=0)
PY
    out="$(python3 -B "$_py_file" "$gpath" "$target_pane" "${_TAP_SCRIPT_DIR}" "$pane_session" "$observed_gen" "$tmux_state" 2>>"$_verdict_file")"
    rc=$?
    rm -f "$_py_file" "$_verdict_file"
    [ -n "$out" ] && printf '%s\n' "$out"
    return $rc
  fi
  idx="$(tap_index_file)"
  [ -f "$idx" ] || return 1
  python3 -B - "$idx" "$target_pane" <<'PY'
import json, os, sys
idx, target_pane = sys.argv[1:3]
if not os.path.exists(idx): sys.exit(1)
try:
    with open(idx) as fh: data = json.load(fh)
except Exception:
    sys.exit(1)

teams = data.get("teams") or {}
for team_name, ent in teams.items():
    if not isinstance(ent, dict): continue
    root = ent.get("root")
    if not root or not os.path.isdir(root): continue
    # Pre-flip dormancy: bus registries only — never team-registry.json.
    candidates = [
        os.path.join(root, ".tap", "bus", "registry.json"),
        os.path.join(root, "tmp", "tap", "registry.json"),
    ]
    rdata = None
    for reg_file in candidates:
        if not os.path.exists(reg_file):
            continue
        try:
            with open(reg_file) as rfh:
                rdata = json.load(rfh)
            break
        except Exception:
            continue
    if not isinstance(rdata, dict):
        continue
    agents = (rdata.get("seats") if isinstance(rdata.get("seats"), dict) else rdata.get("agents") or rdata.get("active") or {})
    if not isinstance(agents, dict): continue
    for handle, seat in agents.items():
        if not isinstance(seat, dict): continue
        pid = seat.get("pane_id") or ""
        pname = seat.get("pane") or ""
        if pid == target_pane or pname == target_pane or pname.endswith("/" + target_pane):
            print(f"{team_name}\t{root}\t{handle}")
            sys.exit(0)
sys.exit(1)
PY
}

# tap_fail_unregistered_pane <pane> [detail] [exit-code]
# Fail for an unregistered pane, checking if it is enrolled under another team in the
# machine index (~/.tap/teams.json) to avoid giving false duplicate registration doors.
tap_fail_unregistered_pane() {
  local pane="$1" detail="${2:-}" rc="${3:-2}" match team_name root handle
  if match="$(tap_index_find_pane_team "$pane")"; then
    team_name="$(printf '%s' "$match" | cut -f1)"
    root="$(printf '%s' "$match" | cut -f2)"
    handle="$(printf '%s' "$match" | cut -f3)"
    # whoami and peek do not accept --team; keep their remedy executable.
    if [ "${TAP_VERB:-}" = "tap whoami" ] || [ "${TAP_VERB:-}" = "tap peek" ]; then
      tap_fail "$rc" unanchored_bus "cd $root" \
        "unanchored cwd ($PWD) has no TAP bus; pane $pane is registered as '$handle' on team '$team_name' at '$root'"
    else
      tap_fail "$rc" unanchored_bus "cd $root  OR  pass --team $team_name" \
        "unanchored cwd ($PWD) has no TAP bus; pane $pane is registered as '$handle' on team '$team_name' at '$root'"
    fi
  else
    # tap-3kwy: the refusal must report what was OBSERVED, not assert a state nobody
    # checked. "not registered" is itself a confident claim, and it is wrong for a
    # pane id that does not exist and for one whose claimants disagree — the remedy
    # it printed sent an operator to `tap register` a pane that is not there.
    local verdict evidence
    verdict="$(printf '%s' "$match" | cut -f1)"
    evidence="$(printf '%s' "$match" | cut -f2)"
    case "$verdict" in
      no_such_pane)
        # `tap in`/`tap register` is CONTRACT's attested write-boundary repair for a
        # row whose recorded pane is from a previous server. Verified executable from
        # an unanchored cwd; the earlier "run whoami from a pane that exists" told an
        # operator standing in the broken state to go stand somewhere else.
        tap_fail "$rc" pane_gone "tap register   (the recorded pane is from a previous tmux server; re-register to rebind)" \
          "pane $pane does not exist on the current tmux server, so no identity can be derived from it; $evidence"
        ;;
      contested)
        # A lookup that cannot tell two seats apart must not hand out an identity.
        # NOT a bare `tap escalate`: from an unanchored cwd that refuses with
        # "run tap register in this pane, or pass --from" — verified by running it.
        # escalate needs a bus anchor and a truthful identity, and identity is exactly
        # what this verdict says cannot be derived, so the caller must supply both.
        tap_fail "$rc" pane_contested "tap escalate --team <team> --from <your handle>   (a human decides which seat owns this pane)" \
          "pane $pane cannot be resolved to one seat; $evidence"
        ;;
      unknown)
        # panel ruling: an unrecognised pane state is a custody question for a human,
        # not a delivery problem to wait on. Escalate immediately rather than park.
        tap_fail "$rc" pane_unknown "tap escalate --team <team> --from <your handle>   (do not retry; tmux state is unreadable)" \
          "pane $pane could not be observed, so its identity is unknown rather than absent; $evidence"
        ;;
      stale_enrollment)
        tap_fail "$rc" pane_unknown "tap admin refresh   (purges enrolled teams whose acting registry file is gone)" \
          "pane $pane identity is blocked by stale machine enrollment; $evidence"
        ;;
      unregistered)
        # The pane IS live; no current-generation row claims it. Same remedy as the
        # generic case, but it carries the evidence — a recycled id whose only
        # claimant is a prior generation reads as "not registered" while an operator
        # can see a row that LOOKS like theirs, and the difference is the whole
        # question they are trying to answer.
        tap_fail "$rc" unregistered "tap register" "pane $pane $evidence"
        ;;
      *)
        tap_fail "$rc" unregistered "tap register" "${detail:-pane $pane is not registered}"
        ;;
    esac
  fi
}

# tap_is_launcher_managed <handle>
# Returns 0 when the acting registry row carries launcher session lineage.
tap_is_launcher_managed() {
  local handle="$1" registry
  [ -n "$handle" ] || return 1
  registry="$(tap_acting_registry 2>/dev/null || true)"
  [ -n "$registry" ] && [ -f "$registry" ] || return 1
  python3 -B - "$registry" "$handle" "${_TAP_SCRIPT_DIR}" <<'PY'
import json, sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import _seat_map
try:
    with open(sys.argv[1]) as fh:
        data = json.load(fh)
except Exception:
    sys.exit(1)
entry = _seat_map(data).get(sys.argv[2])
if not isinstance(entry, dict):
    sys.exit(1)
session = entry.get("session")
harness = entry.get("harness")
sys.exit(0 if isinstance(session, str) and session and isinstance(harness, str) and harness else 1)
PY
}

# tap_fail_no_actor <verb> [detail]
# Fail for missing actor on done/cancel/command, checking if caller pane is enrolled on
# another team in ~/.tap/teams.json to provide single-door resolution.
tap_fail_no_actor() {
  local verb="$1" detail="${2:-only the addressee settles}" pane="" caller_refusal="" match team_name root handle
  if ! tap_calling_pane_id pane; then
    caller_refusal="${TAP_CALLING_PANE_REFUSAL:-}"
  fi
  if [ -n "$pane" ] && match="$(tap_index_find_pane_team "$pane")"; then
    team_name="$(printf '%s' "$match" | cut -f1)"
    root="$(printf '%s' "$match" | cut -f2)"
    handle="$(printf '%s' "$match" | cut -f3)"
    if [ "$verb" = "tap command" ]; then
      tap_fail 1 no_actor "cd $root" \
        "$detail (pane $pane is registered on team '$team_name' at '$root')"
    else
      tap_fail 1 no_actor "cd $root  OR  pass --by $handle" \
        "$detail (pane $pane is registered on team '$team_name' at '$root')"
    fi
  else
    if [ -n "$caller_refusal" ]; then
      detail="$detail (caller pane observation: $caller_refusal)"
    fi
    if [ "$verb" = "tap command" ]; then
      tap_fail 1 no_actor "run 'tap register' to join this team" "$detail"
    else
      tap_fail 1 no_actor "pass --by <handle> (or run 'tap register' to join this team)" "$detail"
    fi
  fi
}

# tap_index_deenroll_team <team> [--if-root-missing]
#                        [--capture <artifact> --expect-root <root> --expect-registry <path>]
# Remove one team from the marker-selected machine index and print its former
# root. WAVE 6 / 3681907109: post-flip mutates global-registry.json (never the
# retired teams.json alone). The optional doctor guard rechecks the root while
# holding the writer lock. Exit: 0 removed | 2 unknown | 3 unreadable | 4 invalid
# | 5 root present | 6 capture expectation mismatch.
#
# Capture mode (H1 tap-gmj0i U5): with --capture, the removal is guarded by an
# exact expectation set — the entry's root and registry_location must match
# --expect-root/--expect-registry exactly, and the acting registry file must be
# positively absent (the observable lifecycle fact, not a selector flag). The
# full entry (including unknown extras) is written atomically to <artifact>
# BEFORE publication so a failed rollback can restore byte-exact enrollment.
# Lock order mirrors enrollment: acting-registry sidecar lock FIRST, then the
# index writer locks. Without --capture, stdout and exits are unchanged.
tap_index_deenroll_team() {
  local team="$1" missing_guard="" capture="" expect_root="" expect_registry=""
  [ -n "$team" ] || return 2
  shift
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --if-root-missing) missing_guard="$1" ;;
      --capture) [ "$#" -ge 2 ] && [ -n "${2:-}" ] || return 4; capture="$2"; shift ;;
      --expect-root) [ "$#" -ge 2 ] && [ -n "${2:-}" ] || return 4; expect_root="$2"; shift ;;
      --expect-registry) [ "$#" -ge 2 ] && [ -n "${2:-}" ] || return 4; expect_registry="$2"; shift ;;
      *) return 4 ;;
    esac
    shift
  done
  # Capture expectations are all-or-none: any witness flag without the full
  # triplet is malformed and must refuse BEFORE the destructive no-capture path.
  if [ -n "$capture" ] || [ -n "$expect_root" ] || [ -n "$expect_registry" ]; then
    { [ -n "$capture" ] && [ -n "$expect_root" ] && [ -n "$expect_registry" ]; } || return 4
  fi
  idx="$(tap_index_file)"
  gpath="$(tap_global_registry_file)"
  mkdir -p "$(tap_index_home)"
  python3 -B - "$idx" "$gpath" "$team" "${_TAP_SCRIPT_DIR}" "$missing_guard" \
    "$capture" "$expect_root" "$expect_registry" <<'PY'
import fcntl, json, os, sys, tempfile
sys.path.insert(0, sys.argv[4])
from registry_v20 import flip_marker_state, load_state_doc

idx, gpath, team = sys.argv[1:4]
missing_guard = sys.argv[5] == "--if-root-missing"
capture, expect_root, expect_registry = sys.argv[6:9]
index_home = os.environ.get("TAP_INDEX_HOME") or os.path.dirname(idx) or "."

def _write_json(path, data):
    d = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tap.")
    with os.fdopen(fd, "w") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
        fh.write("\n")
    os.replace(tmp, path)

# Capture mode fences the acting-registry sidecar FIRST (registry→index is the
# enrollment lock order; the removal witness must be taken under it).
actlf = None
if capture:
    try:
        actlf = open(expect_registry + ".lock", "a+")
        fcntl.flock(actlf, fcntl.LOCK_EX)
    except OSError as exc:
        print(f"acting-registry sidecar lock for capture failed ({exc})", file=sys.stderr)
        sys.exit(3)

# Hold teams.json.lock for polarity recheck (same enroll fence polarity).
with open(idx + ".lock", "w") as tlf:
    fcntl.flock(tlf, fcntl.LOCK_EX)
    state = flip_marker_state(index_home)
    if state == "invalid":
        print("global-registry.json is present but unreadable or wrong schema", file=sys.stderr)
        sys.exit(4)
    if state == "live":
        with open(gpath + ".lock", "w") as glf:
            fcntl.flock(glf, fcntl.LOCK_EX)
            if flip_marker_state(index_home) != "live":
                print("flip marker moved during retire; retry", file=sys.stderr)
                sys.exit(3)
            try:
                data = load_state_doc(gpath)
            except Exception as exc:
                print(f"global-registry '{gpath}' could not be read ({exc})", file=sys.stderr)
                sys.exit(3)
            teams = data.get("teams") or {}
            if not isinstance(teams, dict):
                teams = {}
            ent = teams.get(team)
            if ent is None:
                sys.exit(2)
            if missing_guard and isinstance(ent, dict) and os.path.isdir(str(ent.get("root") or "")):
                sys.exit(5)
            if capture:
                if not isinstance(ent, dict):
                    print("captured entry is not an object", file=sys.stderr)
                    sys.exit(3)
                ent_root = str(ent.get("root") or "")
                ent_loc = str(ent.get("registry_location") or "")
                try:
                    same_root = os.path.realpath(ent_root) == os.path.realpath(expect_root)
                except OSError:
                    same_root = ent_root == expect_root
                if not same_root:
                    print(f"capture refused: enrolled root '{ent_root}' does not match expected '{expect_root}'", file=sys.stderr)
                    sys.exit(6)
                if ent_loc != expect_registry:
                    print(f"capture refused: registry_location '{ent_loc}' does not match expected '{expect_registry}'", file=sys.stderr)
                    sys.exit(6)
                # Explicit polarity: only a positive FileNotFoundError proves the
                # acting registry is gone; an unprobeable path must NOT authorize
                # index deletion.
                try:
                    os.stat(expect_registry)
                except FileNotFoundError:
                    pass
                except OSError as exc:
                    print(f"capture refused: acting registry '{expect_registry}' could not be inspected ({exc})", file=sys.stderr)
                    sys.exit(6)
                else:
                    print(f"capture refused: acting registry '{expect_registry}' still exists (team not fully stopped)", file=sys.stderr)
                    sys.exit(6)
                envelope = {
                    "authority": "live",
                    "team": team,
                    "entry": ent,
                    "expected_root": expect_root,
                    "registry_location": expect_registry,
                    "index_root": index_home,
                    "index_path": gpath,
                }
                # Witness lands on disk BEFORE the index publishes the removal.
                _write_json(capture, envelope)
            teams.pop(team, None)
            data["teams"] = teams
            _write_json(gpath, data)
            if not capture and isinstance(ent, dict):
                sys.stdout.write(ent.get("root", ""))
        if actlf is not None:
            actlf.close()
        sys.exit(0)

    # Pre-flip — legacy teams.json.
    if capture:
        print("capture requires live v0.20 authority", file=sys.stderr)
        sys.exit(4)
    data = {}
    if os.path.exists(idx):
        try:
            with open(idx) as fh:
                data = json.load(fh)
        except Exception as exc:
            print(f"machine index '{idx}' could not be read ({exc})", file=sys.stderr)
            sys.exit(3)
    teams = data.get("teams") or {}
    ent = teams.get(team)
    if ent is None:
        sys.exit(2)
    if missing_guard and isinstance(ent, dict) and os.path.isdir(str(ent.get("root") or "")):
        sys.exit(5)
    teams.pop(team, None)
    data["teams"] = teams
    _write_json(idx, data)
    if isinstance(ent, dict):
        sys.stdout.write(ent.get("root", ""))
PY
}


# tap_apply_team_override <team>
# Pane-less callers (poll-mode members, daemons) have no pane and often no
# meaningful cwd (a launchd cwd is not a bus anchor — the launchd-cwd-lands-on-
# wrong-bus failure, CONTRACT.md §Registry). A global --team on poll/done/reply/
# send/outstanding resolves the SAME machine index `register --team` uses and
# re-derives TAP_HOME/TAP_PAYLOADS/etc from that team's root, overriding whatever
# cwd-based default lib.sh's source-time resolution chose. Rule (CONTRACT.md §Bus
# anchor for pane-less callers): for a pane-less caller, bus identity comes from
# --team or an explicit TAP_HOME, never cwd. A no-op for an empty <team>; an
# explicit TAP_HOME env (rule=env) always wins and is never second-guessed.
tap_apply_team_override() {
  local team="$1" root
  [ -n "$team" ] || return 0
  [ "${TAP_BUS_RULE:-}" = "env" ] && return 0
  tap_valid_token "$team" || tap_fail 1 usage_error "tap help" "--team '$team' fails charset $TAP_ID_RE"
  root="$(tap_index_resolve_root "$team")"
  [ -n "$root" ] || tap_fail 1 not_found "tap register" "--team '$team' is not enrolled in the machine index (~/.tap/teams.json) — register a member in that worktree first, or pass an explicit TAP_HOME"
  if [ -d "$root/.tap/bus" ]; then
    TAP_HOME="$root/.tap/bus"; TAP_BUS_RULE="team-dotdir"
  elif [ -d "$root/tmp/tap" ]; then
    TAP_HOME="$root/tmp/tap"; TAP_BUS_RULE="team-legacy"
  else
    TAP_HOME="$root/.tap/bus"; TAP_BUS_RULE="team-default"
  fi
  TAP_HOME="$(cd "$TAP_HOME" 2>/dev/null && pwd -P || printf '%s' "$TAP_HOME")"
  TAP_PAYLOADS="$TAP_HOME/payloads"
  TAP_RECEIPTS="$TAP_HOME/receipts"
  TAP_REGISTRY="$TAP_HOME/registry.json"
  TAP_INPUT_BACKUPS="$TAP_HOME/input-backups"
  TAP_REGISTRY_EVENTS="$TAP_HOME/registry-events.log"
  TAP_WATCH_LOGS="$TAP_HOME/watch/evaluator-prompts"
  # Post-flip: registry ACTS at stored location, not the bus decoy just set.
  tap_rebind_acting_registry "$team" || tap_fail 1 registry_unreachable \
    "tap doctor" "acting registry for team '$team' is unreachable (flip marker live/invalid?)"
  # Export so a verb that shells out to another tap-*.sh (tap reply -> tap send)
  # propagates the resolved bus instead of the child re-deriving it from cwd —
  # cwd is exactly what --team exists to bypass for a pane-less caller. The
  # derived-bus marker exports WITH it so both runtimes (and their children)
  # keep locks on the incumbent root: a child must not mistake the inherited
  # TAP_HOME for a caller pin (tap-7r3fn.66, Fable round-1 finding).
  TAP_TEAM_OVERRIDE_BUS="$TAP_HOME"
  export TAP_HOME TAP_BUS_RULE TAP_REGISTRY TAP_TEAM_OVERRIDE_BUS
}

# tap_resolve_payload_by_id <id>
# tap-akt4: on a LOCAL miss, resolve a payload id across every enrolled team's bus
# (the machine index roots; each bus is <root>/.tap/bus, else legacy <root>/tmp/tap —
# the same derivation tap_apply_team_override uses). Payload filenames are globally
# unique (sender handle + UTC timestamp + hex), so at most one match: echo its absolute
# path, or nothing when none. More than one match is a filename-collision anomaly that
# must never pass silently — fail loud (exit 3) so the caller demands --payload. This
# lets `tap reply/done <id>` settle a cross-worktree obligation whose payload lives on
# the sender team's bus, without the caller hand-copying the sentinel's path= field.
tap_resolve_payload_by_id() {
  local id="$1" idx
  # WAVE 6.7 / 3682449519: marker-selected index — post-flip teams live only in
  # global-registry.json; teams.json alone makes cross-team bare-id reply/done
  # miss enrolled buses. invalid marker → fail closed (no retired-index scan).
  idx="$(tap_authority_index_file)" || return 0
  [ -f "$idx" ] || return 0
  python3 -B - "$idx" "$id" <<'PY'
import json, os, sys
idx, ident = sys.argv[1], sys.argv[2]
try:
    teams = (json.load(open(idx)).get("teams") or {})
except Exception:
    sys.exit(0)
hits = []
for ent in teams.values():
    root = (ent or {}).get("root")
    if not root:
        continue
    bus = os.path.join(root, ".tap", "bus")
    if not os.path.isdir(bus):
        legacy = os.path.join(root, "tmp", "tap")
        bus = legacy if os.path.isdir(legacy) else bus
    p = os.path.join(bus, "payloads", ident + ".md")
    if os.path.isfile(p):
        hits.append(os.path.realpath(p))
hits = sorted(set(hits))
if len(hits) == 1:
    print(hits[0])
elif len(hits) > 1:
    sys.stderr.write("id resolves to multiple enrolled team buses:\n  " + "\n  ".join(hits) + "\n")
    sys.exit(3)
PY
}

# tap_resolve_team_target <raw-target>
# THE single source of truth for team-qualified <team>/<handle> (and bare <handle>)
# address resolution, shared by tap-send.sh and tap-nudge.sh (tap-zvx) so the two
# can never drift — a change to the resolution chain here reaches both verbs. It
# performs exactly the resolution tap send historically inlined:
#   1. LOCAL_TEAM from the BUS ANCHOR (the git toplevel containing TAP_HOME's parent,
#      then that registry's team.name; falls back to the worktree basename) — NEVER
#      cwd, so a cross-team caller run from an unrelated repo still brands correctly.
#   2. index resolve (tap_index_resolve_root), then a git worktree-list sibling scan
#      as the deprecation-window fallback for a team not yet enrolled in the index.
# Sets globals (never returns fields on stdout, so callers stay quiet):
#   TAP_TT_SCOPE       local | remote | unknown_team | error
#   TAP_TT_LOCAL_TEAM  the caller's own team (always set)
#   TAP_TT_SENDER_ROOT the bus-anchored sender repo root (always set)
#   TAP_TT_TEAM        the target team (== LOCAL_TEAM for a bare handle)
#   TAP_TT_HANDLE      the bare handle
#   TAP_TT_ROOT        remote worktree root (remote scope only; else empty)
#   TAP_TT_REGISTRY    exact registry bound for downstream recipient lookups
#   TAP_TT_DETAIL      known sibling team names (unknown_team) / error text (error)
# Dies ONLY on a malformed address (bad charset / not one-slash) or an invalid local
# team token — verb-agnostic usage errors (die honors TAP_VERB). unknown_team and
# error are RETURNED (not died) so each caller names its own --pane / --cross-worktree
# fallback in its own voice. Always returns 0.
tap_resolve_team_target() {
  local target="$1" bus_parent
  if [[ "$target" == *:* ]] && [[ "$target" != */* ]]; then
    tap_valid_qualified_token "$target" \
      || tap_fail 1 usage_error "tap help" "address '$target' is not a valid <team>:<handle> token ($TAP_ID_RE)"
    target="${target%%:*}/${target#*:}"
  fi
  TAP_TT_SCOPE=""; TAP_TT_LOCAL_TEAM=""; TAP_TT_SENDER_ROOT=""
  TAP_TT_TEAM=""; TAP_TT_HANDLE=""; TAP_TT_ROOT=""; TAP_TT_REGISTRY=""; TAP_TT_DETAIL=""
  bus_parent="$(cd "$(dirname "$TAP_HOME")" 2>/dev/null && pwd -P || true)"
  if [ -n "$bus_parent" ] && git -C "$bus_parent" rev-parse --show-toplevel >/dev/null 2>&1; then
    TAP_TT_SENDER_ROOT="$(git -C "$bus_parent" rev-parse --show-toplevel)"
  else
    TAP_TT_SENDER_ROOT="$(_tap_repo_root)"
  fi
  TAP_TT_LOCAL_TEAM="$(python3 -B - "$TAP_REGISTRY" "$TAP_TT_SENDER_ROOT" <<'PY'
import json, os, sys
registry, repo_root = sys.argv[1], sys.argv[2]
try:
    team = ((json.load(open(registry)).get("team") or {}).get("name") or "").strip()
except Exception:
    team = ""
print(team or os.path.basename(repo_root.rstrip(os.sep)))
PY
)"
  tap_valid_token "$TAP_TT_LOCAL_TEAM" || tap_fail 1 usage_error "tap help" "local team '$TAP_TT_LOCAL_TEAM' is not a valid token ($TAP_ID_RE)"

  case "$target" in
    */*)
      TAP_TT_TEAM="${target%%/*}"; TAP_TT_HANDLE="${target#*/}"
      { [ -n "$TAP_TT_TEAM" ] && [ -n "$TAP_TT_HANDLE" ] && [[ "$TAP_TT_HANDLE" != */* ]]; } \
        || tap_fail 1 usage_error "tap help" "address '$target' must be <team>/<handle> with one slash"
      tap_valid_token "$TAP_TT_TEAM"   || tap_fail 1 usage_error "tap help" "team '$TAP_TT_TEAM' is not a valid token ($TAP_ID_RE)"
      tap_valid_token "$TAP_TT_HANDLE" || tap_fail 1 usage_error "tap help" "handle '$TAP_TT_HANDLE' is not a valid token ($TAP_ID_RE)" ;;
    *)
      TAP_TT_TEAM="$TAP_TT_LOCAL_TEAM"; TAP_TT_HANDLE="$target" ;;
  esac

  # Pass1 #1 + authority-context class: only explicit absent|live may continue.
  # Unreadable marker (empty capture / import fail) must NOT fall through to
  # pre-flip teams.json / worktree-list — same polarity as tap_authority_context.
  _tt_marker="$(tap_registry_v20_state)" || _tt_marker=""
  case "$_tt_marker" in
    invalid)
      TAP_TT_SCOPE="invalid_flip"
      TAP_TT_DETAIL="global-registry.json is present but unreadable or wrong schema; repair migration (tap doctor) — refusing legacy fallback"
      return 0 ;;
    live|absent)
      ;;
    *)
      TAP_TT_SCOPE="invalid_flip"
      TAP_TT_DETAIL="could not read global-registry flip marker (python/import PATH); refusing legacy fallback"
      return 0 ;;
  esac

  # Local team: post-flip still binds stored registry_location (not ambient TAP_REGISTRY).
  if [ "$TAP_TT_TEAM" = "$TAP_TT_LOCAL_TEAM" ]; then
    if tap_registry_v20_live; then
      tap_index_resolve_team "$TAP_TT_TEAM"
      case "$TAP_IDX_STATUS" in
        ok)
          TAP_TT_ROOT="$TAP_IDX_ROOT"
          TAP_TT_REGISTRY="$TAP_IDX_REGISTRY_LOCATION"
          if [ -z "$TAP_TT_REGISTRY" ] || [ ! -f "$TAP_TT_REGISTRY" ]; then
            TAP_TT_SCOPE="unreachable_team"
            TAP_TT_DETAIL="stored registry_location missing or unreadable for '$TAP_TT_TEAM'"
            return 0
          fi
          TAP_TT_SCOPE="local"; return 0 ;;
        invalid)
          TAP_TT_SCOPE="invalid_flip"
          TAP_TT_DETAIL="${TAP_IDX_ROOT:-global registry unreadable}"
          return 0 ;;
        *)
          TAP_TT_SCOPE="unreachable_team"
          TAP_TT_DETAIL="local team '$TAP_TT_TEAM' has no usable stored registry_location post-flip"
          return 0 ;;
      esac
    fi
    TAP_TT_REGISTRY="$TAP_REGISTRY"
    TAP_TT_SCOPE="local"; return 0
  fi

  # Post-flip remote: structured resolve — delivery binds ONLY stored registry_location
  # on status=ok. historical/unreachable/invalid are non-deliverable.
  # Pre-flip: teams.json root + legacy bus registry only (team-registry.json is
  # inert until the flip — dormancy).
  if tap_registry_v20_live; then
    tap_index_resolve_team "$TAP_TT_TEAM"
    case "$TAP_IDX_STATUS" in
      ok)
        TAP_TT_ROOT="$TAP_IDX_ROOT"
        TAP_TT_REGISTRY="$TAP_IDX_REGISTRY_LOCATION"
        if [ -z "$TAP_TT_REGISTRY" ] || [ ! -f "$TAP_TT_REGISTRY" ]; then
          TAP_TT_SCOPE="unreachable_team"
          TAP_TT_DETAIL="stored registry_location missing or unreadable for '$TAP_TT_TEAM'"
          return 0
        fi
        TAP_TT_SCOPE="remote"; return 0 ;;
      unreachable)
        TAP_TT_ROOT="$TAP_IDX_ROOT"
        TAP_TT_REGISTRY="$TAP_IDX_REGISTRY_LOCATION"
        TAP_TT_SCOPE="unreachable_team"
        TAP_TT_DETAIL="registry_location unreachable for '$TAP_TT_TEAM' ($TAP_IDX_REGISTRY_LOCATION); tap doctor"
        return 0 ;;
      historical)
        TAP_TT_ROOT="$TAP_IDX_ROOT"
        TAP_TT_REGISTRY="$TAP_IDX_REGISTRY_LOCATION"
        TAP_TT_SCOPE="historical_team"
        TAP_TT_DETAIL="team '$TAP_TT_TEAM' is historical (not delivery-addressable)"
        return 0 ;;
      invalid)
        # Pass1 #6: preserve structured invalid (do not collapse to unknown_team).
        TAP_TT_SCOPE="invalid_flip"
        TAP_TT_DETAIL="${TAP_IDX_ROOT:-global registry unreadable}"
        return 0 ;;
      *)
        TAP_TT_SCOPE="unknown_team"
        TAP_TT_DETAIL="<none>"
        return 0 ;;
    esac
  fi

  TAP_TT_ROOT="$(tap_index_resolve_root "$TAP_TT_TEAM")"
  if [ -n "$TAP_TT_ROOT" ]; then
    # Pre-flip dormancy: never select team-registry.json by file presence.
    if [ -f "$TAP_TT_ROOT/.tap/bus/registry.json" ]; then
      TAP_TT_REGISTRY="$TAP_TT_ROOT/.tap/bus/registry.json"
    else
      TAP_TT_REGISTRY="$TAP_TT_ROOT/tmp/tap/registry.json"
    fi
    TAP_TT_SCOPE="remote"; return 0
  fi

  # ONE worktree scan, shared with tap_authority_context (u1 round-1,
  # r4045876915): the scan lived twice — here as a private Python block, there
  # as tap_worktree_team_root — and could drift. The Bun slice now carries the
  # FOUND/AMBIGUOUS/MISSING/ERROR diagnostics both callers need; ERROR is
  # returned as scope=error, never collapsed into unknown_team.
  tap_worktree_team_root "$TAP_TT_TEAM" "$TAP_TT_SENDER_ROOT"
  case "$TAP_WT_STATE" in
    found)
      TAP_TT_ROOT="$TAP_WT_ROOT"
      if [ -f "$TAP_TT_ROOT/.tap/bus/registry.json" ]; then TAP_TT_REGISTRY="$TAP_TT_ROOT/.tap/bus/registry.json"
      else TAP_TT_REGISTRY="$TAP_TT_ROOT/tmp/tap/registry.json"
      fi
      TAP_TT_SCOPE="remote" ;;
    ambiguous) TAP_TT_SCOPE="ambiguous_team"; TAP_TT_DETAIL="$TAP_WT_DETAIL" ;;
    missing)   TAP_TT_SCOPE="unknown_team"; TAP_TT_DETAIL="$TAP_WT_DETAIL" ;;
    *)         TAP_TT_SCOPE="error"; TAP_TT_DETAIL="$TAP_WT_DETAIL" ;;
  esac
  return 0
}

# Read one recipient row from the exact registry selected during address
# resolution. Output is US-delimited: status, pane, pane_id, delivery,
# server_epoch, session, harness, boot_id, registered_at.
tap_registry_pane_binding() { # <registry> <handle>
  python3 -B - "$1" "$2" <<'PY'
import json, sys
try:
    data = json.load(open(sys.argv[1]))
except Exception:
    data = {}
# v0.20 team-registry uses seats; pre-flip bus registry uses agents.
agents = (data.get("seats") if isinstance(data.get("seats"), dict) else data.get("agents") or {})
ent = agents.get(sys.argv[2]) if isinstance(agents, dict) else None
if not isinstance(ent, dict):
    print("\x1f".join(["missing"] + [""] * 8))
else:
    print("\x1f".join(str(x or "") for x in (
        ent.get("status", "active"), ent.get("pane"), ent.get("pane_id"), ent.get("delivery", "pane"),
        ent.get("server_epoch"),
        ent.get("session"),
        ent.get("harness"),
        ent.get("boot_id"),
        ent.get("registered_at"),
    )))
PY
}

# Triple-check a previously bound pane identity immediately before an effect.
# `match` means registry(handle).pane/pane_id still equal the bound values and
# tmux reports that same pane_id live. Every other result is fail-closed.
tap_bound_pane_identity_state() { # <registry> <handle> <bound_pane> <bound_pane_id>
  local registry="$1" handle="$2" bound_pane="$3" bound_id="$4"
  local row status pane pane_id delivery server_epoch session harness boot_id registered_at
  local observed_record observed reason resolved_pane resolved_id observed_harness
  [ -f "$registry" ] || { printf 'registry_missing'; return 0; }
  row="$(tap_registry_pane_binding "$registry" "$handle")"
  IFS=$'\x1f' read -r status pane pane_id delivery server_epoch session harness boot_id registered_at <<< "$row"
  [ "$status" = active ] || { printf 'handle_missing_or_inactive'; return 0; }
  [ "$delivery" != poll ] || { printf 'not_pane_delivery'; return 0; }
  [ -n "$bound_pane" ] && [ "$pane" = "$bound_pane" ] || { printf 'pane_drift'; return 0; }
  [ -n "$bound_id" ] && [ -n "$pane_id" ] || { printf 'pane_id_missing'; return 0; }
  [ "$pane_id" = "$bound_id" ] || { printf 'pane_id_drift'; return 0; }
  # The point-of-effect authorizer consumes the same exact session-name,
  # designated-pane, boot, generation, and harness evidence as roster/attach.
  # A matching numeric id alone is never delivery authority: ids recycle, a
  # session can survive while its designated pane changes, and an agent pane can
  # fall back to a shell without changing either address or id.
  observed_record="$(tap_seat_observed_record "$status" "$delivery" "$pane" "$pane_id" \
    "$session" "$registered_at" "$server_epoch" "$(tap_server_epoch_now 2>/dev/null || true)" \
    "$boot_id" "$(tap_boot_id 2>/dev/null || true)" "$harness")"
  IFS=$'\x1f' read -r observed reason resolved_pane resolved_id observed_harness <<< "$observed_record"
  if [ "$observed" != active ]; then
    printf '%s' "${reason:-seat_$observed}"
    return 0
  fi
  [ "$resolved_pane" = "$bound_pane" ] || { printf 'pane_drift'; return 0; }
  [ "$resolved_id" = "$bound_id" ] || { printf 'pane_recycled'; return 0; }
  printf 'match'
}

# Rowless manual relay authority. This escape hatch deliberately does not call a
# seat ACTIVE: the operator supplied a pane outside a recipient registry. It
# proves only that one exact session name is observable and that the designated
# address/id is still a member of that session at this effect boundary. When the
# caller carries its preflight harness family, the same observation also proves
# the pane did not fall back to a shell or another agent before an effect.
tap_unbound_pane_identity_record() { # <exact-session> <pane-address> [<expected-pane-id> [<expected-harness>]]
  local session="$1" pane="$2" expected_id="${3:-}" expected_harness="${4:-}" name_record name_state epoch panes line
  local row_session address pane_id command pane_pid pane_epoch extra found_id="" found_command="" found_pid=""
  local harness_record harness_state
  [ -n "$session" ] && [ -n "$pane" ] || { printf 'identity_incomplete\x1f'; return 0; }
  case "$pane" in "$session":*) ;; *) printf 'pane_outside_session\x1f'; return 0 ;; esac
  name_record="$(tap_tmux_session_observation "$session")"
  IFS=$'\x1f' read -r name_state epoch <<< "$name_record"
  case "$name_state" in
    alive) ;;
    observed_absent) printf 'session_absent\x1f'; return 0 ;;
    *) printf 'session_unobservable\x1f'; return 0 ;;
  esac
  panes="$(tap_tmux_session_panes "$session" "$epoch")" \
    || { printf 'pane_set_unobservable\x1f'; return 0; }
  while IFS= read -r line; do
    IFS=$'\t' read -r row_session address pane_id command pane_pid pane_epoch extra <<< "$line"
    [ "$row_session" = "$session" ] && [ "$address" = "$pane" ] || continue
    found_id="$pane_id"; found_command="$command"; found_pid="$pane_pid"; break
  done <<< "$panes"
  [ -n "$found_id" ] || { printf 'designated_pane_missing\x1f'; return 0; }
  [ -z "$expected_id" ] || [ "$found_id" = "$expected_id" ] \
    || { printf 'pane_recycled\x1f%s' "$found_id"; return 0; }
  if [ -n "$expected_harness" ]; then
    harness_record="$(tap_harness_evidence "$expected_harness" "$found_command" "$found_pid")"
    IFS=$'\x1f' read -r harness_state _ <<< "$harness_record"
    case "$harness_state" in
      alive) ;;
      exited) printf 'harness_exited\x1f%s' "$found_id"; return 0 ;;
      mismatch) printf 'harness_mismatch\x1f%s' "$found_id"; return 0 ;;
      *) printf 'harness_unobservable\x1f%s' "$found_id"; return 0 ;;
    esac
  fi
  printf 'match\x1f%s' "$found_id"
}

# Optional submit-time identity guard. An empty <registry> and empty
# <rowless-session> means no guard; a rowless session arms the narrower manual
# relay check. Effectful rowless callers such as `tap command` must carry the
# exact session name their preflight observed so this arm cannot disable itself.
tap_submit_identity_guard() { # <registry> <handle> <pane> <pane_id> [<rowless-session> [<rowless-harness>]]
  local registry="$1" handle="$2" pane="$3" pane_id="$4"
  local rowless_session="${5:-}" rowless_harness="${6:-}" state record
  TAP_SUBMIT_HARNESS_ALIVE=0
  TAP_SUBMIT_PERMISSIONS=bypass
  if [ -z "$registry" ]; then
    [ -n "$rowless_session" ] || return 0
    [ -n "$pane_id" ] || { echo "tap: incomplete rowless pane identity before pane effect" >&2; return 6; }
    record="$(tap_unbound_pane_identity_record "$rowless_session" "$pane" "$pane_id" "$rowless_harness")"
    state="${record%%$'\x1f'*}"
    if [ "$state" = match ]; then
      [ -z "$rowless_harness" ] || TAP_SUBMIT_HARNESS_ALIVE=1
      return 0
    fi
    echo "tap: rowless pane identity drifted before pane effect ($state)" >&2
    return 6
  fi
  if [ -z "$handle" ] || [ -z "$pane_id" ]; then
    echo "tap: incomplete bound recipient identity before pane effect" >&2
    return 6
  fi
  state="$(tap_bound_pane_identity_state "$registry" "$handle" "$pane" "$pane_id")"
  if [ "$state" = match ]; then
    TAP_SUBMIT_PERMISSIONS="$(tap_recorded_permissions "$registry" "$handle")" || return 6
    [ "$TAP_SUBMIT_PERMISSIONS" != unknown ] || return 6
    TAP_SUBMIT_HARNESS_ALIVE=1; return 0
  fi
  echo "tap: bound recipient identity drifted before pane effect ($state)" >&2
  return 6
}

# tap_seat_deliverable <handle|team/handle> -> 0 iff the target names a seat
# that can receive a reply RIGHT NOW: an active pane-backed member (status
# active, delivery!=poll, non-empty pane) OR an active delivery:poll member —
# the SAME bar tap_registry_dischargeable enforces for --from, extended to
# work against any resolved team's registry (local or remote), not just
# $TAP_REGISTRY. reply_to needs this exact bar, not mere existence: PR #xx
# panel MUST-FIX 1 — an existence-only check let send-time --reply-to accept
# a pending/suspended seat, which then ROUTED at reply time only to have
# delivery itself refuse (seat_pending/suspended) with no fallback, leaving
# the inbound unsettled. 1 for an unknown/unresolvable team, an absent
# handle, or a present-but-undeliverable one (pending/suspended/no pane).
# Dies only on a malformed address (tap_resolve_team_target's own contract —
# reused here as the one source of truth for <team>/<handle> splitting,
# shared with tap send's TO resolution so the two can't drift).
# Sets TAP_SD_TEAM / TAP_SD_HANDLE / TAP_SD_SCOPE / TAP_SD_DETAIL on return —
# callers (tap send/register's --reply-to validation, tap reply's reply-time
# re-check) use TAP_SD_SCOPE/TEAM/HANDLE to build their own error voice.
tap_seat_deliverable() {
  local target="$1" registry handle route
  tap_resolve_team_target "$target"
  TAP_SD_TEAM="$TAP_TT_TEAM"; TAP_SD_HANDLE="$TAP_TT_HANDLE"
  TAP_SD_SCOPE="$TAP_TT_SCOPE"; TAP_SD_DETAIL="$TAP_TT_DETAIL"
  case "$TAP_SD_SCOPE" in
    unknown_team|ambiguous_team|error) return 1 ;;
    remote|local) registry="$TAP_TT_REGISTRY" ;;
  esac
  if [ ! -f "$registry" ]; then
    TAP_SD_DETAIL="no registry at team '$TAP_SD_TEAM' root"
    return 1
  fi
  handle="$TAP_SD_HANDLE"
  if tap_v20_obligation_live; then
    route="$(tap_bun_call forwarding "$handle" forwarding.ts route "$registry" "$handle")" || return 1
    handle="$(printf '%s' "$route" | python3 -B -c 'import json,sys; print(json.load(sys.stdin)["target"])')" || return 1
    tap_valid_token "$handle" || return 1
  fi
  python3 -B - "$registry" "$handle" "${_TAP_SCRIPT_DIR}" <<'PY'
import sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import _seat_map, load_state_doc
try:
    reg = load_state_doc(sys.argv[1])
except Exception:
    sys.exit(1)
ent = _seat_map(reg).get(sys.argv[2])
if not isinstance(ent, dict):
    sys.exit(1)
if ent.get("status", "active") != "active":
    sys.exit(1)
if ent.get("status_reason") == "launching":
    sys.exit(1)
if ent.get("delivery") == "poll":
    sys.exit(0)
sys.exit(0 if ent.get("pane") else 1)
PY
}

# tap_resolve_self_handle [<pane-target>]
# Resolve the current (or given) tmux pane to its REGISTERED handle by pane_id.
# Observational identity: an agent auto-suffixed at register (claude → claude-2)
# learns its REAL handle instead of impersonating the incumbent — the ONE lookup
# whoami/unregister/send/done/reply share (KTD3), so --from/--by can't drift from
# what whoami reports. Echoes the handle on success and sets globals
# TAP_SELF_HANDLE / TAP_SELF_TEAM / TAP_SELF_PANE / TAP_SELF_PANE_ID for callers
# that need the richer identity (whoami --verbose). Legacy {pane}-only rows resolve
# by pane target when they carry no pane_id (back-compat).
# Exit: 0 resolved | 1 no pane / not inside tmux / pane gone | 2 pane not registered.
tap_resolve_self_handle() {
  local pane="${1:-}" observed_id out now_epoch
  TAP_SELF_HANDLE=""; TAP_SELF_TEAM=""; TAP_SELF_PANE=""; TAP_SELF_PANE_ID=""
  # tap-6lai: additive refusal channel. Exit 2 alone cannot distinguish "this
  # pane is not registered" from "this pane's registration cannot be VERIFIED
  # right now", and those need opposite remedies. Additive on purpose: every
  # existing caller that ignores it is unaffected, and no exit code moved.
  TAP_SELF_REFUSAL=""
  if [ -z "$pane" ]; then
    # tap-316wj: the no-arg path takes pane id, TTY, session, and generation
    # from ONE tap_calling_pane_observe record. Splitting tap_calling_pane_id
    # then tap_pane_observe let a server rebirth recycle the numeric id onto a
    # different TTY between the two probes; the second record was internally
    # current but no longer the caller's.
    # Same-shell observe so TAP_CALLING_PANE_REFUSAL survives; a command
    # substitution would drop it and whoami would mis-class a missing pane as
    # unregistered (tap-316wj).
    local calling_obs rest
    _TAP_RESOLVE_CALLING_OBS=""
    if ! tap_calling_pane_observe _TAP_RESOLVE_CALLING_OBS; then
      unset _TAP_RESOLVE_CALLING_OBS
      return 1
    fi
    calling_obs="$_TAP_RESOLVE_CALLING_OBS"
    unset _TAP_RESOLVE_CALLING_OBS
    observed_id="${calling_obs%%$'\t'*}"
    rest="${calling_obs#*$'\t'}"
    rest="${rest#*$'\t'}"
    now_epoch="${rest#*$'\t'}"
    pane="$observed_id"
    # The former second probe (tap_pane_observe) refused a malformed pane id
    # via tap_is_pane_id before the registry lookup. The one-record path must
    # not skip that: a damaged row whose pane_id equals a garbled observation
    # would otherwise resolve as SELF (tap-316wj / #xxx T2).
    if ! tap_is_pane_id "$observed_id"; then
      TAP_CALLING_PANE_REFUSAL="malformed pane id"
      return 1
    fi
  else
    # tap-6lai: ONE observation for both facts. Taking the identity and the
    # generation as two probes let a server rebirth land between them, so this
    # lookup could match rows against a generation the id was never observed
    # under. tap_pane_observe answers pane id, session and generation from a
    # single display-message, so they always describe the same world.
    local observed rest observe_rc=0
    observed="$(tap_pane_observe "$pane")" || observe_rc=$?
    if [ "$observe_rc" -ne 0 ]; then
      [ "$observe_rc" -eq 2 ] || return 1
      # A malformed atomic record cannot establish either pane identity or the
      # generation it belongs to. Preserve the unobservable class so in-process
      # caller gates refuse instead of taking a gone-pane fallback.
      TAP_SELF_REFUSAL=generation_unverifiable
      return 2
    fi
    observed_id="${observed%%$'\t'*}"
    rest="${observed#*$'\t'}"
    now_epoch="${rest#*$'\t'}"
  fi
  TAP_SELF_PANE_ID="$observed_id"
  TAP_SELF_PANE="$pane"
  # tap-6lai: an UNKNOWN generation resolves NOTHING — stamped and unstamped
  # alike. Skipping only stamped rows was tried and is WRONG: with the
  # generation unknown you cannot tell "this stamped row is mine and current"
  # from "this stamped row is stale", so skipping them removes the CORRECT row
  # too and hands the match to whatever unstamped row collides on this pane id.
  # That turns the unstamped forge from sort-dependent into RELIABLE, on
  # exactly the migrated seats the skip was meant to protect.
  #
  # This does NOT decide whether an unstamped row may confer identity at all —
  # that is tap-zk1w and it stays open. Behavior changes ONLY inside the
  # unknown-generation window; whenever the generation is observable, which on
  # real tmux is always, unstamped rows resolve exactly as they do today.
  if [ -z "$now_epoch" ]; then
    TAP_SELF_REFUSAL=generation_unverifiable
    return 2
  fi
  # Post-flip: ambient $TAP_REGISTRY names the retired bus path. Rebind before
  # the existence check so seats-first parsing runs against team-registry.json
  # (chatgpt-codex P1 @ lib.sh:3550 — class sweep via tap_require_acting_registry).
  tap_require_acting_registry || return 2
  out="$(TAP_RESOLVE_SERVER_EPOCH="$now_epoch" \
    TAP_RESOLVE_SELECTED_HANDLE="${TAP_CALLER_SELECTED_HANDLE:-}" \
    TAP_RESOLVE_SELECTED_INSTANCE="${TAP_CALLER_SELECTED_INSTANCE:-}" \
    python3 -B - "$TAP_REGISTRY" "$observed_id" "$pane" "${_TAP_SCRIPT_DIR}" <<'PY'
import json, os, sys
path, pane_id, pane, scripts = sys.argv[1:5]
sys.path.insert(0, scripts)
from registry_v20 import _seat_map
now_epoch = os.environ.get("TAP_RESOLVE_SERVER_EPOCH", "")
selected_handle = os.environ.get("TAP_RESOLVE_SELECTED_HANDLE", "")
selected_instance = os.environ.get("TAP_RESOLVE_SELECTED_INSTANCE", "")
try:
    reg = json.load(open(path))
except Exception:
    sys.exit(2)
team = (reg.get("team") or {}).get("name", "")
# seats-first (tap-vpwp / sol P1 #2) — bare agents misses post-flip seats-only rows
for handle, ent in sorted(_seat_map(reg).items()):
    if selected_handle and handle != selected_handle:
        continue
    if not isinstance(ent, dict):
        continue
    if ent.get("status", "active") != "active":
        continue
    if selected_instance and ent.get("instance") != selected_instance:
        continue
    # tap-24f: a row stamped under a PRIOR server generation records ids from a
    # retired server — its pane_id equaling the CALLER's live id is recycling
    # coincidence, never identity. Skipping it prevents a stale row from
    # misattributing this caller's handle (whoami/send/reply all ride here).
    #
    # tap-6lai: the original predicate required BOTH generations known, so when
    # the current one was unobservable it skipped nothing and a stale row could
    # be returned as SELF — a forged `from=` on the bus, invisible downstream.
    # That window is now refused in the caller before this loop ever runs, so
    # now_epoch is guaranteed non-empty here and a STAMPED row simply has to
    # match it. NO ROW WHOSE GENERATION CLAIM WE CANNOT VERIFY MAY CONFER
    # IDENTITY. The cost is a seat that cannot name itself while the generation
    # is unobservable — chosen deliberately, because a mute seat is loud,
    # immediate and fixable, whereas a forged author is silent, corrupting, and
    # invisible to every downstream reader.
    row_epoch = ent.get("server_epoch") or ""
    if row_epoch and row_epoch != now_epoch:
        continue
    if ent.get("pane_id") == pane_id or (not ent.get("pane_id") and ent.get("pane") == pane):
        print(handle); print(team); print(ent.get("pane", pane)); print(pane_id)
        sys.exit(0)
sys.exit(2)
PY
)" || return 2
  TAP_SELF_HANDLE="$(printf '%s\n' "$out" | sed -n '1p')"
  TAP_SELF_TEAM="$(printf '%s\n' "$out" | sed -n '2p')"
  TAP_SELF_PANE="$(printf '%s\n' "$out" | sed -n '3p')"
  TAP_SELF_PANE_ID="$(printf '%s\n' "$out" | sed -n '4p')"
  [ -n "$TAP_SELF_HANDLE" ] || return 2
  printf '%s' "$TAP_SELF_HANDLE"
}

# tap_resolve_self_handle_into <output-var> [<pane-target>]
# In-process output form for callers that must distinguish an unregistered pane
# from TAP_SELF_REFUSAL=generation_unverifiable. `$(tap_resolve_self_handle)`
# loses that refusal channel with its subshell; state-changing callers must not
# let the lost reason route them onto a weaker fallback.
tap_resolve_self_handle_into() {
  local output_var="$1" pane="${2:-}" resolve_rc=0
  printf -v "$output_var" '%s' ""
  tap_resolve_self_handle "$pane" >/dev/null 2>&1 || resolve_rc=$?
  if [ "$resolve_rc" -eq 0 ]; then
    printf -v "$output_var" '%s' "$TAP_SELF_HANDLE"
  fi
  return "$resolve_rc"
}

# tap_warn_overdue_inbound [<threshold-seconds>]
# Best-effort dispatcher reflex for an active registered seat. It is advisory
# only: one stderr line, no state writes, and no effect on the invoked verb's
# stdout or exit status. ponytail: O(all payload names), but opens only unsettled
# candidates; add an index only if real bus size makes this reflex measurable.
# Eligibility shared by Bash poll and its aged-inbound advisory. Call after
# envelope validation: this predicate never quarantines or changes state.
tap_poll_obligation_visible() { # <id> <to> <to-team> <recipient-instance> <actor> <local-team>
  local id="$1" to="$2" to_team="$3" recipient_instance="$4" actor="$5" local_team="$6"
  local ID="$id" FROM="" LOCAL_TEAM="$local_team"
  tap_is_done "$id" && return 1
  tap_target_team_is_local "$to_team" "$local_team" || return 1
  tap_addressee_grant_check "$actor" "$to" "${7:-}" "$recipient_instance" --quiet
}

tap_warn_overdue_inbound() (
  local threshold="${1:-3600}" handle="" local_team="" now payload id to_team age count=0 oldest=0
  [ -d "$TAP_PAYLOADS" ] && [ -d "$TAP_RECEIPTS" ] || return 0
  tap_require_acting_registry || return 0

  if tap_resolve_self_handle >/dev/null 2>&1; then
    handle="$TAP_SELF_HANDLE"
  elif [ -n "${TAP_SELF:-}" ] && tap_registry_dischargeable "$TAP_SELF"; then
    handle="$TAP_SELF"
  else
    return 0
  fi
  local_team="$(tap_spool_team_name)"

  now="$(date +%s)"
  while IFS=$'\t' read -r id payload; do
    [ -n "$id" ] && [ -n "$payload" ] || continue
    tap_is_done "$id" && continue
    tap_validate_envelope "$payload" >/dev/null 2>&1 || continue
    [ "$(tap_envelope_field "$payload" id || true)" = "$id" ] || continue
    tap_poll_obligation_visible "$id" "$(tap_envelope_field "$payload" to || true)" \
      "$(tap_envelope_field "$payload" to_team || true)" \
      "$(tap_envelope_field "$payload" recipient_instance || true)" "$handle" "$local_team" || continue
    # Keep stderr open so a future-stamped id warning is visible (tap-56ig).
    age="$(tap_id_age_seconds "$id" "$now")" || continue
    [ "$age" -ge "$threshold" ] || continue
    count=$((count + 1))
    [ "$age" -le "$oldest" ] || oldest="$age"
  done < <(python3 -B "$_TAP_SCRIPT_DIR/tap_frontmatter.py" pending-to \
    "$TAP_PAYLOADS" "$TAP_RECEIPTS" "$handle" "$local_team" 2>/dev/null)

  [ "$count" -gt 0 ] || return 0
  printf "tap: warning: %s has %s unsettled inbound aged >=%ss (oldest %ss); run 'tap poll %s'\n" \
    "$handle" "$count" "$threshold" "$oldest" "$handle" >&2
)

# Resolve the tmux pane that owns the calling process without trusting
# TMUX_PANE. That environment variable is ordinary caller-controlled state and
# tmux itself honors an overridden value for untargeted commands. Walk upward
# until the real process ancestry exposes a controlling TTY, then map that TTY
# back to tmux's stable pane_id. Ambiguous, detached, or unobservable callers
# fail closed; destructive command mode is intentionally pane-local. With an
# optional output-variable name, the caller can keep this function in the
# current shell and read TAP_CALLING_PANE_REFUSAL plus TAP_CALLING_PANE_STATE.
# The state is inside, outside (a terminal was positively observed but belongs
# to no pane on this server), or unobservable. The function returns zero only
# for inside; consumers decide whether a positive outside state is actionable.
tap_calling_pane_fail() {
  TAP_CALLING_PANE_REFUSAL="$1"
  TAP_CALLING_PANE_STATE="${2:-unobservable}"
  return 1
}

# tap_calling_pane_observe
#   -> "<pane_id>\t<pane_tty>\t<session_name>\t<generation>" for the caller's
#      controlling TTY. The final binding and identity facts are one targeted
#      tmux observation; the generation field may be empty.
# The output-variable form is internal and reserved to tap_calling_pane_id:
#   tap_calling_pane_observe _TAP_CALLING_PANE_ID_VALUE pane-id
# Other callers consume stdout; arbitrary output-variable names belong to the
# tap_calling_pane_id compatibility API, whose local-free frame assigns them.
tap_calling_pane_observe() {
  local output_var="${1:-}" result="${2:-observation}" pid="${BASHPID:-$$}" row ppid tty="" pane_tty panes_raw candidate candidate_tty found="" observed observed_id observed_tty observed_session observed_raw_epoch observed_epoch rest record steps=0
  local pane_format=$'#{pane_id}\t#{pane_tty}'
  local observation_format=$'#{pane_id}\t#{pane_tty}\t#{session_name}\t#{pid}:#{start_time}'
  local -a tmux_observer=(tmux)
  if [ -n "${TAP_CALLING_PANE_SOCKET:-}" ]; then
    tmux_observer=(python3 -B "$_TAP_SCRIPT_DIR/tmux_deadline.py" -S "$TAP_CALLING_PANE_SOCKET")
  fi
  [ "$result" = observation ] || observation_format="$pane_format"
  TAP_CALLING_PANE_REFUSAL=""
  TAP_CALLING_PANE_STATE="unobservable"
  [ -z "$output_var" ] || printf -v "$output_var" '%s' ""
  while [ "$steps" -lt 64 ]; do
    row="$(ps -o ppid= -o tty= -p "$pid" 2>/dev/null || true)"
    [ -n "$row" ] || {
      tap_calling_pane_fail "process observation unavailable for pid '$pid'"
      return 1
    }
    read -r ppid tty _ <<< "$row"
    case "$tty" in
      ""|"?"|"??"|"-") ;;
      *)
        case "$tty" in /dev/*) pane_tty="$tty" ;; *) pane_tty="/dev/$tty" ;; esac
        found=""
        if ! panes_raw="$("${tmux_observer[@]}" list-panes -a -F "$pane_format" 2>/dev/null)"; then
          tap_calling_pane_fail "tmux could not list panes: usually no tmux server is running, or you are outside tmux"
          return 1
        fi
        while IFS=$'\t' read -r candidate candidate_tty; do
          [ "$candidate_tty" = "$pane_tty" ] || continue
          [ -z "$found" ] || {
            tap_calling_pane_fail "controlling tty '$pane_tty' maps to multiple panes"
            return 1
          }
          found="$candidate"
        done <<< "$panes_raw"
        if [ -n "$found" ]; then
          # RE-ASSERT THE TTY BINDING, not merely that the id is live (tap-bzyz).
          # The scan above established a BINDING: this tty -> $found. Checking
          # `#{pane_id}` alone is VACUOUSLY TRUE for any live id — it answers "does
          # a pane with this id exist", never "does the pane that owns my tty still
          # exist" — so a server replacement that RECYCLES the numeric id passes it
          # trivially and this function hands a stranger's pane to every caller,
          # `tap_resolve_self_handle` among them.
          #
          # Do not "simplify" this back to a pane_id check: the tautological form
          # looks correct and is the defect. Both fields come from ONE
          # display-message, in the same format the scan uses, so the two facts are
          # consistent by construction rather than by timing.
          observed="$("${tmux_observer[@]}" display-message -p -t "$found" "$observation_format" 2>/dev/null || true)"
          observed="${observed%%$'\n'*}"
          observed_id="${observed%%$'\t'*}"
          rest="${observed#*$'\t'}"
          observed_tty="${rest%%$'\t'*}"
          if [ "$observed_id" != "$found" ] || [ "$observed_tty" != "$pane_tty" ]; then
            tap_calling_pane_fail "pane '$found' no longer owns controlling tty '$pane_tty'"
            return 1
          fi
          if [ "$result" = observation ]; then
            # Exact four-field arity. A missing delimiter shifts generation
            # into the session slot; the field is non-empty so the empty-session
            # check passes, and a matching current-generation row resolves as
            # SELF (tap-316wj / #xxx). Not "at least four" — a five-field
            # response is equally not the record the contract describes.
            local _obs_tabs="${observed//[!$'\t']/}"
            if [ "$((${#_obs_tabs} + 1))" -ne 4 ]; then
              tap_calling_pane_fail "observation is not a four-field record"
              return 1
            fi
            rest="${rest#*$'\t'}"
            observed_session="${rest%%$'\t'*}"
            observed_raw_epoch="${rest#*$'\t'}"
            # Four-field discriminator is pane_id + pane_tty + session_name
            # together. An empty session_name still yields four tab-fields, so
            # arity cannot catch it — refuse explicitly (tap-316wj / #xxx T8).
            if [ -z "$observed_session" ]; then
              tap_calling_pane_fail "observation is missing a session name"
              return 1
            fi
            observed_epoch="$(tap_server_epoch_from_raw "$observed_raw_epoch" 2>/dev/null || true)"
            record="$(printf '%s\t%s\t%s\t%s' \
              "$observed_id" "$observed_tty" "$observed_session" "$observed_epoch")"
          else
            record="$observed_id"
          fi
          if [ -n "$output_var" ]; then
            printf -v "$output_var" '%s' "$record"
          else
            printf '%s' "$record"
          fi
          TAP_CALLING_PANE_STATE="inside"
          return 0
        fi
        # This is the first observable controlling terminal in the caller's
        # ancestry, so it is the terminal whose identity we are classifying.
        # Do not climb past it and borrow a tmux pane from an ancestor after a
        # child has acquired its own PTY.
        tap_calling_pane_fail "observed caller terminal is not owned by a pane on this tmux server" outside
        return 1
        ;;
    esac
    case "$ppid" in
      ""|*[!0-9]*)
        tap_calling_pane_fail "process observation returned invalid parent pid '$ppid'"
        return 1
        ;;
    esac
    if [ "$ppid" -le 1 ] || [ "$ppid" = "$pid" ]; then
      tap_calling_pane_fail "process ancestry ended before finding a tmux pane (pid '$pid', parent '$ppid')"
      return 1
    fi
    pid="$ppid"
    steps=$((steps + 1))
  done
  tap_calling_pane_fail "process ancestry exceeded 64 steps before finding a tmux pane"
  return 1
}

# Claude Code 2.1.257 may run tool shells from a reparented ClaudeCode.app
# process: the shell has no TMUX/TMUX_PANE, its ancestry never reaches tmux's
# pane_pid, and Claude's controlling tty is not the pane tty. An ordinary tool
# can join by exact harness session id. A `bg` daemon has its OWN session id;
# its job state instead names the originating `<team>/<handle>`. Validate that
# record's session, name, and cwd before it may select a row, then re-observe the
# row's pane identity. Duplicate ids and malformed job records refuse.
tap_harness_session_pane_observe() { # [output-var] [allow-launching=0]
  local output_var="${1:-}" allow_launching="${2:-0}" session_id="${TAP_HARNESS_SESSION_ID:-${CLAUDE_CODE_SESSION_ID:-}}"
  local candidate pane expected_id expected_session expected_epoch raw observed_id observed_tty observed_session raw_epoch observed_epoch rest record tabs
  local acting_team acting_root selected_handle selected_instance expected_socket expected_instance observed_socket
  [ -z "$output_var" ] || printf -v "$output_var" '%s' ""
  [ -n "$session_id" ] || return 1
  tap_require_acting_registry >/dev/null 2>&1 || return 1
  acting_team="$(tap_spool_team_name 2>/dev/null || true)"
  acting_root="$(tap_team_dir_from_bus 2>/dev/null || true)"
  [ -n "$acting_team" ] && [ -n "$acting_root" ] || return 1
  candidate="$(TAP_CALLER_HSID="$session_id" TAP_CALLER_ALLOW_LAUNCHING="$allow_launching" \
    TAP_CALLER_ACTING_TEAM="$acting_team" TAP_CALLER_ACTING_ROOT="$acting_root" \
    python3 -B - "$TAP_REGISTRY" "${_TAP_SCRIPT_DIR}" <<'PY'
import datetime, json, os, sys
sys.path.insert(0, sys.argv[2])
from registry_v20 import _seat_map, load_state_doc
try:
    doc = load_state_doc(sys.argv[1])
    seats = _seat_map(doc)
except Exception:
    raise SystemExit(1)
sid = os.environ.get("TAP_CALLER_HSID", "")
allow_launching = os.environ.get("TAP_CALLER_ALLOW_LAUNCHING", "0") == "1"
matches = []

def eligible(row):
    if not isinstance(row, dict):
        return False
    if row.get("status", "active") != "active" or row.get("delivery", "pane") == "poll":
        return False
    if not allow_launching and row.get("status_reason") == "launching":
        return False
    return row.get("harness") == "claude"

def job_owns_instance(row, handle, created_at, team_root):
    instance = row.get("instance") if isinstance(row, dict) else ""
    if not isinstance(instance, str) or not instance or not isinstance(created_at, str):
        return False
    try:
        created = datetime.datetime.fromisoformat(created_at.replace("Z", "+00:00")).timestamp()
        latest = float("-inf")
        owner = ""
        path = os.path.join(team_root, ".tap", "team-history", handle + ".lineage.jsonl")
        for line in open(path):
            record = json.loads(line)
            raw_stamp = record.get("ts", "")
            stamp = datetime.datetime.fromisoformat(raw_stamp.replace("Z", "+00:00")).timestamp()
            # Whole-second legacy records in the job creation second cannot
            # order the job against a same-second successor; refuse ambiguity.
            if "." not in raw_stamp and int(stamp) == int(created):
                return False
            if stamp <= created and stamp >= latest and isinstance(record.get("instance"), str):
                latest, owner = stamp, record["instance"]
        return owner == instance
    except Exception:
        return False

if os.environ.get("CLAUDE_JOB_DIR"):
    try:
        state = json.load(open(os.path.join(os.environ["CLAUDE_JOB_DIR"], "state.json")))
        team_name = os.environ.get("TAP_CALLER_ACTING_TEAM", "")
        team_root = os.environ.get("TAP_CALLER_ACTING_ROOT", "")
        name = state.get("name")
        cwd = state.get("cwd")
        prefix = team_name + "/" if isinstance(team_name, str) and team_name else ""
        if not (
            state.get("template") == "bg" and state.get("sessionId") == sid and prefix
            and isinstance(name, str) and name.startswith(prefix)
            and name[len(prefix):] and "/" not in name[len(prefix):]
            and isinstance(cwd, str) and isinstance(team_root, str)
            and os.path.realpath(cwd) == os.path.realpath(team_root)
        ):
            raise ValueError("background job identity mismatch")
        row = seats.get(name[len(prefix):])
        if eligible(row) and job_owns_instance(row, name[len(prefix):], state.get("createdAt"), team_root):
            matches.append((name[len(prefix):], row))
    except Exception:
        pass
else:
    for handle, row in seats.items():
        if eligible(row) and row.get("harness_session_id") == sid:
            matches.append((handle, row))
if len(matches) != 1:
    raise SystemExit(2)
handle, row = matches[0]
fields = [handle, row.get("pane"), row.get("pane_id"), row.get("session"), row.get("server_epoch"), row.get("server_socket") or ""]
if not all(isinstance(v, str) and v and "\n" not in v and "\r" not in v for v in fields[:5]):
    raise SystemExit(3)
if fields[-1] and not fields[-1].startswith("/"):
    raise SystemExit(3)
instance = row.get("instance") if os.environ.get("CLAUDE_JOB_DIR") else ""
if instance and (not isinstance(instance, str) or "\n" in instance or "\r" in instance):
    raise SystemExit(3)
print("\n".join(fields + [instance]))
PY
)" || {
    TAP_CALLING_PANE_REFUSAL="Claude caller context does not identify exactly one active pane on this team"
    TAP_CALLING_PANE_STATE="unobservable"
    return 1
  }
  selected_handle="$(printf '%s\n' "$candidate" | sed -n '1p')"
  pane="$(printf '%s\n' "$candidate" | sed -n '2p')"
  expected_id="$(printf '%s\n' "$candidate" | sed -n '3p')"
  expected_session="$(printf '%s\n' "$candidate" | sed -n '4p')"
  expected_epoch="$(printf '%s\n' "$candidate" | sed -n '5p')"
  expected_socket="$(printf '%s\n' "$candidate" | sed -n '6p')"
  expected_instance="$(printf '%s\n' "$candidate" | sed -n '7p')"
  tap_is_pane_id "$expected_id" || {
    TAP_CALLING_PANE_REFUSAL="Claude harness session row carries a malformed pane id"
    TAP_CALLING_PANE_STATE="unobservable"
    return 1
  }
  if [ -n "$expected_socket" ]; then
    raw="$(tmux -S "$expected_socket" display-message -p -t "$pane" \
      $'#{pane_id}\t#{pane_tty}\t#{session_name}\t#{pid}:#{start_time}\t#{socket_path}' 2>/dev/null || true)"
  else
    raw="$(tmux display-message -p -t "$pane" \
      $'#{pane_id}\t#{pane_tty}\t#{session_name}\t#{pid}:#{start_time}' 2>/dev/null || true)"
  fi
  raw="${raw%%$'\n'*}"
  tabs="${raw//[!$'\t']/}"
  expected_fields=4
  [ -z "$expected_socket" ] || expected_fields=5
  if [ "$((${#tabs} + 1))" -ne "$expected_fields" ]; then
    TAP_CALLING_PANE_REFUSAL="Claude harness session pane observation has the wrong field count"
    TAP_CALLING_PANE_STATE="unobservable"
    return 1
  fi
  observed_id="${raw%%$'\t'*}"; rest="${raw#*$'\t'}"
  observed_tty="${rest%%$'\t'*}"; rest="${rest#*$'\t'}"
  observed_session="${rest%%$'\t'*}"; rest="${rest#*$'\t'}"
  if [ -n "$expected_socket" ]; then
    raw_epoch="${rest%%$'\t'*}"; observed_socket="${rest#*$'\t'}"
  else
    raw_epoch="$rest"; observed_socket=""
  fi
  observed_epoch="$(tap_server_epoch_from_raw "$raw_epoch" 2>/dev/null || true)"
  mismatch=0
  [ -z "$expected_session" ] || [ "$observed_session" = "$expected_session" ] || mismatch=1
  [ -z "$expected_epoch" ] || [ "$observed_epoch" = "$expected_epoch" ] || mismatch=1
  [ -z "$expected_socket" ] || [ "$observed_socket" = "$expected_socket" ] || mismatch=1
  if [ "$observed_id" != "$expected_id" ] || [ -z "$observed_session" ] \
      || [ -z "$observed_epoch" ] || [ "$mismatch" = 1 ]; then
    TAP_CALLING_PANE_REFUSAL="Claude harness session row no longer matches its live pane identity"
    TAP_CALLING_PANE_STATE="unobservable"
    return 1
  fi
  record="$(printf '%s\t%s\t%s\t%s\t%s\t%s' "$observed_id" "$observed_tty" "$observed_session" "$observed_epoch" "$selected_handle" "$expected_instance")"
  TAP_CALLER_SELECTED_HANDLE="$selected_handle"
  TAP_CALLER_SELECTED_INSTANCE="$expected_instance"
  TAP_CALLER_SELECTED_PANE="$pane"
  TAP_CALLER_SELECTED_PANE_ID="$expected_id"
  TAP_CALLER_SELECTED_SESSION="$expected_session"
  TAP_CALLER_SELECTED_SOCKET="$expected_socket"
  TAP_CALLER_SELECTED_EPOCH="$expected_epoch"
  if [ -n "${CLAUDE_JOB_DIR:-}" ]; then TAP_CALLER_SELECTED_JOB=1; else TAP_CALLER_SELECTED_JOB=0; fi
  if [ -n "$output_var" ]; then printf -v "$output_var" '%s' "$record"; else printf '%s' "$record"; fi
  TAP_CALLING_PANE_STATE="inside"
  TAP_CALLING_PANE_REFUSAL=""
  return 0
}

# Identity-aware caller observation for the commands whose job is to name or
# rebind this seat. Keep the process/TTY observer pure for attach and other
# callers whose positive outside verdict has separate authority semantics.
tap_caller_pane_observe() { # [output-var] [allow-launching=0]
  local output_var="${1:-}" allow_launching="${2:-0}" _tap_caller_record="" _tap_process_refusal="" _tap_process_state=""
  local _tap_job_record="" _tap_selected_handle="" _tap_selected_instance="" _tap_selected_pane="" _tap_selected_pane_id="" _tap_selected_session="" _tap_selected_socket="" _tap_selected_epoch=""
  TAP_CALLER_SELECTED_HANDLE=""
  TAP_CALLER_SELECTED_INSTANCE=""
  TAP_CALLER_SELECTED_PANE=""
  TAP_CALLER_SELECTED_PANE_ID=""
  TAP_CALLER_SELECTED_SESSION=""
  TAP_CALLER_SELECTED_SOCKET=""
  TAP_CALLER_SELECTED_EPOCH=""
  TAP_CALLER_SELECTED_JOB=0
  [ -z "$output_var" ] || printf -v "$output_var" '%s' ""
  if tap_calling_pane_observe _tap_caller_record; then
    if [ -n "$output_var" ]; then printf -v "$output_var" '%s' "$_tap_caller_record"; else printf '%s' "$_tap_caller_record"; fi
    return 0
  fi
  _tap_process_refusal="${TAP_CALLING_PANE_REFUSAL:-}"
  _tap_process_state="${TAP_CALLING_PANE_STATE:-unobservable}"
  if [ "$_tap_process_state" != outside ]; then
    # A detached Claude background shell may have no ambient/default tmux
    # server even though its validated owner lives on a recorded private
    # socket. Select and verify that row first, then establish the positive
    # outside verdict against THAT server before accepting the fallback.
    if [ -n "${CLAUDE_JOB_DIR:-}" ] && tap_harness_session_pane_observe _tap_job_record "$allow_launching"; then
      _tap_selected_handle="$TAP_CALLER_SELECTED_HANDLE"
      _tap_selected_instance="$TAP_CALLER_SELECTED_INSTANCE"
      _tap_selected_pane="$TAP_CALLER_SELECTED_PANE"
      _tap_selected_pane_id="$TAP_CALLER_SELECTED_PANE_ID"
      _tap_selected_session="$TAP_CALLER_SELECTED_SESSION"
      _tap_selected_socket="$TAP_CALLER_SELECTED_SOCKET"
      _tap_selected_epoch="$TAP_CALLER_SELECTED_EPOCH"
      if [ -n "$_tap_selected_socket" ]; then
        if TAP_CALLING_PANE_SOCKET="$_tap_selected_socket" tap_calling_pane_observe _tap_caller_record; then
          TAP_CALLER_SELECTED_HANDLE="" TAP_CALLER_SELECTED_INSTANCE=""
          TAP_CALLER_SELECTED_PANE="" TAP_CALLER_SELECTED_PANE_ID="" TAP_CALLER_SELECTED_SESSION=""
          TAP_CALLER_SELECTED_SOCKET="" TAP_CALLER_SELECTED_EPOCH="" TAP_CALLER_SELECTED_JOB=0
          if [ -n "$output_var" ]; then printf -v "$output_var" '%s' "$_tap_caller_record"; else printf '%s' "$_tap_caller_record"; fi
          return 0
        fi
        if [ "${TAP_CALLING_PANE_STATE:-unobservable}" = outside ]; then
          TAP_CALLER_SELECTED_HANDLE="$_tap_selected_handle"
          TAP_CALLER_SELECTED_INSTANCE="$_tap_selected_instance"
          TAP_CALLER_SELECTED_PANE="$_tap_selected_pane"
          TAP_CALLER_SELECTED_PANE_ID="$_tap_selected_pane_id"
          TAP_CALLER_SELECTED_SESSION="$_tap_selected_session"
          TAP_CALLER_SELECTED_SOCKET="$_tap_selected_socket"
          TAP_CALLER_SELECTED_EPOCH="$_tap_selected_epoch"
          TAP_CALLER_SELECTED_JOB=1
          if [ -n "$output_var" ]; then printf -v "$output_var" '%s' "$_tap_job_record"; else printf '%s' "$_tap_job_record"; fi
          TAP_CALLING_PANE_STATE=inside
          TAP_CALLING_PANE_REFUSAL=""
          return 0
        fi
      fi
    fi
    TAP_CALLING_PANE_REFUSAL="$_tap_process_refusal"
    TAP_CALLING_PANE_STATE="$_tap_process_state"
    return 1
  fi
  if tap_harness_session_pane_observe _tap_caller_record "$allow_launching"; then
    if [ -n "$output_var" ]; then printf -v "$output_var" '%s' "$_tap_caller_record"; else printf '%s' "$_tap_caller_record"; fi
    return 0
  fi
  if [ -z "${TAP_HARNESS_SESSION_ID:-${CLAUDE_CODE_SESSION_ID:-}}" ]; then
    TAP_CALLING_PANE_REFUSAL="$_tap_process_refusal"
    TAP_CALLING_PANE_STATE="$_tap_process_state"
  fi
  return 1
}

# After a Claude-context fallback selected and verified a row on its stored
# tmux socket, keep later Bash operations on that same server. The wrapper is
# shell-local: it neither exports a fake TMUX ancestry claim nor affects other
# TAP processes.
tap_pin_selected_tmux_socket() {
  [ -n "${TAP_CALLER_SELECTED_SOCKET:-}" ] || return 0
  TAP_CALLER_PINNED_SOCKET="$TAP_CALLER_SELECTED_SOCKET"
  tmux() {
    command env -u TMUX -u TMUX_PANE \
      python3 -B "$_TAP_SCRIPT_DIR/tmux_deadline.py" -S "$TAP_CALLER_PINNED_SOCKET" "$@"
  }
}

# A background job is bound to the seat instance that owned its handle when the
# job was created. Re-read that instance at the pane-effect boundary so a
# same-pane successor cannot inherit an already-validated daemon.
tap_revalidate_selected_instance() { # [registry] [handle] [instance] [pane] [pane-id] [session] [epoch] [socket]
  local selected_registry selected_handle selected_instance selected_pane selected_pane_id selected_session selected_epoch selected_socket
  selected_registry="${1:-}"
  selected_handle="${2:-${TAP_CALLER_SELECTED_HANDLE:-}}"
  selected_instance="${3:-${TAP_CALLER_SELECTED_INSTANCE:-}}"
  selected_pane="${4:-${TAP_CALLER_SELECTED_PANE:-}}"
  selected_pane_id="${5:-${TAP_CALLER_SELECTED_PANE_ID:-}}"
  selected_session="${6:-${TAP_CALLER_SELECTED_SESSION:-}}"
  selected_epoch="${7:-${TAP_CALLER_SELECTED_EPOCH:-}}"
  selected_socket="${8:-${TAP_CALLER_SELECTED_SOCKET:-}}"
  [ -n "$selected_instance" ] || return 0
  if [ -z "$selected_registry" ]; then
    tap_require_acting_registry >/dev/null 2>&1 || return 1
    selected_registry="$TAP_REGISTRY"
  fi
  TAP_SELECTED_HANDLE="$selected_handle" \
    TAP_SELECTED_INSTANCE="$selected_instance" \
    TAP_SELECTED_PANE="$selected_pane" \
    TAP_SELECTED_PANE_ID="$selected_pane_id" \
    TAP_SELECTED_SESSION="$selected_session" \
    TAP_SELECTED_EPOCH="$selected_epoch" \
    TAP_SELECTED_SOCKET="$selected_socket" \
    python3 -B - "$selected_registry" "${_TAP_SCRIPT_DIR}" <<'PY'
import json, os, sys
sys.path.insert(0, sys.argv[2])
from registry_v20 import _seat_map
try:
    row = _seat_map(json.load(open(sys.argv[1]))).get(os.environ.get("TAP_SELECTED_HANDLE", ""))
except Exception:
    raise SystemExit(1)
expected = {
    "pane": os.environ.get("TAP_SELECTED_PANE", ""),
    "pane_id": os.environ.get("TAP_SELECTED_PANE_ID", ""),
    "session": os.environ.get("TAP_SELECTED_SESSION", ""),
    "server_epoch": os.environ.get("TAP_SELECTED_EPOCH", ""),
    "server_socket": os.environ.get("TAP_SELECTED_SOCKET", ""),
}
binding_ok = isinstance(row, dict) and (
    not expected["pane"] or all((row.get(key) or "") == value for key, value in expected.items())
)
raise SystemExit(0 if isinstance(row, dict)
    and row.get("status", "active") == "active"
    and row.get("instance") == os.environ.get("TAP_SELECTED_INSTANCE")
    and binding_ok else 1)
PY
}

# Detached /self helpers may inherit a background-job owner witness. Keep that
# witness inside the submit primitive: a wrapper check can go stale while the
# primitive is waiting, redrawing, or retrying Enter. Ordinary courier callers
# leave the tuple empty and retain their existing pane-identity contract.
tap_submit_owner_guard() {
  [ -n "${TAP_SUBMIT_OWNER_INSTANCE:-}" ] || return 0
  tap_revalidate_selected_instance \
    "${TAP_SUBMIT_OWNER_REGISTRY:-}" \
    "${TAP_SUBMIT_OWNER_HANDLE:-}" \
    "$TAP_SUBMIT_OWNER_INSTANCE" \
    "${TAP_SUBMIT_OWNER_PANE:-}" \
    "${TAP_SUBMIT_OWNER_PANE_ID:-}" \
    "${TAP_SUBMIT_OWNER_SESSION:-}" \
    "${TAP_SUBMIT_OWNER_EPOCH:-}" \
    "${TAP_SUBMIT_OWNER_SOCKET:-}"
}

tap_caller_pane_id() { # [output-var] [allow-launching=0]
  local output_var="${1:-}" allow_launching="${2:-0}" _tap_caller_observation=""
  if ! tap_caller_pane_observe _tap_caller_observation "$allow_launching"; then
    [ -z "$output_var" ] || printf -v "$output_var" '%s' ""
    return 1
  fi
  _tap_caller_observation="${_tap_caller_observation%%$'\t'*}"
  if [ -n "$output_var" ]; then printf -v "$output_var" '%s' "$_tap_caller_observation"; else printf '%s' "$_tap_caller_observation"; fi
}

tap_calling_pane_id() {
  if [ -z "${1:-}" ]; then
    tap_calling_pane_observe "" pane-id
    return
  fi
  printf -v "$1" '%s' ""
  _TAP_CALLING_PANE_ID_VALUE=""
  if ! tap_calling_pane_observe _TAP_CALLING_PANE_ID_VALUE pane-id; then
    [ "$1" = _TAP_CALLING_PANE_ID_VALUE ] || unset _TAP_CALLING_PANE_ID_VALUE
    return 1
  fi
  printf -v "$1" '%s' "$_TAP_CALLING_PANE_ID_VALUE"
  [ "$1" = _TAP_CALLING_PANE_ID_VALUE ] || unset _TAP_CALLING_PANE_ID_VALUE
}

# --- pane liveness (the ONE alive primitive) -----------------------------------
# tmux 3.6a: `display-message -p -t <dead-target>` exits 0 with EMPTY output
# instead of failing (send-keys/capture-pane still fail). Alive-ness must key on
# a non-empty #{pane_id} expansion, NEVER on display-message's exit code. Every
# alive check routes through here.
tap_pane_alive() {  # $1=tmux-target -> prints pane_id; fails when the pane is gone
  local pid
  pid="$(tmux display-message -p -t "$1" '#{pane_id}' 2>/dev/null || true)"
  [ -n "$pid" ] || return 1
  printf '%s' "$pid"
}

# tap_server_epoch_now — the current tmux SERVER epoch as "srv:<pid>:<start>",
# or rc 1 with no output when it cannot be observed (the epoch guard then
# disables — an unknown epoch never voids anything). Pane/session ids are
# unique only within ONE server lifetime; a keeper rebirth restarts the
# numbering, so ids captured under a prior epoch can resolve on the new server
# to unrelated panes (tap-24f). Bash mirror of seat_corpse.server_epoch_now —
# the two strings MUST compare equal, pinned by server-epoch-guard.test.sh.
# TAP_SERVER_EPOCH (set = override, empty = force-unknown) pins the answer. It
# exists for tests, and for a caller that must make one observation decide two
# things — see tap_destructive_session_target's note on pinning (tap-usix).
# A server generation is comparable only inside its socket namespace.
tap_server_socket_now() {
  local socket
  socket="$(tmux display-message -p '#{socket_path}' 2>/dev/null)" || return 1
  case "$socket" in /*) ;; *) return 1 ;; esac
  [[ "$socket" != *$'\n'* ]] || return 1
  printf '%s' "$socket"
}

tap_server_epoch_now() {
  if [ -n "${TAP_SERVER_EPOCH+x}" ]; then
    [ -n "$TAP_SERVER_EPOCH" ] || return 1
    printf '%s' "$TAP_SERVER_EPOCH"
    return 0
  fi
  local raw
  raw="$(tmux display-message -p '#{pid}:#{start_time}' 2>/dev/null)" || return 1
  tap_server_epoch_from_raw "$raw"
}

# tap_boot_id — stable current boot-session identity, or rc 1 with no output
# when unobservable. macOS prefers kern.bootsessionuuid; Linux and older hosts
# fall back to the boot epoch as "boot:<sec>". Exact twin of
# launcher.current_boot_id() (tap-24f INVARIANT: shell and python stamps MUST
# compare equal). TAP_BOOT_ID is honoured LIVE for controlled probes.
#
# POLARITY WARNING (tap-9tqt amendment 7): launcher.current_boot_id() documents
# that a missing boot id "never marks anything gone" — correct for reservation
# expiry (fail toward not-destroying). The reset fence has the OPPOSITE safe
# direction: unreadable identity must treat the owner as LIVE and refuse
# reclaim. Do not inherit the launcher's default into fence composition.
tap_boot_id() {
  if [ -n "${TAP_BOOT_ID+x}" ]; then
    [ -n "$TAP_BOOT_ID" ] || return 1
    printf '%s' "$TAP_BOOT_ID"
    return 0
  fi
  local uuid="" sec="" raw=""
  if uuid="$(sysctl -n kern.bootsessionuuid 2>/dev/null)"; then
    uuid="$(printf '%s' "$uuid" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')"
    case "$uuid" in
      ''|*[!0-9a-f-]*) uuid="" ;;
      ????????-????-????-????-????????????) ;;
      *) uuid="" ;;
    esac
  fi
  if [ -n "$uuid" ]; then
    printf 'bootuuid:%s' "$uuid"
    return 0
  fi
  tap_boot_epoch_id
}

# Legacy epoch observation used only to admit pre-UUID registry stamps through
# a narrow migration window. TAP_BOOT_ID_LEGACY is the explicit test seam.
tap_boot_epoch_id() {
  if [ -n "${TAP_BOOT_ID_LEGACY+x}" ]; then
    [ -n "$TAP_BOOT_ID_LEGACY" ] || return 1
    printf '%s' "$TAP_BOOT_ID_LEGACY"
    return 0
  fi
  case "${TAP_BOOT_ID:-}" in
    boot:[0-9]*) printf '%s' "$TAP_BOOT_ID"; return 0 ;;
  esac
  local sec="" raw=""
  if raw="$(sysctl -n kern.boottime 2>/dev/null)"; then
    # "{ sec = 1783.., usec = .. } ..." — must NOT match the "sec" inside "usec"
    # (greedy .*sec= latches onto usec and yields the wrong integer).
    sec="$(printf '%s' "$raw" | sed -n 's/.*{ sec = \([0-9][0-9]*\).*/\1/p')"
  fi
  if [ -z "$sec" ] && [ -r /proc/stat ]; then
    sec="$(awk '/^btime / { print $2; exit }' /proc/stat 2>/dev/null || true)"
  fi
  [ -n "$sec" ] || return 1
  printf 'boot:%s' "$sec"
}
# Exact UUIDs remain exact. A legacy boot:<sec> row is accepted only when its
# epoch is within five seconds of the independently observed current boot.
# Explicit TAP_BOOT_ID fixtures retain exact comparison unless they also set
# TAP_BOOT_ID_LEGACY, so reboot tests do not become tolerance tests by accident.
# THREE ANSWERS, not two: rc 0 = match, rc 1 = positively different boots,
# rc 2 = UNKNOWN (the pair could not be related at all).
#
# The two-state version collapsed "different" with "could not tell", and the
# reset fence mapped both to PROVED STALE — licensing reclaim of a fence whose
# owner may be alive, and contradicting the fence's own rule that an unreadable
# factor resolves to LIVE. Every existing caller that tests this as a boolean
# keeps its behaviour, because both 1 and 2 are non-zero; only the fence
# distinguishes them.
tap_boot_stamp_readable() { # <stamp> -> 0 when it is one of the two shapes tap_boot_id emits
  case "$1" in
    # CANONICAL OR UNREADABLE, and this shell is the reason the rule cannot be
    # left to the arithmetic below. A leading zero puts $(( )) into OCTAL, where
    # 8 and 9 are not digits: the expansion ERRORS, the error resolves to
    # "differ", and this guard RECLAIMS a fence native and python both hold --
    # the one divergence in this predicate where the shell takes what the others
    # protect. Length is bounded in the same breath because digits too long to
    # represent overflow SILENTLY here, to a plausible finite number, so the
    # arithmetic cannot be asked whether it succeeded. Both halves are decided by
    # SHAPE, before any number exists.
    boot:0) return 0 ;;
    boot:[1-9]*)
      case "${1#boot:}" in
        *[!0-9]*) return 1 ;;
      esac
      [ "${#1}" -le 20 ] || return 1   # 5 for "boot:" + at most 15 digits
      return 0 ;;
    boot:*) return 1 ;;
    bootuuid:*)
      # EVERY GROUP MUST BE HEX, spelled out rather than as `?` wildcards.
      # `tap_boot_id`'s own validation pairs `????????-????-????-????-????????????`
      # with a charset reject of `*[!0-9a-f-]*`, and `-` is INSIDE that charset —
      # so `?` matches a hyphen and `bootuuid:-0000000-0000-0000-0000-000000000000`
      # read as well-formed here, then as a positive MISMATCH, licensing the very
      # reclaim this predicate exists to refuse. The native regex
      # `[0-9a-f]{8}-...` and the acquire python's copy both rejected it, so this
      # was one recognizer looser than its two twins rather than a shared rule
      # (opus-deep-tidying-examiner by execution; grok/sol panel confirming).
      case "${1#bootuuid:}" in
        [0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f]-[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]) return 0 ;;
        *) return 1 ;;
      esac ;;
    *) return 1 ;;
  esac
}

tap_boot_ids_match() { # <row-boot-id> <current-boot-id>  -> 0 match | 1 differ | 2 unknown
  local row="$1" current="$2" legacy="" row_sec current_sec delta
  [ -n "$row" ] && [ -n "$current" ] || return 2
  # SHAPE FIRST, EVEN FOR AN EQUAL PAIR. rc 0 (match) does not short-circuit the
  # caller to LIVE the way rc 2 (unknown) does — the guard falls through to the
  # pid and fingerprint factors — so two equal unparseable stamps waved the boot
  # factor through and let a later dead pid authorize a reclaim.
  tap_boot_stamp_readable "$row" && tap_boot_stamp_readable "$current" || return 2
  [ "$row" = "$current" ] && return 0
  if [ -n "${TAP_BOOT_ID+x}" ] && [ -z "${TAP_BOOT_ID_LEGACY+x}" ]; then
    return 1
  fi
  case "$row" in
    boot:[0-9]*) row_sec="${row#boot:}" ;;
    # An exact row against another exact id genuinely differs; against a legacy
    # epoch there is nothing to relate it to.
    *) case "$current" in boot:[0-9]*) return 2 ;; *) return 1 ;; esac ;;
  esac
  # THE ORACLE IS AN INPUT TOO. Both stamps above are shape-checked; this third
  # value is supplied independently, and a bare `boot:[0-9]*` glob accepted a
  # leading zero -- which puts the arithmetic below into OCTAL, where 8 and 9 are
  # not digits, so the expansion errors and the failure resolves to "differ".
  # Same canonical rule as the stamps, via the same predicate, so there is one
  # definition of a readable boot epoch rather than three.
  legacy="$(tap_boot_epoch_id 2>/dev/null || true)"
  tap_boot_stamp_readable "$legacy" || return 2
  case "$legacy" in boot:*) current_sec="${legacy#boot:}" ;; *) return 2 ;; esac
  delta=$((row_sec - current_sec))
  [ "$delta" -ge 0 ] || delta=$((-delta))
  [ "$delta" -le 5 ]
}

# tap_server_epoch_from_raw <raw> — read a "<pid>:<start_time>" field OUT of a
# wider tmux record and emit the same "srv:<pid>:<start>" string the standalone
# probe does; rc 1 when the field is absent or ungrammatical. THE single
# grammar authority on this side of the boundary, so the standalone probe and
# the single-observation capture (tap-ua9l) can never disagree about what a
# generation is called. Bash twin of seat_corpse.observed_server_epoch, pinned
# by seat-corpse-lockstep.test.sh. Honours TAP_SERVER_EPOCH for the same reason
# the probe does: a test simulating a rebirth must move the observation and the
# re-check together, or the fixture proves nothing.
tap_server_epoch_from_raw() {
  if [ -n "${TAP_SERVER_EPOCH+x}" ]; then
    [ -n "$TAP_SERVER_EPOCH" ] || return 1
    printf '%s' "$TAP_SERVER_EPOCH"
    return 0
  fi
  local raw="$1"
  case "$raw" in
    ''|*[!0-9:]*|:*|*:) return 1 ;;
  esac
  case "$raw" in
    *:*) case "${raw#*:}" in *:*) return 1 ;; esac ;;
    *) return 1 ;;
  esac
  printf 'srv:%s' "$raw"
}

# tap_pane_observe <tmux-target>
#   -> "<pane_id>\t<session_name>\t<generation>" (rc 0), rc 1 with no output
#      when the pane is gone, or rc 2 with no output when tmux returned a
#      malformed pane id. The generation field is empty when the record could
#      not carry one.
#
# THE writer-side capture (tap-ua9l finding 7). A writer that probes the pane
# and then probes the generation makes TWO observations, and a server rebirth
# landing between them stamps ids belonging to the dead server with the live
# one — a false-current row minted during exactly the event the guard exists to
# handle, which every downstream reader then believes. One record removes the
# window: whatever generation comes back is the generation that pane id was
# seen under, by construction.
#
# Deliberately a SIBLING of tap_pane_alive rather than a replacement for it.
# Guard direction follows the question: tap_pane_alive answers "does this pane
# exist", a detector that is safest seeing MORE and must stay fail-open, and it
# keeps its narrow single-field format and its ~20 callers unchanged. This one
# answers "what may I write down as identity", where an unproven answer must
# cost the write, not the row. Callers that persist ids use this; callers that
# merely check existence must not.
#
# Command and path provenance stay separate probes on purpose: they are
# descriptive, never resolved as identity later, so they carry no TOCTOU and
# folding them in would only widen what fake tmuxes must answer.
tap_pane_observe() {
  local fmt raw observed_id rest sess epoch
  fmt="$(printf '#{pane_id}\t#{session_name}\t#{pid}:#{start_time}')"
  raw="$(tmux display-message -p -t "$1" "$fmt" 2>/dev/null || true)"
  raw="${raw%%$'\n'*}"
  observed_id="${raw%%$'\t'*}"
  # Same death signal as tap_pane_alive: an empty #{pane_id} expansion, never
  # display-message's exit code (tmux 3.6a exits 0 for a gone target).
  [ -n "$observed_id" ] || return 1
  # This is the shell registry-observation boundary: every targeted writer
  # consumes this record, so malformed tmux output is refused here rather than
  # being entrusted to each persistence caller.
  tap_is_pane_id "$observed_id" || return 2
  rest="${raw#*$'\t'}"
  [ "$rest" = "$raw" ] && rest=""
  sess="${rest%%$'\t'*}"
  epoch=""
  [ "$rest" = "$sess" ] && rest="$sess$(printf '\t')"
  epoch="$(tap_server_epoch_from_raw "${rest#*$'\t'}" 2>/dev/null || true)"
  printf '%s\t%s\t%s' "$observed_id" "$sess" "$epoch"
}

# tap_destructive_session_target <pane-id> <row-session> <row-epoch> <expected-session>
#
# THE sanctioned derivation of a session name for a session-TERMINATING shell
# decision — the single verifier `tap team shutdown` and `tap out --kill` route
# through. Shell twin of launcher.destructive_session_target; the two must
# agree, because the same registry row can be terminated from either language.
# Bun twin: runtime/bun/src/lifecycle-target.ts destructiveSessionTarget.
#
# NAME-FIRST (session-name authority, 2026-08-04; supersedes the 2026-07-25
# id-anchored proven arm — obs 73641/73569/74434). The tmux session name is the
# identity key; stored pane ids are HINTS re-verified at point of use against
# panes re-derived from that name. The old "wherever the seat moved, that is
# the seat" proven arm IS the E2 kill-wrong mechanism (same epoch, recycled %N
# live on a foreign session → verifier returned the foreign name). It is
# retired: a seat that genuinely moved/renamed is un-killable by stored id
# until its registry session string matches a live name (intentional tradeoff).
#
# Authorize iff ALL of:
#   1. <pane-id> satisfies the tmux pane-id grammar (tap_is_pane_id);
#   2. <row-session> EXACTLY equals caller-derived <expected-session>;
#   3. that exact name is live (`tmux has-session -t "=<expected>"`);
#   4. the stored pane_id is NOT alive in a different session.
#
# Ops (2026-08-04): kill by session name; refusal fires ONLY on stored-id/name
# disagreement (pane live elsewhere — the E2 wrong-session case). A gone or
# unproven pane tip does not block kill-by-name of the canonical live session.
# Epoch stamps no longer gate authorization (name+live is the existence oracle;
# pane-elsewhere is the identity refuse). pane-command/harness is never consulted.
#
# Prints the authorized session name (always <expected-session>) and returns 0,
# or prints a refusal REASON and returns 1. Reasons are distinct on purpose:
#   pane_identity_missing     the row carries no in-grammar pane id
#   session_name_gone         the canonical name is no longer live
#   pane_live_elsewhere       expected name live, stored id alive in another session
#   server_epoch_unproven     retained for empty expectation / no row-session match
#   server_epoch_stale        retained label for callers that still branch on it
#
# An empty <expected-session> is a refusal, not a wildcard.
#
# PINNING THE GENERATION (tap-usix). This observes the current epoch itself, so
# a caller that ALSO observes it — to label which arm authorized, to log, to
# decide anything the outcome is later re-tested against — is holding two
# independent readings of a fact that can change between them, and an epoch that
# is momentarily unobservable is enough to make them disagree. Such a caller
# must pin this one to its own reading by setting TAP_SERVER_EPOCH for the call
# (set = that generation, set-but-empty = unknown, which is what a failed
# observation means). Then the arm taken here and the label the caller kept
# cannot diverge. Callers that keep NO derived state — `tap team shutdown`,
# which re-runs this whole verifier before acting and demands the same answer —
# need no pin, because they retain nothing that could go stale.
tap_destructive_session_target() {
  local pane_id="$1" row_session="$2" row_epoch="$3" expected="$4"
  local observed member p
  tap_is_pane_id "$pane_id" || { printf 'pane_identity_missing'; return 1; }
  [ -n "$expected" ] && [ "$row_session" = "$expected" ] || {
    # Row does not name the caller's canonical seat. If the stored id is live
    # on some other session while the expected name is live, that is E2.
    if [ -n "$expected" ] && tmux has-session -t "=$expected" >/dev/null 2>&1; then
      observed="$(tap_pane_alive "$pane_id" 2>/dev/null || true)"
      if [ "$observed" = "$pane_id" ]; then
        member=0
        while IFS= read -r p; do
          [ "$p" = "$pane_id" ] && { member=1; break; }
        done < <(tmux list-panes -t "=$expected" -F '#{pane_id}' 2>/dev/null || true)
        [ "$member" = 1 ] || { printf 'pane_live_elsewhere'; return 1; }
      fi
    fi
    printf 'server_epoch_unproven'; return 1
  }
  tmux has-session -t "=$expected" >/dev/null 2>&1 || { printf 'session_name_gone'; return 1; }
  # Ops: refuse ONLY when the stored id is alive in a different session.
  # A gone tip, or a tip that names / is a member of the expected session, authorizes.
  observed="$(tap_pane_alive "$pane_id" 2>/dev/null || true)"
  if [ "$observed" = "$pane_id" ]; then
    tip_sess="$(tmux display-message -p -t "$pane_id" '#{session_name}' 2>/dev/null || true)"
    if [ "$tip_sess" != "$expected" ]; then
      member=0
      while IFS= read -r p; do
        [ "$p" = "$pane_id" ] && { member=1; break; }
      done < <(tmux list-panes -t "=$expected" -F '#{pane_id}' 2>/dev/null || true)
      if [ "$member" != 1 ]; then
        printf 'pane_live_elsewhere'; return 1
      fi
    fi
  fi
  printf '%s' "$expected"
  return 0
}

# tap_tmux_server_reachable
# Distinguishes "this pane is gone" from "I cannot talk to tmux at all"
# (missing/synthetic TMUX socket, missing binary, any probe failure — tap-o4ae).
# A dead SOCKET is not a dead PANE; callers must not write pane_gone suspensions
# when this returns nonzero.
#
# Fail-closed: EVERY failed server probe refuses the suspension write. The sole
# reachable-on-failure exception is an empty-stderr mock that implements only
# `-t` probes and fails the no-target form silently — so legitimate dead-pane
# smokes still suspend and exit 3.
tap_tmux_server_reachable() {
  local err rc=0
  err="$(tmux display-message -p '#{socket_path}' 2>&1 >/dev/null)" || rc=$?
  [ "$rc" -eq 0 ] && return 0
  # Failed probe with empty stderr → fixture mock no-target gap; treat reachable.
  [ -z "$err" ] && return 0
  return 1
}

# tap_seat_pane_probe <stored-pane-id> <pane-address>
# Bash mirror of the authoritative python classifier (session/seat_corpse.py —
# the code the register ladder executes); pinned against it by
# seat-corpse-lockstep.test.sh. Four-way classification, identity first with
# address fallback: registry rows with pane_id must prove THAT identity is
# still alive; an address resolving to the STORED id is that identity, alive;
# an address resolving to a DIFFERENT pane_id is a recycled (occupied) seat;
# only OBSERVED misses classify pane_gone; a probe that cannot reach the tmux
# server at all classifies 'unobservable' and proves nothing (tap-o4ae's rule:
# absence-of-observation is never observation-of-absence).
#
# RC CONTRACT (the delete-permission bit): exit 0 means this row may NOT be
# treated as dead (alive OR unobservable); exit 1 means the row's identity was
# OBSERVED stale (pane_gone, pane_recycled). Callers that need the exact state
# must branch on the printed STRING — never infer "dead" from a bare nonzero,
# and never infer "alive" from a bare zero. This direction is deliberate: a
# caller that only checks the exit code can keep a row it should trim (safe),
# but can never trim a row it must keep (tap-67n1's live-seat deletion).
# tap_seat_pane_observation <target>
# One observation, tri-state: prints the pane id the target resolves to
# (rc 0), prints nothing when the target was OBSERVED absent (rc 0), rc 2
# when no observation could be made. Bash mirror of seat_corpse.py's
# pane_observation, pinned per-case by seat-corpse-lockstep.test.sh.
#
# Absence requires the SERVER to have answered: rc 0 with an empty expansion
# (tmux 3.6a dead target), or a nonzero exit whose stderr says "can't find"
# (the classic dead-target reply — the error IS the answer). A nonzero exit
# with any other stderr (dead server, transient failure), a missing binary,
# or a MALFORMED resolution is rc 2: the probe failed or lied, and a failed
# probe is never an observation of absence (sol, #xxx re-gate — the
# fail-closed rule exists FOR the failure branch).
#
# tap_is_pane_id <value>
# PANE-ID GRAMMAR (sol, re-gate round 2): a tmux pane id is '%' followed by
# decimal digits, NOTHING else. A bare %-prefix check accepted '%bogus' as
# an identity, which misclassified it PANE_RECYCLED — not a blanket
# "replace the seat" authorization, but a verdict each consumer acts on under
# its own guarded policy (see seat_corpse.is_pane_id for the per-consumer
# breakdown). This function is the bash mirror of seat_corpse.is_pane_id,
# pinned by the lockstep boundary corpus, and it is the ONE place the shell
# spells the grammar: every bash caller that asks "is this a stable pane
# identity?" comes here rather than testing the string for non-emptiness,
# because a garbled capture is a broken observation channel and non-emptiness
# cannot tell the two apart.
tap_is_pane_id() {
  case "${1-}" in
    %*) case "${1#%}" in ''|*[!0-9]*) return 1 ;; *) return 0 ;; esac ;;
    *) return 1 ;;
  esac
}

tap_seat_pane_observation() {
  local out="" err_file err="" rc=0
  err_file="$(mktemp "${TMPDIR:-/tmp}/tap-seat-obs.XXXXXX")"
  out="$(tmux display-message -p -t "$1" '#{pane_id}' 2>"$err_file")" || rc=$?
  err="$(cat "$err_file" 2>/dev/null || true)"
  rm -f "$err_file"
  if [ "$rc" -ne 0 ]; then
    case "$err" in
      *"can't find"*) return 0 ;;
      *) return 2 ;;
    esac
  fi
  # RECORD FRAMING (sol, #xxx re-gate r4): a multi-line rc-0 answer is a
  # garbled channel even when its first line looks valid — taking the first
  # line would drift from the python authorities, which reject the frame.
  case "$out" in *$'\n'*) return 2 ;; esac
  [ -n "$out" ] || return 0
  tap_is_pane_id "$out" || return 2
  printf '%s' "$out"
  return 0
}

tap_seat_pane_probe() {
  local stored_id="${1:-}" pane="${2:-}" identity="" address="" orc=0
  if [ -n "$stored_id" ]; then
    # A malformed stored id proves the observation channel/row is damaged; it
    # is not permission to probe an address and declare the seat recycled.
    if ! tap_is_pane_id "$stored_id"; then
      printf 'unobservable'
      return 0
    fi
    identity="$(tap_seat_pane_observation "$stored_id")" || orc=$?
    if [ "$orc" -eq 2 ]; then
      printf 'unobservable'
      return 0
    fi
    if [ -n "$identity" ]; then
      printf 'alive'
      return 0
    fi
    if [ -n "$pane" ]; then
      address="$(tap_seat_pane_observation "$pane")" || orc=$?
      if [ "$orc" -eq 2 ]; then
        printf 'unobservable'
        return 0
      fi
      if [ -n "$address" ] && [ "$address" = "$stored_id" ]; then
        printf 'alive'
        return 0
      fi
      if [ -n "$address" ]; then
        printf 'pane_recycled'
        return 1
      fi
    fi
    printf 'pane_gone'
    return 1
  fi
  if [ -n "$pane" ]; then
    address="$(tap_seat_pane_observation "$pane")" || orc=$?
    if [ "$orc" -eq 2 ]; then
      printf 'unobservable'
      return 0
    fi
    if [ -n "$address" ]; then
      printf 'alive'
      return 0
    fi
  fi
  printf 'pane_gone'
  return 1
}

# tap_tmux_session_observation <exact-session-name>
# Print "alive|observed_absent|unobservable<US>server_epoch" from one reachable
# list-sessions snapshot. A nonzero tmux exit is never absence proof: missing
# binaries, dead sockets, and transient probe failures all land on unobservable.
tap_tmux_session_observation() {
  local wanted="${1:-}" fmt out rc=0 line session raw_epoch extra epoch="" seen=0 found=0 parsed=""
  [ -n "$wanted" ] || { printf 'unobservable\x1f'; return 0; }
  fmt="$(printf '#{session_name}\t#{pid}:#{start_time}')"
  out="$(tmux list-sessions -F "$fmt" 2>/dev/null)" || rc=$?
  [ "$rc" -eq 0 ] || { printf 'unobservable\x1f'; return 0; }
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    IFS=$'\t' read -r session raw_epoch extra <<< "$line"
    if [ -z "$session" ] || [ -z "$raw_epoch" ] || [ -n "${extra:-}" ]; then
      printf 'unobservable\x1f'; return 0
    fi
    parsed="$(tap_server_epoch_from_raw "$raw_epoch" 2>/dev/null || true)"
    [ -n "$parsed" ] || { printf 'unobservable\x1f'; return 0; }
    if [ -n "$epoch" ] && [ "$epoch" != "$parsed" ]; then
      printf 'unobservable\x1f'; return 0
    fi
    epoch="$parsed"; seen=1
    [ "$session" = "$wanted" ] && found=1
  done <<< "$out"
  [ "$seen" = 1 ] || { printf 'observed_absent\x1f'; return 0; }
  if [ "$found" = 1 ]; then printf 'alive\x1f%s' "$epoch"
  else printf 'observed_absent\x1f%s' "$epoch"
  fi
}

# tap_tmux_session_panes <exact-session-name> <name-snapshot-epoch>
# Print validated TAB records:
#   session, address, pane_id, current_command, pane_pid, server_epoch
# A failure or a server-generation move returns 1 with no records.
tap_tmux_session_panes() {
  local wanted="${1:-}" expected_epoch="${2:-}" fmt out rc=0 line session address pane_id command pane_pid raw_epoch extra parsed seen=0
  [ -n "$wanted" ] || return 1
  fmt="$(printf '#{session_name}\t#{session_name}:#{window_index}.#{pane_index}\t#{pane_id}\t#{pane_current_command}\t#{pane_pid}\t#{pid}:#{start_time}')"
  out="$(tmux list-panes -s -t "=$wanted" -F "$fmt" 2>/dev/null)" || rc=$?
  [ "$rc" -eq 0 ] && [ -n "$out" ] || return 1
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    IFS=$'\t' read -r session address pane_id command pane_pid raw_epoch extra <<< "$line"
    [ "$session" = "$wanted" ] && [ -n "$address" ] && tap_is_pane_id "$pane_id" \
      && [ -n "$command" ] && case "$pane_pid" in ''|*[!0-9]*) false ;; *) true ;; esac \
      && [ -z "${extra:-}" ] || return 1
    parsed="$(tap_server_epoch_from_raw "$raw_epoch" 2>/dev/null || true)"
    [ -n "$parsed" ] || return 1
    [ -z "$expected_epoch" ] || [ "$parsed" = "$expected_epoch" ] || return 1
    printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$session" "$address" "$pane_id" "$command" "$pane_pid" "$parsed"
    seen=1
  done <<< "$out"
  [ "$seen" = 1 ]
}

# tap_process_harness_observation <pane-pid>
# Print "observed<US><family>" only when ps answered and the pane root process
# was present. For a shell root only, the kernel-designated terminal foreground
# process-group leader may supply the family. This is not a descendant walk: a
# background agent has a different process group and remains deliberately
# invisible. A failed ps or a vanished root prints "unobservable<US>".
# Authority lives in runtime/bun/src/observe.ts (shared with the batched roster
# path). It was tap_observe_seats.py until that file was deleted with its last
# caller.
tap_process_harness_observation() {
  # Same canonical family list the batch engine receives (tap-lae7 / sol P2).
  TAP_OBS_HARNESS_FAMILIES="${TAP_HARNESS_FAMILIES}" \
    tap_bun_call observe-harness-pid "${1:-}" observe.ts --harness-pid "${1:-}" 2>/dev/null
}

# tap_harness_evidence <expected-harness> <current-command> <pane-pid>
# Print "alive|exited|mismatch|unattested|unobservable<US><observed-family>".
# Observation can confirm an attested expectation but never mint one: an empty
# expected family is a repairable write-boundary omission, not a matches-any
# wildcard and not a positive mismatch.
tap_harness_evidence() {
  local expected="$(tap_harness_family "${1:-}")" command="${2:-}" pane_pid="${3:-}"
  local observed="$(tap_harness_family "$command")" class record state family
  [ -n "$expected" ] || { printf 'unattested\x1f'; return 0; }
  class="$(tap_classify_harness "$observed")"
  case "$class" in
    agent)
      if [ "$observed" = "$expected" ]; then printf 'alive\x1f%s' "$observed"
      else printf 'mismatch\x1f%s' "$observed"
      fi
      return 0 ;;
    denylist)
      printf 'exited\x1f%s' "$observed"; return 0 ;;
  esac
  [ -n "$pane_pid" ] || { printf 'unobservable\x1f'; return 0; }
  record="$(tap_process_harness_observation "$pane_pid")"
  IFS=$'\x1f' read -r state family <<< "$record"
  [ "$state" = observed ] || { printf 'unobservable\x1f'; return 0; }
  if [ -n "$family" ]; then
    if [ "$family" = "$expected" ]; then printf 'alive\x1f%s' "$family"
    else printf 'mismatch\x1f%s' "$family"
    fi
  else
    printf 'exited\x1f%s' "$observed"
  fi
}

# tap_observe_roster_batch
# Batched seat observation (tap-lae7). Stdin is a JSON array of row objects:
#   {key,status,delivery,pane,pane_id,session,registered_at,row_epoch,
#    row_boot,harness,status_reason}
# Stdout lines:
#   key<US>state<US>reason<US>pane<US>pane_id<US>harness<US>attached
# Named consumer: tap team's roster path today; tap-l8ve's fleet-watcher later.
#
# THIS IS AN ADAPTER AND NOTHING ELSE (tap-fqd3e). It used to run the tmux and
# ps queries itself and hand three temp files to the classifier, which made it a
# second gather beside `verbs/team.ts observe()` — same two formats, same
# coverage check, same staged per-session fallback, written twice. Worse, the
# Bash half held a DECISION (skip `ps` when every shallow command classifies), a
# PARSER (the awk coverage check) and a RETRY (the fallback loop), so the "one
# classifier" rule was true of the engine and false of its input.
#
# `runtime/bun/src/observe-gather.ts` is that one gather now, and the door below
# collects the snapshot in the same process that classifies it. Every knob this
# function used to read — TAP_OBS_SESSION_SCOPE, TAP_OBS_NOW_BOOT_PIN,
# TAP_WATCH_NOW, TAP_BOOT_ID / TAP_BOOT_ID_LEGACY presence, TAP_SERVER_EPOCH —
# is read from the environment in that child, which is exactly where the
# incumbent read it.
tap_observe_roster_batch() {
  # FAIL CLOSED on a router this adapter cannot hand to its child. The gather
  # runs in a Bun process that selects a server from the environment; a
  # caller-injected `tmux` function with no socket pin routes somewhere only
  # this shell knows. Observing server A and then pressing Enter on server B is
  # a point-of-effect authorization defect, not a fixture artifact, so the
  # observation refuses instead of answering about the wrong world.
  if ! tap_tmux_router_representable; then
    printf 'tap: observation refused: an injected tmux router cannot be represented to the native gather\n' >&2
    return 1
  fi
  TAP_OBS_HARNESS_FAMILIES="${TAP_HARNESS_FAMILIES}" \
    tap_bun_call observe-batch roster observe.ts --gather-from-env
}

# tap_seat_observed_record has the same first eight arguments as the historical
# tap_seat_observed_state contract, followed by row_boot_id, now_boot_id,
# expected_harness, and optional stored status_reason. It prints state, reason,
# resolved address, resolved pane id, and observed harness separated by US. The
# caller-supplied now_server_epoch is retained for source compatibility but never
# authorizes identity; the exact-name snapshot supplies the epoch used by this
# decision. A durable suspended/server_restarted row renders as OFFLINE:
# suspension is the compatible storage vocabulary, while offline is the shared
# observed lifecycle state and the row remains relaunchable.
#
# Implementation (tap-lae7): thin N=1 wrapper over tap_observe_roster_batch so
# attach/peek/command/watch share one authority with tap team.
tap_seat_observed_record() {
  local status="${1:-active}" delivery="${2:-pane}" pane="${3:-}" pane_id="${4:-}"
  local session="${5:-}" registered_at="${6:-}" row_epoch="${7:-}" _caller_epoch="${8:-}"
  local row_boot="${9:-}" now_boot="${10:-}" expected_harness="${11:-}"
  local stored_reason="${12:-}"
  local record state reason resolved_pane resolved_id observed_harness attached
  local rows_json _jq

  # Point-of-effect speed: TAP_OBS_SESSION_SCOPE + skip global ps when shallow
  # commands already prove harness (sol P1). Never cache under TAP_HOME — a
  # row-only TTL there broke liveness within 1s and refused clean-team reset
  # as an unclassified bus component.
  #
  # No cross-call observation reuse of ANY kind: point-of-effect identity
  # guards consume this record, and a result recorded before a pane changed
  # hands authorizes effects into the new occupant. The key for such a reuse
  # channel can only be built from registry-row fields while the value encodes
  # live state, so a stale hit is exactly the case the guard exists to catch
  # (sol P1, effect-guard-observes-fresh smoke).
  if [ -z "$session" ]; then
    case "$pane" in *:*) session="${pane%%:*}" ;; esac
  fi

  # Bash JSON for the one-row payload — avoid a second python3 spawn per N=1 call.
  _jq() {
    local s=$1
    s=${s//\\/\\\\}
    s=${s//\"/\\\"}
    s=${s//$'\n'/\\n}
    s=${s//$'\r'/\\r}
    s=${s//$'\t'/\\t}
    printf '"%s"' "$s"
  }
  rows_json="[{\"key\":\"0\",\"status\":$(_jq "$status"),\"delivery\":$(_jq "$delivery"),\"pane\":$(_jq "$pane"),\"pane_id\":$(_jq "$pane_id"),\"session\":$(_jq "$session"),\"registered_at\":$(_jq "$registered_at"),\"row_epoch\":$(_jq "$row_epoch"),\"row_boot\":$(_jq "$row_boot"),\"harness\":$(_jq "$expected_harness"),\"status_reason\":$(_jq "$stored_reason")}]"

  # Nonempty caller-sampled now_boot always pins the observed VALUE via
  # TAP_OBS_NOW_BOOT_PIN. Do not overload TAP_BOOT_ID for the value (that
  # invents presence and kills boot:<epoch> tolerance), and do not skip the
  # pin when TAP_BOOT_ID is already set — a nonempty 10th arg is the sample
  # the historical path used (sol P2 / tap-lae7).
  # Scope pane inventory to this seat's session — point-of-effect must not pay
  # for a global list-panes -a (sol P1 / defer-spool 7c).
  if [ -n "$now_boot" ]; then
    record="$(printf '%s\n' "$rows_json" | TAP_OBS_NOW_BOOT_PIN="$now_boot" \
      TAP_OBS_SESSION_SCOPE="$session" tap_observe_roster_batch)"
  else
    record="$(printf '%s\n' "$rows_json" | TAP_OBS_SESSION_SCOPE="$session" \
      tap_observe_roster_batch)"
  fi || {
    printf 'unknown\x1fharness_unobservable\x1f\x1f\x1f'
    return 0
  }
  record="${record%%$'\n'*}"
  # Drop key + attached; keep the historical five-field contract.
  IFS=$'\x1f' read -r _key state reason resolved_pane resolved_id observed_harness attached <<< "$record"
  printf '%s\x1f%s\x1f%s\x1f%s\x1f%s' \
    "$state" "$reason" "$resolved_pane" "$resolved_id" "$observed_harness"
}

# --- pane harness detection ---------------------------------------------------
# tmux's pane_current_command is shallow: Claude Code reports a version string
# like "2.1.198". Resolve the actual harness from the process tree rooted at
# pane_pid, then fall back to pane_current_command if ps/tmux cannot tell.
tap_harness_family() {
  local cmd="${1:-}" name fam
  name="${cmd##*/}"
  for fam in $TAP_HARNESS_FAMILIES; do
    case "$name" in "$fam"|"$fam"-*) printf '%s' "$fam"; return 0 ;; esac
  done
  printf '%s' "$name"
}

tap_classify_harness() {
  case "$(tap_harness_family "$1")" in
    bash|zsh|sh|fish|dash|ksh|tcsh|less|more|man|vi|vim|view|nvim|nano|emacs|ssh|cat|pager|git)
      printf 'denylist' ;;
    claude|codex|opencode|cursor|hermes|agy)
      printf 'agent' ;;
    *)
      printf 'unsupported' ;;
  esac
}

# Inline compact-focus capability — ONE table for /self and tap compact (tap-zsrn).
#   inline     — harness accepts `/compact <focus>` (Claude)
#   deferred   — bare `/compact` only; the focus rides the resume ping on the self
#                path and a settle-only payload on the peer path (tap-thgv)
#   unsupported — compact verb unavailable; callers must degrade/refuse loudly
# Key is tap_harness_family (same normalizer as tap_classify_harness / command's
# live pane resolve). Pass raw or family — never invent a second key vocabulary.
# A convention in an operator ledger is not a table: both paths must call this.
tap_compact_focus_mode() {
  case "$(tap_harness_family "$1")" in
    claude) printf 'inline' ;;
    codex|opencode) printf 'deferred' ;;
    *) printf 'unsupported' ;;
  esac
}

# Pane chrome for compaction, keyed by harness family (tap-ieiy), in TWO
# patterns because the two say different things and are trustworthy in different
# ways. Empty means "no observed chrome for this family" — callers then keep the
# older fixed-spacing behavior rather than gating on a regex nobody has watched a
# real pane produce.
#
#   inflight  — rendered ONLY while a compaction is running. Claude Code 2.1.233:
#               `✻ Compacting conversation… (1m 7s · ↑ 1.2k tokens)`. Its mere
#               presence is proof, so it needs no baseline.
#   done      — a TRANSCRIPT line left behind afterwards: `⎿  Compacted (ctrl+o
#               to see full summary)`. It persists, so presence proves nothing
#               about THIS compaction — only a strict increase does. It is worth
#               watching anyway: a small context compacts in under a poll
#               interval, and without this arm a completed compaction would read
#               as one that never started.
#
# This is HARNESS BEHAVIOR, not a property of this code: it is anchored to the
# version named in docs/solutions/architecture-patterns/compact-queue-behind-probe.md
# and is re-established by RE-RUNNING that probe, never by the suite going green.
# ANCHORED TO THE CHROME LINE, NEVER A BARE SUBSTRING (tap-ieiy follow-on).
#
# These patterns decide whether a compaction is under way, and the wake ping is
# withheld until they say yes. An unanchored `Compacting conversation` matched
# any pane whose TRANSCRIPT contained the words — and the panes most likely to
# contain them are the ones DISCUSSING compaction: whoever is working on this
# code, reading this file, or was sent a message about the wake. The detector's
# own authors were its most likely false positives, and the consequence is the
# defect the gate exists to prevent: "observed" returns instantly, the helper
# waits only the spacing, and the plain wake lands in a turn that is still
# running.
#
# So both patterns require the phrase to sit where CHROME sits and nowhere else:
# at the start of a line, behind a spinner or tree glyph, with the harness's own
# punctuation attached. Prose puts words before the phrase; chrome puts a glyph.
#
# Specimens, captured live from a disposable claude pane during a real /compact
# (2026-08-19, sampled at 0.3s) rather than written from memory — the previous
# pattern was written from memory, which is how it came to match a sentence:
#
#   ✽ Compacting conversation… (16s)      <- in-flight; the spinner cycles
#   · Compacting conversation… (17s)          through at least ✳ ✶ ✻ ✢ ✽ ·
#
# SIX glyphs, not the two an earlier capture caught. The character class above
# absorbed the other four by luck rather than by design, which is the argument
# for a class over a pinned set — and for not trusting a single capture to
# enumerate a rendering. A 40-column capture also showed the harness DROPPING
# the token suffix (`(0s)` rather than `(0s · ↑ 1.5k tokens)`), so the tail of
# this line is not stable either and nothing may depend on it.
#     ⎿  Compacted (ctrl+o to see full summary)   <- done
#
# The trailing ellipsis is part of the in-flight match on purpose: it is chrome
# punctuation a sentence would not carry. It is NOT free, though — an earlier
# version of this comment claimed it "costs nothing to require", and that was
# false: U+2026 is the least stable byte here, one locale, accessibility or
# fallback path away from three ASCII dots. Both spellings are accepted, so the
# load-bearing part is kept and the brittleness is not.
#
# A harness that re-words its chrome drops out of this table, and the gate then
# falls back to its timeout arm — loud and slow, never silently permissive. That
# is the correct direction for this to fail in.
tap_compaction_chrome_re() {  # <harness> [inflight|done] -> extended regex, or empty
  case "$(tap_harness_family "$1")" in
    claude)
      case "${2:-inflight}" in
        inflight) printf '^[[:space:]]*[^[:alnum:][:space:]]+[[:space:]]+Compacting conversation(…|\.\.\.)' ;;
        done) printf '^[[:space:]]*[^[:alnum:][:space:]]+[[:space:]]+Compacted \(' ;;
      esac ;;
    *) printf '' ;;
  esac
}

# tap_compaction_chrome_count <pane> <harness> [inflight|done] — how many lines of
# that chrome the pane currently shows. Prints a count and returns 0; returns 2
# (printing nothing) when this harness has no known chrome, so a caller never
# reads "cannot tell" as "zero".
tap_compaction_chrome_count() {
  local pane="$1" harness="$2" kind="${3:-inflight}" re
  re="$(tap_compaction_chrome_re "$harness" "$kind")"
  [ -n "$re" ] || return 2
  # -J rejoins tmux's wrapped lines into logical ones. Without it a pane narrow
  # enough to break the in-flight line splits it at the pane edge and the
  # ^-anchored pattern stops matching: latent on today's geometry (the line needs
  # ~26 columns; the narrowest pane on this machine is 53) and live the moment an
  # operator rearranges panes. kimi constructed the 24-column miss against the
  # live pattern rather than arguing it.
  tap_capture_pane -pJ -t "$pane" -S -40 2>/dev/null \
    | tap_strip_ansi | grep -Ec "$re" || true
}

# tap_compaction_chrome_lines <pane> <harness> [inflight|done] — the matching
# lines themselves, not a count. The gate needs the TEXT because the question it
# asks is whether the chrome CHANGED between two instants; a count cannot see a
# timer advance from (16s) to (17s).
tap_compaction_chrome_lines() {
  local pane="$1" harness="$2" kind="${3:-inflight}" re
  re="$(tap_compaction_chrome_re "$harness" "$kind")"
  [ -n "$re" ] || return 2
  tap_capture_pane -pJ -t "$pane" -S -40 2>/dev/null \
    | tap_strip_ansi | grep -E "$re" || true
}

# tap_wait_compaction <pane> <harness> <timeout-seconds> [poll-seconds]
# Block until a compaction is observably under way — the in-flight chrome is
# present, or the completed-compaction chrome count has risen above the count
# taken at entry. Exits 0 observed, 1 timed out or pane gone, 2 unknowable for
# this harness (returns IMMEDIATELY — never burns the timeout on a question it
# cannot answer).
#
# WHO MAY CALL THIS: only code running OUTSIDE the turn that submitted the
# /compact. A `/self compact` injects into the caller's OWN pane mid-turn, and
# that turn cannot end while a script it launched is still blocking — so an
# in-turn wait for "compaction started" waits for something its own existence
# prevents. The self path therefore arms this wait detached (tmux run-shell -b);
# see skills/self/scripts/self-compact-ping.sh.
#
# The done-baseline is taken HERE rather than accepted as an argument so that no
# caller can pass a stale one, and it is deliberately taken AFTER the /compact
# has been submitted: a `Compacted` line on screen at that instant belongs to an
# EARLIER compaction, which is precisely what must not count.
tap_wait_compaction() {
  local pane="$1" harness="$2" timeout="$3" poll="${4:-0.5}" deadline base now cur prev
  base="$(tap_compaction_chrome_count "$pane" "$harness" done)" || return 2
  prev="$(tap_compaction_chrome_lines "$pane" "$harness" inflight)"
  deadline="$(( $(date +%s) + timeout ))"
  while [ "$(date +%s)" -le "$deadline" ]; do
    sleep "$poll"
    # THE TICK. Chrome is rewritten in place about once a second; the live
    # capture caught 109 distinct frames in one compaction. Quoted text does not
    # tick. Requiring a CHANGE between two consecutive observations is therefore
    # a predicate over two instants, and no static content can satisfy it —
    # whatever glyph, bullet, blockquote or verbatim specimen it uses. That is
    # the property; the smoke asserts it by holding the worst content still
    # rather than by enumerating adversarial lines, because enumeration is what
    # failed twice here already.
    cur="$(tap_compaction_chrome_lines "$pane" "$harness" inflight)"
    if [ -n "$cur" ] && [ -n "$prev" ] && [ "$cur" != "$prev" ]; then return 0; fi
    prev="$cur"
    # The done arm was always a delta and was never fooled by a quoted specimen;
    # it also covers a compaction too short to show two distinct in-flight
    # frames, which is the one thing the tick alone would miss.
    now="$(tap_compaction_chrome_count "$pane" "$harness" done)"
    [ "$now" -gt "$base" ] && return 0
    tap_pane_alive "$pane" >/dev/null 2>&1 || return 1
  done
  return 1
}

# tap_compact_focus_narrowing <text> — the exclusive/destructive-phrasing gate
# for a /compact focus, in ONE place both the self path and the peer path call
# (tap-thgv). Prints the first offending phrase and returns 0 when the text
# narrows; returns 1 when it is clean.
#
# A focus SUPPLEMENTS the default summarizer. The one known way it degrades the
# summary is exclusive phrasing, which deprioritizes every thread the author did
# not happen to mention; the one way it corrupts the summary is directing the
# summarizer to drop material. The list is a backstop for the doctrine in
# skills/self/SKILL.md, not exhaustive coverage — known gaps are accepted.
#
# It lives here because it used to live in self.sh alone, which made the guard
# real for a seat compacting itself and a matter of prose discipline for the
# same text aimed at a teammate — an asymmetry no caller could see a reason for.
#
# Word-boundary matched against the lowercased text, never plain substring:
# substring matching over-fires on ordinary session vocabulary ("only once" ⊃
# "only on", "gitignore" ⊃ "ignore", "registry to" ⊃ "try to"), and a false
# positive strands a legitimate focus, since callers are told never to route
# around the gate. Non-alnum characters in a phrase are escaped for the ERE.
tap_compact_focus_narrowing() {
  local _text="${1-}" _lower _phrase _esc
  [ -n "$_text" ] || return 1
  _lower="$(printf '%s' "$_text" | tr '[:upper:]' '[:lower:]')"
  for _phrase in "focus only" "only on" "solely" "exclusively" "nothing else" \
                 "ignore" "discard" "forget about" "drop everything" \
                 "don't keep" "do not keep" "leave out" "omit"; do
    _esc="$(printf '%s' "$_phrase" | sed 's/[^[:alnum:] ]/\\&/g')"
    if printf '%s' "$_lower" | grep -Eq "(^|[^[:alnum:]])${_esc}(\$|[^[:alnum:]])"; then
      printf '%s' "$_phrase"
      return 0
    fi
  done
  return 1
}

tap_pane_harness_command() {
  local pane="$1" fallback="${2:-}" pane_pid detected record state fallback_family fallback_class
  fallback_family="$(tap_harness_family "$fallback")"
  fallback_class="$(tap_classify_harness "$fallback_family")"
  case "$fallback_class" in
    agent|denylist)
      # Known agent/denylist family from the shallow command — trust it, skip the walk.
      printf '%s' "$fallback_family"
      return 0 ;;
    # unsupported: ALWAYS attempt the process observation below. A shallow command like
    # "node" (cursor-agent) or a version string is not classifiable on its own; the
    # pane root or its foreground process-group leader resolves the real harness.
    # Fall back to the family only when the observation finds nothing.
  esac
  pane_pid="$(tmux display-message -p -t "$pane" '#{pane_pid}' 2>/dev/null || true)"
  if [ -n "$pane_pid" ]; then
    record="$(tap_process_harness_observation "$pane_pid")"
    IFS=$'\x1f' read -r state detected <<< "$record"
    [ "$state" = observed ] || detected=""
  fi
  if [ -n "${detected:-}" ]; then
    printf '%s' "$detected"
  else
    printf '%s' "$fallback_family"
  fi
}

# tap_settle <seconds> — a TUI-settle delay: fixed waits that let a live
# pane redraw/commit before the courier re-reads it (inject-land retries,
# submit render, C-u clear, copy-mode cancel, urgent-interrupt beat).
# TAP_TUI_SETTLE_SCALE (default 1 = exactly the historical sleeps) scales
# every settle; smoke tests running against the synchronous mock tmux opt
# into 0.1 because a mock has no redraw race to wait out (measured: the
# suite pays ~90s of settle sleeps against mocks — PR #xxx report).
# Timeout SEMANTICS (e.g. the watch evaluator deadline) never route through
# here: scaling must never reorder a timeout race. Scale must be a plain
# decimal in [0.01, 10] — anything else (junk, 0, huge, exponents, locale
# commas) warns once per process and runs unscaled, fail-safe to production
# timing. A VALID non-1 scale also announces itself once per process
# (grok, PR #xxx): a smoke scale leaked into a live sender's environment
# must be audible, never a silent shrink of the tap-dl3 second-Enter beat.
# LC_ALL=C on the awk: EU locales print "0,025", which sleep rejects.
tap_settle() {
  local d="$1" s="${TAP_TUI_SETTLE_SCALE:-1}" scaled=""
  if [ "$s" != 1 ] && [ "$s" != 1.0 ]; then
    case "$s" in
      ''|.|*[!0-9.]*|*.*.*) ;;   # syntactic junk -> warn arm below
      *)
        scaled="$(LC_ALL=C awk -v d="$d" -v s="$s" \
          'BEGIN { s += 0; if (s >= 0.01 && s <= 10) printf "%.3f", d * s }')"
        ;;
    esac
    if [ -n "$scaled" ]; then
      if [ "${_TAP_SETTLE_NOTED:-}" != 1 ]; then
        echo "tap: TUI settle scale $s active (mock-smoke knob; production runs unset/1)" >&2
        _TAP_SETTLE_NOTED=1
      fi
      d="$scaled"
    elif [ "${_TAP_SETTLE_WARNED:-}" != 1 ]; then
      echo "tap: invalid TAP_TUI_SETTLE_SCALE='$s' (need a decimal in [0.01, 10]) -> running unscaled" >&2
      _TAP_SETTLE_WARNED=1
    fi
  fi
  sleep "$d"
}

# Subshell deliberately scopes the mutex EXIT trap; this helper returns no caller variables.
tap_exit_copy_mode() (
  local pane="$1" registry="${2:-}" handle="${3:-}" pane_id="${4:-}"
  local rowless_session="${5:-}" rowless_harness="${6:-}" attempt_ids="${7:-}" mode
  local TAP_DELIVERY_EFFECT_STARTED=0 TAP_DELIVERY_ATTEMPT_IDS="$attempt_ids"
  mode="$(tmux display-message -p -t "$pane" '#{pane_in_mode}' 2>/dev/null || true)"
  # Empty expansion = the pane is GONE (tmux 3.6a returns rc 0 for dead targets);
  # report pane-gone (3), never a copy-mode defer, so callers suspend the entry.
  if [ -z "$mode" ]; then
    echo "tap: pane '$pane' gone (empty tmux expansion) -> human-relay" >&2
    return 3
  fi
  [ "$mode" = "0" ] && return 0
  tap_pane_submit_lock "${pane_id:-$pane}" || { tap_pane_submit_unlock; return 4; }
  trap tap_pane_submit_unlock EXIT
  local recovery_state
  recovery_state="$(tap_bun_call recovery "$handle" recovery/cli.ts guard "${pane_id:-$pane}")" || recovery_state=park
  [ "$recovery_state" = allowed ] || { echo "tap: recovery owns pane '$pane' -> park" >&2; return 4; }
  # The pane-mode probe above is observational but still leaves a race window.
  # Re-authorize at the actual effect boundary so a binding that changes after
  # the caller's preflight cannot receive even the copy-mode cancel.
  tap_submit_identity_guard "$registry" "$handle" "$pane" "$pane_id" \
    "$rowless_session" "$rowless_harness" || return 6
  [ "${TAP_SUBMIT_PERMISSIONS:-bypass}" != auto ] || return 4
  if [ -n "$attempt_ids" ]; then
    tap_delivery_effect_begin "${attempt_ids%% *}" || return 8
  fi
  tmux send-keys -t "$pane" -X cancel || {
    [ "$?" != 124 ] || return 124
    echo "tap: pane '$pane' in copy-mode and cancel failed -> defer" >&2
    return 4
  }
  tap_settle 0.05
  mode="$(tmux display-message -p -t "$pane" '#{pane_in_mode}' 2>/dev/null || true)"
  if [ -z "$mode" ]; then
    echo "tap: pane '$pane' gone after copy-mode cancel -> human-relay" >&2
    return 3
  fi
  [ "$mode" = "0" ] || {
    echo "tap: pane '$pane' stayed in copy-mode after cancel -> defer" >&2
    return 4
  }
  [ -z "$attempt_ids" ] || printf '%s\n' effect
)

# --- per-harness input-band capture + submit-verify ---------------------------
# Shared primitives for injecting a sentinel and verifying it submitted. Called
# by both tap-send.sh (courier) and future harness-self helpers. ONE implementation,
# never reimplemented per caller. See CONTRACT.md §Submit-verify helper.
#
# The opencode lesson (verified live, Fusion ground truth): key on the ACTIVE input
# band / sentinel id clearing from the input line — NEVER on footer text or a tail-N
# of rendered history. On opencode a naive tail/footer match false-matches against
# rendered history forever; use Claude’s [›❯] or Codex’s [›❯»] input line.

# tap_prompt_glyph_re <pane_cmd>
# The prompt-glyph char class for a harness's input line, in ONE place so the glyph
# match sites can't drift. Default harnesses prompt with › or ❯; cursor-agent uses →
# (U+2192). Returns a bracket expression usable in grep -E / awk / sed -E / python re.
# (→ is multibyte UTF-8; the sites interpolate this verbatim, matching the existing
# bracket-class approach, so byte handling is identical to the prior hardcoded [›❯].)
tap_prompt_glyph_re() {  # $1=pane_cmd
  case "${1:-}" in
    cursor*) printf '[›❯→]' ;;
    codex*)  printf '[›❯»]' ;;
    agy*)    printf '>' ;;   # Antigravity/Gemini: ASCII '>' band prompt (bottom-anchored; see tap_agy_box_text)
    *)       printf '[›❯]' ;;
  esac
}

# Input-band whitespace explicitly includes U+00A0 (UTF-8 C2 A0). glibc
# excludes NBSP from POSIX space; keep this aligned with glyph_strip below.
# The literal NBSP in these bracket expressions is intentional.
# tap_prompt_line_re <pane_cmd>
# Full anchored prompt-line regex. Hermes named profiles prefix the idle glyph
# with a token ("ops-hermes ❯"); keep that prefix charset-locked so the
# working "⚕ ❯ ..." prompt never reads idle.
tap_prompt_line_re() {  # $1=pane_cmd
  case "${1:-}" in
    hermes*) printf '^[[:space:] ]*([A-Za-z0-9._-]+ )?[›❯]' ;;
    *)       printf '^[[:space:] ]*%s' "$(tap_prompt_glyph_re "${1:-}")" ;;
  esac
}


# tap_queue_prefix <pane_cmd>
# Per-harness SAFE QUEUE PREFIX (delivery-policies plan, docs/plans/2026-07-08-001).
# Hermes is the only harness whose default mid-turn behavior is INTERRUPT; its
# '/queue <prompt>' form queues safely even mid-turn (Ops live-verified 2026-07-08).
# A harness with a non-empty prefix takes queue-prefix delivery: the courier
# prepends the prefix to the sentinel and skips the no-input-prompt defer — the
# harness's own queue is the turn-boundary buffer. Every other harness queues
# typed input natively, so no prefix is needed (empty output). This is the
# "default = always inject, always queue" policy; the rc-3 defer remains for
# non-prefix harnesses only as the modal-dialog guard (a chooser/permission
# dialog has no input band, and injected Enter would press its buttons).
tap_queue_prefix() {  # $1=pane_cmd
  case "${1:-}" in
    hermes*) printf '/queue ' ;;
  esac
}

# tap_interrupt_seq <pane_cmd>
# Per-harness URGENT INTERRUPT KEYSTROKE (delivery-policies plan, PR-B), live-
# verified by Ops 2026-07-08: sent BEFORE the payload, never after (post-payload
# interrupt behavior varies by harness; pre-payload Escape is uniform). Prints
# space-separated `tmux send-keys` key names, empty meaning "no keystroke needed".
# Hermes is the exact inverse of every other harness here: its default (queued)
# delivery takes the `/queue ` prefix from tap_queue_prefix above, so its bare,
# un-prefixed inject already IS the interrupt — sending Escape first would only
# risk clobbering in-flight input for no reason. tap_submit_verify is the ONLY
# caller (never re-implement the send-keys call at a second site): it forces the
# queue prefix off when urgent, sends this sequence, then falls through to the
# same paste/verify path default policy already uses.
# By construction this is only ever called with a pane already classified
# 'agent' by tap_classify_harness (denylist/unsupported panes terminal-defer
# before urgent-specific code runs — CONTRACT §Delivery policies), so every
# case below is one of the five known harness families; there is no unmatched-
# fallthrough case to guard against a silently-empty (wrongly no-op) sequence.
tap_interrupt_seq() {  # $1=pane_cmd
  case "${1:-}" in
    opencode*) printf 'Escape Escape' ;;
    # agy joins the Escape families at tap-92v3r, and it is a REPAIR the readiness
    # change forced rather than an unrelated addition. agy had no arm here, which was
    # survivable only because the footer gate refused a generating agy pane outright:
    # an urgent send to a working seat deferred, so nothing ever asked what its
    # interrupt keystroke was. Making the pane injectable removes that accident, and
    # without this line urgent would type into the queue while `tap send` printed
    # "urgent — interrupting" — a claim the code no longer performed. Ops verified the
    # keystroke by hand on a live seat, 2026-09-03: entering a message during
    # generation QUEUES it, and Escape is what interrupts.
    claude*|codex*|agy*) printf 'Escape' ;;
    cursor*) printf 'C-c' ;;
    hermes*) : ;;
  esac
}


# --- opencode input box (v1.17+ layout) ----------------------------------------
# The OpenCode input box is the run of consecutive '┃'-bordered lines sitting
# DIRECTLY ABOVE the last '╹▀' bottom border. Anchor on that geometry, never on a
# '▣ Build' header: since 1.17 the '▣ Build · <model> · <t>s' line is a per-turn
# TRANSCRIPT marker (it can scroll off entirely when the box content wraps tall),
# not a box header. Older layouts keep a header above the box, which this anchor
# simply ignores — one rule covers both.

# tap_opencode_prompt_ready — stdin: plain pane capture. Returns 0 when the input
# box is present and its status row has no working indicator, 1 when the box is
# present with an active `esc interrupt` marker, and 3 when the box is absent.
# The third state distinguishes startup chrome from a generating pane: both are
# not ready, but only the latter is demonstrably working.
tap_opencode_prompt_ready() {
  awk '
    { line[NR] = $0; if ($0 ~ /^[[:space:] ]*╹▀/) border = NR }
    END {
      if (!border) exit 3
      if (line[border - 1] !~ /^[[:space:] ]*┃/) exit 3
      for (i = border + 1; i <= NR; i++) if (line[i] ~ /esc interrupt/) exit 1
      exit 0
    }'
}

tap_cursor_prompt_ready() {
  # Use index(), not a regex: awk's '+' is a quantifier. Exit only from END.
  awk '
    { line[NR] = $0 }
    END {
      last = NR
      while (last > 0 && line[last] ~ /^[[:space:] ]*$/) last--
      if (!last) exit 0
      lo = last - 11; if (lo < 1) lo = 1
      for (i = lo; i <= last; i++)
        if (index(line[i], "ctrl+c to stop")) exit 1
      exit 0
    }
  '
}

# --- Antigravity / Gemini (agy) input band (v1.1.x layout) ---------------------
# The agy input band is a '>' prompt line bracketed by two full-width '─' rule
# lines, with a status footer BELOW the bottom rule: '? for shortcuts' (left) +
# 'Gemini <model> · <effort>' (right) when idle, or 'esc to cancel' + a
# '⣷ Generating...' spinner when the agent is mid-turn. Two agy-specific facts
# drive detection, both learned from live %229 captures (fixture-realism, tap-luae):
#   1. The '>' band STAYS on screen while generating (unlike claude, which hides
#      its prompt). That is what makes agy INJECTABLE mid-turn: Ops verified by
#      hand on a live seat (tap-92v3r, 2026-09-03) that typing into the Antigravity
#      TUI during generation QUEUES the message, exactly as Claude Code and Codex
#      do, and that Escape is what interrupts. So readiness is BAND PRESENCE minus a
#      recognized permission modal — never the footer's turn vocabulary — and
#      ordinary delivery types into the queue.
#
#      The modal exception is not a hedge; it is the one thing the old rule was
#      doing right, kept deliberately. See tap_agy_permission_overlay for why
#      geometry alone cannot carry it: this TUI renders content BELOW the band, so
#      an overlay drawn like a task card would leave the rule pair intact.
#
#      This is the CORRECTED rule. The original one gated readiness on the footer
#      ('? for shortcuts' present, 'esc to cancel'/'Generating' absent) by analogy
#      with opencode's 'esc interrupt' gate, and that analogy was wrong twice over.
#      Antigravity renders a running subagent's or command's output BELOW the input
#      line — a third full-width rule and a task card sit between the band and the
#      footer — so a working seat with a perfectly usable band read as no-prompt.
#      Live capture of tap/gemini-roster-runner mid-tool-loop, 2026-09-03:
#
#          ⣽  Working...
#          ────────────────────────────────  <- band top rule
#          >                                 <- the band, empty and ready
#          ────────────────────────────────  <- band bottom rule / task card top
#            ● [00:46:22] bun test runtime/bun/test/team.test.ts running
#          ────────────────────────────────
#          esc to cancel        Gemini 3.8 Flash · high · 1 task(s) · /tasks
#
#      The courier deferred that pane, held the payload for its 300s deadline, and
#      told the sender it would never arrive — for a seat that was one send-keys
#      away the whole time. tap_agy_box_text already located that band correctly,
#      including the third-rule case, so the information was in hand and the footer
#      gate discarded it.
#   2. Submitted user messages echo into the TRANSCRIPT also prefixed with '>', so a
#      naive first-/any-'>' match hits a stale echo. Anchor to the LIVE bottom render
#      (the bottom-most rule pair), never scrollback (repurposed panes also carry an
#      old 'agy --conversation=<uuid>' exit banner). Same render-position-anchor rule
#      tap-commander set for cursor.

# Native recognized survey tail, not transcript/composer keyword matching.
tap_agy_survey_overlay() {
  local result
  result="$(tap_bun_call agy-survey-overlay frame submit-frame.ts agy-survey-overlay)" || return 1
  [ "$result" = yes ]
}

# Shared native modal reader; runtime/shape failure refuses before any pane effect.
# Native policy preserves the positional/task-card guards and provisional window.
tap_agy_permission_overlay() {
  local result
  result="$(tap_bun_call agy-permission-overlay frame submit-frame.ts agy-permission-overlay)" || return 0
  case "$result" in
    yes) return 0 ;;
    no) return 1 ;;
    *) printf 'tap: slice_failed id=frame slice=agy-permission-overlay: invalid result\n' >&2; return 0 ;;
  esac
}

# tap_agy_seat_in_turn is GONE (A3a): the agy focus read is now a branch of
# spool-readiness.ts's readiness walk, which reads the same last-rendered-line footer
# from the frame the walk asks for. Its rationale travels with the port.

# Shared Antigravity prompt-pair geometry excludes footer and task-card chrome.
# Permission/modal policy remains with the readiness caller, not this reader.
tap_agy_box_text() {
  tap_bun_call agy-composer frame submit-frame.ts agy-composer || return 3
}

tap_agy_reprobe_input_matches() { # <expected>; stdin: localized AGY composer
  [ "$(tap_bun_call agy-reprobe-match frame submit-frame.ts agy-reprobe-match "$1")" = yes ]
}

# tap_inputline <pane> <pane_cmd>
# Capture the active input region for <pane>. For opencode: the typed text inside
# the bordered input box (chrome-free — see tap_opencode_box_text). For all other
# harnesses: the last prompt-glyph line (› ❯ →).
# Single joined capture owner for full-id searches and harnesses whose input
# geometry survives tmux soft-wrap joining.
tap_capture_pane() { tmux capture-pane -J "$@"; }

# Input geometry needs physical terminal rows for OpenCode. One observed 1.18.30
# process marked every row wrapped, so `capture-pane -J` collapsed a 63-row pane
# into one line and erased every `┃`/`╹▀` boundary. Other harnesses keep joined
# capture so soft-wrapped sentinel ids remain searchable as one token.
tap_capture_pair() { # <pane> <harness> -> "<bytes-of-escaped>\n<escaped><plain>"
  # THE TWO CAPTURES THE INCUMBENT TOOK, handed over together.
  #
  # The port briefly took ONE escaped capture and let the module derive the plain
  # view with a CSI strip. That is not tmux's plain view: an OSC 8 hyperlink
  # around the prompt row survives the strip, the derived row stops starting with
  # the glyph, and the reader answers rc 3 — absent geometry, the type-over
  # direction — where the incumbent returned the draft. Widening the strip is not
  # the fix; the incumbent's own tap_strip_ansi is the same CSI-only regex, and it
  # never needed more because it never derived.
  #
  # Length-prefixed rather than separated by a sentinel byte: a pane can contain
  # any control character, so no separator is safe. `wc -c` counts BYTES, which is
  # what the module slices by.
  #
  # Capture stays HERE rather than moving into the module: this function's
  # `tap_capture_pane` is a bare `tmux` on the ambient server, while the module
  # resolves TAP_TMUX_SOCKET_PATH/NAME itself. Moving it would change which server
  # is asked, and that is a transport change, not a reader port.
  local _cp_esc _cp_plain _cp_rc=0
  _cp_esc="$( { tap_capture_input_frame "$1" "$2" 1 2>/dev/null; _cp_rc=$?; printf 'X'; exit "$_cp_rc"; } )" || return 1
  _cp_esc="${_cp_esc%X}"
  _cp_plain="$( { tap_capture_input_frame "$1" "$2" 0 2>/dev/null; _cp_rc=$?; printf 'X'; exit "$_cp_rc"; } )" || return 1
  _cp_plain="${_cp_plain%X}"
  printf '%s\n' "$(printf '%s' "$_cp_esc" | wc -c | tr -d ' ')"
  printf '%s%s' "$_cp_esc" "$_cp_plain"
}

tap_capture_input_frame() { # <pane> <harness> [escaped=0]
  local pane="$1" harness="$2" escaped="${3:-0}"
  if [ "${harness##*/}" = opencode ]; then
    if [ "$escaped" = 1 ]; then tmux capture-pane -p -e -t "$pane"
    else tmux capture-pane -p -t "$pane"
    fi
  elif [ "$escaped" = 1 ]; then
    tap_capture_pane -p -e -t "$pane"
  else
    tap_capture_pane -p -t "$pane"
  fi
}

# tap_inputregion <pane> <pane_cmd>
# The active input REGION used for id matching and draft backup: the LAST prompt
# row plus every following row, so a wrapped draft is never truncated to its
# first glyph row. Its row SELECTOR uses a narrower character class than
# `tap_inputline`'s — measured per instrument, not assumed;
# `runtime/bun/src/pane/geometry.ts` carries the table and why they disagree.
tap_inputregion() {
  local _pn_frame _pn_verdict _pn_rc=0
  # THE CAPTURE IS HANDED OVER EXACTLY, trailing newlines included. `$(…)` strips
  # them, and whether that is faithful is PER FUNCTION: `tap_inputregion` and
  # `tap_inputline` piped the capture straight into `awk`/`grep` and kept every
  # byte, while the claude/codex overlay read and `tap_pane_read` went through a
  # substitution and did not. A uniform strip here cost `tap_inputregion` awk's
  # final empty record — one trailing blank row, on 18 of the oracle's cases —
  # so the stripping moved into the module, where it is per function and visible.
  _pn_frame="$( { tap_capture_pair "$1" "$2" 2>/dev/null; printf 'X'; } )"
  _pn_frame="${_pn_frame%X}"
  _pn_verdict="$( { printf '%s' "$_pn_frame" | tap_bun_call pane-inputregion "$1" pane/cli.ts inputregion "$1" "$2"; _pn_rc=$?; printf 'X'; exit "$_pn_rc"; } )" || return 1
  _pn_verdict="${_pn_verdict%X}"
  case "$_pn_verdict" in
    no-band) return 3 ;;
    text$'\x1f'*) printf '%s' "${_pn_verdict#text$'\x1f'}" ;;
    *) printf 'tap: slice_failed id=%s slice=pane-inputregion: invalid verdict\n' "$1" >&2; return 1 ;;
  esac
}

tap_strip_ansi() {
  python3 -B -c 'import re, sys
sys.stdout.write(re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", sys.stdin.read()))'
}

# tap_input_state_from_region <region> <escaped-input> <glyph> <prompt-re> <cmd>
# `empty` | `unsubmitted-sentinel` | `other-text`. A non-empty <escaped-input>
# selects the styled path, which classifies the FIRST ROW ONLY and applies the
# dim-placeholder check; without it the whole region is classified.
tap_input_state_from_region() {
  local _pn_out _pn_rc=0
  _pn_out="$( { tap_bun_call pane-input-state state pane/cli.ts input-state "$1" "${2:-}" "${3:-}" "${4:-}" "${5:-}" </dev/null; _pn_rc=$?; printf 'X'; exit "$_pn_rc"; } )" || return 1
  _pn_out="${_pn_out%X}"
  case "$_pn_out" in
    empty|unsubmitted-sentinel|other-text) printf '%s' "$_pn_out" ;;
    *) printf 'tap: slice_failed id=state slice=pane-input-state: invalid verdict\n' >&2; return 1 ;;
  esac
}



tap_pane_read() {  # <pane> <pane_cmd> [handle] -> prints input_state header + transcript
  local _pn_frame _pn_out _pn_rc=0
  # THE CAPTURE IS HANDED OVER EXACTLY, trailing newlines included. `$(…)` strips
  # them, and whether that is faithful is PER FUNCTION: `tap_inputregion` and
  # `tap_inputline` piped the capture straight into `awk`/`grep` and kept every
  # byte, while the claude/codex overlay read and `tap_pane_read` went through a
  # substitution and did not. A uniform strip here cost `tap_inputregion` awk's
  # final empty record — one trailing blank row, on 18 of the oracle's cases —
  # so the stripping moved into the module, where it is per function and visible.
  _pn_frame="$( { tap_capture_pair "$1" "$2" 2>/dev/null; printf 'X'; } )"
  _pn_frame="${_pn_frame%X}"
  _pn_out="$( { printf '%s' "$_pn_frame" | tap_bun_call pane-read "$1" pane/cli.ts pane-read "$1" "$2" "${3:-}" "${TAP_PEEK_JSON:-0}"; _pn_rc=$?; printf 'X'; exit "$_pn_rc"; } )" || return 1
  # Raw bytes either way: the module terminates its JSON object as `print` did,
  # and the human view's transcript rows carry their own newlines.
  printf '%s' "${_pn_out%X}"
}

tap_registry_agent_json() {  # <handle>
  local handle="$1" reg
  reg="$(tap_acting_registry || true)"
  [ -n "$reg" ] && [ -f "$reg" ] || return 1
  python3 -B - "$reg" "$handle" "${_TAP_SCRIPT_DIR}" <<'PY'
import json, sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import _seat_map, load_state_doc
try:
    reg = load_state_doc(sys.argv[1])
except Exception:
    sys.exit(1)
ent = _seat_map(reg).get(sys.argv[2])
if not isinstance(ent, dict):
    sys.exit(1)
print(json.dumps(ent, separators=(",", ":")))
PY
}

# tap_registry_active_pane <handle> -> 0 iff <handle> is a registered, ACTIVE,
# delivery!=poll member with a non-empty pane — a genuinely dischargeable reply
# target right now. 1 for an absent handle, a poll member, a suspended entry, or
# a pane-less/legacy-blank pane field. A suspended or pane_gone armer cannot
# discharge a reply (CONTRACT.md §Registry: "only active entries are delivery
# targets"), so this is the ONE gate both tap-send.sh's on-behalf-of
# reply-expectation grant and tap-escalate.sh's --from anchor validation share —
# never reimplemented per-caller, so they can't drift (codex P1).
tap_registry_active_pane() {
  local handle="$1"
  tap_registry_agent_json "$handle" 2>/dev/null | python3 -B -c '
import json, sys
try:
    ent = json.load(sys.stdin)
except Exception:
    sys.exit(1)
if ent.get("delivery") == "poll":
    sys.exit(1)
if ent.get("status", "active") != "active":
    sys.exit(1)
if ent.get("status_reason") == "launching":
    sys.exit(1)
sys.exit(0 if ent.get("pane") else 1)
'
}

# tap_registry_dischargeable <handle> -> 0 iff <handle> is a registered, ACTIVE
# member capable of receiving a reply RIGHT NOW: an active pane member (see
# tap_registry_active_pane) OR an active delivery:poll member (it discharges by
# polling). Used by tap-escalate.sh's --from anchor validation — broader than
# tap_registry_active_pane, which tap-send.sh's on-behalf-of grant deliberately
# keeps pane-only (a poll FROM's reply-expectation is the separate
# --expect-reply carve-out there, not this grant).
tap_registry_dischargeable() {
  local handle="$1"
  tap_registry_active_pane "$handle" && return 0
  [ "$(tap_delivery_class "$handle")" = "poll" ] || return 1
  tap_registry_agent_json "$handle" 2>/dev/null | python3 -B -c '
import json, sys
try:
    ent = json.load(sys.stdin)
except Exception:
    sys.exit(1)
sys.exit(0 if ent.get("status", "active") == "active" and ent.get("status_reason") != "launching" else 1)
'
}

tap_registry_unattended() {  # <handle>
  local handle="$1"
  tap_registry_agent_json "$handle" 2>/dev/null | python3 -B -c '
import json, sys
try:
    ent = json.load(sys.stdin)
except Exception:
    sys.exit(1)
sys.exit(0 if ent.get("unattended") is True else 1)
'
}

# tap_registry_reply_to <handle> — echoes the seat's stored reply_to (register
# --reply-to), or nothing if unset/handle unknown. Always exits 0. Used by
# tap-send.sh to auto-stamp reply_to on a plain send from a seat that
# registered one (tap-ywb design point 4), same shape as reading unattended.
tap_registry_reply_to() {  # <handle>
  local handle="$1"
  tap_registry_agent_json "$handle" 2>/dev/null | python3 -B -c '
import json, sys
try:
    ent = json.load(sys.stdin)
except Exception:
    sys.exit(0)
v = ent.get("reply_to")
if isinstance(v, str) and v:
    print(v)
' || true
}

# tap_registry_sender_facts <handle> — ONE registry read returning every send-time
# fact about the --from seat that tap-send.sh's sender gate needs, as a single
# \x1f-delimited line: <delivery>\x1f<active_pane 0|1>\x1f<dischargeable 0|1>\x1f<unattended 0|1>.
# This is a LATENCY consolidation (tap-8wl): PR 22 (ProtocolDiscipline) dropped the
# self-handle hot-path guard for correctness, after which every send forked python3
# ~6-8 times over the SAME registry for the SAME handle (tap_delivery_class +
# tap_registry_active_pane + tap_registry_dischargeable + tap_registry_unattended,
# each re-parsing registry.json). Semantics here are IDENTICAL to those four helpers
# (which remain the single source of truth for escalate/reply's own call sites — this
# is a same-logic fast path, never a fork of the rules): delivery = the entry's
# delivery if in {pane,poll} else pane (absent registry/entry -> pane); active_pane =
# active + delivery!=poll + non-empty pane; dischargeable = active_pane OR an active
# poll seat; unattended = the entry's unattended flag is exactly True. Always exits 0
# and prints exactly one line so the caller can `IFS=$'\x1f' read` it fork-free.
# tap_unregistered_sender_next <handle> — the `next:` command for the
# unregistered_sender refusal, fitted to the caller it is talking to. Also sets
# TAP_UNREGISTERED_SENDER_DETAIL, so the prose and the command can never
# describe different audiences.
#
# WHY THIS IS NOT A CONSTANT (tap-hgzj, P0). The refusal used to hardcode
# `tap register <handle> --delivery poll`. Its prose named the intended audience
# — pane-less daemons and scripts — but PROSE IS NOT WHAT AN AGENT COPIES. On
# 2026-08-19 a launcher-managed seat sitting in a live pane followed the command,
# became a poll seat holding a pane, and for 95 minutes eight sends from two
# senders wrote success receipts into a mailbox nobody read. Poll mode then
# exempted it from every liveness check, so the one state that guarantees a live
# seat receives nothing is the one state that hides it from the census.
#
# A hint is executable prose: it is copied and run verbatim. So it is computed
# per caller and asserted as behavior.
#
# FAIL-CLOSED DIRECTION. tap_calling_pane_id returns 0 only for a positively
# observed `inside`; `outside` and `unobservable` both keep the poll hint,
# because those are the daemons and scripts the original prose was written for.
# An unobservable caller therefore gets today's answer, unchanged.
#
# WHY THE HANDLE IS ALWAYS NAMED EXPLICITLY, AND WHY --force IS NOT THE COMMAND.
# Plain `tap in` DERIVES the handle from the session, and a derived name is the
# one form the collision ladder refuses against an active poll incumbent
# (tap-register.sh: a poll row is occupied by declaration, so a derived handle
# never silently rebinds a daemon's seat). It mints `<handle>-2` and leaves the
# poll row still holding the address every other seat writes to — the seat
# becomes MORE unreachable, under a name nobody uses. That is what happened on
# 2026-08-19 after the first hint was followed.
#
# NAMING THE HANDLE is itself the documented authorization for the poll->pane
# conversion, so `tap in <handle>` is the whole cure for that case and it is what
# the command says. --force is deliberately NOT in the command: when the
# incumbent is an active PANE seat on someone else's pane, forcing takes a live
# teammate's address, and a remedy line is copied without reading. It rides the
# prose instead, where a reader who sees `-2` minted can reach for it knowingly.
# CALL IT WITH AN OUTPUT VARIABLE, not in a command substitution: the detail is
# a second return value, and `$( ... )` runs the function in a SUBSHELL, so the
# assignment dies with it and a `set -u` caller reads an unbound variable. Same
# footgun class as TAP_SUBMIT_DEFER_REASON (tap-r49z) — a marker set by a
# function is only visible to a caller that stayed in the same shell. The
# printing form is kept for tests and for callers that want only the command.
# tap_acting_registry_seat_state -> 0 the acting registry holds at least one seat
#                                   1 it is READABLE and holds none
#                                   2 it is absent or unreadable
#
# The three-way split is load-bearing and a two-way one was WRONG (grok, unit-2
# review). "No seats" has two very different causes:
#
#   absent/unreadable  a DECOY bus. `.tap/.gitignore` is a tracked file, so every
#                      git worktree carries a `.tap/` directory and anchors a bus
#                      that no one ever wrote to. Registering here splits the
#                      seat's identity away from its real team.
#   readable, empty    a REAL team bus with nobody on it yet — immediately after
#                      `tap team reset` or `tap init`, whose own next-line is
#                      `tap in`. Telling that caller "pass --team" cannot progress
#                      and contradicts the instruction reset just printed.
tap_acting_registry_seat_state() {
  local reg
  reg="$(tap_acting_registry || true)"
  [ -n "$reg" ] && [ -f "$reg" ] || return 2
  python3 -B - "$reg" "${_TAP_SCRIPT_DIR}" <<'SEATS' >/dev/null 2>&1
import sys
sys.path.insert(0, sys.argv[2])
from registry_v20 import _seat_map, load_state_doc
try:
    seats = _seat_map(load_state_doc(sys.argv[1]))
except Exception:
    sys.exit(2)          # unreadable is a decoy, not an empty team
sys.exit(0 if isinstance(seats, dict) and seats else 1)
SEATS
}

tap_unregistered_sender_next() {  # <handle> [next-var]
  local handle="$1" out_var="${2:-}" _pane="" _next="" _seat_state=0 _team=""
  if tap_calling_pane_id _pane; then
    # CAPTURE THE STATUS IN A `set -e`-SAFE POSITION. Callers run under
    # `set -euo pipefail` (tap-send.sh does), and a bare call to a function
    # that returns non-zero is a failing SIMPLE COMMAND — it aborts the shell
    # before the assignment happens. The two states this predicate added are
    # exactly the two that return non-zero, so the remedy this whole lane is
    # about would never print: the send would die silently with no
    # unregistered_sender line at all, which is worse than the wrong hint.
    _seat_state=0; tap_acting_registry_seat_state || _seat_state=$?
    if [ "$_seat_state" = 2 ]; then
      # An empty bus with a live pane in front of it is a CWD diagnosis, not
      # an identity one, and it is checked FIRST because both identity answers
      # are wrong here — the pane-derived one most of all. Registering would
      # bind this pane into the worktree's own empty bus, splitting the seat's
      # identity while every teammate keeps writing to the real one: a silent
      # mailbox traded for a split identity. Found by reproducing tap-hgzj on
      # the lane fixing it, from a lane worktree.
      TAP_UNREGISTERED_SENDER_DETAIL="no seats are registered on the bus this cwd resolves to, so this is almost certainly not the bus $handle belongs to — every git worktree carries a .tap/ directory and is therefore an empty bus anchor. Pass --team <team> to name the bus, or run this from the team's worktree. Do NOT register here: it would bind this pane to the wrong bus while other seats keep writing to the right one"
      # Fill the placeholder when the pane can answer it. A launcher-managed
      # seat sits in a session named `<team>/<handle>`, so the team is knowable
      # from the same pane we just resolved — and a remedy the reader can paste
      # is the entire point of this lane. Anything that does not look like
      # `team/handle` (a fake tmux, an unnamed session) leaves the placeholder.
      _team="$(tmux display-message -p -t "$_pane" '#{session_name}' 2>/dev/null || true)"
      case "$_team" in
        */*) _team="${_team%%/*}" ;;
        *)   _team="" ;;
      esac
      case "$_team" in *'#'*|'') _team="<team>" ;; esac
      _next="tap send <to> --from $handle --team $_team"
      if [ -n "$out_var" ]; then printf -v "$out_var" '%s' "$_next"; else printf '%s' "$_next"; fi
      return 0
    fi
    if tap_registry_agent_json "$handle" >/dev/null 2>&1; then
      TAP_UNREGISTERED_SENDER_DETAIL="'$handle' is not an active sender on this team and a registry row already holds that handle; naming the handle explicitly is what authorizes reclaiming it. If the registration reports it minted '$handle-2', the incumbent row is STILL holding the address other seats write to — 'tap in $handle --force' reclaims it, and is only safe once you know the incumbent is not a live teammate. --delivery poll is for pane-less daemons and scripts: a poll seat with a pane receives nothing while reporting success"
      _next="tap in $handle"
    else
      TAP_UNREGISTERED_SENDER_DETAIL="'$handle' is not an active sender on this team; this caller is in a live pane, so register from the pane itself. --delivery poll is for pane-less daemons and scripts, and a poll seat with a pane receives nothing while reporting success"
      _next="tap in $handle"
    fi
    if [ -n "$out_var" ]; then printf -v "$out_var" '%s' "$_next"; else printf '%s' "$_next"; fi
    return 0
  fi
  TAP_UNREGISTERED_SENDER_DETAIL="'$handle' is not an active sender on this team; pane-less daemons/scripts must register a stable poll seat, then pass --team on send when cwd is unanchored"
  _next="tap register $handle --delivery poll [--team <team>]"
  if [ -n "$out_var" ]; then printf -v "$out_var" '%s' "$_next"; else printf '%s' "$_next"; fi
}

tap_registry_sender_facts() {  # <handle>
  local reg
  reg="$(tap_acting_registry || true)"
  python3 -B - "${reg:-/dev/null}" "$1" "${_TAP_SCRIPT_DIR}" "$(tap_server_epoch_now 2>/dev/null || true)" "$(tap_boot_id 2>/dev/null || true)" "$(tap_boot_epoch_id 2>/dev/null || true)" <<'PY'
import os, sys
sys.path.insert(0, sys.argv[3])
from registry_v20 import _seat_map, load_state_doc
path, handle = sys.argv[1], sys.argv[2]
reg = None
if os.path.exists(path):
    try:
        reg = load_state_doc(path)
    except Exception:
        reg = None
ent = None
if isinstance(reg, dict):
    cand = _seat_map(reg).get(handle)
    if isinstance(cand, dict):
        ent = cand

raw_delivery = (ent.get("delivery") if ent else None) or "pane"
delivery = raw_delivery if raw_delivery in ("pane", "poll") else "pane"
active = (
    bool(ent)
    and ent.get("status", "active") == "active"
    and ent.get("status_reason") != "launching"
)
active_pane = bool(active and ent.get("delivery") != "poll" and ent.get("pane"))
# Legacy rows may lack socket provenance and therefore stay unmodified during
# reconciliation. They still cannot authorize a sender from a known old epoch.
now_epoch, now_boot, legacy_boot = sys.argv[4:7]
if active_pane:
    epoch, boot = ent.get("server_epoch") or "", ent.get("boot_id") or ""
    # The boot predicate is the BOOLEAN observation one, reached through the Bun
    # engine's own door -- not lib.sh's tap_boot_ids_match, which is three-valued
    # and rejects equal-but-malformed stamps before comparing. Routing here to
    # the Bash twin would silently tighten a different contract.
    boot_stale = False
    if boot and now_boot:
        import subprocess
        # Three states cross this boundary -- match, differ, and "could not
        # run" -- and this program decides none of them. The verdict is the
        # TOKEN the door prints: reading `returncode != 0` conflated a stale
        # boot with a Bun that never answered, and a valid sender was then told
        # it is unregistered and should reclaim its own handle (tap-qa6e2).
        # stdout and stderr are captured rather than discarded, because the
        # unobservable arm has to carry its diagnostic somewhere.
        proc = subprocess.run(
            ["bun", os.path.join(sys.argv[3], "..", "..", "..", "runtime", "bun", "src", "observe.ts"),
             "--boot-ids-match", boot, now_boot, legacy_boot,
             "1" if "TAP_BOOT_ID" in os.environ else "0",
             "1" if "TAP_BOOT_ID_LEGACY" in os.environ else "0"],
            capture_output=True, text=True)
        # BOTH signals, and neither alone. The token says a verdict was
        # computed; the status says the process that computed it finished. A
        # child that prints `boot-ids:differ` and then dies still mapped an
        # execution failure onto predicate-false when only the token was read
        # (sol-pinnacle-3, U0-F1) -- the same defect one layer in. This is not
        # a decision about what a non-zero status MEANS: any disagreement
        # between the two is the third state, which the reader reports rather
        # than resolves.
        verdict = (proc.stdout or "").strip()
        if proc.returncode != 0 or verdict not in ("boot-ids:match", "boot-ids:differ"):
            diag = ((proc.stderr or "").strip().splitlines() or [""])[-1]
            sys.stderr.write("tap: boot-id predicate did not answer (exit %s, said %r): %s\n"
                             % (proc.returncode, verdict, diag))
            raise SystemExit(2)
        boot_stale = verdict == "boot-ids:differ"
    if (epoch and now_epoch and epoch != now_epoch) or boot_stale:
        active_pane = False
dischargeable = bool(active_pane or (active and ent.get("delivery") == "poll"))
unattended = bool(ent and ent.get("unattended") is True)

print("\x1f".join([
    delivery,
    "1" if active_pane else "0",
    "1" if dischargeable else "0",
    "1" if unattended else "0",
]))
PY
}

tap_registry_active_harness_count() {  # <harness> <worktree>
  local harness="$1" worktree="$2"
  tap_require_acting_registry || { printf '0'; return 0; }
  python3 -B - "$TAP_REGISTRY" "$harness" "$worktree" "${_TAP_SCRIPT_DIR}" <<'PY'
import json, sys
path, harness, worktree, scripts = sys.argv[1:5]
sys.path.insert(0, scripts)
from registry_v20 import _seat_map
try:
    reg = json.load(open(path))
except Exception:
    print(0); sys.exit(0)
count = 0
for ent in _seat_map(reg).values():
    if not isinstance(ent, dict):
        continue
    if ent.get("status", "active") != "active":
        continue
    if ent.get("harness") != harness:
        continue
    root = ent.get("registered_from_worktree") or (reg.get("team") or {}).get("worktree_root") or ""
    if root == worktree:
        count += 1
print(count)
PY
}

tap_transcript_fresh_for_worktree() {  # <harness> <worktree> <now> <stale_after>
  local harness="$1" worktree="$2" now="$3" stale_after="$4"
  python3 -B - "$harness" "$worktree" "$now" "$stale_after" <<'PY'
import glob, json, os, sys
harness, worktree, now_s, stale_s = sys.argv[1:5]
now = int(now_s)
stale = int(stale_s)

def mtime(path):
    try:
        return int(os.path.getmtime(path))
    except OSError:
        return 0

paths = []
if harness == "codex":
    home = os.environ.get("TAP_CODEX_HOME") or os.environ.get("CODEX_HOME") or os.path.expanduser("~/.codex")
    paths = glob.glob(os.path.join(home, "sessions", "**", "*.jsonl"), recursive=True)
elif harness == "claude":
    home = os.environ.get("TAP_CLAUDE_HOME") or os.environ.get("CLAUDE_HOME") or os.path.expanduser("~/.claude")
    munged = worktree.strip("/").replace("/", "-")
    paths = glob.glob(os.path.join(home, "projects", f"*{munged}*", "*.jsonl"))

for path in paths:
    try:
        text = open(path, encoding="utf-8", errors="replace").read()
    except OSError:
        continue
    if worktree not in text:
        continue
    mt = mtime(path)
    if mt and now - mt <= stale:
        print("fresh")
        sys.exit(0)
print("stale")
PY
}

tap_pane_alert_state() {  # <harness> ; reads stripped pane text on stdin
  local _pn_out _pn_rc=0
  _pn_out="$( { tap_bun_call pane-alert alert pane/cli.ts alert-state "$1"; _pn_rc=$?; printf 'X'; exit "$_pn_rc"; } )" || return 1
  _pn_out="${_pn_out%X}"
  # THE CALLER USES THIS OUTPUT AS THE SEAT STATE VERBATIM (`tap_seat_state`:
  # `[ -z "$alert_state" ] || { printf '%s' "$alert_state"; return 0; }`), and
  # the incumbent was a `python3` that could print one of two strings or nothing
  # at all. Passing an unrecognized module answer through therefore promotes a
  # broken runtime into a reported seat state — `seat-activity.test.ts`'s
  # `malformed` mode drove exactly that and got `nonsense` back.
  #
  # An unrecognized answer refuses SILENTLY on purpose: this door never had a
  # diagnostic channel, its output is read inside a command substitution, and
  # the caller's fallthrough to its own classification IS the handling.
  case "$_pn_out" in
    "") ;;
    rate-limited-error|blocked-on-approval) printf '%s\n' "$_pn_out" ;;
    *) return 1 ;;
  esac
}

tap_seat_state() {  # <handle> [<already-authorized-pane>]
  local handle="$1" pane_override="${2:-}" ent pane harness status worktree pane_cmd_raw
  local region escaped_input input_state now stale_after window_activity transcript_state full
  local alert_state hash cache_dir cache_file prev_hash prompt_re prompt_rc
  ent="$(tap_registry_agent_json "$handle")" || { printf 'unknown'; return 0; }
  # Pull status/pane/harness/worktree from the entry in one python fork (runs per seat
  # per watch tick), rather than one fork per field. Unit-separator delimited, NOT
  # tab: bash's `IFS=$'\t' read` collapses consecutive/empty fields because tab is
  # classified as IFS-whitespace regardless of what else is in IFS — a legacy
  # pane-only entry with an empty `harness` field would shift `worktree`'s value
  # left into `harness` and leave `worktree` empty. \x1f is not IFS-whitespace, so
  # empty fields survive intact (same fix as tap-health.sh's roster parser).
  IFS=$'\x1f' read -r status pane harness worktree < <(printf '%s' "$ent" | python3 -c '
import json, sys
d = json.load(sys.stdin)
print("\x1f".join([d.get("status", "active"), d.get("pane", ""), d.get("harness", ""), d.get("registered_from_worktree", "")]))')
  [ -z "$pane_override" ] || pane="$pane_override"
  [ "$status" = "active" ] || { printf 'unknown'; return 0; }
  [ -n "$worktree" ] || worktree="$(python3 -c 'import json,sys; print((json.load(open(sys.argv[1])).get("team") or {}).get("worktree_root",""))' "$TAP_REGISTRY" 2>/dev/null || true)"
  tap_pane_alive "$pane" >/dev/null || { printf 'unknown'; return 0; }
  [ -n "$harness" ] || {
    pane_cmd_raw="$(tmux display-message -p -t "$pane" '#{pane_current_command}' 2>/dev/null || true)"
    harness="$(tap_pane_harness_command "$pane" "$pane_cmd_raw")"
  }
  now="${TAP_WATCH_NOW:-$(date +%s)}"
  stale_after="${TAP_SEAT_STALE_AFTER:-300}"

  # Classification PRECEDENCE LADDER — load-bearing, do not reorder: a watcher must bias
  # toward SUSPICION, so
  #     ALERT STATES  >  LIVENESS EVIDENCE  >  WORKING SHORTCUTS.
  # A blocked/rate-limited seat is still blocked even with a warm transcript; a seat at an
  # empty prompt is stopped even if it just wrote; and MISSING evidence is never "active".
  # Putting a working shortcut ahead of an alert or a liveness signal is exactly the bias
  # that made stopped/blocked seats vanish from the watcher's probe chain.
  full="$(tap_capture_input_frame "$pane" "$harness" | tap_strip_ansi)"

  # (1) ALERT STATES — rate-limited / blocked-on-approval outrank every other signal.
  alert_state="$(printf '%s\n' "$full" | tap_pane_alert_state "$harness")"
  [ -z "$alert_state" ] || { printf '%s' "$alert_state"; return 0; }

  # (2) BUSY-FOOTER GATES — a generating seat that still shows an input band must
  # not fall through to idle-at-prompt. opencode and cursor keep (empty) bands
  # mid-turn; their busy markers are the readiness signal (agy is gated in
  # tap_pending_input_text). An active opencode pane with no band at all is still
  # starting, not generating: naming that state keeps a splash from reading as
  # working while preserving the healthy empty-band control. Cursor's marker is
  # layout-position-independent (tap-mk4b): adjacency to the prompt row is not
  # required.
  case "$harness" in
    opencode)
      prompt_rc=0
      printf '%s\n' "$full" | tap_opencode_prompt_ready || prompt_rc=$?
      if [ "$prompt_rc" = 3 ]; then
        printf 'booting'
        return 0
      elif [ "$prompt_rc" != 0 ]; then
        printf 'working'
        return 0
      fi
      ;;
    cursor)
      if ! printf '%s\n' "$full" | tap_cursor_prompt_ready; then
        printf 'working'
        return 0
      fi
      ;;
    claude)
      local claude_activity
      claude_activity="$(printf '%s' "$full" | tap_bun_call claude-seat-state "$handle" agent-state.ts claude-seat-state)" \
        || { printf 'unknown'; return 0; }
      case "$claude_activity" in
        working) printf 'working'; return 0 ;;
        idle) printf 'idle-at-prompt'; return 0 ;;
        blocked) printf 'blocked-on-approval'; return 0 ;;
        unknown) ;; # No recognized band: preserve the existing fallback observation.
        *) printf 'unknown'; return 0 ;;
      esac
      ;;
  esac

  # (3) LIVENESS EVIDENCE — an empty input region at a prompt is a STOPPED seat.
  region="$(tap_inputregion "$pane" "$harness")"
  escaped_input="$(tap_escaped_inputline "$pane" "$harness")"
  prompt_re="$(tap_prompt_line_re "$harness")"
  input_state="$(tap_input_state_from_region "$region" "$escaped_input" "$(tap_prompt_glyph_re "$harness")" "$prompt_re" "$harness")"
  if [ "$input_state" = "empty" ]; then
    if [ "$harness" = "opencode" ]; then
      # No prompt glyph on opencode: "at the prompt" = input box on screen AND no
      # 'esc interrupt' working indicator (checked above). Ready box → idle.
      if printf '%s\n' "$full" | tap_opencode_prompt_ready; then
        printf 'idle-at-prompt'
        return 0
      fi
    elif printf '%s\n' "$full" | grep -Eq "$prompt_re"; then
      printf 'idle-at-prompt'
      return 0
    fi
  fi

  # (4) WORKING SHORTCUTS (lowest) — a fresh transcript (sole seat of its harness) or a
  # recent window_activity means actively working. Missing/invalid window_activity is
  # treated as STALE (0), NEVER as "now": absent evidence must not read as active.
  if [ -n "$worktree" ] && [ "$(tap_registry_active_harness_count "$harness" "$worktree")" = "1" ]; then
    transcript_state="$(tap_transcript_fresh_for_worktree "$harness" "$worktree" "$now" "$stale_after")"
    [ "$transcript_state" = "fresh" ] && { printf 'working'; return 0; }
  fi
  window_activity="$(tmux display-message -p -t "$pane" '#{window_activity}' 2>/dev/null || true)"
  case "$window_activity" in ''|*[!0-9]*) window_activity=0 ;; esac
  if [ "$window_activity" -gt 0 ] && [ "$(( now - window_activity ))" -le "$stale_after" ]; then
    printf 'working'
    return 0
  fi

  cache_dir="$TAP_HOME/seat-state"
  cache_file="$cache_dir/${handle}.hash"
  # tap-zcbw: Size-invariant wedged predicate — normalize pane content (join words across soft line wraps)
  # so opening a viewer / terminal window resize does NOT break hash comparison or blind the watcher.
  # Addresses tap-zcbw (size-dependent hash instability across re-wraps); tap-hdzo (stale identity cache) is distinct.
  hash="$(printf '%s' "$full" | python3 -c 'import sys; print(" ".join(sys.stdin.read().split()))' | tap_sha256)"
  prev_hash="$(cat "$cache_file" 2>/dev/null || true)"
  if [ "${TAP_SEAT_STATE_READONLY:-0}" != "1" ]; then
    mkdir -p "$cache_dir"
    printf '%s' "$hash" > "$cache_file"
  fi
  if [ -n "$prev_hash" ] && [ "$prev_hash" = "$hash" ]; then
    printf 'wedged'
  else
    printf 'unknown'
  fi
}

# --- watch layer: arm record = lease (U4/U5) ----------------------------------
# The arm record ($TAP_HOME/watch/arm.json) is the watcher's LEASE: its presence
# means a team is armed; deleting it (off / tap team reset / disband / migration) reaps
# the loop on its next tick. Every liveness question is answerable from this file.
# The supervisor's sender identity is a reserved token so a probe's --from can never
# acquire a registered pane and silently become reply=expected (CONTRACT.md:153).
TAP_WATCH_IDENTITY="watcher"

tap_watch_arm_path()    { printf '%s/watch/arm.json' "$TAP_HOME"; }

tap_watch_is_armed()    { [ -f "$(tap_watch_arm_path)" ]; }

# Read one top-level field from the arm record (prints empty when unarmed/missing).
# dict/list values are printed as compact JSON. Body: watch-lease.ts.
tap_watch_field() {  # <key>
  tap_bun_call watch field watch-lease.ts "$(tap_watch_arm_path)" field "$1"
}

# Merge key=value updates into the arm record under the lease lock. Known numeric keys
# are coerced to int; array keys (`chain_overrides`, `probed_seats`, `blocked_exempt`,
# `tinted_panes`) to a JSON array. Exits nonzero when there is no lease to update
# (UNLESS TAP_WATCH_ALLOW_CREATE=1, the arming write) or a TAP_WATCH_EXPECT_* generation
# check mismatches; watch-lease.ts distinguishes those as 3 and 4, tap_bun_call reports 1.
tap_watch_set() {  # <key> <value> [<key> <value> ...]
  tap_bun_call watch set watch-lease.ts "$(tap_watch_arm_path)" set "$@"
}

# Release the lease (idempotent): delete the arm record UNDER THE SAME LOCK tap_watch_set
# takes, so a disarm can never land between a tick's read and its publish rename and thereby
# get the lease resurrected. The lock FILE is kept (a stable inode all lockers share) —
# deleting it would let a future locker synchronize on a new inode while an old fd holds
# the old lock. Deletes only arm.json + arm.json.tmp.
#
# FAIL LOUD (no unlocked fallback): disarm is a safety verb. If the locked delete fails,
# an unlocked `rm` would be the exact race the lock exists to prevent — silently. So we
# keep the lease, surface the error, and return non-zero. An armed-but-undismissed watch
# is visible in `tap health` and recoverable by re-running `tap watch off`; a silent racy
# delete is neither.
tap_watch_disarm() {
  tap_bun_call watch disarm watch-lease.ts "$(tap_watch_arm_path)" disarm && return 0
  echo "tap watch: warning: locked disarm failed; lease KEPT to avoid an unlocked racy delete. See 'tap health'; retry 'tap watch off'." >&2
  return 1
}

# Normalize TUI-captured input for sentinel-id matching. tmux visual wrapping can
# split an id across whitespace/newlines; ANSI can also be present in escaped
# captures. Strip both before matching. This is deliberately for id checks only,
# not for preserving human input text.
tap_normalize_input_match() {
  python3 -B -c 'import re, sys, unicodedata
text = sys.stdin.read()
text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text)
text = unicodedata.normalize("NFC", text)
text = re.sub(r"\s+", "", text)
sys.stdout.write(text)'
}

# Exact mode is for allowlisted harness commands that cannot carry a minted
# marker (notably `/clear`). Match only the active input, never transcript
# history or a substring such as "unclear".
tap_input_has_match() {  # <pane> <pane_cmd> <needle> [<id|exact>]
  local _pn_frame _pn_out _pn_cap=0
  # A FAILED CAPTURE IS NOT A PREDICATE ANSWER. Dropping `|| true` here is the
  # other half of rule 19: an empty frame would make the module honestly report
  # "the id is not in this band", and `tap_submit_verify`'s post-Enter loop reads
  # that as the payload having been consumed. The incumbent had the identical
  # hole — a failed capture produced an empty region that matched nothing — so
  # this is a fix riding the port, ratified rather than folded in.
  _pn_frame="$( { tap_capture_pair "$1" "$2" 2>/dev/null; _pn_cap=$?; printf 'X'; exit "$_pn_cap"; } )" || return 2
  _pn_frame="${_pn_frame%X}"
  _pn_out="$(printf '%s' "$_pn_frame" | tap_bun_call pane-has-match "$1" pane/cli.ts has-match "$1" "$2" "$3" "${4:-id}")" || return 2
  # THREE answers, not two. `yes`/`no` are the predicate; anything else — a
  # missing runtime, a module that failed to load, a verdict this adapter does
  # not recognize — is 2, "could not read". Collapsing that into `no` is what
  # rule 19 forbids, and here it is not abstract: `tap_submit_verify`'s
  # post-Enter loop reads a false answer as "the id left the band", so a crashed
  # reader would certify an unverified submit.
  case "$_pn_out" in
    yes) return 0 ;;
    no) return 1 ;;
    *) return 2 ;;
  esac
}

# tap_queueband_has_id <pane> <pane_cmd> <id>
# GLYPH-LESS positive landing check for queue-prefix harnesses (hermes): its working
# input band carries no prompt glyph (⚕ header, then a bare '/queue [[TAP …]]' line),
# so the glyph-anchored tap_input_has_id can't see the injected sentinel. Scan the
# WHOLE visible pane for the freshly-minted id — it is unique to THIS send, so any
# occurrence is our just-injected line, never history (tap-dl3). This is a POSITIVE
# observation, not a blind trust: a genuine inject miss leaves the id absent and the
# caller must still fail closed.
tap_queueband_has_id() {
  local pane="$1" cmd="$2" id="$3" haystack needle
  haystack="$(tap_capture_pane -p -t "$pane" 2>/dev/null | tap_strip_ansi | tap_normalize_input_match)"
  needle="$(printf '%s' "$id" | tap_normalize_input_match)"
  [ -n "$needle" ] || return 1
  case "$haystack" in *"$needle"*) return 0 ;; *) return 1 ;; esac
}

# A large paste can be represented by a harness-owned chip instead of the text
# containing the minted id. This is intentionally a rendering check, not a
# pending-input check; callers must establish input provenance before using it.
tap_text_has_paste_collapse() {  # $1=pane_cmd $2=plain input text
  local _pn_out
  _pn_out="$(tap_bun_call pane-text-chip chip pane/cli.ts text-paste-collapse "$1" "$2" </dev/null)" || return 2
  # THREE answers, not two. `yes`/`no` are the predicate; anything else — a
  # missing runtime, a module that failed to load, a verdict this adapter does
  # not recognize — is 2, "could not read". Collapsing that into `no` is what
  # rule 19 forbids, and here it is not abstract: `tap_submit_verify`'s
  # post-Enter loop reads a false answer as "the id left the band", so a crashed
  # reader would certify an unverified submit.
  case "$_pn_out" in
    yes) return 0 ;;
    no) return 1 ;;
    *) return 2 ;;
  esac
}

tap_input_has_paste_collapse() {
  local _pn_frame _pn_out _pn_cap=0
  # A FAILED CAPTURE IS NOT A PREDICATE ANSWER. Dropping `|| true` here is the
  # other half of rule 19: an empty frame would make the module honestly report
  # "the id is not in this band", and `tap_submit_verify`'s post-Enter loop reads
  # that as the payload having been consumed. The incumbent had the identical
  # hole — a failed capture produced an empty region that matched nothing — so
  # this is a fix riding the port, ratified rather than folded in.
  _pn_frame="$( { tap_capture_pair "$1" "$2" 2>/dev/null; _pn_cap=$?; printf 'X'; exit "$_pn_cap"; } )" || return 2
  _pn_frame="${_pn_frame%X}"
  _pn_out="$(printf '%s' "$_pn_frame" | tap_bun_call pane-has-chip "$1" pane/cli.ts has-paste-collapse "$1" "$2")" || return 2
  # THREE answers, not two. `yes`/`no` are the predicate; anything else — a
  # missing runtime, a module that failed to load, a verdict this adapter does
  # not recognize — is 2, "could not read". Collapsing that into `no` is what
  # rule 19 forbids, and here it is not abstract: `tap_submit_verify`'s
  # post-Enter loop reads a false answer as "the id left the band", so a crashed
  # reader would certify an unverified submit.
  case "$_pn_out" in
    yes) return 0 ;;
    no) return 1 ;;
    *) return 2 ;;
  esac
}

tap_input_has_injected_content() {  # $4=allow paste-collapse; $5=id|exact
  local _pn_frame _pn_out _pn_cap=0
  # A FAILED CAPTURE IS NOT A PREDICATE ANSWER. Dropping `|| true` here is the
  # other half of rule 19: an empty frame would make the module honestly report
  # "the id is not in this band", and `tap_submit_verify`'s post-Enter loop reads
  # that as the payload having been consumed. The incumbent had the identical
  # hole — a failed capture produced an empty region that matched nothing — so
  # this is a fix riding the port, ratified rather than folded in.
  _pn_frame="$( { tap_capture_pair "$1" "$2" 2>/dev/null; _pn_cap=$?; printf 'X'; exit "$_pn_cap"; } )" || return 2
  _pn_frame="${_pn_frame%X}"
  _pn_out="$(printf '%s' "$_pn_frame" | tap_bun_call pane-has-injected "$1" pane/cli.ts has-injected "$1" "$2" "$3" "${4:-0}" "${5:-id}")" || return 2
  # THREE answers, not two. `yes`/`no` are the predicate; anything else — a
  # missing runtime, a module that failed to load, a verdict this adapter does
  # not recognize — is 2, "could not read". Collapsing that into `no` is what
  # rule 19 forbids, and here it is not abstract: `tap_submit_verify`'s
  # post-Enter loop reads a false answer as "the id left the band", so a crashed
  # reader would certify an unverified submit.
  case "$_pn_out" in
    yes) return 0 ;;
    no) return 1 ;;
    *) return 2 ;;
  esac
}

# Read a stuck sentinel out of a captured input band.
#
# Emits `<id>\x1f<recipient>\x1f<wire>` where <wire> is `v023` or `pre023`, and
# exits non-zero when the region does not read as a bare sentinel. The grammar,
# the prompt-row strip and the de-wrapping live in `runtime/bun/src/stuck-sentinel.ts`,
# shared with the native delivery path's `pendingSentinel`; this is the
# output/exit adapter over that one implementation. A refusal is an ordinary
# verdict (the band holds human text), so it travels on stdout and maps to
# status 1 here; only a runtime failure is a slice failure.
tap_stuck_sentinel_fields_from_region() { # <cmd>; region on stdin
  local verdict status id to wire
  verdict="$(tap_bun_call stuck-sentinel region stuck-sentinel.ts fields "$1")" || return 1
  IFS=$'\x1f' read -r status id to wire <<< "$verdict"
  case "$status" in
    ok)
      case "$wire" in v023|pre023) ;; *) status=invalid ;; esac
      [ -n "$id" ] || status=invalid ;;
    refused)
      # `id` carries the reason; the anchor and charset refusals are silent.
      [ -z "$id" ] || printf 'stuck sentinel: %s\n' "$id" >&2
      return 1 ;;
  esac
  [ "$status" = ok ] || { printf 'tap: slice_failed id=region slice=stuck-sentinel: invalid verdict\n' >&2; return 1; }
  printf '%s\x1f%s\x1f%s' "$id" "$to" "$wire"
}

tap_stuck_sentinel_fields() {
  local pane="$1" cmd="$2"
  case "$cmd" in
    codex*) tap_capture_pane -p -e -J -t "$pane" | tap_composer_input "$cmd" | tap_stuck_sentinel_fields_from_region "$cmd" ;;
    *) tap_inputregion "$pane" "$cmd" | tap_stuck_sentinel_fields_from_region "$cmd" ;;
  esac
}

# --- pending-input observation ------------------------------------------------
# These helpers give tap-send.sh a pre-canonical, no-wait way to report that a
# target pane is blocked by human text. They intentionally do not decide whether
# a peer is alive or abandoned; callers may use the emitted hash for supervision.
TAP_PENDING_INPUT_CAP_BYTES="${TAP_PENDING_INPUT_CAP_BYTES:-4096}"
# Ops ruling (tap-jb3): only trivially short captured drafts get one automatic
# paste-back after verified delivery. This is intentionally fixed, not a knob.
TAP_SHORT_DRAFT_MAX_LINES=2

tap_sha256() { shasum -a 256 | awk '{print $1}'; }


# tap_pending_input_text <pane> <pane_cmd> [<already-captured-frame>]
# The band's TYPED text, with harness chrome removed. Four answers and they are
# not interchangeable: rc 0 with text (empty = a clear band), rc 3 "nothing
# readable was here" — which `tap_submit_verify`'s draft-clear may push through
# — rc 5 is an OpenCode terminal overprint that split the input geometry, and
# rc 4 is BLOCKED, a modal asking this seat's human, which may never be typed
# over. The decision tree lives in `runtime/bun/src/pane/reader.ts`.
#
# THE RUNTIME-FAILURE ROW IS THE INCUMBENT'S, not a default. When the reader
# crashed, each branch answered differently and the callers read those answers:
# claude and codex reached `tap_approval_prompt`, whose `|| return 0` MEANS
# "overlay present", so a crash answered 4; agy's `tap_agy_box_text || return 3`
# fell through to 3; opencode inherited `tap_inputline`'s 1. Collapsing them
# would delete a distinction on the exact 3-versus-4 contract this function
# owns, in the type-over direction.
#
# The pane WIDTH is queried only for claude, as the incumbent did: it is the
# geometry signal for a truncated argument-placeholder hint and nothing else
# reads it. An unreadable width keeps the truncated form and still accepts the
# verbatim placeholder.
tap_pending_input_text() {
  local _pn_frame _pn_verdict _pn_width="" _pn_rc=0
  # Exact bytes here too; the module applies the stripping the incumbent applied
  # per branch (claude/codex's overlay frame and agy's capture went through a
  # substitution, the generic path's `tap_inputline` did not).
  if [ "$#" -ge 3 ]; then
    _pn_frame="$3"
  else
    _pn_frame="$( { tap_capture_pair "$1" "$2" 2>/dev/null; printf 'X'; } )"
    _pn_frame="${_pn_frame%X}"
  fi
  case "$2" in claude*) _pn_width="$(tmux display-message -p -t "$1" '#{pane_width}' 2>/dev/null || true)" ;; esac
  # `--frame` is passed or it is not: an empty positional is still an argument,
  # and the door would read it as an unknown flag.
  if [ "$#" -ge 3 ]; then
    _pn_verdict="$( { printf '%s' "$_pn_frame" | TAP_PANE_WIDTH="$_pn_width" tap_bun_call pane-pending "$1" pane/cli.ts pending-text "$1" "$2" --frame; _pn_rc=$?; printf 'X'; exit "$_pn_rc"; } )" \
      || { case "$2" in claude*|codex*) return 4 ;; opencode) return 1 ;; esac; return 3; }
  else
    _pn_verdict="$( { printf '%s' "$_pn_frame" | TAP_PANE_WIDTH="$_pn_width" tap_bun_call pane-pending "$1" pane/cli.ts pending-text "$1" "$2"; _pn_rc=$?; printf 'X'; exit "$_pn_rc"; } )" \
      || { case "$2" in claude*|codex*) return 4 ;; opencode) return 1 ;; esac; return 3; }
  fi
  _pn_verdict="${_pn_verdict%X}"
  case "$_pn_verdict" in
    no-band) return 3 ;;
    overprint) return 5 ;;
    blocked) return 4 ;;
    text$'\x1f'*) printf '%s' "${_pn_verdict#text$'\x1f'}" ;;
    # AN UNRECOGNIZED TOKEN IS A BROKEN PROTOCOL, NOT ABSENT GEOMETRY. rc 3 says
    # "nothing readable was here", which the force bound may type over; a module
    # that answered with a token this adapter does not know has told us nothing
    # about the band. The runtime-failure arm above already has the right answer
    # per harness, so take it rather than inventing a permissive one. The stderr
    # label does not protect a caller that consumes the status
    # (astra-pinnacle-reviewer-2, P2).
    *) printf 'tap: slice_failed id=%s slice=pane-pending: invalid verdict\n' "$1" >&2
       case "$2" in claude*|codex*) return 4 ;; opencode) return 1 ;; esac
       return 3 ;;
  esac
}

tap_recorded_permissions() { # <registry> <handle>
  tap_bun_call delivery-permissions policy delivery-permissions.ts "$@" </dev/null
}

tap_auto_band_ready() { # <pane> <harness>
  local frame result mode
  mode="$(tmux display-message -p -t "$1" '#{pane_in_mode}')" || return 1
  [ "$mode" = 0 ] || return 1
  frame="$(tap_capture_input_frame "$1" "$2" 1)" || return 1
  result="$(printf '%s' "$frame" | tap_bun_call auto-ready frame submit-frame.ts auto-ready "$2")" || return 1
  [ "$result" = ready ]
}

# A human approval modal holds even when the harness is healthy. Shared with Bun.
tap_approval_prompt() { # <harness>; stdin: full ANSI pane frame
  local result
  result="$(tap_bun_call approval-prompt frame submit-frame.ts approval-prompt "$1")" || return 0
  [ "$result" = clear ] && return 1
  return 0
}

# Recognized feedback chrome and failed observations both withhold pane effects.
tap_claude_feedback_overlay() {
  local result
  result="$(tap_bun_call claude-feedback-overlay frame submit-frame.ts claude-feedback-overlay)" || return 0
  [ "$result" = clear ] && return 1
  return 0
}


# Read the active composer from one supplied capture. Known empty geometry is
# rc 0 with empty text; absent or unknown geometry is rc 3, never evidence of
# clear; rc 4 is BLOCKED. OpenCode and agy keep the REGION reader's convention
# and report their own failure as rc 0 — the incumbent's shape, preserved rather
# than repaired inside a port (tap-bxfd8 carries the hazard).
#
# A failed CAPTURE is rc 3 here, which is not the same as those readers' rc 0:
# this is the incumbent's explicit `|| return 3`, and without it an unreadable
# OpenCode pane would answer "rc 0, empty" — evidence of a clear band that
# nobody observed.
tap_pending_input_region_text() {
  local _pn_frame _pn_verdict _pn_rc=0
  _pn_frame="$(tap_capture_pair "$1" "$2")" || return 3
  _pn_verdict="$( { printf '%s' "$_pn_frame" | tap_bun_call pane-pending-region "$1" pane/cli.ts pending-region-text "$1" "$2"; _pn_rc=$?; printf 'X'; exit "$_pn_rc"; } )" || return 3
  _pn_verdict="${_pn_verdict%X}"
  case "$_pn_verdict" in
    no-band) return 3 ;;
    blocked) return 4 ;;
    text$'\x1f'*) printf '%s' "${_pn_verdict#text$'\x1f'}" ;;
    *) printf 'tap: slice_failed id=%s slice=pane-pending-region: invalid verdict\n' "$1" >&2; return 3 ;;
  esac
}

# Read the active composer from one supplied capture. Known empty geometry is
# rc0 with empty text; absent/unknown geometry is nonzero, never evidence of clear.
# Read the active composer from one supplied capture. Known empty geometry is
# rc0 with empty text; absent/unknown geometry is rc3, never evidence of clear;
# rc4 is BLOCKED — a modal is asking the seat's human a question, or cursor's box
# geometry is unreadable and the caller must not fall back to the chrome-rich
# region. The three-way split is the contract: rc3 means "nothing readable was
# here", which the bound may push through, and rc4 may never be typed over
# (CONTRACT.md, the modal/startup holds).
#
# The harness dispatch, the decision ORDER and every branch live in
# `runtime/bun/src/submit-frame.ts` (`composerInput`), shared with the native
# readers. The order is not `readFrame`'s and that is deliberate — the approval
# check runs for claude and codex only, claude's feedback overlay blocks before
# its box is read, and cursor is consulted only after a prompt region exists, so
# no prompt row is rc3 while unreadable box geometry is rc4.
tap_composer_input() { # <harness>; stdin: one ANSI pane frame; rc3/4: unknown
  local verdict rc=0
  # A RUNTIME failure keeps the incumbent's fail-closed holds, and that is not
  # the same as keeping its box-reader status. My first draft claimed 3-on-crash
  # was inherited everywhere; it was inherited only for the box readers and the
  # generic path (grok-patch-sponsor, #xxxx). The three holds went the other way:
  #
  #   claude*/codex*  `tap_approval_prompt`, then `tap_claude_feedback_overlay`
  #                   — each `|| return 0`, and 0 MEANS "overlay present", so a
  #                   crashed reader returned 4.
  #   cursor*         `if tap_cursor_box_text …; then return 0; fi; return 4`
  #                   — a failed call fell through to 4.
  #
  # Those are fail-closed safety holds and the caller reads them: in
  # `tap_submit_verify`'s draft-clear, rc 4 DEFERS while rc 3 proceeds to the
  # backup and the `C-u`, and cursor rc 4 sets `cursor_geometry_missing` so a
  # failed re-read is not treated as a clear band. Collapsing them to 3 would
  # delete a distinction the incumbent had, on the exact 3-versus-4 contract
  # this function owns, in the type-over direction.
  #
  # One case is deliberately not specimen-exact: cursor with NO prompt row and
  # Bun down answers 4 where the incumbent answered 3, because it reached its
  # region check without calling Bun. The adapter cannot know whether a region
  # exists without the module that is missing, so it takes the safe side — and
  # that case is a pane with nothing to type into anyway.
  #
  # The box readers' and generic path's 3-on-crash IS inherited and stays; a
  # fourth verdict for it is a contract change with its own bead.
  # The sentinel `X` is not decoration: a command substitution strips trailing
  # newlines, and the generic branch's text ENDS in one (the incumbent's `awk`
  # tail terminates every row it prints). Reading the verdict plainly cost that
  # byte on 292 of 1395 cases — caught only because the differential compares
  # the BASH FUNCTION as well as the module, which was byte-identical on all
  # 1395. `exit "$rc"` carries the runtime status out of the subshell.
  verdict="$( { tap_bun_call composer-input frame submit-frame.ts composer-input "$1"; rc=$?; printf 'X'; exit "$rc"; } )" \
    || { case "$1" in claude*|codex*|cursor*) return 4 ;; esac; return 3; }
  verdict="${verdict%X}"
  case "$verdict" in
    unknown) return 3 ;;
    blocked) return 4 ;;
    text$'\x1f'*) printf '%s' "${verdict#text$'\x1f'}" ;;
    *) printf 'tap: slice_failed id=frame slice=composer-input: invalid verdict\n' >&2; return 3 ;;
  esac
}

# 0: visible owned text; 2: a prior Enter consumed the control; 5: withhold.
tap_submit_enter_ready() { # <pane> <harness> <expected> <id> <allow-chip> <entered>
  local pane="$1" cmd="$2" expected="$3" id="$4" allow_chip="$5" entered="$6" frame result captured=1
  frame="$(tap_capture_input_frame "$pane" "$cmd" 1 2>/dev/null)" || captured=0
  result="$(printf '%s' "$frame" | tap_bun_call enter-ready "$id" submit-frame.ts enter-ready \
    "$cmd" "$expected" "$id" "$allow_chip" "$entered" "${TAP_SUBMIT_HARNESS_ALIVE:-0}" \
    "${TAP_SUBMIT_PERMISSIONS:-bypass}" "${TAP_SUBMIT_AUTO_READY:-0}" "$captured")" || return 5
  case "$result" in
    ready) return 0 ;;
    consumed) return 2 ;;
    gated) return 5 ;;
    unread) return 5 ;;
    withhold)
      printf '%s' "$frame" | tap_debug_submit_frame "$id" "$cmd" "$pane" "$expected" composer-mismatch
      echo "tap: composer changed before Enter; input left untouched -> submit-unverified" >&2
      return 5 ;;
    # A module that exits 0 and prints a token this map does not carry is a
    # protocol failure, not a refusal. Falling through silently would let
    # infrastructure breakage wear the disposition of a typed answer, so it says
    # so and keeps rc 5 -- no Enter, no pane effect (rule 19).
    *)
      printf 'tap: slice_failed id=%s slice=enter-ready: invalid verdict\n' "$id" >&2
      return 5 ;;
  esac
}

# tap_dim_prompt_input <typed> <escaped> <glyph> <cmd>
# 0 when the band's visible text is HARNESS CHROME rather than a human draft:
# Cursor's SGR-2 placeholder, Codex's animated idle hint, Hermes's italic muted
# 256-colour hint. The SGR walk, the per-harness attribute rules and the
# reverse-video cursor allowance live in `runtime/bun/src/pane/geometry.ts`
# (`dimPromptInput`), which is the same function the native reader calls.
tap_dim_prompt_input() {
  local _pn_out
  # No empty-input fast path here: `dimPromptInput` (pane/geometry.ts:181) already
  # answers `typed === "" -> false`, which this adapter maps to the same rc 1. The
  # duplicate made the "adapters hold no decision" claim literally false for one
  # function (astra-pinnacle-reviewer-2, nonblocking).
  _pn_out="$(printf '%s' "${2:-}" | tap_bun_call pane-dim dim pane/cli.ts dim-prompt "$1" "${3:-[›❯]}" "${4:-}")" || return 2
  # THREE answers, not two. `yes`/`no` are the predicate; anything else — a
  # missing runtime, a module that failed to load, a verdict this adapter does
  # not recognize — is 2, "could not read". Collapsing that into `no` is what
  # rule 19 forbids, and here it is not abstract: `tap_submit_verify`'s
  # post-Enter loop reads a false answer as "the id left the band", so a crashed
  # reader would certify an unverified submit.
  case "$_pn_out" in
    yes) return 0 ;;
    no) return 1 ;;
    *) return 2 ;;
  esac
}

# 0 when the text holds a C0 control other than LF, or DEL.
tap_text_has_control() {
  local _pn_out
  _pn_out="$(tap_bun_call pane-text-control text pane/cli.ts text-control)" || return 2
  # THREE answers, not two. `yes`/`no` are the predicate; anything else — a
  # missing runtime, a module that failed to load, a verdict this adapter does
  # not recognize — is 2, "could not read". Collapsing that into `no` is what
  # rule 19 forbids, and here it is not abstract: `tap_submit_verify`'s
  # post-Enter loop reads a false answer as "the id left the band", so a crashed
  # reader would certify an unverified submit.
  case "$_pn_out" in
    yes) return 0 ;;
    no) return 1 ;;
    *) return 2 ;;
  esac
}



# tap_input_backup_body <backup-path> — stream only the durable backup body.
tap_input_backup_body() {
  tap_bun_call input-backup body input-backup.ts body "$1"
}

# 0: meaningful text; 1: whitespace only; 2: unreadable decision (never empty).
tap_input_has_text() {
  local content
  content="$(tap_bun_call input-backup content input-backup.ts content)" || return 2
  case "$content" in
    yes) return 0 ;; no) return 1 ;;
    *) echo 'tap: slice_failed id=content slice=input-backup: invalid content decision' >&2; return 2 ;;
  esac
}

# tap_restore_short_input_backup <pane> <pane-cmd> <backup-path>
# One bounded post-submit paste-back. It never presses Enter or clears input; a
# nonempty band, failed paste, or failed first-line observation leaves the file
# as the manual `tap draft` recovery authority.
tap_restore_short_input_backup() (
  local pane="$1" cmd="$2" backup_path="$3" current first_line observed buffer body content_rc=0
  body="$(mktemp "${TMPDIR:-/tmp}/tap-restore-body.XXXXXX")" || return 1
  trap 'rm -f "$body"' EXIT
  tap_input_backup_body "$backup_path" > "$body" || return 1
  tap_input_has_text < "$body" || content_rc=$?
  [ "$content_rc" != 1 ] || return 0
  [ "$content_rc" = 0 ] || return 1
  current="$(tap_pending_input_text "$pane" "$cmd")" || return 1
  [ -z "$current" ] || return 1
  first_line="$(sed -n '1p' "$body")"
  [ -n "$first_line" ] || return 1
  buffer="tap-restore-$$-$RANDOM"
  tmux load-buffer -b "$buffer" - < "$body" || return 1
  if ! tmux paste-buffer -b "$buffer" -p -t "$pane"; then
    tmux delete-buffer -b "$buffer" 2>/dev/null || true
    return 1
  fi
  tmux delete-buffer -b "$buffer" 2>/dev/null || true
  observed="$(tap_pending_input_text "$pane" "$cmd")" || observed=""
  [ "$observed" = "$first_line" ] || return 1
  echo "tap: input backup restored from retained file: $backup_path" >&2
)

# (tap_clear_pending_input / tap_recover_pending_input removed 2026-07-02: the
# opt-in stale-input recovery path is subsumed by the clobber pipeline inside
# tap_submit_verify — pending input is backed up and cleared on every send.)

# tap_escaped_inputline <pane> [<pane_cmd>]
# Capture the last prompt-glyph line (› ❯ →) WITH ANSI escape sequences intact. Used
# only for styled-placeholder detection (dimmed or the calibrated Hermes hint =
# idle chrome, not blocking input). <pane_cmd> selects the glyph set and style
# discriminator (cursor uses →); defaults to › ❯.
tap_escaped_inputline() {
  local pane="$1" cmd="${2:-}"
  tap_capture_pane -e -t "$pane" -p | tap_escaped_prompt_from_frame "$cmd"
}

# Same placeholder reader for an already captured submit frame; no second peek.
# opencode has no glyph prompt row — a stray chevron rendered in the transcript
# tail must not be mistaken for one — and the module answers empty for it.
tap_escaped_prompt_from_frame() {
  local _pn_out _pn_rc=0
  _pn_out="$( { tap_bun_call pane-escaped-prompt frame pane/cli.ts escaped-prompt "${1:-}"; _pn_rc=$?; printf 'X'; exit "$_pn_rc"; } )" || return 1
  printf '%s' "${_pn_out%X}"
}

# tap_inject_text <pane> <pane_cmd> <text>
# Inject a short TAP control line into a harness input. OpenCode needs the bare
# literal-keystroke form; the generic path keeps `--` so a future text value that
# starts with '-' cannot be parsed as tmux flags.
tap_inject_text() {
  local pane="$1" cmd="$2" text="$3"
  if [ "$cmd" = "opencode" ]; then
    tmux send-keys -t "$pane" -l "$text"
  else
    tmux send-keys -t "$pane" -l -- "$text"
  fi
}

# tap_prefix_region_clean <pane> <pane_cmd>
# 0 iff the active input region carries nothing past its first line (tap-tx3s).
#
# The typed-prefix render check compares the PROMPT LINE, which a wrapped draft
# escapes: at a narrow width the prompt line can read as exactly the prefix while
# the pane owner's leftover text sits on continuation rows. Region emptiness is
# the missing half of that check, and it is asked ONLY of the typed-prefix path —
# every other caller of the region reader is doing draft backup, where extra rows
# are the point rather than a fault.
#
# Fail-closed on both branches: a region that cannot be read at all contradicts a
# prompt line that just read fine, and an anomaly here costs a refusal (exit 5,
# this path's pre-existing behaviour) while a wrong pass appends a payload to
# someone's draft and presses Enter. A continuation row that is genuinely chrome
# — a hint wide enough to wrap — also refuses; that is the same safe direction
# and is why this is a wrapped-draft guard rather than a chrome classifier.
tap_prefix_region_clean() {
  local pane="$1" cmd="$2" region
  # tap_pending_input_region_text, NOT tap_inputregion. The raw region is
  # prompt-ANCHORED: every row after the prompt line is the harness's own box
  # chrome — the bottom border and the shortcuts footer — so reading it here
  # refuses every healthy render and leaves in place the very defect this
  # change exists to fix, while a negative-only test stays green. This needs
  # the box's TYPED rows, which is the chrome-bounded reader's job.
  region="$(tap_pending_input_region_text "$pane" "$cmd" 2>/dev/null || true)"
  [ -n "$region" ] || return 1
  printf '%s\n' "$region" | awk 'NR > 1 && $0 ~ /[^[:space:] ]/ { extra = 1 } END { exit extra ? 1 : 0 }'
}

# A fresh paste chip proves activity, not that a control focus finished arriving.
# Report byte counts only (never focus contents); compare the final 128
# non-whitespace characters so physical line wraps cannot hide the tail marker.
# This is an ordered-input tail check, not a checksum of opaque pasted content.
tap_control_tail_ready() { # <pane> <harness> <payload>
  local rendered="" decision=""
  rendered="$(tap_pending_input_region_text "$1" "$2" 2>/dev/null)" || rendered=""
  decision="$(printf '%s' "$rendered" | tap_bun_call control-payload "$1" slices/control-payload.ts tail "$2" "$3")" || return 1
  printf '%s\n' "${decision%$'\n'*}"
  [ "${decision##*$'\n'}" = ready ]
}

# --- per-pane submit serialization (tap-9ivr lane B) ---------------------------
# THE DEFECT, reproduced on a real tmux pane before this was written: two senders
# submitting to ONE pane concurrently produce a FUSED LINE — both sentinels in a
# single submitted turn — and BOTH senders exit 0. Observed:
#
#   probe-AAA rc=0 / probe-BBB rc=0
#   harness received: [[TAP … id=probe-AAA …]][[TAP … id=probe-BBB …]]
#
# The band-clear read-back cannot see this and is not at fault: it asks "did my
# id leave the band", and the id did leave — glued to someone else's. One Enter
# submitted both, so the band was honestly empty. Downstream, the recipient sees
# ONE turn carrying two sentinels; whichever it acts on, the other's canonical
# sits on the bus with no push wake. Raw send-keys contention shows the same at
# the primitive level (3 of 10 lines fused): nothing between the text write and
# the Enter is atomic, and any concurrent writer lands inside that window.
#
# The lock is keyed on the PANE, held across the whole submit cycle, and taken
# with flock(2) on an inherited fd rather than a lockfile-as-mutex. That choice
# is about death: a holder that dies must release, and here the KERNEL declares
# the release rather than a survivor inferring it from a pid that may have been
# recycled. Verified on this platform, including that the lock is released when
# the holder is SIGKILLed.
#
# ONE CONSTRAINT THIS CREATES, and it is not obvious: a child process that
# inherits the fd keeps the lock alive after the holder dies. Every child inside
# the locked region today is short-lived (tmux calls, python reads), so the
# exposure is milliseconds. Do NOT spawn a long-lived or backgrounded child
# inside the locked region without closing fd 9 for it — that turns a courier
# crash into a pane that spools forever.
#
# fd 9 is reserved for this. bash 3.2 (the macOS system bash) has no {var}>
# dynamic-fd form, so the number is fixed rather than allocated.
TAP_PANE_SUBMIT_LOCK_FD=9

tap_pane_submit_lock_path() { # <key>
  local key="$1" dir
  # Match Bun lockRoot and obligation locks: explicit lock dir, pinned index,
  # then the CALLER-PINNED bus, then the user's default index. A caller pin is
  # TAP_HOME that is neither source-time derived (TAP_BUS_RULE) nor inherited
  # from a --team override (the exported TAP_TEAM_OVERRIDE_BUS marker names the
  # derived bus in BOTH runtimes, so a child never mistakes it for a pin —
  # tap-7r3fn.66). Derived buses keep the incumbent default so Bash and Bun
  # agree under every reachable env, including across exported envs.
  if [ -n "${TAP_LOCK_DIR:-}" ]; then
    dir="$TAP_LOCK_DIR"
  elif [ -n "${TAP_INDEX_HOME:-}" ]; then
    dir="$TAP_INDEX_HOME/locks"
  elif [ "${TAP_BUS_RULE:-}" = "env" ] && [ -n "${TAP_HOME:-}" ] \
    && [ "${TAP_HOME}" != "${TAP_TEAM_OVERRIDE_BUS:-}" ]; then
    dir="$TAP_HOME/locks"
  else
    dir="$HOME/.tap/locks"
  fi
  mkdir -p "$dir" 2>/dev/null || return 1
  printf '%s/pane-submit-%s.lock' "$dir" "$(printf '%s' "$key" | tr -c 'A-Za-z0-9_.-' '_')"
}

# tap_pane_submit_lock <key> [<timeout-seconds>]
# 0 acquired | 1 unavailable/timed out (caller MUST treat this as "park it", never as
# "proceed anyway" — proceeding unlocked re-creates the fused line this exists to
# prevent, silently, with both senders green).
tap_pane_submit_lock() {
  local key="$1" timeout="${2:-${TAP_PANE_SUBMIT_LOCK_TIMEOUT:-5}}" path
  [ -n "$key" ] || return 0
  path="$(tap_pane_submit_lock_path "$key")" || {
    tap_error_line pane_lock_unavailable "check lock-directory permissions" "pane_lock_unavailable: cannot create the pane lock directory"
    return 1
  }
  eval "exec ${TAP_PANE_SUBMIT_LOCK_FD}>\"\$path\"" 2>/dev/null || {
    tap_error_line pane_lock_unavailable "check lock-file permissions" "pane_lock_unavailable: cannot open the pane lock file"
    return 1
  }
  python3 -B -c '
import fcntl, sys, time
fd, timeout = int(sys.argv[1]), float(sys.argv[2])
deadline = time.time() + timeout
while True:
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        sys.exit(0)
    except OSError:
        if time.time() >= deadline:
            sys.exit(1)
        time.sleep(0.02)
' "$TAP_PANE_SUBMIT_LOCK_FD" "$timeout"
}

tap_pane_submit_unlock() {
  eval "exec ${TAP_PANE_SUBMIT_LOCK_FD}>&-" 2>/dev/null || true
}

# --- cross-runtime obligation serialization ----------------------------------
# Bun and Bash must derive the SAME path. This is intentionally a small
# companion to the pane lock rather than a generic lock framework: cancel is
# the only incumbent verb that shares this critical section with native code.
TAP_OBLIGATION_LOCK_FD=8

tap_obligation_lock_path() { # <id>
  local id="$1" dir digest
  if [ -n "${TAP_LOCK_DIR:-}" ]; then
    dir="$TAP_LOCK_DIR"
  elif [ -n "${TAP_INDEX_HOME:-}" ]; then
    dir="$TAP_INDEX_HOME/locks"
  elif [ "${TAP_BUS_RULE:-}" = "env" ] && [ -n "${TAP_HOME:-}" ] \
    && [ "${TAP_HOME}" != "${TAP_TEAM_OVERRIDE_BUS:-}" ]; then
    # A caller-pinned bus keeps its locks WITH its bus; without this tier a
    # bare TAP_HOME-only run escaped the sandbox into the operator's
    # ~/.tap/locks (tap-7r3fn.66, same class as tap-bw8z). The marker check
    # excludes a bus inherited from a --team override in either runtime, so
    # derived buses keep the incumbent default in lockstep.
    dir="$TAP_HOME/locks"
  else
    dir="$HOME/.tap/locks"
  fi
  mkdir -p "$dir" 2>/dev/null || return 1
  id="$(printf '%s' "$id" | tr -c 'A-Za-z0-9_.-' '_')"
  if [ "${#id}" -gt 239 ]; then
    mkdir -p "$dir/obligation-long" 2>/dev/null || return 1
    digest="$(printf '%s' "$id" | tap_sha256)" || return 1
    [ "${#digest}" -eq 64 ] || return 1
    case "$digest" in *[!a-f0-9]*) return 1 ;; esac
    printf '%s/obligation-long/%s.lock' "$dir" "$digest"
  else
    printf '%s/obligation-%s.lock' "$dir" "$id"
  fi
}

# Hold the exact-id lock on fd 8 until this process exits. A timeout is a
# refusal; callers must never continue unlocked.
tap_obligation_lock() { # <id> [timeout-seconds]
  local id="$1" timeout="${2:-5}" path
  path="$(tap_obligation_lock_path "$id")" || return 1
  eval "exec ${TAP_OBLIGATION_LOCK_FD}>\"\$path\"" 2>/dev/null || return 1
  python3 -B -c '
import fcntl, sys, time
fd, timeout = int(sys.argv[1]), float(sys.argv[2])
deadline = time.time() + timeout
while True:
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        sys.exit(0)
    except OSError:
        if time.time() >= deadline:
            sys.exit(1)
        time.sleep(0.02)
' "$TAP_OBLIGATION_LOCK_FD" "$timeout"
}

# tap_submit_verify <pane> <pane_cmd> <sentinel> <id> [<to-handle>] [<urgent 0|1>] [<id|exact>] [<registry> <bound-handle> <pane-id> [<rowless-session> [<rowless-harness>]]]
# Full submit-verify cycle: pending-input clobber pipeline → inject sentinel →
# verify the id landed in the input band → submit Enter → verify id clears.
#
# v2 clobber policy (Ops, 2026-07-02): pending input NEVER defers delivery. Human
# input in a registered pane is ephemeral by policy — pipeline continuity outranks
# preserving a draft. A stuck [[TAP …]] sentinel is submitted first (recovers a
# prior exit-5 without losing either message); any other text is backed up to
# input-backups/ then cleared. Clearing is BUFFER-LOCAL ONLY; the courier never sends Escape or C-c
# ON ITS OWN — TAP messages queue behind a turn, never preempt it, UNLESS the
# sender explicitly asked to interrupt (urgent=1, delivery-policies plan PR-B):
# the ONE deliberate exception, and it is always sender-initiated, never inferred.
#
# "Verify" means "transport accepted the input and the id left the input line" —
# NEVER "the agent processed the message." This is the sole, shared semantic.
#
# TAP_SV_TYPED_PREFIX (env, optional, tap-lmbs): when set to a non-empty
# string, this call injects it via tap_inject_text as its own FIRST stage (a
# short settle beat follows), then injects `sentinel` as a SECOND stage —
# the typed control must then expose its payload tail before Enter. Ordinary
# non-prefix delivery retains its existing landed and clear verification. Fixes: a slash command sent as
# part of one large send-keys -l burst gets collapsed by Claude Code into a
# "[Pasted text]" chip, and slash-command parsing is disabled inside a pasted
# blob, so the command is never recognized. Typing the command token
# ("/goal ", "/compact ", "/loop ") as its own keystrokes first — ending in a
# trailing space that commits the token and closes the autocomplete popup —
# lands the command before the (possibly still-collapsing) payload arrives.
# The trailing space is REQUIRED: a prefix that doesn't end with exactly one
# space fails closed (stderr + return 5). The variable is read into a local
# and unset at function entry so a value set for one call can never leak into
# a later one. Refused (return 5) when this call would take queue-prefix
# delivery (qprefix non-empty, e.g. hermes) or match_mode=exact: neither path
# ever carries a slash-command payload, so combining them is untested.
# Unset/empty (the default) is byte-for-byte identical to before this
# variable existed.
#
# Exit: 0 submitted+verified | 3 pane gone | 4 deferred | 5 input-miss or
#       submit-unverified | 6 bound identity mismatch
# Stderr: human-readable reason on non-zero.
#
# rc 4 distinguishes why delivery deferred (tap-r49z, tap-7r3fn.36):
#   lock-park — a concurrent submit held this pane's submit lock past
#               TAP_PANE_SUBMIT_LOCK_TIMEOUT. Transient; retry shortly.
#   no-prompt — the pane shows no input band to type into, or (agy) a permission
#               modal is asking the seat for a decision. Wait for the pane, not for
#               a turn to end: mid-turn is NOT this class for any family but hermes,
#               since the rest queue typed input natively (tap-92v3r).
#   booting — OpenCode has not drawn its input band; hold without sending keys.
# The number stays ONE number on purpose: rc 4 is the courier's documented
# defer -> spool path, and renumbering would move a contract every caller
# reads for a benefit that is entirely message-level. Callers that only need
# "defer" keep reading the number and are unaffected; a caller that must tell
# the operator WHY reads TAP_SUBMIT_DEFER_REASON, set to one of those three
# words on every rc-4 return and cleared at entry of every call (same
# stale-value discipline as TAP_SV_TYPED_PREFIX below — a reason left over
# from a previous call would be read as this call's diagnosis).
# It is a plain shell variable, so it survives only a DIRECT call; a caller
# that invokes tap_submit_verify inside $( ) or a pipeline gets the number
# and no reason, and must say so rather than pick one. Set it the way
# TAP_SV_TYPED_PREFIX must be set — never as an invocation-scoped
# `TAP_SUBMIT_DEFER_REASON=x tap_submit_verify ...` prefix. That footgun is
# the same bash rule inverted for an OUTPUT variable: bash restores the
# caller's value when the call returns, so the reason this function just
# cleared and set comes back as whatever the caller had, and the next read
# is a stale diagnosis wearing this call's authority.
#
# TAP_SUBMIT_REPROBE_PENDING is the narrower post-injection output channel. It
# is set only when AGY changes its rendered input between positive landing
# proof and the first Enter, so the caller knows both that the sentinel landed
# and that this attempt sent zero Enters. The direct courier may park that
# already-visible sentinel for a bounded re-probe; it must never re-inject it.
# Like TAP_SUBMIT_DEFER_REASON, this is a plain shell variable and requires a
# direct call.
# Wrapper: acquire the pane's submit lock, run the real cycle, release always.
# A wrapper rather than an unlock before each `return` — the body has two dozen
# exit points and the one missed would leak the lock for that pane permanently.
# Keep the first escaped OpenCode failure frame under the payload id. Run while
# the submit lock is held; capture is read-only and cannot change the delivery rc.
tap_record_opencode_submit_failure() (
  local pane="$1" id="$4" frame target
  [ "${7:-id}" = id ] && tap_valid_id "$id" || return 0
  tap_submit_identity_guard "${8:-}" "${9:-}" "$pane" "${10:-}" "${11:-}" "${12:-}" || return 0
  umask 077
  mkdir -p "$TAP_HOME/receipts" || return 0
  target="$TAP_HOME/receipts/$id.opencode-submit-unverified.ansi"
  [ ! -e "$target" ] || return 0
  frame="$(mktemp "$TAP_HOME/receipts/.opencode-frame.XXXXXX")" || return 0
  if tap_capture_input_frame "$pane" opencode 1 > "$frame"; then
    # Retain raw SGR bytes. Geometry selects the composer, including its footer;
    # an unreadable boundary retains the frame rather than hiding the evidence.
    python3 -B - "$frame" <<'PYFRAME'
import pathlib, re, sys
p = pathlib.Path(sys.argv[1])
lines = p.read_bytes().splitlines(keepends=True)
plain = [re.sub(rb"\x1b\[[0-?]*[ -/]*[@-~]", b"", x).decode("utf-8", "replace") for x in lines]
borders = [i for i, x in enumerate(plain) if re.match(r"^\s*╹▀", x)]
if borders:
    end = borders[-1]
    start = end
    while start and re.match(r"^\s*┃", plain[start - 1]):
        start -= 1
    if start < end:
        p.write_bytes(b"".join(lines[start:]))
PYFRAME
    # First failure wins. A later retry must not replace the original frame.
    ln "$frame" "$target" 2>/dev/null || true
  fi
  rm -f "$frame"
  return 0
)

tap_submit_verify() {
  # KEY OFF $1, NOT ${10}. The lock is documented as keyed on the PANE, and $1
  # IS the pane — every caller passes it, while ${10} (bound_pane_id) is optional
  # and four of the five call sites never reach it: self.sh (:539, :559, :590,
  # :642) and self-compact-submit.sh:62 pass four to seven arguments. Keyed on
  # ${10} those five submits took NO LOCK while appearing to call the locking
  # entry point — the guard failed OPEN ON ARITY, which is invisible at the call
  # site and which a "does this file call the wrapper?" test cannot see
  # (opus-2, gate on #xxx).
  local _sv_pane="$1" _sv_key="${10:-$1}" _sv_rc=0
  local TAP_DELIVERY_EFFECT_STARTED=0 TAP_DELIVERY_ATTEMPT_IDS="${TAP_DELIVERY_ATTEMPT_IDS:-}"
  TAP_SUBMIT_DEFER_REASON=""
  TAP_SUBMIT_REPROBE_PENDING=0
  TAP_SUBMIT_LAST_FRAME=""
  if ! tap_pane_submit_lock "$_sv_key"; then
    # PARK, never proceed. fable's ruling: proceeding unlocked after a bounded
    # wait re-creates the exact fused line the lock prevents, and does it
    # silently. rc 4 is the courier's existing defer -> spool path, so the sender
    # gets an honest queued receipt and standard retry rather than a corrupted
    # submit or a stalled send.
    tap_pane_submit_unlock
    TAP_SUBMIT_DEFER_REASON=lock-park
    echo "tap: another submit holds pane '$_sv_pane' (waited ${TAP_PANE_SUBMIT_LOCK_TIMEOUT:-5}s) -> park" >&2
    return 4
  fi
  local recovery_state
  recovery_state="$(tap_bun_call recovery "$4" recovery/cli.ts guard "$_sv_key")" || recovery_state=park
  if [ "$recovery_state" != allowed ]; then
    tap_pane_submit_unlock
    TAP_SUBMIT_DEFER_REASON=recovery-hold
    echo "tap: recovery owns pane '$_sv_pane' -> park" >&2
    return 4
  fi
  local TAP_DEBUG_FRAME_FILE=""
  export TAP_DEBUG_FRAME_FILE
  if tap_debug_enabled; then
    TAP_DEBUG_FRAME_FILE="$(mktemp "${TMPDIR:-/tmp}/tap-debug-frame.XXXXXX")" || \
      echo 'tap debug: cannot retain courier observations' >&2
  fi
  tap_submit_verify_body "$@" || _sv_rc="$?"
  if [ "$_sv_rc" = 5 ] && [ -s "$TAP_DEBUG_FRAME_FILE" ]; then
    tap_debug_submit_frame "$4" "$2" "$1" "$3" last-observed < "$TAP_DEBUG_FRAME_FILE"
  fi
  [ -z "$TAP_DEBUG_FRAME_FILE" ] || rm -f "$TAP_DEBUG_FRAME_FILE"
  if [ "$_sv_rc" = 5 ] && [ "$2" = opencode ]; then
    tap_record_opencode_submit_failure "$@" || true
  fi
  tap_pane_submit_unlock
  return "$_sv_rc"
}

tap_submit_verify_body() {
  local TAP_SUBMIT_HARNESS_ALIVE=0
  local TAP_SUBMIT_PERMISSIONS TAP_SUBMIT_AUTO_READY=0 TAP_SUBMIT_PRESERVE_DRAFT="${TAP_SUBMIT_PRESERVE_DRAFT:-0}" TAP_SUBMIT_FORCE_NO_PROMPT="${TAP_SUBMIT_FORCE_NO_PROMPT:-0}"
  local pane="$1" cmd="$2" sentinel="$3" id="$4" to_handle="${5:-peer}" urgent="${6:-0}" match_mode="${7:-id}"
  local reprobe_only="${TAP_SUBMIT_REPROBE_ONLY:-0}"
  local bound_registry="${8:-}" bound_handle="${9:-}" bound_pane_id="${10:-}"
  local rowless_session="${11:-}" rowless_harness="${12:-}"
  local _submission_policy
  _submission_policy="$(tap_recorded_permissions "$bound_registry" "$bound_handle" "$TAP_SUBMIT_PRESERVE_DRAFT")" || _submission_policy=unknown
  IFS=$'\x1f' read -r TAP_SUBMIT_PERMISSIONS TAP_SUBMIT_PRESERVE_DRAFT <<< "$_submission_policy"
  if [ "$TAP_SUBMIT_PERMISSIONS" = unknown ]; then TAP_SUBMIT_DEFER_REASON=no-prompt; return 4; fi
  if [ "$TAP_SUBMIT_PERMISSIONS" = auto ]; then
    TAP_SUBMIT_PRESERVE_DRAFT=1
    TAP_SUBMIT_FORCE_NO_PROMPT=0
    if [ "$urgent" = 1 ]; then
      echo 'tap: auto_mode_no_interrupt: auto seat will receive ordinary delivery without Escape' >&2
      urgent=0
    fi
    if ! tap_auto_band_ready "$pane" "$cmd"; then TAP_SUBMIT_DEFER_REASON=no-prompt; return 4; fi
    TAP_SUBMIT_AUTO_READY=1
  fi
  local _pi_rc _tmux_rc typed_input input_region input_region_rc _ landed stuck_id stuck_to stuck_fields backup_path pane_id_now _sf_rc qprefix seq no_prompt_ok backup_lines typed_prefix_rendered
  local preinject_paste_chip=0 pre_inject_chip=0 allow_paste_collapse chip_landed=0 restore_short=0
  local tail_measurement="rendered_bytes=0 expected_bytes=unavailable"
  local pane_obs="" pane_epoch_now="" pane_session_now=""
  local typed_prefix="${TAP_SV_TYPED_PREFIX:-}"
  unset TAP_SV_TYPED_PREFIX
  if [ -n "$typed_prefix" ]; then
    case "$typed_prefix" in
      *'  ')
        echo "tap: TAP_SV_TYPED_PREFIX must end with exactly one trailing space (found two or more): '$typed_prefix'" >&2
        return 5 ;;
      *' ') ;;
      *)
        echo "tap: TAP_SV_TYPED_PREFIX must end with a trailing space: '$typed_prefix'" >&2
        return 5 ;;
    esac
  fi
  allow_paste_collapse=1
  # Queue-prefix delivery (delivery-policies plan): a harness with a safe queue
  # prefix (hermes: '/queue ') is injectable even without a visible idle prompt —
  # the prefix makes mid-turn injection queue instead of interrupt.
  qprefix="$(tap_queue_prefix "$cmd")"
  # Captured BEFORE any urgent override below: this is "does this harness's mid-
  # turn behavior legitimately show no prompt at all" (true for hermes only,
  # whether the send is urgent or default) — the no-visible-prompt defer bypass
  # a few lines down keys on THIS, not on the (possibly urgent-zeroed) qprefix
  # used for the actual injected text.
  no_prompt_ok="$qprefix"
  if [ "$match_mode" = exact ]; then
    # Exact commands are destructive control input, not queueable messages. They
    # require a live prompt and cannot use a transcript-wide Hermes fallback.
    no_prompt_ok=""
    allow_paste_collapse=0
  fi
  # tap-lmbs: evaluated against qprefix's ORIGINAL value (captured above) and
  # placed BEFORE any pane effect — urgent's Escape interrupt and red flash,
  # both below. Urgent zeroes qprefix for its own delivery purposes; checking
  # AFTER that point would erase the very evidence this refusal depends on and
  # let urgent+hermes+typed-prefix slip through with both stages injected and
  # the pane already flashed. Neither the queue-prefix path nor exact-match
  # control input ever carries a slash-command payload, so the combination is
  # refused before anything touches the pane.
  if [ -n "$typed_prefix" ] && { [ -n "$qprefix" ] || [ "$match_mode" = exact ]; }; then
    echo "tap: TAP_SV_TYPED_PREFIX cannot combine with '$cmd' queue-prefix delivery or match_mode=exact — neither path carries a slash-command payload" >&2
    return 5
  fi
  # OpenCode draws an input band even while generating, so a missing band is
  # startup chrome rather than a mid-turn focus signal. Refuse before urgent's
  # Escape or any submit-body pane effect; rc 4 is retry-safe only on this side
  # of the submission boundary.
  if [ "$cmd" = opencode ]; then
    _pi_rc=0
    tap_pending_input_text "$pane" "$cmd" >/dev/null || _pi_rc=$?
    if [ "$_pi_rc" = 5 ]; then
      if [ -n "$bound_registry" ] && [ -n "$bound_handle" ] && [ -n "$bound_pane_id" ]; then
        local _repaint_frame
        _repaint_frame="$(tap_bun_call recovery "$id" recovery/cli.ts repaint-probe \
          "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id")" || _pi_rc=5
        if [ -n "$_repaint_frame" ]; then
          _pi_rc=0
          tap_pending_input_text "$pane" "$cmd" "$_repaint_frame" >/dev/null || _pi_rc=$?
          echo "tap: OpenCode terminal overprint repainted before delivery classification" >&2
        fi
      fi
    fi
    if [ "$_pi_rc" = 5 ]; then
      TAP_SUBMIT_DEFER_REASON=booting
      echo "tap: pane '$pane' has an OpenCode terminal overprint obscuring its input band -> defer" >&2
      return 4
    fi
    if [ "$_pi_rc" = 3 ]; then
      TAP_SUBMIT_DEFER_REASON=booting
      echo "tap: pane '$pane' has no OpenCode input band yet -> defer" >&2
      return 4
    fi
  fi
  # Exactly one native survey dismissal, before urgent Escape and band reads.
  # The wrapper holds the submit lock; native code rechecks bound identity and
  # shared recovery policy. A blocked recovery returns before any sentinel effect.
  if [ "$cmd" = agy ]; then
    local survey_frame survey_recovery
    survey_frame="$(tap_capture_pane -t "$pane" -p)" || { TAP_SUBMIT_DEFER_REASON=no-prompt; return 4; }
    if printf '%s' "$survey_frame" | tap_agy_survey_overlay; then
      tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return 6
      survey_recovery="$(tap_bun_call agy-survey "$id" agy-survey-cli.ts "$pane" "$bound_registry" "$bound_handle" "$bound_pane_id" "$TAP_HOME" "$id")" || survey_recovery=blocked
      case "$survey_recovery" in
        restored|not-survey) ;;
        attempt_evidence_unwritable) TAP_SUBMIT_DEFER_REASON=attempt-evidence; return 8 ;;
        *) TAP_SUBMIT_DEFER_REASON=no-prompt; echo "tap: Antigravity survey blocks composer; no sentinel attempted" >&2; return 4 ;;
      esac
    fi
  fi
  # AGY MODAL REFUSAL, BEFORE URGENT'S KEYSTROKE (tap-92v3r round 3).
  #
  # Ordering, and it is the whole point: urgent's Escape is sent below, before the
  # band pre-check runs tap_agy_permission_overlay. Adding agy to tap_interrupt_seq
  # therefore made `--urgent` press Escape at a pane whose modal refusal had not been
  # evaluated yet — and if Escape dismisses that modal, the later classifier cannot
  # see it and the payload injects into a pane the refusal existed to protect. sol
  # drove exactly that at the review pin and got `escapes=1 pastes=1 modal_remaining=no`:
  # a pane-safety refusal defeated by the effect that precedes it. Round 2 disclosed
  # this ordering in a comment and filed it; that was the wrong call. A disclosure is
  # not a guard, and this one is a regression this delta introduced rather than an
  # inherited property.
  #
  # AGY-SCOPED, deliberately. The general question — should every family's urgent
  # interrupt run after the safety classifier? — is a change to claude, codex, cursor
  # and opencode semantics with its own controls, and it is not this lane's. What is
  # this lane's is the family whose keystroke this PR added. Nothing here alters when
  # the other families Escape.
  #
  # Read the pane ONCE, here, rather than trusting the read below: an urgent send that
  # gets this far will press a key, and the refusal has to be decided on bytes observed
  # before any effect of ours.
  if [ "$urgent" = 1 ] && [ "$cmd" = agy ]; then
    if tap_capture_pane -t "$pane" -p 2>/dev/null | tap_agy_permission_overlay; then
      TAP_SUBMIT_DEFER_REASON=no-prompt
      echo "tap: pane '$pane' is showing a permission prompt -> defer (urgent will not interrupt a pending decision)" >&2
      return 4
    fi
  fi
  if [ "$urgent" = 1 ]; then
    case "$cmd" in claude*|codex*)
      local feedback_frame
      feedback_frame="$(tap_capture_pane -p -e -t "$pane")" || { TAP_SUBMIT_DEFER_REASON=no-prompt; return 4; }
      if printf '%s' "$feedback_frame" | tap_approval_prompt "$cmd"; then
        TAP_SUBMIT_DEFER_REASON=no-prompt
        echo "tap: approval prompt blocks urgent delivery; nothing submitted or cleared" >&2
        return 4
      fi
      if [[ "$cmd" = claude* ]] && printf '%s' "$feedback_frame" | tap_claude_feedback_overlay; then
        TAP_SUBMIT_DEFER_REASON=no-prompt
        echo "tap: Claude feedback dialog blocks urgent delivery; nothing submitted or cleared" >&2
        return 4
      fi
      ;;
    esac
    # Urgent forces the queue prefix off (hermes's bare, un-prefixed inject IS its
    # interrupt — CONTRACT §Delivery policies) and sends the harness's own abort
    # keystroke BEFORE anything else, per Ops's live verification that post-payload
    # interrupt behavior varies by harness (Cursor uses Ctrl+C, never Escape).
    qprefix=""
    seq="$(tap_interrupt_seq "$cmd")"
    if [ -n "$seq" ]; then
      tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-6}"
      tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return 6
      tap_delivery_effect_begin "$id" || { TAP_SUBMIT_DEFER_REASON=attempt-evidence; return 8; }
      # $seq is a small fixed, code-controlled set of bare key names ("Escape" /
      # "Escape Escape") from tap_interrupt_seq — word-splitting it here is the
      # intended way to pass each as its own send-keys argument, never user input.
      tmux send-keys -t "$pane" $seq || {
        [ "$?" != 124 ] || return 124
        echo "tap: pane '$pane' gone before urgent interrupt -> human-relay" >&2
        return 3
      }
      # Give the harness a beat to register the interrupt and redraw before the
      # pending-input pre-check below reads the pane; the landed-verification
      # retry loop further down is the backstop if this isn't quite enough.
      tap_settle 0.15
    fi
    # Interrupt policy does not imply a human draft; bare bands get no flash.

  fi
  if [ "$match_mode" = exact ] && [ -n "$qprefix" ]; then
    echo "tap: exact control input cannot use '$cmd' queue-prefix delivery" >&2
    return 5
  fi
  [ -n "$qprefix" ] && sentinel="${qprefix}${sentinel}"
  # Pre-check: an input prompt must exist. OpenCode keeps its existing busy
  # handling, but a visible paste-collapse chip is still human input that must
  # take the backup/C-u path before its post-inject fallback can be considered.
  if [ "$cmd" != "opencode" ] || [ "${TAP_SUBMIT_NO_SPOOL:-0}" = 1 ] || [ "${TAP_SUBMIT_PRESERVE_DRAFT:-0}" = 1 ]; then
    # ONE pending-input classification, owned by tap_pending_input_text: glyph-aware
    # per harness (incl. cursor's →), and blanks dim idle placeholders including the
    # reverse-video cursor overlay. rc 3 = no visible input prompt -> defer (injection
    # safety). Do NOT re-implement the sed/dim logic inline here — that duplicate
    # drifted from the shared one and shipped the cursor-placeholder bug (Unit F).
    _pi_rc=0
    typed_input="$(tap_pending_input_text "$pane" "$cmd")" || _pi_rc=$?
    if [ "$_pi_rc" != 0 ]; then
      # THE FORCED INJECTION, AND THE ONE THING IT MAY NEVER OVERRIDE (ruling 15 item 2).
      #
      # `TAP_SUBMIT_FORCE_NO_PROMPT=1` is set by the drain after three post-deadline
      # looks at a live, non-modal pane, and it reuses the queue-prefix bypass rather
      # than adding a second way past this gate — one door, two reasons to be allowed
      # through it.
      #
      # rc 4 IS EXCLUDED HERE AS WELL AS IN THE DRAIN, and the duplication is deliberate.
      # The drain refuses to force on `busy:modal`, so this branch should be unreachable
      # for a modal; making it structurally unreachable too means a future caller that
      # sets the variable for some other reason still cannot type over a human's pending
      # decision. The bound is allowed to be aggressive precisely because this one
      # refusal is not reachable by being more aggressive.
      if [ "$_pi_rc" = 3 ] && [ "${TAP_SUBMIT_NO_SPOOL:-0}" = 1 ]; then
        echo "tap: explicit --no-spool attempt with no readable input band -> injecting" >&2
        typed_input=""
      elif [ "$_pi_rc" != 4 ] && [ "${TAP_SUBMIT_FORCE_NO_PROMPT:-0}" = 1 ]; then
        echo "tap: pane '$pane' shows no readable input band; forced delivery after the post-deadline bound -> injecting" >&2
        typed_input=""
      elif [ "$_pi_rc" != 4 ] && [ -n "$no_prompt_ok" ]; then
        # No idle prompt, but this harness takes queue-prefix delivery (default)
        # or IS this harness's urgent interrupt (its bare inject, never escaped):
        # inject anyway. This retires the hermes false-defer class (tap-rd3); the
        # rc-3 defer below stays for non-prefix harnesses as the modal-dialog guard.
        echo "tap: pane '$pane' shows no idle prompt; '$cmd' takes queue-prefix/bare-urgent delivery -> injecting" >&2
        typed_input=""
      else
        TAP_SUBMIT_DEFER_REASON=no-prompt
        # "No visible input prompt", not "busy": for agy this is reached only when
        # there is no rule-pair band at all or a permission modal is up, never merely
        # because a turn is running (tap-92v3r). The wording matters because the
        # operator reads it as the diagnosis.
        echo "tap: pane '$pane' has no visible input prompt -> defer" >&2; return 4
      fi
    fi
  else
    # NO MID-TURN CHECK HERE, DELIBERATELY (tap-toi9, reverting tap-ted6's gate).
    # opencode queues typed input natively like every non-hermes harness, so an
    # ordinary send injects mid-turn and is read at the turn boundary — that is
    # the ratified "default = always inject, always queue" policy stated at
    # tap_queue_prefix (~:6407, Ops live-verified 2026-07-08), and hermes is the
    # only family whose default mid-turn behavior is INTERRUPT.
    #
    # tap-ted6 gated ordinary opencode sends on DB turn state, which reads the
    # rc-3 defer as a mid-turn guard. It is not: it is the MODAL-DIALOG guard —
    # "no input band exists to type into". opencode mid-turn HAS a band (its
    # `esc interrupt` chrome is persistent), so that rationale never applied to
    # the path the gate refused, and the cost was a spool round-trip on every
    # busy opencode send.
    #
    # L1 U4 removed OpenCode's polite DB focus gate as well. A visible composer
    # is ready during a turn; AGY alone retains `busy:in-turn` focus gating in
    # tap_spool_pane_ready. Startup and modal holds remain separate.
    typed_input="$(tap_pending_input_text "$pane" "$cmd")" || typed_input=""
    # Do not broaden OpenCode's ordinary busy/input behavior here. This narrow
    # branch exists so a pre-existing collapse chip receives the same protection
    # as the other harnesses.
    #
    # EXACT MODE ALSO BYPASSES THE SKIP (tap-e034). Zeroing non-chip text keeps
    # ordinary sends off OpenCode's residue path, but it also skips the
    # backup/C-u clobber pipeline entirely — so a control command that failed to
    # land leaves its own text sitting in the band, and the NEXT attempt types on
    # top of it. That is how two `tap refresh` runs produced '/new/new', which
    # matches no command at all ("No matching items"), turning a retry into a
    # state strictly worse than the first failure. Exact mode is destructive
    # control input on a band we must own outright, so it takes the same
    # backup-then-clear path every other harness already takes.
    # A staged TAP anchor must reach the shared sentinel-first recovery below.
    # Otherwise a failed submit lets every later send append to the same input.
    case "${typed_input#"${typed_input%%[![:space:] ]*}"}" in
      '[[TAP'*) ;;
      # THREE ANSWERS, and only one of them may blank the draft. The chip
      # predicate returns 0 chip, 1 no chip, 2 COULD NOT READ. Written as
      # `|| tap_input_has_paste_collapse ... || typed_input=""` the 2 falls
      # through to the blanking arm, so a chip reader that merely failed to run
      # discards the pane owner's text. Rule 19: infrastructure failure never
      # maps to predicate-false, and here predicate-false is destructive.
      *)
        if [ "$match_mode" != exact ]; then
          local _pn_chip_rc=0
          tap_input_has_paste_collapse "$pane" "$cmd" || _pn_chip_rc=$?
          if [ "$_pn_chip_rc" -eq 1 ]; then typed_input=""; fi
        fi ;;
    esac
  fi

  # Content-free rows do not earn draft protection, backup or warning effects.
  if [ -n "$typed_input" ]; then
    local content_rc=0
    printf '%s' "$typed_input" | tap_input_has_text || content_rc=$?
    case "$content_rc" in 1) typed_input="" ;; 2) return 5 ;; esac
  fi

  if [ "$reprobe_only" = 1 ] && [ -z "$typed_input" ]; then
    echo "tap: AGY re-probe no longer sees its staged sentinel -> submit-unverified" >&2
    return 5
  fi

  # Recheck at the shared submit boundary, including a draft that appeared after
  # tap send's early check. Direct means one attempt, never clearing human input.
  if { [ "${TAP_SUBMIT_NO_SPOOL:-0}" = 1 ] || [ "${TAP_SUBMIT_PRESERVE_DRAFT:-0}" = 1 ]; } && [ -n "$typed_input" ]; then
    TAP_SUBMIT_DEFER_REASON=no-prompt
    echo "tap: draft-preserving delivery refuses pending human input" >&2
    return 4
  fi

  if [ -n "$typed_input" ]; then
    tap_input_has_paste_collapse "$pane" "$cmd" && preinject_paste_chip=1
  fi

  if [ -n "$typed_input" ]; then
    stuck_fields="$(tap_stuck_sentinel_fields "$pane" "$cmd" || true)"
    stuck_id=""; stuck_to=""; stuck_wire=""
    [ -n "$stuck_fields" ] && IFS=$'\x1f' read -r stuck_id stuck_to stuck_wire <<< "$stuck_fields"
    # The v0.23 id may carry the sender's team as a locator prefix. Ids on disk are
    # never qualified, and the band's substring match finds the bare id inside the
    # qualified token, so split it and keep the bus separately.
    stuck_id_team=""
    case "$stuck_id" in
      */*) stuck_id_team="${stuck_id%%/*}"; stuck_id="${stuck_id#*/}" ;;
    esac

    if [ "$reprobe_only" = 1 ] \
      && { [ "$stuck_id" != "$id" ] || ! printf '%s' "$typed_input" | tap_agy_reprobe_input_matches "$sentinel"; }; then
      echo "tap: AGY re-probe found altered input; refusing reinjection -> submit-unverified" >&2
      return 5
    fi

    if [ -n "$stuck_id" ]; then
        if [ -n "$bound_registry" ]; then
          tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return 6
        fi
        # Bun owns corroboration and its evidence bus; this retained caller owns
        # the ordered pane effects. Instrument failure is rc5: keep the new
        # canonical and forbid retry, including after an earlier urgent Escape.
        # rc6 is reserved here for the owner's actual recipient disagreement.
        # Self wake must not reinterpret this rc5 as staged-input recovery.
        TAP_SUBMIT_DEFER_REASON=corroboration-failed
        local _sc_result _SC_RC _SC_BUS
        _sc_result="$(mktemp "${TMPDIR:-/tmp}/tap-corroboration.XXXXXX")" || return 5
        if ! tap_bun_call existing-sentinel "$stuck_id" existing-sentinel.ts corroborate --result "$_sc_result" -- \
          "$stuck_wire" "$stuck_id" "$stuck_id_team" "$stuck_to" "$TAP_PAYLOADS" "$TAP_HOME" \
          "$bound_registry" "$bound_handle" "$pane" "${TAP_SELF:-courier}" "$TAP_REGISTRY_EVENTS" \
          "$(tap_spool_team_name)" "${TAP_VERB:-tap}" </dev/null; then
          rm -f "${_sc_result:?}"
          return 5
        fi
        tap_bun_read_pairs "$_sc_result" existing-sentinel
        tap_bun_require_pairs existing-sentinel _SC_RC _SC_BUS
        [ -n "$_SC_BUS" ] || return 5
        case "$_SC_RC" in
          0) TAP_SUBMIT_DEFER_REASON="" ;;
          6) TAP_SUBMIT_DEFER_REASON=""; return 6 ;;
          *) return 5 ;;
        esac
        local stuck_expected="" stuck_bus="$_SC_BUS"
        [ "$stuck_wire" != v023 ] || stuck_expected="$typed_input"
        # Sentinel-first: a stuck courier inject from a prior send. Submitting it
        # delivers that message; a sentinel is NEVER cleared — clearing one would
        # orphan its canonical (bus payload with no push wake, poll-only recovery).
        if [ "$stuck_id" = "$id" ]; then
          # Our own sentinel already sits in the box (a prior inject that missed
          # its Enter). Submitting it IS the delivery — no re-inject needed.
          echo "tap: own sentinel id=$id already pending in '$pane' -> submitting it" >&2
          tap_delivery_effect_begin "$id" || { TAP_SUBMIT_DEFER_REASON=attempt-evidence; return 8; }
          tap_submit_existing_verify "$pane" "$cmd" "$id" 1 id \
            "$bound_registry" "$bound_handle" "$bound_pane_id" 6 "$rowless_session" "$rowless_harness" "$stuck_expected"
          return "$?"
        fi
        echo "tap: stuck sentinel id=$stuck_id in '$pane' -> submitting it first" >&2
        tap_delivery_effect_begin "$id" || { TAP_SUBMIT_DEFER_REASON=attempt-evidence; return 8; }
        _sf_rc=0
        TAP_HOME="$stuck_bus" tap_submit_existing_verify "$pane" "$cmd" "$stuck_id" 1 id \
          "$bound_registry" "$bound_handle" "$bound_pane_id" 6 "$rowless_session" "$rowless_harness" "$stuck_expected" || _sf_rc="$?"
        if [ "$_sf_rc" = 7 ]; then
          tap_bun_call harness-queue "$stuck_id" harness-queue.ts record "$stuck_bus" "$stuck_id"
          _sf_rc=0
        fi
        if [ "$_sf_rc" != 0 ]; then
          echo "tap: stuck sentinel did not submit (rc=$_sf_rc) -> leaving it intact; ours is submit-unverified" >&2
          return "$_sf_rc"
        fi
        # Verified submitted: the input band is clear; fall through to inject ours.
    elif [[ "${typed_input#"${typed_input%%[![:space:] ]*}"}" == '[[TAP'* ]]; then
      # ANCHOR-GATED: the band holds something that ANNOUNCES itself as a sentinel,
      # and no id could be extracted from it. Refuse, read-only, and leave the band
      # exactly as it is.
      #
      # This is gated on the `[[TAP` ANCHOR rather than on a successful parse, and
      # the difference is the whole point. Keying the sentinel-first branch on a
      # non-empty id means every path that fails to yield one — pre-0.23 bytes still
      # in a band at install time, an id split by a visual wrap the parser could not
      # rejoin, chrome sharing the band, a genuinely truncated marker — falls
      # through to the courtesy backup and then the CLOBBER, which is precisely what
      # the sentinel-first rule and CONTRACT's poll-only-recovery promise forbid. A
      # backup makes the loss recoverable; it does not make it acceptable, and "the
      # courier does not eat messages" is not a property that should depend on the
      # parser being right about a shape it has never seen.
      #
      # THE GATE IS THE OPENING ANCHOR, AND ONLY THAT. Not a substring: prose with a
      # sentinel inside it is a HUMAN DRAFT and stays one (the Bun delivery path has
      # an arm pinning exactly that), and a substring gate quietly overturns it —
      # my first cut was the substring form and that arm is what caught it. Not the
      # closed `[[TAP` … `]]` form either: a TRUNCATED marker is the case most worth
      # protecting and is exactly the one with no `]]` to match. What is left says
      # the right thing — the band OPENS as a sentinel, so it is not human prose,
      # and nothing could be read out of it.
      #
      # `tap nudge` reaches the same refusal from its own anchored parse. Stated
      # once, applied at all three sites: submit it when an id is extractable;
      # otherwise refuse, read-only, and leave the band exactly as it is.
      echo "tap: band holds an unparseable [[TAP marker in '$pane' -> refusing to clear it; nothing was submitted" >&2
      return 6
    else
      # Courtesy backup before the clobber. The retained file is the recovery
      # authority; `tap draft` lets its owner view and copy it explicitly.
      # The pane-clobber door owns mechanics; this route keeps the approval,
      # warning-flash, and verdict policy (tap-maavp effect 2).
      input_region_rc=0
      input_region="$(tap_pending_input_region_text "$pane" "$cmd")" || input_region_rc="$?"
      if [ "$input_region_rc" = 4 ]; then
        case "$cmd" in claude*|codex*)
          TAP_SUBMIT_DEFER_REASON=no-prompt
          echo "tap: approval or feedback prompt appeared before draft clearing -> defer" >&2
          return 4 ;;
        esac
      fi
      # A failed second read cannot erase the draft already observed; the door re-reads or fails closed.
      [ "$input_region_rc" = 0 ] || input_region="$typed_input"
      backup_content_rc=0
      printf '%s' "$input_region" | tap_input_has_text || backup_content_rc=$?
      [ "$backup_content_rc" != 2 ] || return 5
      if [ "$backup_content_rc" = 0 ]; then
        # ONE record for id + session + generation (tap-cnka). The observation
        # accompanies both the backup record and the flash; probing the pane
        # and the generation separately can stamp an id from one server with
        # another server's generation.
        pane_obs="$(tap_pane_observe "$pane" 2>/dev/null || true)"
        pane_id_now="${pane_obs%%$'\t'*}"
        pane_epoch_now="${pane_obs##*$'\t'}"
        [ "$pane_epoch_now" = "$pane_obs" ] && pane_epoch_now=""
        pane_session_now="${pane_obs#*$'\t'}"
        pane_session_now="${pane_session_now%%$'\t'*}"
        [ "$pane_session_now" = "$pane_obs" ] && pane_session_now=""
        if [ -z "$pane_id_now" ] || [ -z "$pane_epoch_now" ]; then
          echo "tap: pane generation became unobservable before draft clearing -> human-relay" >&2
          return 6
        fi
        # tap-tayo: pre-clobber RED cue. The urgent path already flashes red before
        # its interrupt, but the DEFAULT direct-inject clobber had NO warning at all
        # — Ops saw the green landed-flash and no red one before his in-progress
        # draft was cleared ("a green flash, but not a red one before the clobber").
        # Best-effort (returns 0 on any failure) and only when we are about to clear
        # REAL human input we just backed up. tap_pane_effect_flash re-verifies the
        # pane identity itself, so a racing pane change can't mis-flash a stranger.
        tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-6}"
        tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return 6
        tap_delivery_effect_begin "$id" || { TAP_SUBMIT_DEFER_REASON=attempt-evidence; return 8; }
        tap_pane_effect_flash_body "$pane" "$pane_id_now" "$id" 'bg=red' 2
        tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-6}"
        door="$(tap_bun_call pane-clobber "$id" pane/cli.ts clobber \
          "$TAP_INPUT_BACKUPS" "$to_handle" "$id" "$pane" "$pane_id_now" "$pane_epoch_now" \
          "${rowless_harness:-$cmd}" "$cmd" - </dev/null 2>/dev/null)" || door=""
        verdict="${door%%$'\x1f'*}"
        case "$verdict" in
          cleared|residue) ;;
          chip-residue)
            echo "tap: paste-collapse draft persists after clear attempts -> leaving it unsubmitted" >&2
            return 5 ;;
          preserved)
            echo "tap: injection.behavior=warn preserves human input" >&2
            return 5 ;;
          backup-failed)
            echo "tap: input backup could not be written -> refusing to clobber" >&2
            return 5 ;;
          identity)
            echo "tap: pane identity changed during clear -> human-relay" >&2
            return 6 ;;
          gone)
            echo "tap: pane '$pane' gone during clear -> human-relay" >&2
            return 3 ;;
          *)
            echo "tap: clobber door failed (verdict ${verdict:-empty}) -> refusing to clobber" >&2
            return 5 ;;
        esac
        # door columns: verdict<US>backup-path<US>lines<US>chip
        backup_path="$(printf '%s' "$door" | awk -F'\037' 'NR==1 { print $2 }')"
        backup_lines="$(printf '%s' "$door" | awk -F'\037' 'NR==1 { print $3 + 0 }')"
        door_chip="$(printf '%s' "$door" | awk -F'\037' 'NR==1 { print $4 + 0 }')"
        if [ -n "$backup_path" ]; then
          if [ "$backup_lines" -le "$TAP_SHORT_DRAFT_MAX_LINES" ]; then
            restore_short=1
          fi
          if [ "$restore_short" = 1 ] && [ "$cmd" = "opencode" ]; then
            restore_short=0
            echo "tap: short input backup restore skipped for OpenCode; view + copy with: tap draft" >&2
            tap_notify_draft_backed_up "$pane" "$pane_id_now" "$pane_epoch_now" "$pane_session_now"
          elif [ "$restore_short" = 1 ] && [ "$door_chip" = 1 ]; then
            restore_short=0
            echo "tap: short input backup restore skipped for paste-collapse placeholder; view + copy with: tap draft" >&2
            tap_notify_draft_backed_up "$pane" "$pane_id_now" "$pane_epoch_now" "$pane_session_now"
          elif [ "$restore_short" != 1 ]; then
            echo "tap: draft backed up — view + copy with: tap draft" >&2
            tap_notify_draft_backed_up "$pane" "$pane_id_now" "$pane_epoch_now" "$pane_session_now"
          fi
        else
          restore_short=0
        fi
        typed_input=""
        if [ "$verdict" = residue ]; then
          allow_paste_collapse=0
          echo "tap: input residue persists after clear attempts -> injecting anyway (pipeline > drafts)" >&2
        fi
      else
        typed_input=""
      fi
    fi
  fi
  tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return 6
  tap_delivery_effect_begin "$id" || { TAP_SUBMIT_DEFER_REASON=attempt-evidence; return 8; }
  if [ -n "$typed_prefix" ]; then
    # Stage 1: type the command token as its own keystrokes, trailing space
    # included — this is what commits it as a real slash command and closes
    # the autocomplete popup, BEFORE the payload (stage 2, which may still
    # collapse into a paste chip) ever lands (tap-lmbs).
    tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-6}"
    _tmux_rc=0
    tap_inject_text "$pane" "$cmd" "$typed_prefix" || _tmux_rc=$?
    [ "$_tmux_rc" != 124 ] || return 124
    if [ "$_tmux_rc" != 0 ]; then
      echo "tap: pane '$pane' gone during typed-prefix inject -> human-relay" >&2
      return 3
    fi
    tap_settle 0.2
    tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return 6
    # tap-lmbs finding 5: send-keys returning success is not proof the prefix
    # actually rendered — a dropped prefix behind a landed payload submits as
    # plain prose, the exact bug class this file exists to fix, one layer
    # down. Verify the prefix is present BEFORE the payload is ever injected.
    # tap_pending_input_text trims exactly one trailing space, so compare
    # against the prefix with its one mandatory trailing space stripped.
    typed_prefix_rendered="$(tap_pending_input_text "$pane" "$cmd" 2>/dev/null || true)"
    if [ "$typed_prefix_rendered" != "${typed_prefix% }" ]; then
      echo "tap: typed prefix did not render in '$pane' before payload injection (want '${typed_prefix% }', saw '$typed_prefix_rendered') -> submit-unverified" >&2
      return 5
    fi
    # tap-tx3s: the reading above is the PROMPT LINE only, so on its own it
    # cannot see a wrapped draft. Captured at width 16: a pane holding
    # '/compact LEFTOVER-DRAFT-TEXT' renders the prompt line as exactly
    # '/compact' with the leftover on continuation rows — the equality passes,
    # and stage 2 then appends the payload to somebody else's draft and submits
    # it. The line comparison is necessary and not sufficient; the region is
    # what makes it sufficient.
    if ! tap_prefix_region_clean "$pane" "$cmd"; then
      echo "tap: input region carries an unclassified row past the typed prefix in '$pane' (wrapped draft, residue, or an unrecognized harness status row) -> submit-unverified" >&2
      return 5
    fi
  fi
  # This is deliberately immediately adjacent to the PAYLOAD inject — in
  # typed-prefix mode that is HERE, after the prefix stage's settle, not
  # before it (tap-lmbs finding 4): a chip that arrives during that settle
  # window is not evidence the PAYLOAD landed either, only that sampling it
  # before the settle let such a chip falsely count once the payload's own
  # landed-check ran. A chip that arrives after THIS sample cannot be
  # evidence of our message.
  tap_input_has_paste_collapse "$pane" "$cmd" && pre_inject_chip=1
  [ "$pre_inject_chip" = 1 ] && allow_paste_collapse=0
  _tmux_rc=0
  if [ -n "$typed_prefix" ]; then
    # Bun bounds each UTF-8 write. Pacing avoids collapse; only the final tail
    # and existing whole-composer Enter guard establish arrival/ownership.
    # Never retry an uncertain chunk or use elapsed time as submission proof.
    local control_chunks control_chunk control_sent=""
    control_chunks="$(tap_bun_call control-payload "$id" slices/control-payload.ts chunks "$sentinel")" || return 5
    while IFS= read -r -d '' control_chunk; do
      tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-6}"
      tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return 6
      tap_inject_text "$pane" "$cmd" "$control_chunk" || { _tmux_rc=$?; break; }
      control_sent+="$control_chunk"
      [ "$control_sent" = "$sentinel" ] || tap_settle 0.2
    done < <(python3 -B - "$control_chunks" "$sentinel" <<'PYCHUNKS'
import json, sys
chunks = json.loads(sys.argv[1])
assert isinstance(chunks, list) and chunks and all(isinstance(c, str) and c and '\0' not in c for c in chunks)
assert ''.join(chunks) == sys.argv[2]
sys.stdout.buffer.write(b''.join(c.encode('utf-8') + b'\0' for c in chunks))
PYCHUNKS
)
    if [ "$_tmux_rc" = 0 ] && [ "$control_sent" != "$sentinel" ]; then
      echo "tap: invalid control chunk plan; Enter withheld -> submit-unverified" >&2
      return 5
    fi
  else
    if [ "$TAP_SUBMIT_PERMISSIONS" = auto ] && ! tap_auto_band_ready "$pane" "$cmd"; then
      TAP_SUBMIT_DEFER_REASON=no-prompt; return 4
    fi
    tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-6}"
    tap_inject_text "$pane" "$cmd" "$sentinel" || _tmux_rc=$?
  fi
  [ "$_tmux_rc" != 124 ] || return 124
  if [ "$_tmux_rc" != 0 ]; then
    echo "tap: pane '$pane' gone during inject -> human-relay" >&2
    return 3
  fi
  # Verify input landed: key on the minted id in the input band, or a known
  # chip only when it transitioned from absent immediately before inject to
  # present after it. Latch that fact for post-Enter clear verification too.
  landed=0
  for _ in 1 2 3 4 5 6; do
    if [ -n "$typed_prefix" ]; then
      # A control's opaque chip is not tail-arrival evidence. Wait without
      # appending potentially pending bytes; refuse before Enter if still opaque.
      tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return 6
      if tail_measurement="$(tap_control_tail_ready "$pane" "$cmd" "$sentinel")"; then
        landed=1
        break
      fi
    else
      if tap_input_has_match "$pane" "$cmd" "$id" "$match_mode"; then
        landed=1
        break
      fi
      if [ "$match_mode" = id ] && [ "$allow_paste_collapse" = 1 ] && tap_input_has_paste_collapse "$pane" "$cmd"; then
        landed=1
        chip_landed=1
        break
      fi
    fi
    tap_settle 0.1   # let the TUI redraw before re-capturing
  done
  if [ "$match_mode" = id ] && [ "$landed" != 1 ] && [ -n "$no_prompt_ok" ]; then
    # tap-dl3 root cause: a queue-prefix harness (hermes) renders its input band
    # WITHOUT a prompt glyph while working, so the glyph-ANCHORED tap_input_has_id
    # can't see the injected '/queue [[TAP …]]' sentinel — the landing check
    # false-negatives and we used to return 5 "did not land" BEFORE pressing Enter.
    # The sender retried, re-injecting, and the /queue lines STACKED unsubmitted
    # (Ops found ~15 glued in the goalie box). Fix (grok8 F1): re-check GLYPH-LESS
    # for the unique id. A POSITIVE observation proves our inject landed and we
    # submit; a genuine miss (send-keys rc=0 but nothing landed) leaves the id absent
    # and still falls through to fail-closed below — never a silent rc=0 loss.
    if tap_queueband_has_id "$pane" "$cmd" "$id"; then
      echo "tap: '$cmd' queue-prefix sentinel observed glyph-less in the input band -> submitting" >&2
      landed=1
    fi
  fi
  if [ "$landed" != 1 ]; then
    if [ -n "$typed_prefix" ]; then
      echo "tap: control tail absent/opaque in '$pane' (${tail_measurement:-rendered_bytes=0 expected_bytes=unavailable}); Enter withheld -> submit-unverified" >&2
    else
      echo "tap: input did not land on '$pane'" >&2
    fi
    return 5
  fi
  # Only a chip that proved this inject landed can extend the post-Enter retry
  # loop. An unrelated paste in that window must not receive another Enter.
  local enter_expected=""
  [ "$match_mode" != id ] || enter_expected="${typed_prefix}${sentinel}"
  tap_submit_existing_verify "$pane" "$cmd" "$id" "$chip_landed" "$match_mode" \
    "$bound_registry" "$bound_handle" "$bound_pane_id" 5 "$rowless_session" "$rowless_harness" "$enter_expected" "$urgent" || return $?
  if [ "$restore_short" = 1 ]; then
    tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return 5
    tap_restore_short_input_backup "$pane" "$cmd" "$backup_path" && return 0
    echo "tap: draft backed up — view + copy with: tap draft" >&2
    tap_notify_draft_backed_up "$pane" "$pane_id_now" "$pane_epoch_now" "$pane_session_now"
  fi
  return 0
}

# Ordinary wire submission: four Enter attempts, each followed by a fresh frame.
# A missing id alone is not acceptance. A known empty composer is positive TUI
# change; unknown/mixed input stops without another key or any draft cleanup.
# Phase records are diagnostics, never retry authority. A failed write preserves
# the original submit result; positive records retain the Enter ordinal/count.
tap_submit_phase() { # <id> <recipient> <phase> [result]
  tap_bun_call submit-phase "$1" submit-phase.ts "$TAP_HOME" "$1" "$_phase_attempt" "$3" "$2" \
    "$_phase_enters" "$_phase_ordinal" "${4:-}" >/dev/null || \
    echo "tap: submission phase evidence unavailable; submit behavior unchanged" >&2
  return 0
}

tap_submit_reprobe_pending() { # <id> — exact zero-Enter AGY transition evidence
  local verdict
  verdict="$(tap_bun_call submit-phase "$1" submit-phase.ts reprobe-pending "$TAP_HOME" "$1")" || return 1
  [ "$verdict" = yes ]
}

tap_submit_transition_verify() {
  local TAP_SUBMIT_HARNESS_ALIVE=0
  local _phase_attempt="${BASHPID:-$$}-${RANDOM}-${RANDOM}-$(date +%s)"
  local _phase_enters=0 _phase_ordinal=0 _phase_confirmed=0 _phase_rc=0 _phase_result=unverified
  tap_submit_transition_body "$@" || _phase_rc=$?
  [ "$_phase_rc" != 0 ] || _phase_result=verified
  [ "$_phase_rc" != 7 ] || _phase_result=queued
  tap_submit_phase "$3" "${7:-}" verify-result "$_phase_result"
  return "$_phase_rc"
}

tap_submit_transition_body() {
  local TAP_RECOVERY_EFFECT_NONE=0
  local pane="$1" cmd="$2" id="$3" allow_chip="${4:-0}"
  local registry="${6:-}" handle="${7:-}" pane_id="${8:-}" identity_rc="${9:-6}"
  local session="${10:-}" harness="${11:-}" expected="${12}" urgent="${13:-0}" entered=0 attempt frame actual rc observed_width mode state fused="" fusion_recovered=0 initial_mode="" nudge_single_enter=0 reobs=0
  local door door_verdict door_obs door_pane_id door_epoch
  case "$cmd:${TAP_NUDGE_SINGLE_ENTER:-0}" in opencode*:1) nudge_single_enter=1 ;; esac
  observed_width="$(tmux display-message -p -t "$pane" '#{pane_width}' 2>/dev/null)" || observed_width=unknown
  for attempt in 0 1 2 3 4; do
    tap_submit_identity_guard "$registry" "$handle" "$pane" "$pane_id" "$session" "$harness" || return "$identity_rc"
    if [ "$(tmux display-message -p -t "$pane" '#{pane_in_mode}' 2>/dev/null)" != 0 ]; then
      TAP_SUBMIT_LAST_FRAME="unobservable, copy-mode, width ${observed_width:-unknown}"
      echo "tap: $TAP_SUBMIT_LAST_FRAME -> submit-unverified" >&2; return 5
    fi
    frame="$(tap_capture_input_frame "$pane" "$cmd" 1 2>/dev/null)" || {
      TAP_SUBMIT_LAST_FRAME="unobservable, width ${observed_width:-unknown}"
      echo "tap: $TAP_SUBMIT_LAST_FRAME -> submit-unverified" >&2; return 5
    }
    local classification
    classification="$(printf '%s' "$frame" | tap_bun_call submit-state "$id" submit-frame.ts submit-state \
      "$cmd" "$expected" "${TAP_SUBMIT_HARNESS_ALIVE:-0}")" || return 5
    IFS=$'\t' read -r state mode fused <<< "$classification"
    case "$state:$mode" in
      queued:working|staged:idle|staged:working|staged:mid-turn|empty:idle|empty:working|empty:mid-turn|changed:idle|changed:working|changed:mid-turn|unobservable:idle|unobservable:working|unobservable:mid-turn) ;;
      *) echo "tap: invalid submit frame decision -> submit-unverified" >&2; return 5 ;;
    esac
    # Before Enter, retain foreign bytes around our wire, clear, and re-inject
    # once. A second fusion stops unverified (tap-maavp effect 2).
    if [ "$state" = changed ] && [ "$fused" = 1 ] && [ "${_phase_enters:-0}" = 0 ]; then
      if [ "$fusion_recovered" = 1 ]; then
        TAP_SUBMIT_LAST_FRAME="changed (fused after recovery), $mode, width ${observed_width:-unknown}"
        echo "tap: fused band persisted after bounded re-inject -> submit-unverified" >&2
        return 5
      fi
      fusion_recovered=1
      if tap_debug_enabled; then
        printf '%s' "$frame" | tap_debug_submit_frame "$id" "$cmd" "$pane" "$expected" "transition-fused"
      fi
      tap_submit_identity_guard "$registry" "$handle" "$pane" "$pane_id" "$session" "$harness" || return "$identity_rc"
      door_obs="$(tap_pane_observe "$pane" 2>/dev/null)" || door_obs=""
      door_pane_id="${door_obs%%$'\t'*}"
      door_epoch="${door_obs##*$'\t'}"
      [ "$door_epoch" = "$door_obs" ] && door_epoch=""
      if [ -z "$door_pane_id" ] || [ "$door_pane_id" != "${pane_id:-$pane}" ] || [ -z "$door_epoch" ]; then
        echo "tap: pane identity changed before fused-band recovery (observed ${door_pane_id:-unknown}/${door_epoch:-unknown}, expected ${pane_id:-$pane}) -> human-relay" >&2
        return "$identity_rc"
      fi
      tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-$identity_rc}"
      tap_pane_effect_flash_body "$pane" "$door_pane_id" "$id" 'bg=red' 2
      tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-$identity_rc}"
      door="$(tap_bun_call pane-clobber "$id" pane/cli.ts clobber \
        "$TAP_INPUT_BACKUPS" "${handle:-$id}" "$id" "$pane" "$door_pane_id" "$door_epoch" \
        "${harness:-$cmd}" "$cmd" "$expected" </dev/null 2>/dev/null)" || door=""
      door_verdict="${door%%$'\x1f'*}"
      case "$door_verdict" in
        cleared|residue) ;;
        identity) echo "tap: pane identity changed during fused-band recovery -> human-relay" >&2; return "$identity_rc" ;;
        gone) echo "tap: pane '$pane' gone during fused-band recovery -> human-relay" >&2; return 3 ;;
        *) echo "tap: fused-band recovery failed ($door_verdict) -> submit-unverified" >&2; return 5 ;;
      esac
      tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-$identity_rc}"
      tap_inject_text "$pane" "$cmd" "$expected" || {
        echo "tap: fused-band re-injection refused by '$pane' -> submit-unverified" >&2
        return 5
      }
      # The re-injected wire can lag one TUI redraw: a single settle-then-capture
      # may still see the stale pre-recovery band and trip the second-fusion
      # terminal above even though the sole sentinel landed. Re-observe briefly
      # for it — the read-only shape of the post-injection landing loop. This
      # probe never Enters and writes nothing, so an exhausted bound simply
      # falls through to the loop's own capture and terminal handling.
      for reobs in 1 2 3; do
        tap_settle 0.1
        frame="$(tap_capture_input_frame "$pane" "$cmd" 1 2>/dev/null)" || break
        classification="$(printf '%s' "$frame" | tap_bun_call submit-state "$id" submit-frame.ts submit-state \
          "$cmd" "$expected" "${TAP_SUBMIT_HARNESS_ALIVE:-0}")" || break
        IFS=$'\t' read -r state mode fused <<< "$classification"
        [ "$state" = staged ] && break
      done
      continue
    fi
    if [ "$state" = queued ]; then
      tap_submit_identity_guard "$registry" "$handle" "$pane" "$pane_id" "$session" "$harness" || return "$identity_rc"
      return 7
    fi
    [ -n "$initial_mode" ] || initial_mode="$mode"
    if [ "$entered" = 1 ] && [ "$state" = unobservable ] && [ "$mode" = working ] && [ "$initial_mode" != working ]; then return 0; fi
    TAP_SUBMIT_LAST_FRAME="$state, $mode, width ${observed_width:-unknown}"
    if [ "$entered" = 1 ] && [ "$state" = empty ]; then return 0; fi
    if [ "$state" != staged ] || [ "$attempt" = 4 ]; then
      # AGY can repaint a terminal-operation layer over its composer between
      # the positive post-inject read and this pre-Enter read. `changed` before
      # the first Enter is therefore a safe retry boundary for the SAME visible
      # sentinel: injection is proven, and `_phase_enters=0` proves this attempt
      # has not submitted anything. The public courier parks it for one bounded
      # re-probe; every other changed/unobservable shape remains terminal.
      if [ "$cmd" = agy ] && [ "$state" = changed ] && [ "$_phase_enters" = 0 ]; then
        if [ "$_phase_confirmed" = 0 ]; then
          tap_submit_phase "$id" "$handle" injected-text-confirmed
          _phase_confirmed=1
        fi
        TAP_SUBMIT_REPROBE_PENDING=1
      fi
      if tap_debug_enabled; then
        printf '%s' "$frame" | tap_debug_submit_frame "$id" "$cmd" "$pane" "$expected" "transition-$state"
      fi
      echo "tap: $TAP_SUBMIT_LAST_FRAME -> submit-unverified" >&2; return 5
    fi
    if [ "$nudge_single_enter" = 1 ] && [ "$entered" = 1 ]; then
      if tap_debug_enabled; then
        printf '%s' "$frame" | tap_debug_submit_frame "$id" "$cmd" "$pane" "$expected" "transition-still-staged-after-nudge"
      fi
      echo "tap: OpenCode nudge already sent its single Enter and the sentinel is still staged -> submit-unverified" >&2
      return 5
    fi
    if [ "$_phase_confirmed" = 0 ]; then
      tap_submit_phase "$id" "$handle" injected-text-confirmed
      _phase_confirmed=1
    fi
    _phase_ordinal=$((_phase_ordinal + 1))
    tap_submit_phase "$id" "$handle" Enter-intent
    # Recheck binding immediately before the effect, after frame parsing.
    tap_submit_identity_guard "$registry" "$handle" "$pane" "$pane_id" "$session" "$harness" || return "$identity_rc"
    tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-$identity_rc}"
    rc=0
    TAP_RECOVERY_EFFECT_NONE=0
    tmux send-keys -t "$pane" Enter || rc=$?
    # Only the recorded recovery adapter certifies 125 as no keys attempted.
    # Other failures remain possible effects; intent already has its ordinal.
    if [ "$TAP_RECOVERY_EFFECT_NONE" = 1 ] && [ "$rc" = 125 ]; then return 5; fi
    _phase_enters=$((_phase_enters + 1))
    [ "$rc" != 124 ] || return 124
    [ "$rc" = 0 ] || return 3
    tap_submit_phase "$id" "$handle" Enter-sent
    # Cursor's plain delivery is one two-Enter sequence, not a queue retry.
    # Send the second even when the first already moved the text into its queue.
    if [[ "$cmd" = cursor* ]] && [ "$urgent" != 1 ]; then
      tap_settle 0.25
      tap_submit_identity_guard "$registry" "$handle" "$pane" "$pane_id" "$session" "$harness" || return "$identity_rc"
      [ "$(tmux display-message -p -t "$pane" '#{pane_in_mode}' 2>/dev/null)" = 0 ] || return 5
      _phase_ordinal=$((_phase_ordinal + 1))
      tap_submit_phase "$id" "$handle" Enter-intent
      tap_submit_identity_guard "$registry" "$handle" "$pane" "$pane_id" "$session" "$harness" || return "$identity_rc"
      tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-$identity_rc}"
      rc=0
      TAP_RECOVERY_EFFECT_NONE=0
      tmux send-keys -t "$pane" Enter || rc=$?
      if [ "$TAP_RECOVERY_EFFECT_NONE" = 1 ] && [ "$rc" = 125 ]; then return 5; fi
      _phase_enters=$((_phase_enters + 1))
      [ "$rc" != 124 ] || return 124
      [ "$rc" = 0 ] || return 3
      tap_submit_phase "$id" "$handle" Enter-sent
    fi
    entered=1
    if [ "$attempt" = 3 ]; then
      tap_settle 1.5
    else
      tap_settle 0.5
    fi
  done
}

# tap_submit_existing_verify <pane> <pane_cmd> <id> [<allow-paste-collapse 0|1>] [<id|exact>] [<registry> <bound-handle> <pane-id> [<identity-rc> [<rowless-session> [<rowless-harness>]]]]
# Submit an already-visible sentinel and verify its id clears from the input band.
# Used after a caller has already confirmed its sentinel is visible. Callers pass
# `1` when a known chip may replace that confirmed sentinel after Enter.
tap_submit_existing_verify() {
  local TAP_SUBMIT_HARNESS_ALIVE=0
  # The recovery adapter certifies "no keys were sent" as exit 125 and sets this
  # flag (tap-nudge.sh); tap_submit_transition_body already honours that pair for
  # the modern path, but its copy is local to that function and invisible here.
  # Declared local so an inherited value can never be read as certification and
  # ours can never leak to a caller. Reset immediately before each Enter below.
  local TAP_RECOVERY_EFFECT_NONE=0
  local pane="$1" cmd="$2" id="$3" allow_paste_collapse="${4:-0}" match_mode="${5:-id}"
  local bound_registry="${6:-}" bound_handle="${7:-}" bound_pane_id="${8:-}" identity_rc="${9:-6}"
  local rowless_session="${10:-}" rowless_harness="${11:-}" sent _ second_enter_done=0 tmux_rc=0
  local expected="${12:-}" urgent="${13:-0}" entered=0 proof_rc=0 nudge_single_enter=0
  case "$cmd:${TAP_NUDGE_SINGLE_ENTER:-0}" in opencode*:1) nudge_single_enter=1 ;; esac
  if [[ "$expected" == '[[TAP v0.23 '* ]]; then
    tap_submit_transition_verify "$@"
    return $?
  fi
  # A swallowed primary Enter gets one extra attempt after the 0.5s commit beat.
  # Fresh inject callers supply their full input: before every Enter, a new frame
  # must still match it. Clear input ends verification without another keypress;
  # mixed or unreadable input stops unverified. Legacy sentinel-first/nudge calls
  # and exact-mode controls omit expected and retain their existing contract.
  sent=0
  for _ in 1 2 3 4 5; do
    tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness" || return "$identity_rc"
    if [ -n "$expected" ]; then
      proof_rc=0
      tap_submit_enter_ready "$pane" "$cmd" "$expected" "$id" "$allow_paste_collapse" "$entered" || proof_rc=$?
      case "$proof_rc" in 0) ;; 2) return 0 ;; *) return 5 ;; esac
    fi
    if [ "$nudge_single_enter" = 1 ] && [ "$entered" = 1 ]; then
      echo "tap: OpenCode nudge already sent its single Enter and the sentinel is still staged -> submit-unverified" >&2
      return 5
    fi
    tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-$identity_rc}"
    tmux_rc=0
    TAP_RECOVERY_EFFECT_NONE=0
    tmux send-keys -t "$pane" Enter || tmux_rc=$?
    [ "$tmux_rc" != 124 ] || return 124
    # Only the recorded recovery adapter certifies 125 as no keys attempted for
    # THIS Enter: a refusal it declined to act on is submit-unverified, not a
    # vanished pane. Both predicates are required -- an unflagged 125 is not
    # certification, and it says nothing about an Enter already sent.
    if [ "$TAP_RECOVERY_EFFECT_NONE" = 1 ] && [ "$tmux_rc" = 125 ]; then
      echo "tap: recovery refused this Enter -> submit-unverified" >&2
      return 5
    fi
    if [ "$tmux_rc" != 0 ]; then
      echo "tap: pane '$pane' gone during submit -> human-relay" >&2
      return 3
    fi
    entered=1
    if [ "$nudge_single_enter" != 1 ] && [ "$second_enter_done" = 0 ] && { [[ "$cmd" != cursor* ]] || [ "$urgent" != 1 ]; }; then
      second_enter_done=1
      if [[ "$cmd" = cursor* ]]; then tap_settle 0.25; else tap_settle 0.5; fi
      # An ordinary failure is caught by verification below. A timeout may have
      # submitted, so it must stop here before the loop can send another Enter.
      if tap_submit_identity_guard "$bound_registry" "$bound_handle" "$pane" "$bound_pane_id" "$rowless_session" "$rowless_harness"; then
        if [ -n "$expected" ]; then
          proof_rc=0
          tap_submit_enter_ready "$pane" "$cmd" "$expected" "$id" "$allow_paste_collapse" "$entered" || proof_rc=$?
          case "$proof_rc" in 0) ;; 2) return 0 ;; *) return 5 ;; esac
        fi
        tap_submit_owner_guard || return "${TAP_SUBMIT_OWNER_MISMATCH_RC:-$identity_rc}"
        tmux_rc=0
        TAP_RECOVERY_EFFECT_NONE=0
        tmux send-keys -t "$pane" Enter || tmux_rc=$?
        [ "$tmux_rc" != 124 ] || return 124
        # Same certified-refusal pair as the primary Enter. Any other nonzero
        # result still falls through to content verification, which may yet
        # succeed -- only the certified no-keys case short-circuits.
        if [ "$TAP_RECOVERY_EFFECT_NONE" = 1 ] && [ "$tmux_rc" = 125 ]; then
          echo "tap: recovery refused this Enter -> submit-unverified" >&2
          return 5
        fi
      else
        return "$identity_rc"
      fi
    fi
    tap_settle 0.15   # let the submit render before verifying (TUI redraw race)
    # A collapse chip remains visible while a provenance-confirmed input (freshly
    # injected or just-read as a stuck sentinel) is still present, so it cannot
    # count as cleared. Calls without that provenance use the minted-id check.
    # THREE answers from this predicate, and the third one is new with the
    # native reader. `1` means the id is no longer in the band, which is the
    # evidence that the payload was consumed. `2` means the band could not be
    # READ at all — a missing runtime, a module that failed to load, a verdict
    # the adapter does not recognize — and that is not evidence of anything.
    # Reading it as consumption would let a crashed reader certify an unverified
    # submit, which is exactly the shape rule 19 forbids.
    #
    # An unreadable band therefore takes neither branch: the loop looks again,
    # and if it never gets a readable answer the exhaustion path below refuses
    # with `submit-unverified`. The incumbent had the same hole by a different
    # route — a crashed `tap_normalize_input_match` left an empty haystack,
    # which matched nothing and read as consumed — so this is a fix riding the
    # port, ratified in the PR body rather than folded in silently.
    local _pn_inj_rc=0
    tap_input_has_injected_content "$pane" "$cmd" "$id" "$allow_paste_collapse" "$match_mode" || _pn_inj_rc=$?
    if [ "$_pn_inj_rc" = 1 ]; then sent=1; break; fi
  done
  [ "$sent" = 1 ] || {
    if ! tap_pane_alive "$pane" >/dev/null; then
      echo "tap: pane '$pane' gone during submit verification -> human-relay" >&2
      return 3
    fi
    echo "tap: id '$id' did not leave the input line of '$pane' -> submit-unverified" >&2; return 5
  }
  return 0
}

# ==============================================================================
# Delivery drivers (TAP 1.0 spine, tap-49kp6)
# ==============================================================================
# ONE branch point sits between the courier and the pane. Today exactly one
# driver exists — `tmux` — and it delegates to `tap_submit_verify` unchanged, so
# the unmodified smoke suite is the behavior-identical proof. A native driver
# (Lane B) adds a file under drivers/ and a config value; nothing here changes.
#
# Design authority: tmp/plans/tap1/design-tap1-v2.md §3.1-3.3, §3.7, §3.8.
# Settlement invariants it must not break: tmp/plans/tap1/invariants-settlement.md
# (I-1 driver success is never a receipt; I-2 the obligation layer audits the
# transport identically across drivers; I-12 evidence tiers are stated, never
# inflated).
#
# NOT migrated in this PR, deliberately: `compact.ts` through tap_submit_verify (control injection) and
# the redelivery/digest/nudge callers in this file all still call
# `tap_submit_verify` directly. They are M2 extraction targets; moving them here
# now would widen the branch point past the one hop this change is allowed to own.

# The tmux driver runs IN-PROCESS, never in a subshell, and that is load-bearing
# rather than an optimization: `tap_submit_verify` reports its defer origin
# through the plain shell variable TAP_SUBMIT_DEFER_REASON, which does not
# survive `$( )` or a pipeline (see the helper's own docstring), and the courier
# reads its stderr through a caller-owned redirect. Subshell isolation is the
# NATIVE-driver rule (design §3.9), where an `exit` in vendor code must kill the
# attempt instead of the courier. tmux IS the courier; isolating it would change
# the behavior this PR exists to preserve.

# Where non-builtin drivers are loaded from. Lane B drops `<name>.sh` here; the
# gate's conformance simulators point this at their own fixture directory.
tap_driver_dir() { printf '%s' "${TAP_DRIVER_DIR:-$_TAP_SCRIPT_DIR/drivers}"; }

# The operator config, same location contract the launcher uses for [harness.*].
tap_driver_config_path() {
  # UNSET HOME AND XDG_CONFIG_HOME IS ALREADY HANDLED, and deliberately left as
  # it is. The nounset error happens INSIDE this command substitution, so it
  # fails the substitution rather than killing the courier: the nonzero is caught
  # by tap_driver_for_harness, the early preflight maps it to exit 1 with
  # error_class=driver_unavailable, and all of that is before canonical
  # placement, so no orphan is left. Verified through the real courier by
  # sol-pinnacle and again here; arm (nohome) pins it.
  #
  # A rewrite was written and reverted rather than kept: it changed nothing
  # observable and would have implied the old form was unsafe.
  local base="${XDG_CONFIG_HOME:-$HOME/.config}"
  # The launcher's contract is an ABSOLUTE config home. A relative one makes the
  # selected driver a function of the courier's cwd, so a repository checkout
  # containing ./tap/config.toml could choose the delivery door for a send that
  # merely happened to run from there. Empty stdout is the refusal signal; the
  # caller turns it into a loud one.
  case "$base" in
    /*) printf '%s/tap/config.toml' "$base" ;;
    *)  return 1 ;;
  esac
}

# Driver names are used to build a function name, so the shape is checked before
# anything is resolved with it.
TAP_DRIVER_NAME_RE='^[a-z][a-z0-9_]*$'
# Drivers this hop actually has a call site for.
#
# THIS IS A CODE FACT, NOT A SETTING, and it is a function with the list inline
# rather than a variable, so there is no environment seam to widen it through.
# The earlier version read an environment variable, and sol-pinnacle showed on a
# live probe that exporting it with a widened set restored the exact failure the gate was added to close: one malformed native
# invocation, then the parked payload crossing to tmux via `tap_spool_redeliver`
# (which calls `tap_submit_verify` directly). An earlier version of this comment
# said "permanent retry loop"; that mechanism does not exist, and sol-pinnacle
# traced the drain to show it.
# The CONTRACT sentence
# shipped alongside it -- "widening this set is a wiring change, not a config
# change" -- was therefore FALSE on that tree: the environment is operator-
# settable at runtime, which makes it a config change by any reading.
#
# The asymmetry that makes TAP_DRIVER_FORCE_TMUX legitimate and this not:
# **the environment may NARROW what is selectable, never WIDEN it.** Narrowing
# to tmux is an emergency deny and cannot reach a door that has no call site;
# widening reaches exactly those doors.
#
# Tests override this FUNCTION after sourcing (a function definition is not an
# environment seam and ships nothing), which is why arm (w-mirror) still bounds
# the fix: a mutant that hardcodes the name `ccnative` ignores this function
# entirely, so the override cannot rescue it and the mirror reds.
# tap_registry_acting_session_id <registry> <handle> -> the seat's ACTING native
# session id on stdout, or rc 1.
#
# READ AT DELIVERY TIME, never persisted at launch -- the same rule
# `tap_driver_for_harness` states for the driver preference, and for a sharper
# reason here: a seat that runs `/clear` or `/compact` mints a new native id and
# TAP adopts it on the next SessionStart (tap-o07f2). A value captured at launch
# is stale from the first clear onward, and a native driver handed a stale id
# refuses `session_id_split`.
#
# NOT "silently": the refusal is `retry-next-rung`, so the attempt IS recorded
# against ccnative with `session_id_split` as its detail, the payload spools, and
# the drain redelivers over tmux. The mail arrives and the record says which door
# refused. What is missing is anyone READING that record -- tap-eloxh owns the
# durable "is native being exercised?" surface. Silent to an operator, not silent
# in the log, and the difference matters because one is a reporting gap and the
# other would be a lost message.
#
# ACTING, not quarantined. When the two differ the row is saying the seat's
# identity is UNSETTLED, and a driver must bind to what TAP is prepared to defend
# rather than to whichever value looks more current. Reading the quarantined
# field here would route native delivery to an id TAP explicitly refused --
# the quarantine would still be on the row, and the delivery would have
# ignored it.
tap_registry_acting_session_id() {
  local registry="${1:-}" handle="${2:-}" sid=""
  [ -n "$registry" ] && [ -n "$handle" ] && [ -f "$registry" ] || return 1
  # HEREDOC INSIDE `$( )` DOES NOT PARSE UNDER BASH 3.2, which is /bin/bash on
  # macOS and the shell `bash32-parse.test.sh` pins every shipped file against.
  # This is the SECOND time this trap fired in this lane -- the first was the
  # regress fingerprint file, fixed hours earlier with this exact remedy, and I
  # walked back into it because the construct reads fine under bash 5 and `bash -n`
  # on a modern shell says nothing. Redirect into a temp file; the substitution
  # disappears and both shells parse.
  local _sidfile
  _sidfile="$(mktemp "${TMPDIR:-/tmp}/tap-acting-sid.XXXXXX")" || return 1
  TAP_SCRIPTS_DIR="${_TAP_SCRIPT_DIR}" python3 -B - "$registry" "$handle" >"$_sidfile" 2>/dev/null <<'PYSEAT' || true
import json, os, sys
sys.path.insert(0, os.environ.get("TAP_SCRIPTS_DIR") or "")
try:
    from registry_v20 import _seat_map
except Exception:
    # NO RAW FALLBACK. The seat map is the sanctioned accessor for both registry
    # shapes (`seats` post-flip, `agents` pre-flip), and reaching past it is what
    # shell-seats-axis-enum exists to catch -- it caught this function's first
    # version. Refusing here is also the right behavior: without the accessor we
    # cannot read the acting id, and the arg-builder turns that into a loud
    # pre-attempt refusal rather than a native send bound to nothing.
    raise SystemExit(0)
try:
    reg = json.load(open(sys.argv[1]))
except Exception:
    raise SystemExit(0)
ent = _seat_map(reg).get(sys.argv[2]) or {}
sid = ent.get("harness_session_id")
if isinstance(sid, str) and sid:
    print(sid)
PYSEAT
  sid="$(cat "$_sidfile")"
  rm -f "$_sidfile"
  [ -n "$sid" ] || return 1
  printf '%s' "$sid"
}

# Native AGY/Claude adapters are retired. The remaining generic dispatcher keeps
# tmux outcome/effect recording; configuration cannot revive a removed adapter.
tap_driver_wired_list() { # -> the wired set, space-separated. THE single source.
  printf 'tmux'
}
tap_driver_is_wired() { # <driver-name> -> rc 0 if this hop has a call site for it
  case " $(tap_driver_wired_list) " in
    *" $1 "*) return 0 ;;
    *)        return 1 ;;
  esac
}

# tap_driver_for_harness <family> -> driver name on stdout, or rc 1 + a stderr
# reason. Read at DELIVERY time, never persisted at launch: an operator flipping
# a seat back to tmux must not have to relaunch it.
#
#   TAP_DRIVER_FORCE_TMUX=1  core-wide emergency deny, checked BEFORE the config
#                            is opened — an emergency switch a malformed config
#                            could block is not an emergency switch.
#   key absent / no config   tmux (the universal fallback)
#   unrecognized shape       loud refusal naming the key and the value; never a
#                            silent fallback to tmux, because the whole point of
#                            the preference is that the operator can tell which
#                            door their mail went through.
tap_driver_for_harness() {
  local family="${1:-}" cfg value rc=0 _tap_adv
  if [ "${TAP_DRIVER_FORCE_TMUX:-0}" = "1" ]; then printf 'tmux'; return 0; fi
  [ -n "$family" ] || { printf 'tmux'; return 0; }
  cfg="$(tap_driver_config_path)" || {
    echo "tap: XDG_CONFIG_HOME is relative or unusable (\"${XDG_CONFIG_HOME:-}\"); the launcher's contract is an absolute config home, and a cwd-relative one would let the working directory choose the delivery door. Refusing." >&2
    return 1
  }
  # NO CONFIG FILE AT ALL is the documented default. A file that EXISTS but
  # cannot be used is a refusal, not a fallback — the operator wrote something,
  # and silently ignoring it is the undetectable selection this preference exists
  # to prevent.
  # -e follows the link, so a DANGLING symlink is false here and would take the
  # no-config default -- silently ignoring a config the operator can see in a
  # directory listing. -L catches the link itself; an unreadable config is a
  # refusal, never a fallback.
  if [ ! -e "$cfg" ]; then
    if [ -L "$cfg" ]; then
      echo "tap: $cfg is a dangling symlink; refusing rather than silently selecting tmux for a config that is present but unreadable" >&2
      return 1
    fi
    printf 'tmux'; return 0
  fi
  value="$(tap_driver_config_resolve "$cfg" "$family")" || rc=$?
  if [ "$rc" = 3 ]; then
    echo "tap: [harness.$family] driver = \"\" in $cfg names no driver; remove the key to use tmux" >&2
    return 1
  fi
  if [ "$rc" = 4 ]; then
    # NO TOML PARSER (Python 3.10) AND A CONFIG THAT EXISTS.
    #
    # Two of sol-pinnacle's findings meet here and both are right. Reachability
    # is not intent: a config naming a driver must not be answered with a
    # successful send through tmux. And the documented floor says ordinary sends
    # keep working on 3.10: refusing on any existing config bricks every operator
    # who copied the shipped reference.
    #
    # THE FIRST ATTEMPT AT A MIDDLE PATH WAS WRONG AND IS RECORDED SO IT IS NOT
    # RETRIED: test the raw bytes for `driver` and default only when absent. TOML
    # keys repeat across tables -- the reference's own `[roles]` table has a
    # `driver` key describing a human role, and the file's comments discuss the
    # word at length -- so the test fires on documents with no harness
    # preference at all. Deciding WHICH table a key belongs to is parsing, which
    # is the thing that is unavailable here.
    #
    # So the honest choice is availability with a non-silent default -- and the
    # reason is NOT the one first written here. That version said the operator
    # reaching this line "HAND-WROTE a preference". grok drove it false: a
    # parserless courier can see only that a file EXISTS, so a keyless copy of
    # the shipped reference lands here identically to `driver = "ccnative"`. The
    # population at this line is "has a config.toml", which includes everyone who
    # followed the `cp` in that file's own header.
    #
    # That is why refusing here would brick the floor population rather than
    # catching the preferer: the preferer CANNOT BE IDENTIFIED without parsing.
    # Availability wins on that ground alone.
    #
    # The residual is real and stated rather than dressed: a programmatic sender
    # that checks only the return code sees success through tmux for a non-tmux
    # key nobody could prove was there. Inherent without a parser. The
    # diagnostic is therefore worded conditionally -- "if you set a non-tmux
    # driver" -- because that is the strongest true claim available here. It is
    # unconditional and repeats; a once-only notice is how this becomes silent.
    # THE ADVISORY MUST NOT SHARE A CHANNEL WITH DRIVER STDERR. sol-pinnacle
    # traced the first version: tap-send runs the dispatcher with 2>"$_sv_err",
    # so this line landed in the DRIVER'S detail file -- which the rc 4 and rc 5
    # paths read one line from and then delete. Only the .sent path cats it, so
    # the advertised "unconditional, repeating" warning was emitted on success
    # and SILENTLY DISCARDED on every deferred or submit-unverified send. The
    # claim was true of this function in isolation and false at the courier,
    # which is the only place it matters.
    #
    # TAP_DRIVER_ADVISORY_FILE is caller-owned: the caller creates it, emits it
    # unconditionally BEFORE any outcome branch, and removes it. A channel owned
    # by the outcome paths inherits their lifecycle; this one does not.
    _tap_adv="tap: $cfg exists but this python3 has no tomllib (needs 3.11+), so any driver preference in it CANNOT BE READ and this send is going through tmux. If you set a non-tmux driver it is NOT in effect. Fix with python3.11+, remove $cfg, or set TAP_DRIVER_FORCE_TMUX=1 to make the tmux choice explicit"
    if [ -n "${TAP_DRIVER_ADVISORY_FILE:-}" ]; then
      printf '%s\n' "$_tap_adv" >> "$TAP_DRIVER_ADVISORY_FILE"
    else
      printf '%s\n' "$_tap_adv" >&2
    fi
    printf 'tmux'
    return 0
  fi
  if [ "$rc" != 0 ]; then
    echo "tap: $cfg is unusable (insecure source, malformed TOML, or a non-string driver value); refusing rather than silently selecting tmux" >&2
    return 1
  fi
  # An absent key resolves empty (rc 0) and takes the documented default; a
  # present-but-empty key arrives as rc 3 above and was already refused.
  [ -n "$value" ] || { printf 'tmux'; return 0; }
  if ! printf '%s' "$value" | grep -Eq "$TAP_DRIVER_NAME_RE"; then
    echo "tap: [harness.$family] driver = \"$value\" in $cfg is not a legal driver name" >&2
    return 1
  fi
  # A LEGAL NAME IS NOT A WIRED DRIVER. The name check is syntax; this is the
  # charter's "unknown value = loud refusal". A module can sit in drivers/ and
  # still have no call site that invokes its typed builder.
  #
  # Before typed builders shipped, selecting an unwired native module forwarded
  # tmux's tail and could park then cross transports on redelivery. That history
  # explains why wiredness requires the builder call site; it is not current
  # behavior or a description of this refusal.
  if ! tap_driver_is_wired "$value"; then
    echo "tap: [harness.$family] driver = \"$value\" in $cfg names no WIRED driver; remove the driver key or set it to tmux" >&2
    return 1
  fi
  printf '%s' "$value"
}

# Mirror of the launcher's read_secure_preset_bytes source checks, in the one
# shape this hot path needs: a REGULAR file (never a FIFO, device or directory —
# a FIFO would hang the courier on open) that is not group- or world-writable
# (or anyone on the box picks the driver). Symlinks resolve, so a symlink TO a
# fifo or to a writable file is refused by the same test.
# Reads the config through the AUTHORITATIVE secure reader and prints its bytes.
#
# Two earlier versions of this guard were wrong in different ways, and both are
# worth recording because the second was created while fixing the first.
#
#   v1 observed the PATH (`[ -f ]`, `ls -lL`) and then let awk open the path
#   separately — two observations of a NAME, with a window between them. A swap
#   in that window reintroduces the FIFO and writable-source classes the guard
#   exists for. A check on a name is not a check on the object you will use.
#
#   v2 tried to fix that in bash by opening a descriptor and stat-ing /dev/fd.
#   It DEADLOCKS: opening a FIFO for reading blocks until a writer appears, so
#   the courier hangs on the very input the guard was added to refuse — before
#   any check can run. The guard's own arm caught it.
#
# So this delegates to `read_secure_preset_bytes`, the launcher's reader, which
# opens with O_NONBLOCK (no FIFO deadlock), fstats the DESCRIPTOR it actually
# read, refuses non-regular and group/world-writable sources, and verifies the
# opened file is the same object the path resolves to. Delegating also retires
# the deeper problem: two implementations of "is this config safe to read" is a
# second normative definition of one rule (I-11), and this hot path was the
# weaker of the two by construction.
#
# The python3 cost is real and accepted: the courier already spawns python3 per
# send for receipt rendering, so this is not a new class of cost, and a
# hand-rolled bash security check has now been wrong twice.
# Read the config through the AUTHORITATIVE secure reader and answer ONE question
# about it: what driver, if any, does this family's table name?
#
# THIS USED TO BE HAND-ROLLED awk, AND IT LOST TO VALID TOML FOUR TIMES.
# Each round patched the spelling that had just been found and left the class
# alive: a quoted table name (`[harness."claude"]`), whitespace around the dot,
# a quoted key (`"driver" = "x"`), trailing garbage after the value, and finally
# dotted assignments (`harness.claude.driver = "x"`) which name the same table
# without ever writing a `[harness.claude]` header at all. Two more defects came
# from the patches themselves: an unsupported-spelling flag that was global
# rather than per-family, so one family's odd header failed resolution for every
# family; and an early exit that accepted a value without ever seeing the rest of
# the document, so a config the LAUNCHER rejects as malformed could still select
# a driver here — two consumers, two policies, one file.
#
# The lesson is not "handle dotted keys too". It is that a courier reading a
# config with a partial parser will keep being wrong in ways nobody enumerated,
# and that this file already had the right answer for the SOURCE check: delegate
# to the reader that owns the format. `tomllib` parses the whole document, so a
# malformed line anywhere is a refusal here exactly as it is in the launcher, and
# every spelling TOML permits resolves identically because it is TOML doing the
# resolving.
#
# No extra process: this call already had to spawn python3 for the secure read.
#
# Exit codes are the whole interface:
#   0 + value on stdout   this family names that driver
#   0 + empty stdout      no driver key for this family (the documented default)
#   1                     unusable — insecure source, malformed document, NUL,
#                         or a driver value that is not a plain string
#   3                     the key is PRESENT and EMPTY, which is a statement that
#                         names nothing rather than an absence
tap_driver_config_resolve() { # <path> <family> -> driver name or empty, or rc 1
  # -I (ISOLATED) IS LOAD-BEARING, NOT TIDINESS. With `python3 -B -`, sys.path[0]
  # is the CWD, and inserting the trusted session directory at index 0 only
  # pushes the untrusted entry to index 1 -- it never removes it. sol-pinnacle
  # demonstrated the consequence at this hop: a repository containing its own
  # `tomllib.py` gets that file imported and EXECUTED with the sender's
  # credentials on every `tap send` that reads config, and can return whatever
  # driver policy it likes from `loads()`. Isolated mode drops the cwd (and
  # PYTHONPATH and user site) before any import runs; the explicit insert below
  # is then the only path entry this hop adds.
  python3 -I -B - "$_TAP_SCRIPT_DIR" "$1" "$2" <<'ENDPY' 2>/dev/null
import sys
sys.path.insert(0, sys.argv[1] + "/session")
try:
    import tomllib
except ModuleNotFoundError:
    # Python 3.10 has no tomllib. presets.py already treats that as "this
    # FEATURE is unavailable" rather than "the launcher is broken"; mirror that
    # policy here instead of inventing a second one. rc 4 is distinct from the
    # rc 1 "unusable config" row precisely so the caller can tell "I could not
    # read your preference" from "your preference is bad".
    sys.exit(4)
try:
    import pathlib
    from presets import read_secure_preset_bytes
    raw, _ = read_secure_preset_bytes(pathlib.Path(sys.argv[2]))
except Exception:
    sys.exit(1)
try:
    doc = tomllib.loads(raw.decode("utf-8"))
except Exception:
    sys.exit(1)
table = doc.get("harness")
if not isinstance(table, dict):
    sys.exit(0)
fam = table.get(sys.argv[3])
if not isinstance(fam, dict):
    sys.exit(0)
if "driver" not in fam:
    sys.exit(0)
value = fam["driver"]
if not isinstance(value, str):
    sys.exit(1)
if value == "":
    # PRESENT BUT EMPTY is not ABSENT. Both would print nothing, so the
    # distinction has to travel in the exit code: an absent key is the documented
    # default, while `driver = ""` is an operator who wrote something and meant
    # something, and silently running tmux for them is the undetectable selection
    # this whole preference exists to prevent.
    sys.exit(3)
if any(ord(ch) < 0x20 or ord(ch) == 0x7f for ch in value):
    # REJECT HERE, WHERE THE BYTES ARE STILL EXACT. `driver = "native\u0000"`
    # and `driver = "native\n"` are valid TOML, and the shell cannot carry
    # either through `$(...)`: NUL is dropped and a trailing newline is stripped,
    # so a name the operator did not write would arrive at the name check
    # looking legal. A validator downstream of a lossy channel validates the
    # wrong bytes; this is the last point at which the value is what the file
    # actually said.
    sys.exit(1)
sys.stdout.write(value)
ENDPY
}

# Source a driver module in a THROWAWAY subshell and require that it survives,
# defines its entry point, AND MUTATES NOTHING THE COURIER DEPENDS ON.
#
# WHAT IS CHECKED IS DESCRIBED AT THE COMPARISONS THEMSELVES, further down, and
# deliberately not summarised here. An earlier version of this header described
# the instrument — "arms `set -e` and reports `$-` through the marker" — and then
# the instrument changed twice (to `set -euo pipefail`, and to a `set +o` snapshot
# through files, with the marker carrying only `$PWD`). The header went stale
# while the accurate description sat fifty lines below it in the same function.
#
# That is the same defect this function was hardened against one layer up:
# `tap_driver_load` was still restating a retired contract eight lines from the
# honest one. Fixing that there and reintroducing it here is why the rule is
# ONE DESCRIPTION, AT THE CODE THAT DOES THE WORK — not "keep both in sync",
# which is the promise that fails silently every time (grok, #xxx, twice).
#
# Scope, which is stable and therefore safe to state here: shell options and the
# working directory. Traps, shopt and IFS remain a review obligation until
# someone writes their arms.
tap_driver_canary_load() { # <name> <file>
  local name="$1" file="$2" _canary _opts _pwd _optfile _optfile2 _want_opts _got_opts
  _opts="$-"; _pwd="$PWD"
  # The probe reports what it armed through a file rather than a variable,
  # because the comparison must be against the ARMED state and only the subshell
  # knows what that string is on this bash.
  _optfile="$(mktemp "${TMPDIR:-/tmp}/tap-canary-opts.XXXXXX")" || return 1
  _optfile2="$(mktemp "${TMPDIR:-/tmp}/tap-canary-opts.XXXXXX")" || { rm -f "$_optfile"; return 1; }
  _canary="$(
    set -euo pipefail
    set +o | tr '\n' ';' > "$_optfile"
    . "$file" >/dev/null 2>&1 || exit 1
    declare -F "tapdrv_${name}_deliver" >/dev/null 2>&1 || exit 1
    set +o | tr '\n' ';' > "$_optfile2"
    printf 'tap-canary-ok\x1f%s' "$PWD"
  )" || { rm -f "$_optfile" "$_optfile2"; return 1; }
  local _us _got_pwd
  # BOTH SAMPLES THROUGH THE IDENTICAL MECHANISM. The first version read the
  # "after" state inside a $( ) substitution and the "before" from a file — and a
  # command substitution does not carry errexit in, so every benign module looked
  # like it had disarmed errexit. An invariance check that samples its two sides
  # differently is measuring its own instrument, and this one refused everything.
  _want_opts="$(cat "$_optfile" 2>/dev/null)"
  _got_opts="$(cat "$_optfile2" 2>/dev/null)"
  rm -f "$_optfile" "$_optfile2"
  [ -n "$_want_opts" ] && [ -n "$_got_opts" ] || return 1
  _us="$(printf '\037')"
  case "$_canary" in
    "tap-canary-ok${_us}"*) ;;
    *) return 1 ;;
  esac
  _got_pwd="${_canary##*${_us}}"
  # THE WHOLE OPTION SET, not one flag, and read through `set +o` rather than
  # `$-`. Two rounds of this: the first version looked only for `e`, so `set +e`
  # was refused and `set +u` sailed through (grok, #xxx) — the same mutation shape
  # one flag over, in the predicate written to catch the shape. Comparing `$-`
  # then still missed `set +o pipefail`, because PIPEFAIL DOES NOT APPEAR IN `$-`
  # AT ALL; the courier runs `set -euo pipefail` and one of its four options was
  # invisible to the instrument. Caught by this file's own arm, which walks u, e
  # and pipefail rather than trusting that a fix for one flag covers the rest.
  #
  # `set +o` prints every option and its state, so the comparison is over the
  # complete surface instead of over whichever flags someone remembered.
  #
  # So the probe compares what it ARMED against what came back. It arms exactly
  # the courier's own set, and any difference at all is a refusal — a module has
  # no business changing the shell it is sourced into, and "which flag" is not a
  # judgment this function should be making.
  [ "$_got_opts" = "$_want_opts" ] || {
    echo "tap: delivery driver '$name' changes shell options at load time ($_want_opts -> $_got_opts)" >&2
    return 1
  }
  [ "$_got_pwd" = "$_pwd" ] || {
    echo "tap: delivery driver '$name' changes the working directory at load time ($_pwd -> $_got_pwd)" >&2
    return 1
  }
  return 0
}

# tap_driver_load <name> -> rc 0 once tapdrv_<name>_deliver is callable.
# tmux is builtin (it is the courier). Anything else is sourced once from the
# driver directory. A name with no driver behind it is a loud refusal, which is
# also what makes an unrecognized config value fail closed.
tap_driver_load() {
  local name="${1:-}" file
  printf '%s' "$name" | grep -Eq "$TAP_DRIVER_NAME_RE" || {
    echo "tap: driver name '$name' is not a legal driver name" >&2; return 1; }
  if declare -F "tapdrv_${name}_deliver" >/dev/null 2>&1; then return 0; fi
  file="$(tap_driver_dir)/${name}.sh"
  [ -r "$file" ] || { echo "tap: no delivery driver named '$name' (looked for $file)" >&2; return 1; }
  # THE LOAD IS AS DANGEROUS AS THE CALL, and the subshell around deliver() does
  # not cover it. A top-level `exit` in a driver module kills the COURIER while
  # the file is being sourced, long before any delivery subshell exists — and so
  # does a top-level effect that SUCCEEDS, by replaying on the live source after
  # the canary discarded its own copy.
  #
  # WHAT THE CANARY ACTUALLY CHECKS is stated on tap_driver_canary_load and
  # nowhere else, deliberately. An earlier version of THIS comment described a
  # §3.9 function-inventory diff and a stray-failing-command guard that were never
  # implemented, and once the canary was corrected the honest description sat
  # eight lines from the surviving overclaim in the same function — so a reader of
  # the load path was still handed the retired contract. One description, on the
  # function that does the work.
  #
  # One correction worth keeping rather than deleting: the stray-`false` threat
  # the old comment named does NOT obtain at this call site. `if ! tap_driver_load`
  # suppresses errexit inside the function, so a sourced failing command does not
  # kill the courier here. Measured, not reasoned.
  if ! tap_driver_canary_load "$name" "$file"; then
    echo "tap: delivery driver '$name' does not hold the load contract (see $file); refusing to source it" >&2
    return 1
  fi
  # THE LIVE SOURCE'S STDOUT IS CONTAINED TOO. The redirect around deliver() does
  # not cover this line, so a module with a top-level `printf` writes straight to
  # `tap send`'s stdout — the receipt channel — during the load. A top-level line
  # emitting well-formed JSON could forge or corrupt a `--json` receipt before any
  # audited delivery attempt exists to blame. Same rule as the invocation: a
  # driver's output goes to stderr, where it is debuggable and harmless.
  # shellcheck disable=SC1090
  . "$file" >&2 || { echo "tap: delivery driver '$name' failed to load from $file" >&2; return 1; }
  declare -F "tapdrv_${name}_deliver" >/dev/null 2>&1 || {
    echo "tap: $file defines no tapdrv_${name}_deliver" >&2; return 1; }
  return 0
}

# --- evidence tiers -----------------------------------------------------------
# Tier names are OBSERVATION names, never verdict words (I-12): they say what was
# positively seen, and the disposition says what it means. An attempt with no
# positive observation carries the reserved record-level tier `none` — design
# §3.2's "renderings always carry the tier attached" constrains DISPOSITIONS
# (never render `delivered` bare); reading it as "every attempt must name an
# observation" would force the driver to manufacture the very inflation I-12
# forbids (kimi, pair review, 2026-08-22).
#
# Two legality rules, asserted by the conformance suite:
#   1. `none` is legal on every disposition EXCEPT `delivered`, which requires a
#      positive tier of its driver's ceiling class. A `delivered/none` record is
#      a conformance red.
#   2. A `stop-ambiguous` tier states only what was positively observed BEFORE
#      the ambiguity — never the ambiguity itself.
#
# The tmux driver's whole vocabulary is three values:
#   left-input-band  rc0 only. Landed observed AND cleared-after-Enter observed.
#                    This is the driver's ceiling.
#   in-input-band    RESERVED, unused in PR1 — the post-split submit-unverified
#                    arm (landed observed, clear unproven). Named now so the
#                    follow-up bead has no vocabulary left to decide.
#   none             rc3, rc4, rc5, rc6.
# `rendered-in-pane`, `socket-acked` and `api-accepted` are native-driver
# vocabulary; the tmux driver must never emit them.
#
# Only a VERIFIED-SUBMISSION tier may carry `delivered`. A driver whose ceiling
# is weaker is capped at `stop-ambiguous` whatever it returns — the I-1 closure
# in code: a driver's success is evidence, never a receipt.
#
# THE CLASS HAS EXACTLY ONE NORMATIVE DEFINITION, AND IT IS THIS LINE (I-11).
# Membership is not a driver's to declare — a driver that could name itself into
# the class could name itself into `delivered`. Adding a member takes evidence
# reviewed by the lead, and the entry records whose evidence it was.
#
#   left-input-band  tmux. The minted id was observed leaving the input band and
#                    the band was observed clear.
#   transcript-match opencode's TUI control API. ADMITTED ON GRANT
#                    (fable-8-78-20260822T105528Z-b99e31247eec), on evidence from
#                    opus-runner-C that this lane did NOT independently reproduce:
#                    /tui/append-prompt + /tui/submit-prompt, then the sentinel
#                    read back VERBATIM out of the seat's own
#                    GET /session/{id}/message transcript. That is the same KIND
#                    of observation as left-input-band — the recipient's own input
#                    surface — and strictly more of it, since tmux stops at
#                    characters-in-a-band while this reads the committed user
#                    message back. Named `transcript-match` rather than the
#                    proposed `submit-verified` because a tier names what was SEEN;
#                    "submit verified" names a conclusion, and collides with the
#                    phrase-space tmux's own verification already occupies.
#                    THE GRANT CARRIED THREE CONDITIONS, and they belong to the
#                    opencode driver's PR, not to this one: per-rung conformance
#                    fixtures with the no-match arm red-proven; kimi reproducing
#                    the transcript-match arm from her own checkout before that
#                    merge; and the driver module restating that `delivered` is
#                    attempt-level truth while settlement remains delivery truth
#                    (I-1). If any condition is not met, this entry comes back out
#                    — a class member whose conditions were waived is worse than
#                    no member at all.
TAP_DRIVER_VERIFIED_SUBMISSION_TIERS="left-input-band transcript-match"

tap_driver_tier_is_verified_submission() {
  local tier="${1:-}" t
  for t in $TAP_DRIVER_VERIFIED_SUBMISSION_TIERS; do
    [ "$tier" = "$t" ] && return 0
  done
  return 1
}

# tap_driver_cap_disposition <ceiling> <tier> <disposition> -> the disposition
# the driver is actually allowed to record. Two independent caps, both required:
# the driver's declared ceiling (I-1), and this record's own tier (rule 1 above
# — a `delivered` with nothing positively observed is not a weaker claim, it is
# an unfounded one).
tap_driver_cap_disposition() {
  local ceiling="${1:-}" tier="${2:-}" disposition="${3:-}"
  # `delivered` requires the record's tier to BE the driver's declared ceiling —
  # not merely to be some member of the verified-submission class. Membership
  # alone was the first version and it was wrong in BOTH directions
  # (sol-pinnacle, #xxx gate): a `left-input-band` ceiling could record a
  # `transcript-match` tier, claiming an observation over an API it never opens;
  # and a `transcript-match` ceiling could record `left-input-band`, claiming to
  # have watched a pane it never reads. Either way the attempt log states the
  # driver saw something it structurally cannot see — the I-12 inflation this
  # cap exists to prevent. The class was doing the work of a TYPE when what it
  # had to enforce was an IDENTITY.
  #
  # A driver producing two grades of evidence declares the STRONGER as its
  # ceiling and records weaker attempts at a non-verified tier, which correctly
  # caps those at `stop-ambiguous`. A delivery claim is available only on the
  # exact evidence the driver said it could produce.
  if [ "$disposition" = delivered ]; then
    if ! tap_driver_tier_is_verified_submission "$ceiling" \
       || [ "$tier" != "$ceiling" ]; then
      printf 'stop-ambiguous'
      return 0
    fi
  fi
  printf '%s' "$disposition"
}

# --- attempt log --------------------------------------------------------------
# Append-only `<payload>.attempts`, one JSON object per line, written BEFORE the
# router would move on. It is the audit surface a discharge has to cite (§3.6),
# so it is written even when the attempt failed — especially then.
tap_attempt_log_path() { printf '%s' "${1%.md}.attempts"; }

tap_attempt_next_seq() { # <attempts-path>
  local path="$1" n=0
  [ -f "$path" ] && n="$(wc -l < "$path" | tr -d ' ')"
  printf '%s' "$(( n + 1 ))"
}

# tap_attempt_append <payload-path> <id> <rung> <op> <driver> <class> \
#                    <disposition> <effect> <tier> <detail> <ts_start> <ts_end>
# Best-effort: a bus that cannot take the audit line must not turn a delivered
# message into a failed one. It says so on stderr instead of failing silently.
tap_attempt_append() {
  local payload="$1" id="$2" rung="$3" op="$4" driver="$5" class="$6" \
        disposition="$7" effect="$8" tier="$9" detail="${10}" ts_start="${11}" ts_end="${12}" \
        native_ref="${13:-}"
  local path seq line
  path="$(tap_attempt_log_path "$payload")"
  seq="$(tap_attempt_next_seq "$path")"
  line="$(tap_json_obj payload_id "$id" seq "$seq" rung "$rung" op "$op" driver "$driver" \
    class "$class" disposition "$disposition" effect "$effect" tier "$tier" \
    detail "$detail" native_ref "$native_ref" ts_start "$ts_start" ts_end "$ts_end")" || {
      echo "tap: could not render an attempt record for $id" >&2; return 1; }
  printf '%s\n' "$line" >> "$path" || {
    echo "tap: could not append the attempt record for $id to $path" >&2; return 1; }
  return 0
}

# --- the tmux driver ----------------------------------------------------------
# Byte-for-byte today's path: every argument is forwarded to tap_submit_verify
# untouched and its return code is returned untouched. This function exists to
# be the thing the dispatcher names, not to add behavior.
tapdrv_tmux_deliver() { tap_submit_verify "$@"; }

# The ceiling tmux can honestly claim: it watches the minted id leave the input
# band. That is a verified submission and nothing more — never that a turn began
# (see tap_submit_verify's own docstring and the `.sent` comment in tap-send.sh).
tapdrv_tmux_ceiling() { printf 'left-input-band'; }

# Map one tmux return code onto (disposition, effect, tier).
#
#   0  the id left the band             delivered       / possible / left-input-band
#   3  pane vanished mid-attempt        stop-ambiguous  / possible / none
#   4  nothing injected, spooled        retry-next-rung / none     / none
#   5  inject-miss OR submit-unverified stop-ambiguous  / possible / none
#   6  bound identity drifted           stop-ambiguous  / possible / none
#
# `possible` on rc0 reads oddly for a certain delivery: it means effect ≠ none,
# i.e. retry-unsafe, which is what the one-effect-record invariant keys on. A
# third value (`performed`) would be a design amendment, not a driver invention.
#
# rc3 has three sites with different effects — pre-inject, inject-stage, and
# submit-verify-stage (reached only after the bytes were provably in the band and
# Enter was pressed at least once). One return code, effects ranging none →
# possible, so the mapping takes the worst arm. That arm is verified-landed, which
# makes `stop-ambiguous` the honest read rather than merely the careful one.
#
# rc6 IS NOT PRE-EFFECT, and an earlier draft of this table said it was. The
# claim was that every rc6 site is a pre-inject guard, resting on the fresh-inject
# call into `tap_submit_existing_verify` passing identity_rc=5 — so an identity
# failure discovered after an Enter would return 5, never 6.
#
# It is false, and sol-pinnacle reproduced it rather than arguing it
# (`rc=6 effects=1 guard_calls=2`). Two things the original reading missed:
# `tap_submit_existing_verify` re-runs the identity guard INSIDE its Enter retry
# loop, so from iteration 2 onward a guard failure follows an Enter that was
# already sent; and the two STUCK-SENTINEL call sites pass identity_rc=6, not 5.
# Those two facts compose into exactly the case the table denied — a `6` returned
# with one Enter already delivered.
#
# So rc6 takes the conservative row: an identity failure MAY follow an effect, and
# `retry-next-rung` would have let the router retry an attempt that already
# pressed Enter. `driver_rc6_premise.py` now enforces the inverse of what it
# originally asserted: NO call site may claim rc6 is pre-effect, and the mapping
# may not be relaxed back without the check going red.
#
# The lesson generalizes past this row. The original premise was reasoned from the
# code and it was WRONG, and no test caught it because the test asserted the
# premise rather than the behavior. A structural argument for a safety-relevant
# claim is a hypothesis; the probe that tries to violate it is the evidence.
#
# rc5 deliberately collapses two arms with DIFFERENT effects onto the conservative
# one: inject-miss (nothing left the shell, effect truly none) and submit-unverified
# (landed observed, clear unproven, effect possible); the typed-prefix arms sit with
# the latter, since prefix keystrokes may remain in the band. The helper separates
# them only in the PROSE of its stderr, and **parsing stderr prose for a routing
# decision is exactly the bug class this layer exists to end — reintroducing it
# needs a ruling, not a patch.** The split lands when the helper grows a structured
# output (a TAP_SV_FAIL_STAGE variable under the same stale-value discipline as
# TAP_SUBMIT_DEFER_REASON); at that point inject-miss earns retry-next-rung/none
# and submit-unverified earns tier `in-input-band`. Tracked as bead tap-ko9p9.
# Until then the detail field carries the helper's stderr line verbatim, as human
# text that is recorded and never parsed.
tapdrv_tmux_outcome() { # <rc> -> "<disposition>\x1f<effect>\x1f<tier>"
  case "${1:-}" in
    0) printf 'delivered\x1fpossible\x1fleft-input-band' ;;
    3) printf 'stop-ambiguous\x1fpossible\x1fnone' ;;
    4) printf 'retry-next-rung\x1fnone\x1fnone' ;;
    5) printf 'stop-ambiguous\x1fpossible\x1fnone' ;;
    6) printf 'stop-ambiguous\x1fpossible\x1fnone' ;;
    *) printf 'stop-ambiguous\x1fpossible\x1fnone' ;;
  esac
}

# --- the dispatcher -----------------------------------------------------------
# tap_driver_deliver <payload-path> <id> <class> <family> <driver-args...>
#
# `class` is the design's delivery class: `steer` for an urgent send that means
# to interrupt, `queue` for an ordinary one. Returns the driver's return code
# UNCHANGED — every spool, exit-5, identity and receipt decision stays with the
# caller, because those are router semantics and a driver never owns them.
#
# On an unresolvable driver it returns 2 without attempting anything, and the
# caller turns that into a loud refusal. Falling back to tmux here would hide
# exactly the misconfiguration the operator needs to see.
tap_driver_deliver() {
  local payload="$1" id="$2" class="$3" family="$4"; shift 4
  local driver rc=0 ts_start ts_end outcome disposition effect tier ceiling detail="" native_ref _k _v
  local TAP_DELIVERY_EFFECT_STARTED=0 TAP_DELIVERY_ATTEMPT_IDS="${TAP_DELIVERY_ATTEMPT_IDS:-}"
  # THE DISPATCHER'S OWN FAILURE IS SIGNALLED OUT OF BAND, never by a status code.
  # A driver's status codes are ITS OWN vocabulary — a native door may legitimately
  # return 2 and declare it `stop-ambiguous`/`possible` — so any number this
  # function reserved for "I could not resolve a driver" would eventually collide
  # with a real post-effect return. The collision is not cosmetic: the caller
  # treats an unresolved driver as a PRE-ATTEMPT failure and deletes the canonical
  # payload, so a driver returning that number after taking effect would have its
  # message destroyed. A flag cannot collide with a return value, so there is
  # nothing to reserve and nothing for a driver to avoid.
  TAP_DRIVER_UNAVAILABLE=0
  TAP_DRIVER_ATTEMPT_EVIDENCE_UNWRITABLE=0
  driver="$(tap_driver_for_harness "$family")" || { TAP_DRIVER_UNAVAILABLE=1; return 2; }
  if ! tap_driver_load "$driver"; then
    # A load refusal is genuinely PRE-ATTEMPT: the canary ran the module in a
    # throwaway subshell, nothing reached the recipient, and the caller correctly
    # discards the canonical. But "the route was refused" and "the route was
    # never tried" are different facts, and with the canonical gone there is no
    # `<id>.attempts` left to tell them apart. The registry event log is the
    # durable surface that survives the deletion, so supervision can still see
    # that a rung was selected and refused rather than silently skipped.
    tap_registry_event_append_or_warn "${FROM:-courier}" driver_load_refused "${TO:-$family}" "" \
      "id=$id driver=$driver" || true
    TAP_DRIVER_UNAVAILABLE=1
    return 2
  fi
  ts_start="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  # The per-attempt result channel. A native driver runs its effectful op in a
  # SUBSHELL (design §3.9), so it cannot hand anything back through a shell
  # variable, and stdout is the courier's receipt channel — a driver writing
  # there corrupts a receipt. It therefore writes `k=v` lines into the file this
  # variable names, and the dispatcher reads them AFTER the call returns. The
  # file is optional: a driver that only has a return code (tmux) writes nothing
  # and gets its fields from its static outcome table.
  TAP_DRIVER_RESULT_FILE="$(mktemp "${TMPDIR:-/tmp}/tap-driver-result.XXXXXX")"
  export TAP_DRIVER_RESULT_FILE
  # A DIRECT call, never `$( )` and never a pipeline: the helper reports its defer
  # origin through the plain shell variable TAP_SUBMIT_DEFER_REASON, which does not
  # survive a subshell (lib.sh's own docstring documents this footgun). If a driver
  # ever has to run out of process, its detail degrades to `defer:reason-unavailable`
  # rather than guessing which origin it was.
  if [ "$driver" = tmux ]; then
    "tapdrv_${driver}_deliver" "$@" || rc="$?"
    if [ "${TAP_SUBMIT_DEFER_REASON:-}" = attempt-evidence ]; then
      TAP_DRIVER_ATTEMPT_EVIDENCE_UNWRITABLE=1
      rm -f "$TAP_DRIVER_RESULT_FILE"; unset TAP_DRIVER_RESULT_FILE
      return 8
    fi
  else
    # STDOUT IS THE COURIER'S RECEIPT CHANNEL, so a native driver never gets to
    # write to it. With --json the caller PARSES that stream: a driver printing
    # there corrupts a receipt into something a consumer cannot read — or worse,
    # something it CAN read and believes, since a well-formed line is
    # indistinguishable from the courier's own. A driver's diagnostics belong on
    # stderr, which the courier already captures for `detail`.
    #
    # Redirected to stderr rather than discarded: a driver that prints something
    # useful should still be debuggable, and stderr is where every other driver
    # diagnostic already goes.
    # NATIVE DRIVERS RUN IN A SUBSHELL (design §3.9). A vendor module calling
    # `exit` must kill the ATTEMPT, not the courier — and it must not kill it
    # BEFORE the attempt record is written, which is the state that would leave a
    # payload with no audit line and an exhaustion check unable to tell it from a
    # rung nobody tried. The subshell converts that exit into a return code this
    # function still handles. tmux is deliberately exempt: it IS the courier, it
    # reports its defer origin through a shell variable that cannot cross a
    # subshell boundary, and isolating it would change the behavior the
    # extraction exists to preserve.
    # THE PER-DRIVER TAIL (tap-lcdm). `$@` here is `tap_submit_verify`'s argv,
    # which is TMUX's tail and nobody else's. Forwarding it to a native driver
    # hands that driver the harness family binary where it expects its own first
    # positional -- CONTRACT.md:1671 already describes what happens next: the
    # driver's usage error is mapped by its own outcome table, and a table
    # mapping usage errors to `retry-next-rung` parks the payload.
    #
    # So each driver builds its own tail from a NAMED CONTEXT the dispatcher
    # owns. The split matters more than it looks: a typed table here would make
    # the dispatcher know every driver's signature, so all four of tonight's
    # native lanes would edit this one function and collide. With the builder
    # per-driver, this hop knows only how to ASK.
    #
    # Positional `key=value`, not exported environment: a named context passed
    # positionally is checkable by the receiving function, an exported one is
    # invisible at the call site -- the hidden-ABI shape this driver already
    # shipped once and had to fix.
    #
    # NUL-DELIMITED, because the sentinel contains spaces and a `$( )` capture
    # would word-split it into a truncated first positional. Pinned by an arm
    # whose sentinel carries a space.
    local -a _dargs=()
    if declare -F "tapdrv_${driver}_args" >/dev/null 2>&1; then
      local _ctx_acting="" _argsfile="" _args_rc=0 _a=""
      _ctx_acting="$(tap_registry_acting_session_id "${8:-}" "${5:-}" 2>/dev/null || true)"
      _argsfile="$(mktemp "${TMPDIR:-/tmp}/tap-driver-args.XXXXXX")"
      "tapdrv_${driver}_args" \
        "payload_id=${4:-}" "class=$class" "family=$family" \
        "sentinel=${3:-}" "pane=${1:-}" "pane_cmd=${2:-}" \
        "bound_pane_id=${10:-}" "acting_session_id=$_ctx_acting" \
        "to=${5:-}" "urgent=${6:-}" "registry=${8:-}" \
        "manual_unbound_session=${11:-}" "payload_path=$payload" \
        >"$_argsfile" 2>>"${TAP_DRIVER_ADVISORY_FILE:-/dev/null}" || _args_rc="$?"
      if [ "$_args_rc" != 0 ]; then
        # A BUILDER REFUSAL IS PRE-ATTEMPT and belongs to the dispatcher's
        # out-of-band channel, never to the driver's outcome table. It means the
        # context could not be assembled -- a missing registry, an unresolvable
        # seat -- which is the same class as an unresolvable driver: nothing
        # reached the recipient, and the operator needs to see it rather than
        # have it silently become a tmux send. Routing it through the outcome
        # table instead would let a misconfiguration be recorded as a delivery
        # attempt against a door that was never opened.
        rm -f "$_argsfile" "$TAP_DRIVER_RESULT_FILE"; unset TAP_DRIVER_RESULT_FILE
        tap_registry_event_append_or_warn "${FROM:-courier}" driver_args_refused "${TO:-$family}" "" \
          "id=$id driver=$driver rc=$_args_rc" || true
        echo "tap: delivery driver '$driver' could not build its argument tail (rc $_args_rc); refusing rather than opening a door with the wrong signature" >&2
        TAP_DRIVER_UNAVAILABLE=1
        return 2
      fi
      while IFS= read -r -d '' _a; do _dargs+=("$_a"); done <"$_argsfile"
      rm -f "$_argsfile"
    else
      # NO BUILDER: the driver has opted into tmux's tail verbatim. Kept so a
      # driver that genuinely wants that tail does not have to write an identity
      # builder, and so this change is not a flag day for anything already wired.
      _dargs=("$@")
    fi
    # Keep the native driver's inherited-shell ABI while using the same pane
    # mutex and native recovery decision as the tmux path. Defer is our own
    # pre-effect result, never a return code interpreted through a vendor table.
    local _native_hold_file _native_hold_reason=""
    _native_hold_file="$(mktemp "${TMPDIR:-/tmp}/tap-native-hold.XXXXXX")"
    (
      # A driver with no pane tail has no pane effects to coordinate (e.g. API-only doors).
      # Preserve that dispatcher ABI; pane-backed callers supply the bound id or target.
      if [ -n "${10:-${1:-}}" ]; then
        if ! tap_pane_submit_lock "${10:-${1:-}}"; then
          tap_pane_submit_unlock; printf lock-park >"$_native_hold_file"; exit 0
        fi
        trap tap_pane_submit_unlock EXIT
        _native_recovery="$(tap_bun_call recovery "$id" recovery/cli.ts guard "${10:-${1:-}}")" || _native_recovery=park
        if [ "$_native_recovery" != allowed ]; then printf recovery-hold >"$_native_hold_file"; exit 0; fi
      fi
      "tapdrv_${driver}_deliver" "${_dargs[@]}" >&2
    ) || rc="$?"
    _native_hold_reason="$(cat "$_native_hold_file")"; rm -f "$_native_hold_file"
    if [ -n "$_native_hold_reason" ]; then
      TAP_SUBMIT_DEFER_REASON="$_native_hold_reason"
      rm -f "$TAP_DRIVER_RESULT_FILE"; unset TAP_DRIVER_RESULT_FILE
      echo "tap: $_native_hold_reason owns pane '${1:-}' -> park" >&2
      return 4
    fi
  fi
  ts_end="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  # A driver's outcome table is REQUIRED unless it is tmux. Falling back to
  # tmux's table for a native driver would invent an observation that driver
  # never made — an rc 0 from a door with a `transcript-match` ceiling would be
  # recorded as `delivered` on the tmux-only tier `left-input-band`, with no
  # per-attempt evidence behind it at all. That is a delivery claim manufactured
  # by a typo (an omitted or misnamed function), which is precisely the class the
  # ceiling apparatus exists to make unreachable. Fail closed: rc 2, the
  # dispatcher's own refusal, and the caller turns it into a loud error.
  if declare -F "tapdrv_${driver}_outcome" >/dev/null 2>&1; then
    outcome="$("tapdrv_${driver}_outcome" "$rc")"
  elif [ "$driver" = tmux ]; then
    outcome="$(tapdrv_tmux_outcome "$rc")"
  else
    rm -f "$TAP_DRIVER_RESULT_FILE"; unset TAP_DRIVER_RESULT_FILE
    echo "tap: delivery driver '$driver' defines no tapdrv_${driver}_outcome; refusing to borrow tmux's evidence for it" >&2
    # A missing outcome table is discovered AFTER the driver ran, so this is not
    # a pre-attempt resolution failure and must not be reported as one — the
    # caller would delete a canonical for a message that may have been delivered.
    # It is unresolvable in the sense that we cannot classify what happened, which
    # is exactly `stop-ambiguous`: refuse the claim, keep the payload.
    TAP_DRIVER_UNAVAILABLE=0
    TAP_DRIVER_LAST_DRIVER="$driver"
    TAP_DRIVER_LAST_DISPOSITION=stop-ambiguous
    TAP_DRIVER_LAST_EFFECT=possible
    TAP_DRIVER_LAST_TIER=none
    TAP_DRIVER_LAST_NATIVE_REF=""
    # The REAL end time. Reusing ts_start erases how long the attempt took, on
    # the one path where a driver ran and we cannot say what it did — which is
    # exactly where duration is the only signal left.
    ts_end="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    tap_attempt_append "$payload" "$id" 1 deliver "$driver" "$class" \
      stop-ambiguous possible none "no-outcome-table" "$ts_start" "$ts_end" || true
    if ! tap_delivery_effect_begin "$id"; then
      TAP_DRIVER_ATTEMPT_EVIDENCE_UNWRITABLE=1
      return 8
    fi
    return 2
  fi
  IFS=$'\x1f' read -r disposition effect tier <<< "$outcome"
  # THE TUPLE IS VALIDATED, NEVER TRUSTED. `retry-next-rung` REQUIRES
  # `effect: none` — that pairing is the whole reason `effect` exists, since a
  # retry after a possible effect is a duplicate delivery. Until now the
  # dispatcher QUOTED that rule everywhere and enforced it nowhere: a driver
  # whose table returned `retry-next-rung` with `effect: possible` had its
  # payload spooled for redelivery on an attempt that may already have landed.
  #
  # `delivered|none` is ILLEGAL too, and that is not pedantry. This file's own rc0
  # rationale says a successful delivery is effect-NOT-none, and explicitly defers
  # a third `performed` value as a design amendment. So a tuple claiming delivery
  # while its effect field denies any effect is self-contradicting — and it would
  # emit a `.sent` receipt alongside an attempt record reading `effect:none`,
  # which is exactly the two-surfaces-disagreeing shape this layer exists to end.
  #
  # A malformed tuple fails CLOSED to the conservative row rather than being
  # refused outright: the driver has already run, so the attempt happened and
  # must be recorded — we simply decline to believe its self-description.
  case "$disposition|$effect" in
    delivered\|possible|stop-ambiguous\|possible|retry-next-rung\|none) ;;
    *)
      echo "tap: driver '$driver' returned an illegal outcome tuple ($disposition/$effect) for rc=$rc; recording it as stop-ambiguous/possible" >&2
      disposition=stop-ambiguous; effect=possible ;;
  esac
  detail="$(tap_driver_detail "$rc" "$driver")"
  native_ref=""
  # Per-attempt overrides from the driver's result file, if it wrote one. Only
  # `tier`, `detail` and `native_ref` may be overridden — never `disposition` and
  # never `effect`. Those two are ROUTING decisions, and a driver that could set
  # its own disposition could set `delivered`; the static outcome table exists so
  # the conformance suite can read a driver's whole disposition surface without
  # running it. `native_ref` ANNOTATES only: the TAP payload id stays the sole key
  # (I-5), so a native id can never become the thing an audit resolves against.
  if [ -r "$TAP_DRIVER_RESULT_FILE" ]; then
    while IFS='=' read -r _k _v; do
      case "$_k" in
        tier)       [ -n "$_v" ] && tier="$_v" ;;
        detail)     [ -n "$_v" ] && detail="$_v" ;;
        native_ref) native_ref="$_v" ;;
      esac
    done < "$TAP_DRIVER_RESULT_FILE"
  fi
  rm -f "$TAP_DRIVER_RESULT_FILE"
  unset TAP_DRIVER_RESULT_FILE
  ceiling="$(tap_driver_ceiling "$driver")"
  disposition="$(tap_driver_cap_disposition "$ceiling" "$tier" "$disposition")"
  # REVALIDATE AFTER THE RESULT FILE, because the result file moved `tier` AFTER
  # the static tuple was checked. sol-pinnacle, #xxx: the cap only ever demotes
  # `delivered`, so a static `retry-next-rung/none` outcome combined with a
  # result-file tier of `transcript-match` stayed RETRYABLE -- the courier spooled
  # the payload for another attempt while the attempt record asserted verified
  # submission evidence for the one it had just made. That is a duplicate
  # delivery, and it is the one failure the disposition layer exists to prevent.
  #
  # Retry means "nothing happened, try the next rung." A verified-submission tier
  # means "something was observed to land." They cannot both be true, so the pair
  # fails CLOSED: the attempt becomes ambiguous with a possible effect, which is
  # the row that is safe to be wrong about in either direction. A driver wanting
  # a retry must not claim verified evidence for the attempt it is retrying.
  if [ "$disposition" = retry-next-rung ] \
     && tap_driver_tier_is_verified_submission "$tier"; then
    disposition=stop-ambiguous
    effect=possible
  fi
  # Native drivers classify their own return codes. Refusals such as ccnative's
  # 10-14 are explicitly effect:none and must remain retryable without minting
  # conservative pane-effect evidence. A possible effect is admitted only after
  # that classification, but still before the caller routes the outcome.
  if [ "$driver" != tmux ] && [ "$effect" = possible ]; then
    if ! tap_delivery_effect_begin "$id"; then
      TAP_DRIVER_ATTEMPT_EVIDENCE_UNWRITABLE=1
      TAP_DRIVER_LAST_DRIVER="$driver"
      TAP_DRIVER_LAST_DISPOSITION="$disposition"
      TAP_DRIVER_LAST_EFFECT="$effect"
      TAP_DRIVER_LAST_TIER="$tier"
      TAP_DRIVER_LAST_NATIVE_REF="$native_ref"
      tap_attempt_append "$payload" "$id" 1 deliver "$driver" "$class" \
        "$disposition" "$effect" "$tier" "$detail" "$ts_start" "$ts_end" "$native_ref" || true
      return 8
    fi
  fi
  TAP_DRIVER_LAST_DRIVER="$driver"
  TAP_DRIVER_LAST_DISPOSITION="$disposition"
  TAP_DRIVER_LAST_EFFECT="$effect"
  TAP_DRIVER_LAST_TIER="$tier"
  TAP_DRIVER_LAST_NATIVE_REF="$native_ref"
  # tap-lcdm P1-2: THE CLASS THIS DRIVER CANNOT SERVE MUST NOT BE PARKED.
  #
  # `steer` means interrupt-capable. A ceiling-capped door that has no interrupt
  # refuses the class BEFORE touching the door -- pre-effect, `effect: none`,
  # nothing crossed -- and the router then parked it in the plain spool, where the
  # drain re-sent it with the class STRIPPED. `tap send --urgent` therefore
  # returned accepted/queued and arrived later as an ordinary message.
  #
  # Worse for the one caller that matters: `tap escalate` is default-urgent
  # (tap-send.sh:417). On a native-configured seat the human-escalation path --
  # the path whose whole job is to reach a person when a lane is stuck -- became a
  # queued note. That is why this falls through to the floor rather than failing
  # loud: failing loud would break escalation for every seat configured native,
  # which is worse than the defect.
  #
  # THE WARNING AT tap-send.sh:1642 IS NOT THE DEFECT AND MUST NOT BE "FIXED".
  # It fires before any dispatch, unconditionally on $URGENT, deliberately: it is
  # a uniform audit line across harnesses because hermes' bare inject IS its
  # interrupt. It was true for every transport until a rung existed that could
  # refuse the class. The defect is the rung, not the warning; making the warning
  # driver-conditional would silence a line four harnesses correctly rely on.
  TAP_DRIVER_LAST_CLASS_UNSUPPORTED=0
  if [ "$class" = steer ] && [ "$disposition" = retry-next-rung ] \
     && [ "$effect" = none ] && [ "$detail" = class_unsupported ]; then
    # The ONE detail-keyed branch in the router, and it is keyed on a value the
    # driver publishes as a typed refusal code rather than on prose. The general
    # rule above -- detail is human text, never parsed -- still holds for every
    # other path; this is a declared exception, narrowed to a class the driver
    # states it cannot serve, and it is checked alongside the disposition and
    # effect that already prove the attempt was pre-effect.
    TAP_DRIVER_LAST_CLASS_UNSUPPORTED=1
  fi
  # Written BEFORE the caller acts on the return code: a discharge receipt has to
  # cite this log to prove exhaustion (§3.6), and its red case is "an unattempted
  # rung". A defer that recorded nothing would be indistinguishable from a rung
  # nobody tried, so a defer IS an attempt record.
  tap_attempt_append "$payload" "$id" 1 deliver "$driver" "$class" \
    "$disposition" "$effect" "$tier" "$detail" "$ts_start" "$ts_end" "$native_ref" || true
  return "$rc"
}

# The detail field is HUMAN TEXT: recorded, displayed, and never parsed by any
# routing decision. TAP_DRIVER_DETAIL_FILE, when the caller sets it, names the
# file it captured the driver's stderr into — the courier redirects that stream
# for its own error reporting, so the dispatcher cannot read it directly.
tap_driver_detail() { # <rc> [<driver>]
  local rc="${1:-}" driver="${2:-tmux}" line=""
  # THE EMPTY-SUCCESS SHORTCUT IS TMUX'S TOO. For tmux, rc 0 means verified
  # submission and there is nothing to diagnose. For a NATIVE driver rc 0 is not
  # self-evidently a success: its own outcome table may map 0 to
  # stop-ambiguous (ccnative does exactly that), and the evidence cap can demote a
  # delivered claim whose tier is not the declared ceiling. In both cases the
  # attempt is durable, pending, and its ONLY diagnosis is what the driver wrote
  # on stderr -- which this shortcut discarded before the reader below ever ran
  # (sol-pinnacle, #xxx: a native rc 0 with "native accepted but not verified"
  # captured returned an empty detail). Returning early on the status code
  # assumes the status code means what tmux means by it, which is the same
  # mistake as the numeric detail table below, one condition earlier.
  [ "$rc" = 0 ] && [ "$driver" = tmux ] && { printf ''; return 0; }
  # THE NUMERIC MEANINGS ARE TMUX'S, HERE TOO. `defer:` and `identity-refused`
  # describe tmux's rc 4 and rc 6; stamping them on a native driver's 4 or 6
  # writes a tmux diagnosis into the audit record of an attempt that never went
  # near a pane (sol-pinnacle, #xxx). The routing layer learned this lesson
  # first; the detail field is the same mistake one field over, and it is worse
  # in one way — a wrong disposition is caught by an arm, while a wrong detail is
  # believed by the next reader who sees it.
  #
  # AND SINCE tap-lcdm, WORSE THAN THAT IN ONE CASE. This used to read "human text
  # nobody asserts on". That is no longer true and the exception makes the warning
  # STRONGER, not weaker: `tap_driver_deliver` keys on `detail = class_unsupported`
  # (alongside class/disposition/effect) to fall through to the tmux floor. This is
  # the function that WRITES detail, so a native driver that stamps that value
  # wrongly does not merely mislead a reader — it reroutes a send. The one detail a
  # driver must never invent is the one the router now reads.
  #
  # A native driver's detail comes from what it actually said on stderr.
  if [ "$driver" = tmux ]; then
    case "$rc" in
      5)
        if [ -n "${TAP_SUBMIT_LAST_FRAME:-}" ]; then printf '%s' "$TAP_SUBMIT_LAST_FRAME"; return 0; fi ;;
      4)
        if [ -n "${TAP_SUBMIT_DEFER_REASON:-}" ]; then
          printf 'defer:%s' "$TAP_SUBMIT_DEFER_REASON"
        else
          printf 'defer:reason-unavailable'
        fi
        return 0 ;;
      6) printf 'identity-refused'; return 0 ;;
    esac
  fi
  if [ -n "${TAP_DRIVER_DETAIL_FILE:-}" ] && [ -r "${TAP_DRIVER_DETAIL_FILE}" ]; then
    line="$(tr -d '\r' < "$TAP_DRIVER_DETAIL_FILE" | grep -v '^[[:space:]]*$' | tail -1)"
  fi
  # A silent native SUCCESS stays empty rather than becoming "rc=0": the fallback
  # exists so a failure is never diagnosis-free, and stamping it on rc 0 would
  # invent a detail where the driver deliberately said nothing.
  if [ -z "$line" ] && [ "$rc" = 0 ]; then printf ''; return 0; fi
  printf '%s' "${line:-rc=$rc}"
}

# A driver that declares no ceiling gets the weakest one, not the strongest:
# an undeclared ceiling is an unproven ceiling.
tap_driver_ceiling() {
  local name="${1:-}"
  if declare -F "tapdrv_${name}_ceiling" >/dev/null 2>&1; then
    "tapdrv_${name}_ceiling"
  else
    printf 'api-accepted'
  fi
}
