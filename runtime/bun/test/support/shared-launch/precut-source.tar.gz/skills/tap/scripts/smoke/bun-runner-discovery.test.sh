#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
WORK="$(mktemp -d /tmp/tap-bd.XXXXXX)"
trap 'rm -rf "$WORK"' EXIT

fail() {
  echo "bun-runner-discovery: $*" >&2
  sed 's/^/  | /' "$WORK/run.log" >&2
  exit 1
}

# Use the real runner and Bun in a tiny checkout-shaped fixture. An ignored
# scratch test must not become suite coverage just because the caller is at root.
fixture="$WORK/repo"
mkdir -p "$fixture/runtime/bun/test/nested" "$fixture/runtime/bun/src" "$fixture/scripts" "$fixture/tmp/seat" "$WORK/elsewhere"
cp "$ROOT/runtime/bun/test/run.sh" "$fixture/runtime/bun/test/run.sh"
cp "$ROOT/scripts/ignored-state-tripwire.py" "$fixture/scripts/ignored-state-tripwire.py"
printf 'tmp/\n' > "$fixture/.gitignore"
for location in test/nested src; do
  cat > "$fixture/runtime/bun/$location/intended.test.ts" <<'TEST'
import { test } from "bun:test";
import { appendFileSync } from "node:fs";
test("intended suite test", () => appendFileSync(process.env.BUN_RUNNER_DISCOVERY_LOG!, "suite\n"));
TEST
done
cat > "$fixture/tmp/seat/probe.test.ts" <<'TEST'
import { test } from "bun:test";
import { appendFileSync } from "node:fs";
test("explicit scratch probe", () => {
  if (process.env.BUN_RUNNER_ALLOW_PROBE !== "1") throw new Error("scratch probe discovered by default");
  appendFileSync(process.env.BUN_RUNNER_DISCOVERY_LOG!, "probe\n");
});
TEST
export BUN_RUNNER_DISCOVERY_LOG="$WORK/observed"
for caller in "$fixture" "$fixture/runtime/bun" "$WORK/elsewhere"; do
  : > "$BUN_RUNNER_DISCOVERY_LOG"
  (cd "$caller" && bash "$fixture/runtime/bun/test/run.sh") > "$WORK/run.log" 2>&1 || fail "(1) ${caller##*/}: default suite command failed"
  [ "$(cat "$BUN_RUNNER_DISCOVERY_LOG")" = "$(printf 'suite\nsuite')" ] || fail "(2) ${caller##*/}: intended suite coverage differs"
  ! grep -q 'tmp/seat' "$WORK/run.log" || fail "(3) ${caller##*/}: default discovery included scratch"
done
echo 'bun-runner-discovery: defaults include nested test and src coverage, exclude scratch from every cwd: ok'

: > "$BUN_RUNNER_DISCOVERY_LOG"
(cd "$fixture" && BUN_RUNNER_ALLOW_PROBE=1 bash "$fixture/runtime/bun/test/run.sh" ./tmp/seat/probe.test.ts --test-name-pattern 'explicit scratch probe') > "$WORK/run.log" 2>&1 || fail '(4) repo: explicit probe command failed'
[ "$(cat "$BUN_RUNNER_DISCOVERY_LOG")" = probe ] || fail '(5) repo: explicit probe selection differs'
echo 'bun-runner-discovery: explicit relative probe and test filter remain focused: ok'

# A timeout or name flag alone must not restore caller-wide discovery. Require
# the selector first instead of maintaining a second parser for Bun's options.
for option in --timeout=20000 --only --help; do
  : > "$BUN_RUNNER_DISCOVERY_LOG"
  rc=0
  (cd "$fixture" && bash "$fixture/runtime/bun/test/run.sh" "$option") > "$WORK/run.log" 2>&1 || rc=$?
  [ "$rc" = 64 ] && [ ! -s "$BUN_RUNNER_DISCOVERY_LOG" ] || fail "(6) $option: option-first call did not refuse before discovery"
  grep -q 'explicit test path/filter before Bun options' "$WORK/run.log" || fail "(7) $option: refusal omitted selector guidance"
done
echo 'bun-runner-discovery: option-first calls refuse before discovering any tests: ok'
