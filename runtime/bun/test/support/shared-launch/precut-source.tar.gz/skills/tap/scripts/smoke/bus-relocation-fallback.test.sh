#!/usr/bin/env bash
# bus-relocation-fallback.test.sh — U2 (R8, R19, R23): the bus resolution chain
# (TAP_HOME env > .tap/bus > legacy tmp/tap > default .tap/bus), the R23 split-brain
# guard (never bootstrap .tap/bus over a non-empty legacy bus except during a
# migration), the self-ignoring .tap/.gitignore, and doctor's resolved-bus report.
#
# Resolution keys on the repo root, which lib.sh derives as `git rev-parse
# --show-toplevel || pwd`. Each case runs from a fresh NON-git temp dir so the repo
# root is that dir (pwd fallback) and TAP_HOME is unset — exercising the real chain.
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP="$ROOT/scripts/tap.sh"
WORK="$(mktemp -d)"
WORK="$(cd "$WORK" && pwd -P)"
trap 'rm -rf "$WORK"' EXIT

# (1) Fresh repo, no bus, TAP_HOME unset → doctor's zero-write promise (tap-0y4u)
#     refuses a genuinely unenrolled cwd rather than bootstrapping .tap/bus;
#     nothing materializes. See runtime/bun/test/doctor.test.ts's own
#     "unenrolled cwd is refused before any bus materializes" coverage.
mkdir -p "$WORK/fresh"
rc=0; out="$(cd "$WORK/fresh" && env -u TAP_HOME "$TAP" doctor 2>&1)" || rc=$?
[ "$rc" != 0 ] || { echo "bus-relocation: (1) doctor should refuse an unenrolled fresh repo" >&2; echo "$out" >&2; exit 1; }
[[ "$out" == *"TAP_HOME"* ]] || { echo "bus-relocation: (1) refusal must name TAP_HOME" >&2; echo "$out" >&2; exit 1; }
[ ! -d "$WORK/fresh/.tap" ] || { echo "bus-relocation: (1) zero-write refusal let .tap be created" >&2; exit 1; }
echo "bus-relocation: (1) fresh unenrolled repo refuses zero-write, nothing created: ok"

# (1b) The default-rule bootstrap doctor used to perform is not gone, just
#      moved: any ordinary writer still creates .tap/bus on demand with a
#      self-ignoring .tap/.gitignore (skills/tap/scripts/smoke/README.md:42's
#      claim), same as (5) exercises for the R23 guard. Exercised directly for
#      the same reason (5) is: no unrelated business logic in the way.
mkdir -p "$WORK/bootstrap"
out="$(cd "$WORK/bootstrap" && env -u TAP_HOME bash -c '. "'"$ROOT"'/skills/tap/scripts/lib.sh" && tap_ensure_dirs' 2>&1)" || {
  echo "bus-relocation: (1b) tap_ensure_dirs failed on a fresh repo" >&2; echo "$out" >&2; exit 1; }
[ -d "$WORK/bootstrap/.tap/bus/payloads" ] || { echo "bus-relocation: (1b) .tap/bus not created" >&2; exit 1; }
grep -qx 'bus/' "$WORK/bootstrap/.tap/.gitignore" || { echo "bus-relocation: (1b) .tap/.gitignore missing 'bus/'" >&2; cat "$WORK/bootstrap/.tap/.gitignore" 2>&1 >&2; exit 1; }
echo "bus-relocation: (1b) an ordinary writer still bootstraps .tap/bus + writes .gitignore: ok"

# (2) Legacy-only repo → tmp/tap used, no .tap/bus created; rule=legacy (AE7 refusal
#     half — the ensure_dirs path register/send would also take).
mkdir -p "$WORK/legacy/tmp/tap/payloads"
out="$(cd "$WORK/legacy" && env -u TAP_HOME "$TAP" doctor 2>&1)" || {
  echo "bus-relocation: (2) doctor failed on a legacy repo" >&2; echo "$out" >&2; exit 1; }
[[ "$out" == *"rule=legacy"* ]] || { echo "bus-relocation: (2) rule should be legacy" >&2; echo "$out" >&2; exit 1; }
[ ! -d "$WORK/legacy/.tap/bus" ] || { echo "bus-relocation: (2) .tap/bus must NOT be created in a legacy repo" >&2; exit 1; }
echo "bus-relocation: (2) legacy-only repo stays on tmp/tap, no .tap/bus: ok"

# (3) Both layouts present → .tap/bus wins; rule=dotdir.
mkdir -p "$WORK/both/.tap/bus/payloads" "$WORK/both/tmp/tap/payloads"
out="$(cd "$WORK/both" && env -u TAP_HOME "$TAP" doctor 2>&1)" || {
  echo "bus-relocation: (3) doctor failed with both layouts" >&2; echo "$out" >&2; exit 1; }
[[ "$out" == *"rule=dotdir"* ]] || { echo "bus-relocation: (3) .tap/bus should win" >&2; echo "$out" >&2; exit 1; }
grep -q "bus=$WORK/both/.tap/bus" <<<"$out" || { echo "bus-relocation: (3) resolved bus should be .tap/bus" >&2; echo "$out" >&2; exit 1; }
echo "bus-relocation: (3) both present → .tap/bus wins: ok"

# (4) TAP_HOME env wins over both; rule=env.
mkdir -p "$WORK/enved/.tap/bus" "$WORK/enved/tmp/tap"
CUSTOM="$WORK/custom-home"
out="$(cd "$WORK/enved" && TAP_HOME="$CUSTOM" "$TAP" doctor 2>&1)" || {
  echo "bus-relocation: (4) doctor failed with TAP_HOME env" >&2; echo "$out" >&2; exit 1; }
[[ "$out" == *"rule=env"* ]] || { echo "bus-relocation: (4) rule should be env" >&2; echo "$out" >&2; exit 1; }
grep -q "bus=$CUSTOM" <<<"$out" || { echo "bus-relocation: (4) env bus should win" >&2; echo "$out" >&2; exit 1; }
echo "bus-relocation: (4) TAP_HOME env wins over both layouts: ok"

# (5) R23 guard: creating .tap/bus over a NON-EMPTY legacy bus is refused, naming
#     `tap init`; nothing is created. TAP_MIGRATING=1 bypasses it (the init seam).
#     `tap doctor` is zero-write (tap-0y4u) and never reaches this guard now —
#     it lives in tap_ensure_dirs, which ordinary writers cross before their
#     first payload/receipt/tmp write. Exercised directly rather than through
#     a verb, since register/send carry unrelated business logic (pane binding,
#     recipient resolution) this case isn't about.
mkdir -p "$WORK/split/tmp/tap/payloads"
printf 'x' > "$WORK/split/tmp/tap/payloads/live.md"
rc=0; out="$(cd "$WORK/split" && TAP_HOME="$WORK/split/.tap/bus" bash -c '. "'"$ROOT"'/skills/tap/scripts/lib.sh" && tap_ensure_dirs' 2>&1)" || rc=$?
[ "$rc" != 0 ] || { echo "bus-relocation: (5) guard should refuse creating .tap/bus over a non-empty legacy bus" >&2; echo "$out" >&2; exit 1; }
[[ "$out" == *"tap init"* ]] || { echo "bus-relocation: (5) refusal must name tap init" >&2; echo "$out" >&2; exit 1; }
[ ! -d "$WORK/split/.tap/bus" ] || { echo "bus-relocation: (5) guard let .tap/bus be created anyway" >&2; exit 1; }
(cd "$WORK/split" && TAP_MIGRATING=1 TAP_HOME="$WORK/split/.tap/bus" bash -c '. "'"$ROOT"'/skills/tap/scripts/lib.sh" && tap_ensure_dirs') >/dev/null 2>&1 \
  || { echo "bus-relocation: (5) TAP_MIGRATING bypass should succeed" >&2; exit 1; }
[ -d "$WORK/split/.tap/bus/payloads" ] || { echo "bus-relocation: (5) migration bypass did not create .tap/bus" >&2; exit 1; }
echo "bus-relocation: (5) R23 guard refuses split-brain, migration bypasses: ok"

echo "bus-relocation-fallback: ok"
