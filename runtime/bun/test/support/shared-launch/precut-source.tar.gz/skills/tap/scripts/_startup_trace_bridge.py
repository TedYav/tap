"""Transport for retained Python callers; startup-trace.ts owns all trace policy.

The capsule is opaque. Failed transport discards it; no helper failure changes a
launch result. No-context command observations do not start a helper.
"""
import json
import os
from pathlib import Path
import subprocess

_DOOR = Path(__file__).resolve().parents[3] / "runtime/bun/src/startup-trace.ts"
_RUN = subprocess.run  # Launcher tests replace subprocess.run to fake tmux.
_context = None


def _call(op, **args):
    global _context
    try:
        result = _RUN(
            [os.environ.get("TAP_SMOKE_BUN") or "bun", str(_DOOR)],
            input=json.dumps({"op": op, "args": args, "context": _context},
                             default=lambda value: type(value).__name__),
            text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            env={**os.environ, "BUN_RUNTIME_TRANSPILER_CACHE_PATH": "0"},
            timeout=0.2,
        )  # subprocess.run kills and waits for the child on TimeoutExpired.
        if result.returncode != 0:
            raise ValueError("trace transport failed")
        packet = json.loads(result.stdout)
        capsule = packet["context"]
        if capsule is not None and not isinstance(capsule, str):
            raise ValueError("invalid trace capsule")
        value = packet["value"]
        _context = capsule
        return value
    except Exception:
        _context = None
        return None


def begin(verb, cwd, target=None, boot_id=None, deferred=False):
    global _context
    _context = None
    _call("begin", verb=verb, cwd=cwd, target=target, boot_id=boot_id, deferred=deferred)


def activate():
    if _context is not None:
        _call("activate")


def phase(name, **fields):
    if _context is not None:
        _call("phase", name=name, fields=fields)


def finish(code):
    global _context
    try:
        if _context is not None:
            _call("finish", code=code)
    finally:
        _context = None


def emit(event, *, rotate=False, **fields):
    return _call("emit", event=event, rotate=rotate, fields=fields)


def _result(value):
    if value is None:
        return None
    stderr = getattr(value, "stderr", None)
    return {"returncode": getattr(value, "returncode", None),
            "stderr": stderr.decode("utf-8", "replace") if isinstance(stderr, bytes) else stderr,
            "error_class": type(value).__name__}


def command_result(argv, result=None, error=None):
    global _context
    try:
        if _context is not None:
            _call("command_result", argv=argv, result=_result(result), error=_result(error))
    except Exception:
        _context = None


def transition(registry, handle, before, after, relaunchable, context=None):
    _call("transition", registry=str(registry), handle=handle, before=before, after=after,
          relaunchable=relaunchable, context=context)


def diagnostic(record, rotate=False):
    return _call("diagnostic", record=record, rotate=rotate)
