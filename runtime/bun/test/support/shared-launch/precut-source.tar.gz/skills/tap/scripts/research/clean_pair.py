"""Clean-Pair Registry (grok's design — tap-b80p).

Indexed by (task_class, seat, tier) cells.
A missing or stale cell MECHANICALLY requires the verifier pass,
making the empirically-clean exemption checkable instead of vibes.
Registry consumes research-run receipts to update cell states.
"""

from dataclasses import dataclass, field, asdict
import datetime
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .receipt import ResearchRunReceipt


@dataclass
class CleanPairCell:
    task_class: str
    seat: str
    tier: str
    n_verified: int = 0
    last_verified_at: Optional[str] = None
    last_verified_refs: List[str] = field(default_factory=list)

    @property
    def key(self) -> str:
        return f"{self.task_class}:{self.seat}:{self.tier}"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CleanPairCell":
        return cls(**data)


@dataclass
class VerificationRequirement:
    requires_verification: bool
    reason: str
    cell_state: Optional[CleanPairCell] = None


class CleanPairRegistry:
    def __init__(
        self,
        storage_path: Optional[Path] = None,
        min_n: int = 3,
        max_age_seconds: int = 86400 * 7,  # default 7 days TTL
    ):
        if storage_path is None:
            storage_path = Path.cwd() / ".tap" / "research" / "clean_pair_registry.json"
        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self.min_n = min_n
        self.max_age_seconds = max_age_seconds
        self.cells: Dict[str, CleanPairCell] = {}
        self._load()

    def _load(self) -> None:
        if not self.storage_path.exists():
            return
        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            cells_data = data.get("cells", {})
            for key, c_data in cells_data.items():
                self.cells[key] = CleanPairCell.from_dict(c_data)
        except Exception:
            self.cells = {}

    def save(self) -> None:
        data = {
            "version": "1.0",
            "min_n_default": self.min_n,
            "max_age_seconds_default": self.max_age_seconds,
            "updated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "cells": {k: c.to_dict() for k, c in self.cells.items()},
        }
        with open(self.storage_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def consume_receipt(self, receipt: ResearchRunReceipt) -> Tuple[CleanPairCell, bool, str]:
        """Consumes a research-run receipt.

        If the receipt is clean (valid, no drift, all verifiers pass),
        increments n_verified and records the receipt ID.
        If unclean/invalid, cell is not incremented.

        Returns (cell, updated_bool, reason).
        """
        cell_key = f"{receipt.task_class}:{receipt.seat}:{receipt.tier}"
        if cell_key not in self.cells:
            self.cells[cell_key] = CleanPairCell(
                task_class=receipt.task_class,
                seat=receipt.seat,
                tier=receipt.tier,
            )
        cell = self.cells[cell_key]

        if not receipt.is_clean():
            valid, errors = receipt.validate()
            reason = f"Receipt '{receipt.receipt_id}' rejected: " + "; ".join(errors)
            return cell, False, reason

        cell.n_verified += 1
        cell.last_verified_at = receipt.created_at
        if receipt.receipt_id not in cell.last_verified_refs:
            cell.last_verified_refs.append(receipt.receipt_id)

        self.save()
        return cell, True, f"Receipt '{receipt.receipt_id}' accepted. Cell '{cell_key}' n_verified={cell.n_verified}"

    def check_requirement(
        self,
        task_class: str,
        seat: str,
        tier: str,
        min_n: Optional[int] = None,
        max_age_seconds: Optional[int] = None,
    ) -> VerificationRequirement:
        """Mechanically determines if verification pass is required.

        Verification IS required if:
        1. Cell missing
        2. Cell n_verified < min_n
        3. Cell last_verified_at is older than max_age_seconds or missing
        """
        min_n = min_n if min_n is not None else self.min_n
        max_age_seconds = max_age_seconds if max_age_seconds is not None else self.max_age_seconds

        cell_key = f"{task_class}:{seat}:{tier}"
        cell = self.cells.get(cell_key)

        if not cell:
            return VerificationRequirement(
                requires_verification=True,
                reason=f"Cell '{cell_key}' is missing from clean-pair registry",
                cell_state=None,
            )

        if cell.n_verified < min_n:
            return VerificationRequirement(
                requires_verification=True,
                reason=f"Cell '{cell_key}' has n_verified={cell.n_verified} < required min_n={min_n}",
                cell_state=cell,
            )

        if not cell.last_verified_at:
            return VerificationRequirement(
                requires_verification=True,
                reason=f"Cell '{cell_key}' has no last_verified_at timestamp",
                cell_state=cell,
            )

        try:
            last_ts = datetime.datetime.fromisoformat(cell.last_verified_at)
            now = datetime.datetime.now(datetime.timezone.utc)
            age = (now - last_ts).total_seconds()
            if age > max_age_seconds:
                return VerificationRequirement(
                    requires_verification=True,
                    reason=f"Cell '{cell_key}' is stale (age {int(age)}s > max {max_age_seconds}s)",
                    cell_state=cell,
                )
        except Exception:
            return VerificationRequirement(
                requires_verification=True,
                reason=f"Cell '{cell_key}' has invalid timestamp format",
                cell_state=cell,
            )

        return VerificationRequirement(
            requires_verification=False,
            reason=f"Cell '{cell_key}' is clean and verified (n={cell.n_verified})",
            cell_state=cell,
        )
