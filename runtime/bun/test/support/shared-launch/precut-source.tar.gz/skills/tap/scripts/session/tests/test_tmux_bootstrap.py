import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import tmux_bootstrap as boot


def bootstrap_env(tmp_path):
    home = tmp_path / 'home'
    home.mkdir()
    return {'HOME': str(home), 'PATH': '/usr/bin:/bin', 'TAP_INDEX_HOME': str(tmp_path / 'index'),
            'TAP_TMUX_SOCKET_PATH': str(tmp_path / 'socket'), 'TERM': 'dumb',
            'TMUX': '/old/socket,1,1', 'TMUX_PANE': '%1', 'CODEX_THREAD_ID': 'old',
            'CLAUDECODE': '1', 'ANTHROPIC_API_KEY': 'secret', 'TAP_HOME': '/foreign', 'GIT_DIR': '/repo/.git'}


def result(code=0, stdout='123\n', stderr=''):
    return SimpleNamespace(returncode=code, stdout=stdout, stderr=stderr)


def test_absent_bootstrap_is_atomic_home_scoped_and_scrubbed(tmp_path):
    env = bootstrap_env(tmp_path)
    calls = []
    observations = iter([result(1, '', 'no server running'), result(1, '', 'no server running'), result()])
    def run(argv, **kwargs):
        calls.append((argv, kwargs))
        if 'display-message' in argv:
            return next(observations)
        return result(stdout='')
    with mock.patch.object(boot.shutil, 'which', return_value='/usr/bin/tmux'), mock.patch.object(boot.subprocess, 'run', side_effect=run):
        assert boot.ensure_server(env)
    argv, options = next(c for c in calls if 'start-server' in c[0])
    assert argv[-6:] == ['start-server', ';', 'set-option', '-s', 'exit-empty', 'off']
    assert options['cwd'] == Path(env['HOME'])
    assert options['env']['TERM'] == 'xterm-256color'
    assert not any(k.startswith(('TAP_', 'CODEX', 'CLAUDE', 'ANTHROPIC_')) or k in ('TMUX', 'TMUX_PANE', 'GIT_DIR') for k in options['env'])
    assert argv[1:3] == ['-S', env['TAP_TMUX_SOCKET_PATH']]


def test_existing_server_is_never_reconfigured(tmp_path):
    env = bootstrap_env(tmp_path)
    with mock.patch.object(boot.shutil, 'which', return_value='/usr/bin/tmux'), mock.patch.object(boot.subprocess, 'run', return_value=result()) as run:
        assert not boot.ensure_server(env)
        assert run.call_count == 1
        assert 'display-message' in run.call_args.args[0]
    assert not Path(env['TAP_INDEX_HOME']).exists()


def test_opt_out_does_not_probe_or_touch_server(tmp_path):
    env = bootstrap_env(tmp_path)
    config = Path(env['HOME']) / '.config/tap/config.toml'
    config.parent.mkdir(parents=True)
    config.write_text('[tmux]\nbootstrap = false\n')
    with mock.patch.object(boot.subprocess, 'run', side_effect=AssertionError('no effect')):
        assert not boot.ensure_server(env)
    assert not Path(env['TAP_INDEX_HOME']).exists()


def test_unobservable_is_not_absent(tmp_path):
    env = bootstrap_env(tmp_path)
    with mock.patch.object(boot.shutil, 'which', return_value='/usr/bin/tmux'), mock.patch.object(boot.subprocess, 'run', return_value=result(1, '', 'Permission denied')) as run:
        try:
            boot.ensure_server(env)
            assert False, 'must refuse unknown socket state'
        except RuntimeError as error:
            assert 'unobservable' in str(error)
        assert run.call_count == 1


def test_second_probe_observes_concurrent_starter(tmp_path):
    env = bootstrap_env(tmp_path)
    with mock.patch.object(boot.shutil, 'which', return_value='/usr/bin/tmux'), mock.patch.object(boot.subprocess, 'run', side_effect=[result(1, '', 'no server running'), result()]) as run:
        assert not boot.ensure_server(env)
        assert run.call_count == 2


def test_broken_sibling_config_is_nonblocking(tmp_path, capsys):
    env = bootstrap_env(tmp_path)
    config = Path(env['HOME']) / '.config/tap/config.toml'
    config.parent.mkdir(parents=True)
    config.write_text('[unrelated]\nbroken = [\n')
    assert boot.enabled(env)
    assert str(config) in capsys.readouterr().err
    config.write_text('[tmux]\nbootstrap = "invalid"\n')
    try:
        boot.enabled(env)
        assert False
    except ValueError:
        pass


def test_malformed_stamps_are_not_comparable():
    from test_launcher import launcher
    observation = ('boot:200', 'srv:2:200', '/tmp/test')
    for value in ('garbage', ' ', 'bootuuid:no', 'srv:wrong'):
        for field in ('boot_id', 'server_epoch'):
            row = {'server_socket':'/tmp/test', field:value}
            assert not launcher.stale_seat_generation(row, observation)
    assert not launcher.stale_seat_generation({'server_socket':'/tmp/test','boot_id':'bootuuid:12345678-1234-1234-1234-123456789abc'}, observation)
