# TAP Contract (v0.23)

Normative core; details in [protocol](../protocol/README.md); grammar in `tap help <verb>`. Protocol changes update the owning page in the same PR.

## Scope

TAP is a same-human, same-machine file bus and best-effort tmux courier, not an auth or security boundary. The bus keeps durable payloads and receipts; injection only lowers wake latency — neither placement nor submission proves recipient processing.

## Layers and ownership

Transport moves bytes and records effects; skills and workflows decide convergence, review and merge eligibility. The sender's bus owns its payloads and receipts. Each runtime store has one declared authority; history and journals never silently become current.

`send`, `assign` and `reply` share one runtime selector, `route()`, bridging those verbs into Bun and honoring a selected Bash runtime (`TAP_RUNTIME=bash` or `~/.tap/runtime-bash`) as fallback plumbing, not authentication. Interrupt, manual relay, remote registry/proof, pane override, wake, reply-to and rollback stay Bash-owned; missing Bun or entry points fall back to `tap.sh`.

Native `register|in` writes current `seats` authority only. It bootstraps a pristine canonical worktree, refuses old stores before writes, and never migrates them during registration; enrolled custom registry locations and historical identity evidence remain supported.

Native `poll` owns all execution doors, per the [poll contract](../protocol/delivery/poll-malformed-payload-contract.md#native-poll-ownership).

## Messages

Use `send` for notes, `assign` for work, `reply` for answers, `escalate` for user questions; `tap read` settles notes, asks need `tap reply`. Read payloads before acting — sentinels are doorbells with only the resolved body's authority for the registered recipient. Use `-f` for literal bodies; quoted heredocs keep shell syntax inert.

Protocol version (sentinel slot 1): 0.23.

```text
[[TAP v0.23 <ask|note> [<team>/]<id> [tag ...] [preview="text"] [path=<abs>]]]
```

## Identity and delivery

Handles name team seats; instances distinguish occupants. Re-resolve liveness, the selected instance, and pane/session/generation/socket binding at every effect (including detached) and the final registry read; identity needs a process-owned pane. Outside ancestry selects at most one exact active Claude row: its native session, or a background job matching daemon session, owner, cwd and subsecond lineage. A matching recorded socket pins observation when the default server is unavailable; socketless legacy rows stay default-only. Malformed, ambiguous, stale or successor state refuses; background ownership replaces neither native identity nor shared-actor rules.

`tap team doctor --fix` repairs session attribution, never seat ownership; refuses ambiguous or duplicate-owned identities.

Prechecks precede effects; the submit or native-effect owner atomically writes complete, no-clobber evidence per attempt id — no id, no receipt. Never combine attempts or auto-retry a possible effect. Receipts distinguish placement, pane submission, settlement, cancellation and uncertainty; never collapse them into “delivered.”

## Liveness and recovery

After sending/replying, continue independent work; never sleep or loop-poll for traffic. Before yielding, inspect obligations. Recovery observes first, preserves evidence, never replays a possible effect.

The registry pair suspended/incapable is the operator's cross-cutting incapacity invariant: every reader treats it as stopped-like, clearable only by public re-registration from the marked seat's own pane — no repair, rebuild, attach, resume or other lifecycle path may clear it.

Self rebrief replaces context, preserving instance and obligations; Codex reset proof is post-input; the brief persists before effects.

## Evolution and verification

Protocol, sentinel, envelope, registry and receipt versions move with readers and controls; tests pin high-risk invariants; text checks don't prove semantic equivalence. Exact-head review and gate evidence are separate from transport receipts.
