"""The config-floor invariants, stated once and checked exhaustively.

WHY THIS FILE EXISTS (fable's ruling, 2026-08-17). Four of six consecutive review
findings in #xxx were fix-induced regressions in ONE mechanism: params_to_argv
rendering a value, and splice_tokens_if_absent deciding whether the builder
already emits it. Each individual fix was correct and each opened an adjacent
seam, which is the signature of missing invariant coverage rather than
insufficient care. The sequence, for the record:

  1. the adapter-conflict guard read a VALUE as a key           -> false refusal
  2. fixing that, it then read a DISABLED key as present        -> false refusal
  3. a flag-shaped value was EATEN by the floor                 -> orphaned flag
  4. fixing that with `=`, the option was DOUBLED past the floor -> duplicate

Every one is the same underlying question asked wrong: *which tokens are options,
and which are their values?* So the invariants are enumerated here as properties
over a matrix of shapes, rather than as one example per bug. A future fix that
trades one of these for another reds immediately instead of shipping and being
found by review.

THE INVARIANTS
  I1  A config option the builder does NOT emit reaches argv, with its value.
  I2  A config option the builder DOES emit never reaches argv twice, in any
      spelling combination (bare/`=` on either side).
  I3  A value is never separated from its option, whatever the value looks like.
  I4  A `false` param contributes nothing at all.
  I5  Operator passthrough (floor=False) is never floored — the human outranks
      config, which is the one case that must NOT be deduped.
"""

import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

import presets  # noqa: E402


# Values chosen to span the shapes that broke: ordinary, flag-shaped, dash-led,
# empty-ish, and one containing `=` (which the `=` rendering must not confuse).
VALUES = ["plain", "--workspace", "-tmp", "a=b", "with space", "-"]
BUILDER_OWNED = "--workspace"
NOT_BUILDER_OWNED = "--foo"


def option_names(argv):
    return [token.split("=", 1)[0] for token in argv if token.startswith("-")]


class FloorInvariantTests(unittest.TestCase):
    def builder_argv(self, spelling="bare"):
        if spelling == "bare":
            return ["cursor-agent", BUILDER_OWNED, "/repo", "--force"]
        return ["cursor-agent", f"{BUILDER_OWNED}=/repo", "--force"]

    def test_i1_a_non_builder_option_arrives_exactly_as_rendered(self):
        """The INSERTED SEGMENT must equal the rendering, token for token.

        Substring survival is not enough, and this is the hole sol-prepull found
        in the first version of this file: searching the whole joined argv for
        the value lets the BUILDER'S OWN copy satisfy the assertion. Degrade
        `--foo=--workspace` to a bare `--foo` and the splice yields

            cursor-agent --foo --workspace /repo --force

        where `--workspace` is the builder's, `--foo` has lost its value, and a
        substring check passes anyway. The net went green on exactly the
        regression it exists to catch.

        Splicing inserts at index 1, so the rendering must appear there verbatim.
        """
        for value in VALUES:
            with self.subTest(value=value):
                tokens = list(presets.params_to_argv({"foo": value}))
                builder = self.builder_argv()
                spliced = presets.splice_tokens_if_absent(builder, tokens)
                self.assertEqual(
                    spliced[1 : 1 + len(tokens)],
                    tokens,
                    f"inserted segment is not the rendering for {value!r}: {spliced}",
                )
                # ...and the rest of the builder argv is untouched.
                self.assertEqual(spliced[1 + len(tokens) :], builder[1:])

    def test_i2_a_builder_owned_option_is_never_doubled(self):
        for value in VALUES:
            for spelling in ("bare", "equals"):
                with self.subTest(value=value, builder=spelling):
                    argv = self.builder_argv(spelling)
                    spliced = presets.splice_tokens_if_absent(
                        argv, presets.params_to_argv({"workspace": value})
                    )
                    self.assertEqual(
                        option_names(spliced).count(BUILDER_OWNED),
                        1,
                        f"builder-owned option duplicated: {spliced}",
                    )
                    # The floor means builder argv WINS, so the config value must
                    # not appear at all — not merely appear once.
                    self.assertEqual(
                        spliced,
                        argv,
                        f"the builder's argv is the floor and must be unchanged: {spliced}",
                    )

    def test_i3_an_option_never_arrives_without_the_value_it_was_given(self):
        """The orphaning bug in its purest form, asserted on the RENDERING.

        `--foo --workspace` as two tokens let the floor eat the VALUE, leaving
        `--foo` to swallow whatever followed. Checking "is the next token the
        value?" cannot distinguish that from the builder's own `--workspace`
        landing next to an orphaned `--foo` — so the binding is asserted against
        what params_to_argv actually produced, not against adjacency.
        """
        tokens = list(presets.params_to_argv({"foo": BUILDER_OWNED}))
        # The rendering itself must keep them bound: one fused token, never two.
        self.assertEqual(tokens, [f"{NOT_BUILDER_OWNED}={BUILDER_OWNED}"])
        spliced = presets.splice_tokens_if_absent(self.builder_argv(), tokens)
        self.assertEqual(spliced[1 : 1 + len(tokens)], tokens, f"{spliced}")

    def test_i4_a_false_param_contributes_nothing(self):
        self.assertEqual(presets.params_to_argv({"mode": False}), ())
        argv = self.builder_argv()
        self.assertEqual(
            presets.splice_tokens_if_absent(argv, presets.params_to_argv({"mode": False})),
            argv,
        )

    def test_i5_operator_passthrough_is_never_floored(self):
        # floor=False is the human's own tail. Deduping it would silently drop a
        # flag the operator typed BECAUSE the builder already emits it, which is
        # backwards: the operator is the stronger authority.
        argv = self.builder_argv()
        tokens = [BUILDER_OWNED, "/elsewhere"]
        spliced = presets.splice_tokens_if_absent(argv, tokens, floor=False)
        # EXACT sequence, not a name count: counting names passes even when the
        # operator's VALUE is dropped, which is the same substring-style hole as
        # I1. floor=False has one legal answer and this is it.
        self.assertEqual(spliced, [argv[0], *tokens, *argv[1:]])

    def test_the_rendering_and_the_keys_agree_about_what_is_emitted(self):
        """param_keys and the rendered tokens must name the SAME options.

        The adapter-conflict guard keys on `param_keys`; the floor keys on
        rendered tokens. Both false refusals came from those two disagreeing
        about which options a preset actually emits — first by reading a VALUE as
        a key, then by carrying a DISABLED key that renders nothing.

        Read from a REAL resolved preset rather than recomputed here: an
        expectation derived independently cannot notice the field regressing,
        which is exactly why the first version of this test passed under the
        disabled-key mutation.
        """
        import tempfile

        with tempfile.TemporaryDirectory() as home:
            cfg = pathlib.Path(home) / "tap"
            cfg.mkdir()
            (cfg / "config.toml").write_text(
                'version = 2\n\n[presets.p]\nharness = "cursor"\n\n'
                '[presets.p.params]\n'
                'mode = false\n'          # renders nothing
                'foo = "--workspace"\n'   # flag-shaped VALUE, not a key
                'quiet = true\n'          # bare flag
                'effort = "high"\n'
            )
            resolved = presets.load_preset_catalog({"XDG_CONFIG_HOME": home}).get("p")

        rendered = set(option_names(resolved.harness_passthrough))
        declared = {f"--{key}" for key in resolved.param_keys}
        self.assertEqual(
            declared,
            rendered,
            "param_keys and the rendered argv disagree about which options this "
            f"preset emits: keys={sorted(declared)} rendered={sorted(rendered)}",
        )
        # And specifically: a disabled param is in neither.
        self.assertNotIn("--mode", declared)
        self.assertNotIn("--mode", rendered)


if __name__ == "__main__":
    unittest.main()
