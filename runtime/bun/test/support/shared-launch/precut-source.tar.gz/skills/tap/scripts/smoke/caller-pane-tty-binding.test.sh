#!/usr/bin/env bash
# caller-pane-tty-binding.test.sh — tap-bzyz headline: `tap_calling_pane_id`
# must re-assert the TTY BINDING it resolved, not merely that the id is live.
#
# THE DEFECT, stated precisely — it is not "two reads", it is that the SECOND read
# checks the WRONG FACT:
#
#   Observation 1 (lib.sh list-panes scan) establishes a BINDING: my tty -> %N.
#   Observation 2 (tap_pane_alive %N) asks only "does a pane with id %N exist?"
#
# `tap_pane_alive` returns its argument iff display-message yields a non-empty
# `#{pane_id}` for that target — which is vacuously true of ANY live id. So the
# second read never re-asserts that %N still owns the caller's tty. A tmux server
# replacement that RECYCLES the numeric id passes it trivially, and the function
# hands a STRANGER'S PANE to seven callers, including `tap_resolve_self_handle`.
#
# That is why "make the two reads atomic" would NOT have been a fix: collapsing
# them into one observation of `pane_id` alone still checks a vacuous property.
#
# Tests:
# (a) happy path: the pane that owns the caller's tty is returned
# (b) THE WITNESS: id survives, tty ownership MOVES -> must REFUSE, not return it
# (c) pane genuinely gone -> refuses (no regression in the liveness it did have)
# (d) ambiguity guard intact: two panes on one tty -> refuses
# (o) a caller-owned outside tty cannot borrow an ancestor's pane identity
# (e-j) every internal refusal identifies the failed observation through the
#       additive refusal channel without rendering on its own
# (k) default `whoami` folds that reason into its one human error line
# (l) `whoami --json` folds it into structured stdout and keeps stderr empty
# (m) `team shutdown --json` does the same before any caller identity work
# (n) a best-effort shutdown probe may still succeed without false-alarm stderr
#
# Run: bash skills/tap/scripts/smoke/caller-pane-tty-binding.test.sh
set -uo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
LIB="$ROOT/skills/tap/scripts/lib.sh"
TAP="$ROOT/scripts/tap.sh"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

pass=0; fail=0
ok()  { pass=$((pass + 1)); printf '  ok   %s\n' "$1"; }
bad() { fail=$((fail + 1)); printf '  FAIL %s\n' "$1"; }

echo "tap-bzyz/caller-pane-tty-binding test  (the second read must re-assert the binding)"

export TAP_HOME="$WORK/.tap/bus"
mkdir -p "$TAP_HOME/payloads" "$TAP_HOME/receipts"

# --- fake tmux -----------------------------------------------------------------
# Models BOTH facts the site reads, and lets them disagree — which is the whole
# point. SCAN_MAP is what `list-panes -a` reports (the binding at observation 1);
# LIVE_MAP is what `display-message -t <id>` reports (observation 2). A server
# replacement is simulated by leaving an id in LIVE_MAP while SCAN_MAP has moved
# that tty to a different pane, or while the id's own tty has changed.
mkdir -p "$WORK/bin"
cat > "$WORK/bin/tmux" <<'FAKE'
#!/usr/bin/env bash
cmd="${1:-}"; shift || true
case "$cmd" in
  list-panes)
    # `list-panes -a -F '#{pane_id}\t#{pane_tty}'` — emit the SCAN map verbatim.
    printf '%s' "${SCAN_MAP:-}"
    ;;
  display-message)
    target=""; fmt=""
    while [ "$#" -gt 0 ]; do
      case "$1" in
        -p) shift ;;
        -t) target="$2"; shift 2 ;;
        *)  fmt="$1"; shift ;;
      esac
    done
    # LIVE_MAP lines are "<pane_id><TAB><pane_tty>". A target absent from it is a
    # dead pane. Answer the requested fields from the SAME row, so a composite
    # format is answered consistently rather than one-field-per-glob.
    row=""
    while IFS= read -r line; do
      [ -n "$line" ] || continue
      lid="${line%%	*}"
      [ "$lid" = "$target" ] || continue
      row="$line"; break
    done <<< "${LIVE_MAP:-}"
    [ -n "$row" ] || exit 0          # dead: exit 0 with EMPTY output (tmux 3.6a)
    lid="${row%%	*}"; ltty="${row#*	}"
    out="$fmt"
    out="${out//'#{pane_id}'/$lid}"
    out="${out//'#{pane_tty}'/$ltty}"
    printf '%s' "$out"
    ;;
  *) exit 0 ;;
esac
FAKE
chmod +x "$WORK/bin/tmux"
export PATH="$WORK/bin:$PATH"

# `tap_calling_pane_id` walks ps(1) up the process tree for a tty. Pin that so the
# test drives the tmux side rather than whatever tty the runner happens to have.
cat > "$WORK/bin/ps" <<'FAKEPS'
#!/usr/bin/env bash
pid=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    -p) pid="$2"; shift 2 ;;
    *) shift ;;
  esac
done
case "${FAKE_PS_MODE:-tty}" in
  missing) exit 0 ;;
  invalid-parent) printf '%s %s\n' "invalid" "?" ;;
  root) printf '%s %s\n' "1" "?" ;;
  depth) printf '%s %s\n' "$((pid + 1))" "?" ;;
  outside-child)
    if [ "$pid" = "${FAKE_CALLER_PID:-}" ]; then
      printf '%s %s\n' "777" "ttys009"
    else
      printf '%s %s\n' "1" "ttys001"
    fi
    ;;
  *) printf '%s %s\n' "1" "${FAKE_CALLER_TTY:-ttys999}" ;;
esac
FAKEPS
chmod +x "$WORK/bin/ps"
export FAKE_CALLER_TTY="ttys001"

call_id() { bash -c '. "$1"; tap_calling_pane_id' _ "$LIB" 2>/dev/null; }
call_id_var() {
  bash -c '. "$1"; resolved=""; tap_calling_pane_id resolved; printf "%s" "$resolved"' _ "$LIB" 2>/dev/null
}
expect_reason() { # <case> <ps-mode> <literal reason>
  local case_id="$1" ps_mode="$2" reason="$3" rc
  local out="$WORK/$case_id.out" err="$WORK/$case_id.err" refusal="$WORK/$case_id.refusal"
  FAKE_PS_MODE="$ps_mode" bash -c '
    . "$1"
    resolved=""
    if tap_calling_pane_id resolved; then
      rc=0
    else
      rc=$?
    fi
    printf "%s" "${TAP_CALLING_PANE_REFUSAL:-}" >"$2"
    exit "$rc"
  ' _ "$LIB" "$refusal" >"$out" 2>"$err"
  rc=$?
  if [ "$rc" -ne 0 ] && [ ! -s "$out" ] && [ ! -s "$err" ] && grep -Fq "$reason" "$refusal"; then
    ok "$case_id published without rendering: $reason"
  else
    bad "$case_id missing quiet refusal '$reason' (rc=$rc, stdout='$(cat "$out")', stderr='$(cat "$err")', refusal='$(cat "$refusal")')"
  fi
}

# (a) happy path ------------------------------------------------------------------
echo "-- (a) the pane owning the caller's tty is returned --"
export SCAN_MAP=$'%5\t/dev/ttys001\n%6\t/dev/ttys002\n'
export LIVE_MAP=$'%5\t/dev/ttys001\n%6\t/dev/ttys002\n'
GOT="$(call_id)"
GOT_BY_VAR="$(call_id_var)"
if [ "$GOT" = "%5" ] && [ "$GOT_BY_VAR" = "%5" ]; then
  ok "(a) resolved %5 through stdout and the current-shell output variable"
else
  bad "(a) got stdout='$GOT' output-var='$GOT_BY_VAR', expected %5"
fi

# The tap_calling_pane_id output-variable API accepts any caller variable name.
# Bash `printf -v` follows dynamic scope, so the wrapper sends one reserved
# scratch name into the observer and assigns the caller only from its local-free frame.
for collision_name in \
  observation pane_id output_var result pid row ppid tty pane_tty panes_raw \
  candidate candidate_tty found observed observed_id observed_tty \
  observed_session observed_raw_epoch observed_epoch rest record steps \
  pane_format observation_format _TAP_CALLING_PANE_ID_VALUE; do
  collision_result="$(bash -c '
    . "$1"
    observation=STALE
    pane_id=STALE
    printf -v "$2" "%s" STALE
    tap_calling_pane_id "$2"
    rc=$?
    printf "%s|%s" "$rc" "${!2}"
  ' _ "$LIB" "$collision_name" 2>/dev/null)"
  if [ "$collision_result" = "0|%5" ]; then
    ok "(a-$collision_name) output variable name '$collision_name' receives %5"
  else
    bad "(a-$collision_name) output variable collision returned '$collision_result', expected 0|%5"
  fi
done

# (b) THE WITNESS -----------------------------------------------------------------
# The id %5 is still live, but on the REPLACEMENT server it belongs to a different
# terminal — a recycled numeric id. The scan still binds ttys001 -> %5 (that is the
# stale map the caller resolved from), while %5 itself now reports a DIFFERENT tty.
# Checking only "is %5 alive?" says yes. Checking the BINDING says no.
echo "-- (b) WITNESS: id live but tty ownership moved -> must refuse --"
export SCAN_MAP=$'%5\t/dev/ttys001\n'
export LIVE_MAP=$'%5\t/dev/ttys999\n'      # same id, someone else's terminal
GOT="$(call_id)"; RC=$?
if [ -z "$GOT" ]; then
  ok "(b) refused to hand back a recycled id whose tty binding no longer holds"
else
  bad "(b) returned '$GOT' for a pane that no longer owns the caller's tty — a stranger's pane"
fi

# (c) genuinely gone --------------------------------------------------------------
echo "-- (c) pane actually gone: still refuses --"
export SCAN_MAP=$'%5\t/dev/ttys001\n'
export LIVE_MAP=$''                        # %5 does not exist at all
GOT="$(call_id)"
[ -z "$GOT" ] && ok "(c) dead pane refused (liveness not regressed)" || bad "(c) returned '$GOT' for a dead pane"

# (d) ambiguity guard -------------------------------------------------------------
echo "-- (d) two panes on one tty: refuses rather than guessing --"
export SCAN_MAP=$'%5\t/dev/ttys001\n%7\t/dev/ttys001\n'
export LIVE_MAP=$'%5\t/dev/ttys001\n%7\t/dev/ttys001\n'
GOT="$(call_id)"
[ -z "$GOT" ] && ok "(d) ambiguous tty refused" || bad "(d) returned '$GOT' with two panes on one tty"

# (e) process observation missing -------------------------------------------------
echo "-- (e-j) each internal refusal publishes its failed observation --"
export SCAN_MAP=$''
export LIVE_MAP=$''
expect_reason "(e)" missing "process observation unavailable"

# (f) one controlling tty maps to more than one pane -----------------------------
export SCAN_MAP=$'%5\t/dev/ttys001\n%7\t/dev/ttys001\n'
export LIVE_MAP=$'%5\t/dev/ttys001\n%7\t/dev/ttys001\n'
expect_reason "(f)" tty "controlling tty '/dev/ttys001' maps to multiple panes"

# (g) the composite binding changes before recheck -------------------------------
export SCAN_MAP=$'%5\t/dev/ttys001\n'
export LIVE_MAP=$'%5\t/dev/ttys999\n'
expect_reason "(g)" tty "pane '%5' no longer owns controlling tty '/dev/ttys001'"

# (h) ps returns a parent value that cannot be followed ---------------------------
export SCAN_MAP=$''
export LIVE_MAP=$''
expect_reason "(h)" invalid-parent "process observation returned invalid parent pid 'invalid'"

# (i) ancestry reaches its root without a tmux-owned tty --------------------------
expect_reason "(i)" root "process ancestry ended before finding a tmux pane"

# (j) malformed ancestry cannot consume the caller forever ------------------------
expect_reason "(j)" depth "process ancestry exceeded 64 steps before finding a tmux pane"

# (k) default output has one renderer and carries the internal reason -------------
human_out="$WORK/human.out"
human_err="$WORK/human.err"
set +e
FAKE_PS_MODE=missing "$TAP" whoami >"$human_out" 2>"$human_err"
human_rc=$?
set -e
human_lines="$(wc -l <"$human_err" | tr -d ' ')"
if [ "$human_rc" -eq 1 ] && [ ! -s "$human_out" ] && [ "$human_lines" = 1 ] \
    && grep -Fq "tap whoami:" "$human_err" \
    && grep -Fq "process observation unavailable" "$human_err"; then
  ok "(k) default whoami renders one line carrying the caller observation"
else
  bad "(k) default whoami renderer changed (rc=$human_rc, lines=$human_lines, stdout='$(cat "$human_out")', stderr='$(cat "$human_err")')"
fi

# (l) whoami JSON output is structured stdout only -------------------------------
json_out="$WORK/whoami-json.out"
json_err="$WORK/whoami-json.err"
set +e
FAKE_PS_MODE=missing "$TAP" whoami --json >"$json_out" 2>"$json_err"
json_rc=$?
set -e
if [ "$json_rc" -eq 1 ] && [ ! -s "$json_err" ] && "${TAP_PYTHON:-python3}" -B - "$json_out" <<'PY'
import json, sys
data = json.load(open(sys.argv[1]))
assert data["ok"] is False, data
assert data["error_class"] == "not_in_tmux", data
assert "process observation unavailable" in data["detail"], data
PY
then
  ok "(l) whoami --json carries the reason on stdout with empty stderr"
else
  bad "(l) whoami --json contract changed (rc=$json_rc, stdout='$(cat "$json_out")', stderr='$(cat "$json_err")')"
fi

# (m) shutdown establishes JSON mode before resolving the caller -----------------
shutdown_json_out="$WORK/shutdown-json.out"
shutdown_json_err="$WORK/shutdown-json.err"
set +e
TMUX=/fake FAKE_PS_MODE=missing "$TAP" team shutdown --json --dry-run \
  >"$shutdown_json_out" 2>"$shutdown_json_err"
shutdown_json_rc=$?
set -e
if [ "$shutdown_json_rc" -eq 1 ] && [ ! -s "$shutdown_json_err" ] \
    && "${TAP_PYTHON:-python3}" -B - "$shutdown_json_out" <<'PY'
import json, sys
data = json.load(open(sys.argv[1]))
assert data["ok"] is False, data
assert data["error_class"] == "caller_identity_unobservable", data
assert "process observation unavailable" in data["detail"], data
PY
then
  ok "(m) team shutdown --json carries the reason on stdout with empty stderr"
else
  bad "(m) team shutdown --json contract changed (rc=$shutdown_json_rc, stdout='$(cat "$shutdown_json_out")', stderr='$(cat "$shutdown_json_err")')"
fi

# (n) no-TMUX shutdown treats caller identity as a quiet best-effort observation -
best_effort_out="$WORK/best-effort.out"
best_effort_err="$WORK/best-effort.err"
set +e
env -u TMUX FAKE_PS_MODE=missing "$TAP" team shutdown --dry-run \
  >"$best_effort_out" 2>"$best_effort_err"
best_effort_rc=$?
set -e
# Class (a) CONTRACT §Registry lifecycle: blank seats={} dry-run plans delete
# (tap-w3op / sol #xxx P1-2), not the pre-w3op "nothing to shut down" string.
# Pin remains: rc=0 and empty stderr (no caller-observation false alarm).
if [ "$best_effort_rc" -eq 0 ] && [ ! -s "$best_effort_err" ] \
    && grep -Eq 'nothing to shut down|would delete blank acting registry' "$best_effort_out"; then
  ok "(n) best-effort shutdown succeeds without caller-observation stderr"
else
  bad "(n) best-effort shutdown produced a false alarm (rc=$best_effort_rc, stdout='$(cat "$best_effort_out")', stderr='$(cat "$best_effort_err")')"
fi

# (o) first observed terminal is the caller identity -----------------------------
# A child may own a new controlling PTY while still descending from a process in
# a tmux pane. Once that child terminal is observable and absent from the pane
# inventory, climbing farther must not borrow the ancestor's pane identity.
export SCAN_MAP=$'%5\t/dev/ttys001\n'
export LIVE_MAP=$'%5\t/dev/ttys001\n'
outside_child_result="$(FAKE_PS_MODE=outside-child bash -c '
  . "$1"
  export FAKE_CALLER_PID="$BASHPID"
  resolved=""
  if tap_calling_pane_id resolved; then rc=0; else rc=$?; fi
  printf "%s|%s|%s" "$rc" "$resolved" "${TAP_CALLING_PANE_STATE:-}"
' _ "$LIB" 2>/dev/null)"
if [ "$outside_child_result" = "1||outside" ]; then
  ok "(o) outside child terminal did not borrow its ancestor's pane identity"
else
  bad "(o) outside child terminal borrowed ancestor identity: '$outside_child_result'"
fi

echo
printf 'caller-pane-tty-binding: %d passed, %d failed\n' "$pass" "$fail"
[ "$fail" -eq 0 ] || exit 1
