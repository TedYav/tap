#!/usr/bin/env bash
# pin-check.sh — a guard is pinned only if mutating it reds a NAMED arm, in the
# direction that has a defined correct behavior (tap-xzu6).
#
# WHY THIS IS NOT A SUITE ARM. It mutates the tree and runs other arms, which
# costs seconds to minutes per predicate. The merge gate has a fixed wall-time
# floor already; putting mutation inside it would trade the gate everyone runs
# for a gate nobody can afford. This is a GATE STEP, invoked on the predicates a
# diff touches. The cheap half — that a declaration is well formed and cites arms
# that exist — is a suite arm (pins-declaration.test.sh) and runs every time.
#
# THE OPERATOR IS A PAIR, NOT A DELETION (the result that forced this design).
# The rule this implements was first written as "every guard needs an arm that
# reds when the guard is DELETED". Deletion misses the most common shape in the
# corpus. At 325fd86c, tap-reply.sh:392 was
#
#     [ "$SEND_STATUS" = queued ] || _reply_turn="; submitted to pane; ..."
#
# and the defect was the qualifier appearing on the queued branch, where it is a
# lie. Deleting the line removes the string EVERYWHERE — the opposite of the
# defect. Forcing the predicate to FAIL (so the right-hand side always runs) is
# what reproduces it, and all five arms citing t-reply stayed green under it.
#
# So the two operators are the two constant substitutions of the predicate:
#
#   always-pass   <expr> || <action>   ->   true  || <action>    (the action never runs)
#   always-fail   <expr> || <action>   ->   false || <action>    (the action always runs)
#
# Deletion is just always-pass for a refusal guard. always-fail is the direction
# nobody runs by hand, because a guard that fires too often reads as caution
# rather than as a bug.
#
# WHAT IT REFUSES, and both are first-class OUTPUTS rather than skips:
#
#   mutation-invalid       the mutant does not parse, so it tested NOTHING. Found
#                          by making this mistake: cutting one line too many from
#                          a guard produced a syntax error whose exit code is
#                          indistinguishable from a pinned guard. A red from a
#                          mutant that does not compile is not a red. Reported
#                          per mutant — never silently dropped, or the checker
#                          reports a clean sweep over mutants it never ran.
#
#   declared-but-unpinned  the direction was declared pinned and its named arm
#                          did not red. The strongest thing this can say: someone
#                          wrote down a claim the tree does not support.
#
# SITE DISCRIMINATION IS THE WHOLE CHECK, not a refinement of it. Two guards in
# series on one path produce the same observable. At 6f874303, deleting only the
# tap_spool_digest_inject guard left the call still refused — by the drain-entry
# guard one layer down — so an arm asserting "was refused" passes while
# defense-at-the-boundary regresses invisibly. A red therefore counts only when
# the arm's output NAMES this predicate's site. "Something went red" is the
# hollow-control shape (61d50c42) applied to the checker itself.
#
# DECLARATION, on the line above the predicate (never in the test — a citation in
# the test drifts from the predicate silently; one on the line above it cannot):
#
#   # PINS: <id>  pass-><arm>  fail-><arm>
#   # PINS: <id>  pass->n/a: <reason>  fail-><arm>
#
# <arm> is an arm label spelled `(name)` in a suite file, the same identity
# arm-inventory.test.sh already enforces. BOTH DIRECTIONS MUST CITE A RUNNABLE
# ARM. There is no n/a.
#
# n/a was in the first cut, gated on "the reason field is non-empty". A
# decorrelated reviewer showed the gate is satisfied by `n/a: arbitrary prose`,
# and that the sole real adopter in the tree had used it for a direction with a
# clearly defined behavior. The general form, adopted as a standing line:
# NO PARSER CAN VALIDATE A RATIONALE'S TRUTH. A reason field checked for presence
# is satisfied by any string, so it is an escape hatch with a comment attached.
# A genuine exception is reported WAIVED/UNPINNED and exits nonzero — visible,
# never counted as pinned.
#
# WHAT THIS TOOL PROVES, AND WHAT IT CANNOT. It proves CONFORMANCE TO A FAILURE
# PROTOCOL: that the cited arm, run against a mutant of the declared predicate,
# terminated in the exact reserved way that says "this site, this direction".
# It does NOT prove causality. Arbitrary combined prose cannot establish that a
# red was CAUSED by the mutation — the first cut scored a red as `pinned` when
# the mutant hit an unrelated downstream failure and exited 42, because the id
# appeared in an earlier banner. A red credited to a site that did not cause it
# is this bead's own class inside the discriminator meant to end it. The protocol
# below replaces prose matching; the ceiling stays, and is stated rather than
# implied.
#
# THE PROTOCOL an arm must follow to be credited:
#   1. Unmutated, the arm exits 0. A cited arm that is already red proves nothing
#      about any mutation, so a non-green baseline is refused before any mutant.
#   2. Against the mutant, the arm exits exactly 91 and its FINAL line is exactly
#      PIN-SITE-RED:<arm>:<id>:<dir>
#
# THE ARM IDENTITY IS IN THE RECORD, and that is not decoration. `run_arm`
# selects a FILE by label and runs the whole file, so a file with several arms
# has several candidates to produce the record. Without the arm name, any arm in
# that file could emit PIN-SITE-RED for a site the declared arm never observed,
# and both directions would report pinned — the attribution hole one level up
# from the prose matching this protocol replaced.
#   Any other nonzero exit is UNPROTOCOLED-RED: a real failure that this checker
#   declines to credit to this site.
#
# Opt-in by declaration, under arm-inventory's ruling: a repo-wide manifest for
# 130+ files is churn people learn to update mechanically, which is how a
# manifest stops meaning anything.
#
# THE FAMILY OF MISTAKES THIS FILE KEEPS MAKING, named once so the next one is
# recognisable: THE CHECKER MISTAKING ITS OWN CONTEXT FOR ITS SUBJECT. It read
# its own header examples as declarations. It mutated inside a plain copy, where
# arms failed for want of a repository rather than because of the mutation. It
# scanned forward for "the next predicate-looking thing" instead of the line it
# was pointed at. Three different clothes, one failure — and every one of them
# produces a result that LOOKS like a verdict about the tree. When adding to this
# file, ask what belongs to the checker and what belongs to the subject; that
# question is where its bugs live.
#
# usage: pin-check.sh [--root <dir>] [--file <path>]
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
ONLY_FILE=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --root) ROOT="${2:?--root needs a path}"; shift 2 ;;
    --file) ONLY_FILE="${2:?--file needs a path}"; shift 2 ;;
    -h|--help) sed -n '1,70p' "$0"; exit 0 ;;
    *) echo "pin-check: unexpected arg '$1'" >&2; exit 64 ;;
  esac
done

ROOT="$(cd "$ROOT" 2>/dev/null && pwd -P)" || { echo "pin-check: --root does not exist" >&2; exit 64; }

# NORMALIZE AND VALIDATE AN EXPLICIT TARGET. `--file` compares against the
# repo-relative path the scan emits, so an absolute, `./`-prefixed, or simply
# misspelled spelling matched nothing and the run exited 0 having checked
# nothing — "I found nothing to check" reported as success is instance one of
# this checker's own class, and a nonexistent path scoring clean is the
# /smoke/-string trap in different clothes.
if [ -n "$ONLY_FILE" ]; then
  case "$ONLY_FILE" in
    "$ROOT"/*) ONLY_FILE="${ONLY_FILE#"$ROOT"/}" ;;
    ./*)       ONLY_FILE="${ONLY_FILE#./}" ;;
  esac
  [ -f "$ROOT/$ONLY_FILE" ] || { echo "pin-check: --file '$ONLY_FILE' does not exist under $ROOT" >&2; exit 64; }
fi

# REFUSE A DIRTY SOURCE TREE. The mutant is built from the working-tree file;
# the baseline worktree is built from HEAD. With uncommitted edits in the subject
# those are two different programs, so an unrelated dirty edit can make the
# mutant arm emit the protocol record while the older baseline stays green — a
# `pinned` verdict caused by the edit rather than by the predicate substitution.
# Refusing is the honest fix: the alternative is snapshotting the working tree
# into the baseline, which makes the checker's answer depend on state no reader
# of the commit can reconstruct.
if [ -n "$(git -C "$ROOT" status --porcelain 2>/dev/null)" ]; then
  echo "pin-check: REFUSED — $ROOT has uncommitted changes. The mutant is built from the working tree and the baseline from HEAD, so a dirty subject can produce a 'pinned' verdict caused by the edit rather than the mutation. Commit or stash first." >&2
  exit 1
fi

PIN_RED_EXIT=91
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
rc=0
declared=0; pinned=0; invalid=0; unpinned=0

say() { printf 'pin-check: %s\n' "$1"; }

# Find every arm label `(name)` across BOTH suite buckets. AGENTS.md's documented
# trap: several sweepers keyed exemptions on the literal string /smoke/, so a
# fixture moved to regress/ silently un-sanctioned itself. Match the directory.
arm_files() {
  find "$ROOT/skills" -type d \( -name smoke -o -name regress \) -prune -exec find {} -name '*.test.sh' \; 2>/dev/null
}

# run_arm <arm-label> <mutated-root> -> prints the arm's combined output; rc = arm's rc
# The label is used VERBATIM, parentheses included, because that is the identity
# arm-inventory.test.sh already enforces and the spelling the arm prints. Wrapping
# it here would mean the declaration and the file disagree about what an arm is
# called, and the checker would report "no such arm" for arms that exist.
run_arm() {
  local label="$1" mroot="$2" f
  while IFS= read -r f; do
    grep -qF "$label" "$f" || continue
    local rel="${f#"$ROOT"/}"
    ( cd "$mroot" && bash "$mroot/$rel" ) 2>&1
    return $?
  done < <(arm_files)
  echo "pin-check: no suite file contains an arm labelled ($label)" >&2
  return 127
}

# The predicate must be shape A: `<expr> || <action>`. Anything else is reported
# as mutation-invalid rather than guessed at — a checker that cannot locate what
# it mutates has not verified anything, and guessing here is how the operator
# itself becomes the defect.
# THE PREDICATE IS THE LINE IMMEDIATELY BELOW THE DECLARATION — no scanning
# forward past blanks or comments. A checker that hunts for "the next thing that
# looks like a predicate" will eventually mutate something the author did not
# declare, and report the result under the declared id. Strict adjacency makes
# the subject unambiguous, and a declaration that has drifted off its predicate
# is reported as mutation-invalid rather than silently re-aimed.
mutate_line() { # <file> <declaration-lineno> <pass|fail> <outfile>
  local file="$1" ln="$(( $2 + 1 ))" dir="$3" out="$4" line const
  line="$(sed -n "${ln}p" "$file")"
  case "$line" in
    *'||'*) : ;;
    *) return 3 ;;
  esac
  [ "$dir" = pass ] && const=true || const=false
  awk -v n="$ln" -v c="$const" 'NR==n{
      i = index($0, "||")
      lead = $0; sub(/[^ \t].*/, "", lead)
      print lead c " " substr($0, i)
      next
    } {print}' "$file" > "$out"
}

while IFS= read -r decl; do
  file="${decl%%:*}"; rest="${decl#*:}"; lineno="${rest%%:*}"; text="${rest#*:}"
  [ -z "$ONLY_FILE" ] || [ "$file" = "$ONLY_FILE" ] || continue
  spec="${text#*\# PINS:}"
  id="$(printf '%s' "$spec" | awk '{print $1}')"
  declared=$((declared + 1))

  for dir in pass fail; do
    # FIELD ORDER IS FIXED: pass-> then fail->. An n/a reason is free prose and
    # can contain anything, so the parse cannot be a token scan — the first
    # implementation used one and swallowed the whole rest of the line into the
    # arm name, then reported DECLARED-BUT-UNPINNED because no file contains an
    # arm by that (absurd) name. It failed closed, which is the right direction,
    # but it failed for a reason that had nothing to do with the tree.
    if [ "$dir" = pass ]; then
      case "$spec" in *'pass->'*) claim="${spec#*pass->}" ;; *) claim="" ;; esac
      case "$claim" in *' fail->'*) claim="${claim%% fail->*}" ;; esac
    else
      case "$spec" in *'fail->'*) claim="${spec#*fail->}" ;; *) claim="" ;; esac
    fi
    claim="$(printf '%s' "$claim" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
    if [ -z "$claim" ]; then
      say "DECLARED-BUT-UNPINNED $id ($file:$lineno) — no '$dir->' direction declared; every direction must name an arm or an n/a with a reason"
      unpinned=$((unpinned + 1)); rc=1; continue
    fi
    case "$claim" in
      n/a*)
        # RULED OUT, not merely discouraged. See the header: no parser can
        # validate a rationale's truth, so a reason field checked for presence
        # is an escape hatch with a comment attached. A direction with no
        # runnable arm is UNPINNED, visibly, and the run fails.
        say "WAIVED/UNPINNED $id [$dir] ($file:$lineno) — cites n/a; both directions must name a runnable arm. If this direction genuinely has no defined behavior, that is a claim for review, not a value this checker can accept"
        unpinned=$((unpinned + 1)); rc=1; continue ;;
    esac

    mroot="$WORK/$id.$dir"
    git -C "$ROOT" worktree add --detach -q "$mroot" HEAD 2>/dev/null || {
      say "MUTATION-INVALID $id [$dir] — could not create a scratch worktree; NOT tested"
      invalid=$((invalid + 1)); rc=1; continue
    }
    if ! mutate_line "$ROOT/$file" "$lineno" "$dir" "$mroot/$file"; then
      git -C "$ROOT" worktree remove --force "$mroot" >/dev/null 2>&1 || true
      say "MUTATION-INVALID $id [$dir] ($file:$lineno) — predicate is not the supported '<expr> || <action>' shape; this direction was NOT tested"
      invalid=$((invalid + 1)); rc=1; continue
    fi
    if ! bash -n "$mroot/$file" 2>/dev/null; then
      git -C "$ROOT" worktree remove --force "$mroot" >/dev/null 2>&1 || true
      say "MUTATION-INVALID $id [$dir] ($file:$lineno) — mutant does not parse; a red here would be a syntax error, not an arm. NOT tested"
      invalid=$((invalid + 1)); rc=1; continue
    fi

    # BASELINE FIRST. A cited arm that is already red proves nothing about any
    # mutation -- every mutant would "red" and every direction would score
    # pinned. Run it unmutated, in a clean scratch worktree, before scoring.
    broot="$WORK/$id.$dir.base"
    if ! git -C "$ROOT" worktree add --detach -q "$broot" HEAD 2>/dev/null; then
      git -C "$ROOT" worktree remove --force "$mroot" >/dev/null 2>&1 || true
      say "MUTATION-INVALID $id [$dir] — could not create a baseline worktree; NOT tested"
      invalid=$((invalid + 1)); rc=1; continue
    fi
    set +e
    run_arm "$claim" "$broot" >/dev/null 2>&1; brc=$?
    set -e
    git -C "$ROOT" worktree remove --force "$broot" >/dev/null 2>&1 || true
    if [ "$brc" != 0 ]; then
      git -C "$ROOT" worktree remove --force "$mroot" >/dev/null 2>&1 || true
      say "BASELINE-NOT-GREEN $id [$dir] — arm ($claim) exits $brc UNMUTATED; a red it produces anyway cannot be credited to this site"
      unpinned=$((unpinned + 1)); rc=1; continue
    fi

    set +e
    out="$(run_arm "$claim" "$mroot")"; arc=$?
    set -e
    git -C "$ROOT" worktree remove --force "$mroot" >/dev/null 2>&1 || true
    if [ "$arc" = 127 ]; then
      say "DECLARED-BUT-UNPINNED $id [$dir] — cites arm ($claim), which no suite file contains"
      unpinned=$((unpinned + 1)); rc=1; continue
    fi
    if [ "$arc" = 0 ]; then
      # A mutant arm that exits 0 having printed NOTHING also lands here. That is
      # safe only because green means UNPINNED at this branch -- a refusal, never
      # an admission. Reuse this scorer where green is an admission and the hole
      # comes with it (tap-xzu6 Slice 1 closes it at the suite level).
      say "DECLARED-BUT-UNPINNED $id [$dir] ($file:$lineno) — arm ($claim) stayed GREEN with the predicate forced $dir"
      unpinned=$((unpinned + 1)); rc=1; continue
    fi
    # THE PROTOCOL, NOT PROSE MATCHING. Substring-anywhere scoring credited a red
    # to a site that did not cause it: a probe printed the id in an earlier
    # banner, the mutant then died of an unrelated downstream failure with exit
    # 42, and the first cut reported `pinned`. Requiring a reserved exit code AND
    # an exact final machine record makes the ARM state which site and direction
    # it is reporting, instead of leaving the checker to infer it from prose.
    #
    # This proves conformance to the protocol. It does NOT prove causality, and
    # nothing reading combined output can. That ceiling is the honest limit of
    # this tool; it is stated here and in the doc rather than implied away.
    last="$(printf '%s' "$out" | tail -n 1)"
    if [ "$arc" = "$PIN_RED_EXIT" ] && [ "$last" = "PIN-SITE-RED:$claim:$id:$dir" ]; then
      say "pinned $id [$dir] — arm ($claim) reported PIN-SITE-RED for this site and direction"
      pinned=$((pinned + 1))
    else
      say "UNPROTOCOLED-RED $id [$dir] ($file:$lineno) — arm ($claim) exited $arc with final line '$last'; expected exit $PIN_RED_EXIT and 'PIN-SITE-RED:$claim:$id:$dir'. A real failure, declined rather than credited to this site"
      unpinned=$((unpinned + 1)); rc=1
    fi
  done
# ANCHORED TO THE LINE START (after indentation only). A real declaration sits at
# the head of its own line, indented to the code it guards. The examples in this
# file's own header are nested inside a comment block, so they begin with '#' and
# not with whitespace — anchoring here is what stops this checker from reading its
# own documentation as declarations. arm-inventory.test.sh hit the same trap and
# solved it by printf-generating its synthetic markers; anchoring is the cheaper
# form of the same fix, and it cost a self-scan to notice.
done < <(grep -rn -E '^[[:space:]]*# PINS:' --include='*.sh' "$ROOT/skills" 2>/dev/null | sed "s#^$ROOT/##")

say "declared=$declared pinned=$pinned declared-but-unpinned=$unpinned mutation-invalid=$invalid"
# A RUN THAT FOUND NOTHING TO CHECK MUST NOT REPORT SUCCESS. Deleting the sole
# declaration made both a global run and an explicit --file exit 0 with
# declared=0 — a checker greening on "there was nothing here" is instance one of
# its own class, and the same shape as a sweep whose zero hits read as a clean
# result.
if [ "$declared" = 0 ]; then
  if [ -n "$ONLY_FILE" ]; then
    say "REFUSED — '$ONLY_FILE' carries no '# PINS:' declaration; nothing was checked, and that is not a pass"
  else
    say "REFUSED — no '# PINS:' declarations found anywhere under $ROOT; nothing was checked, and that is not a pass"
  fi
  exit 1
fi
exit "$rc"
