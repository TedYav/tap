"""Exact detached resume adapter; run through session-pytest.test.sh only."""
import contextlib
import copy
import json

import pytest

import launcher


@pytest.fixture
def retained(tmp_path, monkeypatch):
    root = str(tmp_path)
    row = {
        "status": "suspended", "status_reason": "session_stopped",
        "session": "team/legacy-vessel", "harness": "codex",
        "harness_session_id": "native-id", "instance": "retained-instance",
        "registered_from_worktree": root, "model": "stored-model",
        "passthrough": ["-c", 'model_reasoning_effort="high"'],
        "harness_env": {"CODEX_HOME": "/isolated-account"},
    }
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(launcher, "root_for_cwd", lambda cwd: root)
    monkeypatch.setattr(launcher, "_refuse_if_flip_authority", lambda *a, **kw: None)
    monkeypatch.setattr(launcher.registry_v20, "enrolled_team_name_for_root", lambda root: ("ok", "team"))
    monkeypatch.setattr(launcher, "refuse_if_team_reset_fenced", lambda *a, **kw: None)
    monkeypatch.setattr(launcher, "reset_fence_mutation_lock", lambda *a, **kw: contextlib.nullcontext())
    monkeypatch.setattr(launcher, "mark_reset_generation_reused", lambda *a: None)
    return root, row


def test_up_replays_stored_configuration_and_exact_roster_key(retained, monkeypatch, capsys):
    root, row = retained
    row.update(tag="old-tag", index=7)
    calls = []
    monkeypatch.setattr(launcher, "prepare_launch_transaction", lambda rec, at, **kw: calls.append((rec, kw)))
    monkeypatch.setattr(launcher, "run_record_detached", lambda action, rec, dry, **kw: calls.append((action, rec, dry, kw)) or 0)
    monkeypatch.setattr(launcher, "resume_attach_tail", lambda *a: pytest.fail("must not attach"))
    assert launcher.internal_seat_up([root, "team", "seat", json.dumps(row), root + "/registry.json"]) == 0
    rec, claim = calls[0]
    assert launcher.session_handle(rec) == "seat"
    assert rec.name == "team/legacy-vessel"
    assert rec.model == row["model"]
    assert rec.harness_passthrough == row["passthrough"]
    assert rec.harness_env == row["harness_env"]
    assert claim["expected_resume_row"] == row
    assert calls[1][0::2] == ("resume", False)
    assert calls[1][3] == {"resume_identity": "native-id", "creation_guard": True}
    assert json.loads(capsys.readouterr().out)["outcome"] == "resumed"


@pytest.mark.parametrize("change", ["missing-native", "removed", "crew", "poll", "hermes"])
def test_up_refuses_nonexact_or_nonretained_seats_before_claim(retained, monkeypatch, change):
    root, row = retained
    if change == "missing-native":
        row.pop("harness_session_id")
    elif change == "removed":
        row["status_reason"] = "user_removed"
    elif change == "crew":
        row["crew"] = True
    elif change == "poll":
        row["delivery"] = "poll"
    else:
        row["harness"] = "hermes"
    monkeypatch.setattr(launcher, "prepare_launch_transaction", lambda *a, **kw: pytest.fail("must not claim"))
    with pytest.raises(launcher.LauncherError):
        launcher.internal_seat_up([root, "team", "seat", json.dumps(row), root + "/registry.json"])


@pytest.mark.parametrize("field,value", [
    ("instance", "replacement"), ("harness_session_id", "other-id"),
    ("passthrough", ["--different"]), ("status_reason", "user_removed"),
])
def test_claim_rechecks_selected_row_under_lock_before_write(retained, tmp_path, monkeypatch, field, value):
    root, expected = retained
    current = copy.deepcopy(expected)
    current[field] = value
    registry = tmp_path / "registry.json"
    registry.write_text(json.dumps({"team": {"name": "team"}, "seats": {"seat": current}}))
    before = registry.read_bytes()
    monkeypatch.setattr(launcher, "writable_tap_registry_path", lambda root: registry)
    monkeypatch.setattr(launcher, "tmux_sessions_for_namespace", lambda: pytest.fail("row mismatch must precede effects"))
    record = launcher.session_record_from_registry_row("seat", expected, {"name": "team"}, root)
    with pytest.raises(launcher.LauncherError, match="changed before resume"):
        launcher.claim_pending_handle(record, allow_same_session=True,
                                      expected_resume_row=expected, expected_team="team", expected_registry=str(registry.resolve()))
    assert registry.read_bytes() == before
    assert record.launch_id is None


def test_claim_refuses_concurrent_live_vessel_without_replacement(retained, tmp_path, monkeypatch):
    root, expected = retained
    registry = tmp_path / "registry.json"
    registry.write_text(json.dumps({"team": {"name": "team"}, "seats": {"seat": expected}}))
    before = registry.read_bytes()
    monkeypatch.setattr(launcher, "writable_tap_registry_path", lambda root: registry)
    monkeypatch.setattr(launcher, "tmux_sessions_for_namespace", lambda: {expected["session"]})
    record = launcher.session_record_from_registry_row("seat", expected, {"name": "team"}, root)
    with pytest.raises(launcher.LauncherError, match="session appeared"):
        launcher.claim_pending_handle(record, allow_same_session=True,
                                      expected_resume_row=expected, expected_team="team", expected_registry=str(registry.resolve()))
    assert registry.read_bytes() == before
    assert record.launch_id is None


@pytest.mark.parametrize("harness", ["claude", "codex"])
def test_detached_exact_identity_never_reenters_fallback(harness, monkeypatch):
    record = launcher.SessionRecord(name="team/seat", harness=harness, cwd="/scratch", base="team",
                                    harness_session_id="exact-id")
    monkeypatch.setattr(launcher, "resolved_resume_identity", lambda *a, **kw: pytest.fail("must not resolve a fallback"))
    monkeypatch.setattr(launcher, "compose_child_invocation", lambda invocation, *a, **kw: invocation)
    seen = []
    monkeypatch.setattr(launcher, "run_invocation", lambda *a, **kw: seen.append((a, kw)) or 0)
    assert launcher.run_record_detached("resume", record, False, resume_identity="exact-id") == 0
    assert "exact-id" in seen[0][0][1].argv
    assert seen[0][1]["attach"] is False


def test_up_rolls_back_its_claim_when_detached_launch_fails(retained, monkeypatch):
    root, row = retained
    def claim(record, *a, **kw):
        record.launch_id = "owned-claim"
    def fail(*a, **kw):
        raise launcher.LauncherError("harness did not start")
    rolled_back = []
    monkeypatch.setattr(launcher, "prepare_launch_transaction", claim)
    monkeypatch.setattr(launcher, "run_record_detached", fail)
    monkeypatch.setattr(launcher, "rollback_launch_transaction", lambda rec, reason: rolled_back.append((rec.launch_id, reason)))
    with pytest.raises(launcher.LauncherError, match="did not start"):
        launcher.internal_seat_up([root, "team", "seat", json.dumps(row), root + "/registry.json"])
    assert rolled_back == [("owned-claim", "repair_failed")]


def test_claim_refuses_relocated_registry_even_with_an_identical_row(retained, tmp_path, monkeypatch):
    root, expected = retained
    registry = tmp_path / "registry.json"
    relocated = tmp_path / "relocated.json"
    raw = json.dumps({"team": {"name": "team"}, "seats": {"seat": expected}})
    registry.write_text(raw)
    relocated.write_text(raw)
    paths = iter([registry, relocated])
    monkeypatch.setattr(launcher, "writable_tap_registry_path", lambda root: next(paths))
    monkeypatch.setattr(launcher, "tmux_sessions_for_namespace", lambda: pytest.fail("must refuse before tmux"))
    record = launcher.session_record_from_registry_row("seat", expected, {"name": "team"}, root)
    with pytest.raises(launcher.LauncherError, match="selected registry changed"):
        launcher.claim_pending_handle(record, allow_same_session=True,
                                      expected_resume_row=expected, expected_team="team", expected_registry=str(registry.resolve()))
    assert registry.read_text() == raw
    assert relocated.read_text() == raw
    assert record.launch_id is None
