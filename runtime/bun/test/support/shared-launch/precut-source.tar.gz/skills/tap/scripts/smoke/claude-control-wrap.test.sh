#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
. "$ROOT/skills/tap/scripts/smoke/sandbox-pins.sh"
. "$ROOT/skills/tap/scripts/lib.sh"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
FIX="$ROOT/skills/tap/scripts/smoke/fixtures/submit-verify"
wanted="$(cat "$FIX/claude-control-wrap-expected.txt")"
tap_capture_pane() {
  if [ -f "$WORK/entered" ]; then printf '─────────────────────────────────────────────────────────────────────\n❯ \n─────────────────────────────────────────────────────────────────────\n'; else cat "$capture_file"; fi
}
tap_submit_identity_guard() { return 0; }
tap_settle() { :; }
tmux() { case "$*" in send-keys*) echo enter >> "$WORK/keys"; : > "$WORK/entered" ;; esac; }
for mode in joined physical; do
  capture_file="$FIX/claude-control-wrap-$mode.ansi"
  rm -f "$WORK/entered"; : > "$WORK/keys"
  tap_submit_enter_ready fixture claude "$wanted" 8f3a1c2d 0 0
  tap_submit_existing_verify fixture claude 8f3a1c2d 0 id '' '' '' 6 '' '' "$wanted"
  [ "$(wc -l < "$WORK/keys" | tr -d ' ')" = 1 ] || { echo "claude-control-wrap: $mode did not receive exactly one Enter"; exit 1; }
done
python3 - "$FIX/claude-control-wrap-joined.ansi" "$WORK" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text();w=Path(sys.argv[2])
(w/'altered').write_text(s.replace('never marks read','ever marks read'))
(w/'spacing').write_text(s.replace('preserve the','preservethe'))
(w/'blank').write_text(s.replace('  tmp/self-', '\n  tmp/self-'))
PY
for kind in altered spacing blank; do
  capture_file="$WORK/$kind"; rm -f "$WORK/entered"; : > "$WORK/keys"
  rc=0; tap_submit_existing_verify fixture claude 8f3a1c2d 0 id '' '' '' 6 '' '' "$wanted" > "$WORK/$kind.out" 2>&1 || rc=$?
  [ "$rc" = 5 ] && [ ! -s "$WORK/keys" ] || { echo "claude-control-wrap: $kind did not refuse before Enter"; exit 1; }
done
echo 'claude-control-wrap: both saved frames submit once; changed draft, spacing and blank row refuse: ok'
