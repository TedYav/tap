"""Read-only resume preparation and the existing guarded replacement transaction.

Bun owns selection and presentation. This private stdin protocol is never a new
launch authority: relaunch_one rechecks the census identity under its fences.
"""
import os
import tempfile
import json
import pathlib
import sys
import time

import launcher


def run(request):
    if request['op'] == 'context':
        root = launcher.root_for_cwd(str(pathlib.Path.cwd().resolve()))
        status, team = launcher.registry_v20.enrolled_team_name_for_root(root)
        return {'team': team if status == 'ok' else None,
                'caller_pane': launcher.resolve_caller_pane_id()}
    if request['op'] == 'prepare':
        prepared = []
        for member in request['members']:
            try:
                record = launcher.session_record_from_registry_row(
                    member['handle'], member['row'], member['team_doc'], member['root'])
                prepared.append({**member,
                    'expect': launcher.relaunch_identity(member['row']),
                    'expect_resume': launcher.resolved_resume_identity(record, emit_receipts=False)
                                     if record is not None else None})
            except Exception as exc:
                prepared.append({**member, 'prepare_error': f'{type(exc).__name__}: {exc}'})
        return {'members': prepared}
    if request['op'] == 'run':
        member = request['member']
        rc = launcher.relaunch_one(
            member['team'] + '/' + member['handle'], request.get('message'),
            request.get('dry_run', False), expect=member['expect'],
            expect_resume=member['expect_resume'], overrides=request.get('overrides'))
        return {'code': rc}
    raise ValueError('unknown relaunch bridge operation')


if __name__ == '__main__':
    request = json.load(sys.stdin)
    started = time.monotonic()
    # Capture subprocess output too: redirect_stdout alone leaves inherited fd 1
    # untouched and a tmux diagnostic would corrupt the worker JSON protocol.
    with tempfile.TemporaryFile(mode='w+') as output, tempfile.TemporaryFile(mode='w+') as errors:
        saved = (os.dup(1), os.dup(2))
        try:
            os.dup2(output.fileno(), 1)
            os.dup2(errors.fileno(), 2)
            try:
                result = run(request)
            except (launcher.LauncherError, SystemExit) as exc:
                result = {'code': 2, 'reason': str(exc)}
            except Exception as exc:
                result = {'code': 1, 'reason': f'{type(exc).__name__}: {exc}'}
        finally:
            sys.stdout.flush()
            sys.stderr.flush()
            os.dup2(saved[0], 1)
            os.dup2(saved[1], 2)
            os.close(saved[0])
            os.close(saved[1])
        output.seek(0)
        errors.seek(0)
        print(json.dumps({**result, 'stdout': output.read(), 'stderr': errors.read(),
                          'elapsed': time.monotonic() - started}))
