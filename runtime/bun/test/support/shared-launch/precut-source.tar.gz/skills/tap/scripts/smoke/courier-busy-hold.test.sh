#!/usr/bin/env bash
# tap-o4ae: fixture env (TMUX=/fake/socket, a fake tmux on PATH) must stay in this
# process. Refuse `source` so an interactive shell cannot inherit top-level exports.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
# courier-busy-hold.test.sh — tap-92v3r U2. A placed payload to a seat that is
# demonstrably THERE is never reported as undeliverable.
#
# THE INCIDENT. 2026-09-03 07:11:20Z, a payload to tap/gemini-roster-runner — a live
# seat, mid-tool-loop, doing exactly what a working driver does. One deferred attempt,
# then five minutes of silence, then at 07:16:24Z a courier notice to the sender:
#
#     DELIVERY FAILED ... the courier stopped trying.
#     Re-send, route it another way, or drop it. It will not arrive on its own.
#
# It arrived on its own at 07:23:27Z and the recipient acted on it. The sentence was
# false, and it is worse than false: it instructs the sender to re-send, and a sender
# who obeys manufactures a duplicate for a recipient who will read the original. That
# is the retry-after-possible-effect class, produced by the courier's own notice.
#
# WHAT THIS FILE PINS: a busy live pane holds instead of terminalizing, the SAME
# untouched entry delivers exactly once when the band frees, and none of the
# neighbouring lifetimes moved.
#
# THREE FALSE-GREENS THIS FILE IS BUILT AGAINST, because each one would let a broken
# hold look like a working one:
#
#  (a) Proving the hold by observing a surviving spool file. `tap_spool_mark_escalated`
#      is one-way and later drains skip escalated entries, so "the file is still there"
#      is equally true of a working hold and of a zombie nothing will ever touch again.
#      Arm 2 therefore requires DELIVERY from the held entry, not survival of it.
#  (b) Proving delivery with a fresh entry. A hold that dropped the original and
#      re-parked a copy would pass a delivery check; arm 2 asserts the body arrives
#      canonical at the ORIGINAL id with no `.cancelled` receipt anywhere.
#  (c) Reading a green run as "the hold fired" when the deadline never elapsed. Arm 1
#      drives time past `deadline_epoch` explicitly and arm 5 shows the same fixture
#      DOES terminalize when the pane is gone — so a hold that simply never
#      terminalizes anything cannot pass this file.
set -euo pipefail
export TAP_TUI_SETTLE_SCALE=0.1
# The drain must be the only flush this fixture cannot see coming: no opportunistic
# drain riding a send, no detached deliverer racing an assertion. Without this, arm 2
# passed on two runs in three — a park-time deliverer was sometimes delivering h1
# before the arm looked, and sometimes holding its claim while the arm's own drain
# tried to. An intermittently-green hold arm is worse than a red one: it reads as
# "the hold works" on the run you happen to look at.
export TAP_SPOOL_DISABLE_DELIVERER=1
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
LIB="$ROOT/skills/tap/scripts/lib.sh"
TAPSH="$ROOT/skills/tap/scripts/tap.sh"
WORK="$(mktemp -d)"; FAKE_BIN="$(mktemp -d)"
trap 'rm -rf "$WORK" "$FAKE_BIN"' EXIT

# Fake tmux, taken VERBATIM from courier-auto-settle.test.sh rather than rewritten.
# A hand-rolled version was tried first and every send refused with
# server_epoch_unobservable: it lacked `list-sessions` and the format-glob
# discriminators the identity check reads. Copying the proven one keeps this file's
# subject the hold policy instead of the fixture. If it drifts from its source, the
# arms below start failing on identity rather than on delivery, which is loud.
cat > "$FAKE_BIN/tmux" <<'TMUX'
#!/usr/bin/env bash
set -euo pipefail
state="${FAKE_TMUX_STATE:?}"; mkdir -p "$state"
cmd="$1"; shift
# Native submit targets immutable pane ids; resolve them to the same fake pane.
args=()
for arg in "$@"; do
  case "$arg" in %401) arg=sess:0.0 ;; %402) arg=sess:0.1 ;; %403) arg=sess:0.2 ;; esac
  args+=("$arg")
done
set -- "${args[@]}"
case "$cmd" in
  list-sessions) printf 'sess\t4242:100\n' ;;
  list-panes)
    printf 'sess\tsess:0.0\t%%401\t%s\t5001\t4242:100\n' "${FAKE_TMUX_CMD:-codex}"
    printf 'sess\tsess:0.1\t%%402\tcodex\t5002\t4242:100\n'
    printf 'sess\tsess:0.2\t%%403\tcodex\t5003\t4242:100\n'
    ;;
  display-message)
    fmt="${@: -1}"
    # Pane identity is per-TARGET: a fixture that answers one id for every pane
    # cannot exercise a send BACK to the sender (identity_mismatch on every reply).
    target=""; argv=("$@")
    for ((i=0; i<${#argv[@]}; i++)); do [ "${argv[$i]}" = "-t" ] && target="${argv[$((i+1))]}"; done
    case "$target" in
      sess:0.1) pid="%402" ;;
      sess:0.2) pid="%403" ;;
      *)        pid="${FAKE_PANE_ID:-%401}" ;;
    esac
    case "$fmt" in
      # The Bash observer's 3-field fmt (tap_pane_observe: pane_id, session_name,
      # pid:start_time) also matches *pid*start_time*, so it must be answered
      # BEFORE the bare server-identity arm or the hard #xxxx gate reads an
      # epoch as the pane id and defers every clobber as unobservable.
      *pane_id*session_name*start_time*) printf '%s\tsess\t4242:100\n' "$pid" ;;
      *pid*start_time*) echo "4242:100" ;;
      # Four-field calling observe (pane_id+pane_tty+session_name+generation). Shorter *pane_id*pane_tty* / *pane_id*session_name* globs also match that string; first match must be this discriminator (tap-316wj / #xxx).
      *pane_id*session_name*pane_pid*pane_current_command*) printf '%s\tsess\t4242\t%s\n' "$pid" "$([ "$pid" = "%402" ] && printf codex || printf '%s' "${FAKE_TMUX_CMD:-codex}")" ;;
      *pane_id*pane_tty*session_name*) printf '%s\t/dev/faketty\tsess\t4242:100\n' "$pid" ;;
      *pane_id*session_name*) printf '%s\tsess\t4242:100\n' "$pid" ;;
      *session_name*)         echo "sess" ;;
      *pane_id*)              echo "$pid" ;;
      *pane_pid*)             echo "4242" ;;
      *pane_in_mode*)         [ -f "$state/copy_mode" ] && echo "1" || echo "0" ;;
      *pane_current_command*) echo "${FAKE_TMUX_CMD:-codex}" ;;
      *pane_current_path*)    echo "${FAKE_WORKTREE:?}" ;;
      *window_activity*)      echo "100" ;;
      *)                      echo "" ;;
    esac ;;
  select-pane) echo "select-pane $*" >> "$state/send-keys.log" ;;
  capture-pane)
    # One line per readiness probe, i.e. one per drain — arm 9 counts these.
    [ -n "${FAKE_TMUX_PROBE_LOG:-}" ] && echo probe >> "$FAKE_TMUX_PROBE_LOG"
    # Busy AND the input band are per-PANE. A single shared input file is not a
    # fidelity detail: it makes one pane's stuck submit look like pending human
    # input on every OTHER pane, so a notice sent to a second seat refuses for a
    # reason no real tmux would produce.
    target=""
    while [ $# -gt 0 ]; do case "$1" in -t) target="$2"; shift 2 ;; *) shift ;; esac; done
    key="${target//[:.\/]/_}"
    # A VERBATIM CAPTURE OVERRIDE, checked first. The synthetic band below is a codex
    # shape; the agy classes this file now covers are distinguished by pane GEOMETRY
    # (rules, band, what renders below it), which no synthetic line reproduces. Arms 17+
    # therefore feed real captured bytes through the same code path a live pane would.
    # Guarded on the file existing, so every earlier arm sees the shapes it always saw.
    if [ -n "$key" ] && [ -f "$state/capture.$key" ]; then cat "$state/capture.$key"; exit 0; fi
    if [ -f "$state/busy" ] || { [ -n "$key" ] && [ -f "$state/busy.$key" ]; }; then
      printf 'model is generating a response...\n'
    elif [ -f "$state/input.$key" ]; then printf '❯ %s\n' "$(cat "$state/input.$key")"
    else printf '❯ \n'; fi ;;
  send-keys)
    echo "$*" >> "$state/send-keys.log"
    key=""
    [ "${1:-}" = "-t" ] && { key="${2//[:.\/]/_}"; shift 2; }
    if [ "${1:-}" = "-X" ] && [ "${2:-}" = "cancel" ]; then
      # A copy-mode the courier cannot exit. Real: a pane scrolled by a human, or one
      # whose cancel loses a race. It is what keeps arm 6's pane in a live non-ready
      # state across the deadline instead of being tidied back to ready.
      [ -f "$state/copy_mode_stuck" ] && exit 1
      rm -f "$state/copy_mode"; exit 0
    fi
    # A pre-effect submit refusal: send-keys fails, nothing lands, no effect occurred.
    # This is what makes arm 6b about the fall-through rather than about a busy pane.
    [ -f "$state/refuse_send" ] && exit 1
    case "${1:-}" in
      -l) shift; [ "${1:-}" = "--" ] && shift; printf '%s' "${1:-}" > "$state/input.$key"; exit 0 ;;
      C-u) rm -f "$state/input.$key"; exit 0 ;;
      Enter)
        # The transaction's own window, opened deliberately: this runs after the
        # digest revalidated its ids and before its post-submit bookkeeping, which
        # is the only place a racing cancel or a failing rewrite can be driven
        # DETERMINISTICALLY rather than hoped for.
        if [ -n "${FAKE_AT_DIGEST_SUBMIT:-}" ] \
           && grep -qE '\[\[TAP v[0-9.]+ (ask|note) [^ ]+( [a-z]+)* digest' "$state/input.$key" 2>/dev/null; then
          bash -c "$FAKE_AT_DIGEST_SUBMIT" || true
        fi
        # Arm (11): the digest doorbell submits but never verifies (rc 5).
        if [ "${FAKE_TMUX_STUCK_DIGEST_SUBMIT:-0}" = 1 ] \
           && grep -qE '\[\[TAP v[0-9.]+ (ask|note) [^ ]+( [a-z]+)* digest' "$state/input.$key" 2>/dev/null; then
          exit 0
        fi
        # Arm (15): ANY submit lands but never clears, so the id stays in the band and
        # tap_submit_verify returns submit-unverified. This drives the rc-5 path through
        # the production code rather than simulating its effects.
        [ -f "$state/stuck_submit" ] && exit 0
        rm -f "$state/input.$key"
        exit 0
        ;;
    esac ;;
esac
TMUX
chmod +x "$FAKE_BIN/tmux"

export PATH="$FAKE_BIN:$PATH" TMUX="/fake/socket" FAKE_TMUX_STATE="$WORK/tmux" \
       FAKE_WORKTREE="$WORK/repo" FAKE_TMUX_CMD="codex" FAKE_PANE_ID="%401"
export TAP_SERVER_EPOCH="srv:4242:100" TAP_BOOT_ID="boot:1"
mkdir -p "$WORK/tmux" "$WORK/repo"

BUS="$WORK/repo/.tap/bus"; mkdir -p "$BUS/payloads" "$BUS/receipts" "$BUS/spool"; export TAP_HOME="$BUS"
write_registry() { cat > "$BUS/registry.json" <<JSON
{ "team": { "name": "t", "worktree_root": "$WORK/repo" },
  "agents": {
    "peer":  { "session": "sess", "pane": "sess:0.0", "pane_id": "%401", "harness": "codex", "status": "active", "server_epoch": "srv:4242:100", "boot_id": "boot:1", "registered_from_worktree": "$WORK/repo" },
    "alice": { "session": "sess", "pane": "sess:0.1", "pane_id": "%402", "harness": "codex", "status": "active", "server_epoch": "srv:4242:100", "boot_id": "boot:1", "registered_from_worktree": "$WORK/repo" }
  } }
JSON
}
write_registry

# The registry's harness must AGREE with what the live pane reports, or the bound-identity
# check drifts to `gone` before any readiness question is asked — which reads as "the seat
# left" and hides whatever the arm was actually testing. Arms that switch FAKE_TMUX_CMD
# call this straight after `reset_bus`, which restores the codex default.
set_peer_harness() { # <harness>
  python3 -B - "$BUS/registry.json" "$1" <<'PY'
import json, sys
path, harness = sys.argv[1], sys.argv[2]
d = json.load(open(path))
d["agents"]["peer"]["harness"] = harness
json.dump(d, open(path, "w"))
PY
}

LOG="$WORK/tmux/send-keys.log"; : > "$LOG"
# shellcheck source=skills/tap/scripts/lib.sh
. "$LIB"
tap_ensure_dirs

fail() { echo "courier-busy-hold: $*" >&2; [ -f "$LOG" ] && cat "$LOG" >&2; exit 1; }
# v0.23 (tap-7r3fn.8): the id is SLOT 3, positional, not an `id=` key, and it may
# carry a `<team>/` bus-locator prefix. Bounded on the right so one id cannot be
# satisfied by a longer id that starts with it.
injected()   { grep -qE "\\[\\[TAP v[0-9.]+ (ask|note) ([A-Za-z0-9][A-Za-z0-9._-]*/)?$1( |:|\\]\\])" "$LOG" 2>/dev/null; }
meta_field() { python3 -B -c 'import json,sys
try: print(json.load(open(sys.argv[1])).get(sys.argv[2]) or "")
except Exception: print("")' "$BUS/spool/$1.meta.json" "$2" 2>/dev/null || true; }
drain() { TAP_SPOOL_NOW="${1:-}" bash -c 'set -euo pipefail; . "$1"; tap_spool_drain_once' _ "$LIB" >/dev/null 2>&1 || true; }
reset_bus() {
  # Prior verified deliveries must not rate-limit the next arm into a window park.
  rm -rf "$BUS/payloads"/*.md "$BUS/receipts"/*.done "$BUS/receipts"/*.cancelled \
         "$BUS/receipts"/*.sent "$BUS/receipts"/*.placed \
         "$BUS/spool"/*.md "$BUS/spool"/*.meta.json* "$BUS/spool"/*.claim \
         "$BUS/spool/digests" "$BUS/delivery" 2>/dev/null || true
  : > "$LOG"
  # The registry is per-arm state too. Arm 5 retires the recipient to prove a departed
  # seat still terminalizes; without this line the next arm parks against a dead row and
  # fails at setup for a reason that has nothing to do with what it tests.
  write_registry
  rm -f "$WORK"/tmux/input.* "$WORK/tmux/busy" "$WORK"/tmux/busy.* "$WORK/tmux/copy_mode" \
        "$WORK/tmux/copy_mode_stuck" "$WORK/tmux/refuse_send" "$WORK"/clear-fence/*.json 2>/dev/null || true
}
# A park of the incident's own class: an ordinary send that found the band busy, which
# is what mints deadline_source=readiness-gate.
park_busy() { # <id>
  touch "$WORK/tmux/busy.sess_0_0"
  # `--wake` IS LOAD-BEARING, and it became so after this file was written. #xxx made a
  # plain `tap send` settle-only by default, which makes it eligible for the courier's
  # auto-settle HOLD — so the same command that used to mint `deadline_source=readiness-gate`
  # started minting `autosettle-hold`, a different lifetime with a different owner and a
  # different terminal rule. `--wake` opts the send out of that hold (§Courier deferred
  # auto-settlement) without interrupting, which is exactly the class this file is about:
  # a message someone is waiting on, parked because the band was busy.
  #
  # The premise assertion below is what caught it. It was written as ordinary
  # setup hygiene and turned out to be the thing that stopped a base change silently
  # re-pointing every arm in this file at a class it does not test — the arms would have
  # kept passing while measuring the wrong lifetime.
  bash "$TAPSH" send peer -m "held body $1" --id "$1" --from alice --wake >"$WORK/send.out" 2>&1 || true
  [ -f "$BUS/spool/$1.md" ] || fail "setup: $1 did not park (fixture premise changed); send said: $(cat "$WORK/send.out")"
  [ "$(meta_field "$1" deadline_source)" = "readiness-gate" ] \
    || { cat "$WORK/send.out" >&2; cat "$BUS/spool/$1.meta.json" >&2;
         fail "setup: $1 did not park as readiness-gate — this file is about that class"; }
}
past_deadline() { echo "$(( $(meta_field "$1" deadline_epoch) + 1 ))"; }

# ---- (1) THE INCIDENT: a busy LIVE pane past its deadline is held, not failed ----
reset_bus
park_busy h1
DEAD="$(past_deadline h1)"
drain "$DEAD"
# v0.23 (tap-7r3fn.8): `kind=` left the wire; delivery-failed is an ENVELOPE field
# now. Read the ids out of slot 3 and ask the payloads -- a stronger question than
# the wire grep, because it confirms the notice that reached the pane IS the
# delivery-failed one rather than that some sentinel carried the string.
_cbh_failed=0
for _cbh_id in $(grep -oE '\[\[TAP v[0-9.]+ (ask|note) [^ ]+' "$LOG" 2>/dev/null | awk '{print $NF}' | sed 's/\]\]$//;s/:$//;s#.*/##'); do
  grep -q '^kind: delivery-failed$' "$BUS/payloads/${_cbh_id}.md" 2>/dev/null && { _cbh_failed=1; break; }
done
[ "$_cbh_failed" = 1 ] \
  && fail "(1) the sender was told a payload to a LIVE, busy seat would never arrive — the tap-92v3r incident, reproduced"
[ ! -f "$BUS/receipts/h1.cancelled" ] \
  || fail "(1) a held entry got a terminal receipt — the sender's queue was cleared for a message still on its way"
[ -f "$BUS/spool/h1.md" ] || fail "(1) the held body left the spool without being delivered"
[ "$(meta_field h1 escalated_at)" = "" ] \
  || fail "(1) the entry was marked escalated — that mark is one-way and later drains skip it, so this is a zombie, not a hold"
echo "courier-busy-hold: (1) a busy live pane past its deadline holds instead of failing: ok"

# ---- (2) …AND THE SAME ENTRY DELIVERS ONCE WHEN THE BAND FREES ------------------
# The arm that makes arm 1 mean something. A surviving spool file proves nothing on
# its own (false-green (a)); this proves the held entry is still WORKED.
rm -f "$WORK/tmux/busy.sess_0_0"
drain "$(( DEAD + 60 ))"
injected h1 || fail "(2) the held entry never delivered after the band freed — arm 1 was holding a zombie"
[ -f "$BUS/payloads/h1.md" ] || fail "(2) delivered body was not canonicalized at its original id"
[ ! -f "$BUS/spool/h1.md" ] || fail "(2) delivered body left in the spool — retry state was not retired"
[ ! -f "$BUS/spool/h1.meta.json" ] || fail "(2) retry metadata survived delivery"
[ ! -f "$BUS/receipts/h1.cancelled" ] \
  || fail "(2) a .cancelled receipt exists for a message that was DELIVERED (false-green (b): a fresh entry delivered while the original was dropped)"
[ "$(grep -cE "\\[\\[TAP v[0-9.]+ (ask|note) ([A-Za-z0-9][A-Za-z0-9._-]*/)?h1( |:|\\]\\])" "$LOG")" = "1" ] \
  || fail "(2) the held entry was injected $(grep -cE "\\[\\[TAP v[0-9.]+ (ask|note) ([A-Za-z0-9][A-Za-z0-9._-]*/)?h1( |:|\\]\\])" "$LOG") times — a hold must not turn into a duplicate wake"
echo "courier-busy-hold: (2) the same held entry delivers exactly once when the band frees: ok"

# ---- (3) NO SENDER NOTICE IS MINTED WHILE AN ENTRY IS HELD ----------------------
# Option (a), and it is a correctness constraint rather than a style choice.
# tap_spool_notify_sender_on_escalate names payloads/<id>.md, and that path exists
# only because terminalize promotes the body immediately after. A "still queued"
# notice followed by a hold hands the sender a pointer to a file that is not there.
reset_bus
park_busy h2
drain "$(past_deadline h2)"
grep -qE 'kind=(delivery-failed|notice)' "$LOG" \
  && fail "(3) a notice was sent about a held entry — no honest notice exists while the body is spool-only"
[ ! -f "$BUS/payloads/h2.md" ] \
  || fail "(3) the held body was promoted to canonical without being delivered"
if grep -rF 'will not arrive' "$BUS/payloads" "$BUS/spool" --include='*.md'; then
  fail "(3) a live held recipient was described as permanent non-delivery"
fi
echo "courier-busy-hold: (3) a held entry mints no sender notice and promotes nothing: ok"

# ---- (4) BUSY-WITH-A-DRAFT: the forced deadline attempt DELIVERS, and backs up ----
# ONE OBSERVABLE CONTRACT, asserted unconditionally. The first version of this arm
# accepted "injected OR still spooled" and only checked the draft backup if injection
# happened, which sol-courier-sponsor correctly held as hiding the behaviour rather
# than describing it: a build that skipped the overdue attempt entirely passed, and so
# did a build that dropped busy:pending from the presence predicate.
#
# The contract this arm now pins, chosen because it is what the code does and what the
# existing deadline design intends: at the deadline `due=1` forces one real redelivery
# even against a busy pane, and for busy:pending that attempt takes the clobber
# pipeline — back up the human's draft, clear the band, inject — and succeeds. So the
# entry DELIVERS. The tap-92v3r property still holds and is asserted beside it: the
# sender is never told a live seat's message will not arrive.
#
# The alternative design — hold a pending-input pane BEFORE the due attempt, leaving
# the draft untouched — is defensible and is NOT what this ships. If it is ever
# adopted, this arm must invert: require continued spool residency and an untouched
# band, not delivery.
reset_bus
park_busy h3
# The draft replaces the busy marker BEFORE the drain, so the pane the drain probes is
# live-with-a-draft rather than generating. Written the other way round first — draft
# added but busy cleared only after the deadline was computed — and the entry simply
# delivered, because for one probe the pane was neither busy nor drafted. The arm was
# describing a state the fixture never entered.
printf 'a human is mid-sentence' > "$WORK/tmux/input.sess_0_0"
rm -f "$WORK/tmux/busy.sess_0_0"
[ "$(tap_spool_pane_ready "sess:0.0" "%401" peer t "$BUS/registry.json" "")" = "busy:pending" ] \
  || fail "(4) fixture premise: the pane is not busy:pending, so this arm would not be about a human draft"
drain "$(past_deadline h3)"
# v0.23 (tap-7r3fn.8): `kind=` left the wire; delivery-failed is an ENVELOPE field
# now. Read the ids out of slot 3 and ask the payloads -- a stronger question than
# the wire grep, because it confirms the notice that reached the pane IS the
# delivery-failed one rather than that some sentinel carried the string.
_cbh_failed=0
for _cbh_id in $(grep -oE '\[\[TAP v[0-9.]+ (ask|note) [^ ]+' "$LOG" 2>/dev/null | awk '{print $NF}' | sed 's/\]\]$//;s/:$//;s#.*/##'); do
  grep -q '^kind: delivery-failed$' "$BUS/payloads/${_cbh_id}.md" 2>/dev/null && { _cbh_failed=1; break; }
done
[ "$_cbh_failed" = 1 ] \
  && fail "(4) a seat holding a human draft was reported undeliverable — it is present, just protected"
[ ! -f "$BUS/receipts/h3.cancelled" ] \
  || fail "(4) a terminal receipt was written for a seat that is present"
injected h3 \
  || fail "(4) the forced deadline attempt did not run against a busy:pending pane — the due gate is what makes this class deliver rather than hold"
[ -f "$BUS/payloads/h3.md" ] || fail "(4) the delivered body was not canonicalized"
[ ! -f "$BUS/spool/h3.md" ] || fail "(4) retry state survived a completed delivery"
# The human's draft is what the clobber pipeline exists to protect, so the retained
# backup is not optional. Asserted as a FILE, not as restored band text: the in-band
# restore goes through tmux load-buffer/paste-buffer, which this fixture's fake does
# not implement, so a band assertion here would be measuring the fake. The retained
# file is the recovery authority the pipeline itself names (`tap draft`).
grep -rq 'a human is mid-sentence' "$BUS/input-backups" 2>/dev/null \
  || fail "(4) the forced deadline attempt clobbered a human draft with no retained backup — the pipeline's whole purpose"
echo "courier-busy-hold: (4) a busy:pending pane takes the forced deadline attempt, delivers, and retains the human's draft: ok"

# ---- (5) A SEAT THAT IS ACTUALLY GONE STILL TERMINALIZES (the discriminator) -----
# Without this, a hold that never terminalizes ANYTHING would pass every arm above
# (false-green (c)). Same fixture, same class, same elapsed deadline — only the
# recipient's presence differs, which is the fact the whole change turns on.
reset_bus
park_busy h4
python3 -B - "$BUS/registry.json" <<'PY' || fail "(5) could not retire the recipient"
import json, sys
reg = json.load(open(sys.argv[1]))
reg["agents"]["peer"]["status"] = "inactive"
json.dump(reg, open(sys.argv[1], "w"))
PY
drain "$(past_deadline h4)"
# v0.23 (tap-7r3fn.8): `kind=` left the wire; delivery-failed is an ENVELOPE field
# now. Read the ids out of slot 3 and ask the payloads -- a stronger question than
# the wire grep, because it confirms the notice that reached the pane IS the
# delivery-failed one rather than that some sentinel carried the string.
_cbh_failed=0
for _cbh_id in $(grep -oE '\[\[TAP v[0-9.]+ (ask|note) [^ ]+' "$LOG" 2>/dev/null | awk '{print $NF}' | sed 's/\]\]$//;s/:$//;s#.*/##'); do
  grep -q '^kind: delivery-failed$' "$BUS/payloads/${_cbh_id}.md" 2>/dev/null && { _cbh_failed=1; break; }
done
[ "$_cbh_failed" = 1 ] \
  || fail "(5) a payload to a seat that LEFT THE ROSTER was held instead of failing — the hold must not swallow real non-delivery"
grep -F 'It will not arrive on its own.' "$BUS/payloads/${_cbh_id}.md" >/dev/null \
  || fail "(5) the gone-seat notice lost its reserved terminal wording"
echo "courier-busy-hold: (5) a departed recipient still terminalizes: ok"

# ---- (6) A LIVE PANE IN ANY NON-TERMINAL STATE HOLDS, not just busy:noprompt ----
# The state-transition case, and the one that broke the first version of this fix.
# tap_spool_pane_ready returns `gone`/`unsafe` BEFORE its bound-identity check and
# every other value AFTER it — so plain `busy` (copy-mode, or a blocked/exempt seat)
# is emitted about a pane whose identity just matched. It is a live seat.
#
# The first predicate was an ALLOWLIST of busy:noprompt and busy:pending, and
# sol-courier-sponsor refuted it with this shape: park an entry while the pane is
# generating, then put the still-bound pane into a copy-mode whose cancel refuses, then
# advance past the deadline. The probe reads `busy`, which the allowlist did not
# contain, and a live pane was told undeliverable. An allowlist has to be re-derived
# every time a busy:* value is added and its failure mode is a false delivery failure;
# the predicate now names the terminal states instead.
#
# THE PANE'S STATE CHANGES BETWEEN PARK AND DEADLINE, deliberately. A fixture that was
# in copy-mode the whole time would park for a different reason and never exercise the
# transition this arm is about.
reset_bus
park_busy h5
rm -f "$WORK/tmux/busy.sess_0_0"
: > "$WORK/tmux/copy_mode"; : > "$WORK/tmux/copy_mode_stuck"
[ "$(tap_spool_pane_ready "sess:0.0" "%401" peer t "$BUS/registry.json" "")" = "busy" ] \
  || fail "(6) fixture premise: the pane does not classify plain 'busy', so this arm is not about the state it claims"
drain "$(past_deadline h5)"
# v0.23 (tap-7r3fn.8): `kind=` left the wire; delivery-failed is an ENVELOPE field
# now. Read the ids out of slot 3 and ask the payloads -- a stronger question than
# the wire grep, because it confirms the notice that reached the pane IS the
# delivery-failed one rather than that some sentinel carried the string.
_cbh_failed=0
for _cbh_id in $(grep -oE '\[\[TAP v[0-9.]+ (ask|note) [^ ]+' "$LOG" 2>/dev/null | awk '{print $NF}' | sed 's/\]\]$//;s/:$//;s#.*/##'); do
  grep -q '^kind: delivery-failed$' "$BUS/payloads/${_cbh_id}.md" 2>/dev/null && { _cbh_failed=1; break; }
done
[ "$_cbh_failed" = 1 ] \
  && fail "(6) a LIVE pane in copy-mode was told its message would never arrive — the allowlist defect"
[ ! -f "$BUS/receipts/h5.cancelled" ] \
  || fail "(6) a terminal receipt was written for a live pane in copy-mode"
[ -f "$BUS/spool/h5.md" ] || fail "(6) the entry left the spool"
rm -f "$WORK/tmux/copy_mode" "$WORK/tmux/copy_mode_stuck"
echo "courier-busy-hold: (6) a live pane in copy-mode holds, not fails (the allowlist-vs-denylist case): ok"

# ---- (6b) A READY PANE WHOSE ATTEMPT FAILED PRE-EFFECT IS NOT TERMINAL ----------
# The fall-through sol-courier-sponsor found, and the reason the first inversion still
# carved out `ready`. Its justification was "a ready pane is delivered to, so the
# caller never reaches here with ready" — and the caller does: the attempt runs, the
# redelivery returns a PRE-EFFECT rc 1 (identity drift, a copy-mode transition, a
# failed sentinel reconstruction, an rc-4 submit defer), and the deadline decision is
# reached with `ready` still in hand. His probe terminalized a positively live pane
# after a failure that had no effect at all.
#
# The fixture drives it the way production does: the pane classifies ready, and the
# submit fails pre-effect because send-keys refuses. No possible effect occurred, so
# nothing may be terminalized.
reset_bus
park_busy h7
rm -f "$WORK/tmux/busy.sess_0_0"
: > "$WORK/tmux/refuse_send"
[ "$(tap_spool_pane_ready "sess:0.0" "%401" peer t "$BUS/registry.json" "")" = "ready" ] \
  || fail "(6b) fixture premise: the pane is not ready, so this arm is not about the ready fall-through"
drain "$(past_deadline h7)"
# v0.23 (tap-7r3fn.8): `kind=` left the wire; delivery-failed is an ENVELOPE field
# now. Read the ids out of slot 3 and ask the payloads -- a stronger question than
# the wire grep, because it confirms the notice that reached the pane IS the
# delivery-failed one rather than that some sentinel carried the string.
_cbh_failed=0
for _cbh_id in $(grep -oE '\[\[TAP v[0-9.]+ (ask|note) [^ ]+' "$LOG" 2>/dev/null | awk '{print $NF}' | sed 's/\]\]$//;s/:$//;s#.*/##'); do
  grep -q '^kind: delivery-failed$' "$BUS/payloads/${_cbh_id}.md" 2>/dev/null && { _cbh_failed=1; break; }
done
[ "$_cbh_failed" = 1 ] \
  && fail "(6b) a READY pane was told its message would never arrive after a pre-effect failure — the ready carve-out"
[ ! -f "$BUS/receipts/h7.cancelled" ] \
  || fail "(6b) a terminal receipt was written after a failure with no effect"
[ -f "$BUS/spool/h7.md" ] || fail "(6b) the entry left the spool"
rm -f "$WORK/tmux/refuse_send"
echo "courier-busy-hold: (6b) a ready pane whose attempt failed pre-effect stays retryable: ok"

# The lifetime controls below hold below an explicit force-probe threshold.
# Default force-after-three behavior is exercised separately in arms 18–20.
# Prove the held state itself so a slower drain cannot make mere PID survival pass.
assert_held_waiter_fixture() { # <id> <private trace directory>
  # A due attempt moves the body to canonical before a busy submit reparks it.
  # Inspect under that attempt's claim so residency is a stable observation.
  # The arms change TAP_HOME after sourcing lib.sh; bind its claim helper locally.
  local TAP_SPOOL="$TAP_HOME/spool" _tries=0 _proof_rc=0
  # A loaded runner may not have completed the waiter's first drain after the
  # fixed sleep. Wait for the asserted state, releasing custody between looks.
  while [ "$_tries" -lt 100 ]; do
    if tap_spool_claim_acquire "$1"; then
      _proof_rc=0
      python3 -B - "$TAP_HOME" "$1" "$TAP_SPOOL_FORCE_PROBES" > "$2/held-proof.log" 2>&1 <<'HELD_FIXTURE' \
        || _proof_rc=$?
import json, pathlib, sys, time
bus, ident, threshold = pathlib.Path(sys.argv[1]), sys.argv[2], int(sys.argv[3])
meta = json.loads((bus / "spool" / f"{ident}.meta.json").read_text())
assert meta["deadline_source"] == "readiness-gate", meta
assert meta["deadline_epoch"] < time.time(), meta
assert 0 < meta.get("busy_live_probes", 0) < threshold, meta
assert (bus / "spool" / f"{ident}.md").is_file(), meta
assert not (bus / "payloads" / f"{ident}.md").exists(), meta
HELD_FIXTURE
      tap_spool_claim_release "$1"
      [ "$_proof_rc" -ne 0 ] || return 0
    fi
    _tries=$((_tries + 1)); command sleep 0.05
  done
  [ ! -f "$2/held-proof.log" ] || cat "$2/held-proof.log" >&2
  [ ! -f "$2/deliver.log" ] || cat "$2/deliver.log" >&2
  fail "held-waiter fixture $1 did not reach its post-deadline, below-force state"
}

# ---- (7) THE REAL DELIVERER DELIVERS A HELD ENTRY, with no test-authored drain ----
# Every arm above disables the deliverer for determinism and drains by hand. That is
# right for testing the POLICY and wrong for testing who carries it out — and the gap
# between those two is where sol-courier-sponsor found this defect. The deliverer's
# deadline branch exists so a park that reached its end terminalizes while a waiter is
# alive to escalate; tap-92v3r changed what "reached its end" means for this class, so
# a waiter that still exits at the deadline retires the only process scheduled to look
# again. His probe ran the real deliverer, let it exit, freed the band, drained
# nothing, and the entry never arrived.
#
# THIS ARM CALLS NO DRAIN AFTER FREEING THE BAND. That absence is the assertion. It
# runs in its own subshell with its own bus so the deliverer it enables cannot outlive
# the arm and race the others.
(
  set -euo pipefail
  unset TAP_SPOOL_DISABLE_DELIVERER
  # A short deadline and a fast cadence: the arm is about ownership across the
  # deadline, not about the 300s production value.
  export TAP_SPOOL_FORCE_PROBES=1000 TAP_SPOOL_BUSY_DEADLINE_SECONDS=1 TAP_SPOOL_DELIVERER_DELAYS="0.2"
  D2="$(mktemp -d)"; mkdir -p "$D2/tmux" "$D2/repo"
  # KILL AUTHORITY COMES FROM THE SPAWN, NEVER FROM A PATTERN (no-pattern-kills).
  #
  # The first version of this arm let the park spawn its own deliverer and then found
  # the pid with `pgrep -f "tap-spool-deliverer.sh h6"`. sol-courier-sponsor held that
  # Critical and he is right: a sandboxed HOME and TAP_HOME do not partition the
  # process table, so that pattern can select — and kill — a deliverer belonging to
  # another focused run, another checkout, or a real user whose payload id happens to
  # be `h6`. It is exactly the incident tap-jptfa records, written by someone who had
  # read the rule and checked their own diff against it an hour earlier.
  #
  # So the park runs with the automatic spawn DISABLED, this arm calls the production
  # spawn helper itself, and `$!` is the only pid it will ever signal.
  _d2pid=""
  cleanup7() {
    if [ -n "$_d2pid" ]; then kill "$_d2pid" 2>/dev/null || true; wait "$_d2pid" 2>/dev/null || true; fi
    # `|| true`, for the same reason arm 8's teardown carries it: the owned waiter is
    # signalled above, but a drain it had already forked can still be writing into
    # $D2 when this runs, and `rm -rf` then exits non-zero on a directory that
    # repopulated under it. Under `set -euo pipefail` that teardown failure IS the
    # file's exit status, so a passing arm reports FAIL.
    #
    # I fixed exactly this in arm 8 when I saw it once under a mutation, and did not
    # grep for the class — so arm 7 kept the bare form and reded the whole file under
    # suite concurrency, after eight green focused runs. Both teardowns now tolerate
    # the race; neither hunts the extra pids by pattern, and they exit on their own
    # when the scratch bus disappears.
    rm -rf "$D2" 2>/dev/null || true
  }
  trap cleanup7 EXIT
  export FAKE_TMUX_STATE="$D2/tmux" FAKE_WORKTREE="$D2/repo"
  BUS2="$D2/repo/.tap/bus"; mkdir -p "$BUS2/payloads" "$BUS2/receipts" "$BUS2/spool"
  export TAP_HOME="$BUS2"
  sed "s|$WORK/repo|$D2/repo|g" "$BUS/registry.json" > "$BUS2/registry.json"
  LOG2="$D2/tmux/send-keys.log"; : > "$LOG2"

  touch "$D2/tmux/busy.sess_0_0"
  # Park with no automatic waiter, so the ONLY deliverer in this arm is the one spawned
  # on the next line and held in $!.
  TAP_SPOOL_DISABLE_DELIVERER=1 bash "$TAPSH" send peer -m "owned hold" --id h6 --from alice --wake >/dev/null 2>&1 || true
  [ -f "$BUS2/spool/h6.md" ] || fail "(7) h6 did not park"

  # The production waiter, started by this arm and owned by it. Spawned through the
  # same script the production helper execs, so the behaviour under test is the real
  # one; what differs is only that we hold its pid.
  nohup env -u TAP_SPOOL_DRAIN_ACTIVE \
    bun "$ROOT/runtime/bun/src/spool-waiter.ts" h6 >>"$D2/deliver.log" 2>&1 &
  _d2pid=$!

  # Let the deadline pass with the pane still busy. Under the pre-fix code the waiter
  # exits here; under the fix it stays because the entry is held rather than terminal.
  _t=0
  while [ "$_t" -lt 60 ]; do
    [ -f "$BUS2/receipts/h6.cancelled" ] && fail "(7) the held entry was terminalized while its recipient was live"
    _t=$((_t + 1))
    command sleep 0.1
  done
  if ! kill -0 "$_d2pid" 2>/dev/null; then
    _waiter_rc=0
    wait "$_d2pid" || _waiter_rc=$?
    printf 'courier-busy-hold: (7) waiter pid=%s exit=%s observed_at=%s\n' \
      "$_d2pid" "$_waiter_rc" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >&2
    cat "$D2/deliver.log" >&2
    for _state in "$BUS2/spool/h6.meta.json" "$BUS2/spool/h6.meta.json.reown"; do
      if [ -f "$_state" ]; then printf '%s\n' "$_state" >&2; cat "$_state" >&2; fi
    done
    fail "(7) the owned waiter exited while the entry remained held"
  fi
  assert_held_waiter_fixture h6 "$D2"

  # Free the band. NOTHING below drains — if the entry arrives, a production owner
  # delivered it.
  rm -f "$D2/tmux/busy.sess_0_0"
  _t=0
  while [ "$_t" -lt 100 ]; do
    grep -qE "\\[\\[TAP v[0-9.]+ (ask|note) ([A-Za-z0-9][A-Za-z0-9._-]*/)?h6( |:|\\]\\])" "$LOG2" 2>/dev/null && break
    _t=$((_t + 1))
    command sleep 0.1
  done
  grep -qE "\\[\\[TAP v[0-9.]+ (ask|note) ([A-Za-z0-9][A-Za-z0-9._-]*/)?h6( |:|\\]\\])" "$LOG2" 2>/dev/null \
    || fail "(7) the band freed and no production owner delivered the held entry — the deliverer exited at the deadline the hold decided to outlive"
  [ -f "$BUS2/payloads/h6.md" ] || fail "(7) delivered body was not canonicalized"
) || exit 1
echo "courier-busy-hold: (7) a production deliverer carries a held entry across its deadline and delivers when the band frees: ok"

# ---- (8) OWNERSHIP: the held entry's owner holds its lease; an escalated one exits --
# Arm 7 proves SOMEBODY delivers; it says nothing about how many processes are trying.
# sol-courier-sponsor measured six owners in three seconds against the round-3 code:
# the surviving waiter kept re-parking, every re-park minted a replacement through
# tap_spool_reown_after_repark, and the population grew for as long as the recipient
# stayed busy. The old design was safe because every waiter was bounded — holding a
# live entry is exactly what removed that premise.
#
# Two assertions, because they are two different failures:
#   cardinality — a waiter that means to outlive its deadline holds the re-own lease,
#                 so re-park finds a live owner and declines to spawn;
#   termination — an ESCALATED entry (custody with a human, every drain skips it) ends
#                 its waiter, which residency-only looping never would.
(
  set -euo pipefail
  unset TAP_SPOOL_DISABLE_DELIVERER
  export TAP_SPOOL_FORCE_PROBES=1000 TAP_SPOOL_BUSY_DEADLINE_SECONDS=1 TAP_SPOOL_DELIVERER_DELAYS="0.2" \
         TAP_SPOOL_REOWN_LEASE_SECONDS=20
  D3="$(mktemp -d)"; mkdir -p "$D3/tmux" "$D3/repo"
  _own=""
  cleanup8() {
    if [ -n "$_own" ]; then kill "$_own" 2>/dev/null || true; wait "$_own" 2>/dev/null || true; fi
    # `|| true`: this arm's whole subject is owner cardinality, so a build where
    # cardinality is BROKEN has untracked owners still writing into $D3 while this
    # runs, and rm -rf loses the race. Observed exactly once, under mutant T. The arm
    # must fail on its assertion, not on a teardown that inherits the defect — and it
    # must not reach for a pattern to find those extra pids (no-pattern-kills). They
    # exit on their own when the scratch bus disappears.
    rm -rf "$D3" 2>/dev/null || true
  }
  trap cleanup8 EXIT
  export FAKE_TMUX_STATE="$D3/tmux" FAKE_WORKTREE="$D3/repo"
  BUS3="$D3/repo/.tap/bus"; mkdir -p "$BUS3/payloads" "$BUS3/receipts" "$BUS3/spool"
  export TAP_HOME="$BUS3"
  sed "s|$WORK/repo|$D3/repo|g" "$BUS/registry.json" > "$BUS3/registry.json"
  : > "$D3/tmux/send-keys.log"

  touch "$D3/tmux/busy.sess_0_0"
  TAP_SPOOL_DISABLE_DELIVERER=1 bash "$TAPSH" send peer -m "one owner" --id h8 --from alice --wake >/dev/null 2>&1 || true
  [ -f "$BUS3/spool/h8.md" ] || fail "(8) h8 did not park"

  # The one owner this arm starts, and the only pid it will signal.
  nohup env -u TAP_SPOOL_DRAIN_ACTIVE \
    bun "$ROOT/runtime/bun/src/spool-waiter.ts" h8 >>"$D3/deliver.log" 2>&1 &
  _own=$!

  # Well past the deadline and several lease lifetimes: if re-park is minting owners,
  # this is where they accumulate.
  _t=0; while [ "$_t" -lt 40 ]; do _t=$((_t + 1)); command sleep 0.1; done

  # FRESHNESS, NOT EXISTENCE. The first version of this assertion checked that the
  # lease FILE was present, and the mutation that deletes the refresh passed it: a
  # lease is created by the first re-park whether or not anybody keeps it alive, so
  # its existence says nothing about ownership. What re-own actually consults is its
  # AGE against TAP_SPOOL_REOWN_LEASE_SECONDS — a stale lease is unlinked and a
  # replacement owner is spawned. So the observable that decides the behaviour is the
  # mtime, and it is what this asserts: after several lease lifetimes of holding, the
  # lease must be younger than one lifetime, which is only true if something is
  # refreshing it.
  #
  # Seconds resolution would be too coarse to tell a refreshed lease from a stale one
  # under a 1s lease, so this reads a float mtime.
  assert_held_waiter_fixture h8 "$D3"
  _age="$(python3 -B -c 'import os,sys,time; print(round(time.time()-os.stat(sys.argv[1]).st_mtime,2))' "$BUS3/spool/h8.meta.json.reown" 2>/dev/null || echo 999)"
  python3 -B -c 'import sys; sys.exit(0 if float(sys.argv[1]) < float(sys.argv[2]) else 1)' "$_age" "$TAP_SPOOL_REOWN_LEASE_SECONDS" \
    || fail "(8) the re-own lease is ${_age}s old against a ${TAP_SPOOL_REOWN_LEASE_SECONDS}s lifetime — nobody is refreshing it, so the next re-park spawns a replacement owner and the population grows"

  # THE COUNT ITSELF IS NOT ASSERTED HERE, AND THAT IS A REPORTED GAP, NOT AN OVERSIGHT.
  #
  # The design review asked for an owner COUNT == 1 alongside the freshness assertion
  # above, by a sandbox-scoped observable, plus a mutant that reds the count while
  # freshness still passes. Both halves were attempted and neither can be delivered
  # from this arm as written:
  #
  #   THE MUTANT CANNOT EXECUTE. The specified mutation — make
  #   `tap_spool_reown_after_repark` spawn regardless of lease freshness — leaves this
  #   scenario green, and not because the assertion is weak: the waiter claims the
  #   lease before its first drain, so re-own's spawning branch is never reached here
  #   at all. A mutation that cannot run is not a survivor; reporting it as one would
  #   misread the code.
  #
  #   THE CENSUS CANNOT BE PROVEN SENSITIVE. A `pgrep`-plus-`ps -E` census counts a
  #   deliverer's command-substitution forks, which carry its argv verbatim; filtering
  #   by parentage improved it (2 became 3 for two real waiters, because `nohup` adds a
  #   level) but did not make it exact. A positive control that starts two real waiters
  #   against a throwaway id could not be made to read 2 — every variant read 0, 3 or
  #   4. An unproven count assertion is worse than none: it would sit here reading 1
  #   forever without anyone knowing whether it CAN read anything else.
  #
  # What IS asserted: the lease freshness above, mutation-proven (delete the refresh ->
  # stale lease -> red), plus the owned pid still alive. That is the mechanism by which
  # cardinality is kept, which is what this code changed. The effect — an exact owner
  # count — needs an observable the waiter itself records, and that is production
  # instrumentation outside this delta's allowed scope. Tracked as tap-7xb5l, whose body
  # carries the three design constraints tonight's failed attempt established.
  kill -0 "$_own" 2>/dev/null || fail "(8) the owner exited while the entry was still held"

  # Termination: escalate the entry by hand (the shape a gone recipient plus an
  # unreachable sender produces) and require the waiter to stop.
  python3 -B - "$BUS3/spool/h8.meta.json" <<'PY'
import json, sys
m = json.load(open(sys.argv[1]))
m["escalated_at"] = "2026-09-03T09:19:39Z"
json.dump(m, open(sys.argv[1], "w"))
PY
  _t=0
  while [ "$_t" -lt 60 ]; do
    kill -0 "$_own" 2>/dev/null || break
    _t=$((_t + 1)); command sleep 0.1
  done
  kill -0 "$_own" 2>/dev/null \
    && fail "(8) the waiter outlived an ESCALATED entry — every drain skips it, so that process can never advance anything"
  _own=""
) || exit 1
echo "courier-busy-hold: (8) a held entry keeps its lease-holding owner alive; an escalated entry keeps none (count itself unasserted — see the arm): ok"

# ---- (9) THE HELD WAITER DOES NOT SPIN (opus6-gate's falsifier, as an arm) --------
# The gate handed me this as "the falsifier, if you think I am wrong": park a
# readiness-gate entry to a present-but-busy pane, let the deadline pass, and count
# drains over a window. A correct cadence shows ~1 per interval; the round-4 code showed
# a spin.
#
# Why it was reachable at all: `delivery_wait` clamps to `max(0, min(delay, min(bounds)
# - now))`, which goes NEGATIVE once now > deadline, so it returns "0.0" — and the
# guard `[ "$wait" = 0 ]` is a STRING comparison that "0.0" does not satisfy, so
# `sleep 0.0` ran and returned instantly. Harmless while every waiter exited at its
# deadline, because no iteration ever ran past that point. Holding made it reachable.
#
# COUNTING PROBES, NOT CPU AND NOT LOG BYTES. A CPU threshold would measure machine
# speed and red on a loaded gate box. Log-size growth — how this arm first shipped —
# measures nothing at all: a deliverer writes nothing to stdout, so the window grew zero
# bytes under BOTH the spin and the fix, and the arm passed under its own mutation.
# Caught by running mutant W rather than by reading the arm.
#
# Every drain probes pane readiness, and the fixture's tmux fake logs one line per
# capture-pane, so probe count IS iteration count.
(
  set -euo pipefail
  unset TAP_SPOOL_DISABLE_DELIVERER
  # A LONG CADENCE IS WHAT MAKES THIS ARM DISCRIMINATING, and it took a measurement to
  # learn that. At a 1s cadence the spin build and the fixed build both probed FOUR
  # times in three seconds — because a drain itself costs ~0.7s, so "sleep 0 and drain
  # again" and "sleep 1 and drain again" look identical. The arm passed under its own
  # mutation for that reason, not because the counter was wrong.
  #
  # At a 30s cadence the two separate completely: a correctly paced waiter probes ZERO
  # more times inside a 3s window past its deadline, while a spinning one keeps going at
  # drain speed. The bound below is therefore small, and the control that the loop ran
  # at all moves BEFORE the window.
  export TAP_SPOOL_FORCE_PROBES=1000 TAP_SPOOL_BUSY_DEADLINE_SECONDS=1 TAP_SPOOL_DELIVERER_DELAYS="30" \
         TAP_SPOOL_REOWN_LEASE_SECONDS=60
  D4="$(mktemp -d)"; mkdir -p "$D4/tmux" "$D4/repo"
  _spin=""
  cleanup9() {
    if [ -n "$_spin" ]; then kill "$_spin" 2>/dev/null || true; wait "$_spin" 2>/dev/null || true; fi
    rm -rf "$D4" 2>/dev/null || true
  }
  trap cleanup9 EXIT
  export FAKE_TMUX_STATE="$D4/tmux" FAKE_WORKTREE="$D4/repo"
  BUS4="$D4/repo/.tap/bus"; mkdir -p "$BUS4/payloads" "$BUS4/receipts" "$BUS4/spool"
  export TAP_HOME="$BUS4"
  sed "s|$WORK/repo|$D4/repo|g" "$BUS/registry.json" > "$BUS4/registry.json"

  touch "$D4/tmux/busy.sess_0_0"
  TAP_SPOOL_DISABLE_DELIVERER=1 bash "$TAPSH" send peer -m "no spin" --id h9 --from alice --wake >/dev/null 2>&1 || true
  [ -f "$BUS4/spool/h9.md" ] || fail "(9) h9 did not park"

  # A tmux fake that records every capture-pane, which is one per readiness probe and
  # therefore a faithful per-drain counter.
  printf '' > "$D4/tmux/probe.log"
  export FAKE_TMUX_PROBE_LOG="$D4/tmux/probe.log"
  nohup env -u TAP_SPOOL_DRAIN_ACTIVE \
    bun "$ROOT/runtime/bun/src/spool-waiter.ts" h9 >>"$D4/spin.log" 2>&1 &
  _spin=$!

  # Well past the deadline, then measure a clean window with the pane still busy.
  command sleep 3
  # The loop must have RUN before the window opens, or a zero count inside it proves
  # nothing. This is the control the first two versions of this arm lacked.
  _ran="$(wc -l < "$D4/tmux/probe.log" | tr -d ' ')"
  [ "$_ran" -gt 0 ] \
    || fail "(9) the waiter made no readiness probe at all before the window — it never entered its loop, so the bound below would measure nothing"
  _before="$_ran"
  command sleep 3
  _after="$(wc -l < "$D4/tmux/probe.log" | tr -d ' ')"
  assert_held_waiter_fixture h9 "$D4"
  _alive=$(kill -0 "$_spin" 2>/dev/null && echo y || echo n)
  kill "$_spin" 2>/dev/null || true; wait "$_spin" 2>/dev/null || true; _spin=""

  # POSITIVE CONTROL ON THE INSTRUMENT, before its bound. A waiter that already exited,
  # or a counter nothing writes to, both read ZERO — indistinguishable from a perfectly
  # paced loop. Two earlier versions of this arm shipped without this and passed under
  # their own mutation for exactly that reason; a direct probe then showed the waiter
  # was already dead at 3s and the arm had never observed a held waiter at all.
  [ "$_alive" = y ] \
    || fail "(9) the waiter was gone before the window closed — this arm never observed a held waiter, so any bound it reports is meaningless"

  # With a 1s cadence, three seconds past the deadline is ~3 iterations. A spin is
  # orders of magnitude more, so the bound is generous on purpose: this arm is about
  # unbounded-vs-bounded, not about hitting the cadence exactly.
  # THE BOUND IS A RATE, NOT A COUNT, and the first version got that wrong. It allowed
  # 2 probes in the window on the reasoning that a paced waiter sleeps through it — true
  # on an idle box, and false under suite concurrency, where the deliverer's own startup
  # drain plus a tick that straddles the window pushed a CORRECT build to 4 and the arm
  # went flaky. A flake here is worse than no arm: this file is the merge gate's, and an
  # arm that reds on a green tree teaches the next reader to rerun until it passes.
  #
  # The discriminating quantity is orders of magnitude, not units. Measured: a paced
  # waiter at a 30s cadence probes a handful of times in 3s (startup plus at most one
  # tick); the spin build probes continuously at drain speed — 8 in the same window on
  # an idle box, and it climbs with the window. The bound sits well above the paced
  # ceiling and well below the spin floor, so it separates the builds without pretending
  # the paced count is exactly zero.
  _grew=$(( _after - _before ))
  [ "$_grew" -le 6 ] \
    || fail "(9) the held waiter made ${_grew} readiness probes in a 3s window at a 30s cadence — a paced waiter manages a handful; this is the loop running free"
) || exit 1
echo "courier-busy-hold: (9) a held waiter past its deadline keeps its cadence instead of spinning: ok"

# ---- (10) A BOUNDED WAITER LEAVES NO FRESH LEASE BEHIND ---------------------------
# The claim's property is "this waiter may outlive its deadline", and only a
# readiness-gate park has it. `_deadline` answers a WIDER question — is this a lifetime
# this file owns — which is true for autosettle-hold and grace-window too. Gating the
# `.reown` claim on `_deadline` fixed the --polite case and moved the same defect onto
# those two classes: a bounded waiter claiming a lease it will not outlive, suppressing
# its own replacement for up to one lease lifetime. Caught by fable-xhigh-developer on
# the fix itself.
#
# An autosettle-hold park is the fixture because it is a real class with a real
# deadline, unlike --polite whose `_deadline` is already 0 and which the previous shape
# happened to get right. RED before the `_held_class` predicate, GREEN after.
(
  set -euo pipefail
  export TAP_SPOOL_DISABLE_DELIVERER=1
  D5="$(mktemp -d)"; mkdir -p "$D5/spool" "$D5/receipts"
  trap 'rm -rf "$D5" 2>/dev/null || true' EXIT
  # A bounded park's metadata, written directly: this arm is about which classes claim
  # the lease, which `_held_class` reads from the meta alone. No bus, no drain, no pane.
  printf '%s\n' '{"waiter_lifetime":"autosettle-hold","deadline_source":"autosettle-hold","deadline_epoch":1}' \
    > "$D5/spool/b1.meta.json"
  # SCOPE, STATED SO NOBODY READS THIS ARM AS MORE THAN IT IS: this exercises the
  # PREDICATE, not its call sites. It calls the native held-class predicate and
  # asks it about four metadata shapes. A mutation that rewires the two `touch` sites to
  # a different predicate leaves this arm GREEN — verified, not assumed (mutant X) — and
  # that is a property of what it tests rather than a weakness to paper over. The call
  # sites are covered by arm 8 (a held entry keeps its lease-holding owner) and by the
  # deliverer's own grep-able shape; what could not be covered any other way is the
  # class table itself, which is where the defect was.
  _claims() { # <id>: the same native held-class predicate used by the waiter
    bun "$ROOT/runtime/bun/src/spool-grace.ts" held "$D5/spool/$1.meta.json" "$D5/receipts/$1.attempted"
  }
  [ "$(_claims b1)" = no ] \
    || fail "(10) an autosettle-hold waiter claims the re-own lease — it is bounded, exits at its deadline, and will suppress its own replacement for a lease lifetime"
  printf '%s\n' '{"waiter_lifetime":"grace-window","deadline_source":"","deadline_epoch":1}' \
    > "$D5/spool/b2.meta.json"
  [ "$(_claims b2)" = yes ] \
    || fail "(10) a marker-free grace-window waiter has no owner for a later refused probe"
  : > "$D5/receipts/b2.attempted"
  [ "$(_claims b2)" = no ] \
    || fail "(10) possible-effect grace residue claims a retry owner"
  # POSITIVE CONTROL: the one class that MUST claim it. Without this the arm passes on a
  # predicate that returns no for everything, which would disable the cardinality
  # guarantee entirely.
  printf '%s\n' '{"waiter_lifetime":"readiness-gate","deadline_source":"readiness-gate","deadline_epoch":1}' \
    > "$D5/spool/b3.meta.json"
  [ "$(_claims b3)" = yes ] \
    || fail "(10) a readiness-gate waiter does NOT claim the lease — the predicate says no to everything, so nothing suppresses replacement spawns and this arm proves nothing"
  # Legacy meta carries deadline_source without waiter_lifetime; the predicate must read
  # it the same way `_deadline` does.
  printf '%s\n' '{"deadline_source":"readiness-gate","deadline_epoch":1}' > "$D5/spool/b4.meta.json"
  [ "$(_claims b4)" = yes ] \
    || fail "(10) legacy meta (deadline_source, no waiter_lifetime) is not recognised as the held class"
) || exit 1
echo "courier-busy-hold: (10) the held-class predicate admits readiness-gate only (predicate-level; call sites are arm 8): ok"

# ---- (11) A HELD ENTRY DOES NOT STARVE YOUNGER READY MAIL -------------------------
# The effect the drain-cap refund exists to produce, asserted as an effect rather than
# the mechanism. This loop is oldest-first under TAP_SPOOL_DRAIN_CAP and already exempts
# two classes for exactly this reason, each saying so in its own comment (lib.sh
# 3423-3425, escalated: "attempts stayed 0 for days behind escalated junk"; 3528-3533,
# auto-settle hold). tap-92v3r added a third entry that leaves the loop having delivered
# nothing, and it took a slot per tick per held entry.
#
# TWO RECIPIENTS, AND THAT IS THE WHOLE FIXTURE. The first version of this arm parked
# both entries against ONE pane and then freed the band — which cannot produce the
# state it claims, because freeing the band un-holds the older entry too. It reddened,
# and reading it as "the refund is broken" would have been wrong: the fixture could not
# create starvation at all. Starvation needs an entry that STAYS held (a busy
# recipient) and a younger entry that is deliverable NOW (a different, free recipient).
#
# CAP=1 is what makes it discriminating: at the default 8 a single held entry is
# invisible, and the starvation only shows when the held entry can consume the whole
# budget — the shape a busy seat with several parked messages produces in production.
(
  set -euo pipefail
  export TAP_SPOOL_DISABLE_DELIVERER=1
  export TAP_SPOOL_DRAIN_CAP=1
  D6="$(mktemp -d)"; mkdir -p "$D6/tmux" "$D6/repo"
  trap 'rm -rf "$D6" 2>/dev/null || true' EXIT
  export FAKE_TMUX_STATE="$D6/tmux" FAKE_WORKTREE="$D6/repo"
  BUS6="$D6/repo/.tap/bus"; mkdir -p "$BUS6/payloads" "$BUS6/receipts" "$BUS6/spool"
  export TAP_HOME="$BUS6"
  # bob is the second recipient: his pane is never busy, so his mail is deliverable the
  # moment the drain reaches it.
  python3 -B - "$BUS6/registry.json" "$D6/repo" <<'PY'
import json, sys
path, root = sys.argv[1:3]
seat = lambda pane, pid: {"session": "sess", "pane": pane, "pane_id": pid, "harness": "codex",
                          "status": "active", "server_epoch": "srv:4242:100", "boot_id": "boot:1",
                          "registered_from_worktree": root}
json.dump({"team": {"name": "t", "worktree_root": root},
           "agents": {"peer": seat("sess:0.0", "%401"), "alice": seat("sess:0.1", "%402"),
                      "bob": seat("sess:0.2", "%403")}}, open(path, "w"))
PY
  LOG6="$D6/tmux/send-keys.log"; : > "$LOG6"

  # OLDER, and held: peer's pane is busy and stays busy for the whole arm.
  touch "$D6/tmux/busy.sess_0_0"
  bash "$TAPSH" send peer -m "older held" --id s1 --from alice --wake >"$D6/send1.out" 2>&1 || true
  [ -f "$BUS6/spool/s1.md" ] || fail "(11) s1 did not park; send said: $(cat "$D6/send1.out")"
  _dl="$(python3 -B -c 'import json,sys
try: print(json.load(open(sys.argv[1])).get("deadline_epoch") or "")
except Exception: print("")' "$BUS6/spool/s1.meta.json")"
  [ -n "$_dl" ] || fail "(11) s1 carries no deadline, so it can never reach the held branch"

  # YOUNGER, and deliverable: parked only because bob's pane is briefly busy, then freed.
  touch "$D6/tmux/busy.sess_0_2"
  bash "$TAPSH" send bob -m "younger ready" --id s2 --from alice --wake >"$D6/send2.out" 2>&1 || true
  [ -f "$BUS6/spool/s2.md" ] || fail "(11) s2 did not park; send said: $(cat "$D6/send2.out")"
  rm -f "$D6/tmux/busy.sess_0_2"
  : > "$LOG6"

  # One tick past s1's deadline, cap=1. s1 is older so the loop reaches it first.
  TAP_SPOOL_NOW="$(( _dl + 1 ))" bash -c 'set -euo pipefail; . "$1"; tap_spool_drain_once' \
    _ "$ROOT/skills/tap/scripts/lib.sh" >/dev/null 2>&1 || true

  # Fixture premise: s1 must still be held, or this proves nothing about starvation.
  [ -f "$BUS6/spool/s1.md" ] \
    || fail "(11) the older entry left the spool — it was not held during the tick, so the cap was never contended"
  grep -qE "\\[\\[TAP v[0-9.]+ (ask|note) ([A-Za-z0-9][A-Za-z0-9._-]*/)?s2( |:|\\]\\])" "$LOG6" \
    || fail "(11) the younger, deliverable entry did not deliver in a tick where an older HELD entry was present at cap=1 — the held entry consumed the only slot, which is the starvation lib.sh exempts two other classes to avoid"
) || exit 1
echo "courier-busy-hold: (11) a held entry does not consume the drain slot younger ready mail needs: ok"

# ---- (12) THE CALL SITES ARE WIRED TO THE HELD CLASS, not merely the predicate ------
# THE GAP ARM 10 DOES NOT COVER, and it is a real one — I raised it and
# fable-xhigh-developer confirmed it rather than waiving it. Arm 10 sources
# `_held_class` and asks it about metadata shapes, so a mutation that rewires the two
# `.reown` touch sites back to `_deadline` leaves it green (verified: mutant X). Arm 8
# only ever parks a readiness-gate entry, so it cannot see the difference either. That
# mutant IS the defect this delta fixed, reintroduced one layer out, with nothing red.
#
# So this arm runs the PRODUCTION deliverer against a bounded park and asks what it did
# to the lease. A `--fyi` send parks as `autosettle-hold` (lib.sh's waiter_lifetime
# assignment), which `_deadline` accepts and `_held_class` refuses — exactly the pair
# that separates the two predicates at the call site.
(
  set -euo pipefail
  unset TAP_SPOOL_DISABLE_DELIVERER
  export TAP_SPOOL_BUSY_DEADLINE_SECONDS=1 TAP_SPOOL_DELIVERER_DELAYS="1" \
         TAP_SPOOL_REOWN_LEASE_SECONDS=20 TAP_AUTOSETTLE_HOLD_SECONDS=1
  D7="$(mktemp -d)"; mkdir -p "$D7/tmux" "$D7/repo"
  _w7=""
  cleanup12() {
    if [ -n "$_w7" ]; then kill "$_w7" 2>/dev/null || true; wait "$_w7" 2>/dev/null || true; fi
    rm -rf "$D7" 2>/dev/null || true
  }
  trap cleanup12 EXIT
  export FAKE_TMUX_STATE="$D7/tmux" FAKE_WORKTREE="$D7/repo"
  BUS7="$D7/repo/.tap/bus"; mkdir -p "$BUS7/payloads" "$BUS7/receipts" "$BUS7/spool"
  export TAP_HOME="$BUS7"
  sed "s|$WORK/repo|$D7/repo|g" "$BUS/registry.json" > "$BUS7/registry.json"
  : > "$D7/tmux/send-keys.log"

  touch "$D7/tmux/busy.sess_0_0"
  # .96 no longer creates this class. Construct a pre-change park explicitly.
  printf '%s\n' '---' '---' 'legacy bounded park' > "$D7/source.md"
  TAP_SPOOL_DISABLE_DELIVERER=1 bash -c '
    . "$1"
    canon="$(tap_payload_path c1)"
    tap_canonical_place "$2" c1 alice peer discuss "$canon" 0 settle-only t t
    tap_spool_add c1 "$canon" peer t auto-settle busy "" sess:0.0 %401 t autosettle "" "$TAP_REGISTRY"
    rm -f "$canon"
  ' _ "$ROOT/skills/tap/scripts/lib.sh" "$D7/source.md" >"$D7/send.out" 2>&1
  [ -f "$BUS7/spool/c1.md" ] || fail "(12) c1 did not park; send said: $(cat "$D7/send.out")"

  # FIXTURE PREMISE, asserted rather than assumed: this must be a park that `_deadline`
  # accepts and `_held_class` refuses. If it parks as readiness-gate the arm is testing
  # the positive case and mutant X would never red it.
  _lt="$(python3 -B -c 'import json,sys
try:
    m = json.load(open(sys.argv[1])); print(m.get("waiter_lifetime") or m.get("deadline_source") or "")
except Exception: print("")' "$BUS7/spool/c1.meta.json")"
  [ "$_lt" = autosettle-hold ] \
    || fail "(12) c1 parked as lifetime '$_lt', not autosettle-hold — this arm needs a BOUNDED class or it cannot distinguish the two predicates"

  # The production waiter, started here so only $! is ever signalled (no-pattern-kills).
  nohup env -u TAP_SPOOL_DRAIN_ACTIVE \
    bun "$ROOT/runtime/bun/src/spool-waiter.ts" c1 >>"$D7/w.log" 2>&1 &
  _w7=$!
  command sleep 3

  # A bounded waiter must not leave a FRESH lease behind. If a re-park minted one, it
  # must be stale — never refreshed by the waiter itself.
  _lease="$BUS7/spool/c1.meta.json.reown"
  if [ -f "$_lease" ]; then
    _age="$(python3 -B -c 'import os,sys,time; print(round(time.time()-os.stat(sys.argv[1]).st_mtime,2))' "$_lease" 2>/dev/null || echo 0)"
    python3 -B -c 'import sys; sys.exit(0 if float(sys.argv[1]) >= 2.0 else 1)' "$_age" \
      || fail "(12) a bounded (autosettle-hold) waiter is refreshing the re-own lease — age ${_age}s after 3s means the call site is keyed on lifetime ownership rather than the held class, and this waiter will suppress its own replacement when it exits"
  fi
) || exit 1
echo "courier-busy-hold: (12) a bounded waiter leaves no fresh re-own lease — the call sites use the held class: ok"

# ---- (13) THE .reown LEASE HAS A LIFECYCLE (tap-nj22m U1) --------------------------
# Codex thread `tap-spool-deliverer.sh:214`: the lease is created before every
# readiness-gate waiter's first drain and deleted by NOTHING. `tap_spool_remove`
# (lib.sh) unlinks payload and meta only; `tap_spool_reap_stale_sidecars` scans
# `*.meta.json.lock` and `*.claim`. So every send that ever parks leaks one inode
# permanently, on a bus that runs for weeks.
#
# THREE EFFECTS, ARMED TOGETHER, because the partner's acceptance names all three and
# a terminal-only fix would leave the finding half-open (my first plan proposed exactly
# that, and it was corrected):
#   (a) a graceful waiter exit removes ITS OWN lease;
#   (b) a SUCCESSOR's authority, minted before the old waiter exits, SURVIVES that exit;
#   (c) terminalization removes residual `.reown`.
#
# (b) is why the lease carries an owner token rather than being an empty mtime file: an
# exiting waiter cannot otherwise tell its own stale lease from a successor's fresh one,
# and deleting the successor's reopens the multi-owner defect arm 8 exists to close.
(
  set -euo pipefail
  export TAP_SPOOL_DISABLE_DELIVERER=1
  D8="$(mktemp -d)"; mkdir -p "$D8/tmux" "$D8/repo"
  trap 'rm -rf "$D8" 2>/dev/null || true' EXIT
  export FAKE_TMUX_STATE="$D8/tmux" FAKE_WORKTREE="$D8/repo"
  BUS8="$D8/repo/.tap/bus"; mkdir -p "$BUS8/payloads" "$BUS8/receipts" "$BUS8/spool"
  export TAP_HOME="$BUS8"
  sed "s|$WORK/repo|$D8/repo|g" "$BUS/registry.json" > "$BUS8/registry.json"
  : > "$D8/tmux/send-keys.log"

  # (c) TERMINALIZATION removes residue. Driven through the real `tap_spool_remove`
  # rather than by deleting files, so the arm tracks the production cleanup path.
  touch "$D8/tmux/busy.sess_0_0"
  bash "$TAPSH" send peer -m "lease lifecycle" --id L1 --from alice >"$D8/s.out" 2>&1 || true
  [ -f "$BUS8/spool/L1.md" ] || fail "(13) L1 did not park; send said: $(cat "$D8/s.out")"
  : > "$BUS8/spool/L1.meta.json.reown"
  bash -c 'set -euo pipefail; . "$1"; tap_spool_remove L1' _ "$ROOT/skills/tap/scripts/lib.sh"
  [ ! -f "$BUS8/spool/L1.meta.json.reown" ] \
    || fail "(13c) tap_spool_remove left <id>.meta.json.reown behind — every parked send leaks one inode forever"

  # (a) GRACEFUL EXIT removes the waiter's OWN lease, and (b) a successor's does not go
  # with it. Both are asserted against the production helpers rather than by simulating
  # a waiter, so the arm cannot pass by testing its own imitation of the protocol.
  touch "$D8/tmux/busy.sess_0_0"
  bash "$TAPSH" send peer -m "own lease" --id L2 --from alice >/dev/null 2>&1 || true
  [ -f "$BUS8/spool/L2.md" ] || fail "(13) L2 did not park"
  _own_token="$(bash -c 'set -euo pipefail; . "$1"; tap_reown_claim L2' _ "$ROOT/skills/tap/scripts/lib.sh" 2>/dev/null || true)"
  [ -n "$_own_token" ] \
    || fail "(13a) tap_reown_claim minted no owner token — the lease carries no identity, so an exiting waiter cannot tell its own from a successor's"
  bash -c 'set -euo pipefail; . "$1"; tap_reown_release L2 "$2"' _ "$ROOT/skills/tap/scripts/lib.sh" "$_own_token"
  [ ! -f "$BUS8/spool/L2.meta.json.reown" ] \
    || fail "(13a) a graceful exit did not remove its own lease"

  # (b) THE DISCRIMINATING HALF. A successor mints while the old token is what the
  # departing waiter still holds; the old waiter's release must be a NO-OP, or it
  # deletes a live owner's authority and two owners are spawned for one entry.
  _t1="$(bash -c 'set -euo pipefail; . "$1"; tap_reown_claim L2' _ "$ROOT/skills/tap/scripts/lib.sh")"
  bash -c 'set -euo pipefail; . "$1"; tap_reown_release L2 "$2"' _ "$ROOT/skills/tap/scripts/lib.sh" "$_own_token" || true
  [ -f "$BUS8/spool/L2.meta.json.reown" ] \
    || fail "(13b) a departing waiter deleted a SUCCESSOR's lease — the compare is not owner-qualified, and this reopens the multi-owner defect arm 8 closes"
  grep -q "$_t1" "$BUS8/spool/L2.meta.json.reown" \
    || fail "(13b) the surviving lease does not carry the successor's token"

  # (d) CANCEL IS A TERMINALIZATION TOO (tap-92v3r U2d). Codex thread
  # `lib.sh:1809`: `tap cancel --spooled` removed `$spool_meta` and
  # `$spool_payload.claim` and nothing else, so a cancelled entry left its
  # `.reown` behind — the same permanent leak (c) closes for the drain path,
  # reached through a second door.
  #
  # THE FIX IS THE ROUTING, NOT THE UNLINK, but routing is NOT mutation-armed here.
  # A partner replaced `tap_spool_remove` with inline unlinks of every asserted file
  # and this arm stayed green, as it must: file absence cannot prove which lock guarded
  # the removal. The routing rests on the design argument in lib.sh:1756-1763.
  # `tap_spool_reown_after_repark` can otherwise observe a payload being terminalized,
  # mint a successor owner for an entry about to stop existing, and write a FRESH
  # `.reown` after the inline unlink. Keep this warning even though the assertions
  # below cannot stage that interleaving.
  #
  # THE ARCHIVE ASSERTION IS THE ORDER CONTROL, and it is not decoration. For a
  # spooled entry `payload` IS `$spool_payload` (tap-cancel.sh:84), the same path
  # `tap_spool_remove` unlinks. The routed call must therefore stay AFTER the `mv`
  # at tap-cancel.sh:447-449: the archive renames that inode first, so the unlink
  # finds nothing and the evidence survives. Move the call above the `mv` and the
  # body is destroyed — the exact incident tap-cancel.sh:440-443 records. Without
  # this line the arm is green on that edit.
  touch "$D8/tmux/busy.sess_0_0"
  bash "$TAPSH" send peer -m "cancel me" --id L3 --from alice >"$D8/s3.out" 2>&1 || true
  [ -f "$BUS8/spool/L3.md" ] || fail "(13d) L3 did not park; send said: $(cat "$D8/s3.out")"
  _t3="$(bash -c 'set -euo pipefail; . "$1"; tap_reown_claim L3' _ "$ROOT/skills/tap/scripts/lib.sh")"
  [ -n "$_t3" ] && [ -f "$BUS8/spool/L3.meta.json.reown" ] \
    || fail "(13d) precondition: tap_reown_claim minted no lease, so this arm would pass on an entry that never had one to leak"
  bash "$TAPSH" cancel L3 --spooled --by alice >"$D8/c3.out" 2>&1 \
    || fail "(13d) tap cancel --spooled failed: $(cat "$D8/c3.out")"
  [ ! -f "$BUS8/spool/L3.meta.json.reown" ] \
    || fail "(13d) tap cancel --spooled left <id>.meta.json.reown behind — cancel is a second door onto the leak (c) closes for the drain"
  [ ! -f "$BUS8/spool/L3.meta.json" ] \
    || fail "(13d) cancel left the meta behind — the routing dropped work cancel already did, and a drain can rebuild the entry"
  [ ! -f "$BUS8/spool/L3.claim" ] \
    || fail "(13d) cancel left its acquired queue claim behind"
  [ -f "$BUS8/archive/L3.cancelled.md" ] \
    || fail "(13d) the withdrawn body was not archived — the routed removal ran BEFORE the mv at tap-cancel.sh:447-449 and destroyed the only copy (the incident :440-443 records)"
) || exit 1
echo "courier-busy-hold: (13) the .reown lease is owner-qualified: own exit clears it, a successor survives, terminalization and cancel both reap it: ok"

# ---- (14) A HARD DRAIN ERROR ENDS THE WAITER (tap-nj22m U2) ------------------------
# Codex thread `tap-spool-deliverer.sh:323`: the post-deadline drain's rc is discarded
# (`tap_spool_drain_once || true`) and the held branch then reads RESIDENCY as proof the
# recipient was classified present. Under a persistent hard error the payload stays
# resident for a reason that has nothing to do with the recipient, and the waiter sleeps
# and retries forever.
#
# THE rc TABLE, read from the production function rather than assumed (lib.sh):
#   rc 0 — :3302 nothing spooled, and :3834 the normal end of a pass. The pass ran.
#   rc 1 — :3293 `tap_spool_home_authorized_or_warn` refused: the bus carries no
#          `.tap-bus-authority` marker. NOTHING was attempted, and rc 1 leaves EVERY
#          entry resident — which is precisely why residency cannot be the evidence.
#   rc 5 — :3832 some submit in the pass was unverified.
# At the FINAL post-deadline drain only rc 0 with the same entry still resident may
# extend the hold; rc 1 exits 1 and rc 5 exits 5. (The partner's conservative reading of
# rc 5 over my first one: "the pass ran" is not evidence about OUR entry, and if ours was
# the unverified one its payload is already gone.)
#
# Pre-deadline hard behaviour stays bounded by the deadline, preserving tap-13c8 — this
# arm points at the FINAL drain, which is where the unbounded loop lives.
(
  set -euo pipefail
  unset TAP_SPOOL_DISABLE_DELIVERER
  export TAP_SPOOL_BUSY_DEADLINE_SECONDS=1 TAP_SPOOL_DELIVERER_DELAYS="1"
  D9="$(mktemp -d)"; mkdir -p "$D9/tmux" "$D9/repo"
  _hw=""
  cleanup14() {
    if [ -n "$_hw" ]; then kill "$_hw" 2>/dev/null || true; wait "$_hw" 2>/dev/null || true; fi
    rm -rf "$D9" 2>/dev/null || true
  }
  trap cleanup14 EXIT
  export FAKE_TMUX_STATE="$D9/tmux" FAKE_WORKTREE="$D9/repo"
  BUS9="$D9/repo/.tap/bus"; mkdir -p "$BUS9/payloads" "$BUS9/receipts" "$BUS9/spool"
  export TAP_HOME="$BUS9"
  sed "s|$WORK/repo|$D9/repo|g" "$BUS9/../../../../CourierReadiness/.tap/bus/registry.json" > /dev/null 2>&1 || true
  sed "s|$WORK/repo|$D9/repo|g" "$BUS/registry.json" > "$BUS9/registry.json"

  touch "$D9/tmux/busy.sess_0_0"
  TAP_SPOOL_DISABLE_DELIVERER=1 bash "$TAPSH" send peer -m "hard error" --id H1 --from alice --wake \
    >"$D9/s.out" 2>&1 || true
  [ -f "$BUS9/spool/H1.md" ] || fail "(14) H1 did not park; send said: $(cat "$D9/s.out")"

  # The hard error: remove the bus-authority marker AFTER the park, so every subsequent
  # drain returns rc 1 having attempted nothing, with the payload permanently resident.
  # This is the thread's own scenario.
  _auth="$(find "$BUS9" -maxdepth 1 -name '.tap-bus-authority' | head -1)"
  [ -n "$_auth" ] \
    || fail "(14) fixture premise: no .tap-bus-authority marker found on the sandbox bus, so rc 1 cannot be produced and this arm would test nothing"
  rm -f "$_auth"
  bash -c 'set -euo pipefail; . "$1"; tap_spool_drain_once' _ "$ROOT/skills/tap/scripts/lib.sh" >/dev/null 2>&1 \
    && fail "(14) fixture premise: the drain returned success with the authority marker removed — rc 1 is not being produced"

  nohup env -u TAP_SPOOL_DRAIN_ACTIVE \
    bun "$ROOT/runtime/bun/src/spool-waiter.ts" H1 >>"$D9/w.log" 2>&1 &
  _hw=$!
  # Well past the deadline. A waiter that classifies rc 1 exits; one that reads residency
  # as presence is still here.
  command sleep 5
  if kill -0 "$_hw" 2>/dev/null; then
    kill "$_hw" 2>/dev/null || true; wait "$_hw" 2>/dev/null || true; _hw=""
    fail "(14) the waiter is still alive 5s past its deadline against a bus whose drain returns rc 1 having attempted nothing — residency is being read as proof the recipient is present, and this loop never ends"
  fi
  _hw=""
) || exit 1
echo "courier-busy-hold: (14) a persistent hard drain error ends the waiter instead of extending it: ok"

# ---- (15) rc 5 DOES NOT REFUND THE DRAIN SLOT (tap-nj22m U3) -----------------------
# Codex thread `lib.sh:3622`: my refund tests `_held_slot`, `delivered` and `ready` —
# none of which changes at rc 5 — while `tap_spool_redeliver` has ALREADY removed the
# spool payload and metadata at submit-unverified. So the slot is refunded for an entry
# that no longer exists, and a backlog of overdue entries all going rc 5 processes the
# whole set in one invocation instead of the bounded cap.
#
# THE SAME-ID RACE, asked by the partner and answered rather than guarded against:
# `tap_canonical_place` (lib.sh:4244, 4248) dies on a duplicate id while the payload
# exists or a `.done` receipt is present, and rc 5 PRESERVES the canonical. So a fresh
# same-id park in that window is not reachable through the supported send path — the
# duplicate-ID refusal IS the answer, and binding residency to an entry identity would
# be machinery for a race that cannot occur. What the refund must still stop doing is
# keying on a STALE `ready`: the predicate becomes redeliver_rc != 5 AND both spool
# payload and meta still resident AND current readiness proves presence.
(
  set -euo pipefail
  export TAP_SPOOL_DISABLE_DELIVERER=1
  export TAP_SPOOL_DRAIN_CAP=1
  DA="$(mktemp -d)"; mkdir -p "$DA/tmux" "$DA/repo"
  trap 'rm -rf "$DA" 2>/dev/null || true' EXIT
  export FAKE_TMUX_STATE="$DA/tmux" FAKE_WORKTREE="$DA/repo"
  BUSA="$DA/repo/.tap/bus"; mkdir -p "$BUSA/payloads" "$BUSA/receipts" "$BUSA/spool"
  export TAP_HOME="$BUSA"
  python3 -B - "$BUSA/registry.json" "$DA/repo" <<'PY'
import json, sys
path, root = sys.argv[1:3]
seat = lambda pane, pid: {"session": "sess", "pane": pane, "pane_id": pid, "harness": "codex",
                          "status": "active", "server_epoch": "srv:4242:100", "boot_id": "boot:1",
                          "registered_from_worktree": root}
json.dump({"team": {"name": "t", "worktree_root": root},
           "agents": {"peer": seat("sess:0.0", "%401"), "alice": seat("sess:0.1", "%402"),
                      "bob": seat("sess:0.2", "%403")}}, open(path, "w"))
PY
  LOGA="$DA/tmux/send-keys.log"; : > "$LOGA"

  # An older entry that will go submit-unverified at its forced deadline attempt: the
  # pane accepts the paste but never clears the id, which is what rc 5 means.
  touch "$DA/tmux/busy.sess_0_0"
  bash "$TAPSH" send peer -m "goes rc5" --id R1 --from alice --wake >"$DA/s1.out" 2>&1 || true
  [ -f "$BUSA/spool/R1.md" ] || fail "(15) R1 did not park; send said: $(cat "$DA/s1.out")"
  _dl="$(python3 -B -c 'import json,sys
try: print(json.load(open(sys.argv[1])).get("deadline_epoch") or "")
except Exception: print("")' "$BUSA/spool/R1.meta.json")"
  [ -n "$_dl" ] || fail "(15) R1 carries no deadline"

  # A younger entry to a DIFFERENT, free recipient, so cap contention is real.
  touch "$DA/tmux/busy.sess_0_2"
  bash "$TAPSH" send bob -m "younger" --id R2 --from alice --wake >/dev/null 2>&1 || true
  [ -f "$BUSA/spool/R2.md" ] || fail "(15) R2 did not park"
  rm -f "$DA/tmux/busy.sess_0_2"

  # Make R1's redelivery land but never clear -> rc 5, which removes its payload+meta.
  rm -f "$DA/tmux/busy.sess_0_0"
  : > "$DA/tmux/stuck_submit"
  : > "$LOGA"
  TAP_SPOOL_NOW="$(( _dl + 1 ))" bash -c 'set -euo pipefail; . "$1"; tap_spool_drain_once' \
    _ "$ROOT/skills/tap/scripts/lib.sh" >/dev/null 2>&1 || true

  # FIXTURE PREMISE: R1 must actually have gone rc 5 — its spool payload and meta gone.
  # Without this the arm could pass on a run where rc 5 never happened.
  [ ! -f "$BUSA/spool/R1.md" ] \
    || fail "(15) fixture premise: R1 is still spooled, so it did not go submit-unverified and this arm is not about rc 5"
  # THE ASSERTION: the slot R1 consumed must NOT have been refunded, so at cap=1 the
  # younger entry does not also deliver in that same tick.
  # `if`-form, not `A && fail`: this assertion is the LAST statement in its subshell, and
  # there a trailing AND-list exits with A's status — so the PASSING branch (grep finds
  # nothing) would exit 1 and read as RED. Written that way, this arm could never go green
  # no matter what the fix did. Position is what makes the difference, so the idiom used by
  # the mid-arm assertions above is correct there and wrong here.
  if grep -qE "\\[\\[TAP v[0-9.]+ (ask|note) ([A-Za-z0-9][A-Za-z0-9._-]*/)?R2( |:|\\]\\])" "$LOGA"; then
    fail "(15) both entries delivered in one tick at cap=1 — the rc-5 entry refunded a slot after its payload and metadata were already removed, so a backlog of submit-unverified entries drains without bound"
  fi
) || exit 1
echo "courier-busy-hold: (15) an rc-5 submit-unverified entry does not refund the drain slot: ok"

# ---- (16) TED'S P0: A GENERATING agy PANE IS INJECTABLE, A MODAL IS NOT ------------
# tap-7r3fn.13, Ops 16:3xZ: he watched gemini-low-moderator's pane flash the courier's
# warn repeatedly while she was MID-TURN. She was not wedged, she was working.
# Antigravity queues input mid-generation. Ruling: be more aggressive about injecting;
# the only hold that survives is a visible dialog/modal.
#
# ITEM 1 IS ALREADY TRUE ON THIS BRANCH and this arm PINS it rather than implementing
# it — the accepted detector half makes a generating pane injectable, and I verified
# that before planning rather than assuming a code change was owed. An arm that pins an
# incidental property is what keeps the next reader from "simplifying" it away.
#
# THE TWO CAPTURES ARE FROM THE INCIDENT ITSELF, taken off the conductor's live pane
# while she was being reported unreachable to me:
#   generating-243.txt          two rules, `esc to cancel`, no task card
#   generating-taskcard-243.txt THREE rules — a task card rendered BELOW the band —
#                               captured 16:35Z while she was mid-`tap send`, at the
#                               moment the courier told me my message to her would never
#                               arrive. That is tap-92v3r reproducing on the driver
#                               assigned to fix it.
(
  set -euo pipefail
  CAPD="$ROOT/skills/tap/scripts/smoke/fixtures/agy-capture-20260903"
  for f in generating-243 generating-taskcard-243; do
    [ -s "$CAPD/$f.txt" ] || fail "(16) missing capture $f.txt"
  done

  # INJECTABLE: both generating shapes. `esc to cancel` and a spinner are NOT a reason
  # to hold, and a task card below the band does not hide the band.
  tap_agy_box_text < "$CAPD/generating-243.txt" >/dev/null \
    || fail "(16) a generating agy pane (esc to cancel, no task card) is not injectable — panel ruling is that this pane queues input and must never be spooled"
  tap_agy_box_text < "$CAPD/generating-taskcard-243.txt" >/dev/null \
    || fail "(16) the incident shape (generating + task card below the band) is not injectable — this is the exact pane the courier declared unreachable at 16:35Z"

  # THE ONE HOLD THAT SURVIVES. Without this arm "be more aggressive" has no floor and
  # the next change injects over a human's pending decision. CONSTRUCTED, and labelled:
  # this fleet runs --dangerously-skip-permissions so no live pane renders the modal;
  # tap-lslrc carries a real capture as its acceptance criterion.
  _rule="$(printf '─%.0s' $(seq 1 60))"
  _modal="$(printf '%s\n' "  x" "$_rule" "> " "$_rule" \
                          "Requesting permission for: run_shell_command" \
                          "Do you want to proceed?" "Yes · No · Tab amend")"
  printf '%s\n' "$_modal" | tap_agy_permission_overlay \
    || fail "(16) a visible permission modal is not recognised — it is the only hold panel ruling leaves standing, so nothing else protects a pending human decision"

  # AND THE DISCRIMINATOR: a generating pane must NOT be mistaken for a modal, or the
  # aggression ruling is undone by the guard that survives it.
  if tap_agy_permission_overlay < "$CAPD/generating-taskcard-243.txt"; then   # see (15) on the form
    fail "(16) a generating pane with a task card reads as a permission modal — the hold would swallow exactly the panes Ops ruled injectable"
  fi
) || exit 1
echo "courier-busy-hold: (16) a generating agy pane is injectable (both shapes); only a visible modal holds: ok"

# ---- (17) A RECOGNIZED MODAL AND AN UNREADABLE PANE ARE DIFFERENT ANSWERS ----------
# Ruling 15 item 3 (leader, 16:45Z) makes a modal hold indefinitely — retried, never
# reported as "will not arrive" — while an unknown no-band pane holds for N and then
# forces. Those are opposite dispositions, and today they are the SAME return code:
# `tap_pending_input_text` returns 3 for a recognized permission overlay and 3 for a
# pane with no band at all, and `tap_spool_pane_ready` maps rc 3 to `busy:noprompt`
# either way. So the force path has nothing to exclude on, and "only a visible dialog
# holds" cannot be expressed against this classification.
#
# THIS ARM IS THE DISCRIMINATOR the ruling needs to exist at all. Without it the two
# classes could be merged again by anyone who reads `busy:noprompt` as "not ready".
(
  set -euo pipefail
  reset_bus
  export FAKE_TMUX_CMD=agy
  set_peer_harness agy
  CAPD="$ROOT/skills/tap/scripts/smoke/fixtures/agy-capture-20260903"
  _rule="$(printf '─%.0s' $(seq 1 60))"
  # The modal, constructed and labelled as such: this fleet runs with permission
  # prompts disabled, so no live pane renders one. tap-lslrc carries a real capture as
  # its acceptance criterion. Geometry is taken from the live captures, not invented —
  # band between two rules, overlay text BELOW the lower rule.
  printf '%s\n' "  working" "$_rule" "> " "$_rule" \
                "Requesting permission for: run_shell_command" \
                "Do you want to proceed?" "Yes · No · Tab amend" > "$WORK/tmux/capture.sess_0_0"
  _cls="$(tap_spool_pane_ready sess:0.0 %401 peer t "$BUS/registry.json" "")"
  [ "$_cls" = "busy:modal" ] \
    || fail "(17) a visible permission overlay classifies '$_cls', not busy:modal — a modal and an unreadable pane share one answer, so the forced-injection bound cannot exclude the one hold panel ruling leaves standing"

  # A pane with no band at all: genuinely unknown, and the class the bound is FOR.
  printf '%s\n' "some scrollback" "no band here at all" > "$WORK/tmux/capture.sess_0_0"
  _cls="$(tap_spool_pane_ready sess:0.0 %401 peer t "$BUS/registry.json" "")"
  [ "$_cls" = "busy:noprompt" ] \
    || fail "(17) a pane with no band classifies '$_cls', not busy:noprompt — the unknown class is what the N-probe bound forces on, and widening it would force on modals too"

  # And the generating pane stays READY, on the first look, with no bound to wait out.
  cp "$CAPD/generating-taskcard-243.txt" "$WORK/tmux/capture.sess_0_0"
  _cls="$(tap_spool_pane_ready sess:0.0 %401 peer t "$BUS/registry.json" "")"
  [ "$_cls" = "ready" ] \
    || fail "(17) a generating agy pane classifies '$_cls', not ready — the leader's rider is that it injects on the FIRST attempt, not after N"
  rm -f "$WORK/tmux/capture.sess_0_0"
) || exit 1
echo "courier-busy-hold: (17) a recognized modal, an unreadable pane and a generating pane are three different answers: ok"

# ---- (18) N=3 POST-DEADLINE LIVE OBSERVATIONS THEN INJECT (ruling 15 item 2) --------
# Ops watched the courier flash its warn at gemini-low-moderator repeatedly while she
# was mid-turn. She was not wedged, she was working. A readiness-gate park never sets
# `due` — that requires reason_class=busy — so it holds for as long as the band stays
# unreadable, which for a working seat is indefinitely. The hold was the tap-92v3r fix
# and it is only half an answer: not lying to the sender is not the same as delivering.
#
# THE BOUND IS 3 AND THE ARM PROVES BOTH SIDES OF IT. A force at 1 would be no bound at
# all; a force that never comes is today's defect. So the second probe must NOT deliver
# and the third must.
(
  set -euo pipefail
  reset_bus
  park_busy F1
  _dl="$(meta_field F1 deadline_epoch)"
  [ -n "$_dl" ] || fail "(18) fixture premise: F1 has no deadline_epoch, so there is no post-deadline observation to count"
  _past=$(( _dl + 60 ))
  drain "$_past"
  injected F1 && fail "(18) F1 delivered on the FIRST post-deadline look — the bound is 3 observations, and forcing on one is not a bound"
  [ "$(meta_field F1 busy_live_probes)" = 1 ] \
    || fail "(18) after one post-deadline live observation busy_live_probes is '$(meta_field F1 busy_live_probes)', not 1 — nothing durable is counting the looks, so the bound cannot be reached or audited"
  drain "$_past"
  injected F1 && fail "(18) F1 delivered on the SECOND look — N=3 is the ruling's number"
  drain "$_past"
  injected F1 \
    || fail "(18) F1 was NOT delivered after three post-deadline observations of a live, non-modal pane — this is Ops's P0: the seat is working, not wedged, and Antigravity queues input mid-generation"
  [ ! -f "$BUS/receipts/F1.cancelled" ] \
    || fail "(18) F1 was terminalized rather than forced — the sender is still being told a live seat is unreachable"
) || exit 1
echo "courier-busy-hold: (18) three post-deadline live observations force the injection instead of holding forever: ok"

# ---- (19) A RECOGNIZED MODAL IS NEVER FORCED, AT ANY N -----------------------------
# The one hold ruling 15 leaves standing. Without this arm "be more aggressive" has no
# floor and the next change types over a human's pending decision.
#
# HONEST ABOUT WHAT IT PROVES: this property is trivially true before the force path
# exists, because nothing forces at all. Its value is entirely as a guard on the change
# in arm 18, so it is mutation-proven against that path rather than against BASE.
#
# AND ONE MUTATION RESULT WORTH CARRYING, because it says what this arm does NOT show.
# Three places refuse to force on a modal — the probe counter, the drain's second look,
# and the submit gate. Removing the counter exclusion reds this arm's busy_live_probes
# assertion. Removing EITHER of the other two alone reds nothing, because the remaining
# two still refuse; removing all three reds the injection assertion below with its own
# message. So this arm covers the property and does not pin the individual guards, and a
# reader who mutates one of them and sees green has found redundancy rather than dead
# code. lib.sh records the same fact at the re-validation site.
(
  set -euo pipefail
  reset_bus
  export FAKE_TMUX_CMD=agy
  set_peer_harness agy
  park_busy M1
  _rule="$(printf '─%.0s' $(seq 1 60))"
  printf '%s\n' "  working" "$_rule" "> " "$_rule" \
                "Requesting permission for: run_shell_command" \
                "Do you want to proceed?" "Yes · No · Tab amend" > "$WORK/tmux/capture.sess_0_0"
  _dl="$(meta_field M1 deadline_epoch)"; _past=$(( _dl + 60 ))
  for _i in 1 2 3 4 5; do drain "$_past"; done
  injected M1 \
    && fail "(19) a payload was typed into a pane showing a permission dialog, after five post-deadline looks — the modal is the only hold the ruling leaves, and the bound swallowed it"
  [ ! -f "$BUS/receipts/M1.cancelled" ] \
    || fail "(19) a held modal entry was terminalized — a modal holds WITH A REASON and is retried; it is never a delivery-failed"
  [ "$(meta_field M1 busy_live_probes)" = "" ] || [ "$(meta_field M1 busy_live_probes)" = 0 ] \
    || fail "(19) modal observations accumulated busy_live_probes='$(meta_field M1 busy_live_probes)' — a class that can never force must not bank credit toward forcing, or removing the modal at look four forces immediately"
  rm -f "$WORK/tmux/capture.sess_0_0"
) || exit 1
echo "courier-busy-hold: (19) a recognized modal holds at every N and is never terminalized: ok"

# ---- (20) THE COUNTER MEANS WHAT ITS NAME SAYS -------------------------------------
# `busy_live_probes` authorizes forcing, so every way of inflating it is a way of
# forcing early. Three inflations are refused here, and each one was reachable:
#   (a) a PRE-deadline look. The entry is inside its normal wait; counting those spends
#       the bound before the deadline the bound is measured from.
#   (b) `busy_pending_probes` is NOT widened. It counts typed-text wedges and feeds the
#       backlog CONDITION; merging the two would make a wedge report fire on ordinary
#       mid-suite traffic, and make a wedge authorize a force.
#   (c) a departed seat. `gone` is terminal — forcing at a pane that is not there is
#       typing into whatever took the pane id.
#
# THIS ARM IS GREEN BEFORE THE COUNTER EXISTS, and that is worth stating rather than
# leaving for a reader to discover. Every assertion here is a negative — "this did not
# move" — and an absent field satisfies all three for free. So a RED->GREEN transition
# proves nothing about it, and its three halves are mutation-proven individually against
# the increment site instead: each mutation that widens the counter must red the half
# that names that widening, and a mutation that reds a DIFFERENT half means the arm is
# not measuring what its message says.
(
  set -euo pipefail
  reset_bus
  park_busy C1
  _dl="$(meta_field C1 deadline_epoch)"
  drain "$(( _dl - 30 ))"
  [ "$(meta_field C1 busy_live_probes)" = "" ] || [ "$(meta_field C1 busy_live_probes)" = 0 ] \
    || fail "(20a) a PRE-deadline look incremented busy_live_probes to '$(meta_field C1 busy_live_probes)' — the bound is three POST-deadline observations, and counting the ordinary wait spends it before the clock starts"

  # (b) the wedge counter is a different question and must not have moved.
  _past=$(( _dl + 60 )); drain "$_past"
  [ "$(meta_field C1 busy_pending_probes)" = "" ] || [ "$(meta_field C1 busy_pending_probes)" = 0 ] \
    || fail "(20b) busy_pending_probes moved to '$(meta_field C1 busy_pending_probes)' on a busy:noprompt look — the wedge counter deliberately ignores that class, and widening it makes the backlog condition fire on healthy mid-suite traffic"

  # (c) a departed seat never accumulates, however many times it is looked at.
  reset_bus
  park_busy G1
  _dl="$(meta_field G1 deadline_epoch)"; _past=$(( _dl + 60 ))
  python3 -B - "$BUS/registry.json" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p))
d["agents"]["peer"]["status"] = "retired"
json.dump(d, open(p, "w"))
PY
  drain "$_past"; drain "$_past"; drain "$_past"; drain "$_past"
  injected G1 \
    && fail "(20c) a payload was typed at a pane whose seat has left the roster — 'gone' is terminal, and forcing there types into whatever now holds that pane id"
  [ "$(meta_field G1 busy_live_probes)" = "" ] || [ "$(meta_field G1 busy_live_probes)" = 0 ] \
    || fail "(20c) a departed seat accumulated busy_live_probes='$(meta_field G1 busy_live_probes)' — only a LIVE observation may pay toward the bound"
) || exit 1
echo "courier-busy-hold: (20) busy_live_probes counts only post-deadline live looks, and does not widen the wedge counter: ok"

# ---- (21) TERMINALIZATION VS RE-OWN, IN TWO ROWS -----------------------------------
# Codex thread lib.sh:1814, against a window this branch itself opened. Giving `.reown` an
# owner made `tap_spool_remove` take the entry meta lock, and `tap_spool_reown_after_repark`
# checks the payload OUTSIDE that lock — so a caller can pass the check and then wait on the
# lock while terminalization completes underneath it.
#
# TWO ROWS BECAUSE THERE ARE TWO INDEPENDENT DEFENSES, and one predicate cannot pin both.
# The claim's under-lock recheck and the child's inherited-token trap are complementary: with
# only the recheck removed the real child still releases, and with only the trap removed the
# recheck refuses to mint. So "no lease remains" is green under either single mutant and reds
# only under both, which makes it a fine combined control and a useless discriminator. Each
# fix gets a row that reds when that fix alone is removed.
#
# THE FIRST VERSION OF THIS ARM PROVED NOTHING, and the reason is worth keeping: this file
# exports `TAP_SPOOL_DISABLE_DELIVERER=1` GLOBALLY at the top, and the arm's own
# `export TAP_SPOOL_DISABLE_OPPORTUNISTIC=1` did not unset it. No child ever spawned;
# `tap_spool_spawn_deliverer` took its suppression branch and released the token itself
# (lib.sh), tidying away the very leak the arm was watching for. Both mutants passed. A
# determinism knob is a code path, not a neutral setting.
(
  set -euo pipefail
  # `reset_bus` FIRST, because this arm seeds its own registry from the shared one and arm
  # 20c retires `peer` there to prove a departed seat never accumulates. Without this the
  # copy carries that retirement and every send here refuses `handle_missing_or_inactive` —
  # which passes in isolation and fails in the file, the least useful way for an arm to be
  # wrong.
  reset_bus
  DR="$(mktemp -d)"; mkdir -p "$DR/tmux" "$DR/repo"
  trap 'rm -rf "$DR" 2>/dev/null || true' EXIT
  export FAKE_TMUX_STATE="$DR/tmux" FAKE_WORKTREE="$DR/repo"
  BUSR="$DR/repo/.tap/bus"; mkdir -p "$BUSR/payloads" "$BUSR/receipts" "$BUSR/spool"
  export TAP_HOME="$BUSR"
  sed "s|$WORK/repo|$DR/repo|g" "$BUS/registry.json" > "$BUSR/registry.json"

  # ---- ROW 1: the CLAIM must not mint for an entry terminalized under the lock ----------
  # Deliverer suppression is OFF for this row, so the production suppression branch cannot
  # release the lease on the arm's behalf. Spawn issuance is stubbed instead: the stub
  # RECORDS and does nothing, so nothing cleans up and the assertion sees what the claim
  # actually left behind. `tap_reown_claim`, the meta lock and the removals stay real.
  unset TAP_SPOOL_DISABLE_DELIVERER
  touch "$DR/tmux/busy.sess_0_0"   # park it: an idle band delivers instead, and there is no race
  TAP_SPOOL_DISABLE_DELIVERER=1 bash "$TAPSH" send peer -m "race body" --id X1 --from alice --wake \
    >"$DR/s.out" 2>&1 || true
  [ -f "$BUSR/spool/X1.md" ] || fail "(21) fixture premise: X1 did not park; send said: $(cat "$DR/s.out")"
  _meta="$BUSR/spool/X1.meta.json"
  : > "$DR/spawns"
  tap_spool_spawn_deliverer() { printf '%s %s\n' "$1" "${TAP_SPOOL_REOWN_TOKEN:-none}" >> "$DR/spawns"; return 0; }

  # A helper holds the lock and signals it; re-own is started while it is held, so re-own is
  # PROVABLY parked on the lock rather than coincidentally slow; the helper then performs
  # terminalization's three removals and releases. Ordering is a property of the fixture, not
  # the scheduler, so this row cannot pass by the race failing to happen. The helper does the
  # removals directly rather than calling `tap_spool_remove`, which takes this same lock —
  # the bytes under test are the CLAIM's recheck, not remove's.
  python3 -B - "$_meta" "$DR/held" "$DR/go" <<'PY' &
import fcntl, os, sys, time
meta, held, go = sys.argv[1], sys.argv[2], sys.argv[3]
with open(meta + ".lock", "w") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    open(held, "w").close()
    deadline = time.time() + 20
    while not os.path.exists(go) and time.time() < deadline:
        time.sleep(0.02)
    for p in (meta[:-len(".meta.json")] + ".md", meta, meta + ".reown"):
        try: os.unlink(p)
        except OSError: pass
PY
  _helper=$!
  for _ in $(seq 1 200); do [ -f "$DR/held" ] && break; command sleep 0.05; done
  [ -f "$DR/held" ] || { kill "$_helper" 2>/dev/null || true; fail "(21) fixture premise: the helper never took the meta lock, so nothing was serialized"; }

  # THE RACED CALL IS `tap_reown_claim` ITSELF, not the whole re-own path, and that is a
  # deliberate narrowing after the first version failed to discriminate. Driving
  # `tap_spool_reown_after_repark` made the row depend on a 0.5s guess that its multi-step
  # prologue (payload stat, dirname readability) would reach the lock before the helper was
  # released — measured, and it did not: under the mutation the raced call returned at its
  # OUTER payload check having never claimed, so the row went green while a direct claim on
  # the same tree minted a token. Claim's first act is to open and flock, so aiming at it
  # makes "is it parked on the lock" true by construction rather than by timing.
  #
  # X1 is fully resident at this instant, which is what makes the window real.
  ( tap_reown_claim X1 >"$DR/claimed" 2>/dev/null ) &
  _reown=$!
  command sleep 0.5
  : > "$DR/go"
  wait "$_helper" 2>/dev/null || true
  wait "$_reown" 2>/dev/null || true

  # The outer path is still checked, on the terminalized entry: it must issue no spawn.
  tap_spool_reown_after_repark X1 >/dev/null 2>&1 || true

  [ ! -f "$BUSR/spool/X1.md" ] \
    || fail "(21.1) fixture premise: X1 still resident after the helper's removals, so terminalization did not win the window and this row tested nothing"
  [ ! -s "$DR/claimed" ] \
    || fail "(21.1) the claim MINTED a token ($(cat "$DR/claimed")) for an entry that terminalized while it waited on the lock — the under-lock payload recheck is what refuses it, and without that recheck the outer check is authority it cannot be"
  [ ! -f "$_meta.reown" ] \
    || fail "(21.1) a .reown lease survives for a terminalized entry — it names an owner that does not exist and nothing will reap it"
  [ ! -s "$DR/spawns" ] \
    || fail "(21.1) re-own issued a spawn for an entry that no longer exists ($(cat "$DR/spawns")) — a deliverer for a dead id, which exits at its first payload check having done nothing"
  unset -f tap_spool_spawn_deliverer

  # ---- ROW 2: a child that INHERITED a token releases it, whatever class it decides ------
  # Seeded directly rather than raced: the state this row is about is "a real deliverer starts
  # holding a token for an entry that is already gone", and constructing that state is more
  # honest than winning a race to reach it. `_held_class` reads metadata that is absent here,
  # so a trap armed inside that branch never arms — which is exactly the defect.
  _tok="row2token$$"
  _m2="$BUSR/spool/X2.meta.json"
  printf '%s' "$_tok" > "$_m2.reown"
  [ ! -f "$BUSR/spool/X2.md" ] && [ ! -f "$_m2" ] \
    || fail "(21.2) fixture premise: X2 payload or meta exists, so the child would not take the terminalized path this row is about"
  TAP_SPOOL_REOWN_TOKEN="$_tok" \
    bun "$ROOT/runtime/bun/src/spool-waiter.ts" X2 >/dev/null 2>&1 || true
  [ ! -f "$_m2.reown" ] \
    || fail "(21.2) an inherited-token child exited without releasing its lease — its metadata is gone so _held_class is false, and a release armed inside that branch never arms; this is the permanent sidecar leak arm 13 closes, reached through a terminalized entry"
) || exit 1
echo "courier-busy-hold: (21) re-own mints no lease for an entry terminalized under the lock, and an inherited-token child releases on exit: ok"

# ---- (22) THE LIVE-PROBE COUNTER IS SERIALIZED (tap-92v3r U2c) ---------------------
# Codex thread `lib.sh:2262`: `tap_spool_note_live_probe` reads the meta, adds one,
# writes a temp file and `os.replace`s it — with no lock, while `tap_reown_claim` takes
# `meta + ".lock"` for its own compare-and-write. Two drains observing the same busy pane
# can each read N and each write N+1, so the counter that AUTHORIZES A FORCED INJECT
# undercounts silently. Undercounting only delays a force; the reason this is worth
# arming is the other direction — the fix must not be able to over-count either, and a
# lock is what makes both directions unavailable.
#
# BOUNDED WAIT, FAIL-CLOSED SKIP — not an unbounded block. Opportunistic drains run at
# the start of ordinary sends, so an unbounded block inside the drain would make every
# `tap send` hostage to whoever holds a meta lock: a wedged holder turns the courier into
# a hang, which is strictly worse than a missed count. The two error directions are not
# symmetric either — a skipped increment delays the force by one drain, a double
# increment forces early into a live pane. Ruling 15 item 3 is fail-closed by design.
#
# WHY THE COUNTER IS THE ONLY ADMISSIBLE OBSERVABLE: the python is invoked
# `2>/dev/null || true`, so a flock failure is silent and neither rc nor stderr can be
# asserted. An arm that watched for an error message would be green against a lock that
# never engaged.
#
# DETERMINISTIC IN BOTH DIRECTIONS, and free of timing races: the lock is HELD by a
# background process for the whole of the contended call, so "did it wait" is not a
# question about scheduling. Under the fix the call reaches its deadline and the counter
# is UNCHANGED; under the unlocked code it takes the file immediately and the counter is
# +1. The knob keeps the contended call short so GREEN does not pay the production wait.
(
  set -euo pipefail
  export TAP_SPOOL_DISABLE_DELIVERER=1
  [ "$(tap_spool_probe_lock_timeout)" = 0.5 ] \
    || fail "(22) the live-probe lock default is $(tap_spool_probe_lock_timeout)s, not 0.5s — eight capped entries can spend most of the 20s re-own lease waiting before U2e exists"
  D22="$(mktemp -d)"; mkdir -p "$D22/tmux" "$D22/repo"
  _holder=""
  cleanup22() {
    # Only the pid this arm started, never a pattern (.claude/rules/no-pattern-kills.md).
    if [ -n "$_holder" ]; then kill "$_holder" 2>/dev/null || true; wait "$_holder" 2>/dev/null || true; fi
    rm -rf "$D22" 2>/dev/null || true
  }
  trap cleanup22 EXIT
  export FAKE_TMUX_STATE="$D22/tmux" FAKE_WORKTREE="$D22/repo"
  BUS22="$D22/repo/.tap/bus"; mkdir -p "$BUS22/payloads" "$BUS22/receipts" "$BUS22/spool"
  export TAP_HOME="$BUS22"
  sed "s|$WORK/repo|$D22/repo|g" "$BUS/registry.json" > "$BUS22/registry.json"
  : > "$D22/tmux/send-keys.log"

  touch "$D22/tmux/busy.sess_0_0"
  bash "$TAPSH" send peer -m "probe counter" --id P1 --from alice >"$D22/s.out" 2>&1 || true
  [ -f "$BUS22/spool/P1.meta.json" ] || fail "(22) P1 did not park; send said: $(cat "$D22/s.out")"

  _probes() { bash -c 'set -euo pipefail; . "$1"; tap_spool_live_probes P1' _ "$ROOT/skills/tap/scripts/lib.sh"; }
  _note()   { bash -c 'set -euo pipefail; . "$1"; tap_spool_note_live_probe P1 busy:noprompt' _ "$ROOT/skills/tap/scripts/lib.sh"; }

  # An uncontended call must still count, or the arm below would pass on a function that
  # never increments at all — the cheapest false green available here.
  _base="$(_probes)"
  _note
  [ "$(_probes)" = "$(( _base + 1 ))" ] \
    || fail "(22) precondition: an UNCONTENDED tap_spool_note_live_probe did not increment (base=$_base now=$(_probes)) — the contended assertion below would be vacuous"

  # Hold meta + ".lock" for longer than the contended call's deadline. The holder writes a
  # ready file only AFTER the lock is held, so the foreground call cannot start early.
  python3 -B - "$BUS22/spool/P1.meta.json.lock" "$D22/held" <<'PY' &
import fcntl, os, sys, time
lock_path, ready = sys.argv[1], sys.argv[2]
fh = open(lock_path, "w")
fcntl.flock(fh, fcntl.LOCK_EX)
open(ready, "w").close()
time.sleep(10)
PY
  _holder=$!
  _spin=0
  while [ ! -f "$D22/held" ]; do
    _spin=$(( _spin + 1 ))
    [ "$_spin" -gt 200 ] && fail "(22) the background lock holder never acquired meta.lock"
    sleep 0.05
  done

  _before="$(_probes)"
  TAP_SPOOL_PROBE_LOCK_TIMEOUT=0.3 _note
  _after="$(_probes)"
  [ "$_after" = "$_before" ] \
    || fail "(22) the counter moved ($_before -> $_after) while another process held meta.lock — the read-modify-write at lib.sh:2259-2270 is unserialized, so two drains can each read N and each write N+1"

  kill "$_holder" 2>/dev/null || true; wait "$_holder" 2>/dev/null || true; _holder=""

  # THE OTHER HALF, and it is what stops the fix from being "never count again": once the
  # lock is free the very same call counts. A fail-closed skip that became permanent would
  # pass the assertion above and break the force bound entirely.
  _note
  [ "$(_probes)" = "$(( _before + 1 ))" ] \
    || fail "(22) the counter did not resume after the lock was released (expected $(( _before + 1 )), got $(_probes)) — the skip is not bounded to the contended call"
) || exit 1
echo "courier-busy-hold: (22) the live-probe counter serializes on the entry's meta lock, skips fail-closed under contention, and resumes when it frees: ok"

# ---- (23) THE MODAL MATCH IS DIALOG CHROME, NOT TWO PHRASES ANYWHERE (tap-92v3r U2b) --
# Codex thread `lib.sh:9472`: the scan covered the whole post-band region for
# `requesting permission for:` and (`do you want to proceed?` or `tab amend`), in any
# order and at any distance. `busy:modal` is the ONE class that holds indefinitely and is
# never forced, so anything that lands both phrases below the band parks a live seat's
# mail forever.
#
# THE RED IS A REAL CAPTURE, not a constructed shape. `tool-running-254.txt` is a live
# 2026-09-03 pane; the two card rows below are inserted HERE, in the arm, so the
# insertion is visible rather than baked into a fixture that a later reader would take
# for a capture of a modal. They are what a person actually produces — two ordinary
# shell commands echoed by agy's running-task card.
#
# WHY A CARD ROW IS THE RIGHT SURFACE TO EXCLUDE, and why that is not a narrowing that
# can hide a dialog: `● [HH:MM:SS] <command> running` echoes arbitrary user text, and the
# repo's own fixtures already prove it — `tool-running-254.txt:66` carries
# `bun test runtime/bun/test/team.test.ts` and `task-idle-footer-228.txt:91` carries a
# whole `bash -c ' set -euo pipefail …'`. A permission dialog is never drawn as a card
# row. Excluding cards removes the surface that carries foreign text and nothing else.
#
# THE WINDOW IS PROVISIONAL. It is calibrated against a CONSTRUCTED modal, because this
# fleet runs with permission prompts off and no capture of a real overlay exists;
# tap-lslrc owns that capture and re-setting this number from the real inter-phrase
# distance is one of its acceptance conditions. Both directions have a real failure mode
# and they are not symmetric: too narrow and a genuine overlay reads not-modal and the
# force bound types over a human's pending decision; too wide and this repo's own prose
# about the overlay holds mail forever. That is why (5) is in this set.
(
  set -euo pipefail
  CAPD="$ROOT/skills/tap/scripts/smoke/fixtures/agy-capture-20260903"
  _m() { tap_agy_permission_overlay; }
  _rule60="$(printf '─%.0s' $(seq 1 60))"

  # (a) THE DEFECT. A real captured pane plus two ordinary commands in its card rows.
  python3 -B - "$CAPD/tool-running-254.txt" "$WORK/u2b-red.txt" <<'PY'
import sys
src, dst = sys.argv[1], sys.argv[2]
out = []
for line in open(src, encoding="utf-8", errors="replace").read().split("\n"):
    if line.lstrip().startswith("\u25cf") and line.rstrip().endswith("running"):
        out.append('  \u25cf [00:46:23] echo "Requesting permission for: deploy" running')
        out.append('  \u25cf [00:46:24] grep -n "Do you want to proceed?" notes.md running')
        continue
    out.append(line)
open(dst, "w", encoding="utf-8").write("\n".join(out))
PY
  grep -q 'Requesting permission for' "$WORK/u2b-red.txt" \
    || fail "(23) precondition: the RED fixture carries no inserted phrase — the substitution missed the card row and the arm would pass on an unmodified capture"
  # `if cmd; then fail; fi` and never `cmd && fail`: under `set -e` a false `&&` list is
  # itself a failing statement, so the arm would exit silently on the outcome it wants.
  # Same form arm (16) uses.
  if _m < "$WORK/u2b-red.txt"; then fail "(23a) a live pane whose TASK CARD echoes the two phrases classified busy:modal — two ordinary shell commands park that seat's mail forever, and busy:modal is the one class nothing ever forces"; fi

  # (b0) DISTANCE ZERO IS STILL DOWNWARD. Some renderers may place the request and
  # confirmation on one chrome row. The recoverable error is holding that row; the
  # unrecoverable one is calling it injectable and typing over the pending decision.
  printf '%s\n' "  x" "$_rule60" "> " "$_rule60" \
      "Requesting permission for: run_shell_command — Do you want to proceed?" \
    | _m \
    || fail "(23b0) a same-line constructed permission modal is no longer recognised — distance zero fell through the directional window and became forceable"

  # (b) THE POSITIVE CONTROL, and this set exists because of it. Too narrow a
  # discriminator makes a real overlay read busy:noprompt, and the bound then types over
  # a human's pending decision. Constructed, and labelled constructed: tap-lslrc holds
  # the real capture (this fleet renders no permission modal).
  printf '%s\n' "  x" "$_rule60" "> " "$_rule60" \
      "Requesting permission for: run_shell_command" "Do you want to proceed?" "Yes · No · Tab amend" \
    | _m \
    || fail "(23b) the constructed permission modal is no longer recognised — the narrowing went too far and nothing now protects a pending human decision"

  # (c) THE SAFETY CASE. A genuine overlay while a task is ALSO running must still hold.
  # Card-skipping must remove the card, not the dialog beside it.
  printf '%s\n' "  x" "$_rule60" "> " "$_rule60" \
      "  ● [00:46:22] sleep 20 running" \
      "Requesting permission for: run_shell_command" "Do you want to proceed?" "Yes · No · Tab amend" \
    | _m \
    || fail "(23c) a real overlay stopped being recognised once a task card shared the region — skipping cards must not skip the dialog rendered beside one"

  # (d) and (e) — ONE PER NARROWING, because each covers the other's gap. (d) has the
  # phrases ADJACENT, so proximity alone would pass it and only card-skipping refuses it.
  # (e) has them far apart and NOT in cards, so card-skipping alone would pass it and only
  # proximity refuses it. Neither narrowing is redundant.
  printf '%s\n' "  x" "$_rule60" "> " "$_rule60" \
      "  ● [00:46:22] echo Requesting permission for: x running" \
      "  ● [00:46:23] echo Do you want to proceed? running" \
    | _m && _hit=1 || _hit=0
  if [ "$_hit" = 1 ]; then fail "(23d) two ADJACENT card rows still classify busy:modal — proximity alone does not refuse card text, so the card exclusion is doing no work"; fi
  printf '%s\n' "  x" "$_rule60" "> " "$_rule60" \
      "Requesting permission for: x" a b c d e f g "Do you want to proceed?" \
    | _m && _hit=1 || _hit=0
  if [ "$_hit" = 1 ]; then fail "(23e) phrases eight lines apart in ordinary prose still classify busy:modal — the card exclusion alone does not refuse prose, so the proximity window is doing no work"; fi

  # (f) DIRECTIONAL. A real overlay always draws the request before the confirm; foreign
  # prose carries them in either order. Refusing the reverse order costs nothing on the
  # side that matters.
  printf '%s\n' "  x" "$_rule60" "> " "$_rule60" "Do you want to proceed?" "Requesting permission for: x" \
    | _m && _hit=1 || _hit=0
  if [ "$_hit" = 1 ]; then fail "(23f) the confirm ABOVE the request still classifies busy:modal — the match is not directional"; fi

  # (g) NO REAL CAPTURE REGRESSES. Every shape this repo actually holds stays not-modal.
  for _f in generating-243 generating-taskcard-243 idle-243 task-idle-footer-228 tool-running-254 draft-262; do
    if _m < "$CAPD/$_f.txt"; then fail "(23g) $_f.txt now classifies busy:modal — a real captured pane with no dialog on it would be held forever"; fi
  done
) || exit 1
echo "courier-busy-hold: (23) the modal match is dialog chrome — card rows excluded, proximity required, direction enforced, and a real overlay beside a task card still holds: ok"

# ---- (24) THE HELD-ENTRY REFUND IS BOUNDED (tap-92v3r U2a) --------------------------
# A drain has two readiness passes: Phase A necessarily probes every spooled entry,
# while Phase B is the cap-governed work pass. A fixed probe ceiling would therefore
# measure the backlog as much as the refund. Calibrate that irreducible term with a
# pre-deadline pass, where Phase B is capped, then compare the same 6-to-12 backlog
# growth after every entry is held. A bounded refund leaves the two deltas equal; an
# unconditional refund makes Phase B scale too.
(
  set -euo pipefail
  # Keep the force threshold above every measured pass so held entries cannot turn
  # into deliveries midway through the probe relation.
  export TAP_SPOOL_DRAIN_CAP=2 TAP_SPOOL_FORCE_PROBES=1000

  measure_backlog() { # <entry-count>
    local count="$1" i id now first_deadline=0 last_deadline=0 probes=0 held=0 live
    reset_bus
    for i in $(seq 1 "$count"); do
      id="u2a-${count}-${i}"
      park_busy "$id"
      now="$(meta_field "$id" deadline_epoch)"
      { [ "$first_deadline" -eq 0 ] || [ "$now" -lt "$first_deadline" ]; } && first_deadline="$now"
      [ "$now" -gt "$last_deadline" ] && last_deadline="$now"
    done

    # Before every deadline, no entry can refund. This measures Phase A's unavoidable
    # backlog scaling plus the constant cap-governed Phase B work.
    FAKE_TMUX_PROBE_LOG="$WORK/u2a-${count}.early.probes"; export FAKE_TMUX_PROBE_LOG
    : > "$FAKE_TMUX_PROBE_LOG"
    TAP_SPOOL_NOW="$((first_deadline - 1))" bash -c 'set -euo pipefail; . "$1"; tap_spool_drain_once' \
      _ "$LIB" >/dev/null 2>&1 || true
    U2A_EARLY_PROBES="$(wc -l < "$FAKE_TMUX_PROBE_LOG" | tr -d ' ')"

    now=$((last_deadline + 1))
    U2A_NOW="$now"

    FAKE_TMUX_PROBE_LOG="$WORK/u2a-${count}.held.probes"; export FAKE_TMUX_PROBE_LOG
    : > "$FAKE_TMUX_PROBE_LOG"
    TAP_SPOOL_NOW="$now" bash -c 'set -euo pipefail; . "$1"; tap_spool_drain_once' \
      _ "$LIB" >/dev/null 2>&1 || true
    probes="$(wc -l < "$FAKE_TMUX_PROBE_LOG" | tr -d ' ')"
    unset FAKE_TMUX_PROBE_LOG

    for i in $(seq 1 "$count"); do
      id="u2a-${count}-${i}"
      live="$(meta_field "$id" busy_live_probes)"
      [ -n "$live" ] || live=0
      if [ -f "$BUS/spool/$id.md" ] && [ "$(meta_field "$id" deadline_source)" = readiness-gate ] \
         && [ "$(meta_field "$id" deadline_epoch)" -le "$now" ] && [ "$live" -ge 1 ]; then
        held=$((held + 1))
      fi
    done
    U2A_HELD_PROBES="$probes"
    U2A_HELD="$held"
  }

  measure_backlog 6
  early6="$U2A_EARLY_PROBES"; probes6="$U2A_HELD_PROBES"; held6="$U2A_HELD"
  [ "$held6" -gt 1 ] \
    || fail "(24) premise: only $held6 of 6 entries reached the post-deadline held path — the refund bound is not exercised"

  measure_backlog 12
  early12="$U2A_EARLY_PROBES"; probes12="$U2A_HELD_PROBES"; held12="$U2A_HELD"
  [ "$held12" -gt 1 ] \
    || fail "(24) premise: only $held12 of 12 entries reached the post-deadline held path — the refund bound is not exercised"

  baseline_delta=$((early12 - early6))
  held_delta=$((probes12 - probes6))
  [ "$baseline_delta" -gt 0 ] \
    || fail "(24) premise: pre-deadline backlog growth produced no readiness-probe delta ($early6 -> $early12), so the Phase-A calibration is vacuous"
  [ "$held_delta" -eq "$baseline_delta" ] \
    || fail "(24) growing the backlog 6 -> 12 added $held_delta probes once fully held ($probes6 -> $probes12), versus the calibrated pre-deadline delta $baseline_delta ($early6 -> $early12) — the refund made Phase B scale beyond its cap"

  # Bounded work must rotate, not pin every later drain to the same oldest prefix.
  # Find one entry the first held pass did not reach, then require the next pass to
  # reach it. Otherwise the bound trades an expensive drain for permanent starvation.
  missed=""
  for i in $(seq 1 12); do
    id="u2a-12-${i}"
    live="$(meta_field "$id" busy_live_probes)"; [ -n "$live" ] || live=0
    if [ "$live" -eq 0 ]; then missed="$id"; break; fi
  done
  [ -n "$missed" ] \
    || fail "(24) premise: the bounded held pass left no deferred entry, so next-drain fairness is not exercised"
  marked=0
  for i in $(seq 1 12); do
    visits="$(meta_field "u2a-12-${i}" held_drain_visits)"; [ -n "$visits" ] || visits=0
    [ "$visits" -gt 0 ] && { marked=1; break; }
  done
  [ "$marked" -eq 1 ] \
    || fail "(24) fairness mark never advanced for a visited held entry — the ordering has no durable round to read"
  before="$(meta_field "$missed" busy_live_probes)"; [ -n "$before" ] || before=0
  TAP_SPOOL_NOW="$U2A_NOW" bash -c 'set -euo pipefail; . "$1"; tap_spool_drain_once' \
    _ "$LIB" >/dev/null 2>&1 || true
  after="$(meta_field "$missed" busy_live_probes)"; [ -n "$after" ] || after=0
  [ "$after" -gt "$before" ] \
    || fail "(24) $missed missed the bounded first pass and still was not retried on the next drain — the refund budget starves the backlog behind the oldest prefix"

  # A fairness mark belongs to the HELD state, not to the entry forever. Make the
  # oldest entry accumulate a mark, then free its pane and put exactly `cap` fresh
  # ready entries ahead of it under the visit-count sort. The Phase A readiness pass
  # sees the whole spool, so it must clear the stale mark before Phase B applies its
  # cap; otherwise sustained cap-sized arrivals can starve the now-deliverable old id.
  reset_bus
  park_busy u2a-mixed-0-old
  old_now="$(past_deadline u2a-mixed-0-old)"
  drain "$old_now"
  old_visits="$(meta_field u2a-mixed-0-old held_drain_visits)"; [ -n "$old_visits" ] || old_visits=0
  [ "$old_visits" -gt 0 ] \
    || fail "(24) mixed-state premise: the old held entry acquired no visit mark, so a permanent penalty is not exercised"

  park_busy u2a-mixed-1-fresh
  park_busy u2a-mixed-2-fresh
  # Keep the two fresh entries out of digest planning. The old standard entry remains
  # Phase A's sole ready candidate, which is exactly where its stale mark is cleared.
  python3 -B - "$BUS/spool/u2a-mixed-1-fresh.meta.json" "$BUS/spool/u2a-mixed-2-fresh.meta.json" <<'PY'
import json, os, sys, tempfile
for path in sys.argv[1:]:
    meta = json.load(open(path, encoding="utf-8"))
    meta["policy"] = "urgent"
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".tap-u2a-policy-")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2, sort_keys=True)
        fh.write("\n")
    os.replace(tmp, path)
PY
  rm -f "$WORK/tmux/busy.sess_0_0"
  : > "$LOG"
  drain "$old_now"
  [ ! -f "$BUS/spool/u2a-mixed-0-old.md" ] && injected u2a-mixed-0-old \
    || fail "(24) a formerly-held old entry stayed behind a full cap of fresh ready mail — its visit mark became a permanent starvation penalty"
  echo "courier-busy-hold: (24 evidence) bounded refund: early $early6->$early12, held $probes6->$probes12"
) || exit 1
echo "courier-busy-hold: (24) deferred held mail rotates, and a freed old entry sheds its mark before fresh mail can starve it: ok"
echo "courier-busy-hold: ok"
