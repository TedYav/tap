"""Per-seat clearing fence, WRITER half: flock serializes writers to the marker.

The read half is `runtime/bun/src/clear-fence.ts`. It reads this file WITHOUT
taking the lock, which is why it could move on its own: a version that treats
lock-held as the fence looks identical in every green test and fails when a
holder dies — kernel release would look like "not clearing" while the pane is
still mid-restart. Age vs the family await ceiling is the courier's question.
Pid death is not.

What stays here is the LIFETIME, and it stays because it cannot survive a
subprocess: the lock is on the marker INODE and is held across
stamp -> respawn -> await, released by truncating in place. `fence_path` stays
with it so writer and reader agree on which file that is.
"""
from __future__ import annotations

import datetime
import fcntl
import json
import os
import pathlib
import time
from typing import Any


class HeldFence:
    """Exclusive flock on the marker file, held across stamp→respawn→await."""

    def __init__(self, fh, path: pathlib.Path, rec: dict[str, Any]):
        self._fh = fh
        self.path = path
        self.rec = rec
        self._released = False

    def release(self) -> None:
        """Drop the clearing claim, then the lock.

        Truncate in place — do not unlink. Unlink would let a second clearer
        create a new inode and acquire while this fd still holds the old one.
        """
        if self._released:
            return
        try:
            self._fh.seek(0)
            self._fh.truncate(0)
            self._fh.flush()
            os.fsync(self._fh.fileno())
        finally:
            self._fh.close()
            self._released = True


def fence_path(bus_dir: str | os.PathLike[str], handle: str) -> pathlib.Path:
    handle = (handle or "").strip()
    if "/" in handle:
        handle = handle.rsplit("/", 1)[-1]
    return pathlib.Path(bus_dir) / "clear-fence" / f"{handle}.json"


def try_acquire(
    bus_dir: str | os.PathLike[str],
    handle: str,
    nonce: str,
    pid: int,
    harness: str,
    ceiling_seconds: float,
) -> HeldFence | None:
    """LOCK_NB. On contention return None (caller emits clear_in_progress)."""
    path = fence_path(bus_dir, handle)
    path.parent.mkdir(parents=True, exist_ok=True)
    fh = open(path, "a+", encoding="utf-8")
    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        fh.close()
        return None
    now_dt = datetime.datetime.now(datetime.timezone.utc)
    rec = {
        "nonce": nonce,
        "since": now_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "since_epoch": now_dt.timestamp(),
        "pid": int(pid),
        "handle": handle.rsplit("/", 1)[-1] if "/" in handle else handle,
        "harness": harness or "",
        "ceiling_seconds": float(ceiling_seconds),
    }
    fh.seek(0)
    fh.truncate(0)
    fh.write(json.dumps(rec, separators=(",", ":")))
    fh.flush()
    os.fsync(fh.fileno())
    return HeldFence(fh, path, rec)
