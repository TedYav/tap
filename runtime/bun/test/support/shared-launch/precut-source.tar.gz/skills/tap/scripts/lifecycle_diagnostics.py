"""Opt-in file-only lifecycle diagnostics. No collector and no tmux tracing."""
import datetime
import json
import os
from pathlib import Path
import sys
import subprocess

import _startup_trace_bridge as startup_trace

_active = False
_configured = None


def configured():
    global _configured
    if _configured is not None:
        return _configured
    _configured = False
    try:
        path = Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'tap/config.toml'
        try:
            import tomllib
            _configured = tomllib.loads(path.read_text()).get('diagnostics', {}).get('level') == 'verbose'
        except ImportError:
            result = subprocess.run(["bun", "-e", "console.log(JSON.stringify(Bun.TOML.parse(await Bun.file(process.argv[1]).text()).diagnostics?.level === 'verbose'))", str(path)], capture_output=True, text=True, timeout=2)
            _configured = result.returncode == 0 and result.stdout.strip() == "true"
    except (OSError, ValueError, AttributeError, subprocess.SubprocessError):
        pass
    return _configured


def begin():
    global _active
    _active = configured()
    if _active:
        emit('diagnostics_start', rotate=True, console=False, tmux_trace=False)


def finish():
    global _active
    _active = False


def active():
    return _active


def emit(event, *, rotate=False, **fields):
    if not _active:
        return
    try:
        # Explicit console -v may capture the pane, but that content can contain
        # prompts. File diagnostics retain only structured probe metadata.
        if event in ("pane_failure", "pane_output"):
            fields = {key: value for key, value in fields.items() if key in ("target", "status", "command")}
        startup_trace.diagnostic(
            {'schema': 1, 'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'pid': os.getpid(), 'event': event, **fields}, rotate=rotate)
    except Exception:
        pass


if __name__ == '__main__':
    # Bun has already evaluated the same config, including Python 3.10 hosts.
    try:
        data = json.load(sys.stdin)
        if data.pop('enabled', False) is True:
            _active = True
            emit(**data)
    except Exception:
        pass
