"""The launcher's dependency-light resolver leaf: handle mapping, worktree root
and acting-registry resolution, and the canonical harness set.

``launcher.py`` re-exports everything here and ``presets.py`` reads
``HARNESSES``; nothing else imports this module. It is no longer a completion
leaf — the zsh completion producer (``tap session complete``) is native in
``runtime/bun/src/launcher/complete.ts`` and composes the runtime's own root,
index and registry readers. That producer offers a deliberate team-scoped
SUBSET of what ``tap session resume`` accepts, so the ONE-DIRECTIONAL contract
still holds: completion never offers a handle ``resume`` would reject.

``tap_registry_path``/``root_for_cwd`` are how ``resume`` itself resolves things
(``tap_registry_path`` under the worktree root; env ``TAP_HOME`` is NOT honored,
exactly as the launcher does not honor it). Nothing here writes, and only
``run_git_probe`` touches git (a read-only rev-parse).
"""

from __future__ import annotations

import dataclasses
import pathlib
import re
import subprocess
import sys

# Import-cheap leaf stays light: registry_v20 supplies the flip-marker registry
# resolution only (no launcher). Path insert matches launcher’s scripts/ root.
_SCRIPTS_DIR = pathlib.Path(__file__).resolve().parent.parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))
import registry_v20  # noqa: E402

# The canonical harness set. Defined here (the import-cheap leaf) so launcher.py
# and presets.py read the same source — the zsh `launch <TAB>` list is
# interpolated from this at generation, so it cannot drift from what the
# launcher accepts. The native producer's `harnesses` kind reads the runtime's
# catalog.HARNESSES; launcher-complete.test.ts pins the two sets equal.
HARNESSES = {"claude", "codex", "opencode", "cursor", "hermes", "agy"}


def sanitize_component(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "-", value.strip())
    cleaned = re.sub(r"-+", "-", cleaned).strip("-")
    return cleaned or "agent"


def slash_handle(name: str, base: str) -> str | None:
    prefix = f"{sanitize_component(base)}/"
    if name.startswith(prefix):
        handle = name[len(prefix):]
        return handle or None
    return None


def session_handle_fields(name, base, tag, harness, index) -> str:
    """The canonical name -> handle mapping, on primitive fields.

    ``launcher.session_handle(record)`` funnels through here so registry-backed
    records and in-memory records resolve to the identical handle.
    """
    slash = slash_handle(name, base)
    if slash:
        return slash
    handle = tag or harness
    if index and index > 1:
        handle = f"{handle}-{index}"
    return handle


def path_is_under(path: str, root: str) -> bool:
    try:
        pathlib.Path(path).resolve().relative_to(pathlib.Path(root).resolve())
        return True
    except ValueError:
        return False


# --- Path resolution (shared with launcher.py) -------------------------------
# These are the launcher's own resolution functions, homed in this import-cheap
# leaf; launcher.py re-exports them. Env TAP_HOME is deliberately NOT honored.


@dataclasses.dataclass
class GitProbe:
    inside: bool
    root: str | None = None
    git_dir: str | None = None
    common_dir: str | None = None


def _resolve_git_path(root: str, value: str) -> str:
    path = pathlib.Path(value)
    if not path.is_absolute():
        path = pathlib.Path(root) / path
    return str(path.resolve())


def run_git_probe(cwd: str) -> GitProbe:
    try:
        result = subprocess.run(
            ["git", "-C", cwd, "rev-parse", "--is-inside-work-tree", "--show-toplevel", "--git-dir", "--git-common-dir"],
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return GitProbe(False)

    lines = result.stdout.splitlines()
    if len(lines) < 4 or lines[0] != "true":
        return GitProbe(False)
    root = lines[1]
    return GitProbe(True, root=root, git_dir=_resolve_git_path(root, lines[2]), common_dir=_resolve_git_path(root, lines[3]))


def root_for_cwd(cwd: str, probe: GitProbe | None = None) -> str:
    probe = probe if probe is not None else run_git_probe(cwd)
    if probe.inside and probe.root:
        return str(pathlib.Path(probe.root).resolve())
    return str(pathlib.Path(cwd).resolve())


class RegistryAuthorityError(Exception):
    """Flip authority refused registry resolution (WAVE 6.5 / 3682216633).

    Raised by ``tap_registry_path`` for every non-``absent`` pathless live
    status (``invalid``, ``live_unreachable``, ``live_unenrolled``, …).
    Distinct from returning ``None``, which means genuine pre-flip absence.
    """

    def __init__(self, status: str):
        self.status = status
        super().__init__(f"registry authority refused ({status})")


def tap_registry_path(root: str):
    """Resolve the team's acting registry path.

    Return contract (WAVE 6.5 / 3682216633 + WAVE 6.6 / sol 114624Z):
      Path — resolvable acting (or pre-flip bus) registry that exists for readers
      None — genuine pre-flip absence ONLY
      raise RegistryAuthorityError — live/invalid refusal statuses, including
            ``live_unreachable`` and ``live_unenrolled``

    ``live_unreachable`` may carry a stored ``registry_location`` from
    ``resolve_team_registry_for_root`` so recovery writers (tap init) know where
    to recreate — but readers must still raise: the file is missing.
    """
    status, path = registry_v20.resolve_team_registry_for_root(root)
    if status == "live" and path:
        return pathlib.Path(path)
    if status == "absent":
        return pathlib.Path(path) if path else None
    # live_unreachable / live_unenrolled / invalid — authority refusal.
    # Do not return a stored-but-missing location to readers (tap-w3op / sol #xxx).
    raise RegistryAuthorityError(status)
