#!/usr/bin/env bash
# .81: late human text must not receive the courier's Enter or draft cleanup.
# Run through smoke-all --only; all pane operations below are a file-backed mock.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
export TAP_HOME="$WORK/bus" TAP_INDEX_HOME="$WORK/index"
export TAP_SPOOL_DISABLE_DELIVERER=1 TAP_TUI_SETTLE_SCALE=0
. "$ROOT/skills/tap/scripts/lib.sh"
tap_ensure_dirs
FIXTURE="$ROOT/skills/tap/scripts/smoke/fixtures/submit-verify/claude-draft-cursor-at-start.ansi"
FRAME="$WORK/frame"
failures=0
bad() { echo "draft-submit-boundary: FAIL $*" >&2; failures=$((failures + 1)); }
frame() {
  python3 -B - "$FIXTURE" "$FRAME" "$1" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
old='\x1b[7mh\x1b[0mello world draft'
assert old in s
Path(sys.argv[2]).write_text(s.replace(old,sys.argv[3]))
PY
}
reset_frame() {
  frame "$1"
  printf 0 > "$WORK/enters"
  : > "$WORK/keys"
  rm -f "${WORK:?}/late-second" "${WORK:?}/swallow-first" "${WORK:?}/late-first" "${WORK:?}/arm-after-inject" "${WORK:?}/capture-fail" "${WORK:?}/identity-flip" "${WORK:?}/pane-gone" "${WORK:?}/stale-redraw" "${WORK:?}/stale-paints"
  rm -rf "${WORK:?}/bus/input-backups"
}
# Identity is a fixed premise in this input-boundary control. Production readers,
# matching, submit loops and digest custody remain in use.
tap_submit_identity_guard() {
  if [ -f "$WORK/late-first" ]; then
    rm -f "$WORK/late-first"
    frame "S${sentinel}ou"
  fi
  return 0
}
tap_bound_pane_identity_state() { printf match; }
tap_pane_harness_command() { printf claude; }
tap_pane_alive() { printf '%%7'; }
tap_settle() {
  printf 'settle:%s\n' "$1" >> "$WORK/keys"
  if [ "$1" = 0.5 ] && [ -f "$WORK/late-second" ]; then
    frame S
  fi
}
tap_pane_effect_flash_body() { printf 'flash\n' >> "$WORK/keys"; }
# Model a transient second-read failure after the first read already observed
# a human draft. The shared door gets its own fresh production read.
eval "$(declare -f tap_pending_input_region_text | sed '1s/tap_pending_input_region_text/real_pending_input_region_text/')"
tap_pending_input_region_text() {
  if [ -f "$WORK/fail-next-region-read" ]; then
    rm -f "${WORK:?}/fail-next-region-read"
    return 3
  fi
  real_pending_input_region_text "$@"
}
# The clobber door's Bun effects spawn the LITERAL tmux binary through PATH, so
# the mock is a PATH script, not a shell function (the shape other smokes use):
# every arm below exercises the same bytes whether the caller is lib.sh or the
# door. Optional marker files arm the deterministic interleaves.
export TAP_MOCK_WORK="$WORK" TAP_MOCK_FRAME="$FRAME" TAP_MOCK_FIXTURE="$FIXTURE"
mkdir -p "$WORK/bin"
cat > "$WORK/bin/tmux" <<'MOCK'
#!/usr/bin/env bash
set -u
WORK="${TAP_MOCK_WORK:?}" FRAME="${TAP_MOCK_FRAME:?}" FIXTURE="${TAP_MOCK_FIXTURE:?}"
mock_frame() {
  python3 -B - "$FIXTURE" "$FRAME" "$1" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
old='\x1b[7mh\x1b[0mello world draft'
assert old in s
Path(sys.argv[2]).write_text(s.replace(old,sys.argv[3]))
PY
}
case "$1" in
  capture-pane)
    [ ! -f "$WORK/capture-fail" ] || exit 1
    # A delayed TUI repaint: while paints remain, every capture still shows the
    # stale pre-recovery frame; only then does the re-injected FRAME become
    # visible.
    if [ -f "$WORK/stale-paints" ]; then
      paints="$(cat "$WORK/stale-paints")"
      if [ "$paints" -gt 0 ]; then
        printf '%s' $((paints - 1)) > "$WORK/stale-paints"
        case " $* " in
          *' -e '*) cat "$WORK/stale-redraw" ;;
          *) python3 -B - "$WORK/stale-redraw" <<'PY'
import re,sys
print(re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',open(sys.argv[1]).read()),end='')
PY
          ;;
        esac
        exit 0
      fi
      rm -f "${WORK:?}/stale-paints"
    fi
    case " $* " in
      *' -e '*) cat "$FRAME" ;;
      *) python3 -B - "$FRAME" <<'PY'
import re,sys
print(re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',open(sys.argv[1]).read()),end='')
PY
      ;;
    esac ;;
  display-message)
    case "${@: -1}" in
      *pane_in_mode*) printf '0\n' ;;
      # The Bun reader's 4-field compound (pane_id, session, pid, command).
      *pane_id*pane_current_command*)
        [ ! -f "$WORK/pane-gone" ] || exit 1
        pid='%7'
        if [ -f "$WORK/identity-flip" ]; then
          flips=$(cat "$WORK/identity-flip" 2>/dev/null || echo 0)
          flips=$((flips + 1))
          printf '%s' "$flips" > "$WORK/identity-flip"
          # The band read carries no paneId comparison; the drift appears at
          # the SECOND pane observation — the clear loop's authorization,
          # which alone compares against the bound pane id.
          [ "$flips" = 2 ] && pid='%8'
        fi
        printf '%s\tsess\t4242\tclaude\n' "$pid" ;;
      # lib.sh's own observe compound keeps its historical 3 fields.
      *pane_id*session_name*) [ ! -f "$WORK/pane-gone" ] || exit 1; printf '%%7\tsess\t4242:100\n' ;;
      # The server-identity probe (no target): pid:start_time. Keep this after
      # compound records, whose final field contains the same expansion.
      *'#{pid}:#{start_time}'*) printf '4242:100\n' ;;
      *pane_id*)
        [ ! -f "$WORK/pane-gone" ] || exit 1
        pid='%7'
        if [ -f "$WORK/identity-flip" ]; then
          rm -f "${WORK:?}/identity-flip"
          pid='%8'
        fi
        printf '%s\n' "$pid" ;;
      *pane_current_command*) printf 'claude\n' ;;
      *pane_width*) printf '200\n' ;;
      *) printf 'sess\n' ;;
    esac ;;
  send-keys)
    printf '%s\n' "$*" >> "$WORK/keys"
    case "${@: -1}" in
      Enter)
        n=$(( $(cat "$WORK/enters") + 1 )); printf '%s' "$n" > "$WORK/enters"
        if [ "$n" != 1 ] || [ ! -f "$WORK/swallow-first" ]; then mock_frame ''; fi ;;
      C-u|BSpace) mock_frame '' ;;
      *) case " $* " in *' -l '*)
        mock_frame "${@: -1}"
        # The literal inject arms ONE late human change at the next identity
        # barrier; the door's re-injection must not re-arm it.
        if [ -f "$WORK/arm-after-inject" ]; then rm -f "${WORK:?}/arm-after-inject"; touch "$WORK/late-first"; fi
        # A delayed repaint arms stale paints for captures after this inject.
        if [ -f "$WORK/stale-redraw" ]; then printf 2 > "$WORK/stale-paints"; fi
      ;; esac ;;
    esac ;;
  *) exit 0 ;;
esac
MOCK
chmod +x "$WORK/bin/tmux"
export PATH="$WORK/bin:$PATH"

sentinel='[[TAP v0.23 note late-draft-test]]'
verify() {
  rc=0
  tap_submit_existing_verify %7 claude late-draft-test 0 id '' '' '' 6 '' '' "$sentinel" \
    > "$WORK/verify.log" 2>&1 || rc=$?
}
reset_frame "$sentinel"
verify
[ "$rc" = 0 ] && [ "$(cat "$WORK/enters")" -ge 1 ] || bad 'positive staged sentinel was not submitted'

# The earlier landing check saw the exact sentinel. A fresh identity check marks
# the deterministic interleave where human typing appears before the first Enter.
reset_frame "$sentinel"
touch "$WORK/late-first"
verify
# tap-maavp effect 2: the fused band (S + wire + ou inside a bounded composer)
# is recovered before Enter — foreign bytes `Sou` backed up, cleared, sentinel
# re-injected, THEN one Enter.
[ "$rc" = 0 ] || cat "$WORK/verify.log" >&2
[ "$rc" = 0 ] || bad "visible wire with extra input returned $rc"
[ "$(cat "$WORK/enters")" = 1 ] || bad 'visible wire did not receive exactly one Enter'
backup="$(ls "$WORK/bus/input-backups/"*.md 2>/dev/null | head -1)"
[ -n "$backup" ] || bad 'fused recovery retained no backup'
[ "$(tail -n 1 "$backup")" = "Sou" ] || bad 'backup body is not the foreign bytes alone'
key_order() { [ "$(grep -n "$1" "$WORK/keys" | head -1 | cut -d: -f1)" -lt "$(grep -n "$2" "$WORK/keys" | tail -1 | cut -d: -f1)" ]; }
first_key_order() { local a b; a="$(grep -n "$1" "$WORK/keys" | head -1 | cut -d: -f1)"; b="$(grep -n "$2" "$WORK/keys" | head -1 | cut -d: -f1)"; [ -n "$a" ] && [ -n "$b" ] && [ "$a" -lt "$b" ]; }
last_key_order() { local a b; a="$(grep -n "$1" "$WORK/keys" | tail -1 | cut -d: -f1)"; b="$(grep -n "$2" "$WORK/keys" | tail -1 | cut -d: -f1)"; [ -n "$a" ] && [ -n "$b" ] && [ "$a" -lt "$b" ]; }
first_key_order 'flash' 'C-u' || bad 'fused clear ran before the red warning flash'
key_order 'C-u' ' -l ' || bad 'clear ran after re-injection'
last_key_order ' -l ' 'settle:0.1' || bad 're-injection was not given its redraw settle'
last_key_order 'settle:0.1' 'Enter' || bad 'Enter ran before the redraw settle'
[ -z "$(tap_pending_input_region_text %7 claude)" ] || bad 'submitted composer did not clear'

# A delayed TUI repaint after fused recovery: the re-injected sentinel becomes
# visible only after more than one settle. The stale paints serve the full
# pre-recovery fused band, so a single settle-then-capture classifies a second
# fusion and fails closed (rc 5, no Enter); the bounded re-observation must
# ride out the stale paints and Enter exactly once on the sole wire.
reset_frame "$sentinel"
touch "$WORK/late-first"
frame "S${sentinel}ou"
cp "$FRAME" "$WORK/stale-redraw"
frame "$sentinel"
verify
[ "$rc" = 0 ] || cat "$WORK/verify.log" >&2
[ "$rc" = 0 ] || bad "delayed redraw after recovery returned $rc"
[ "$(cat "$WORK/enters")" = 1 ] || bad 'delayed redraw recovery did not Enter exactly once'
[ "$(grep -c ' -l ' "$WORK/keys")" = 1 ] || bad 'delayed redraw recovery re-injected more than once'
backup="$(ls "$WORK/bus/input-backups/"*.md 2>/dev/null | head -1)"
[ -n "$backup" ] || bad 'delayed redraw recovery retained no backup'
[ "$(tail -n 1 "$backup")" = "Sou" ] || bad 'delayed redraw backup body is not the foreign bytes alone'
last_key_order ' -l ' 'settle:0.1' || bad 'delayed redraw re-injection was not followed by a settle'
last_key_order 'settle:0.1' 'Enter' || bad 'delayed redraw Enter ran before the sole sentinel was re-observed'

reset_frame "$sentinel"
touch "$WORK/late-first"
rm -rf "${WORK:?}/bus/input-backups"
: > "$WORK/bus/input-backups"
verify
# A backup that cannot be written stops the door before any pane key.
[ "$rc" = 5 ] || bad "backup failure returned $rc"
grep -qE 'C-u|BSpace| -l |Enter' "$WORK/keys" && bad 'backup failure still sent pane keys' || :

reset_frame "$sentinel"
touch "$WORK/late-first"
touch "$WORK/identity-flip"
verify
# Pane identity drift after the first C-u is the identity verdict: refuse
# without Enter (the door re-authorizes between keys).
[ "$rc" = 6 ] || bad "identity drift returned $rc"
grep -q 'Enter' "$WORK/keys" && bad 'identity drift still received an Enter' || :

reset_frame "$sentinel"
touch "$WORK/late-second"
verify
[ "$rc" = 5 ] || bad 'a changed draft without an observed empty composer falsely verified submission'
[ "$(cat "$WORK/enters")" = 1 ] || bad 'automatic second Enter submitted the new human draft'
[ "$(tap_pending_input_text %7 claude)" = S ] || bad 'new human draft was not preserved after first submission'

# A missed first Enter still needs the second when the same exact input remains.
reset_frame "$sentinel"
touch "$WORK/swallow-first"
verify
[ "$rc" = 0 ] && [ "$(cat "$WORK/enters")" = 2 ] || bad 'unchanged sentinel lost its second-Enter recovery'

# Exercise the real fresh-call wiring, including construction of argument 12.
# The literal inject arms a late change at the next identity barrier.
reset_frame ''
touch "$WORK/arm-after-inject"
rc=0
tap_submit_verify %7 claude "$sentinel" late-draft-test > "$WORK/fresh.log" 2>&1 || rc=$?
[ "$rc" = 0 ] || bad "fresh visible wire with extra input returned $rc"
[ "$(cat "$WORK/enters")" = 1 ] || bad 'fresh visible wire did not receive one Enter'
backup="$(ls "$WORK/bus/input-backups/"*.md 2>/dev/null | head -1)"
[ -n "$backup" ] || bad 'fresh fused recovery retained no backup'
[ "$(tail -n 1 "$backup")" = "Sou" ] || bad 'fresh backup body is not the foreign bytes alone'
key_order 'C-u' ' -l ' || bad 'fresh clear ran after re-injection'
last_key_order ' -l ' 'settle:0.1' || bad 'fresh re-injection was not given its redraw settle'
last_key_order 'settle:0.1' 'Enter' || bad 'fresh Enter ran before the redraw settle'
[ -z "$(tap_pending_input_region_text %7 claude)" ] || bad 'fresh submitted composer did not clear'

reset_frame "$sentinel"
touch "$WORK/capture-fail"
verify
[ "$rc" = 5 ] && [ "$(cat "$WORK/enters")" = 0 ] || bad 'failed capture authorized Enter'

# The first read saw a draft, but the courtesy re-read disappeared. That must
# still route through backup + clear before the first literal wire inject.
reset_frame 'human draft'
touch "$WORK/fail-next-region-read"
rc=0
tap_submit_verify %7 claude "$sentinel" late-draft-test > "$WORK/re-read.log" 2>&1 || rc=$?
[ "$rc" = 0 ] || bad "failed courtesy re-read returned $rc"
first_key_order 'C-u' ' -l ' || bad 'failed courtesy re-read appended before backup and clear'
backup="$(ls "$WORK/bus/input-backups/"*.md 2>/dev/null | head -1)"
[ -n "$backup" ] || bad 'failed courtesy re-read retained no backup'
[ "$(tail -n 1 "$backup")" = 'human draft' ] || bad 'failed courtesy re-read backed up the wrong bytes'

# The real digest transaction must honor the configured draft policy at the pane.
export XDG_CONFIG_HOME="$WORK/config"
mkdir -p "$XDG_CONFIG_HOME/tap"
cat > "$TAP_HOME/registry.json" <<'JSON'
{"team":{"name":"t"},"agents":{"peer":{"harness":"claude","pane":"%7","pane_id":"%7","status":"active"}}}
JSON
for behavior in warn clobber; do
  reset_frame 'recover this draft'
  printf '[injection]\nbehavior="%s"\n' "$behavior" > "$XDG_CONFIG_HOME/tap/config.toml"
  id="policy-$behavior"
  printf -- '---\nid: %s\nfrom: sender\nto: peer\nkind: discuss\nreply: settle-only\n---\nbody\n' "$id" > "$WORK/$id.md"
  TAP_AUTOSETTLE_HOLD_SECONDS=0 tap_spool_add "$id" "$WORK/$id.md" peer t pending-input busy '' \
    %7 %7 '' autosettle 30 "$TAP_HOME/registry.json" >/dev/null
  python3 -B - "$TAP_SPOOL/$id.meta.json" <<'PYMETA'
import json,sys
p=sys.argv[1]; d=json.load(open(p)); d['draft_deadline_epoch']=1
with open(p,'w') as f: json.dump(d,f)
PYMETA
  rc=0
  tap_spool_digest_inject "$TAP_HOME/registry.json" '' peer %7 %7 "$id" > "$WORK/policy.log" 2>&1 || rc=$?
  if [ "$behavior" = warn ]; then
    [ "$rc" != 0 ] && [ "$(cat "$WORK/enters")" = 0 ] && [ ! -s "$WORK/keys" ] || bad 'warn affected an occupied pane'
    [ -f "$TAP_SPOOL/$id.md" ] || bad 'warn lost queued note'
  else
    [ "$rc" = 0 ] || { cat "$WORK/policy.log" >&2; bad 'expired note draft did not deliver'; }
    [ "$(cat "$WORK/enters")" -gt 0 ] || bad 'clobber never submitted note'
    backup="$(find "$TAP_INPUT_BACKUPS" -name '*.md' -type f -print -quit)"
    [ -n "$backup" ] && grep -q 'recover this draft' "$backup" || bad 'clobber lost original draft'
  fi
done

# Real digest transaction: publish two ordinary parks, observe an empty composer,
# then type one character after the real index write and before shared submission.
reset_frame ''
cat > "$TAP_HOME/registry.json" <<'JSON'
{"team":{"name":"t"},"agents":{"peer":{"harness":"claude","pane":"%7","pane_id":"%7","status":"active"}}}
JSON
for id in late-digest-a late-digest-b; do
  printf -- '---\nid: %s\nfrom: sender\nto: peer\nkind: discuss\nreply: expected\n---\nbody %s\n' "$id" "$id" > "$WORK/$id.md"
  TAP_AUTOSETTLE_HOLD_SECONDS=0 tap_spool_add "$id" "$WORK/$id.md" peer t window '' '' \
    %7 %7 '' standard '' "$TAP_HOME/registry.json" >/dev/null
 done
# Use the production readiness predicate; only its bound identity was pinned above.
#
# THE SEAM IS THE SUBMIT, NOT THE INDEX WRITE. This arm types a human draft into the
# window between publication and submission, and it used to reach that window by wrapping
# `tap_digest_write_index`. That write now happens inside `spool-digest-inject.ts`, where a
# Bash wrapper cannot intercept it — a stub of a function the port moved would silently
# stop firing, which is how a retired seam survives a sweep that only reads `smoke/`.
# `tap_debug_spool_submit` is the same window's far edge and is still Bash: the walk hands
# the adapter its submit request only after the index is on disk, so a draft typed at the
# top of this wrapper is a draft that appeared after publication and before any pane effect
# — the property the arm is about, now asserted one call closer to it.
eval "$(declare -f tap_debug_spool_submit | sed '1s/tap_debug_spool_submit/real_debug_spool_submit/')"
tap_debug_spool_submit() {
  frame S
  : > "$WORK/draft-after-index"
  real_debug_spool_submit "$@"
}
rc=0
tap_spool_digest_inject "$TAP_HOME/registry.json" '' peer %7 %7 late-digest-a late-digest-b \
  > "$WORK/digest.log" 2>&1 || rc=$?
[ -f "$WORK/draft-after-index" ] || { cat "$WORK/digest.log" >&2; bad 'digest control never reached the submit request'; }
[ "$rc" != 0 ] || bad 'digest accepted despite a late human draft'
[ "$(cat "$WORK/enters")" = 0 ] || bad 'digest submitted the late human draft'
[ ! -s "$WORK/keys" ] || bad 'digest cleared or typed over the late human draft'
[ "$(tap_pending_input_text %7 claude)" = S ] || bad 'digest changed the late human draft'
for id in late-digest-a late-digest-b; do
  [ -f "$TAP_SPOOL/$id.md" ] && [ -f "$TAP_SPOOL/$id.meta.json" ] || bad "$id lost spool custody on pre-effect refusal"
  [ ! -f "$TAP_RECEIPTS/$id.sent" ] && [ ! -f "$TAP_RECEIPTS/$id.done" ] || bad "$id falsely claimed delivery or settlement"
done
[ "$failures" = 0 ] || exit 1
echo 'draft-submit-boundary: pre-inject draft custody and post-inject containment hold'
