import json
import os
import signal
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
from unittest import mock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import _startup_trace_bridge as trace
import verbose


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def log_path():
    return Path(os.environ["TAP_INDEX_HOME"]) / "logs/startup.jsonl"


def test_lifecycle_trace_redacts_omits_prompts_and_preserves_failure(monkeypatch, tmp_path):
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path))
    monkeypatch.setenv("OPENAI_API_KEY", "test-secret-value")
    trace.begin("resume", "/repo", "coach")
    trace.phase("respawn_pane", session="repo/coach")
    error = subprocess.CalledProcessError(1, ["tmux", "respawn-pane"], stderr="fork failed test-secret-value")
    trace.command_result(["tmux", "respawn-pane", "do not log this prompt"], error=error)
    trace.emit("probe", prompt="private prompt", API_TOKEN="secret", detail="OPENAI_API_KEY=test-secret-value")
    trace.finish(1)
    data = rows(log_path())
    assert data[0]["target"] == "coach"
    assert data[1]["command"] == "respawn-pane"
    assert data[1]["exit_code"] == 1
    assert data[1]["phase"] == "respawn_pane"
    text = log_path().read_text()
    assert "test-secret-value" not in text and "private prompt" not in text and "do not log" not in text
    assert data[-1]["event"] == "launch_failure"


def test_trace_failure_never_changes_command_result(monkeypatch, tmp_path):
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path / "not-directory"))
    (tmp_path / "not-directory").write_text("file")
    trace.begin("launch", "/repo")
    result = verbose.run([sys.executable, "-c", "raise SystemExit(7)"], capture_output=True)
    assert result.returncode == 7
    trace.finish(7)


def test_verbose_transport_without_lifecycle_context_writes_no_startup_log(monkeypatch, tmp_path):
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path))
    monkeypatch.setattr(trace, "_context", None)
    transport = mock.Mock(side_effect=AssertionError("no helper without context"))
    monkeypatch.setattr(trace, "_RUN", transport)
    trace.command_result(["tmux", "display-message"], result=SimpleNamespace(returncode=1, stderr="no server running"))
    result = verbose.run([sys.executable, "-c", "raise SystemExit(7)"], capture_output=True)
    assert result.returncode == 7
    transport.assert_not_called()
    assert not log_path().exists()


def test_standalone_rollback_journal_preserves_identity(monkeypatch, tmp_path):
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path / "index"))
    registry = tmp_path / "team" / "team-registry.json"
    registry.parent.mkdir()
    before = {"status": "active", "delivery": "pane", "session": "repo/coach", "harness": "claude", "harness_session_id": "same-id", "harness_env": {"API_KEY": "secret"}}
    after = {**before, "status": "suspended", "status_reason": "session_replaced"}
    trace.transition(registry, "coach", before, after, False)
    journal = rows(registry.parent / "registry-events.jsonl")
    assert journal[0]["before"]["harness_session_id"] == journal[0]["after"]["harness_session_id"] == "same-id"
    assert "harness_env" not in journal[0]["before"]
    assert rows(log_path())[0]["event"] == "launch_rollback"


def test_deferred_start_does_not_publish_on_prerequisite_refusal(monkeypatch, tmp_path):
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path))
    trace.begin("new", "/repo", deferred=True)
    trace.finish(2)
    assert not log_path().exists()
    trace.begin("new", "/repo", deferred=True)
    trace.activate()
    trace.finish(0)
    assert [row["event"] for row in rows(log_path())] == ["launch_start", "launch_complete"]


def test_rollback_context_and_extended_secret_keys(monkeypatch, tmp_path):
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path / "index"))
    context = {"operation_id": "operation", "phase": "rollback", "session": "repo/seat"}
    trace.transition(tmp_path / "registry.json", "seat", {}, {}, False, context)
    row = rows(log_path())[-1]
    assert row["operation_id"] == "operation" and row["phase"] == "rollback"
    trace.emit("secret_test", authorization="private-auth", credential="private-cred", passwd="private-pass")
    text = log_path().read_text()
    assert "private-auth" not in text and "private-cred" not in text and "private-pass" not in text


def test_developer_diagnostics_off_by_default_file_only_when_enabled(monkeypatch, tmp_path, capsys):
    import lifecycle_diagnostics as diagnostics
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path / "index"))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
    monkeypatch.setattr(diagnostics, "_configured", None)
    diagnostics.begin()
    diagnostics.emit("detail", stdout="not captured while off")
    path = log_path().with_name("launch-debug.jsonl")
    assert not path.exists()
    config = tmp_path / "config/tap/config.toml"
    config.parent.mkdir(parents=True)
    config.write_text('[diagnostics]\nlevel = "verbose"\n')
    monkeypatch.setattr(diagnostics, "_configured", None)
    diagnostics.begin()
    verbose.emit("detail", API_TOKEN="secret", prompt="private", stderr="bounded detail")
    diagnostics.finish()
    text = path.read_text()
    assert "bounded detail" in text and '"secret"' not in text and "private" not in text
    assert capsys.readouterr().err == ""


def test_console_verbose_and_developer_mode_never_file_pane_prompt(monkeypatch, tmp_path, capfd):
    import lifecycle_diagnostics as diagnostics
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path / "index"))
    monkeypatch.setenv("TAP_VERBOSE", "1")
    monkeypatch.setenv("OPENAI_API_KEY", "planted:value2..92")
    monkeypatch.setenv("TAP_VERBOSE_FD", "2")
    monkeypatch.setattr(diagnostics, "_configured", True)
    diagnostics.begin()
    prompt = "planted-private-prompt-992"
    def run(argv, **kwargs):
        if "new-session" in argv:
            return subprocess.CompletedProcess(argv, 1, "", "fork failed planted:value2..92")
        if "capture-pane" in argv:
            return subprocess.CompletedProcess(argv, 0, prompt + " planted:value2..92", "")
        return subprocess.CompletedProcess(argv, 0, "pid=-1 dead=1 status=1", "")
    monkeypatch.setattr(verbose.subprocess, "run", run)
    try:
        result = verbose.run(["tmux", "new-session", "-s", "test/seat"], capture_output=True, text=True)
        assert result.returncode == 1
        # Direct capture through run uses the separate pane_output event.
        verbose.run(["tmux", "capture-pane", "-p", "-t", "test/seat"], capture_output=True, text=True)
    finally:
        diagnostics.finish()
    text = log_path().with_name("launch-debug.jsonl").read_text()
    assert prompt not in text
    assert "planted:value2..92" not in text
    console = capfd.readouterr().err
    assert prompt in console  # Explicit console -v still owns the capture.
    assert "planted:value2..92" not in console


@pytest.mark.parametrize("failed_op", ["begin", "phase"])
def test_real_timeout_kills_child_and_discards_context_before_next_operation(monkeypatch, tmp_path, failed_op):
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path / "index"))
    trace.begin("resume", "/before", "first")
    assert trace._context is not None
    fake = tmp_path / "slow-bun"
    fake.write_text(f"#!{sys.executable}\nimport time\ntime.sleep(10)\n")
    fake.chmod(0o755)
    real_run = trace._RUN
    observations = []
    children = []
    real_popen = subprocess.Popen
    def spawn(*args, **kwargs):
        child = real_popen(*args, **kwargs)
        children.append(child)
        return child
    def observe(*args, **kwargs):
        kwargs["stderr"] = subprocess.PIPE
        try:
            result = real_run(*args, **kwargs)
            observations.append(("returned", result.returncode, result.stderr))
            return result
        except Exception as error:
            observations.append((type(error).__name__, str(error)))
            raise
    with monkeypatch.context() as patch:
        patch.setenv("TAP_SMOKE_BUN", str(fake))
        patch.setattr(trace, "_RUN", observe)
        patch.setattr(subprocess, "Popen", spawn)
        started = time.monotonic()
        if failed_op == "begin":
            trace.begin("resume", "/failed", "must-not-stick")
        else:
            trace.phase("respawn_pane")
        assert time.monotonic() - started < 2
        assert observations[0][0] == "TimeoutExpired", observations
        assert trace._context is None
        assert len(children) == 1
        assert children[0].returncode == -signal.SIGKILL
        with pytest.raises(ProcessLookupError):
            os.kill(children[0].pid, 0)
        # A failed capsule cannot leak into a finish or launch another child.
        with mock.patch.object(trace, "_RUN") as transport:
            trace.finish(1)
            trace.command_result(["tmux", "new-session"])
            transport.assert_not_called()
    trace.emit("standalone")
    trace.begin("resume", "/after", "second")
    trace.finish(0)
    data = rows(log_path())
    assert [row["event"] for row in data] == ["launch_start", "standalone", "launch_start", "launch_complete"]
    assert "operation_id" not in data[1] and "phase" not in data[1]
    assert data[0]["operation_id"] != data[2]["operation_id"] == data[3]["operation_id"]
    assert data[-1]["target"] == "second"


@pytest.mark.parametrize("result", [
    SimpleNamespace(returncode=7, stdout='{"context": "old", "value": true}'),
    SimpleNamespace(returncode=0, stdout='{"context":'),
    SimpleNamespace(returncode=0, stdout='{"context": {}, "value": true}'),
    SimpleNamespace(returncode=0, stdout='{"context": "old"}'),
])
def test_bad_transport_clears_capsule_without_output(monkeypatch, tmp_path, capsys, result):
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path))
    monkeypatch.setattr(trace, "_context", "old")
    with mock.patch.object(trace, "_RUN", return_value=result) as transport:
        trace.finish(0)
        assert trace._context is None
        trace.command_result(["tmux", "new-session"])
        transport.assert_called_once()
    assert not log_path().exists()
    assert capsys.readouterr() == ("", "")
