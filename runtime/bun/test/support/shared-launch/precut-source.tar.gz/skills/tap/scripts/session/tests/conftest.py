"""Hermeticity guard for the session tests.

These tests are a UNIT suite. The live-pane, registration-lifecycle and
cross-worktree behavior they look like they cover actually lives in the shell
smoke suite (`skills/*/scripts/smoke/*.test.sh`), which AGENTS.md names as its
home and which the merge gate runs separately. So there is no tmux integration
coverage here to protect -- only an accidental dependency on whatever the
developer's tmux server happens to be holding.

That dependency was not theoretical. Three defects came from it: a stored pane
id that resolved to an unrelated live pane keyed a seat under a foreign session
name (tap-3ktp), and two more rows stored a pane id that this server had simply
not handed out yet -- tmux issues pane ids in increasing order for a server's
lifetime and never reuses them, so such an id is not reserved, only pending.

Fixing those one at a time does not stop the class regrowing: the next test that
forgets to pin a probe silently re-acquires the machine. So the interception is
here, once, at the choke point every tmux call passes through, rather than as a
list of helper names that has to be kept in sync with launcher.py. There are two
choke points, not one -- Python's `subprocess`, and `tmux` on the PATH a shelled-
out `bash` searches -- so the guard holds both, and answers each identically.

The canonical answer models a RUNNING server that holds nothing of yours:
whole-server queries succeed and return nothing; anything naming a target with
`-t` reports that target absent. Those are the same answers the real server
gives for the synthetic names these fixtures use, so the guard removes the
machine dependency without changing what any test observes.

A test that wants specific tmux behavior keeps its own `mock.patch.object(
launcher, "tmux_*")`; those patch the helper, which returns before it ever
reaches subprocess, so they layer on top of this guard and win.
"""

import os
import pathlib
import subprocess
import sys

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import presets as preset_config  # noqa: E402

_REAL_RUN = subprocess.run
_REAL_CALL = subprocess.call
_REAL_POPEN = subprocess.Popen


def _argv(args, kwargs):
    """The command, whether passed positionally or as args=."""
    argv = kwargs.get("args", args[0] if args else None)
    return argv if isinstance(argv, (list, tuple)) else None


def _is_tmux(argv):
    return bool(argv) and str(argv[0]) == "tmux"


def _wants_text(kwargs):
    return bool(
        kwargs.get("text")
        or kwargs.get("universal_newlines")
        or kwargs.get("encoding")
        or kwargs.get("errors")
    )


def _stream(kwargs, name, body):
    """Populate a stream only when the caller asked for it via PIPE.

    Mirrors CompletedProcess: a stream that was not piped is None, never "".
    """
    if kwargs.get(name) != subprocess.PIPE:
        return None
    return body if _wants_text(kwargs) else body.encode()


def _absent_server_result(argv, kwargs):
    """Canonical reply from a live server that holds nothing of yours."""
    targeted = "-t" in [str(a) for a in argv]
    if targeted:
        # tmux exits non-zero and says so; `can't find` is load-bearing --
        # tmux_pane_raw_id reads it to tell "observed absent" (\"\") apart from
        # "unobservable" (None).
        return subprocess.CompletedProcess(
            list(argv), 1,
            _stream(kwargs, "stdout", ""),
            _stream(kwargs, "stderr", f"can't find target: {argv[-1]}\n"),
        )
    # Whole-server query: the server is up, it just has nothing to report.
    return subprocess.CompletedProcess(
        list(argv), 0,
        _stream(kwargs, "stdout", ""),
        _stream(kwargs, "stderr", ""),
    )


# The shell half of the same model. Two launcher paths shell out --
# seat_state_for_handle and pane_harness both run `bash -c '. lib.sh; ...'` --
# and lib.sh calls tmux itself, where a guard patching the Python stdlib cannot
# follow. That gap is not theoretical either: a server holding a session named
# `repo/scout` was measured turning this suite RED. Prepending our own `tmux` to
# PATH puts the child back behind the same model, without naming call sites.
#
# Deliberately consistent with _absent_server_result rather than with real tmux.
# Real tmux answers a targeted `display-message` with rc 0 and empty stdout, and
# reserves rc 1 + `can't find` for `capture-pane`, `has-session` and
# `list-panes`. Both `display-message` callers here (lib.sh `tap_pane_alive`,
# `tap_pane_harness_command`) discard the rc with `|| true` and branch on an
# empty result, so the two shapes converge on the same answer -- and one model
# shared by both halves is worth more than reproducing that split twice.
_TMUX_SHIM = """#!/bin/sh
# Written by conftest.py -- a bash child must see what the Python guard shows.
targeted=0
for a in "$@"; do
  [ "$a" = "-t" ] && targeted=1
  last="$a"
done
[ "$targeted" = 0 ] && exit 0
printf "can't find target: %s\\n" "$last" >&2
exit 1
"""


@pytest.fixture(scope="session")
def _tmux_shim_dir(tmp_path_factory):
    """A PATH directory holding the shell mirror of the guard, written once."""
    shim = tmp_path_factory.mktemp("tmux-shim") / "tmux"
    shim.write_text(_TMUX_SHIM)
    shim.chmod(0o755)
    # Launcher units replace execution; supply presence without host agent installs.
    for executable in ("claude", "codex", "opencode", "cursor-agent", "agy", "hermes"):
        command = shim.parent / executable
        command.write_text("#!/bin/sh\nexit 99\n")
        command.chmod(0o755)
    return shim.parent


@pytest.fixture(autouse=True)
def block_live_tmux(monkeypatch, _tmux_shim_dir, tmp_path, request):
    """Answer every tmux command from a fixed model instead of the real server.

    Non-tmux commands pass straight through untouched -- the launcher shells out
    to `sysctl` for the boot id, among others, and rewriting those would break
    tests that have nothing to do with tmux.
    """

    def run(*args, **kwargs):
        argv = _argv(args, kwargs)
        if not _is_tmux(argv):
            return _REAL_RUN(*args, **kwargs)
        return _absent_server_result(argv, kwargs)

    def call(*args, **kwargs):
        argv = _argv(args, kwargs)
        if not _is_tmux(argv):
            return _REAL_CALL(*args, **kwargs)
        return _absent_server_result(argv, kwargs).returncode

    def popen(*args, **kwargs):
        argv = _argv(args, kwargs)
        if not _is_tmux(argv):
            return _REAL_POPEN(*args, **kwargs)
        # No tmux call uses Popen today. Fail loudly rather than invent a
        # process object, so a future one is told to pin itself instead of
        # quietly reaching the real server.
        raise AssertionError(
            f"session tests: tmux via Popen is not modelled by the hermeticity "
            f"guard (conftest.py); pin this probe in the test: {list(argv)}"
        )

    # Patched on the stdlib module itself: each test module builds its own
    # `launcher` object via SourceFileLoader, so there is no single launcher
    # attribute to patch, but every copy calls through this one module.
    monkeypatch.setattr(subprocess, "run", run)
    monkeypatch.setattr(subprocess, "call", call)
    monkeypatch.setattr(subprocess, "Popen", popen)
    # The shell half: neither bash call site passes `env=`, so the child
    # inherits this PATH and resolves `tmux` to the shim above.
    monkeypatch.setenv("PATH", str(_tmux_shim_dir), prepend=os.pathsep)

    # The same class of machine dependency, one file over. The launcher now reads
    # `${XDG_CONFIG_HOME:-$HOME/.config}/tap/config.toml` on EVERY launch and resume for
    # harness-level environment policy. Unpinned, this suite would read the developer's real
    # config: once an operator seeds `[harness.codex.env] PONYTAIL_DEFAULT_MODE=off`, a test
    # asserting that value passes because of the machine rather than because of the code — a
    # green that proves nothing, and that flips to red on any machine without that file.
    #
    # Pointing XDG_CONFIG_HOME at an empty per-test directory models the fresh-system state:
    # no config, tier 2 empty, no notice. A test that wants a config writes one THERE.
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg-config"))
    import tmux_bootstrap
    import verbose
    monkeypatch.setattr(verbose, "tmux_argv", lambda argv, env=None: argv)
    if request.node.path.name != "test_tmux_bootstrap.py":
        monkeypatch.setattr(tmux_bootstrap, "ensure_server", lambda *args, **kwargs: False)

    # Third machine dependency, same class as the two above. The launcher resolves a
    # worktree's acting registry through `TAP_INDEX_HOME`; the suite WRAPPER pins it (via
    # sandbox-pins.sh) but a bare `python3 -m pytest` does not, so the same test consults the
    # operator's real registry and refuses "worktree is not enrolled" on a fixture that is
    # perfectly well formed. The verdict then depends on which runner was used, which is how a
    # reviewer running the obvious command produces a finding the gate cannot reproduce — it
    # cost exactly one such round-trip. Pinning here makes the two runners agree.
    monkeypatch.setenv("TAP_INDEX_HOME", str(tmp_path / "tap-index"))


@pytest.fixture(autouse=True)
def reset_notice_history():
    """Give every test its own notice history.

    `emit_notice` de-duplicates identical text per COMMAND, and a test process is one long-lived
    process running many commands. Without this reset the FIRST test to emit a given line
    silences every later test asserting the same line — the ambient-warning matrix asserts the
    identical string in four cells, so three would have gone quietly green while asserting
    nothing. This is the test-side half of the dedup, not hygiene around it.
    """
    # Suppression is global too, and leaks the same way: any test that drives `--json` through
    # launcher.main sets it True for the REST OF THE PROCESS. Nothing reset it because until now
    # nothing asserted a notice's presence after such a test — the first one to try saw zero
    # notices in the full suite and one when run alone, which is the runner-dependent verdict
    # this file already exists to prevent (see the TAP_INDEX_HOME note above).
    preset_config.suppress_notices(False)
    preset_config.reset_notices()
    yield
    preset_config.suppress_notices(False)
    preset_config.reset_notices()
