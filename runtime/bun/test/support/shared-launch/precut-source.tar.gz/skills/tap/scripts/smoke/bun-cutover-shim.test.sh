#!/usr/bin/env bash
# bun-cutover-shim.test.sh — the installed shim prefers Bun and preserves rollback.
if [ "${BASH_SOURCE[0]}" != "$0" ]; then
  echo "$(basename "${BASH_SOURCE[0]}"): do not source — run: bash $0" >&2
  return 1 2>/dev/null || exit 1
fi
set -euo pipefail

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
WORK="$(mktemp -d)"
WORK="$(cd -P "$WORK" && pwd)"
FIXTURE="$WORK/repo"
HOME_FIXTURE="$WORK/home"
FAKE_BIN="$WORK/bin"
MAIN="$FIXTURE/runtime/bun/main.ts"
MAIN_ARG="$FIXTURE/bin/../runtime/bun/main.ts"
SHIM="$WORK/link/tap"
ARGS=("whoami" "arg with spaces" '--literal=$(not-executed)')

fail() { echo "bun-cutover-shim: $1" >&2; exit 1; }
cleanup() {
  case "$WORK" in /tmp/*|/private/tmp/*|/var/folders/*) rm -rf "$WORK" ;; esac
}
trap cleanup EXIT

mkdir -p "$FIXTURE/bin" "$FIXTURE/skills/tap/scripts" "$(dirname "$MAIN")" \
  "$HOME_FIXTURE" "$FAKE_BIN" "$(dirname "$SHIM")"
cp "$ROOT/bin/tap" "$FIXTURE/bin/tap"
cp "$ROOT/skills/tap/scripts/python-runtime.sh" "$FIXTURE/skills/tap/scripts/"
cp -R "$ROOT/skills/tap/scripts/python-bin" "$FIXTURE/skills/tap/scripts/"
printf '// fixture main\n' > "$MAIN"

cat > "$FIXTURE/skills/tap/scripts/tap.sh" <<'EOF'
printf 'bash\n'
printf '<%s>\n' "$@"
EOF
cat > "$FAKE_BIN/bun" <<'EOF'
#!/bin/bash
printf 'bun\n'
printf '<%s>\n' "$@"
EOF
chmod +x "$FAKE_BIN/bun"
ln -s "$FIXTURE/bin/tap" "$SHIM"

capture() {
  local out="$1"
  shift
  (
    cd /
    env -u TAP_RUNTIME HOME="$HOME_FIXTURE" PATH="$FAKE_BIN:/bin:/usr/bin" \
      /bin/bash "$SHIM" "${ARGS[@]}"
  ) > "$out"
}

expect_bun() {
  local out="$1"
  {
    printf 'bun\n<%s>\n' "$MAIN_ARG"
    printf '<%s>\n' "${ARGS[@]}"
  } > "$out"
}

expect_bash() {
  local out="$1"
  {
    printf 'bash\n'
    printf '<%s>\n' "${ARGS[@]}"
  } > "$out"
}

expect_bun "$WORK/expected-bun"
expect_bash "$WORK/expected-bash"

capture "$WORK/default"
cmp "$WORK/expected-bun" "$WORK/default" || fail "available Bun runtime was not preferred with identical argv"

cat > "$FAKE_BIN/bun" <<'EOF'
#!/no/such/interpreter
EOF
chmod +x "$FAKE_BIN/bun"
if ! capture "$WORK/broken-bun"; then
  fail "Bun exec failure did not fall back with identical argv"
fi
cmp "$WORK/expected-bash" "$WORK/broken-bun" || fail "Bun exec failure did not fall back with identical argv"

cat > "$FAKE_BIN/bun" <<'EOF'
#!/bin/bash
printf 'bun\n'
printf '<%s>\n' "$@"
EOF
chmod +x "$FAKE_BIN/bun"

rm "$MAIN"
capture "$WORK/no-main"
cmp "$WORK/expected-bash" "$WORK/no-main" || fail "missing main.ts did not fall back with identical argv"
: > "$MAIN"
capture "$WORK/empty-main"
cmp "$WORK/expected-bash" "$WORK/empty-main" || fail "empty main.ts did not fall back with identical argv"
printf '// fixture main\n' > "$MAIN"

(
  cd /
  env -u TAP_RUNTIME HOME="$HOME_FIXTURE" PATH="/bin:/usr/bin" \
    /bin/bash "$SHIM" "${ARGS[@]}"
) > "$WORK/no-bun"
cmp "$WORK/expected-bash" "$WORK/no-bun" || fail "missing Bun executable did not fall back with identical argv"

(
  cd /
  HOME="$HOME_FIXTURE" PATH="$FAKE_BIN:/bin:/usr/bin" TAP_RUNTIME=bash \
    /bin/bash "$SHIM" "${ARGS[@]}"
) > "$WORK/env-rollback"
cmp "$WORK/expected-bash" "$WORK/env-rollback" || fail "TAP_RUNTIME=bash did not fall back with identical argv"

mkdir -p "$HOME_FIXTURE/.tap"
: > "$HOME_FIXTURE/.tap/runtime-bash"
capture "$WORK/file-rollback"
cmp "$WORK/expected-bash" "$WORK/file-rollback" || fail "runtime-bash touch file did not fall back with identical argv"

echo "bun-cutover-shim: ok"
