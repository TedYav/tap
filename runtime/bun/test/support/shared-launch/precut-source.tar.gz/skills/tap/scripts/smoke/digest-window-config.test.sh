#!/usr/bin/env bash
# digest-window-config.test.sh — the recipient's delivery-window override writer
# (runtime/bun/src/digest-window.ts, the native form of digest_window.py):
# preserves unrelated fields and comments, serializes concurrent setters through
# the config lock, scopes reads by seat, removes on `off`, refuses bad input and
# never reconstructs a config it could not parse. Exercised through the module's
# CLI (the adapter boundary) and read back with an independent parser.
set -euo pipefail
. "$(dirname "${BASH_SOURCE[0]}")/sandbox-pins.sh"
ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
MODULE="$ROOT/runtime/bun/src/digest-window.ts"
WORK="$(cd "$(mktemp -d)" && pwd -P)"
trap 'rm -rf "$WORK"' EXIT
CFG="$WORK/config.toml"
fail() { echo "digest-window-config: FAIL — $*" >&2; exit 1; }
dw() { bun "$MODULE" "$@"; }
# Independent read-back: Python's tomllib, one JSON document on stdout.
doc() { python3 -B -c 'import json,sys,tomllib; print(json.dumps(tomllib.loads(open(sys.argv[1], encoding="utf-8").read())))' "$CFG"; }
field() { python3 -B -c 'import json,sys; d=json.load(sys.stdin); print(json.dumps(eval(sys.argv[1], {"d": d}), sort_keys=True))' "$1"; }

cat > "$CFG" <<'TOML'
# operator comment
[delivery]
now_window_seconds = 10
[delivery.overrides."t/peer"]
now_window_seconds = 40 # old setting
polite_window_seconds = 700
[delivery.overrides."other/peer"]
now_window_seconds = 900
[presets.sample]
harness = "codex"
TOML
chmod 600 "$CFG"

# --- 1. update in place: the seat's two keys, everything else byte-preserved ---
dw update "$CFG" 't/peer' 600 0 || fail "update exited $?"
[ "$(doc | field 'd["delivery"]["overrides"]["t/peer"]')" = '{"digest_include_asks": false, "now_window_seconds": 600, "polite_window_seconds": 700}' ] \
  || fail "seat row after update: $(doc | field 'd["delivery"]["overrides"]["t/peer"]')"
[ "$(doc | field 'd["delivery"]["overrides"]["other/peer"]["now_window_seconds"]')" = 900 ] || fail "other seat's row moved"
grep -q '# operator comment' "$CFG" || fail "the operator comment was rewritten away"
[ "$(doc | field 'd["presets"]["sample"]["harness"]')" = '"codex"' ] || fail "an unrelated table was rewritten"
# The layout is a SPLICE, not a re-serialization: the untouched lines are byte-identical.
grep -q '^\[presets.sample\]$' "$CFG" && grep -q '^harness = "codex"$' "$CFG" || fail "unrelated lines were re-serialized"

# --- 2. scoped reads through the same module ----------------------------------
[ "$(dw configured-window "$CFG" now_window_seconds t peer t expected)" = 10 ] \
  || fail "t/peer with include-asks false and an expected reply must fall back to the [delivery] default"
[ "$(dw configured-window "$CFG" now_window_seconds t peer t settle-only)" = 600 ] \
  || fail "t/peer with a settle-only reply reads its override"
[ "$(dw configured-window "$CFG" now_window_seconds other peer t expected)" = 900 ] \
  || fail "other/peer reads its own override"

# --- 3. concurrent setters serialize on the config lock -------------------------
dw update "$CFG" 't/a' 25 0 & p1=$!
dw update "$CFG" 't/b' 25 0 & p2=$!
wait "$p1" || fail "concurrent setter t/a exited nonzero"
wait "$p2" || fail "concurrent setter t/b exited nonzero"
for seat in t/a t/b; do
  [ "$(doc | field "d['delivery']['overrides']['$seat']['now_window_seconds']")" = 25 ] || fail "concurrent setter lost $seat"
done
[ -z "$(ls -A "$WORK" | grep -E '^\.digest-window-' || true)" ] || fail "a temp file was left behind: $(ls -A "$WORK")"

# --- 4. off removes the two keys and keeps the rest of the row -------------------
dw update "$CFG" 't/peer' off 0 || fail "off exited $?"
[ "$(doc | field 'd["delivery"]["overrides"]["t/peer"]')" = '{"polite_window_seconds": 700}' ] || fail "off left: $(doc | field 'd["delivery"]["overrides"]["t/peer"]')"

# --- 5. invalid windows are refused before any write ------------------------------
before="$(cat "$CFG")"
for value in -1 bad 2.5 2147483648 '' ' 10'; do
  if dw validate "$value" 2>/dev/null; then fail "validate accepted '$value'"; fi
  if dw update "$CFG" 't/peer' "$value" 0 2>/dev/null; then fail "update accepted window '$value'"; fi
done
[ "$(cat "$CFG")" = "$before" ] || fail "a refused window still wrote the config"
dw validate off && dw validate 0 && dw validate 2147483647 || fail "a legal window was refused"

# --- 6. unsafe syntax is refused, never reconstructed from partially parsed data ---
printf '[delivery\n' > "$CFG"
if dw update "$CFG" 't/peer' 10 0 2>"$WORK/err"; then fail "invalid TOML was overwritten"; fi
grep -q '^tap digest-window: ' "$WORK/err" || fail "the refusal did not carry the verb label: $(cat "$WORK/err")"
[ "$(cat "$CFG")" = '[delivery' ] || fail "invalid TOML was rewritten to: $(cat "$CFG")"
# A layout the splice cannot see (dotted keys) is refused by the semantic round-trip check.
printf 'delivery.overrides."t/peer".now_window_seconds = 5\n' > "$CFG"
if dw update "$CFG" 't/peer' 10 0 2>/dev/null; then fail "a dotted-key layout was spliced"; fi
[ "$(cat "$CFG")" = 'delivery.overrides."t/peer".now_window_seconds = 5' ] || fail "the dotted-key config was rewritten"

# --- 7. a group-writable config is refused by the secure read, untouched ----------
printf '[delivery]\nnow_window_seconds = 10\n' > "$CFG"; chmod 664 "$CFG"
if dw update "$CFG" 't/peer' 10 0 2>/dev/null; then fail "a group-writable config was edited"; fi
[ "$(cat "$CFG")" = "$(printf '[delivery]\nnow_window_seconds = 10')" ] || fail "the insecure config was rewritten"

echo 'digest config: preserved unrelated fields/comments, atomic concurrent setters, scoped reads, off and invalid-input refusal PASS'
