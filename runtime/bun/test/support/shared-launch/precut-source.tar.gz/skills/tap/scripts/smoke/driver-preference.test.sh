#!/usr/bin/env bash
# driver-preference.test.sh — the per-harness driver preference (TAP 1.0, tap-49kp6).
#
# The preference is what an operator uses to move one family's mail onto a native
# door and back. Its whole value is that you can tell which door your mail went
# through, so the failure mode this file guards is not "the wrong driver ran" but
# "a misconfiguration silently ran the right one anyway."
#
# Arms:
#   (a) no config at all        -> tmux
#   (b) key absent from a table -> tmux
#   (c) driver = "tmux"         -> tmux
#   (d) an unrecognized value   -> LOUD refusal, never a silent tmux fallback
#   (e) a malformed value       -> LOUD refusal
#   (f) TAP_DRIVER_FORCE_TMUX=1 -> tmux, and it is checked BEFORE the config is
#       opened, so a config too broken to read cannot disable the emergency deny
#   (g) resolution is per FAMILY: one family's preference never leaks to another
#   (h) read at DELIVERY time: editing the config takes effect on the next send,
#       with no relaunch and no cached value
set -euo pipefail
# shellcheck source=skills/tap/scripts/smoke/sandbox-pins.sh
. "$(dirname "${BASH_SOURCE[0]}")/../../../tap/scripts/smoke/sandbox-pins.sh"

ROOT="$(git -C "$(dirname "${BASH_SOURCE[0]}")" rev-parse --show-toplevel)"
TAP_HOME="$(mktemp -d)"
trap 'rm -rf "$TAP_HOME"' EXIT
export TAP_HOME
mkdir -p "$TAP_HOME/payloads" "$TAP_HOME/receipts"
XDG_CONFIG_HOME="$TAP_HOME/config"; export XDG_CONFIG_HOME
mkdir -p "$XDG_CONFIG_HOME/tap"
CFG="$XDG_CONFIG_HOME/tap/config.toml"

# shellcheck disable=SC1090
. "$ROOT/skills/tap/scripts/lib.sh"

# WIRING OVERRIDE. `tap_driver_wired_list` is a code fact with no environment
# seam (sol-pinnacle showed an env-settable set reopened the wrong-transport
# failure the gate closes), so a suite that needs fixture drivers selectable
# redefines the FUNCTION after sourcing. That ships nothing: the override
# lives in this file, not in lib.sh.
# These arms exercise the PARSER: which spellings resolve to which name.
tap_driver_wired_list() { printf %s 'tmux somedriver native nosuchdriver'; }

fail() { echo "driver-preference: $*" >&2; exit 1; }


expect_driver() { # <family> <expected> <label>
  local got rc=0
  got="$(tap_driver_for_harness "$1" 2>/dev/null)" || rc="$?"
  [ "$rc" = 0 ] || fail "$3: resolving '$1' failed with rc=$rc, expected '$2'"
  [ "$got" = "$2" ] || fail "$3: resolved '$1' to '$got', expected '$2'"
}

expect_refusal() { # <family> <label> <substring the operator needs to see>
  local out rc=0
  out="$(tap_driver_for_harness "$1" 2>&1)" && rc=0 || rc="$?"
  [ "$rc" != 0 ] || fail "$2: an unusable preference resolved to '$out' instead of refusing — the operator cannot tell which door their mail took"
  case "$out" in
    *"$3"*) ;;
    *) fail "$2: the refusal did not name '$3'; it said: $out" ;;
  esac
}

# --- (a) no config at all -----------------------------------------------------
rm -f "$CFG"
expect_driver claude tmux "(a)"
echo "driver-preference: (a) no config resolves to tmux: ok"

# --- (b) a table with no driver key -------------------------------------------
cat > "$CFG" <<'ENDCFG'
[harness.claude]
params.dangerously-skip-permissions = true
ENDCFG
expect_driver claude tmux "(b)"
echo "driver-preference: (b) an absent key resolves to tmux: ok"

# --- (c) the explicit default -------------------------------------------------
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "tmux"
ENDCFG
expect_driver claude tmux "(c)"
echo "driver-preference: (c) driver = \"tmux\" resolves to tmux: ok"

# --- (d) an unrecognized value is a LOUD refusal ------------------------------
# The refusal happens in two places and both matter: a value that is not a legal
# NAME is refused by the reader, and a legal name with no driver behind it is
# refused by the loader. Both are checked, because a typo lands in either.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "definitely-not-a-driver"
ENDCFG
expect_refusal claude "(d)" "definitely-not-a-driver"
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "nosuchdriver"
ENDCFG
expect_driver claude nosuchdriver "(d-name)"
if tap_driver_load nosuchdriver 2>/dev/null; then
  fail "(d) a driver name with no module behind it loaded anyway"
fi
echo "driver-preference: (d) an unrecognized preference refuses loudly, never falls back silently: ok"

# --- (e) a malformed value ----------------------------------------------------
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = tmux
ENDCFG
expect_refusal claude "(e)" "unusable"
echo "driver-preference: (e) an unquoted value refuses rather than guessing: ok"

# --- (e2) `driver = ""` is a statement, not an absence ------------------------
# An absent key and an empty value read identically to a naive parser — both
# yield no value — but they are different statements from the operator. An
# absent key is the documented default; `driver = ""` is someone who wrote
# something and meant something, and silently running tmux for them is the exact
# undetectable selection this preference exists to prevent.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = ""
ENDCFG
expect_refusal claude "(e2)" "names no driver"
# ...and the absent-key default must still work, or the fix traded one silent
# wrong answer for a loud wrong one.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
params.dangerously-skip-permissions = true
ENDCFG
expect_driver claude tmux "(e2-absent)"
echo "driver-preference: (e2) an explicitly empty preference refuses, while an absent key still defaults: ok"

# --- (e3) a quoted value with trailing garbage --------------------------------
# `driver = "tmux" and then some` parses as a quoted value IF the reader takes
# the first quoted run and discards the rest. It must not: the operator wrote
# something, and running tmux for them silently is the same undetectable
# selection as (e2), arriving through a typo instead of an empty string.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "tmux" and then some
ENDCFG
expect_refusal claude "(e3)" "unusable"
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "somedriver" ; leftover
ENDCFG
expect_refusal claude "(e3-semicolon)" "unusable"
# ...but a trailing COMMENT is ordinary TOML and must still work, or the guard
# has started refusing valid files.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "tmux"   # the universal fallback
ENDCFG
expect_driver claude tmux "(e3-comment)"
echo "driver-preference: (e3) trailing garbage refuses; a trailing comment still parses: ok"

# --- (e4) a valid TOML spelling this reader does not implement --------------
# `[harness."claude"]` is VALID TOML and names the same table. A literal string
# comparison never matches it, so the table reads as ABSENT and the send takes
# tmux — an explicit preference routed through the wrong transport with no
# notice, which is the exact outcome this setting exists to prevent. Refuse the
# spelling rather than mistake it for an absence. (Full TOML here is the wrong
# trade: this runs on every send, and the launcher already owns the complete
# parse.)
cat > "$CFG" <<'ENDCFG'
[harness."claude"]
driver = "native"
ENDCFG
expect_driver claude native "(e4-quoted-table)"
cat > "$CFG" <<'ENDCFG'
[harness . claude]
driver = "native"
ENDCFG
expect_driver claude native "(e4-spaced)"
# The QUOTED-FIRST-SEGMENT form. `["harness".claude]` is valid TOML naming the
# same table (confirmed against the python TOML parser), and a guard keyed on a
# leading BARE `harness` slides straight past it — the refusal has to recognize
# every spelling that could name a harness table, not the ones that look like
# the spelling someone already thought of.
cat > "$CFG" <<'ENDCFG'
["harness".claude]
driver = "native"
ENDCFG
expect_driver claude native "(e4-quoted-prefix)"
# The plain spelling must keep working, or the guard has started refusing the
# only form anyone actually writes.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "tmux"
ENDCFG
expect_driver claude tmux "(e4-plain)"
# And an unrelated quoted table must not poison a family that is spelled plainly
# — the refusal is per-resolve, not per-file.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "tmux"

[presets."odd name"]
harness = "claude"
ENDCFG
expect_driver claude tmux "(e4-unrelated)"
# DOTTED ASSIGNMENT names the same table without ever writing a header. This is
# the spelling that finally retired the hand-rolled reader: a section-keyed
# matcher cannot see it at all, because there is no section.
cat > "$CFG" <<'ENDCFG'
harness.claude.driver = "native"
ENDCFG
expect_driver claude native "(e4-dotted)"
cat > "$CFG" <<'ENDCFG'
[harness]
claude.driver = "native"
ENDCFG
expect_driver claude native "(e4-dotted-under-header)"
echo "driver-preference: (e4) quoted, spaced and DOTTED spellings all resolve identically: ok"

# (e4b) ONE FAMILY'S ODD SPELLING MUST NOT FAIL ANOTHER FAMILY'S SEND. The
# hand-rolled version raised a GLOBAL unsupported flag, so an unusual header for
# codex made every send to claude fail with driver_unavailable — a config for a
# harness you are not addressing taking down the one you are.
cat > "$CFG" <<'ENDCFG'
[harness."codex"]
driver = "somedriver"

[harness.claude]
driver = "tmux"
ENDCFG
expect_driver claude tmux "(e4b)"
expect_driver codex somedriver "(e4b-other)"
echo "driver-preference: (e4b) one family's spelling does not fail another family's resolve: ok"

# (e4c) THE WHOLE DOCUMENT IS VALIDATED, not just the target table. An early exit
# on finding the value accepted a config the LAUNCHER rejects — two consumers of
# one file applying different policy, which is the split this reader was supposed
# to close rather than widen.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "native"
this line is not valid toml
ENDCFG
expect_refusal claude "(e4c)" "unusable"
echo "driver-preference: (e4c) a malformed line ANYWHERE refuses, even with a valid value in the target table: ok"

# --- (e5) the config source itself must be safe -------------------------------
# The launcher reads this same file through read_secure_preset_bytes, which
# refuses non-regular and group/world-writable sources. This reader runs on EVERY
# SEND and must not be the weaker door: a readable FIFO would block the courier
# indefinitely on open, before it could ever fall back to tmux.
rm -f "$CFG"
mkfifo "$CFG"
_fifo_rc=0
# A bounded probe: if the guard is absent this call blocks forever on the open,
# so the timeout IS the assertion. (bash's read -t cannot help — the hang is in
# awk's open, in a subprocess.)
( tap_driver_for_harness claude >/dev/null 2>&1 ) & _probe=$!
_waited=0
while kill -0 "$_probe" 2>/dev/null && [ "$_waited" -lt 50 ]; do
  sleep 0.1; _waited=$((_waited + 1))
done
if kill -0 "$_probe" 2>/dev/null; then
  kill -9 "$_probe" 2>/dev/null || true
  wait "$_probe" 2>/dev/null || true
  rm -f "$CFG"
  fail "(e5) a FIFO config blocked the courier — every send hangs before any tmux fallback"
fi
wait "$_probe" 2>/dev/null || _fifo_rc=$?
[ "$_fifo_rc" != 0 ] || fail "(e5) a FIFO config was accepted as a config source"
rm -f "$CFG"
echo "driver-preference: (e5) a FIFO config refuses promptly instead of hanging the courier: ok"

# A world-writable config means anyone on the box picks the driver.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "tmux"
ENDCFG
chmod 666 "$CFG"
expect_refusal claude "(e5-writable)" "unusable"
chmod 600 "$CFG"
expect_driver claude tmux "(e5-restored)"
echo "driver-preference: (e5) a group/world-writable config refuses; a 0600 one still works: ok"

# (e6) THE CONTRACT SENTENCE, driven. "Absent" and "present but unusable" are
# different states and CONTRACT once collapsed them into one fallback claim the
# code has never implemented (grok, #xxx pre-screen). An operator reading the old
# sentence would take an unreadable config as the emergency path; it is not, and
# TAP_DRIVER_FORCE_TMUX is.
rm -f "$CFG"
expect_driver claude tmux "(e6-absent)"
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "tmux"
ENDCFG
chmod 000 "$CFG"
expect_refusal claude "(e6-unreadable)" "unusable"
got="$(TAP_DRIVER_FORCE_TMUX=1 tap_driver_for_harness claude 2>&1)" ||   fail "(e6) the emergency deny failed on an unreadable config — the one path that must work when the file cannot be"
[ "$got" = tmux ] || fail "(e6) TAP_DRIVER_FORCE_TMUX=1 resolved to '$got' on an unreadable config"
chmod 600 "$CFG"
echo "driver-preference: (e6) absent falls back, present-but-unusable refuses, and FORCE_TMUX is the escape: ok"

# (e7) A NUL BYTE CANNOT SURVIVE SHELL CAPTURE. The source is descriptor-bound,
# but `$( )` silently strips NULs — so `driver = "na<NUL>tive"` reaches the
# readers as `native`, and invalid TOML resolves to a driver name instead of
# refusing. The bytes used for dispatch would not be the bytes that were read.
printf '[harness.claude]\ndriver = "na\000tive"\n' > "$CFG"
chmod 600 "$CFG"
expect_refusal claude "(e7)" "unusable"
# The mirror: an ordinary config must still resolve. A length-comparison version
# of this guard refused EVERY valid file, because `$( )` also strips trailing
# newlines and every well-formed config has one.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "tmux"
ENDCFG
expect_driver claude tmux "(e7-mirror)"
echo "driver-preference: (e7) a NUL refuses; an ordinary trailing newline still resolves: ok"

# --- (f) the emergency deny outranks a config too broken to read --------------
# The order is the assertion. If FORCE_TMUX were checked after the config read, a
# config in exactly the state that makes you reach for an emergency switch would
# be the thing that stops it working.
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = tmux
ENDCFG
got="$(TAP_DRIVER_FORCE_TMUX=1 tap_driver_for_harness claude 2>&1)" || \
  fail "(f) the emergency deny failed on a config it should never have opened"
[ "$got" = tmux ] || fail "(f) TAP_DRIVER_FORCE_TMUX=1 resolved to '$got'"
echo "driver-preference: (f) the core-wide deny is checked before the config is opened: ok"

# --- (g) preference is per family ---------------------------------------------
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "tmux"

[harness.codex]
driver = "somedriver"

[harness.opencode]
driver = "tmux"
ENDCFG
expect_driver claude tmux "(g)"
expect_driver codex somedriver "(g)"
expect_driver opencode tmux "(g)"
expect_driver hermes tmux "(g-absent-table)"
echo "driver-preference: (g) one family's preference does not leak to another: ok"

# --- (h) read at delivery time ------------------------------------------------
# No process restart, no cached value: the same shell resolves differently after
# the file changes, which is what makes flipping a family back to tmux a config
# edit rather than a fleet relaunch.
cat > "$CFG" <<'ENDCFG'
[harness.codex]
driver = "tmux"
ENDCFG
expect_driver codex tmux "(h-before)"
cat > "$CFG" <<'ENDCFG'
[harness.codex]
driver = "somedriver"
ENDCFG
expect_driver codex somedriver "(h-after)"
echo "driver-preference: (h) the preference is read fresh on every resolve: ok"

# --- (ref) the checked-in reference declares NO driver key at all -------------
# Two findings landed on this arm at once.
#
# sol-pinnacle: the old version used awk plus a substring test, so it could GREEN
# on a family whose real assignment was `driver = "ccnative"` with the word tmux
# appearing in a trailing comment. A substring is not a value, and an arm that
# accepts a comment as evidence is asserting on prose.
#
# And the reference no longer carries `driver` keys at all. They selected the
# default the code already provides, and their only live effect was to brick
# Python 3.10 operators who copied the file: the courier cannot parse it there,
# so an existing preference it cannot read forced a choice between refusing every
# send and silently ignoring the operator. Removing a key that never did anything
# dissolved that choice.
#
# So this arm now asserts ABSENCE, and it parses with tomllib rather than
# pattern-matching -- the same reader the courier uses, on the same file.
_ref_out="$(python3 -I -B - "$ROOT/skills/tap/config/config.v3.toml" <<'ENDPY'
import sys, tomllib
with open(sys.argv[1], "rb") as fh:
    doc = tomllib.load(fh)
bad = []
for fam, table in (doc.get("harness") or {}).items():
    if isinstance(table, dict) and "driver" in table:
        bad.append("%s=%r" % (fam, table["driver"]))
# The roles table legitimately has its own `driver` key describing a human role.
# Only [harness.*] is in scope here -- which is exactly why a whole-document
# substring test could never have been the right instrument.
print(" ".join(bad))
ENDPY
)" || fail "(ref) could not parse the checked-in reference config"
[ -z "$_ref_out" ] || \
  fail "(ref) the checked-in reference declares harness driver keys ($_ref_out); selection is a code fact and a shipped key only breaks python3.10 operators who copy this file"
echo "driver-preference: (ref) the checked-in reference declares no harness driver key: ok"


# --- (w) a legal, PARSEABLE name that nothing wires is refused, not loaded -----
# grok's finding on PR #xxx. The rebase put drivers/ccnative.sh in the tree, so
# Before tap-lcdm wired ccnative's typed builder, `driver = "ccnative"` parsed,
# resolved, and would have been sourced while this hop still forwarded tmux's argv
# tail. ccnative read its own first positional as the delivery class, got the
# harness family binary, returned rc 14, and parked the payload.
#
# What happens then was documented wrong here first, and the correction matters
# more than the original: redelivery does NOT go through the dispatcher
# (`tap_spool_redeliver` calls `tap_submit_verify` directly), so the parked
# payload is drained OVER TMUX. One malformed native attempt, then a silent
# transport crossing -- the operator picked a door and the message left by a
# different one. Parsing a name is not the same as having a call site that
# speaks it.
(
  tap_driver_wired_list() { printf '%s' 'tmux'; }
  cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "ccnative"
ENDCFG
  if err="$(tap_driver_for_harness claude 2>&1 >/dev/null)"; then
    fail "(w) an unwired driver resolved instead of refusing"
  fi
  case "$err" in
    *"no WIRED driver"*) : ;;
    *) fail "(w) refused, but not with the wiring reason: $err" ;;
  esac
  out="$(tap_driver_for_harness claude 2>/dev/null)"
  [ -z "$out" ] || fail "(w) refusal still emitted a driver name: '$out'"
) || exit 1
echo "driver-preference: (w) a parseable but unwired driver name is refused: ok"

# --- (w-env) THE ENVIRONMENT CANNOT WIDEN THE WIRED SET -----------------------
# sol-pinnacle's finding on 73d8ea79, and the reason the set is a function rather
# than a variable. The first version read the environment, so exporting a widened
# set resolved ccnative and restored the exact failure arm (w) exists to close: one
# malformed native invocation, then the parked payload crossing to tmux on the
# next drain. (An earlier version of this comment called that a permanent retry
# loop. It is not one -- redelivery bypasses the dispatcher -- and the wrong
# account had spread to five files before sol-pinnacle caught it.)
#
# Meanwhile CONTRACT claimed widening was "a wiring change, not a config change".
# The environment is operator-settable at runtime, so that sentence was false.
#
# The asymmetry is the point: the environment may NARROW what is selectable
# (TAP_DRIVER_FORCE_TMUX) and never WIDEN it. Narrowing cannot reach a door with
# no call site; widening reaches exactly those doors.
# THIS ARM MUST RUN AGAINST THE SHIPPED FILE, IN A CHILD SHELL. This suite
# overrides tap_driver_wired_list for its parser arms, and an in-shell probe here
# would be answered by that override rather than by the code -- the arm reported
# "ok" against a deliberately reintroduced environment seam before this was
# fixed. The fixture was more generous than the world, in the arm written to
# prove the world was safe.
# THE PLACEHOLDER MUST NAME A DRIVER THAT IS NOT IN THE SHIPPED SET, and it must
# keep being one. This arm used `ccnative` until ccnative was wired (tap-lcdm) --
# at which point the probe returned `ccnative` for the honest reason that it is
# selectable, and the arm could no longer distinguish "the environment widened
# the set" from "the set already contained it". It failed loudly, which is the
# good outcome; the bad one was available too, because an arm that reads the
# SHIPPED list decays silently the moment its example graduates.
#
# THE PLACEHOLDER MUST BE A LEGAL DRIVER NAME, or the arm never reaches the
# boundary it guards. The first repoint used `nosuchdriver-w-env`, and hyphens are
# rejected by TAP_DRIVER_NAME_RE (`^[a-z][a-z0-9_]*$`, lib.sh:10954) at the NAME
# gate -- BEFORE wired-set membership is consulted. Restoring the forbidden
# environment-widening left this test green, because the name died one gate
# earlier. sol-pinnacle caught it.
#
# That repoint was itself the fix for this arm having decayed when `ccnative` got
# wired. So the arm was repointed at a name that cannot reach its own boundary --
# the same false-green class it was being repointed to escape. Underscores.
#
# THE REFUSAL REASON IS ASSERTED, not just the absence of the name. "Did not
# return the name" is satisfied by a refusal at ANY gate, which is exactly how the
# hyphen version passed; only the reason distinguishes "the wired set held" from
# "the string was malformed".
cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "nosuchdriver_w_env"
ENDCFG
for _seam in TAP_DRIVER_WIRED TAP_DRIVER_WIRED_LIST; do
  _wenv_out="$(env "$_seam=tmux nosuchdriver_w_env" XDG_CONFIG_HOME="$XDG_CONFIG_HOME" \
    bash -c '. "$1" >/dev/null 2>&1; tap_driver_for_harness claude 2>&1 >/dev/null' \
    _ "$ROOT/skills/tap/scripts/lib.sh")" || true
  _got="$(env "$_seam=tmux nosuchdriver_w_env" XDG_CONFIG_HOME="$XDG_CONFIG_HOME" \
    bash -c '. "$1" >/dev/null 2>&1; tap_driver_for_harness claude 2>/dev/null' \
    _ "$ROOT/skills/tap/scripts/lib.sh")" || true
  [ "$_got" != nosuchdriver_w_env ] || \
    fail "(w-env) exporting $_seam widened the shipped wired set to reach an unwired driver"
  case "$_wenv_out" in
    *"no WIRED driver"*) : ;;
    *) fail "(w-env) $_seam: refused, but not at the WIRING gate — the arm did not reach the boundary it guards. stderr: $_wenv_out" ;;
  esac
done
# THE POSITIVE CONTROL. Without it "the probe did not return the name" is
# satisfied by a probe that returns nothing at all -- a broken invocation, a
# lib.sh that fails to source, a typo in the bash -c body -- and the arm above
# would report ok forever. The shipped set contains tmux, so this
# call MUST come back with it; if it does not, the instrument is disconnected and
# the refusal above proved nothing.
_wired_control="$(env XDG_CONFIG_HOME="$XDG_CONFIG_HOME" \
  bash -c 'cat > "$2" <<EOF
[harness.claude]
driver = "tmux"
EOF
. "$1" >/dev/null 2>&1; tap_driver_for_harness claude 2>/dev/null' \
  _ "$ROOT/skills/tap/scripts/lib.sh" "$CFG")" || true
[ "$_wired_control" = tmux ] || \
  fail "(w-env) positive control failed: a WIRED driver did not resolve either, so the refusals above are not evidence (got '$_wired_control')"
echo "driver-preference: (w-env) no environment variable widens the wired set: ok"

# --- (w-mirror) the refusal is the allowlist, not a hardcoded name ------------
# Bounds the fix. Without this, (w) is equally satisfied by code that special-
# cases the string "ccnative", which would refuse the next unwired door by luck.
# The override is a FUNCTION definition, which ships nothing -- a mutant that
# hardcodes the name ignores the function entirely, so it cannot be rescued here
# and this arm reds.
(
  tap_driver_wired_list() { printf '%s' 'tmux ccnative'; }
  cat > "$CFG" <<'ENDCFG'
[harness.claude]
driver = "ccnative"
ENDCFG
  got="$(tap_driver_for_harness claude 2>/dev/null)" || fail "(w-mirror) a wired driver was refused"
  [ "$got" = ccnative ] || fail "(w-mirror) resolved to '$got', expected ccnative"
) || exit 1
echo "driver-preference: (w-mirror) wiring a driver makes it selectable again: ok"

# --- (w-tmux) the SHIPPED set is EXACTLY what we think it is ------------------
# Read out of the shipped file rather than the sourced shell, because this suite
# overrides the function for its own arms and would otherwise be asserting
# against its own override.
#
# The point of pinning the literal is that WIRING A DRIVER MUST BE A DELIBERATE
# ACT that shows up in a diff of this file. Adding a name to the shipped set
# reds here, and the person adding it has to come and say so -- which is the
# moment to check that the call site landed in the same commit, because a wired
# name with no call site is selectable and dispatches through tmux's tail.
#
# Retired native adapters cannot be selected, including when their old config remains.
_shipped="$(bash -c '. "$1" >/dev/null 2>&1; tap_driver_wired_list' _ "$ROOT/skills/tap/scripts/lib.sh")"
[ "$_shipped" = 'tmux' ] || fail "(w-tmux) the shipped wired set is '$_shipped', expected exactly 'tmux'"
for _retired in agy ccnative; do
  printf '[harness.claude]\ndriver = "%s"\n' "$_retired" > "$CFG"
  if _retired_err="$(bash -c '. "$1" >/dev/null 2>&1; tap_driver_for_harness claude' _ "$ROOT/skills/tap/scripts/lib.sh" 2>&1)"; then
    fail "retired driver $_retired was selectable"
  fi
  case "$_retired_err" in
    *"no WIRED driver"*"remove the driver key or set it to tmux"*) ;;
    *) fail "retired driver refusal lost its repair: $_retired_err" ;;
  esac
done
echo "driver-preference: (w-tmux) only tmux ships; native adapter configs refuse: ok"

# --- (w-callsite) every WIRED driver has a deliver function -------------------
# The invariant the arm above protects, asserted directly rather than left to a
# reviewer noticing. `tmux` is exempt: it is the courier, and its deliver is a
# one-line wrapper defined in lib.sh itself rather than a module under drivers/.
for _wired in $_shipped; do
  [ "$_wired" = tmux ] && continue
  [ -f "$ROOT/skills/tap/scripts/drivers/$_wired.sh" ] || \
    fail "(w-callsite) '$_wired' is in the wired set but has no drivers/$_wired.sh"
  grep -q "^tapdrv_${_wired}_deliver()" "$ROOT/skills/tap/scripts/drivers/$_wired.sh" || \
    fail "(w-callsite) drivers/$_wired.sh defines no tapdrv_${_wired}_deliver"
  # _args IS REQUIRED TOO (grok, PR #xxx panel). `tap_driver_deliver` falls back to
  # forwarding the courier's own argv when a driver defines no `_args` -- a real
  # branch, kept for a driver that genuinely wants tmux's tail. But OMISSION and
  # INTENT are indistinguishable at that branch, so a wired driver that simply
  # forgot its builder silently takes the courier-argv path and receives the harness
  # family binary where it expects its own first positional. Pinning both means the
  # fallback is UNREACHABLE FOR ANY WIRED DRIVER while this arm stands, and a typo reds
  # here instead of shipping.
  #
  # Precisely: `lib.sh` branches on `declare -F tapdrv_<name>_args`, i.e. on the builder's
  # ABSENCE — there is no declaration mechanism a driver can opt into. An earlier version
  # of this comment said the fallback "can only be reached by a driver that declares it",
  # which describes an opt-in that does not exist. The branch is real and reachable only
  # by an UNWIRED driver; this arm is what keeps every wired one out of it.
  grep -q "^tapdrv_${_wired}_args()" "$ROOT/skills/tap/scripts/drivers/$_wired.sh" || \
    fail "(w-callsite) drivers/$_wired.sh defines no tapdrv_${_wired}_args; the dispatcher would forward the courier's argv to it"
done
echo "driver-preference: (w-callsite) every wired driver has both a deliver and an args builder: ok"

# --- (w-py310) no TOML parser: tmux, but never silently ----------------------
# This arm has been rewritten twice and the history is the point.
#
# v1: `import tomllib` unconditional -> EVERY pane send failed on a supported
#     Python 3.10 whenever any config.toml existed. sol-pinnacle, P1.
# v2: default to tmux whenever tmux was the only wired driver. She rejected it:
#     REACHABILITY IS NOT INTENT -- a config naming ccnative answered with a
#     successful send through tmux tells a programmatic sender it went out the
#     door it asked for.
# v3: refuse any existing unparseable config. She rejected that too, from the
#     other side: the documented floor promises ordinary sends keep working on
#     3.10, and the shipped reference carried `driver` keys, so every operator
#     who copied it was bricked.
#
# v4 is the same behaviour with the RATIONALE corrected, and the correction is
# the load-bearing part. v3's comment said the operator reaching this path
# HAND-WROTE a preference. grok drove that false: copy the shipped reference
# as-is -- which now has NO harness driver key -- stub the resolve to rc 4, and
# you land here identically. Parserless, the courier can see only that a file
# EXISTS, so the population here is "has a config.toml", including everyone who
# followed the `cp` in that file's own header.
#
# So refusing would brick the floor population WITHOUT catching the preferer,
# because the preferer cannot be identified without parsing. That -- not "the key
# did nothing" -- is why availability wins. The residual is real: a sender that
# checks only the return code sees success through tmux for a non-tmux key nobody
# can prove was there. The diagnostic is worded conditionally for that reason.
#
# A byte-level presence test for `driver` was tried and abandoned: TOML keys
# repeat across tables, the reference's own [roles] table has a `driver` key, and
# deciding which table a key belongs to is parsing -- the thing unavailable here.
(
  tap_driver_config_resolve() { return 4; }   # "this python has no tomllib"
  for _body in 'driver = "tmux"' 'driver = "ccnative"' 'this is not toml' ''; do
    printf '[harness.claude]\n%s\n' "$_body" > "$CFG"
    got="$(tap_driver_for_harness claude 2>/dev/null)" || \
      fail "(w-py310) a parserless resolve failed the send outright (body: $_body)"
    [ "$got" = tmux ] || fail "(w-py310) resolved to '$got', expected tmux (body: $_body)"
    err="$(tap_driver_for_harness claude 2>&1 >/dev/null)"
    # The diagnostic must say the preference is NOT IN EFFECT, not merely that
    # something went wrong. "tmux was selected" and "your choice was discarded"
    # are different messages and only the second is honest here.
    case "$err" in
      *"NOT in effect"*) : ;;
      *) fail "(w-py310) the advisory did not say the preference is not in effect: $err" ;;
    esac
    case "$err" in
      *TAP_DRIVER_FORCE_TMUX*) : ;;
      *) fail "(w-py310) the advisory did not name an executable recovery: $err" ;;
    esac
    # It must REPEAT. A once-only notice is how this becomes silent.
    err2="$(tap_driver_for_harness claude 2>&1 >/dev/null)"
    case "$err2" in
      *"NOT in effect"*) : ;;
      *) fail "(w-py310) the advisory did not repeat (body: $_body)" ;;
    esac
  done
  # ABSENT config is the ordinary 3.10 path: tmux, and NO advisory, because
  # nothing was ignored.
  rm -f "$CFG"
  got="$(tap_driver_for_harness claude 2>/dev/null)" || fail "(w-py310) an absent config failed on a parserless python"
  [ "$got" = tmux ] || fail "(w-py310) an absent config resolved to '$got'"
  err="$(tap_driver_for_harness claude 2>&1 >/dev/null)"
  [ -z "$err" ] || fail "(w-py310) an absent config emitted an advisory about a preference nobody wrote: $err"
  # And the emergency switch still short-circuits before the config is opened.
  printf '[harness.claude]\ndriver = "ccnative"\n' > "$CFG"
  got="$(TAP_DRIVER_FORCE_TMUX=1 tap_driver_for_harness claude 2>/dev/null)" || \
    fail "(w-py310) FORCE_TMUX did not survive a parserless resolve"
  [ "$got" = tmux ] || fail "(w-py310) FORCE_TMUX resolved to '$got'"
) || exit 1
echo "driver-preference: (w-py310) a parserless resolve takes tmux and says so, every time: ok"

# --- (w-dangling) a dangling config symlink is present, not absent ------------
(
  rm -f "$CFG"; ln -s "$CFG.nope" "$CFG"
  if tap_driver_for_harness claude >/dev/null 2>&1; then
    fail "(w-dangling) a dangling config symlink silently took the tmux default"
  fi
  rm -f "$CFG"
) || exit 1
echo "driver-preference: (w-dangling) a dangling config symlink refuses: ok"

# --- (w-relxdg) a relative config home cannot choose the door -----------------
# A cwd-relative config home makes the delivery driver a function of where the
# courier happened to be run from.
(
  XDG_CONFIG_HOME="relative/config"
  export XDG_CONFIG_HOME
  if tap_driver_for_harness claude >/dev/null 2>&1; then
    fail "(w-relxdg) a relative XDG_CONFIG_HOME was accepted"
  fi
) || exit 1
echo "driver-preference: (w-relxdg) a relative XDG_CONFIG_HOME refuses: ok"

# --- (w-ctl) control characters are rejected where the bytes are exact --------
# `driver = "native\u0000"` and `driver = "native\n"` are valid TOML that the
# shell cannot carry through `$(...)`: NUL is dropped, a trailing newline is
# stripped. Validating downstream of a lossy channel validates the wrong bytes.
for _ctl in '\u0000' '\n' '\u007f'; do
  printf '[harness.claude]\ndriver = "native%s"\n' "$_ctl" > "$CFG"
  if tap_driver_for_harness claude >/dev/null 2>&1; then
    fail "(w-ctl) a driver value containing $_ctl was accepted"
  fi
done
echo "driver-preference: (w-ctl) control characters in a driver value are refused: ok"

# --- (w-shadow) the repository cannot shadow the parser this hop imports ------
# sol-pinnacle's P1. `python3 -B -` leaves the CWD on sys.path, and inserting the
# trusted session directory at index 0 only moves the untrusted entry to index 1.
# A repo carrying its own tomllib.py therefore had that file IMPORTED AND
# EXECUTED with the sender's credentials on every send that reads config -- and
# could return any driver policy it liked from loads(). Reproduced before the
# fix: the marker file was written and tomllib.__spec__.origin pointed into the
# repo.
#
# Both names are probed. tomllib is the one that was exploited; pathlib is the
# one that would be reached for next, and an arm that covers only the reported
# name tests the report rather than the class.
(
  _shadow="$(mktemp -d)"
  mkdir -p "$_shadow/repo" "$_shadow/cfg/tap"
  printf '[harness.claude]\ndriver = "tmux"\n' > "$_shadow/cfg/tap/config.toml"
  for _mod in tomllib pathlib; do
    rm -f "$_shadow/repo"/*.py "$_shadow/marker"
    cat > "$_shadow/repo/$_mod.py" <<ENDPY
import os
open(os.environ["TAP_SHADOW_MARKER"], "w").write("executed")
def loads(s):
    return {"harness": {"claude": {"driver": "ccnative"}}}
class TOMLDecodeError(Exception):
    pass
ENDPY
    _got="$(cd "$_shadow/repo" && env TAP_SHADOW_MARKER="$_shadow/marker" \
      XDG_CONFIG_HOME="$_shadow/cfg" \
      bash -c '. "$1" >/dev/null 2>&1; tap_driver_for_harness claude 2>/dev/null' \
      _ "$ROOT/skills/tap/scripts/lib.sh")" || true
    [ ! -f "$_shadow/marker" ] || \
      fail "(w-shadow) a repo-local $_mod.py was EXECUTED by the config read"
    [ "$_got" != ccnative ] || \
      fail "(w-shadow) a repo-local $_mod.py dictated the driver policy"
  done
  rm -rf "$_shadow"
) || exit 1
echo "driver-preference: (w-shadow) a repo-local tomllib.py/pathlib.py neither executes nor sets policy: ok"

# --- (w-shadow-path) the PYTHONPATH half of the same boundary -----------------
# sol-pinnacle. (w-shadow) runs FROM the directory holding the shadow module, so
# it proves only that -I drops the CWD. The implementation comment claims more
# than that -- it says -I also ignores PYTHONPATH and user site -- and a guard
# that asserts a wider boundary than its arm covers is a safety claim pointing
# past its own evidence.
#
# The concrete substitution this catches: `-P` drops sys.path[0] and leaves
# PYTHONPATH honoured. (w-shadow) stays green under it while imports from an
# attacker-controlled path are wide open again.
(
  _sp="$(mktemp -d)"
  mkdir -p "$_sp/evil" "$_sp/clean" "$_sp/cfg/tap"
  printf '[harness.claude]\ndriver = "tmux"\n' > "$_sp/cfg/tap/config.toml"
  for _mod in tomllib pathlib; do
    rm -f "$_sp/evil"/*.py "$_sp/marker"
    cat > "$_sp/evil/$_mod.py" <<ENDPY
import os
open(os.environ["TAP_SHADOW_MARKER"], "w").write("executed")
def loads(s):
    return {"harness": {"claude": {"driver": "ccnative"}}}
class TOMLDecodeError(Exception):
    pass
ENDPY
    _got="$(cd "$_sp/clean" && env PYTHONPATH="$_sp/evil" TAP_SHADOW_MARKER="$_sp/marker" \
      XDG_CONFIG_HOME="$_sp/cfg" \
      bash -c '. "$1" >/dev/null 2>&1; tap_driver_for_harness claude 2>/dev/null' \
      _ "$ROOT/skills/tap/scripts/lib.sh")" || true
    [ ! -f "$_sp/marker" ] || \
      fail "(w-shadow-path) $_mod.py supplied through PYTHONPATH was EXECUTED by the config read"
    [ "$_got" != ccnative ] || \
      fail "(w-shadow-path) $_mod.py supplied through PYTHONPATH dictated the driver policy"
  done
  rm -rf "$_sp"
) || exit 1
echo "driver-preference: (w-shadow-path) PYTHONPATH cannot supply the parser either: ok"

# --- (w-py310-producer) the REAL resolver returns rc 4 with no tomllib ---------
# Two independent reviewers found the same hole: (w-py310) stubs
# tap_driver_config_resolve to `return 4`, so it tests the CONSUMER's semantics
# and would stay green if the real embedded Python stopped producing rc 4 at all.
# The producer and the caller were both asserted and only one was measured.
#
# No Python version matrix. Run the REAL heredoc on the current interpreter with
# an import hook that makes ONLY tomllib raise ModuleNotFoundError, and assert
# the producer's exit status is 4. Everything else about the resolver -- the
# secure read, the argv shape, isolated mode -- stays exactly as shipped.
(
  _pw="$(mktemp -d)"
  # Extract the heredoc body from the shipped lib.sh rather than restating it.
  # A copy of the source would drift; this reds if the resolver is rewritten.
  python3 -I -B - "$ROOT/skills/tap/scripts/lib.sh" "$_pw/resolver.py" <<'ENDPY'
import re, sys
src = open(sys.argv[1]).read()
m = re.search(r"tap_driver_config_resolve\(\) \{.*?<<'ENDPY'[^\n]*\n(.*?)\nENDPY\n", src, re.S)
if not m:
    sys.exit("could not extract the resolver heredoc from lib.sh")
open(sys.argv[2], "w").write(m.group(1))
ENDPY
  [ -s "$_pw/resolver.py" ] || fail "(w-py310-producer) could not extract the real resolver body"
  printf '[harness.claude]\ndriver = "ccnative"\n' > "$_pw/config.toml"
  # argv shape must match what lib.sh passes: <script-dir> <config-path> <family>
  set +e
  python3 -I -B -c "
import sys, runpy
class NoTomllib:
    def find_spec(self, name, path=None, target=None):
        if name == 'tomllib':
            raise ModuleNotFoundError(\"No module named 'tomllib'\")
        return None
sys.meta_path.insert(0, NoTomllib())
sys.argv = ['-'] + sys.argv[1:]
runpy.run_path('$_pw/resolver.py', run_name='__main__')
" "$ROOT/skills/tap/scripts" "$_pw/config.toml" claude >/dev/null 2>&1
  _prc=$?
  set -e
  [ "$_prc" = 4 ] || \
    fail "(w-py310-producer) the real resolver returned $_prc without tomllib, expected 4; the consumer arm stubs this and cannot see it"
  # BOUND: with tomllib available the same body must NOT return 4, or the arm
  # would pass against a resolver that returns 4 unconditionally.
  set +e
  python3 -I -B "$_pw/resolver.py" "$ROOT/skills/tap/scripts" "$_pw/config.toml" claude >/dev/null 2>&1
  _grc=$?
  set -e
  [ "$_grc" != 4 ] || \
    fail "(w-py310-producer) the resolver returned 4 even WITH tomllib; the arm proves nothing"
  rm -rf "$_pw"
) || exit 1
echo "driver-preference: (w-py310-producer) the real resolver exits 4 only when tomllib is absent: ok"

echo "driver-preference: ok"
