"""`tap team up --only` resolves against candidate records, not the registry (tap-sttl).

No lifecycle verb precomputes a complement in bash: the typed set is carried
positive and each verb asks the spared question against its own snapshot at plan
time. Resume is the verb whose snapshot lives in Python, so its resolution does
too — and it is also the one where the handle mapping can differ, because
``SessionRecord.tag`` is optional (``str | None``) and ``session_handle`` can
therefore return a handle with no registry row. Resolving against the registry
would leave such a record out of the spared set and relaunch a seat the operator
never named — the failure these tests exist to prevent.
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import pathlib
import sys
import tempfile
import unittest

_SCRIPTS = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_SCRIPTS))
import launcher  # noqa: E402


def _record(name: str, tag: str | None) -> launcher.SessionRecord:
    return launcher.SessionRecord(name=name, harness="claude", cwd="/tmp/demo", base="demo", tag=tag)


class TeamOnlyResolutionTest(unittest.TestCase):
    def test_spares_every_record_not_named(self) -> None:
        records = [_record("demo/kimi", "kimi"), _record("demo/grok", "grok"), _record("demo/sonnet", "sonnet")]
        self.assertEqual(launcher.only_to_excepted(records, {"kimi"}), {"grok", "sonnet"})

    def test_named_records_are_not_spared(self) -> None:
        records = [_record("demo/kimi", "kimi"), _record("demo/grok", "grok")]
        self.assertEqual(launcher.only_to_excepted(records, {"kimi", "grok"}), set())

    def test_untagged_record_is_still_spared(self) -> None:
        """The whole reason this resolves against records instead of the registry.

        An untagged record has no registry row, so a registry-derived complement
        would not contain its handle — leaving it un-spared and relaunched. Here
        it must land in the spared set like any other unnamed candidate.
        """
        untagged = _record("demo/adopted", None)
        records = [_record("demo/kimi", "kimi"), untagged]
        excepted = launcher.only_to_excepted(records, {"kimi"})
        self.assertIn(launcher.session_handle(untagged), excepted)
        self.assertNotIn("kimi", excepted)

    def test_naming_every_record_spares_nobody(self) -> None:
        records = [_record("demo/kimi", "kimi"), _record("demo/grok", "grok")]
        self.assertEqual(launcher.only_to_excepted(records, {"kimi", "grok"}), set())

    def test_unknown_handle_does_not_widen_the_action(self) -> None:
        """bash refuses an unknown handle before this runs; if it ever did not,
        the resolution must still spare every real candidate rather than fall
        through to acting on all of them."""
        records = [_record("demo/kimi", "kimi"), _record("demo/grok", "grok")]
        self.assertEqual(launcher.only_to_excepted(records, {"typo"}), {"kimi", "grok"})


class TeamOnlyEnvTest(unittest.TestCase):
    def setUp(self) -> None:
        os.environ.pop("TAP_TEAM_ONLY_HANDLES", None)

    def tearDown(self) -> None:
        os.environ.pop("TAP_TEAM_ONLY_HANDLES", None)

    def test_absent_env_is_an_empty_selection(self) -> None:
        self.assertEqual(launcher.team_only_handles(), set())

    def test_blob_splits_and_drops_blanks(self) -> None:
        os.environ["TAP_TEAM_ONLY_HANDLES"] = "kimi\ngrok\n"
        self.assertEqual(launcher.team_only_handles(), {"kimi", "grok"})

    def test_value_is_popped_so_a_resumed_seat_does_not_inherit_it(self) -> None:
        os.environ["TAP_TEAM_ONLY_HANDLES"] = "kimi\n"
        launcher.team_only_handles()
        self.assertNotIn("TAP_TEAM_ONLY_HANDLES", os.environ)



# The three classes that drove `attach_partition.partition()` directly moved to
# `runtime/bun/test/launcher-attach-partition.test.ts` with the body they tested:
# AttachCanonicalHandleGuardTest, AttachPartitionSelectionTest and
# AttachPartitionTeamNamespaceTest. They imported the Python module, so they
# stopped testing anything the moment it became Bun -- and no live Python caller
# survives to keep as an oracle, which is why their inputs were captured into
# `runtime/bun/test/fixtures/attach-partition-oracle.json` BEFORE the deletion.
# What stays here is everything that drives `launcher` itself.

class UpReceiptsTest(unittest.TestCase):
    """`tap team up`'s receipts under --only (sol-prepull).

    Two distinct rules meet here. TEXT names the TYPED selection, because that is
    what the operator recognizes. The --json companion stderr line names the
    EFFECTIVE spared set, because it sits beside `excluded[]` and a consumer of
    those fields reconciles against real sessions. Reporting the typed clause on
    the JSON path made the two halves of one message disagree.
    """

    def _resume(self, only_handles, records, as_json):
        import argparse
        import contextlib as _ctx

        os.environ["TAP_TEAM_ONLY_HANDLES"] = "".join(f"{h}\n" for h in only_handles)
        args = argparse.Namespace(key=None, legacy_name=None, json=as_json, dry_run=False)
        state = launcher.Manifest(sessions=records, dir_aliases={"/tmp/demo": "demo"})
        out, err = io.StringIO(), io.StringIO()
        originals = {
            name: getattr(launcher, name)
            for name in ("tmux_sessions_for_namespace", "refuse_if_team_reset_fenced",
                         "_reset_fence_entry_barrier", "_refuse_if_flip_authority", "in_scope")
        }
        try:
            # Every record already LIVE, so nothing is relaunchable and the
            # function returns right after emitting its receipt. The receipt is
            # what is under test; letting it proceed to a real launch would only
            # exercise tmux.
            launcher.tmux_sessions_for_namespace = lambda: {r.name for r in records}
            launcher.refuse_if_team_reset_fenced = lambda *a, **k: None
            launcher._reset_fence_entry_barrier = lambda *a, **k: None
            launcher._refuse_if_flip_authority = lambda *a, **k: None
            launcher.in_scope = lambda record, cwd, machine=False: True
            with _ctx.redirect_stdout(out), _ctx.redirect_stderr(err):
                launcher.cmd_resume_all(args, state, "/tmp/demo")
        finally:
            for name, fn in originals.items():
                setattr(launcher, name, fn)
            os.environ.pop("TAP_TEAM_ONLY_HANDLES", None)
        return out.getvalue(), err.getvalue()

    def _records(self):
        return [
            launcher.SessionRecord(name="demo/kimi", harness="claude", cwd="/tmp/demo", base="demo", tag="kimi", index=1),
            launcher.SessionRecord(name="demo/grok", harness="claude", cwd="/tmp/demo", base="demo", tag="grok", index=1),
        ]

    def test_text_partial_selection_names_the_typed_set(self) -> None:
        out, _err = self._resume(["kimi"], self._records(), as_json=False)
        self.assertIn("--only kimi", out)
        # grok is the complement; naming it would report a seat never typed.
        self.assertNotIn("by --except", out)

    def test_whole_roster_only_still_names_its_selector(self) -> None:
        """Nothing is spared, so a receipt gated on `spared` printed nothing."""
        out, _err = self._resume(["kimi", "grok"], self._records(), as_json=False)
        self.assertIn("matched every seat", out)
        self.assertIn("--only", out)

    def test_json_companion_reports_the_effective_set(self) -> None:
        # Only the SPARED record is in scope, so the plan empties and the
        # all-spared aggregate (excluded[] + its stderr companion) is emitted.
        grok_only = [self._records()[1]]
        out, err = self._resume(["kimi"], grok_only, as_json=True)
        # UNCONDITIONAL. An earlier version guarded both assertions with
        # `if '"excluded"' in out`, so deleting the aggregate outright left the
        # test green — a pin that asserts nothing when the thing it pins is gone
        # (sol-prepull). Parse the aggregate and require it, then check the
        # companion line agrees with it.
        aggregate = json.loads(out.strip().splitlines()[-1])
        self.assertEqual(aggregate["excluded"], ["grok"])
        self.assertEqual(aggregate["count"], 0)
        # The stderr companion reports the EFFECTIVE set beside excluded[], not
        # the typed clause — the two halves of one message must agree.
        self.assertIn("grok", err)
        self.assertNotIn("selection (--only", err)


if __name__ == "__main__":
    unittest.main()
